/* A Bison parser, made by GNU Bison 3.7.2.  */

/* Skeleton implementation for Bison GLR parsers in C

   Copyright (C) 2002-2015, 2018-2020 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C GLR parser skeleton written by Paul Hilfinger.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "3.7.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "glr.c"

/* Pure parsers.  */
#define YYPURE 0







# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "src/parser.hpp"

/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_PROGRAM = 3,                    /* PROGRAM  */
  YYSYMBOL_CLASS = 4,                      /* CLASS  */
  YYSYMBOL_TYPE = 5,                       /* TYPE  */
  YYSYMBOL_FUNCTION = 6,                   /* FUNCTION  */
  YYSYMBOL_OPERATOR = 7,                   /* OPERATOR  */
  YYSYMBOL_AUTO = 8,                       /* AUTO  */
  YYSYMBOL_LET = 9,                        /* LET  */
  YYSYMBOL_IF = 10,                        /* IF  */
  YYSYMBOL_ELSE = 11,                      /* ELSE  */
  YYSYMBOL_FOR = 12,                       /* FOR  */
  YYSYMBOL_IN = 13,                        /* IN  */
  YYSYMBOL_WHILE = 14,                     /* WHILE  */
  YYSYMBOL_DO = 15,                        /* DO  */
  YYSYMBOL_WITH = 16,                      /* WITH  */
  YYSYMBOL_ASSERT = 17,                    /* ASSERT  */
  YYSYMBOL_RETURN = 18,                    /* RETURN  */
  YYSYMBOL_FACTOR = 19,                    /* FACTOR  */
  YYSYMBOL_CPP = 20,                       /* CPP  */
  YYSYMBOL_HPP = 21,                       /* HPP  */
  YYSYMBOL_THIS = 22,                      /* THIS  */
  YYSYMBOL_SUPER = 23,                     /* SUPER  */
  YYSYMBOL_GLOBAL = 24,                    /* GLOBAL  */
  YYSYMBOL_PARALLEL = 25,                  /* PARALLEL  */
  YYSYMBOL_DYNAMIC = 26,                   /* DYNAMIC  */
  YYSYMBOL_ABSTRACT = 27,                  /* ABSTRACT  */
  YYSYMBOL_OVERRIDE = 28,                  /* OVERRIDE  */
  YYSYMBOL_FINAL = 29,                     /* FINAL  */
  YYSYMBOL_NIL = 30,                       /* NIL  */
  YYSYMBOL_DOUBLE_BRACE_OPEN = 31,         /* DOUBLE_BRACE_OPEN  */
  YYSYMBOL_DOUBLE_BRACE_CLOSE = 32,        /* DOUBLE_BRACE_CLOSE  */
  YYSYMBOL_NAME = 33,                      /* NAME  */
  YYSYMBOL_BOOL_LITERAL = 34,              /* BOOL_LITERAL  */
  YYSYMBOL_INT_LITERAL = 35,               /* INT_LITERAL  */
  YYSYMBOL_REAL_LITERAL = 36,              /* REAL_LITERAL  */
  YYSYMBOL_STRING_LITERAL = 37,            /* STRING_LITERAL  */
  YYSYMBOL_LEFT_OP = 38,                   /* LEFT_OP  */
  YYSYMBOL_RIGHT_OP = 39,                  /* RIGHT_OP  */
  YYSYMBOL_LEFT_TILDE_OP = 40,             /* LEFT_TILDE_OP  */
  YYSYMBOL_RIGHT_TILDE_OP = 41,            /* RIGHT_TILDE_OP  */
  YYSYMBOL_LEFT_QUERY_OP = 42,             /* LEFT_QUERY_OP  */
  YYSYMBOL_AND_OP = 43,                    /* AND_OP  */
  YYSYMBOL_OR_OP = 44,                     /* OR_OP  */
  YYSYMBOL_LE_OP = 45,                     /* LE_OP  */
  YYSYMBOL_GE_OP = 46,                     /* GE_OP  */
  YYSYMBOL_EQ_OP = 47,                     /* EQ_OP  */
  YYSYMBOL_NE_OP = 48,                     /* NE_OP  */
  YYSYMBOL_RANGE_OP = 49,                  /* RANGE_OP  */
  YYSYMBOL_50_ = 50,                       /* '('  */
  YYSYMBOL_51_ = 51,                       /* ')'  */
  YYSYMBOL_52_ = 52,                       /* '['  */
  YYSYMBOL_53_ = 53,                       /* ']'  */
  YYSYMBOL_54_ = 54,                       /* '?'  */
  YYSYMBOL_55_ = 55,                       /* '\\'  */
  YYSYMBOL_56_ = 56,                       /* ','  */
  YYSYMBOL_57_ = 57,                       /* '.'  */
  YYSYMBOL_58_ = 58,                       /* '!'  */
  YYSYMBOL_59_ = 59,                       /* '+'  */
  YYSYMBOL_60_ = 60,                       /* '-'  */
  YYSYMBOL_61_ = 61,                       /* '*'  */
  YYSYMBOL_62_ = 62,                       /* '/'  */
  YYSYMBOL_63_ = 63,                       /* '<'  */
  YYSYMBOL_64_ = 64,                       /* '>'  */
  YYSYMBOL_65_ = 65,                       /* ':'  */
  YYSYMBOL_66___ = 66,                     /* '_'  */
  YYSYMBOL_67_ = 67,                       /* ';'  */
  YYSYMBOL_68_ = 68,                       /* '='  */
  YYSYMBOL_69_ = 69,                       /* '~'  */
  YYSYMBOL_70_ = 70,                       /* '{'  */
  YYSYMBOL_71_ = 71,                       /* '}'  */
  YYSYMBOL_72_ = 72,                       /* '&'  */
  YYSYMBOL_YYACCEPT = 73,                  /* $accept  */
  YYSYMBOL_name = 74,                      /* name  */
  YYSYMBOL_bool_literal = 75,              /* bool_literal  */
  YYSYMBOL_int_literal = 76,               /* int_literal  */
  YYSYMBOL_real_literal = 77,              /* real_literal  */
  YYSYMBOL_string_literal = 78,            /* string_literal  */
  YYSYMBOL_literal = 79,                   /* literal  */
  YYSYMBOL_identifier = 80,                /* identifier  */
  YYSYMBOL_parens_expression = 81,         /* parens_expression  */
  YYSYMBOL_sequence_expression = 82,       /* sequence_expression  */
  YYSYMBOL_cast_expression = 83,           /* cast_expression  */
  YYSYMBOL_function_expression = 84,       /* function_expression  */
  YYSYMBOL_this_expression = 85,           /* this_expression  */
  YYSYMBOL_super_expression = 86,          /* super_expression  */
  YYSYMBOL_nil_expression = 87,            /* nil_expression  */
  YYSYMBOL_primary_expression = 88,        /* primary_expression  */
  YYSYMBOL_index_expression = 89,          /* index_expression  */
  YYSYMBOL_index_list = 90,                /* index_list  */
  YYSYMBOL_slice = 91,                     /* slice  */
  YYSYMBOL_postfix_expression = 92,        /* postfix_expression  */
  YYSYMBOL_query_expression = 93,          /* query_expression  */
  YYSYMBOL_prefix_operator = 94,           /* prefix_operator  */
  YYSYMBOL_prefix_expression = 95,         /* prefix_expression  */
  YYSYMBOL_multiplicative_operator = 96,   /* multiplicative_operator  */
  YYSYMBOL_multiplicative_expression = 97, /* multiplicative_expression  */
  YYSYMBOL_additive_operator = 98,         /* additive_operator  */
  YYSYMBOL_additive_expression = 99,       /* additive_expression  */
  YYSYMBOL_relational_operator = 100,      /* relational_operator  */
  YYSYMBOL_relational_expression = 101,    /* relational_expression  */
  YYSYMBOL_equality_operator = 102,        /* equality_operator  */
  YYSYMBOL_equality_expression = 103,      /* equality_expression  */
  YYSYMBOL_logical_and_operator = 104,     /* logical_and_operator  */
  YYSYMBOL_logical_and_expression = 105,   /* logical_and_expression  */
  YYSYMBOL_logical_or_operator = 106,      /* logical_or_operator  */
  YYSYMBOL_logical_or_expression = 107,    /* logical_or_expression  */
  YYSYMBOL_assign_operator = 108,          /* assign_operator  */
  YYSYMBOL_assign_expression = 109,        /* assign_expression  */
  YYSYMBOL_expression = 110,               /* expression  */
  YYSYMBOL_optional_expression = 111,      /* optional_expression  */
  YYSYMBOL_expression_list = 112,          /* expression_list  */
  YYSYMBOL_span_expression = 113,          /* span_expression  */
  YYSYMBOL_span_list = 114,                /* span_list  */
  YYSYMBOL_brackets = 115,                 /* brackets  */
  YYSYMBOL_parameters = 116,               /* parameters  */
  YYSYMBOL_optional_parameters = 117,      /* optional_parameters  */
  YYSYMBOL_parameter_list = 118,           /* parameter_list  */
  YYSYMBOL_parameter = 119,                /* parameter  */
  YYSYMBOL_options = 120,                  /* options  */
  YYSYMBOL_option_list = 121,              /* option_list  */
  YYSYMBOL_option = 122,                   /* option  */
  YYSYMBOL_arguments = 123,                /* arguments  */
  YYSYMBOL_optional_arguments = 124,       /* optional_arguments  */
  YYSYMBOL_shape = 125,                    /* shape  */
  YYSYMBOL_generics = 126,                 /* generics  */
  YYSYMBOL_generic_list = 127,             /* generic_list  */
  YYSYMBOL_generic = 128,                  /* generic  */
  YYSYMBOL_optional_generics = 129,        /* optional_generics  */
  YYSYMBOL_generic_arguments = 130,        /* generic_arguments  */
  YYSYMBOL_generic_argument_list = 131,    /* generic_argument_list  */
  YYSYMBOL_generic_argument = 132,         /* generic_argument  */
  YYSYMBOL_optional_generic_arguments = 133, /* optional_generic_arguments  */
  YYSYMBOL_global_variable_declaration = 134, /* global_variable_declaration  */
  YYSYMBOL_member_variable_declaration = 135, /* member_variable_declaration  */
  YYSYMBOL_local_variable_declaration = 136, /* local_variable_declaration  */
  YYSYMBOL_function_declaration = 137,     /* function_declaration  */
  YYSYMBOL_138_1 = 138,                    /* $@1  */
  YYSYMBOL_member_function_annotation = 139, /* member_function_annotation  */
  YYSYMBOL_member_function_declaration = 140, /* member_function_declaration  */
  YYSYMBOL_141_2 = 141,                    /* $@2  */
  YYSYMBOL_142_3 = 142,                    /* $@3  */
  YYSYMBOL_program_declaration = 143,      /* program_declaration  */
  YYSYMBOL_144_4 = 144,                    /* $@4  */
  YYSYMBOL_binary_operator = 145,          /* binary_operator  */
  YYSYMBOL_unary_operator = 146,           /* unary_operator  */
  YYSYMBOL_binary_operator_declaration = 147, /* binary_operator_declaration  */
  YYSYMBOL_148_5 = 148,                    /* $@5  */
  YYSYMBOL_unary_operator_declaration = 149, /* unary_operator_declaration  */
  YYSYMBOL_150_6 = 150,                    /* $@6  */
  YYSYMBOL_assignment_operator_declaration = 151, /* assignment_operator_declaration  */
  YYSYMBOL_152_7 = 152,                    /* $@7  */
  YYSYMBOL_conversion_operator_declaration = 153, /* conversion_operator_declaration  */
  YYSYMBOL_154_8 = 154,                    /* $@8  */
  YYSYMBOL_class_annotation = 155,         /* class_annotation  */
  YYSYMBOL_class_declaration = 156,        /* class_declaration  */
  YYSYMBOL_157_9 = 157,                    /* $@9  */
  YYSYMBOL_158_10 = 158,                   /* $@10  */
  YYSYMBOL_159_11 = 159,                   /* $@11  */
  YYSYMBOL_basic_declaration = 160,        /* basic_declaration  */
  YYSYMBOL_cpp = 161,                      /* cpp  */
  YYSYMBOL_hpp = 162,                      /* hpp  */
  YYSYMBOL_assume_operator = 163,          /* assume_operator  */
  YYSYMBOL_assume_statement = 164,         /* assume_statement  */
  YYSYMBOL_expression_statement = 165,     /* expression_statement  */
  YYSYMBOL_if = 166,                       /* if  */
  YYSYMBOL_for_variable_declaration = 167, /* for_variable_declaration  */
  YYSYMBOL_for = 168,                      /* for  */
  YYSYMBOL_parallel_annotation = 169,      /* parallel_annotation  */
  YYSYMBOL_parallel = 170,                 /* parallel  */
  YYSYMBOL_while = 171,                    /* while  */
  YYSYMBOL_do_while = 172,                 /* do_while  */
  YYSYMBOL_with = 173,                     /* with  */
  YYSYMBOL_block = 174,                    /* block  */
  YYSYMBOL_assertion = 175,                /* assertion  */
  YYSYMBOL_return = 176,                   /* return  */
  YYSYMBOL_factor = 177,                   /* factor  */
  YYSYMBOL_statement = 178,                /* statement  */
  YYSYMBOL_statements = 179,               /* statements  */
  YYSYMBOL_optional_statements = 180,      /* optional_statements  */
  YYSYMBOL_class_statement = 181,          /* class_statement  */
  YYSYMBOL_class_statements = 182,         /* class_statements  */
  YYSYMBOL_optional_class_statements = 183, /* optional_class_statements  */
  YYSYMBOL_file_statement = 184,           /* file_statement  */
  YYSYMBOL_file_statements = 185,          /* file_statements  */
  YYSYMBOL_optional_file_statements = 186, /* optional_file_statements  */
  YYSYMBOL_file = 187,                     /* file  */
  YYSYMBOL_return_type = 188,              /* return_type  */
  YYSYMBOL_optional_return_type = 189,     /* optional_return_type  */
  YYSYMBOL_value = 190,                    /* value  */
  YYSYMBOL_optional_value = 191,           /* optional_value  */
  YYSYMBOL_braces = 192,                   /* braces  */
  YYSYMBOL_optional_braces = 193,          /* optional_braces  */
  YYSYMBOL_class_braces = 194,             /* class_braces  */
  YYSYMBOL_optional_class_braces = 195,    /* optional_class_braces  */
  YYSYMBOL_double_braces = 196,            /* double_braces  */
  YYSYMBOL_named_type = 197,               /* named_type  */
  YYSYMBOL_primary_type = 198,             /* primary_type  */
  YYSYMBOL_type = 199,                     /* type  */
  YYSYMBOL_type_list = 200,                /* type_list  */
  YYSYMBOL_optional_type_list = 201        /* optional_type_list  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;


/* Default (constant) value used for initialization for null
   right-hand sides.  Unlike the standard yacc.c template, here we set
   the default value of $$ to a zeroed-out value.  Since the default
   value is undefined, this behavior is technically correct.  */
static YYSTYPE yyval_default;
static YYLTYPE yyloc_default
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
  = { 1, 1, 1, 1 }
# endif
;


/* Unqualified %code blocks.  */
#line 6 "src/parser.ypp"

  #include "src/expression/all.hpp"
  #include "src/statement/all.hpp"
  #include "src/type/all.hpp"

  /**
   * Raw string stack.
   */
  std::stack<std::string> raws;

  /**
   * Push the current raw string onto the stack, and restart it.
   */
  void push_raw() {
    raws.push(raw.str());
    raw.str("");
  }

  /**
   * Pop a raw string from the stack.
   */
  std::string pop_raw() {
    std::string raw = raws.top();
    raws.pop();
    return raw;
  }

  /**
   * Make a location, without documentation string.
   */
  birch::Location* make_loc(YYLTYPE& loc) {
    return new birch::Location(compiler->file, loc.first_line, loc.last_line,
        loc.first_column, loc.last_column);
  }

  /**
   * Make a location, with documentation string.
   */
  birch::Location* make_doc_loc(YYLTYPE& loc) {
    return new birch::Location(compiler->file, loc.first_line, loc.last_line,
        loc.first_column, loc.last_column, pop_raw());
  }

  /**
   * Make an empty expression.
   */
  birch::Expression* empty_expr(YYLTYPE& loc) {
    return new birch::EmptyExpression(make_loc(loc));
  }

  /**
   * Make an empty statement.
   */
  birch::Statement* empty_stmt(YYLTYPE& loc) {
    return new birch::EmptyStatement(make_loc(loc));
  }

  /**
   * Make an empty type.
   */
  birch::Type* empty_type(YYLTYPE& loc) {
    return new birch::EmptyType(make_loc(loc));
  }

#line 369 "src/parser.cpp"

#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif
#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YYFREE
# define YYFREE free
#endif
#ifndef YYMALLOC
# define YYMALLOC malloc
#endif
#ifndef YYREALLOC
# define YYREALLOC realloc
#endif

#ifdef __cplusplus
  typedef bool yybool;
# define yytrue true
# define yyfalse false
#else
  /* When we move to stdbool, get rid of the various casts to yybool.  */
  typedef signed char yybool;
# define yytrue 1
# define yyfalse 0
#endif

#ifndef YYSETJMP
# include <setjmp.h>
# define YYJMP_BUF jmp_buf
# define YYSETJMP(Env) setjmp (Env)
/* Pacify Clang and ICC.  */
# define YYLONGJMP(Env, Val)                    \
 do {                                           \
   longjmp (Env, Val);                          \
   YY_ASSERT (0);                               \
 } while (yyfalse)
#endif

#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* The _Noreturn keyword of C11.  */
#ifndef _Noreturn
# if (defined __cplusplus \
      && ((201103 <= __cplusplus && !(__GNUC__ == 4 && __GNUC_MINOR__ == 7)) \
          || (defined _MSC_VER && 1900 <= _MSC_VER)))
#  define _Noreturn [[noreturn]]
# elif (!defined __cplusplus                     \
        && (201112 <= (defined __STDC_VERSION__ ? __STDC_VERSION__ : 0)  \
            || 4 < __GNUC__ + (7 <= __GNUC_MINOR__) \
            || (defined __apple_build_version__ \
                ? 6000000 <= __apple_build_version__ \
                : 3 < __clang_major__ + (5 <= __clang_minor__))))
   /* _Noreturn works as-is.  */
# elif 2 < __GNUC__ + (8 <= __GNUC_MINOR__) || 0x5110 <= __SUNPRO_C
#  define _Noreturn __attribute__ ((__noreturn__))
# elif 1200 <= (defined _MSC_VER ? _MSC_VER : 0)
#  define _Noreturn __declspec (noreturn)
# else
#  define _Noreturn
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(E) ((void) (E))
#else
# define YYUSE(E) /* empty */
#endif

#if defined __GNUC__ && ! defined __ICC && 407 <= __GNUC__ * 100 + __GNUC_MINOR__
/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                            \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  35
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   543

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  73
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  129
/* YYNRULES -- Number of rules.  */
#define YYNRULES  259
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  441
/* YYMAXRHS -- Maximum number of symbols on right-hand side of rule.  */
#define YYMAXRHS 10
/* YYMAXLEFT -- Maximum number of symbols to the left of a handle
   accessed by $0, $-1, etc., in any rule.  */
#define YYMAXLEFT 0

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   304

/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    58,     2,     2,     2,     2,    72,     2,
      50,    51,    61,    59,    56,    60,    57,    62,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    65,    67,
      63,    68,    64,    54,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    52,    55,    53,     2,    66,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    70,     2,    71,    69,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49
};

#if YYDEBUG
/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   157,   157,   166,   170,   174,   178,   182,   183,   184,
     185,   189,   193,   197,   201,   205,   209,   213,   217,   221,
     222,   223,   224,   225,   226,   227,   228,   232,   233,   237,
     238,   242,   246,   247,   248,   249,   250,   251,   252,   258,
     259,   263,   264,   265,   269,   270,   274,   275,   279,   280,
     284,   285,   289,   290,   294,   295,   296,   297,   306,   307,
     311,   312,   316,   317,   321,   325,   326,   330,   334,   335,
     339,   343,   344,   348,   352,   353,   357,   358,   362,   366,
     367,   371,   375,   376,   380,   381,   385,   386,   390,   394,
     395,   399,   400,   404,   408,   409,   413,   414,   418,   419,
     423,   424,   428,   429,   433,   437,   438,   442,   443,   447,
     448,   452,   456,   457,   466,   467,   468,   469,   470,   474,
     475,   476,   477,   478,   482,   483,   484,   485,   486,   487,
     488,   492,   492,   496,   497,   498,   499,   505,   505,   506,
     506,   510,   510,   514,   515,   516,   517,   518,   519,   523,
     527,   527,   531,   531,   535,   535,   539,   539,   543,   544,
     545,   549,   549,   550,   550,   551,   551,   555,   556,   557,
     561,   565,   569,   570,   571,   572,   576,   580,   584,   585,
     586,   590,   594,   598,   604,   605,   609,   613,   617,   621,
     625,   629,   633,   637,   638,   639,   640,   641,   642,   643,
     644,   645,   646,   647,   648,   649,   650,   654,   655,   659,
     660,   664,   665,   666,   667,   668,   672,   673,   677,   678,
     682,   683,   684,   685,   686,   687,   688,   689,   690,   694,
     695,   699,   700,   704,   708,   712,   713,   717,   721,   722,
     726,   730,   731,   735,   739,   740,   744,   753,   754,   758,
     759,   763,   764,   765,   766,   767,   771,   772,   776,   777
};
#endif

#define YYPACT_NINF (-315)
#define YYTABLE_NINF (-233)

  /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
     STATE-NUM.  */
static const yytype_int16 yypact[] =
{
      83,     9,     9,     9,    12,    15,    15,  -315,  -315,  -315,
     -11,  -315,  -315,  -315,  -315,  -315,    77,  -315,  -315,  -315,
    -315,   202,  -315,  -315,    73,    35,    85,    75,     6,   111,
    -315,  -315,    24,     9,  -315,  -315,     2,  -315,     9,  -315,
       9,    -4,  -315,   115,  -315,  -315,  -315,   110,  -315,   479,
       9,  -315,    24,   130,   120,   134,  -315,    87,   121,  -315,
     135,   153,   155,    88,   160,   170,  -315,  -315,   161,   177,
       4,   204,    24,  -315,  -315,  -315,  -315,  -315,  -315,  -315,
    -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,
    -315,     9,   194,   158,   203,    24,    -6,  -315,   185,     9,
     461,   422,   127,  -315,  -315,   -16,   182,   195,    68,    24,
    -315,     9,  -315,   383,  -315,  -315,  -315,  -315,  -315,     9,
    -315,   210,   207,    24,  -315,  -315,   140,   213,   204,   200,
      24,  -315,  -315,   218,  -315,   206,   215,   140,  -315,  -315,
    -315,  -315,   220,  -315,  -315,  -315,  -315,  -315,   461,   461,
     115,   212,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,
    -315,  -315,  -315,   222,  -315,  -315,   201,  -315,   461,  -315,
     -31,    48,    69,   193,   237,    38,  -315,  -315,  -315,   225,
     231,   227,  -315,   230,   235,   238,  -315,   229,  -315,  -315,
       9,  -315,   234,   118,  -315,     9,     9,   461,     9,   461,
     232,   461,   461,   461,   461,   288,  -315,   136,    60,  -315,
    -315,  -315,  -315,  -315,  -315,   276,  -315,  -315,  -315,  -315,
    -315,  -315,  -315,  -315,   383,  -315,   233,  -315,  -315,  -315,
       9,   166,    88,   204,  -315,  -315,   204,  -315,    24,     9,
     254,   253,   204,   255,     9,   461,  -315,     9,  -315,  -315,
    -315,  -315,   461,   461,   461,   461,   461,  -315,   461,   461,
     461,  -315,   200,   461,  -315,  -315,  -315,  -315,     9,    99,
    -315,  -315,   270,   270,   232,  -315,   297,   232,   298,   232,
     246,  -315,   247,   250,     9,    24,  -315,  -315,  -315,  -315,
    -315,   461,   306,  -315,  -315,  -315,  -315,  -315,    88,  -315,
    -315,   259,  -315,  -315,  -315,    88,   273,  -315,   268,   274,
     277,  -315,  -315,   -31,    48,    69,   193,   237,  -315,  -315,
    -315,  -315,   261,   279,  -315,   266,  -315,  -315,   264,   267,
     322,   461,  -315,   461,  -315,  -315,  -315,  -315,   323,   165,
     272,     9,    88,  -315,  -315,  -315,   461,   461,  -315,   461,
    -315,  -315,  -315,     9,    96,  -315,  -315,   307,   275,  -315,
     331,  -315,  -315,  -315,  -315,   266,  -315,   271,  -315,  -315,
       5,   294,   280,   461,  -315,    11,   281,   282,  -315,   333,
    -315,   293,  -315,  -315,    99,    75,     9,  -315,  -315,    24,
       9,  -315,  -315,  -315,  -315,   461,  -315,   301,  -315,   284,
    -315,  -315,   461,  -315,  -315,   115,  -315,    88,   198,    75,
     232,   461,  -315,   303,   204,    88,  -315,  -315,    55,   290,
     291,   115,  -315,   232,   461,  -315,  -315,  -315,   292,  -315,
    -315,   204,  -315,   232,    88,  -315,  -315,  -315,  -315,    88,
    -315
};

  /* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
     Performed when YYTABLE does not specify something else to do.  Zero
     means the default is an error.  */
static const yytype_int16 yydefact[] =
{
     160,     0,     0,     0,     0,     0,     0,   159,   158,     2,
       0,   220,   221,   222,   223,   224,     0,   225,   226,   227,
     228,   160,   231,   233,     0,     0,     0,   106,     0,     0,
     170,   171,     0,     0,   230,     1,     0,   141,     0,   169,
       0,     0,   105,     0,    43,    41,    42,     0,   149,     0,
       0,   246,     0,     0,   113,   249,   251,     0,   106,    89,
       0,     0,    91,     0,     0,     0,   100,   104,     0,   102,
       0,   236,     0,    64,    67,    56,    57,    60,    61,    50,
      51,    46,    47,    54,    55,   143,   144,   145,   146,   147,
     148,     0,     0,   256,     0,   259,     0,   112,   247,     0,
       0,     0,     0,   252,   114,     0,     0,     0,    85,     0,
      90,     0,   242,   210,   241,   142,   167,   168,   101,     0,
      82,     0,    86,     0,   235,   131,    88,     0,   236,     0,
       0,   250,   258,     0,   107,     0,   109,   111,   248,   253,
      16,    17,     0,    18,     3,     4,     5,     6,     0,     0,
       0,   113,     7,     8,     9,    10,    19,    20,    21,    22,
      23,    24,    25,     0,    26,    32,    39,    44,     0,    48,
      52,    58,    62,    65,    68,    71,    73,   237,    94,    76,
       0,    98,    78,    79,     0,     0,   117,     0,   115,   116,
       0,    84,   163,   239,    92,     0,     0,     0,     0,     0,
       0,     0,     0,    75,    75,     0,   183,   113,     0,   193,
     206,   195,   194,   196,   197,     0,   198,   199,   200,   201,
     202,   203,   204,   205,   207,   209,     0,   189,   103,    83,
       0,   234,     0,   236,   152,   257,   236,   108,     0,     0,
       0,     0,   236,    11,     0,     0,    40,     0,    38,    36,
      37,    45,     0,     0,     0,     0,     0,    70,     0,     0,
       0,    95,     0,     0,    81,   254,   118,   165,     0,     0,
     238,    93,     0,     0,     0,   181,     0,     0,     0,     0,
       0,    74,     0,     0,     0,     0,   173,   174,   175,   177,
     172,     0,     0,   208,   240,    87,   132,   150,     0,   255,
     110,   113,    34,    12,    13,     0,     0,    33,    29,     0,
      28,    35,    49,    53,    59,    63,    66,    69,    72,    77,
      99,    80,     0,    97,   245,   219,   244,   164,     0,     0,
     180,     0,   186,     0,   188,   190,   191,   192,     0,     0,
       0,     0,     0,   153,    11,    15,     0,     0,    31,     0,
     166,    96,   161,     0,     0,   133,   135,   134,     0,   211,
       0,   212,   213,   214,   215,   216,   218,     0,   124,   125,
       0,     0,     0,     0,   126,     0,     0,     0,   176,     0,
     151,     0,    30,    27,     0,   106,     0,   156,   136,     0,
       0,   217,   243,   179,   178,     0,   187,     0,   129,     0,
     127,   128,     0,    14,   162,     0,   154,     0,     0,   106,
       0,     0,   130,     0,   236,     0,   157,   119,     0,     0,
       0,     0,   182,     0,     0,   139,   155,   122,     0,   120,
     121,   236,   185,     0,     0,   123,   137,   184,   140,     0,
     138
};

  /* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -315,     0,  -315,  -315,  -315,  -315,  -315,   -66,  -315,  -315,
    -315,  -315,  -315,  -315,  -315,  -315,  -315,     8,  -315,  -315,
    -315,   332,  -146,   312,   113,   314,   114,   320,   116,   321,
     117,   325,   119,   197,  -315,  -315,   122,   -57,   171,  -129,
    -315,   124,  -314,  -102,  -315,   146,   -24,  -315,   269,  -315,
     -97,  -315,   123,  -315,   260,  -315,   -53,  -315,   144,  -315,
     -45,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,
    -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,
    -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,   -96,  -302,
    -315,  -315,  -315,    13,  -273,  -315,  -315,  -315,  -315,  -315,
    -315,  -315,  -315,  -315,  -315,  -315,   154,  -315,  -315,    19,
    -315,  -315,   367,  -315,  -315,    40,  -116,  -180,  -315,  -103,
    -218,  -315,    20,   390,   -22,  -315,   -25,   -71,  -315
};

  /* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,   151,   152,   153,   154,   155,   156,   157,   158,   159,
     160,   161,   162,   163,   164,   165,   308,   309,   249,   166,
     167,   168,   169,   252,   170,   253,   171,   254,   172,   255,
     173,   256,   174,    90,   175,   259,   176,   179,   282,   180,
     183,   184,   105,    71,   192,   121,   122,    37,    61,    62,
     106,   352,   185,    42,    68,    69,    43,    97,   135,   136,
     243,    11,   359,   209,    12,   232,   360,   361,   439,   434,
      13,    63,    91,    50,    14,   342,    15,   298,   362,   415,
     363,   407,    16,    17,   384,   269,   322,    18,    19,    20,
     291,   211,   212,   213,   276,   214,   215,   216,   217,   218,
     219,   220,   221,   222,   223,   224,   225,   226,   365,   366,
     367,    21,    22,    23,    24,   124,   125,   107,   271,   114,
     115,   326,   327,    30,    55,    56,    93,    94,   133
};

  /* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
     positive, shift that token.  If negative, reduce the rule whose
     number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      10,    25,    26,    27,    49,   108,   191,    57,   187,    98,
     227,   338,   234,   270,   296,   197,    64,   210,    65,   240,
     241,    10,   251,   364,   132,   375,    92,     9,    47,     9,
      81,    82,    54,    58,   101,     9,    60,     9,    54,     9,
      54,    67,     9,   177,    52,   182,    29,   126,   242,    53,
      47,   186,    54,    59,    32,   120,   208,     9,   134,   235,
      66,   101,    28,   364,    44,    45,    46,   127,   379,   250,
      47,   137,    54,    35,    52,   113,   257,   139,   398,    53,
     343,    33,    74,  -232,   193,    36,     1,   345,     2,     3,
       4,    47,   328,   329,   418,    54,    54,   278,   231,    54,
     286,   287,   288,     5,     6,   101,   312,    79,    80,    54,
       7,    60,     8,   207,    75,    76,     9,   297,    70,    67,
     299,   227,   427,    54,   380,   100,   305,   289,   210,   290,
      54,   319,    83,    84,   386,   123,   190,   101,    41,   102,
     274,   103,   277,    51,   279,   280,   281,   281,    38,   140,
     141,   142,    39,    40,   104,   112,   100,   143,   113,   377,
       9,   144,   145,   146,   147,    70,   324,   208,   267,   325,
     129,   330,   103,   302,   332,    72,   334,   148,   307,   149,
      95,   311,   150,    96,    41,    44,    45,    46,   310,   416,
      54,    99,   129,   181,   103,   272,   273,   426,   275,    96,
     109,   285,  -229,   100,   110,     1,   182,     2,     3,     4,
     129,   111,   103,   137,   130,   101,   438,   102,   129,   103,
     103,   440,     5,     6,   207,   118,   351,   116,   420,     7,
      47,     8,   374,   119,   340,     9,   100,   117,    54,   301,
      77,    78,   376,   123,   301,   128,   323,   301,   101,   188,
     102,   101,   103,   245,   131,   246,   344,   138,   247,   248,
     339,   229,   189,   230,   233,   417,   181,   394,    54,   236,
     237,   238,   353,   354,   371,    96,   372,   239,   399,   244,
      73,   260,   261,   262,   275,    54,   263,     6,   264,   381,
     310,   265,   383,   355,   356,   357,   266,   268,   425,     9,
     284,   292,   113,   414,   294,   303,   304,   422,   100,   306,
     331,   419,   333,   335,   336,   436,   397,   337,   341,   431,
     432,   428,    96,   346,   347,   358,   349,   348,   350,   101,
     437,   368,   405,   370,   369,   388,   373,   390,   410,   378,
     389,   275,   392,   395,   403,   413,   402,   396,   400,   401,
     411,   412,   424,   385,   423,   382,   421,   429,   430,   435,
      48,    85,   406,    86,   408,   358,   313,   433,   314,    87,
      88,   315,   258,   316,    89,   283,   295,   317,   293,   228,
     194,   318,   300,   393,   391,   320,    47,   321,    34,    54,
     409,   195,   196,   197,   387,   198,    31,   199,   200,   201,
     202,   203,   204,     5,   404,   140,   141,   142,   205,   206,
       0,     0,     0,   143,     0,     0,     9,   144,   145,   146,
     147,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   148,     0,   149,     0,     0,   150,     0,
       0,    44,    45,    46,   140,   141,   142,     0,     0,     0,
       0,     0,   143,   113,     0,     9,   144,   145,   146,   147,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   148,   178,   149,     0,     0,   150,     0,     0,
      44,    45,    46,   140,   141,   142,     0,     0,     0,     0,
       0,   143,     0,     0,     9,   144,   145,   146,   147,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   148,     0,   149,     0,     0,   150,     0,     0,    44,
      45,    46,    73,    74,    75,    76,    77,    78,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    79,    80,
      81,    82,    83,    84
};

static const yytype_int16 yycheck[] =
{
       0,     1,     2,     3,    28,    58,   108,    32,   105,    54,
     113,   284,   128,   193,   232,    10,    38,   113,    40,   148,
     149,    21,   168,   325,    95,   339,    50,    33,    28,    33,
      61,    62,    32,    33,    50,    33,    36,    33,    38,    33,
      40,    41,    33,   100,    50,   102,    31,    72,   150,    55,
      50,    67,    52,    51,    65,    51,   113,    33,    64,   130,
      64,    50,    50,   365,    58,    59,    60,    91,   341,   166,
      70,    96,    72,     0,    50,    70,    38,    99,    67,    55,
     298,     4,    44,     0,   109,    50,     3,   305,     5,     6,
       7,    91,   272,   273,   408,    95,    96,   200,   123,    99,
      40,    41,    42,    20,    21,    50,   252,    59,    60,   109,
      27,   111,    29,   113,    45,    46,    33,   233,    50,   119,
     236,   224,    67,   123,   342,    38,   242,    67,   224,    69,
     130,   260,    63,    64,    38,    39,    68,    50,    63,    52,
     197,    54,   199,    32,   201,   202,   203,   204,    63,    22,
      23,    24,    67,    68,    67,    67,    38,    30,    70,   339,
      33,    34,    35,    36,    37,    50,    67,   224,   190,    70,
      52,   274,    54,   239,   277,    65,   279,    50,   244,    52,
      50,   247,    55,    63,    63,    58,    59,    60,   245,   407,
     190,    57,    52,    66,    54,   195,   196,   415,   198,    63,
      65,    65,     0,    38,    51,     3,   263,     5,     6,     7,
      52,    56,    54,   238,    56,    50,   434,    52,    52,    54,
      54,   439,    20,    21,   224,    64,   323,    67,   408,    27,
     230,    29,    67,    56,   291,    33,    38,    67,   238,   239,
      47,    48,   339,    39,   244,    51,   268,   247,    50,    67,
      52,    50,    54,    52,    51,    54,   301,    72,    57,    58,
     285,    51,    67,    56,    51,    67,    66,   370,   268,    51,
      64,    56,     6,     7,   331,    63,   333,    57,   375,    57,
      43,    56,    51,    56,   284,   285,    56,    21,    53,   346,
     347,    53,   349,    27,    28,    29,    67,    63,   414,    33,
      12,    25,    70,   405,    71,    51,    53,   410,    38,    54,
      13,   408,    14,    67,    67,   431,   373,    67,    12,   421,
     423,   418,    63,    50,    56,   325,    49,    53,    67,    50,
     433,    67,   385,    11,    67,    28,    13,     6,   395,    67,
      65,   341,    71,    49,    51,   402,    13,    67,    67,    67,
      49,    67,    49,   353,   411,   347,   409,    67,    67,    67,
      28,    49,   386,    49,   389,   365,   253,   424,   254,    49,
      49,   255,   175,   256,    49,   204,   230,   258,   224,   119,
     111,   259,   238,   370,   365,   262,   386,   263,    21,   389,
     390,     8,     9,    10,   354,    12,     6,    14,    15,    16,
      17,    18,    19,    20,   384,    22,    23,    24,    25,    26,
      -1,    -1,    -1,    30,    -1,    -1,    33,    34,    35,    36,
      37,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    50,    -1,    52,    -1,    -1,    55,    -1,
      -1,    58,    59,    60,    22,    23,    24,    -1,    -1,    -1,
      -1,    -1,    30,    70,    -1,    33,    34,    35,    36,    37,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    50,    51,    52,    -1,    -1,    55,    -1,    -1,
      58,    59,    60,    22,    23,    24,    -1,    -1,    -1,    -1,
      -1,    30,    -1,    -1,    33,    34,    35,    36,    37,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    50,    -1,    52,    -1,    -1,    55,    -1,    -1,    58,
      59,    60,    43,    44,    45,    46,    47,    48,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    59,    60,
      61,    62,    63,    64
};

  /* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
     symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     3,     5,     6,     7,    20,    21,    27,    29,    33,
      74,   134,   137,   143,   147,   149,   155,   156,   160,   161,
     162,   184,   185,   186,   187,    74,    74,    74,    50,    31,
     196,   196,    65,     4,   185,     0,    50,   120,    63,    67,
      68,    63,   126,   129,    58,    59,    60,    74,    94,   119,
     146,    32,    50,    55,    74,   197,   198,   199,    74,    51,
      74,   121,   122,   144,   197,   197,    64,    74,   127,   128,
      50,   116,    65,    43,    44,    45,    46,    47,    48,    59,
      60,    61,    62,    63,    64,    96,    98,   100,   102,   104,
     106,   145,   119,   199,   200,    50,    63,   130,   133,    57,
      38,    50,    52,    54,    67,   115,   123,   190,   129,    65,
      51,    56,    67,    70,   192,   193,    67,    67,    64,    56,
      51,   118,   119,    39,   188,   189,   199,   119,    51,    52,
      56,    51,   200,   201,    64,   131,   132,   199,    72,   197,
      22,    23,    24,    30,    34,    35,    36,    37,    50,    52,
      55,    74,    75,    76,    77,    78,    79,    80,    81,    82,
      83,    84,    85,    86,    87,    88,    92,    93,    94,    95,
      97,    99,   101,   103,   105,   107,   109,   110,    51,   110,
     112,    66,   110,   113,   114,   125,    67,   123,    67,    67,
      68,   116,   117,   199,   121,     8,     9,    10,    12,    14,
      15,    16,    17,    18,    19,    25,    26,    74,   110,   136,
     161,   164,   165,   166,   168,   169,   170,   171,   172,   173,
     174,   175,   176,   177,   178,   179,   180,   192,   127,    51,
      56,   199,   138,    51,   189,   200,    51,    64,    56,    57,
     112,   112,   116,   133,    57,    52,    54,    57,    58,    91,
     123,    95,    96,    98,   100,   102,   104,    38,   106,   108,
      56,    51,    56,    56,    53,    53,    67,   197,    63,   158,
     190,   191,    74,    74,   110,    74,   167,   110,   192,   110,
     110,   110,   111,   111,    12,    65,    40,    41,    42,    67,
      69,   163,    25,   179,    71,   118,   193,   189,   150,   189,
     131,    74,    80,    51,    53,   189,    54,    80,    89,    90,
     110,    80,    95,    97,    99,   101,   103,   105,   109,   112,
     125,   114,   159,   197,    67,    70,   194,   195,   190,   190,
     192,    13,   192,    14,   192,    67,    67,    67,   167,   199,
     110,    12,   148,   193,   133,   193,    50,    56,    53,    49,
      67,   123,   124,     6,     7,    27,    28,    29,    74,   135,
     139,   140,   151,   153,   162,   181,   182,   183,    67,    67,
      11,   110,   110,    13,    67,   115,   123,   190,    67,   167,
     193,   110,    90,   110,   157,    74,    38,   188,    28,    65,
       6,   182,    71,   166,   192,    49,    67,   110,    67,   123,
      67,    67,    13,    51,   195,   129,   119,   154,   199,    74,
     110,    49,    67,   110,   116,   152,   193,    67,   115,   123,
     190,   129,   192,   110,    49,   189,   193,    67,   123,    67,
      67,   116,   192,   110,   142,    67,   189,   192,   193,   141,
     193
};

  /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    73,    74,    75,    76,    77,    78,    79,    79,    79,
      79,    80,    81,    82,    83,    84,    85,    86,    87,    88,
      88,    88,    88,    88,    88,    88,    88,    89,    89,    90,
      90,    91,    92,    92,    92,    92,    92,    92,    92,    93,
      93,    94,    94,    94,    95,    95,    96,    96,    97,    97,
      98,    98,    99,    99,   100,   100,   100,   100,   101,   101,
     102,   102,   103,   103,   104,   105,   105,   106,   107,   107,
     108,   109,   109,   110,   111,   111,   112,   112,   113,   114,
     114,   115,   116,   116,   117,   117,   118,   118,   119,   120,
     120,   121,   121,   122,   123,   123,   124,   124,   125,   125,
     126,   126,   127,   127,   128,   129,   129,   130,   130,   131,
     131,   132,   133,   133,   134,   134,   134,   134,   134,   135,
     135,   135,   135,   135,   136,   136,   136,   136,   136,   136,
     136,   138,   137,   139,   139,   139,   139,   141,   140,   142,
     140,   144,   143,   145,   145,   145,   145,   145,   145,   146,
     148,   147,   150,   149,   152,   151,   154,   153,   155,   155,
     155,   157,   156,   158,   156,   159,   156,   160,   160,   160,
     161,   162,   163,   163,   163,   163,   164,   165,   166,   166,
     166,   167,   168,   169,   170,   170,   171,   172,   173,   174,
     175,   176,   177,   178,   178,   178,   178,   178,   178,   178,
     178,   178,   178,   178,   178,   178,   178,   179,   179,   180,
     180,   181,   181,   181,   181,   181,   182,   182,   183,   183,
     184,   184,   184,   184,   184,   184,   184,   184,   184,   185,
     185,   186,   186,   187,   188,   189,   189,   190,   191,   191,
     192,   193,   193,   194,   195,   195,   196,   197,   197,   198,
     198,   199,   199,   199,   199,   199,   200,   200,   201,   201
};

  /* YYR2[YYN] -- Number of symbols on the right hand side of rule YYN.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     2,     3,     3,     6,     4,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     3,     1,     1,
       3,     3,     1,     3,     3,     3,     2,     2,     2,     1,
       2,     1,     1,     1,     1,     2,     1,     1,     1,     3,
       1,     1,     1,     3,     1,     1,     1,     1,     1,     3,
       1,     1,     1,     3,     1,     1,     3,     1,     1,     3,
       1,     1,     3,     1,     1,     0,     1,     3,     1,     1,
       3,     3,     2,     3,     1,     0,     1,     3,     3,     2,
       3,     1,     3,     4,     2,     3,     1,     0,     1,     3,
       2,     3,     1,     3,     1,     1,     0,     2,     3,     1,
       3,     1,     1,     0,     4,     5,     5,     5,     6,     4,
       5,     5,     5,     6,     4,     4,     4,     5,     5,     5,
       6,     0,     7,     1,     1,     1,     2,     0,     8,     0,
       7,     0,     5,     1,     1,     1,     1,     1,     1,     1,
       0,     9,     0,     8,     0,     5,     0,     4,     1,     1,
       0,     0,    10,     0,     7,     0,     8,     5,     5,     3,
       2,     2,     1,     1,     1,     1,     4,     2,     5,     5,
       3,     1,     7,     1,     9,     8,     3,     5,     3,     1,
       3,     3,     3,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     2,     1,
       0,     1,     1,     1,     1,     1,     1,     2,     1,     0,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       2,     1,     0,     1,     2,     1,     0,     2,     1,     0,
       3,     1,     1,     3,     1,     1,     2,     2,     3,     1,
       3,     1,     2,     3,     4,     5,     1,     3,     1,     0
};


/* YYDPREC[RULE-NUM] -- Dynamic precedence of rule #RULE-NUM (0 if none).  */
static const yytype_int8 yydprec[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     3,     2,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0
};

/* YYMERGER[RULE-NUM] -- Index of merging function for rule #RULE-NUM.  */
static const yytype_int8 yymerger[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0
};

/* YYIMMEDIATE[RULE-NUM] -- True iff rule #RULE-NUM is not to be deferred, as
   in the case of predicates.  */
static const yybool yyimmediate[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0
};

/* YYCONFLP[YYPACT[STATE-NUM]] -- Pointer into YYCONFL of start of
   list of conflicting reductions corresponding to action entry for
   state STATE-NUM in yytable.  0 means no conflicts.  The list in
   yyconfl is terminated by a rule number of 0.  */
static const yytype_int8 yyconflp[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     1,     3,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     7,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     9,     0,
      11,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     5,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    13,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    15,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0
};

/* YYCONFL[I] -- lists of conflicting rule numbers, each terminated by
   0, pointed into by YYCONFLP.  */
static const short yyconfl[] =
{
       0,   113,     0,   106,     0,   113,     0,   113,     0,   234,
       0,   234,     0,    11,     0,   113,     0
};


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)                                \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;        \
          (Current).first_column = YYRHSLOC (Rhs, 1).first_column;      \
          (Current).last_line    = YYRHSLOC (Rhs, N).last_line;         \
          (Current).last_column  = YYRHSLOC (Rhs, N).last_column;       \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).first_line   = (Current).last_line   =              \
            YYRHSLOC (Rhs, 0).last_line;                                \
          (Current).first_column = (Current).last_column =              \
            YYRHSLOC (Rhs, 0).last_column;                              \
        }                                                               \
    while (0)
#endif

# define YYRHSLOC(Rhs, K) ((Rhs)[K].yystate.yyloc)


YYSTYPE yylval;
YYLTYPE yylloc;

int yynerrs;
int yychar;

enum { YYENOMEM = -2 };

typedef enum { yyok, yyaccept, yyabort, yyerr } YYRESULTTAG;

#define YYCHK(YYE)                              \
  do {                                          \
    YYRESULTTAG yychk_flag = YYE;               \
    if (yychk_flag != yyok)                     \
      return yychk_flag;                        \
  } while (0)

/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYMAXDEPTH * sizeof (GLRStackItem)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif

/* Minimum number of free items on the stack allowed after an
   allocation.  This is to allow allocation and initialization
   to be completed by functions that call yyexpandGLRStack before the
   stack is expanded, thus insuring that all necessary pointers get
   properly redirected to new data.  */
#define YYHEADROOM 2

#ifndef YYSTACKEXPANDABLE
#  define YYSTACKEXPANDABLE 1
#endif

#if YYSTACKEXPANDABLE
# define YY_RESERVE_GLRSTACK(Yystack)                   \
  do {                                                  \
    if (Yystack->yyspaceLeft < YYHEADROOM)              \
      yyexpandGLRStack (Yystack);                       \
  } while (0)
#else
# define YY_RESERVE_GLRSTACK(Yystack)                   \
  do {                                                  \
    if (Yystack->yyspaceLeft < YYHEADROOM)              \
      yyMemoryExhausted (Yystack);                      \
  } while (0)
#endif

/** State numbers. */
typedef int yy_state_t;

/** Rule numbers. */
typedef int yyRuleNum;

/** Item references. */
typedef short yyItemNum;

typedef struct yyGLRState yyGLRState;
typedef struct yyGLRStateSet yyGLRStateSet;
typedef struct yySemanticOption yySemanticOption;
typedef union yyGLRStackItem yyGLRStackItem;
typedef struct yyGLRStack yyGLRStack;

struct yyGLRState {
  /** Type tag: always true.  */
  yybool yyisState;
  /** Type tag for yysemantics.  If true, yysval applies, otherwise
   *  yyfirstVal applies.  */
  yybool yyresolved;
  /** Number of corresponding LALR(1) machine state.  */
  yy_state_t yylrState;
  /** Preceding state in this stack */
  yyGLRState* yypred;
  /** Source position of the last token produced by my symbol */
  YYPTRDIFF_T yyposn;
  union {
    /** First in a chain of alternative reductions producing the
     *  nonterminal corresponding to this state, threaded through
     *  yynext.  */
    yySemanticOption* yyfirstVal;
    /** Semantic value for this state.  */
    YYSTYPE yysval;
  } yysemantics;
  /** Source location for this state.  */
  YYLTYPE yyloc;
};

struct yyGLRStateSet {
  yyGLRState** yystates;
  /** During nondeterministic operation, yylookaheadNeeds tracks which
   *  stacks have actually needed the current lookahead.  During deterministic
   *  operation, yylookaheadNeeds[0] is not maintained since it would merely
   *  duplicate yychar != YYEMPTY.  */
  yybool* yylookaheadNeeds;
  YYPTRDIFF_T yysize;
  YYPTRDIFF_T yycapacity;
};

struct yySemanticOption {
  /** Type tag: always false.  */
  yybool yyisState;
  /** Rule number for this reduction */
  yyRuleNum yyrule;
  /** The last RHS state in the list of states to be reduced.  */
  yyGLRState* yystate;
  /** The lookahead for this reduction.  */
  int yyrawchar;
  YYSTYPE yyval;
  YYLTYPE yyloc;
  /** Next sibling in chain of options.  To facilitate merging,
   *  options are chained in decreasing order by address.  */
  yySemanticOption* yynext;
};

/** Type of the items in the GLR stack.  The yyisState field
 *  indicates which item of the union is valid.  */
union yyGLRStackItem {
  yyGLRState yystate;
  yySemanticOption yyoption;
};

struct yyGLRStack {
  int yyerrState;
  /* To compute the location of the error token.  */
  yyGLRStackItem yyerror_range[3];

  YYJMP_BUF yyexception_buffer;
  yyGLRStackItem* yyitems;
  yyGLRStackItem* yynextFree;
  YYPTRDIFF_T yyspaceLeft;
  yyGLRState* yysplitPoint;
  yyGLRState* yylastDeleted;
  yyGLRStateSet yytops;
};

#if YYSTACKEXPANDABLE
static void yyexpandGLRStack (yyGLRStack* yystackp);
#endif

_Noreturn static void
yyFail (yyGLRStack* yystackp, const char* yymsg)
{
  if (yymsg != YY_NULLPTR)
    yyerror (yymsg);
  YYLONGJMP (yystackp->yyexception_buffer, 1);
}

_Noreturn static void
yyMemoryExhausted (yyGLRStack* yystackp)
{
  YYLONGJMP (yystackp->yyexception_buffer, 2);
}

/** Accessing symbol of state YYSTATE.  */
static inline yysymbol_kind_t
yy_accessing_symbol (yy_state_t yystate)
{
  return YY_CAST (yysymbol_kind_t, yystos[yystate]);
}

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "PROGRAM", "CLASS",
  "TYPE", "FUNCTION", "OPERATOR", "AUTO", "LET", "IF", "ELSE", "FOR", "IN",
  "WHILE", "DO", "WITH", "ASSERT", "RETURN", "FACTOR", "CPP", "HPP",
  "THIS", "SUPER", "GLOBAL", "PARALLEL", "DYNAMIC", "ABSTRACT", "OVERRIDE",
  "FINAL", "NIL", "DOUBLE_BRACE_OPEN", "DOUBLE_BRACE_CLOSE", "NAME",
  "BOOL_LITERAL", "INT_LITERAL", "REAL_LITERAL", "STRING_LITERAL",
  "LEFT_OP", "RIGHT_OP", "LEFT_TILDE_OP", "RIGHT_TILDE_OP",
  "LEFT_QUERY_OP", "AND_OP", "OR_OP", "LE_OP", "GE_OP", "EQ_OP", "NE_OP",
  "RANGE_OP", "'('", "')'", "'['", "']'", "'?'", "'\\\\'", "','", "'.'",
  "'!'", "'+'", "'-'", "'*'", "'/'", "'<'", "'>'", "':'", "'_'", "';'",
  "'='", "'~'", "'{'", "'}'", "'&'", "$accept", "name", "bool_literal",
  "int_literal", "real_literal", "string_literal", "literal", "identifier",
  "parens_expression", "sequence_expression", "cast_expression",
  "function_expression", "this_expression", "super_expression",
  "nil_expression", "primary_expression", "index_expression", "index_list",
  "slice", "postfix_expression", "query_expression", "prefix_operator",
  "prefix_expression", "multiplicative_operator",
  "multiplicative_expression", "additive_operator", "additive_expression",
  "relational_operator", "relational_expression", "equality_operator",
  "equality_expression", "logical_and_operator", "logical_and_expression",
  "logical_or_operator", "logical_or_expression", "assign_operator",
  "assign_expression", "expression", "optional_expression",
  "expression_list", "span_expression", "span_list", "brackets",
  "parameters", "optional_parameters", "parameter_list", "parameter",
  "options", "option_list", "option", "arguments", "optional_arguments",
  "shape", "generics", "generic_list", "generic", "optional_generics",
  "generic_arguments", "generic_argument_list", "generic_argument",
  "optional_generic_arguments", "global_variable_declaration",
  "member_variable_declaration", "local_variable_declaration",
  "function_declaration", "$@1", "member_function_annotation",
  "member_function_declaration", "$@2", "$@3", "program_declaration",
  "$@4", "binary_operator", "unary_operator",
  "binary_operator_declaration", "$@5", "unary_operator_declaration",
  "$@6", "assignment_operator_declaration", "$@7",
  "conversion_operator_declaration", "$@8", "class_annotation",
  "class_declaration", "$@9", "$@10", "$@11", "basic_declaration", "cpp",
  "hpp", "assume_operator", "assume_statement", "expression_statement",
  "if", "for_variable_declaration", "for", "parallel_annotation",
  "parallel", "while", "do_while", "with", "block", "assertion", "return",
  "factor", "statement", "statements", "optional_statements",
  "class_statement", "class_statements", "optional_class_statements",
  "file_statement", "file_statements", "optional_file_statements", "file",
  "return_type", "optional_return_type", "value", "optional_value",
  "braces", "optional_braces", "class_braces", "optional_class_braces",
  "double_braces", "named_type", "primary_type", "type", "type_list",
  "optional_type_list", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#if YYDEBUG

# ifndef YYFPRINTF
#  define YYFPRINTF fprintf
# endif

# define YY_FPRINTF                             \
  YY_IGNORE_USELESS_CAST_BEGIN YY_FPRINTF_

# define YY_FPRINTF_(Args)                      \
  do {                                          \
    YYFPRINTF Args;                             \
    YY_IGNORE_USELESS_CAST_END                  \
  } while (0)

# define YY_DPRINTF                             \
  YY_IGNORE_USELESS_CAST_BEGIN YY_DPRINTF_

# define YY_DPRINTF_(Args)                      \
  do {                                          \
    if (yydebug)                                \
      YYFPRINTF Args;                           \
    YY_IGNORE_USELESS_CAST_END                  \
  } while (0)


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

# ifndef YY_LOCATION_PRINT
#  if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL

/* Print *YYLOCP on YYO.  Private, do not rely on its existence. */

YY_ATTRIBUTE_UNUSED
static int
yy_location_print_ (FILE *yyo, YYLTYPE const * const yylocp)
{
  int res = 0;
  int end_col = 0 != yylocp->last_column ? yylocp->last_column - 1 : 0;
  if (0 <= yylocp->first_line)
    {
      res += YYFPRINTF (yyo, "%d", yylocp->first_line);
      if (0 <= yylocp->first_column)
        res += YYFPRINTF (yyo, ".%d", yylocp->first_column);
    }
  if (0 <= yylocp->last_line)
    {
      if (yylocp->first_line < yylocp->last_line)
        {
          res += YYFPRINTF (yyo, "-%d", yylocp->last_line);
          if (0 <= end_col)
            res += YYFPRINTF (yyo, ".%d", end_col);
        }
      else if (0 <= end_col && yylocp->first_column < end_col)
        res += YYFPRINTF (yyo, "-%d", end_col);
    }
  return res;
 }

#   define YY_LOCATION_PRINT(File, Loc)          \
  yy_location_print_ (File, &(Loc))

#  else
#   define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#  endif
# endif /* !defined YY_LOCATION_PRINT */



/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp)
{
  FILE *yyoutput = yyo;
  YYUSE (yyoutput);
  YYUSE (yylocationp);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  YY_LOCATION_PRINT (yyo, *yylocationp);
  YYFPRINTF (yyo, ": ");
  yy_symbol_value_print (yyo, yykind, yyvaluep, yylocationp);
  YYFPRINTF (yyo, ")");
}

# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                  \
  do {                                                                  \
    if (yydebug)                                                        \
      {                                                                 \
        YY_FPRINTF ((stderr, "%s ", Title));                            \
        yy_symbol_print (stderr, Kind, Value, Location);        \
        YY_FPRINTF ((stderr, "\n"));                                    \
      }                                                                 \
  } while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;

static void yypstack (yyGLRStack* yystackp, YYPTRDIFF_T yyk)
  YY_ATTRIBUTE_UNUSED;
static void yypdumpstack (yyGLRStack* yystackp)
  YY_ATTRIBUTE_UNUSED;

#else /* !YYDEBUG */

# define YY_DPRINTF(Args) do {} while (yyfalse)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)

#endif /* !YYDEBUG */



/** Fill in YYVSP[YYLOW1 .. YYLOW0-1] from the chain of states starting
 *  at YYVSP[YYLOW0].yystate.yypred.  Leaves YYVSP[YYLOW1].yystate.yypred
 *  containing the pointer to the next state in the chain.  */
static void yyfillin (yyGLRStackItem *, int, int) YY_ATTRIBUTE_UNUSED;
static void
yyfillin (yyGLRStackItem *yyvsp, int yylow0, int yylow1)
{
  int i;
  yyGLRState *s = yyvsp[yylow0].yystate.yypred;
  for (i = yylow0-1; i >= yylow1; i -= 1)
    {
#if YYDEBUG
      yyvsp[i].yystate.yylrState = s->yylrState;
#endif
      yyvsp[i].yystate.yyresolved = s->yyresolved;
      if (s->yyresolved)
        yyvsp[i].yystate.yysemantics.yysval = s->yysemantics.yysval;
      else
        /* The effect of using yysval or yyloc (in an immediate rule) is
         * undefined.  */
        yyvsp[i].yystate.yysemantics.yyfirstVal = YY_NULLPTR;
      yyvsp[i].yystate.yyloc = s->yyloc;
      s = yyvsp[i].yystate.yypred = s->yypred;
    }
}


/** If yychar is empty, fetch the next token.  */
static inline yysymbol_kind_t
yygetToken (int *yycharp)
{
  yysymbol_kind_t yytoken;
  if (*yycharp == YYEMPTY)
    {
      YY_DPRINTF ((stderr, "Reading a token\n"));
      *yycharp = yylex ();
    }
  if (*yycharp <= YYEOF)
    {
      *yycharp = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YY_DPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (*yycharp);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }
  return yytoken;
}

/* Do nothing if YYNORMAL or if *YYLOW <= YYLOW1.  Otherwise, fill in
 * YYVSP[YYLOW1 .. *YYLOW-1] as in yyfillin and set *YYLOW = YYLOW1.
 * For convenience, always return YYLOW1.  */
static inline int yyfill (yyGLRStackItem *, int *, int, yybool)
     YY_ATTRIBUTE_UNUSED;
static inline int
yyfill (yyGLRStackItem *yyvsp, int *yylow, int yylow1, yybool yynormal)
{
  if (!yynormal && yylow1 < *yylow)
    {
      yyfillin (yyvsp, *yylow, yylow1);
      *yylow = yylow1;
    }
  return yylow1;
}

/** Perform user action for rule number YYN, with RHS length YYRHSLEN,
 *  and top stack item YYVSP.  YYLVALP points to place to put semantic
 *  value ($$), and yylocp points to place for location information
 *  (@$).  Returns yyok for normal return, yyaccept for YYACCEPT,
 *  yyerr for YYERROR, yyabort for YYABORT.  */
static YYRESULTTAG
yyuserAction (yyRuleNum yyn, int yyrhslen, yyGLRStackItem* yyvsp,
              yyGLRStack* yystackp,
              YYSTYPE* yyvalp, YYLTYPE *yylocp)
{
  yybool yynormal YY_ATTRIBUTE_UNUSED = yystackp->yysplitPoint == YY_NULLPTR;
  int yylow;
  YYUSE (yyvalp);
  YYUSE (yylocp);
  YYUSE (yyrhslen);
# undef yyerrok
# define yyerrok (yystackp->yyerrState = 0)
# undef YYACCEPT
# define YYACCEPT return yyaccept
# undef YYABORT
# define YYABORT return yyabort
# undef YYERROR
# define YYERROR return yyerrok, yyerr
# undef YYRECOVERING
# define YYRECOVERING() (yystackp->yyerrState != 0)
# undef yyclearin
# define yyclearin (yychar = YYEMPTY)
# undef YYFILL
# define YYFILL(N) yyfill (yyvsp, &yylow, (N), yynormal)
# undef YYBACKUP
# define YYBACKUP(Token, Value)                                              \
  return yyerror (YY_("syntax error: cannot back up")),     \
         yyerrok, yyerr

  yylow = 1;
  if (yyrhslen == 0)
    *yyvalp = yyval_default;
  else
    *yyvalp = yyvsp[YYFILL (1-yyrhslen)].yystate.yysemantics.yysval;
  /* Default location. */
  YYLLOC_DEFAULT ((*yylocp), (yyvsp - yyrhslen), yyrhslen);
  yystackp->yyerror_range[1].yystate.yyloc = *yylocp;

  switch (yyn)
    {
  case 2: /* name: NAME  */
#line 157 "src/parser.ypp"
            { ((*yyvalp).valName) = new birch::Name((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valString)); }
#line 1751 "src/parser.cpp"
    break;

  case 3: /* bool_literal: BOOL_LITERAL  */
#line 166 "src/parser.ypp"
                    { ((*yyvalp).valExpression) = new birch::Literal<bool>((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valString), make_loc((*yylocp))); }
#line 1757 "src/parser.cpp"
    break;

  case 4: /* int_literal: INT_LITERAL  */
#line 170 "src/parser.ypp"
                   { ((*yyvalp).valExpression) = new birch::Literal<int64_t>((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valString), make_loc((*yylocp))); }
#line 1763 "src/parser.cpp"
    break;

  case 5: /* real_literal: REAL_LITERAL  */
#line 174 "src/parser.ypp"
                    { ((*yyvalp).valExpression) = new birch::Literal<double>((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valString), make_loc((*yylocp))); }
#line 1769 "src/parser.cpp"
    break;

  case 6: /* string_literal: STRING_LITERAL  */
#line 178 "src/parser.ypp"
                      { ((*yyvalp).valExpression) = new birch::Literal<const char*>((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valString), make_loc((*yylocp))); }
#line 1775 "src/parser.cpp"
    break;

  case 11: /* identifier: name optional_generic_arguments  */
#line 189 "src/parser.ypp"
                                       { ((*yyvalp).valExpression) = new birch::NamedExpression((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valType), make_loc((*yylocp))); }
#line 1781 "src/parser.cpp"
    break;

  case 12: /* parens_expression: '(' expression_list ')'  */
#line 193 "src/parser.ypp"
                               { ((*yyvalp).valExpression) = new birch::Parentheses((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1787 "src/parser.cpp"
    break;

  case 13: /* sequence_expression: '[' expression_list ']'  */
#line 197 "src/parser.ypp"
                               { ((*yyvalp).valExpression) = new birch::Sequence((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1793 "src/parser.cpp"
    break;

  case 14: /* cast_expression: name optional_generic_arguments '?' '(' expression ')'  */
#line 201 "src/parser.ypp"
                                                              { ((*yyvalp).valExpression) = new birch::Cast(new birch::NamedType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valType), make_loc((*yylocp))), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1799 "src/parser.cpp"
    break;

  case 15: /* function_expression: '\\' parameters optional_return_type optional_braces  */
#line 205 "src/parser.ypp"
                                                            { ((*yyvalp).valExpression) = new birch::LambdaFunction((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 1805 "src/parser.cpp"
    break;

  case 16: /* this_expression: THIS  */
#line 209 "src/parser.ypp"
            { ((*yyvalp).valExpression) = new birch::This(make_loc((*yylocp))); }
#line 1811 "src/parser.cpp"
    break;

  case 17: /* super_expression: SUPER  */
#line 213 "src/parser.ypp"
             { ((*yyvalp).valExpression) = new birch::Super(make_loc((*yylocp))); }
#line 1817 "src/parser.cpp"
    break;

  case 18: /* nil_expression: NIL  */
#line 217 "src/parser.ypp"
           { ((*yyvalp).valExpression) = new birch::Nil(make_loc((*yylocp))); }
#line 1823 "src/parser.cpp"
    break;

  case 27: /* index_expression: expression RANGE_OP expression  */
#line 232 "src/parser.ypp"
                                      { ((*yyvalp).valExpression) = new birch::Range((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1829 "src/parser.cpp"
    break;

  case 28: /* index_expression: expression  */
#line 233 "src/parser.ypp"
                                      { ((*yyvalp).valExpression) = new birch::Index((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1835 "src/parser.cpp"
    break;

  case 30: /* index_list: index_expression ',' index_list  */
#line 238 "src/parser.ypp"
                                       { ((*yyvalp).valExpression) = new birch::ExpressionList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1841 "src/parser.cpp"
    break;

  case 31: /* slice: '[' index_list ']'  */
#line 242 "src/parser.ypp"
                          { ((*yyvalp).valExpression) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression); }
#line 1847 "src/parser.cpp"
    break;

  case 33: /* postfix_expression: super_expression '.' identifier  */
#line 247 "src/parser.ypp"
                                         { ((*yyvalp).valExpression) = new birch::Member((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1853 "src/parser.cpp"
    break;

  case 34: /* postfix_expression: GLOBAL '.' identifier  */
#line 248 "src/parser.ypp"
                                         { ((*yyvalp).valExpression) = new birch::Global((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1859 "src/parser.cpp"
    break;

  case 35: /* postfix_expression: postfix_expression '.' identifier  */
#line 249 "src/parser.ypp"
                                         { ((*yyvalp).valExpression) = new birch::Member((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1865 "src/parser.cpp"
    break;

  case 36: /* postfix_expression: postfix_expression slice  */
#line 250 "src/parser.ypp"
                                         { ((*yyvalp).valExpression) = new birch::Slice((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1871 "src/parser.cpp"
    break;

  case 37: /* postfix_expression: postfix_expression arguments  */
#line 251 "src/parser.ypp"
                                         { ((*yyvalp).valExpression) = new birch::Call((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1877 "src/parser.cpp"
    break;

  case 38: /* postfix_expression: postfix_expression '!'  */
#line 252 "src/parser.ypp"
                                         { ((*yyvalp).valExpression) = new birch::Get((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1883 "src/parser.cpp"
    break;

  case 40: /* query_expression: postfix_expression '?'  */
#line 259 "src/parser.ypp"
                              { ((*yyvalp).valExpression) = new birch::Query((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1889 "src/parser.cpp"
    break;

  case 41: /* prefix_operator: '+'  */
#line 263 "src/parser.ypp"
           { ((*yyvalp).valName) = new birch::Name("+"); }
#line 1895 "src/parser.cpp"
    break;

  case 42: /* prefix_operator: '-'  */
#line 264 "src/parser.ypp"
           { ((*yyvalp).valName) = new birch::Name("-"); }
#line 1901 "src/parser.cpp"
    break;

  case 43: /* prefix_operator: '!'  */
#line 265 "src/parser.ypp"
           { ((*yyvalp).valName) = new birch::Name("!"); }
#line 1907 "src/parser.cpp"
    break;

  case 45: /* prefix_expression: prefix_operator prefix_expression  */
#line 270 "src/parser.ypp"
                                         { ((*yyvalp).valExpression) = new birch::UnaryCall((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1913 "src/parser.cpp"
    break;

  case 46: /* multiplicative_operator: '*'  */
#line 274 "src/parser.ypp"
           { ((*yyvalp).valName) = new birch::Name("*"); }
#line 1919 "src/parser.cpp"
    break;

  case 47: /* multiplicative_operator: '/'  */
#line 275 "src/parser.ypp"
           { ((*yyvalp).valName) = new birch::Name("/"); }
#line 1925 "src/parser.cpp"
    break;

  case 49: /* multiplicative_expression: multiplicative_expression multiplicative_operator prefix_expression  */
#line 280 "src/parser.ypp"
                                                                           { ((*yyvalp).valExpression) = new birch::BinaryCall((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1931 "src/parser.cpp"
    break;

  case 50: /* additive_operator: '+'  */
#line 284 "src/parser.ypp"
           { ((*yyvalp).valName) = new birch::Name("+"); }
#line 1937 "src/parser.cpp"
    break;

  case 51: /* additive_operator: '-'  */
#line 285 "src/parser.ypp"
           { ((*yyvalp).valName) = new birch::Name("-"); }
#line 1943 "src/parser.cpp"
    break;

  case 53: /* additive_expression: additive_expression additive_operator multiplicative_expression  */
#line 290 "src/parser.ypp"
                                                                       { ((*yyvalp).valExpression) = new birch::BinaryCall((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1949 "src/parser.cpp"
    break;

  case 54: /* relational_operator: '<'  */
#line 294 "src/parser.ypp"
             { ((*yyvalp).valName) = new birch::Name("<"); }
#line 1955 "src/parser.cpp"
    break;

  case 55: /* relational_operator: '>'  */
#line 295 "src/parser.ypp"
             { ((*yyvalp).valName) = new birch::Name(">"); }
#line 1961 "src/parser.cpp"
    break;

  case 56: /* relational_operator: LE_OP  */
#line 296 "src/parser.ypp"
             { ((*yyvalp).valName) = new birch::Name("<="); }
#line 1967 "src/parser.cpp"
    break;

  case 57: /* relational_operator: GE_OP  */
#line 297 "src/parser.ypp"
             { ((*yyvalp).valName) = new birch::Name(">="); }
#line 1973 "src/parser.cpp"
    break;

  case 59: /* relational_expression: relational_expression relational_operator additive_expression  */
#line 307 "src/parser.ypp"
                                                                               { ((*yyvalp).valExpression) = new birch::BinaryCall((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1979 "src/parser.cpp"
    break;

  case 60: /* equality_operator: EQ_OP  */
#line 311 "src/parser.ypp"
             { ((*yyvalp).valName) = new birch::Name("=="); }
#line 1985 "src/parser.cpp"
    break;

  case 61: /* equality_operator: NE_OP  */
#line 312 "src/parser.ypp"
             { ((*yyvalp).valName) = new birch::Name("!="); }
#line 1991 "src/parser.cpp"
    break;

  case 63: /* equality_expression: equality_expression equality_operator relational_expression  */
#line 317 "src/parser.ypp"
                                                                   { ((*yyvalp).valExpression) = new birch::BinaryCall((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1997 "src/parser.cpp"
    break;

  case 64: /* logical_and_operator: AND_OP  */
#line 321 "src/parser.ypp"
              { ((*yyvalp).valName) = new birch::Name("&&"); }
#line 2003 "src/parser.cpp"
    break;

  case 66: /* logical_and_expression: logical_and_expression logical_and_operator equality_expression  */
#line 326 "src/parser.ypp"
                                                                       { ((*yyvalp).valExpression) = new birch::BinaryCall((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2009 "src/parser.cpp"
    break;

  case 67: /* logical_or_operator: OR_OP  */
#line 330 "src/parser.ypp"
             { ((*yyvalp).valName) = new birch::Name("||"); }
#line 2015 "src/parser.cpp"
    break;

  case 69: /* logical_or_expression: logical_or_expression logical_or_operator logical_and_expression  */
#line 335 "src/parser.ypp"
                                                                        { ((*yyvalp).valExpression) = new birch::BinaryCall((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2021 "src/parser.cpp"
    break;

  case 70: /* assign_operator: LEFT_OP  */
#line 339 "src/parser.ypp"
                 { ((*yyvalp).valName) = new birch::Name("<-"); }
#line 2027 "src/parser.cpp"
    break;

  case 72: /* assign_expression: logical_or_expression assign_operator assign_expression  */
#line 344 "src/parser.ypp"
                                                               { ((*yyvalp).valExpression) = new birch::Assign((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2033 "src/parser.cpp"
    break;

  case 75: /* optional_expression: %empty  */
#line 353 "src/parser.ypp"
                  { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2039 "src/parser.cpp"
    break;

  case 77: /* expression_list: expression ',' expression_list  */
#line 358 "src/parser.ypp"
                                      { ((*yyvalp).valExpression) = new birch::ExpressionList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2045 "src/parser.cpp"
    break;

  case 78: /* span_expression: expression  */
#line 362 "src/parser.ypp"
                   { ((*yyvalp).valExpression) = new birch::Span((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2051 "src/parser.cpp"
    break;

  case 80: /* span_list: span_expression ',' span_list  */
#line 367 "src/parser.ypp"
                                     { ((*yyvalp).valExpression) = new birch::ExpressionList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2057 "src/parser.cpp"
    break;

  case 81: /* brackets: '[' span_list ']'  */
#line 371 "src/parser.ypp"
                         { ((*yyvalp).valExpression) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression); }
#line 2063 "src/parser.cpp"
    break;

  case 82: /* parameters: '(' ')'  */
#line 375 "src/parser.ypp"
                              { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2069 "src/parser.cpp"
    break;

  case 83: /* parameters: '(' parameter_list ')'  */
#line 376 "src/parser.ypp"
                              { ((*yyvalp).valExpression) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression); }
#line 2075 "src/parser.cpp"
    break;

  case 85: /* optional_parameters: %empty  */
#line 381 "src/parser.ypp"
                  { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2081 "src/parser.cpp"
    break;

  case 87: /* parameter_list: parameter ',' parameter_list  */
#line 386 "src/parser.ypp"
                                    { ((*yyvalp).valExpression) = new birch::ExpressionList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2087 "src/parser.cpp"
    break;

  case 88: /* parameter: name ':' type  */
#line 390 "src/parser.ypp"
                     { ((*yyvalp).valExpression) = new birch::Parameter(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valType), empty_expr((*yylocp)), make_loc((*yylocp))); }
#line 2093 "src/parser.cpp"
    break;

  case 89: /* options: '(' ')'  */
#line 394 "src/parser.ypp"
                           { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2099 "src/parser.cpp"
    break;

  case 90: /* options: '(' option_list ')'  */
#line 395 "src/parser.ypp"
                           { ((*yyvalp).valExpression) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression); }
#line 2105 "src/parser.cpp"
    break;

  case 92: /* option_list: option ',' option_list  */
#line 400 "src/parser.ypp"
                              { ((*yyvalp).valExpression) = new birch::ExpressionList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2111 "src/parser.cpp"
    break;

  case 93: /* option: name ':' type optional_value  */
#line 404 "src/parser.ypp"
                                    { ((*yyvalp).valExpression) = new birch::Parameter(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2117 "src/parser.cpp"
    break;

  case 94: /* arguments: '(' ')'  */
#line 408 "src/parser.ypp"
                               { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2123 "src/parser.cpp"
    break;

  case 95: /* arguments: '(' expression_list ')'  */
#line 409 "src/parser.ypp"
                               { ((*yyvalp).valExpression) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression); }
#line 2129 "src/parser.cpp"
    break;

  case 97: /* optional_arguments: %empty  */
#line 414 "src/parser.ypp"
                 { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2135 "src/parser.cpp"
    break;

  case 98: /* shape: '_'  */
#line 418 "src/parser.ypp"
                     { ((*yyvalp).valInt) = 1; }
#line 2141 "src/parser.cpp"
    break;

  case 99: /* shape: '_' ',' shape  */
#line 419 "src/parser.ypp"
                     { ((*yyvalp).valInt) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valInt) + 1; }
#line 2147 "src/parser.cpp"
    break;

  case 100: /* generics: '<' '>'  */
#line 423 "src/parser.ypp"
                            { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2153 "src/parser.cpp"
    break;

  case 101: /* generics: '<' generic_list '>'  */
#line 424 "src/parser.ypp"
                            { ((*yyvalp).valExpression) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression); }
#line 2159 "src/parser.cpp"
    break;

  case 103: /* generic_list: generic ',' generic_list  */
#line 429 "src/parser.ypp"
                                { ((*yyvalp).valExpression) = new birch::ExpressionList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2165 "src/parser.cpp"
    break;

  case 104: /* generic: name  */
#line 433 "src/parser.ypp"
            { ((*yyvalp).valExpression) = new birch::Generic(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valName), empty_type((*yylocp)), make_loc((*yylocp))); }
#line 2171 "src/parser.cpp"
    break;

  case 106: /* optional_generics: %empty  */
#line 438 "src/parser.ypp"
                { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2177 "src/parser.cpp"
    break;

  case 107: /* generic_arguments: '<' '>'  */
#line 442 "src/parser.ypp"
                                     { ((*yyvalp).valType) = empty_type((*yylocp)); }
#line 2183 "src/parser.cpp"
    break;

  case 108: /* generic_arguments: '<' generic_argument_list '>'  */
#line 443 "src/parser.ypp"
                                     { ((*yyvalp).valType) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valType); }
#line 2189 "src/parser.cpp"
    break;

  case 110: /* generic_argument_list: generic_argument ',' generic_argument_list  */
#line 448 "src/parser.ypp"
                                                  { ((*yyvalp).valType) = new birch::TypeList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valType), make_loc((*yylocp))); }
#line 2195 "src/parser.cpp"
    break;

  case 113: /* optional_generic_arguments: %empty  */
#line 457 "src/parser.ypp"
                         { ((*yyvalp).valType) = empty_type((*yylocp)); }
#line 2201 "src/parser.cpp"
    break;

  case 114: /* global_variable_declaration: name ':' type ';'  */
#line 466 "src/parser.ypp"
                                            { push_raw(); ((*yyvalp).valStatement) = new birch::GlobalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valType), empty_expr((*yylocp)), empty_expr((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2207 "src/parser.cpp"
    break;

  case 115: /* global_variable_declaration: name ':' type arguments ';'  */
#line 467 "src/parser.ypp"
                                            { push_raw(); ((*yyvalp).valStatement) = new birch::GlobalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2213 "src/parser.cpp"
    break;

  case 116: /* global_variable_declaration: name ':' type value ';'  */
#line 468 "src/parser.ypp"
                                            { push_raw(); ((*yyvalp).valStatement) = new birch::GlobalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), empty_expr((*yylocp)), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_doc_loc((*yylocp))); }
#line 2219 "src/parser.cpp"
    break;

  case 117: /* global_variable_declaration: name ':' type brackets ';'  */
#line 469 "src/parser.ypp"
                                            { push_raw(); ((*yyvalp).valStatement) = new birch::GlobalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valName), new birch::ArrayType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression)->width(), make_loc((*yylocp))), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), empty_expr((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2225 "src/parser.cpp"
    break;

  case 118: /* global_variable_declaration: name ':' type brackets arguments ';'  */
#line 470 "src/parser.ypp"
                                            { push_raw(); ((*yyvalp).valStatement) = new birch::GlobalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valName), new birch::ArrayType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression)->width(), make_loc((*yylocp))), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2231 "src/parser.cpp"
    break;

  case 119: /* member_variable_declaration: name ':' type ';'  */
#line 474 "src/parser.ypp"
                                            { push_raw(); ((*yyvalp).valStatement) = new birch::MemberVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valType), empty_expr((*yylocp)), empty_expr((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2237 "src/parser.cpp"
    break;

  case 120: /* member_variable_declaration: name ':' type arguments ';'  */
#line 475 "src/parser.ypp"
                                            { push_raw(); ((*yyvalp).valStatement) = new birch::MemberVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2243 "src/parser.cpp"
    break;

  case 121: /* member_variable_declaration: name ':' type value ';'  */
#line 476 "src/parser.ypp"
                                            { push_raw(); ((*yyvalp).valStatement) = new birch::MemberVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), empty_expr((*yylocp)), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_doc_loc((*yylocp))); }
#line 2249 "src/parser.cpp"
    break;

  case 122: /* member_variable_declaration: name ':' type brackets ';'  */
#line 477 "src/parser.ypp"
                                            { push_raw(); ((*yyvalp).valStatement) = new birch::MemberVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valName), new birch::ArrayType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression)->width(), make_loc((*yylocp))), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), empty_expr((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2255 "src/parser.cpp"
    break;

  case 123: /* member_variable_declaration: name ':' type brackets arguments ';'  */
#line 478 "src/parser.ypp"
                                            { push_raw(); ((*yyvalp).valStatement) = new birch::MemberVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valName), new birch::ArrayType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression)->width(), make_loc((*yylocp))), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2261 "src/parser.cpp"
    break;

  case 124: /* local_variable_declaration: AUTO name value ';'  */
#line 482 "src/parser.ypp"
                                            { yywarn("the auto keyword is deprecated, use let instead"); push_raw(); ((*yyvalp).valStatement) = new birch::LocalVariable(birch::LET, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valName), empty_type((*yylocp)), empty_expr((*yylocp)), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_doc_loc((*yylocp))); }
#line 2267 "src/parser.cpp"
    break;

  case 125: /* local_variable_declaration: LET name value ';'  */
#line 483 "src/parser.ypp"
                                            { push_raw(); ((*yyvalp).valStatement) = new birch::LocalVariable(birch::LET, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valName), empty_type((*yylocp)), empty_expr((*yylocp)), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_doc_loc((*yylocp))); }
#line 2273 "src/parser.cpp"
    break;

  case 126: /* local_variable_declaration: name ':' type ';'  */
#line 484 "src/parser.ypp"
                                            { push_raw(); ((*yyvalp).valStatement) = new birch::LocalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valType), empty_expr((*yylocp)), empty_expr((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2279 "src/parser.cpp"
    break;

  case 127: /* local_variable_declaration: name ':' type arguments ';'  */
#line 485 "src/parser.ypp"
                                            { push_raw(); ((*yyvalp).valStatement) = new birch::LocalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2285 "src/parser.cpp"
    break;

  case 128: /* local_variable_declaration: name ':' type value ';'  */
#line 486 "src/parser.ypp"
                                            { push_raw(); ((*yyvalp).valStatement) = new birch::LocalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), empty_expr((*yylocp)), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_doc_loc((*yylocp))); }
#line 2291 "src/parser.cpp"
    break;

  case 129: /* local_variable_declaration: name ':' type brackets ';'  */
#line 487 "src/parser.ypp"
                                            { push_raw(); ((*yyvalp).valStatement) = new birch::LocalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valName), new birch::ArrayType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression)->width(), make_loc((*yylocp))), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), empty_expr((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2297 "src/parser.cpp"
    break;

  case 130: /* local_variable_declaration: name ':' type brackets arguments ';'  */
#line 488 "src/parser.ypp"
                                            { push_raw(); ((*yyvalp).valStatement) = new birch::LocalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valName), new birch::ArrayType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression)->width(), make_loc((*yylocp))), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2303 "src/parser.cpp"
    break;

  case 131: /* $@1: %empty  */
#line 492 "src/parser.ypp"
                                                                      { push_raw(); }
#line 2309 "src/parser.cpp"
    break;

  case 132: /* function_declaration: FUNCTION name optional_generics parameters optional_return_type $@1 optional_braces  */
#line 492 "src/parser.ypp"
                                                                                                       { ((*yyvalp).valStatement) = new birch::Function(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_doc_loc((*yylocp))); }
#line 2315 "src/parser.cpp"
    break;

  case 133: /* member_function_annotation: ABSTRACT  */
#line 496 "src/parser.ypp"
                      { ((*yyvalp).valAnnotation) = birch::ABSTRACT; }
#line 2321 "src/parser.cpp"
    break;

  case 134: /* member_function_annotation: FINAL  */
#line 497 "src/parser.ypp"
                      { ((*yyvalp).valAnnotation) = birch::FINAL; }
#line 2327 "src/parser.cpp"
    break;

  case 135: /* member_function_annotation: OVERRIDE  */
#line 498 "src/parser.ypp"
                      { ((*yyvalp).valAnnotation) = birch::OVERRIDE; }
#line 2333 "src/parser.cpp"
    break;

  case 136: /* member_function_annotation: FINAL OVERRIDE  */
#line 499 "src/parser.ypp"
                      { ((*yyvalp).valAnnotation) = birch::Annotation(birch::FINAL|birch::OVERRIDE); }
#line 2339 "src/parser.cpp"
    break;

  case 137: /* $@2: %empty  */
#line 505 "src/parser.ypp"
                                                                                                 { push_raw(); }
#line 2345 "src/parser.cpp"
    break;

  case 138: /* member_function_declaration: member_function_annotation FUNCTION name optional_generics parameters optional_return_type $@2 optional_braces  */
#line 505 "src/parser.ypp"
                                                                                                                                  { ((*yyvalp).valStatement) = new birch::MemberFunction((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-7)].yystate.yysemantics.yysval.valAnnotation), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_doc_loc((*yylocp))); }
#line 2351 "src/parser.cpp"
    break;

  case 139: /* $@3: %empty  */
#line 506 "src/parser.ypp"
                                                                      { push_raw(); }
#line 2357 "src/parser.cpp"
    break;

  case 140: /* member_function_declaration: FUNCTION name optional_generics parameters optional_return_type $@3 optional_braces  */
#line 506 "src/parser.ypp"
                                                                                                                                  { ((*yyvalp).valStatement) = new birch::MemberFunction(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_doc_loc((*yylocp))); }
#line 2363 "src/parser.cpp"
    break;

  case 141: /* $@4: %empty  */
#line 510 "src/parser.ypp"
                           { push_raw(); }
#line 2369 "src/parser.cpp"
    break;

  case 142: /* program_declaration: PROGRAM name options $@4 optional_braces  */
#line 510 "src/parser.ypp"
                                                            { ((*yyvalp).valStatement) = new birch::Program((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_doc_loc((*yylocp))); }
#line 2375 "src/parser.cpp"
    break;

  case 150: /* $@5: %empty  */
#line 527 "src/parser.ypp"
                                                                                { push_raw(); }
#line 2381 "src/parser.cpp"
    break;

  case 151: /* binary_operator_declaration: OPERATOR '(' parameter binary_operator parameter ')' optional_return_type $@5 optional_braces  */
#line 527 "src/parser.ypp"
                                                                                                                 { ((*yyvalp).valStatement) = new birch::BinaryOperator(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-6)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_doc_loc((*yylocp))); }
#line 2387 "src/parser.cpp"
    break;

  case 152: /* $@6: %empty  */
#line 531 "src/parser.ypp"
                                                                     { push_raw(); }
#line 2393 "src/parser.cpp"
    break;

  case 153: /* unary_operator_declaration: OPERATOR '(' unary_operator parameter ')' optional_return_type $@6 optional_braces  */
#line 531 "src/parser.ypp"
                                                                                                      { ((*yyvalp).valStatement) = new birch::UnaryOperator(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_doc_loc((*yylocp))); }
#line 2399 "src/parser.cpp"
    break;

  case 154: /* $@7: %empty  */
#line 535 "src/parser.ypp"
                                 { push_raw(); }
#line 2405 "src/parser.cpp"
    break;

  case 155: /* assignment_operator_declaration: OPERATOR LEFT_OP parameter $@7 optional_braces  */
#line 535 "src/parser.ypp"
                                                                  { ((*yyvalp).valStatement) = new birch::AssignmentOperator((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_doc_loc((*yylocp))); }
#line 2411 "src/parser.cpp"
    break;

  case 156: /* $@8: %empty  */
#line 539 "src/parser.ypp"
                           { push_raw(); }
#line 2417 "src/parser.cpp"
    break;

  case 157: /* conversion_operator_declaration: OPERATOR return_type $@8 optional_braces  */
#line 539 "src/parser.ypp"
                                                            { ((*yyvalp).valStatement) = new birch::ConversionOperator((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_doc_loc((*yylocp))); }
#line 2423 "src/parser.cpp"
    break;

  case 158: /* class_annotation: FINAL  */
#line 543 "src/parser.ypp"
                { ((*yyvalp).valAnnotation) = birch::FINAL; }
#line 2429 "src/parser.cpp"
    break;

  case 159: /* class_annotation: ABSTRACT  */
#line 544 "src/parser.ypp"
                { ((*yyvalp).valAnnotation) = birch::ABSTRACT; }
#line 2435 "src/parser.cpp"
    break;

  case 160: /* class_annotation: %empty  */
#line 545 "src/parser.ypp"
                { ((*yyvalp).valAnnotation) = birch::NONE; }
#line 2441 "src/parser.cpp"
    break;

  case 161: /* $@9: %empty  */
#line 549 "src/parser.ypp"
                                                                                                          { push_raw(); }
#line 2447 "src/parser.cpp"
    break;

  case 162: /* class_declaration: class_annotation CLASS name optional_generics optional_parameters '<' named_type optional_arguments $@9 optional_class_braces  */
#line 549 "src/parser.ypp"
                                                                                                                                                 { ((*yyvalp).valStatement) = new birch::Class((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-9)].yystate.yysemantics.yysval.valAnnotation), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-7)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-6)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valType), false, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_doc_loc((*yylocp))); }
#line 2453 "src/parser.cpp"
    break;

  case 163: /* $@10: %empty  */
#line 550 "src/parser.ypp"
                                                                        { push_raw(); }
#line 2459 "src/parser.cpp"
    break;

  case 164: /* class_declaration: class_annotation CLASS name optional_generics optional_parameters $@10 optional_class_braces  */
#line 550 "src/parser.ypp"
                                                                                                                                                 { ((*yyvalp).valStatement) = new birch::Class((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-6)].yystate.yysemantics.yysval.valAnnotation), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), empty_type((*yylocp)), false, empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_doc_loc((*yylocp))); }
#line 2465 "src/parser.cpp"
    break;

  case 165: /* $@11: %empty  */
#line 551 "src/parser.ypp"
                                                                   { push_raw(); }
#line 2471 "src/parser.cpp"
    break;

  case 166: /* class_declaration: class_annotation CLASS name optional_generics '=' named_type $@11 ';'  */
#line 551 "src/parser.ypp"
                                                                                                                                                 { ((*yyvalp).valStatement) = new birch::Class((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-7)].yystate.yysemantics.yysval.valAnnotation), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valExpression), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), true, empty_expr((*yylocp)), empty_stmt((*yylocp)), make_doc_loc((*yylocp))); }
#line 2477 "src/parser.cpp"
    break;

  case 167: /* basic_declaration: TYPE name '<' named_type ';'  */
#line 555 "src/parser.ypp"
                                    { push_raw(); ((*yyvalp).valStatement) = new birch::Basic(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valName), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valType), false, make_doc_loc((*yylocp))); }
#line 2483 "src/parser.cpp"
    break;

  case 168: /* basic_declaration: TYPE name '=' named_type ';'  */
#line 556 "src/parser.ypp"
                                    { push_raw(); ((*yyvalp).valStatement) = new birch::Basic(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valName), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valType), true, make_doc_loc((*yylocp))); }
#line 2489 "src/parser.cpp"
    break;

  case 169: /* basic_declaration: TYPE name ';'  */
#line 557 "src/parser.ypp"
                                    { push_raw(); ((*yyvalp).valStatement) = new birch::Basic(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valName), empty_expr((*yylocp)), empty_type((*yylocp)), false, make_doc_loc((*yylocp))); }
#line 2495 "src/parser.cpp"
    break;

  case 170: /* cpp: CPP double_braces  */
#line 561 "src/parser.ypp"
                         { push_raw(); ((*yyvalp).valStatement) = new birch::Raw(new birch::Name("cpp"), pop_raw(), make_loc((*yylocp))); }
#line 2501 "src/parser.cpp"
    break;

  case 171: /* hpp: HPP double_braces  */
#line 565 "src/parser.ypp"
                         { push_raw(); ((*yyvalp).valStatement) = new birch::Raw(new birch::Name("hpp"), pop_raw(), make_loc((*yylocp))); }
#line 2507 "src/parser.cpp"
    break;

  case 172: /* assume_operator: '~'  */
#line 569 "src/parser.ypp"
                      { ((*yyvalp).valName) = new birch::Name("~"); }
#line 2513 "src/parser.cpp"
    break;

  case 173: /* assume_operator: LEFT_TILDE_OP  */
#line 570 "src/parser.ypp"
                      { ((*yyvalp).valName) = new birch::Name("<~"); }
#line 2519 "src/parser.cpp"
    break;

  case 174: /* assume_operator: RIGHT_TILDE_OP  */
#line 571 "src/parser.ypp"
                      { ((*yyvalp).valName) = new birch::Name("~>"); }
#line 2525 "src/parser.cpp"
    break;

  case 175: /* assume_operator: LEFT_QUERY_OP  */
#line 572 "src/parser.ypp"
                      { ((*yyvalp).valName) = new birch::Name("<-?"); }
#line 2531 "src/parser.cpp"
    break;

  case 176: /* assume_statement: expression assume_operator expression ';'  */
#line 576 "src/parser.ypp"
                                                 { ((*yyvalp).valStatement) = new birch::Assume((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2537 "src/parser.cpp"
    break;

  case 177: /* expression_statement: expression ';'  */
#line 580 "src/parser.ypp"
                      { ((*yyvalp).valStatement) = new birch::ExpressionStatement((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2543 "src/parser.cpp"
    break;

  case 178: /* if: IF expression braces ELSE braces  */
#line 584 "src/parser.ypp"
                                        { ((*yyvalp).valStatement) = new birch::If((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2549 "src/parser.cpp"
    break;

  case 179: /* if: IF expression braces ELSE if  */
#line 585 "src/parser.ypp"
                                        { ((*yyvalp).valStatement) = new birch::If((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2555 "src/parser.cpp"
    break;

  case 180: /* if: IF expression braces  */
#line 586 "src/parser.ypp"
                                        { ((*yyvalp).valStatement) = new birch::If((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), empty_stmt((*yylocp)), make_loc((*yylocp))); }
#line 2561 "src/parser.cpp"
    break;

  case 181: /* for_variable_declaration: name  */
#line 590 "src/parser.ypp"
                          { ((*yyvalp).valStatement) = new birch::LocalVariable((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valName), new birch::NamedType(new birch::Name("Integer")), make_loc((*yylocp))); }
#line 2567 "src/parser.cpp"
    break;

  case 182: /* for: FOR for_variable_declaration IN expression RANGE_OP expression braces  */
#line 594 "src/parser.ypp"
                                                                             { ((*yyvalp).valStatement) = new birch::For(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2573 "src/parser.cpp"
    break;

  case 183: /* parallel_annotation: DYNAMIC  */
#line 598 "src/parser.ypp"
               { ((*yyvalp).valAnnotation) = birch::DYNAMIC; }
#line 2579 "src/parser.cpp"
    break;

  case 184: /* parallel: parallel_annotation PARALLEL FOR for_variable_declaration IN expression RANGE_OP expression braces  */
#line 604 "src/parser.ypp"
                                                                                                          { ((*yyvalp).valStatement) = new birch::Parallel((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-8)].yystate.yysemantics.yysval.valAnnotation), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2585 "src/parser.cpp"
    break;

  case 185: /* parallel: PARALLEL FOR for_variable_declaration IN expression RANGE_OP expression braces  */
#line 605 "src/parser.ypp"
                                                                                                          { ((*yyvalp).valStatement) = new birch::Parallel(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2591 "src/parser.cpp"
    break;

  case 186: /* while: WHILE expression braces  */
#line 609 "src/parser.ypp"
                               { ((*yyvalp).valStatement) = new birch::While((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2597 "src/parser.cpp"
    break;

  case 187: /* do_while: DO braces WHILE expression ';'  */
#line 613 "src/parser.ypp"
                                      { ((*yyvalp).valStatement) = new birch::DoWhile((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2603 "src/parser.cpp"
    break;

  case 188: /* with: WITH expression braces  */
#line 617 "src/parser.ypp"
                              { ((*yyvalp).valStatement) = new birch::With((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2609 "src/parser.cpp"
    break;

  case 189: /* block: braces  */
#line 621 "src/parser.ypp"
              { ((*yyvalp).valStatement) = new birch::Block((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2615 "src/parser.cpp"
    break;

  case 190: /* assertion: ASSERT expression ';'  */
#line 625 "src/parser.ypp"
                             { ((*yyvalp).valStatement) = new birch::Assert((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2621 "src/parser.cpp"
    break;

  case 191: /* return: RETURN optional_expression ';'  */
#line 629 "src/parser.ypp"
                                      { ((*yyvalp).valStatement) = new birch::Return((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2627 "src/parser.cpp"
    break;

  case 192: /* factor: FACTOR optional_expression ';'  */
#line 633 "src/parser.ypp"
                                      { ((*yyvalp).valStatement) = new birch::Factor((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2633 "src/parser.cpp"
    break;

  case 208: /* statements: statement statements  */
#line 655 "src/parser.ypp"
                            { ((*yyvalp).valStatement) = new birch::StatementList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2639 "src/parser.cpp"
    break;

  case 210: /* optional_statements: %empty  */
#line 660 "src/parser.ypp"
                  { ((*yyvalp).valStatement) = empty_stmt((*yylocp)); }
#line 2645 "src/parser.cpp"
    break;

  case 217: /* class_statements: class_statement class_statements  */
#line 673 "src/parser.ypp"
                                        { ((*yyvalp).valStatement) = new birch::StatementList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2651 "src/parser.cpp"
    break;

  case 219: /* optional_class_statements: %empty  */
#line 678 "src/parser.ypp"
                        { ((*yyvalp).valStatement) = empty_stmt((*yylocp)); }
#line 2657 "src/parser.cpp"
    break;

  case 230: /* file_statements: file_statement file_statements  */
#line 695 "src/parser.ypp"
                                      { ((*yyvalp).valStatement) = new birch::StatementList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2663 "src/parser.cpp"
    break;

  case 232: /* optional_file_statements: %empty  */
#line 700 "src/parser.ypp"
                       { ((*yyvalp).valStatement) = empty_stmt((*yylocp)); }
#line 2669 "src/parser.cpp"
    break;

  case 233: /* file: optional_file_statements  */
#line 704 "src/parser.ypp"
                                { compiler->setRoot((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement)); }
#line 2675 "src/parser.cpp"
    break;

  case 234: /* return_type: RIGHT_OP type  */
#line 708 "src/parser.ypp"
                     { ((*yyvalp).valType) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valType); }
#line 2681 "src/parser.cpp"
    break;

  case 236: /* optional_return_type: %empty  */
#line 713 "src/parser.ypp"
                   { ((*yyvalp).valType) = empty_type((*yylocp)); }
#line 2687 "src/parser.cpp"
    break;

  case 237: /* value: LEFT_OP expression  */
#line 717 "src/parser.ypp"
                          { ((*yyvalp).valExpression) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression); }
#line 2693 "src/parser.cpp"
    break;

  case 239: /* optional_value: %empty  */
#line 722 "src/parser.ypp"
             { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2699 "src/parser.cpp"
    break;

  case 240: /* braces: '{' optional_statements '}'  */
#line 726 "src/parser.ypp"
                                   { ((*yyvalp).valStatement) = new birch::Braces((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2705 "src/parser.cpp"
    break;

  case 242: /* optional_braces: ';'  */
#line 731 "src/parser.ypp"
              { ((*yyvalp).valStatement) = empty_stmt((*yylocp)); }
#line 2711 "src/parser.cpp"
    break;

  case 243: /* class_braces: '{' optional_class_statements '}'  */
#line 735 "src/parser.ypp"
                                         { ((*yyvalp).valStatement) = new birch::Braces((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2717 "src/parser.cpp"
    break;

  case 245: /* optional_class_braces: ';'  */
#line 740 "src/parser.ypp"
                    { ((*yyvalp).valStatement) = empty_stmt((*yylocp)); }
#line 2723 "src/parser.cpp"
    break;

  case 247: /* named_type: name optional_generic_arguments  */
#line 753 "src/parser.ypp"
                                           { ((*yyvalp).valType) = new birch::NamedType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valType), make_loc((*yylocp))); }
#line 2729 "src/parser.cpp"
    break;

  case 248: /* named_type: name optional_generic_arguments '&'  */
#line 754 "src/parser.ypp"
                                           { yywarn("using weak pointers is no longer necessary"); ((*yyvalp).valType) = new birch::NamedType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valType), make_loc((*yylocp))); }
#line 2735 "src/parser.cpp"
    break;

  case 250: /* primary_type: '(' type_list ')'  */
#line 759 "src/parser.ypp"
                         { ((*yyvalp).valType) = new birch::TupleType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valType), make_loc((*yylocp))); }
#line 2741 "src/parser.cpp"
    break;

  case 252: /* type: type '?'  */
#line 764 "src/parser.ypp"
                                                            { ((*yyvalp).valType) = new birch::OptionalType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valType), make_loc((*yylocp))); }
#line 2747 "src/parser.cpp"
    break;

  case 253: /* type: named_type '.' named_type  */
#line 765 "src/parser.ypp"
                                                            { ((*yyvalp).valType) = new birch::MemberType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valType), make_loc((*yylocp))); }
#line 2753 "src/parser.cpp"
    break;

  case 254: /* type: type '[' shape ']'  */
#line 766 "src/parser.ypp"
                                                            { ((*yyvalp).valType) = new birch::ArrayType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valInt), make_loc((*yylocp))); }
#line 2759 "src/parser.cpp"
    break;

  case 255: /* type: '\\' '(' optional_type_list ')' optional_return_type  */
#line 767 "src/parser.ypp"
                                                            { ((*yyvalp).valType) = new birch::FunctionType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valType), make_loc((*yylocp))); }
#line 2765 "src/parser.cpp"
    break;

  case 257: /* type_list: type ',' type_list  */
#line 772 "src/parser.ypp"
                          { ((*yyvalp).valType) = new birch::TypeList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valType), make_loc((*yylocp))); }
#line 2771 "src/parser.cpp"
    break;

  case 259: /* optional_type_list: %empty  */
#line 777 "src/parser.ypp"
                 { ((*yyvalp).valType) = empty_type((*yylocp)); }
#line 2777 "src/parser.cpp"
    break;


#line 2781 "src/parser.cpp"

      default: break;
    }

  return yyok;
# undef yyerrok
# undef YYABORT
# undef YYACCEPT
# undef YYERROR
# undef YYBACKUP
# undef yyclearin
# undef YYRECOVERING
}


static void
yyuserMerge (int yyn, YYSTYPE* yy0, YYSTYPE* yy1)
{
  YYUSE (yy0);
  YYUSE (yy1);

  switch (yyn)
    {

      default: break;
    }
}

                              /* Bison grammar-table manipulation.  */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
{
  YYUSE (yyvaluep);
  YYUSE (yylocationp);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}

/** Number of symbols composing the right hand side of rule #RULE.  */
static inline int
yyrhsLength (yyRuleNum yyrule)
{
  return yyr2[yyrule];
}

static void
yydestroyGLRState (char const *yymsg, yyGLRState *yys)
{
  if (yys->yyresolved)
    yydestruct (yymsg, yy_accessing_symbol (yys->yylrState),
                &yys->yysemantics.yysval, &yys->yyloc);
  else
    {
#if YYDEBUG
      if (yydebug)
        {
          if (yys->yysemantics.yyfirstVal)
            YY_FPRINTF ((stderr, "%s unresolved", yymsg));
          else
            YY_FPRINTF ((stderr, "%s incomplete", yymsg));
          YY_SYMBOL_PRINT ("", yy_accessing_symbol (yys->yylrState), YY_NULLPTR, &yys->yyloc);
        }
#endif

      if (yys->yysemantics.yyfirstVal)
        {
          yySemanticOption *yyoption = yys->yysemantics.yyfirstVal;
          yyGLRState *yyrh;
          int yyn;
          for (yyrh = yyoption->yystate, yyn = yyrhsLength (yyoption->yyrule);
               yyn > 0;
               yyrh = yyrh->yypred, yyn -= 1)
            yydestroyGLRState (yymsg, yyrh);
        }
    }
}

/** Left-hand-side symbol for rule #YYRULE.  */
static inline yysymbol_kind_t
yylhsNonterm (yyRuleNum yyrule)
{
  return YY_CAST (yysymbol_kind_t, yyr1[yyrule]);
}

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

/** True iff LR state YYSTATE has only a default reduction (regardless
 *  of token).  */
static inline yybool
yyisDefaultedState (yy_state_t yystate)
{
  return yypact_value_is_default (yypact[yystate]);
}

/** The default reduction for YYSTATE, assuming it has one.  */
static inline yyRuleNum
yydefaultAction (yy_state_t yystate)
{
  return yydefact[yystate];
}

#define yytable_value_is_error(Yyn) \
  0

/** The action to take in YYSTATE on seeing YYTOKEN.
 *  Result R means
 *    R < 0:  Reduce on rule -R.
 *    R = 0:  Error.
 *    R > 0:  Shift to state R.
 *  Set *YYCONFLICTS to a pointer into yyconfl to a 0-terminated list
 *  of conflicting reductions.
 */
static inline int
yygetLRActions (yy_state_t yystate, yysymbol_kind_t yytoken, const short** yyconflicts)
{
  int yyindex = yypact[yystate] + yytoken;
  if (yytoken == YYSYMBOL_YYerror)
    {
      // This is the error token.
      *yyconflicts = yyconfl;
      return 0;
    }
  else if (yyisDefaultedState (yystate)
           || yyindex < 0 || YYLAST < yyindex || yycheck[yyindex] != yytoken)
    {
      *yyconflicts = yyconfl;
      return -yydefact[yystate];
    }
  else if (! yytable_value_is_error (yytable[yyindex]))
    {
      *yyconflicts = yyconfl + yyconflp[yyindex];
      return yytable[yyindex];
    }
  else
    {
      *yyconflicts = yyconfl + yyconflp[yyindex];
      return 0;
    }
}

/** Compute post-reduction state.
 * \param yystate   the current state
 * \param yysym     the nonterminal to push on the stack
 */
static inline yy_state_t
yyLRgotoState (yy_state_t yystate, yysymbol_kind_t yysym)
{
  int yyr = yypgoto[yysym - YYNTOKENS] + yystate;
  if (0 <= yyr && yyr <= YYLAST && yycheck[yyr] == yystate)
    return yytable[yyr];
  else
    return yydefgoto[yysym - YYNTOKENS];
}

static inline yybool
yyisShiftAction (int yyaction)
{
  return 0 < yyaction;
}

static inline yybool
yyisErrorAction (int yyaction)
{
  return yyaction == 0;
}

                                /* GLRStates */

/** Return a fresh GLRStackItem in YYSTACKP.  The item is an LR state
 *  if YYISSTATE, and otherwise a semantic option.  Callers should call
 *  YY_RESERVE_GLRSTACK afterwards to make sure there is sufficient
 *  headroom.  */

static inline yyGLRStackItem*
yynewGLRStackItem (yyGLRStack* yystackp, yybool yyisState)
{
  yyGLRStackItem* yynewItem = yystackp->yynextFree;
  yystackp->yyspaceLeft -= 1;
  yystackp->yynextFree += 1;
  yynewItem->yystate.yyisState = yyisState;
  return yynewItem;
}

/** Add a new semantic action that will execute the action for rule
 *  YYRULE on the semantic values in YYRHS to the list of
 *  alternative actions for YYSTATE.  Assumes that YYRHS comes from
 *  stack #YYK of *YYSTACKP. */
static void
yyaddDeferredAction (yyGLRStack* yystackp, YYPTRDIFF_T yyk, yyGLRState* yystate,
                     yyGLRState* yyrhs, yyRuleNum yyrule)
{
  yySemanticOption* yynewOption =
    &yynewGLRStackItem (yystackp, yyfalse)->yyoption;
  YY_ASSERT (!yynewOption->yyisState);
  yynewOption->yystate = yyrhs;
  yynewOption->yyrule = yyrule;
  if (yystackp->yytops.yylookaheadNeeds[yyk])
    {
      yynewOption->yyrawchar = yychar;
      yynewOption->yyval = yylval;
      yynewOption->yyloc = yylloc;
    }
  else
    yynewOption->yyrawchar = YYEMPTY;
  yynewOption->yynext = yystate->yysemantics.yyfirstVal;
  yystate->yysemantics.yyfirstVal = yynewOption;

  YY_RESERVE_GLRSTACK (yystackp);
}

                                /* GLRStacks */

/** Initialize YYSET to a singleton set containing an empty stack.  */
static yybool
yyinitStateSet (yyGLRStateSet* yyset)
{
  yyset->yysize = 1;
  yyset->yycapacity = 16;
  yyset->yystates
    = YY_CAST (yyGLRState**,
               YYMALLOC (YY_CAST (YYSIZE_T, yyset->yycapacity)
                         * sizeof yyset->yystates[0]));
  if (! yyset->yystates)
    return yyfalse;
  yyset->yystates[0] = YY_NULLPTR;
  yyset->yylookaheadNeeds
    = YY_CAST (yybool*,
               YYMALLOC (YY_CAST (YYSIZE_T, yyset->yycapacity)
                         * sizeof yyset->yylookaheadNeeds[0]));
  if (! yyset->yylookaheadNeeds)
    {
      YYFREE (yyset->yystates);
      return yyfalse;
    }
  memset (yyset->yylookaheadNeeds,
          0,
          YY_CAST (YYSIZE_T, yyset->yycapacity) * sizeof yyset->yylookaheadNeeds[0]);
  return yytrue;
}

static void yyfreeStateSet (yyGLRStateSet* yyset)
{
  YYFREE (yyset->yystates);
  YYFREE (yyset->yylookaheadNeeds);
}

/** Initialize *YYSTACKP to a single empty stack, with total maximum
 *  capacity for all stacks of YYSIZE.  */
static yybool
yyinitGLRStack (yyGLRStack* yystackp, YYPTRDIFF_T yysize)
{
  yystackp->yyerrState = 0;
  yynerrs = 0;
  yystackp->yyspaceLeft = yysize;
  yystackp->yyitems
    = YY_CAST (yyGLRStackItem*,
               YYMALLOC (YY_CAST (YYSIZE_T, yysize)
                         * sizeof yystackp->yynextFree[0]));
  if (!yystackp->yyitems)
    return yyfalse;
  yystackp->yynextFree = yystackp->yyitems;
  yystackp->yysplitPoint = YY_NULLPTR;
  yystackp->yylastDeleted = YY_NULLPTR;
  return yyinitStateSet (&yystackp->yytops);
}


#if YYSTACKEXPANDABLE
# define YYRELOC(YYFROMITEMS, YYTOITEMS, YYX, YYTYPE)                   \
  &((YYTOITEMS)                                                         \
    - ((YYFROMITEMS) - YY_REINTERPRET_CAST (yyGLRStackItem*, (YYX))))->YYTYPE

/** If *YYSTACKP is expandable, extend it.  WARNING: Pointers into the
    stack from outside should be considered invalid after this call.
    We always expand when there are 1 or fewer items left AFTER an
    allocation, so that we can avoid having external pointers exist
    across an allocation.  */
static void
yyexpandGLRStack (yyGLRStack* yystackp)
{
  yyGLRStackItem* yynewItems;
  yyGLRStackItem* yyp0, *yyp1;
  YYPTRDIFF_T yynewSize;
  YYPTRDIFF_T yyn;
  YYPTRDIFF_T yysize = yystackp->yynextFree - yystackp->yyitems;
  if (YYMAXDEPTH - YYHEADROOM < yysize)
    yyMemoryExhausted (yystackp);
  yynewSize = 2*yysize;
  if (YYMAXDEPTH < yynewSize)
    yynewSize = YYMAXDEPTH;
  yynewItems
    = YY_CAST (yyGLRStackItem*,
               YYMALLOC (YY_CAST (YYSIZE_T, yynewSize)
                         * sizeof yynewItems[0]));
  if (! yynewItems)
    yyMemoryExhausted (yystackp);
  for (yyp0 = yystackp->yyitems, yyp1 = yynewItems, yyn = yysize;
       0 < yyn;
       yyn -= 1, yyp0 += 1, yyp1 += 1)
    {
      *yyp1 = *yyp0;
      if (*YY_REINTERPRET_CAST (yybool *, yyp0))
        {
          yyGLRState* yys0 = &yyp0->yystate;
          yyGLRState* yys1 = &yyp1->yystate;
          if (yys0->yypred != YY_NULLPTR)
            yys1->yypred =
              YYRELOC (yyp0, yyp1, yys0->yypred, yystate);
          if (! yys0->yyresolved && yys0->yysemantics.yyfirstVal != YY_NULLPTR)
            yys1->yysemantics.yyfirstVal =
              YYRELOC (yyp0, yyp1, yys0->yysemantics.yyfirstVal, yyoption);
        }
      else
        {
          yySemanticOption* yyv0 = &yyp0->yyoption;
          yySemanticOption* yyv1 = &yyp1->yyoption;
          if (yyv0->yystate != YY_NULLPTR)
            yyv1->yystate = YYRELOC (yyp0, yyp1, yyv0->yystate, yystate);
          if (yyv0->yynext != YY_NULLPTR)
            yyv1->yynext = YYRELOC (yyp0, yyp1, yyv0->yynext, yyoption);
        }
    }
  if (yystackp->yysplitPoint != YY_NULLPTR)
    yystackp->yysplitPoint = YYRELOC (yystackp->yyitems, yynewItems,
                                      yystackp->yysplitPoint, yystate);

  for (yyn = 0; yyn < yystackp->yytops.yysize; yyn += 1)
    if (yystackp->yytops.yystates[yyn] != YY_NULLPTR)
      yystackp->yytops.yystates[yyn] =
        YYRELOC (yystackp->yyitems, yynewItems,
                 yystackp->yytops.yystates[yyn], yystate);
  YYFREE (yystackp->yyitems);
  yystackp->yyitems = yynewItems;
  yystackp->yynextFree = yynewItems + yysize;
  yystackp->yyspaceLeft = yynewSize - yysize;
}
#endif

static void
yyfreeGLRStack (yyGLRStack* yystackp)
{
  YYFREE (yystackp->yyitems);
  yyfreeStateSet (&yystackp->yytops);
}

/** Assuming that YYS is a GLRState somewhere on *YYSTACKP, update the
 *  splitpoint of *YYSTACKP, if needed, so that it is at least as deep as
 *  YYS.  */
static inline void
yyupdateSplit (yyGLRStack* yystackp, yyGLRState* yys)
{
  if (yystackp->yysplitPoint != YY_NULLPTR && yystackp->yysplitPoint > yys)
    yystackp->yysplitPoint = yys;
}

/** Invalidate stack #YYK in *YYSTACKP.  */
static inline void
yymarkStackDeleted (yyGLRStack* yystackp, YYPTRDIFF_T yyk)
{
  if (yystackp->yytops.yystates[yyk] != YY_NULLPTR)
    yystackp->yylastDeleted = yystackp->yytops.yystates[yyk];
  yystackp->yytops.yystates[yyk] = YY_NULLPTR;
}

/** Undelete the last stack in *YYSTACKP that was marked as deleted.  Can
    only be done once after a deletion, and only when all other stacks have
    been deleted.  */
static void
yyundeleteLastStack (yyGLRStack* yystackp)
{
  if (yystackp->yylastDeleted == YY_NULLPTR || yystackp->yytops.yysize != 0)
    return;
  yystackp->yytops.yystates[0] = yystackp->yylastDeleted;
  yystackp->yytops.yysize = 1;
  YY_DPRINTF ((stderr, "Restoring last deleted stack as stack #0.\n"));
  yystackp->yylastDeleted = YY_NULLPTR;
}

static inline void
yyremoveDeletes (yyGLRStack* yystackp)
{
  YYPTRDIFF_T yyi, yyj;
  yyi = yyj = 0;
  while (yyj < yystackp->yytops.yysize)
    {
      if (yystackp->yytops.yystates[yyi] == YY_NULLPTR)
        {
          if (yyi == yyj)
            YY_DPRINTF ((stderr, "Removing dead stacks.\n"));
          yystackp->yytops.yysize -= 1;
        }
      else
        {
          yystackp->yytops.yystates[yyj] = yystackp->yytops.yystates[yyi];
          /* In the current implementation, it's unnecessary to copy
             yystackp->yytops.yylookaheadNeeds[yyi] since, after
             yyremoveDeletes returns, the parser immediately either enters
             deterministic operation or shifts a token.  However, it doesn't
             hurt, and the code might evolve to need it.  */
          yystackp->yytops.yylookaheadNeeds[yyj] =
            yystackp->yytops.yylookaheadNeeds[yyi];
          if (yyj != yyi)
            YY_DPRINTF ((stderr, "Rename stack %ld -> %ld.\n",
                        YY_CAST (long, yyi), YY_CAST (long, yyj)));
          yyj += 1;
        }
      yyi += 1;
    }
}

/** Shift to a new state on stack #YYK of *YYSTACKP, corresponding to LR
 * state YYLRSTATE, at input position YYPOSN, with (resolved) semantic
 * value *YYVALP and source location *YYLOCP.  */
static inline void
yyglrShift (yyGLRStack* yystackp, YYPTRDIFF_T yyk, yy_state_t yylrState,
            YYPTRDIFF_T yyposn,
            YYSTYPE* yyvalp, YYLTYPE* yylocp)
{
  yyGLRState* yynewState = &yynewGLRStackItem (yystackp, yytrue)->yystate;

  yynewState->yylrState = yylrState;
  yynewState->yyposn = yyposn;
  yynewState->yyresolved = yytrue;
  yynewState->yypred = yystackp->yytops.yystates[yyk];
  yynewState->yysemantics.yysval = *yyvalp;
  yynewState->yyloc = *yylocp;
  yystackp->yytops.yystates[yyk] = yynewState;

  YY_RESERVE_GLRSTACK (yystackp);
}

/** Shift stack #YYK of *YYSTACKP, to a new state corresponding to LR
 *  state YYLRSTATE, at input position YYPOSN, with the (unresolved)
 *  semantic value of YYRHS under the action for YYRULE.  */
static inline void
yyglrShiftDefer (yyGLRStack* yystackp, YYPTRDIFF_T yyk, yy_state_t yylrState,
                 YYPTRDIFF_T yyposn, yyGLRState* yyrhs, yyRuleNum yyrule)
{
  yyGLRState* yynewState = &yynewGLRStackItem (yystackp, yytrue)->yystate;
  YY_ASSERT (yynewState->yyisState);

  yynewState->yylrState = yylrState;
  yynewState->yyposn = yyposn;
  yynewState->yyresolved = yyfalse;
  yynewState->yypred = yystackp->yytops.yystates[yyk];
  yynewState->yysemantics.yyfirstVal = YY_NULLPTR;
  yystackp->yytops.yystates[yyk] = yynewState;

  /* Invokes YY_RESERVE_GLRSTACK.  */
  yyaddDeferredAction (yystackp, yyk, yynewState, yyrhs, yyrule);
}

#if !YYDEBUG
# define YY_REDUCE_PRINT(Args)
#else
# define YY_REDUCE_PRINT(Args)          \
  do {                                  \
    if (yydebug)                        \
      yy_reduce_print Args;             \
  } while (0)

/*----------------------------------------------------------------------.
| Report that stack #YYK of *YYSTACKP is going to be reduced by YYRULE. |
`----------------------------------------------------------------------*/

static inline void
yy_reduce_print (yybool yynormal, yyGLRStackItem* yyvsp, YYPTRDIFF_T yyk,
                 yyRuleNum yyrule)
{
  int yynrhs = yyrhsLength (yyrule);
  int yylow = 1;
  int yyi;
  YY_FPRINTF ((stderr, "Reducing stack %ld by rule %d (line %d):\n",
               YY_CAST (long, yyk), yyrule - 1, yyrline[yyrule]));
  if (! yynormal)
    yyfillin (yyvsp, 1, -yynrhs);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YY_FPRINTF ((stderr, "   $%d = ", yyi + 1));
      yy_symbol_print (stderr,
                       yy_accessing_symbol (yyvsp[yyi - yynrhs + 1].yystate.yylrState),
                       &yyvsp[yyi - yynrhs + 1].yystate.yysemantics.yysval,
                       &(YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL ((yyi + 1) - (yynrhs))].yystate.yyloc)                       );
      if (!yyvsp[yyi - yynrhs + 1].yystate.yyresolved)
        YY_FPRINTF ((stderr, " (unresolved)"));
      YY_FPRINTF ((stderr, "\n"));
    }
}
#endif

/** Pop the symbols consumed by reduction #YYRULE from the top of stack
 *  #YYK of *YYSTACKP, and perform the appropriate semantic action on their
 *  semantic values.  Assumes that all ambiguities in semantic values
 *  have been previously resolved.  Set *YYVALP to the resulting value,
 *  and *YYLOCP to the computed location (if any).  Return value is as
 *  for userAction.  */
static inline YYRESULTTAG
yydoAction (yyGLRStack* yystackp, YYPTRDIFF_T yyk, yyRuleNum yyrule,
            YYSTYPE* yyvalp, YYLTYPE *yylocp)
{
  int yynrhs = yyrhsLength (yyrule);

  if (yystackp->yysplitPoint == YY_NULLPTR)
    {
      /* Standard special case: single stack.  */
      yyGLRStackItem* yyrhs
        = YY_REINTERPRET_CAST (yyGLRStackItem*, yystackp->yytops.yystates[yyk]);
      YY_ASSERT (yyk == 0);
      yystackp->yynextFree -= yynrhs;
      yystackp->yyspaceLeft += yynrhs;
      yystackp->yytops.yystates[0] = & yystackp->yynextFree[-1].yystate;
      YY_REDUCE_PRINT ((yytrue, yyrhs, yyk, yyrule));
      return yyuserAction (yyrule, yynrhs, yyrhs, yystackp,
                           yyvalp, yylocp);
    }
  else
    {
      yyGLRStackItem yyrhsVals[YYMAXRHS + YYMAXLEFT + 1];
      yyGLRState* yys = yyrhsVals[YYMAXRHS + YYMAXLEFT].yystate.yypred
        = yystackp->yytops.yystates[yyk];
      int yyi;
      if (yynrhs == 0)
        /* Set default location.  */
        yyrhsVals[YYMAXRHS + YYMAXLEFT - 1].yystate.yyloc = yys->yyloc;
      for (yyi = 0; yyi < yynrhs; yyi += 1)
        {
          yys = yys->yypred;
          YY_ASSERT (yys);
        }
      yyupdateSplit (yystackp, yys);
      yystackp->yytops.yystates[yyk] = yys;
      YY_REDUCE_PRINT ((yyfalse, yyrhsVals + YYMAXRHS + YYMAXLEFT - 1, yyk, yyrule));
      return yyuserAction (yyrule, yynrhs, yyrhsVals + YYMAXRHS + YYMAXLEFT - 1,
                           yystackp, yyvalp, yylocp);
    }
}

/** Pop items off stack #YYK of *YYSTACKP according to grammar rule YYRULE,
 *  and push back on the resulting nonterminal symbol.  Perform the
 *  semantic action associated with YYRULE and store its value with the
 *  newly pushed state, if YYFORCEEVAL or if *YYSTACKP is currently
 *  unambiguous.  Otherwise, store the deferred semantic action with
 *  the new state.  If the new state would have an identical input
 *  position, LR state, and predecessor to an existing state on the stack,
 *  it is identified with that existing state, eliminating stack #YYK from
 *  *YYSTACKP.  In this case, the semantic value is
 *  added to the options for the existing state's semantic value.
 */
static inline YYRESULTTAG
yyglrReduce (yyGLRStack* yystackp, YYPTRDIFF_T yyk, yyRuleNum yyrule,
             yybool yyforceEval)
{
  YYPTRDIFF_T yyposn = yystackp->yytops.yystates[yyk]->yyposn;

  if (yyforceEval || yystackp->yysplitPoint == YY_NULLPTR)
    {
      YYSTYPE yysval;
      YYLTYPE yyloc;

      YYRESULTTAG yyflag = yydoAction (yystackp, yyk, yyrule, &yysval, &yyloc);
      if (yyflag == yyerr && yystackp->yysplitPoint != YY_NULLPTR)
        YY_DPRINTF ((stderr,
                     "Parse on stack %ld rejected by rule %d (line %d).\n",
                     YY_CAST (long, yyk), yyrule - 1, yyrline[yyrule - 1]));
      if (yyflag != yyok)
        return yyflag;
      YY_SYMBOL_PRINT ("-> $$ =", yylhsNonterm (yyrule), &yysval, &yyloc);
      yyglrShift (yystackp, yyk,
                  yyLRgotoState (yystackp->yytops.yystates[yyk]->yylrState,
                                 yylhsNonterm (yyrule)),
                  yyposn, &yysval, &yyloc);
    }
  else
    {
      YYPTRDIFF_T yyi;
      int yyn;
      yyGLRState* yys, *yys0 = yystackp->yytops.yystates[yyk];
      yy_state_t yynewLRState;

      for (yys = yystackp->yytops.yystates[yyk], yyn = yyrhsLength (yyrule);
           0 < yyn; yyn -= 1)
        {
          yys = yys->yypred;
          YY_ASSERT (yys);
        }
      yyupdateSplit (yystackp, yys);
      yynewLRState = yyLRgotoState (yys->yylrState, yylhsNonterm (yyrule));
      YY_DPRINTF ((stderr,
                   "Reduced stack %ld by rule %d (line %d); action deferred.  "
                   "Now in state %d.\n",
                   YY_CAST (long, yyk), yyrule - 1, yyrline[yyrule - 1],
                   yynewLRState));
      for (yyi = 0; yyi < yystackp->yytops.yysize; yyi += 1)
        if (yyi != yyk && yystackp->yytops.yystates[yyi] != YY_NULLPTR)
          {
            yyGLRState *yysplit = yystackp->yysplitPoint;
            yyGLRState *yyp = yystackp->yytops.yystates[yyi];
            while (yyp != yys && yyp != yysplit && yyp->yyposn >= yyposn)
              {
                if (yyp->yylrState == yynewLRState && yyp->yypred == yys)
                  {
                    yyaddDeferredAction (yystackp, yyk, yyp, yys0, yyrule);
                    yymarkStackDeleted (yystackp, yyk);
                    YY_DPRINTF ((stderr, "Merging stack %ld into stack %ld.\n",
                                 YY_CAST (long, yyk), YY_CAST (long, yyi)));
                    return yyok;
                  }
                yyp = yyp->yypred;
              }
          }
      yystackp->yytops.yystates[yyk] = yys;
      yyglrShiftDefer (yystackp, yyk, yynewLRState, yyposn, yys0, yyrule);
    }
  return yyok;
}

static YYPTRDIFF_T
yysplitStack (yyGLRStack* yystackp, YYPTRDIFF_T yyk)
{
  if (yystackp->yysplitPoint == YY_NULLPTR)
    {
      YY_ASSERT (yyk == 0);
      yystackp->yysplitPoint = yystackp->yytops.yystates[yyk];
    }
  if (yystackp->yytops.yycapacity <= yystackp->yytops.yysize)
    {
      YYPTRDIFF_T state_size = YYSIZEOF (yystackp->yytops.yystates[0]);
      YYPTRDIFF_T half_max_capacity = YYSIZE_MAXIMUM / 2 / state_size;
      if (half_max_capacity < yystackp->yytops.yycapacity)
        yyMemoryExhausted (yystackp);
      yystackp->yytops.yycapacity *= 2;

      {
        yyGLRState** yynewStates
          = YY_CAST (yyGLRState**,
                     YYREALLOC (yystackp->yytops.yystates,
                                (YY_CAST (YYSIZE_T, yystackp->yytops.yycapacity)
                                 * sizeof yynewStates[0])));
        if (yynewStates == YY_NULLPTR)
          yyMemoryExhausted (yystackp);
        yystackp->yytops.yystates = yynewStates;
      }

      {
        yybool* yynewLookaheadNeeds
          = YY_CAST (yybool*,
                     YYREALLOC (yystackp->yytops.yylookaheadNeeds,
                                (YY_CAST (YYSIZE_T, yystackp->yytops.yycapacity)
                                 * sizeof yynewLookaheadNeeds[0])));
        if (yynewLookaheadNeeds == YY_NULLPTR)
          yyMemoryExhausted (yystackp);
        yystackp->yytops.yylookaheadNeeds = yynewLookaheadNeeds;
      }
    }
  yystackp->yytops.yystates[yystackp->yytops.yysize]
    = yystackp->yytops.yystates[yyk];
  yystackp->yytops.yylookaheadNeeds[yystackp->yytops.yysize]
    = yystackp->yytops.yylookaheadNeeds[yyk];
  yystackp->yytops.yysize += 1;
  return yystackp->yytops.yysize - 1;
}

/** True iff YYY0 and YYY1 represent identical options at the top level.
 *  That is, they represent the same rule applied to RHS symbols
 *  that produce the same terminal symbols.  */
static yybool
yyidenticalOptions (yySemanticOption* yyy0, yySemanticOption* yyy1)
{
  if (yyy0->yyrule == yyy1->yyrule)
    {
      yyGLRState *yys0, *yys1;
      int yyn;
      for (yys0 = yyy0->yystate, yys1 = yyy1->yystate,
           yyn = yyrhsLength (yyy0->yyrule);
           yyn > 0;
           yys0 = yys0->yypred, yys1 = yys1->yypred, yyn -= 1)
        if (yys0->yyposn != yys1->yyposn)
          return yyfalse;
      return yytrue;
    }
  else
    return yyfalse;
}

/** Assuming identicalOptions (YYY0,YYY1), destructively merge the
 *  alternative semantic values for the RHS-symbols of YYY1 and YYY0.  */
static void
yymergeOptionSets (yySemanticOption* yyy0, yySemanticOption* yyy1)
{
  yyGLRState *yys0, *yys1;
  int yyn;
  for (yys0 = yyy0->yystate, yys1 = yyy1->yystate,
       yyn = yyrhsLength (yyy0->yyrule);
       0 < yyn;
       yys0 = yys0->yypred, yys1 = yys1->yypred, yyn -= 1)
    {
      if (yys0 == yys1)
        break;
      else if (yys0->yyresolved)
        {
          yys1->yyresolved = yytrue;
          yys1->yysemantics.yysval = yys0->yysemantics.yysval;
        }
      else if (yys1->yyresolved)
        {
          yys0->yyresolved = yytrue;
          yys0->yysemantics.yysval = yys1->yysemantics.yysval;
        }
      else
        {
          yySemanticOption** yyz0p = &yys0->yysemantics.yyfirstVal;
          yySemanticOption* yyz1 = yys1->yysemantics.yyfirstVal;
          while (yytrue)
            {
              if (yyz1 == *yyz0p || yyz1 == YY_NULLPTR)
                break;
              else if (*yyz0p == YY_NULLPTR)
                {
                  *yyz0p = yyz1;
                  break;
                }
              else if (*yyz0p < yyz1)
                {
                  yySemanticOption* yyz = *yyz0p;
                  *yyz0p = yyz1;
                  yyz1 = yyz1->yynext;
                  (*yyz0p)->yynext = yyz;
                }
              yyz0p = &(*yyz0p)->yynext;
            }
          yys1->yysemantics.yyfirstVal = yys0->yysemantics.yyfirstVal;
        }
    }
}

/** Y0 and Y1 represent two possible actions to take in a given
 *  parsing state; return 0 if no combination is possible,
 *  1 if user-mergeable, 2 if Y0 is preferred, 3 if Y1 is preferred.  */
static int
yypreference (yySemanticOption* y0, yySemanticOption* y1)
{
  yyRuleNum r0 = y0->yyrule, r1 = y1->yyrule;
  int p0 = yydprec[r0], p1 = yydprec[r1];

  if (p0 == p1)
    {
      if (yymerger[r0] == 0 || yymerger[r0] != yymerger[r1])
        return 0;
      else
        return 1;
    }
  if (p0 == 0 || p1 == 0)
    return 0;
  if (p0 < p1)
    return 3;
  if (p1 < p0)
    return 2;
  return 0;
}

static YYRESULTTAG yyresolveValue (yyGLRState* yys,
                                   yyGLRStack* yystackp);


/** Resolve the previous YYN states starting at and including state YYS
 *  on *YYSTACKP. If result != yyok, some states may have been left
 *  unresolved possibly with empty semantic option chains.  Regardless
 *  of whether result = yyok, each state has been left with consistent
 *  data so that yydestroyGLRState can be invoked if necessary.  */
static YYRESULTTAG
yyresolveStates (yyGLRState* yys, int yyn,
                 yyGLRStack* yystackp)
{
  if (0 < yyn)
    {
      YY_ASSERT (yys->yypred);
      YYCHK (yyresolveStates (yys->yypred, yyn-1, yystackp));
      if (! yys->yyresolved)
        YYCHK (yyresolveValue (yys, yystackp));
    }
  return yyok;
}

/** Resolve the states for the RHS of YYOPT on *YYSTACKP, perform its
 *  user action, and return the semantic value and location in *YYVALP
 *  and *YYLOCP.  Regardless of whether result = yyok, all RHS states
 *  have been destroyed (assuming the user action destroys all RHS
 *  semantic values if invoked).  */
static YYRESULTTAG
yyresolveAction (yySemanticOption* yyopt, yyGLRStack* yystackp,
                 YYSTYPE* yyvalp, YYLTYPE *yylocp)
{
  yyGLRStackItem yyrhsVals[YYMAXRHS + YYMAXLEFT + 1];
  int yynrhs = yyrhsLength (yyopt->yyrule);
  YYRESULTTAG yyflag =
    yyresolveStates (yyopt->yystate, yynrhs, yystackp);
  if (yyflag != yyok)
    {
      yyGLRState *yys;
      for (yys = yyopt->yystate; yynrhs > 0; yys = yys->yypred, yynrhs -= 1)
        yydestroyGLRState ("Cleanup: popping", yys);
      return yyflag;
    }

  yyrhsVals[YYMAXRHS + YYMAXLEFT].yystate.yypred = yyopt->yystate;
  if (yynrhs == 0)
    /* Set default location.  */
    yyrhsVals[YYMAXRHS + YYMAXLEFT - 1].yystate.yyloc = yyopt->yystate->yyloc;
  {
    int yychar_current = yychar;
    YYSTYPE yylval_current = yylval;
    YYLTYPE yylloc_current = yylloc;
    yychar = yyopt->yyrawchar;
    yylval = yyopt->yyval;
    yylloc = yyopt->yyloc;
    yyflag = yyuserAction (yyopt->yyrule, yynrhs,
                           yyrhsVals + YYMAXRHS + YYMAXLEFT - 1,
                           yystackp, yyvalp, yylocp);
    yychar = yychar_current;
    yylval = yylval_current;
    yylloc = yylloc_current;
  }
  return yyflag;
}

#if YYDEBUG
static void
yyreportTree (yySemanticOption* yyx, int yyindent)
{
  int yynrhs = yyrhsLength (yyx->yyrule);
  int yyi;
  yyGLRState* yys;
  yyGLRState* yystates[1 + YYMAXRHS];
  yyGLRState yyleftmost_state;

  for (yyi = yynrhs, yys = yyx->yystate; 0 < yyi; yyi -= 1, yys = yys->yypred)
    yystates[yyi] = yys;
  if (yys == YY_NULLPTR)
    {
      yyleftmost_state.yyposn = 0;
      yystates[0] = &yyleftmost_state;
    }
  else
    yystates[0] = yys;

  if (yyx->yystate->yyposn < yys->yyposn + 1)
    YY_FPRINTF ((stderr, "%*s%s -> <Rule %d, empty>\n",
                 yyindent, "", yysymbol_name (yylhsNonterm (yyx->yyrule)),
                 yyx->yyrule - 1));
  else
    YY_FPRINTF ((stderr, "%*s%s -> <Rule %d, tokens %ld .. %ld>\n",
                 yyindent, "", yysymbol_name (yylhsNonterm (yyx->yyrule)),
                 yyx->yyrule - 1, YY_CAST (long, yys->yyposn + 1),
                 YY_CAST (long, yyx->yystate->yyposn)));
  for (yyi = 1; yyi <= yynrhs; yyi += 1)
    {
      if (yystates[yyi]->yyresolved)
        {
          if (yystates[yyi-1]->yyposn+1 > yystates[yyi]->yyposn)
            YY_FPRINTF ((stderr, "%*s%s <empty>\n", yyindent+2, "",
                         yysymbol_name (yy_accessing_symbol (yystates[yyi]->yylrState))));
          else
            YY_FPRINTF ((stderr, "%*s%s <tokens %ld .. %ld>\n", yyindent+2, "",
                         yysymbol_name (yy_accessing_symbol (yystates[yyi]->yylrState)),
                         YY_CAST (long, yystates[yyi-1]->yyposn + 1),
                         YY_CAST (long, yystates[yyi]->yyposn)));
        }
      else
        yyreportTree (yystates[yyi]->yysemantics.yyfirstVal, yyindent+2);
    }
}
#endif

static YYRESULTTAG
yyreportAmbiguity (yySemanticOption* yyx0,
                   yySemanticOption* yyx1)
{
  YYUSE (yyx0);
  YYUSE (yyx1);

#if YYDEBUG
  YY_FPRINTF ((stderr, "Ambiguity detected.\n"));
  YY_FPRINTF ((stderr, "Option 1,\n"));
  yyreportTree (yyx0, 2);
  YY_FPRINTF ((stderr, "\nOption 2,\n"));
  yyreportTree (yyx1, 2);
  YY_FPRINTF ((stderr, "\n"));
#endif

  yyerror (YY_("syntax is ambiguous"));
  return yyabort;
}

/** Resolve the locations for each of the YYN1 states in *YYSTACKP,
 *  ending at YYS1.  Has no effect on previously resolved states.
 *  The first semantic option of a state is always chosen.  */
static void
yyresolveLocations (yyGLRState *yys1, int yyn1,
                    yyGLRStack *yystackp)
{
  if (0 < yyn1)
    {
      yyresolveLocations (yys1->yypred, yyn1 - 1, yystackp);
      if (!yys1->yyresolved)
        {
          yyGLRStackItem yyrhsloc[1 + YYMAXRHS];
          int yynrhs;
          yySemanticOption *yyoption = yys1->yysemantics.yyfirstVal;
          YY_ASSERT (yyoption);
          yynrhs = yyrhsLength (yyoption->yyrule);
          if (0 < yynrhs)
            {
              yyGLRState *yys;
              int yyn;
              yyresolveLocations (yyoption->yystate, yynrhs,
                                  yystackp);
              for (yys = yyoption->yystate, yyn = yynrhs;
                   yyn > 0;
                   yys = yys->yypred, yyn -= 1)
                yyrhsloc[yyn].yystate.yyloc = yys->yyloc;
            }
          else
            {
              /* Both yyresolveAction and yyresolveLocations traverse the GSS
                 in reverse rightmost order.  It is only necessary to invoke
                 yyresolveLocations on a subforest for which yyresolveAction
                 would have been invoked next had an ambiguity not been
                 detected.  Thus the location of the previous state (but not
                 necessarily the previous state itself) is guaranteed to be
                 resolved already.  */
              yyGLRState *yyprevious = yyoption->yystate;
              yyrhsloc[0].yystate.yyloc = yyprevious->yyloc;
            }
          YYLLOC_DEFAULT ((yys1->yyloc), yyrhsloc, yynrhs);
        }
    }
}

/** Resolve the ambiguity represented in state YYS in *YYSTACKP,
 *  perform the indicated actions, and set the semantic value of YYS.
 *  If result != yyok, the chain of semantic options in YYS has been
 *  cleared instead or it has been left unmodified except that
 *  redundant options may have been removed.  Regardless of whether
 *  result = yyok, YYS has been left with consistent data so that
 *  yydestroyGLRState can be invoked if necessary.  */
static YYRESULTTAG
yyresolveValue (yyGLRState* yys, yyGLRStack* yystackp)
{
  yySemanticOption* yyoptionList = yys->yysemantics.yyfirstVal;
  yySemanticOption* yybest = yyoptionList;
  yySemanticOption** yypp;
  yybool yymerge = yyfalse;
  YYSTYPE yysval;
  YYRESULTTAG yyflag;
  YYLTYPE *yylocp = &yys->yyloc;

  for (yypp = &yyoptionList->yynext; *yypp != YY_NULLPTR; )
    {
      yySemanticOption* yyp = *yypp;

      if (yyidenticalOptions (yybest, yyp))
        {
          yymergeOptionSets (yybest, yyp);
          *yypp = yyp->yynext;
        }
      else
        {
          switch (yypreference (yybest, yyp))
            {
            case 0:
              yyresolveLocations (yys, 1, yystackp);
              return yyreportAmbiguity (yybest, yyp);
              break;
            case 1:
              yymerge = yytrue;
              break;
            case 2:
              break;
            case 3:
              yybest = yyp;
              yymerge = yyfalse;
              break;
            default:
              /* This cannot happen so it is not worth a YY_ASSERT (yyfalse),
                 but some compilers complain if the default case is
                 omitted.  */
              break;
            }
          yypp = &yyp->yynext;
        }
    }

  if (yymerge)
    {
      yySemanticOption* yyp;
      int yyprec = yydprec[yybest->yyrule];
      yyflag = yyresolveAction (yybest, yystackp, &yysval, yylocp);
      if (yyflag == yyok)
        for (yyp = yybest->yynext; yyp != YY_NULLPTR; yyp = yyp->yynext)
          {
            if (yyprec == yydprec[yyp->yyrule])
              {
                YYSTYPE yysval_other;
                YYLTYPE yydummy;
                yyflag = yyresolveAction (yyp, yystackp, &yysval_other, &yydummy);
                if (yyflag != yyok)
                  {
                    yydestruct ("Cleanup: discarding incompletely merged value for",
                                yy_accessing_symbol (yys->yylrState),
                                &yysval, yylocp);
                    break;
                  }
                yyuserMerge (yymerger[yyp->yyrule], &yysval, &yysval_other);
              }
          }
    }
  else
    yyflag = yyresolveAction (yybest, yystackp, &yysval, yylocp);

  if (yyflag == yyok)
    {
      yys->yyresolved = yytrue;
      yys->yysemantics.yysval = yysval;
    }
  else
    yys->yysemantics.yyfirstVal = YY_NULLPTR;
  return yyflag;
}

static YYRESULTTAG
yyresolveStack (yyGLRStack* yystackp)
{
  if (yystackp->yysplitPoint != YY_NULLPTR)
    {
      yyGLRState* yys;
      int yyn;

      for (yyn = 0, yys = yystackp->yytops.yystates[0];
           yys != yystackp->yysplitPoint;
           yys = yys->yypred, yyn += 1)
        continue;
      YYCHK (yyresolveStates (yystackp->yytops.yystates[0], yyn, yystackp
                             ));
    }
  return yyok;
}

static void
yycompressStack (yyGLRStack* yystackp)
{
  yyGLRState* yyp, *yyq, *yyr;

  if (yystackp->yytops.yysize != 1 || yystackp->yysplitPoint == YY_NULLPTR)
    return;

  for (yyp = yystackp->yytops.yystates[0], yyq = yyp->yypred, yyr = YY_NULLPTR;
       yyp != yystackp->yysplitPoint;
       yyr = yyp, yyp = yyq, yyq = yyp->yypred)
    yyp->yypred = yyr;

  yystackp->yyspaceLeft += yystackp->yynextFree - yystackp->yyitems;
  yystackp->yynextFree = YY_REINTERPRET_CAST (yyGLRStackItem*, yystackp->yysplitPoint) + 1;
  yystackp->yyspaceLeft -= yystackp->yynextFree - yystackp->yyitems;
  yystackp->yysplitPoint = YY_NULLPTR;
  yystackp->yylastDeleted = YY_NULLPTR;

  while (yyr != YY_NULLPTR)
    {
      yystackp->yynextFree->yystate = *yyr;
      yyr = yyr->yypred;
      yystackp->yynextFree->yystate.yypred = &yystackp->yynextFree[-1].yystate;
      yystackp->yytops.yystates[0] = &yystackp->yynextFree->yystate;
      yystackp->yynextFree += 1;
      yystackp->yyspaceLeft -= 1;
    }
}

static YYRESULTTAG
yyprocessOneStack (yyGLRStack* yystackp, YYPTRDIFF_T yyk,
                   YYPTRDIFF_T yyposn)
{
  while (yystackp->yytops.yystates[yyk] != YY_NULLPTR)
    {
      yy_state_t yystate = yystackp->yytops.yystates[yyk]->yylrState;
      YY_DPRINTF ((stderr, "Stack %ld Entering state %d\n",
                   YY_CAST (long, yyk), yystate));

      YY_ASSERT (yystate != YYFINAL);

      if (yyisDefaultedState (yystate))
        {
          YYRESULTTAG yyflag;
          yyRuleNum yyrule = yydefaultAction (yystate);
          if (yyrule == 0)
            {
              YY_DPRINTF ((stderr, "Stack %ld dies.\n", YY_CAST (long, yyk)));
              yymarkStackDeleted (yystackp, yyk);
              return yyok;
            }
          yyflag = yyglrReduce (yystackp, yyk, yyrule, yyimmediate[yyrule]);
          if (yyflag == yyerr)
            {
              YY_DPRINTF ((stderr,
                           "Stack %ld dies "
                           "(predicate failure or explicit user error).\n",
                           YY_CAST (long, yyk)));
              yymarkStackDeleted (yystackp, yyk);
              return yyok;
            }
          if (yyflag != yyok)
            return yyflag;
        }
      else
        {
          yysymbol_kind_t yytoken = yygetToken (&yychar);
          const short* yyconflicts;
          const int yyaction = yygetLRActions (yystate, yytoken, &yyconflicts);
          yystackp->yytops.yylookaheadNeeds[yyk] = yytrue;

          for (/* nothing */; *yyconflicts; yyconflicts += 1)
            {
              YYRESULTTAG yyflag;
              YYPTRDIFF_T yynewStack = yysplitStack (yystackp, yyk);
              YY_DPRINTF ((stderr, "Splitting off stack %ld from %ld.\n",
                           YY_CAST (long, yynewStack), YY_CAST (long, yyk)));
              yyflag = yyglrReduce (yystackp, yynewStack,
                                    *yyconflicts,
                                    yyimmediate[*yyconflicts]);
              if (yyflag == yyok)
                YYCHK (yyprocessOneStack (yystackp, yynewStack,
                                          yyposn));
              else if (yyflag == yyerr)
                {
                  YY_DPRINTF ((stderr, "Stack %ld dies.\n", YY_CAST (long, yynewStack)));
                  yymarkStackDeleted (yystackp, yynewStack);
                }
              else
                return yyflag;
            }

          if (yyisShiftAction (yyaction))
            break;
          else if (yyisErrorAction (yyaction))
            {
              YY_DPRINTF ((stderr, "Stack %ld dies.\n", YY_CAST (long, yyk)));
              yymarkStackDeleted (yystackp, yyk);
              break;
            }
          else
            {
              YYRESULTTAG yyflag = yyglrReduce (yystackp, yyk, -yyaction,
                                                yyimmediate[-yyaction]);
              if (yyflag == yyerr)
                {
                  YY_DPRINTF ((stderr,
                               "Stack %ld dies "
                               "(predicate failure or explicit user error).\n",
                               YY_CAST (long, yyk)));
                  yymarkStackDeleted (yystackp, yyk);
                  break;
                }
              else if (yyflag != yyok)
                return yyflag;
            }
        }
    }
  return yyok;
}






static void
yyreportSyntaxError (yyGLRStack* yystackp)
{
  if (yystackp->yyerrState != 0)
    return;
  yyerror (YY_("syntax error"));
  yynerrs += 1;
}

/* Recover from a syntax error on *YYSTACKP, assuming that *YYSTACKP->YYTOKENP,
   yylval, and yylloc are the syntactic category, semantic value, and location
   of the lookahead.  */
static void
yyrecoverSyntaxError (yyGLRStack* yystackp)
{
  if (yystackp->yyerrState == 3)
    /* We just shifted the error token and (perhaps) took some
       reductions.  Skip tokens until we can proceed.  */
    while (yytrue)
      {
        yysymbol_kind_t yytoken;
        int yyj;
        if (yychar == YYEOF)
          yyFail (yystackp, YY_NULLPTR);
        if (yychar != YYEMPTY)
          {
            /* We throw away the lookahead, but the error range
               of the shifted error token must take it into account.  */
            yyGLRState *yys = yystackp->yytops.yystates[0];
            yyGLRStackItem yyerror_range[3];
            yyerror_range[1].yystate.yyloc = yys->yyloc;
            yyerror_range[2].yystate.yyloc = yylloc;
            YYLLOC_DEFAULT ((yys->yyloc), yyerror_range, 2);
            yytoken = YYTRANSLATE (yychar);
            yydestruct ("Error: discarding",
                        yytoken, &yylval, &yylloc);
            yychar = YYEMPTY;
          }
        yytoken = yygetToken (&yychar);
        yyj = yypact[yystackp->yytops.yystates[0]->yylrState];
        if (yypact_value_is_default (yyj))
          return;
        yyj += yytoken;
        if (yyj < 0 || YYLAST < yyj || yycheck[yyj] != yytoken)
          {
            if (yydefact[yystackp->yytops.yystates[0]->yylrState] != 0)
              return;
          }
        else if (! yytable_value_is_error (yytable[yyj]))
          return;
      }

  /* Reduce to one stack.  */
  {
    YYPTRDIFF_T yyk;
    for (yyk = 0; yyk < yystackp->yytops.yysize; yyk += 1)
      if (yystackp->yytops.yystates[yyk] != YY_NULLPTR)
        break;
    if (yyk >= yystackp->yytops.yysize)
      yyFail (yystackp, YY_NULLPTR);
    for (yyk += 1; yyk < yystackp->yytops.yysize; yyk += 1)
      yymarkStackDeleted (yystackp, yyk);
    yyremoveDeletes (yystackp);
    yycompressStack (yystackp);
  }

  /* Pop stack until we find a state that shifts the error token.  */
  yystackp->yyerrState = 3;
  while (yystackp->yytops.yystates[0] != YY_NULLPTR)
    {
      yyGLRState *yys = yystackp->yytops.yystates[0];
      int yyj = yypact[yys->yylrState];
      if (! yypact_value_is_default (yyj))
        {
          yyj += YYSYMBOL_YYerror;
          if (0 <= yyj && yyj <= YYLAST && yycheck[yyj] == YYSYMBOL_YYerror
              && yyisShiftAction (yytable[yyj]))
            {
              /* Shift the error token.  */
              int yyaction = yytable[yyj];
              /* First adjust its location.*/
              YYLTYPE yyerrloc;
              yystackp->yyerror_range[2].yystate.yyloc = yylloc;
              YYLLOC_DEFAULT (yyerrloc, (yystackp->yyerror_range), 2);
              YY_SYMBOL_PRINT ("Shifting", yy_accessing_symbol (yyaction),
                               &yylval, &yyerrloc);
              yyglrShift (yystackp, 0, yyaction,
                          yys->yyposn, &yylval, &yyerrloc);
              yys = yystackp->yytops.yystates[0];
              break;
            }
        }
      yystackp->yyerror_range[1].yystate.yyloc = yys->yyloc;
      if (yys->yypred != YY_NULLPTR)
        yydestroyGLRState ("Error: popping", yys);
      yystackp->yytops.yystates[0] = yys->yypred;
      yystackp->yynextFree -= 1;
      yystackp->yyspaceLeft += 1;
    }
  if (yystackp->yytops.yystates[0] == YY_NULLPTR)
    yyFail (yystackp, YY_NULLPTR);
}

#define YYCHK1(YYE)                                                          \
  do {                                                                       \
    switch (YYE) {                                                           \
    case yyok:                                                               \
      break;                                                                 \
    case yyabort:                                                            \
      goto yyabortlab;                                                       \
    case yyaccept:                                                           \
      goto yyacceptlab;                                                      \
    case yyerr:                                                              \
      goto yyuser_error;                                                     \
    default:                                                                 \
      goto yybuglab;                                                         \
    }                                                                        \
  } while (0)

/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
  int yyresult;
  yyGLRStack yystack;
  yyGLRStack* const yystackp = &yystack;
  YYPTRDIFF_T yyposn;

  YY_DPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY;
  yylval = yyval_default;
  yylloc = yyloc_default;

  if (! yyinitGLRStack (yystackp, YYINITDEPTH))
    goto yyexhaustedlab;
  switch (YYSETJMP (yystack.yyexception_buffer))
    {
    case 0: break;
    case 1: goto yyabortlab;
    case 2: goto yyexhaustedlab;
    default: goto yybuglab;
    }
  yyglrShift (&yystack, 0, 0, 0, &yylval, &yylloc);
  yyposn = 0;

  while (yytrue)
    {
      /* For efficiency, we have two loops, the first of which is
         specialized to deterministic operation (single stack, no
         potential ambiguity).  */
      /* Standard mode. */
      while (yytrue)
        {
          yy_state_t yystate = yystack.yytops.yystates[0]->yylrState;
          YY_DPRINTF ((stderr, "Entering state %d\n", yystate));
          if (yystate == YYFINAL)
            goto yyacceptlab;
          if (yyisDefaultedState (yystate))
            {
              yyRuleNum yyrule = yydefaultAction (yystate);
              if (yyrule == 0)
                {
                  yystack.yyerror_range[1].yystate.yyloc = yylloc;
                  yyreportSyntaxError (&yystack);
                  goto yyuser_error;
                }
              YYCHK1 (yyglrReduce (&yystack, 0, yyrule, yytrue));
            }
          else
            {
              yysymbol_kind_t yytoken = yygetToken (&yychar);
              const short* yyconflicts;
              int yyaction = yygetLRActions (yystate, yytoken, &yyconflicts);
              if (*yyconflicts)
                /* Enter nondeterministic mode.  */
                break;
              if (yyisShiftAction (yyaction))
                {
                  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
                  yychar = YYEMPTY;
                  yyposn += 1;
                  yyglrShift (&yystack, 0, yyaction, yyposn, &yylval, &yylloc);
                  if (0 < yystack.yyerrState)
                    yystack.yyerrState -= 1;
                }
              else if (yyisErrorAction (yyaction))
                {
                  yystack.yyerror_range[1].yystate.yyloc = yylloc;
                  /* Issue an error message unless the scanner already
                     did. */
                  if (yychar != YYerror)
                    yyreportSyntaxError (&yystack);
                  goto yyuser_error;
                }
              else
                YYCHK1 (yyglrReduce (&yystack, 0, -yyaction, yytrue));
            }
        }

      /* Nondeterministic mode. */
      while (yytrue)
        {
          yysymbol_kind_t yytoken_to_shift;
          YYPTRDIFF_T yys;

          for (yys = 0; yys < yystack.yytops.yysize; yys += 1)
            yystackp->yytops.yylookaheadNeeds[yys] = yychar != YYEMPTY;

          /* yyprocessOneStack returns one of three things:

              - An error flag.  If the caller is yyprocessOneStack, it
                immediately returns as well.  When the caller is finally
                yyparse, it jumps to an error label via YYCHK1.

              - yyok, but yyprocessOneStack has invoked yymarkStackDeleted
                (&yystack, yys), which sets the top state of yys to NULL.  Thus,
                yyparse's following invocation of yyremoveDeletes will remove
                the stack.

              - yyok, when ready to shift a token.

             Except in the first case, yyparse will invoke yyremoveDeletes and
             then shift the next token onto all remaining stacks.  This
             synchronization of the shift (that is, after all preceding
             reductions on all stacks) helps prevent double destructor calls
             on yylval in the event of memory exhaustion.  */

          for (yys = 0; yys < yystack.yytops.yysize; yys += 1)
            YYCHK1 (yyprocessOneStack (&yystack, yys, yyposn));
          yyremoveDeletes (&yystack);
          if (yystack.yytops.yysize == 0)
            {
              yyundeleteLastStack (&yystack);
              if (yystack.yytops.yysize == 0)
                yyFail (&yystack, YY_("syntax error"));
              YYCHK1 (yyresolveStack (&yystack));
              YY_DPRINTF ((stderr, "Returning to deterministic operation.\n"));
              yystack.yyerror_range[1].yystate.yyloc = yylloc;
              yyreportSyntaxError (&yystack);
              goto yyuser_error;
            }

          /* If any yyglrShift call fails, it will fail after shifting.  Thus,
             a copy of yylval will already be on stack 0 in the event of a
             failure in the following loop.  Thus, yychar is set to YYEMPTY
             before the loop to make sure the user destructor for yylval isn't
             called twice.  */
          yytoken_to_shift = YYTRANSLATE (yychar);
          yychar = YYEMPTY;
          yyposn += 1;
          for (yys = 0; yys < yystack.yytops.yysize; yys += 1)
            {
              yy_state_t yystate = yystack.yytops.yystates[yys]->yylrState;
              const short* yyconflicts;
              int yyaction = yygetLRActions (yystate, yytoken_to_shift,
                              &yyconflicts);
              /* Note that yyconflicts were handled by yyprocessOneStack.  */
              YY_DPRINTF ((stderr, "On stack %ld, ", YY_CAST (long, yys)));
              YY_SYMBOL_PRINT ("shifting", yytoken_to_shift, &yylval, &yylloc);
              yyglrShift (&yystack, yys, yyaction, yyposn,
                          &yylval, &yylloc);
              YY_DPRINTF ((stderr, "Stack %ld now in state #%d\n",
                           YY_CAST (long, yys),
                           yystack.yytops.yystates[yys]->yylrState));
            }

          if (yystack.yytops.yysize == 1)
            {
              YYCHK1 (yyresolveStack (&yystack));
              YY_DPRINTF ((stderr, "Returning to deterministic operation.\n"));
              yycompressStack (&yystack);
              break;
            }
        }
      continue;
    yyuser_error:
      yyrecoverSyntaxError (&yystack);
      yyposn = yystack.yytops.yystates[0]->yyposn;
    }

 yyacceptlab:
  yyresult = 0;
  goto yyreturn;

 yybuglab:
  YY_ASSERT (yyfalse);
  goto yyabortlab;

 yyabortlab:
  yyresult = 1;
  goto yyreturn;

 yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturn;

 yyreturn:
  if (yychar != YYEMPTY)
    yydestruct ("Cleanup: discarding lookahead",
                YYTRANSLATE (yychar), &yylval, &yylloc);

  /* If the stack is well-formed, pop the stack until it is empty,
     destroying its entries as we go.  But free the stack regardless
     of whether it is well-formed.  */
  if (yystack.yyitems)
    {
      yyGLRState** yystates = yystack.yytops.yystates;
      if (yystates)
        {
          YYPTRDIFF_T yysize = yystack.yytops.yysize;
          YYPTRDIFF_T yyk;
          for (yyk = 0; yyk < yysize; yyk += 1)
            if (yystates[yyk])
              {
                while (yystates[yyk])
                  {
                    yyGLRState *yys = yystates[yyk];
                    yystack.yyerror_range[1].yystate.yyloc = yys->yyloc;
                    if (yys->yypred != YY_NULLPTR)
                      yydestroyGLRState ("Cleanup: popping", yys);
                    yystates[yyk] = yys->yypred;
                    yystack.yynextFree -= 1;
                    yystack.yyspaceLeft += 1;
                  }
                break;
              }
        }
      yyfreeGLRStack (&yystack);
    }

  return yyresult;
}

/* DEBUGGING ONLY */
#if YYDEBUG
static void
yy_yypstack (yyGLRState* yys)
{
  if (yys->yypred)
    {
      yy_yypstack (yys->yypred);
      YY_FPRINTF ((stderr, " -> "));
    }
  YY_FPRINTF ((stderr, "%d@%ld", yys->yylrState, YY_CAST (long, yys->yyposn)));
}

static void
yypstates (yyGLRState* yyst)
{
  if (yyst == YY_NULLPTR)
    YY_FPRINTF ((stderr, "<null>"));
  else
    yy_yypstack (yyst);
  YY_FPRINTF ((stderr, "\n"));
}

static void
yypstack (yyGLRStack* yystackp, YYPTRDIFF_T yyk)
{
  yypstates (yystackp->yytops.yystates[yyk]);
}

static void
yypdumpstack (yyGLRStack* yystackp)
{
#define YYINDEX(YYX)                                                    \
  YY_CAST (long,                                                        \
           ((YYX)                                                       \
            ? YY_REINTERPRET_CAST (yyGLRStackItem*, (YYX)) - yystackp->yyitems \
            : -1))

  yyGLRStackItem* yyp;
  for (yyp = yystackp->yyitems; yyp < yystackp->yynextFree; yyp += 1)
    {
      YY_FPRINTF ((stderr, "%3ld. ",
                   YY_CAST (long, yyp - yystackp->yyitems)));
      if (*YY_REINTERPRET_CAST (yybool *, yyp))
        {
          YY_ASSERT (yyp->yystate.yyisState);
          YY_ASSERT (yyp->yyoption.yyisState);
          YY_FPRINTF ((stderr, "Res: %d, LR State: %d, posn: %ld, pred: %ld",
                       yyp->yystate.yyresolved, yyp->yystate.yylrState,
                       YY_CAST (long, yyp->yystate.yyposn),
                       YYINDEX (yyp->yystate.yypred)));
          if (! yyp->yystate.yyresolved)
            YY_FPRINTF ((stderr, ", firstVal: %ld",
                         YYINDEX (yyp->yystate.yysemantics.yyfirstVal)));
        }
      else
        {
          YY_ASSERT (!yyp->yystate.yyisState);
          YY_ASSERT (!yyp->yyoption.yyisState);
          YY_FPRINTF ((stderr, "Option. rule: %d, state: %ld, next: %ld",
                       yyp->yyoption.yyrule - 1,
                       YYINDEX (yyp->yyoption.yystate),
                       YYINDEX (yyp->yyoption.yynext)));
        }
      YY_FPRINTF ((stderr, "\n"));
    }

  YY_FPRINTF ((stderr, "Tops:"));
  {
    YYPTRDIFF_T yyi;
    for (yyi = 0; yyi < yystackp->yytops.yysize; yyi += 1)
      YY_FPRINTF ((stderr, "%ld: %ld; ", YY_CAST (long, yyi),
                   YYINDEX (yystackp->yytops.yystates[yyi])));
    YY_FPRINTF ((stderr, "\n"));
  }
#undef YYINDEX
}
#endif

#undef yylval
#undef yychar
#undef yynerrs
#undef yylloc




#line 780 "src/parser.ypp"

