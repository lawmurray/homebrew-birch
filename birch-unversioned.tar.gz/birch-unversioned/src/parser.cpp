/* A Bison parser, made by GNU Bison 3.7.4.  */

/* Skeleton implementation for Bison GLR parsers in C

   Copyright (C) 2002-2015, 2018-2020 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C GLR parser skeleton written by Paul Hilfinger.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30704

/* Bison version string.  */
#define YYBISON_VERSION "3.7.4"

/* Skeleton name.  */
#define YYSKELETON_NAME "glr.c"

/* Pure parsers.  */
#define YYPURE 0







# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "src/parser.hpp"

/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_PROGRAM = 3,                    /* PROGRAM  */
  YYSYMBOL_CLASS = 4,                      /* CLASS  */
  YYSYMBOL_TYPE = 5,                       /* TYPE  */
  YYSYMBOL_FUNCTION = 6,                   /* FUNCTION  */
  YYSYMBOL_OPERATOR = 7,                   /* OPERATOR  */
  YYSYMBOL_AUTO = 8,                       /* AUTO  */
  YYSYMBOL_LET = 9,                        /* LET  */
  YYSYMBOL_IF = 10,                        /* IF  */
  YYSYMBOL_ELSE = 11,                      /* ELSE  */
  YYSYMBOL_FOR = 12,                       /* FOR  */
  YYSYMBOL_IN = 13,                        /* IN  */
  YYSYMBOL_WHILE = 14,                     /* WHILE  */
  YYSYMBOL_DO = 15,                        /* DO  */
  YYSYMBOL_WITH = 16,                      /* WITH  */
  YYSYMBOL_ASSERT = 17,                    /* ASSERT  */
  YYSYMBOL_RETURN = 18,                    /* RETURN  */
  YYSYMBOL_FACTOR = 19,                    /* FACTOR  */
  YYSYMBOL_CPP = 20,                       /* CPP  */
  YYSYMBOL_HPP = 21,                       /* HPP  */
  YYSYMBOL_THIS = 22,                      /* THIS  */
  YYSYMBOL_SUPER = 23,                     /* SUPER  */
  YYSYMBOL_GLOBAL = 24,                    /* GLOBAL  */
  YYSYMBOL_PARALLEL = 25,                  /* PARALLEL  */
  YYSYMBOL_DYNAMIC = 26,                   /* DYNAMIC  */
  YYSYMBOL_ABSTRACT = 27,                  /* ABSTRACT  */
  YYSYMBOL_OVERRIDE = 28,                  /* OVERRIDE  */
  YYSYMBOL_FINAL = 29,                     /* FINAL  */
  YYSYMBOL_ACYCLIC = 30,                   /* ACYCLIC  */
  YYSYMBOL_NIL = 31,                       /* NIL  */
  YYSYMBOL_DOUBLE_BRACE_OPEN = 32,         /* DOUBLE_BRACE_OPEN  */
  YYSYMBOL_DOUBLE_BRACE_CLOSE = 33,        /* DOUBLE_BRACE_CLOSE  */
  YYSYMBOL_NAME = 34,                      /* NAME  */
  YYSYMBOL_BOOL_LITERAL = 35,              /* BOOL_LITERAL  */
  YYSYMBOL_INT_LITERAL = 36,               /* INT_LITERAL  */
  YYSYMBOL_REAL_LITERAL = 37,              /* REAL_LITERAL  */
  YYSYMBOL_STRING_LITERAL = 38,            /* STRING_LITERAL  */
  YYSYMBOL_LEFT_OP = 39,                   /* LEFT_OP  */
  YYSYMBOL_RIGHT_OP = 40,                  /* RIGHT_OP  */
  YYSYMBOL_LEFT_TILDE_OP = 41,             /* LEFT_TILDE_OP  */
  YYSYMBOL_RIGHT_TILDE_OP = 42,            /* RIGHT_TILDE_OP  */
  YYSYMBOL_LEFT_QUERY_OP = 43,             /* LEFT_QUERY_OP  */
  YYSYMBOL_AND_OP = 44,                    /* AND_OP  */
  YYSYMBOL_OR_OP = 45,                     /* OR_OP  */
  YYSYMBOL_LE_OP = 46,                     /* LE_OP  */
  YYSYMBOL_GE_OP = 47,                     /* GE_OP  */
  YYSYMBOL_EQ_OP = 48,                     /* EQ_OP  */
  YYSYMBOL_NE_OP = 49,                     /* NE_OP  */
  YYSYMBOL_RANGE_OP = 50,                  /* RANGE_OP  */
  YYSYMBOL_51_ = 51,                       /* '('  */
  YYSYMBOL_52_ = 52,                       /* ')'  */
  YYSYMBOL_53_ = 53,                       /* '['  */
  YYSYMBOL_54_ = 54,                       /* ']'  */
  YYSYMBOL_55_ = 55,                       /* '?'  */
  YYSYMBOL_56_ = 56,                       /* '\\'  */
  YYSYMBOL_57_ = 57,                       /* ','  */
  YYSYMBOL_58_ = 58,                       /* '.'  */
  YYSYMBOL_59_ = 59,                       /* '!'  */
  YYSYMBOL_60_ = 60,                       /* '+'  */
  YYSYMBOL_61_ = 61,                       /* '-'  */
  YYSYMBOL_62_ = 62,                       /* '*'  */
  YYSYMBOL_63_ = 63,                       /* '/'  */
  YYSYMBOL_64_ = 64,                       /* '<'  */
  YYSYMBOL_65_ = 65,                       /* '>'  */
  YYSYMBOL_66_ = 66,                       /* '~'  */
  YYSYMBOL_67_ = 67,                       /* ':'  */
  YYSYMBOL_68___ = 68,                     /* '_'  */
  YYSYMBOL_69_ = 69,                       /* ';'  */
  YYSYMBOL_70_ = 70,                       /* '='  */
  YYSYMBOL_71_ = 71,                       /* '{'  */
  YYSYMBOL_72_ = 72,                       /* '}'  */
  YYSYMBOL_73_ = 73,                       /* '&'  */
  YYSYMBOL_YYACCEPT = 74,                  /* $accept  */
  YYSYMBOL_name = 75,                      /* name  */
  YYSYMBOL_bool_literal = 76,              /* bool_literal  */
  YYSYMBOL_int_literal = 77,               /* int_literal  */
  YYSYMBOL_real_literal = 78,              /* real_literal  */
  YYSYMBOL_string_literal = 79,            /* string_literal  */
  YYSYMBOL_literal = 80,                   /* literal  */
  YYSYMBOL_identifier = 81,                /* identifier  */
  YYSYMBOL_parens_expression = 82,         /* parens_expression  */
  YYSYMBOL_sequence_expression = 83,       /* sequence_expression  */
  YYSYMBOL_cast_expression = 84,           /* cast_expression  */
  YYSYMBOL_function_expression = 85,       /* function_expression  */
  YYSYMBOL_this_expression = 86,           /* this_expression  */
  YYSYMBOL_super_expression = 87,          /* super_expression  */
  YYSYMBOL_nil_expression = 88,            /* nil_expression  */
  YYSYMBOL_primary_expression = 89,        /* primary_expression  */
  YYSYMBOL_slice_expression = 90,          /* slice_expression  */
  YYSYMBOL_slice_expression_list = 91,     /* slice_expression_list  */
  YYSYMBOL_slice = 92,                     /* slice  */
  YYSYMBOL_postfix_expression = 93,        /* postfix_expression  */
  YYSYMBOL_query_expression = 94,          /* query_expression  */
  YYSYMBOL_prefix_operator = 95,           /* prefix_operator  */
  YYSYMBOL_prefix_expression = 96,         /* prefix_expression  */
  YYSYMBOL_multiplicative_operator = 97,   /* multiplicative_operator  */
  YYSYMBOL_multiplicative_expression = 98, /* multiplicative_expression  */
  YYSYMBOL_additive_operator = 99,         /* additive_operator  */
  YYSYMBOL_additive_expression = 100,      /* additive_expression  */
  YYSYMBOL_relational_operator = 101,      /* relational_operator  */
  YYSYMBOL_relational_expression = 102,    /* relational_expression  */
  YYSYMBOL_equality_operator = 103,        /* equality_operator  */
  YYSYMBOL_equality_expression = 104,      /* equality_expression  */
  YYSYMBOL_logical_and_operator = 105,     /* logical_and_operator  */
  YYSYMBOL_logical_and_expression = 106,   /* logical_and_expression  */
  YYSYMBOL_logical_or_operator = 107,      /* logical_or_operator  */
  YYSYMBOL_logical_or_expression = 108,    /* logical_or_expression  */
  YYSYMBOL_assign_operator = 109,          /* assign_operator  */
  YYSYMBOL_assign_expression = 110,        /* assign_expression  */
  YYSYMBOL_expression = 111,               /* expression  */
  YYSYMBOL_optional_expression = 112,      /* optional_expression  */
  YYSYMBOL_expression_list = 113,          /* expression_list  */
  YYSYMBOL_span_expression = 114,          /* span_expression  */
  YYSYMBOL_span_list = 115,                /* span_list  */
  YYSYMBOL_brackets = 116,                 /* brackets  */
  YYSYMBOL_parameters = 117,               /* parameters  */
  YYSYMBOL_optional_parameters = 118,      /* optional_parameters  */
  YYSYMBOL_parameter_list = 119,           /* parameter_list  */
  YYSYMBOL_parameter = 120,                /* parameter  */
  YYSYMBOL_options = 121,                  /* options  */
  YYSYMBOL_option_list = 122,              /* option_list  */
  YYSYMBOL_option = 123,                   /* option  */
  YYSYMBOL_arguments = 124,                /* arguments  */
  YYSYMBOL_optional_arguments = 125,       /* optional_arguments  */
  YYSYMBOL_shape = 126,                    /* shape  */
  YYSYMBOL_generics = 127,                 /* generics  */
  YYSYMBOL_generic_list = 128,             /* generic_list  */
  YYSYMBOL_generic = 129,                  /* generic  */
  YYSYMBOL_optional_generics = 130,        /* optional_generics  */
  YYSYMBOL_generic_arguments = 131,        /* generic_arguments  */
  YYSYMBOL_generic_argument_list = 132,    /* generic_argument_list  */
  YYSYMBOL_generic_argument = 133,         /* generic_argument  */
  YYSYMBOL_optional_generic_arguments = 134, /* optional_generic_arguments  */
  YYSYMBOL_init_operator = 135,            /* init_operator  */
  YYSYMBOL_global_variable_declaration = 136, /* global_variable_declaration  */
  YYSYMBOL_member_variable_declaration = 137, /* member_variable_declaration  */
  YYSYMBOL_local_variable_declaration = 138, /* local_variable_declaration  */
  YYSYMBOL_function_declaration = 139,     /* function_declaration  */
  YYSYMBOL_140_1 = 140,                    /* $@1  */
  YYSYMBOL_member_function_annotation = 141, /* member_function_annotation  */
  YYSYMBOL_member_function_declaration = 142, /* member_function_declaration  */
  YYSYMBOL_143_2 = 143,                    /* $@2  */
  YYSYMBOL_144_3 = 144,                    /* $@3  */
  YYSYMBOL_program_declaration = 145,      /* program_declaration  */
  YYSYMBOL_146_4 = 146,                    /* $@4  */
  YYSYMBOL_binary_operator = 147,          /* binary_operator  */
  YYSYMBOL_unary_operator = 148,           /* unary_operator  */
  YYSYMBOL_binary_operator_declaration = 149, /* binary_operator_declaration  */
  YYSYMBOL_150_5 = 150,                    /* $@5  */
  YYSYMBOL_unary_operator_declaration = 151, /* unary_operator_declaration  */
  YYSYMBOL_152_6 = 152,                    /* $@6  */
  YYSYMBOL_assignment_operator_declaration = 153, /* assignment_operator_declaration  */
  YYSYMBOL_154_7 = 154,                    /* $@7  */
  YYSYMBOL_conversion_operator_declaration = 155, /* conversion_operator_declaration  */
  YYSYMBOL_156_8 = 156,                    /* $@8  */
  YYSYMBOL_slice_operator_declaration = 157, /* slice_operator_declaration  */
  YYSYMBOL_158_9 = 158,                    /* $@9  */
  YYSYMBOL_class_annotation = 159,         /* class_annotation  */
  YYSYMBOL_class_declaration = 160,        /* class_declaration  */
  YYSYMBOL_161_10 = 161,                   /* $@10  */
  YYSYMBOL_162_11 = 162,                   /* $@11  */
  YYSYMBOL_163_12 = 163,                   /* $@12  */
  YYSYMBOL_basic_declaration = 164,        /* basic_declaration  */
  YYSYMBOL_cpp = 165,                      /* cpp  */
  YYSYMBOL_hpp = 166,                      /* hpp  */
  YYSYMBOL_expression_statement = 167,     /* expression_statement  */
  YYSYMBOL_if = 168,                       /* if  */
  YYSYMBOL_for_variable_declaration = 169, /* for_variable_declaration  */
  YYSYMBOL_for = 170,                      /* for  */
  YYSYMBOL_parallel_annotation = 171,      /* parallel_annotation  */
  YYSYMBOL_parallel = 172,                 /* parallel  */
  YYSYMBOL_while = 173,                    /* while  */
  YYSYMBOL_do_while = 174,                 /* do_while  */
  YYSYMBOL_with = 175,                     /* with  */
  YYSYMBOL_block = 176,                    /* block  */
  YYSYMBOL_assertion = 177,                /* assertion  */
  YYSYMBOL_return = 178,                   /* return  */
  YYSYMBOL_factor = 179,                   /* factor  */
  YYSYMBOL_statement = 180,                /* statement  */
  YYSYMBOL_statements = 181,               /* statements  */
  YYSYMBOL_optional_statements = 182,      /* optional_statements  */
  YYSYMBOL_class_statement = 183,          /* class_statement  */
  YYSYMBOL_class_statements = 184,         /* class_statements  */
  YYSYMBOL_optional_class_statements = 185, /* optional_class_statements  */
  YYSYMBOL_file_statement = 186,           /* file_statement  */
  YYSYMBOL_file_statements = 187,          /* file_statements  */
  YYSYMBOL_optional_file_statements = 188, /* optional_file_statements  */
  YYSYMBOL_file = 189,                     /* file  */
  YYSYMBOL_return_type = 190,              /* return_type  */
  YYSYMBOL_optional_return_type = 191,     /* optional_return_type  */
  YYSYMBOL_braces = 192,                   /* braces  */
  YYSYMBOL_optional_braces = 193,          /* optional_braces  */
  YYSYMBOL_class_braces = 194,             /* class_braces  */
  YYSYMBOL_optional_class_braces = 195,    /* optional_class_braces  */
  YYSYMBOL_double_braces = 196,            /* double_braces  */
  YYSYMBOL_named_type = 197,               /* named_type  */
  YYSYMBOL_primary_type = 198,             /* primary_type  */
  YYSYMBOL_type = 199,                     /* type  */
  YYSYMBOL_type_list = 200,                /* type_list  */
  YYSYMBOL_optional_type_list = 201        /* optional_type_list  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;


/* Default (constant) value used for initialization for null
   right-hand sides.  Unlike the standard yacc.c template, here we set
   the default value of $$ to a zeroed-out value.  Since the default
   value is undefined, this behavior is technically correct.  */
static YYSTYPE yyval_default;
static YYLTYPE yyloc_default
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
  = { 1, 1, 1, 1 }
# endif
;


/* Unqualified %code blocks.  */
#line 6 "src/parser.ypp"

  #include "src/expression/all.hpp"
  #include "src/statement/all.hpp"
  #include "src/type/all.hpp"

  /**
   * Raw string stack.
   */
  std::stack<std::string> raws;

  /**
   * Push the current raw string onto the stack, and restart it.
   */
  void push_raw() {
    raws.push(raw.str());
    raw.str("");
  }

  /**
   * Pop a raw string from the stack.
   */
  std::string pop_raw() {
    std::string raw = raws.top();
    raws.pop();
    return raw;
  }

  /**
   * Make a location, without documentation string.
   */
  birch::Location* make_loc(YYLTYPE& loc) {
    return new birch::Location(compiler->file, loc.first_line, loc.last_line,
        loc.first_column, loc.last_column);
  }

  /**
   * Make a location, with documentation string.
   */
  birch::Location* make_doc_loc(YYLTYPE& loc) {
    return new birch::Location(compiler->file, loc.first_line, loc.last_line,
        loc.first_column, loc.last_column, pop_raw());
  }

  /**
   * Make an empty name.
   */
  birch::Name* empty_name(YYLTYPE& loc) {
    return new birch::Name();
  }

  /**
   * Make an empty expression.
   */
  birch::Expression* empty_expr(YYLTYPE& loc) {
    return new birch::EmptyExpression(make_loc(loc));
  }

  /**
   * Make an empty statement.
   */
  birch::Statement* empty_stmt(YYLTYPE& loc) {
    return new birch::EmptyStatement(make_loc(loc));
  }

  /**
   * Make an empty type.
   */
  birch::Type* empty_type(YYLTYPE& loc) {
    return new birch::EmptyType(make_loc(loc));
  }

#line 376 "src/parser.cpp"

#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif
#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YYFREE
# define YYFREE free
#endif
#ifndef YYMALLOC
# define YYMALLOC malloc
#endif
#ifndef YYREALLOC
# define YYREALLOC realloc
#endif

#ifdef __cplusplus
  typedef bool yybool;
# define yytrue true
# define yyfalse false
#else
  /* When we move to stdbool, get rid of the various casts to yybool.  */
  typedef signed char yybool;
# define yytrue 1
# define yyfalse 0
#endif

#ifndef YYSETJMP
# include <setjmp.h>
# define YYJMP_BUF jmp_buf
# define YYSETJMP(Env) setjmp (Env)
/* Pacify Clang and ICC.  */
# define YYLONGJMP(Env, Val)                    \
 do {                                           \
   longjmp (Env, Val);                          \
   YY_ASSERT (0);                               \
 } while (yyfalse)
#endif

#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* The _Noreturn keyword of C11.  */
#ifndef _Noreturn
# if (defined __cplusplus \
      && ((201103 <= __cplusplus && !(__GNUC__ == 4 && __GNUC_MINOR__ == 7)) \
          || (defined _MSC_VER && 1900 <= _MSC_VER)))
#  define _Noreturn [[noreturn]]
# elif (!defined __cplusplus                     \
        && (201112 <= (defined __STDC_VERSION__ ? __STDC_VERSION__ : 0)  \
            || 4 < __GNUC__ + (7 <= __GNUC_MINOR__) \
            || (defined __apple_build_version__ \
                ? 6000000 <= __apple_build_version__ \
                : 3 < __clang_major__ + (5 <= __clang_minor__))))
   /* _Noreturn works as-is.  */
# elif 2 < __GNUC__ + (8 <= __GNUC_MINOR__) || 0x5110 <= __SUNPRO_C
#  define _Noreturn __attribute__ ((__noreturn__))
# elif 1200 <= (defined _MSC_VER ? _MSC_VER : 0)
#  define _Noreturn __declspec (noreturn)
# else
#  define _Noreturn
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(E) ((void) (E))
#else
# define YYUSE(E) /* empty */
#endif

#if defined __GNUC__ && ! defined __ICC && 407 <= __GNUC__ * 100 + __GNUC_MINOR__
/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                            \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  36
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   508

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  74
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  128
/* YYNRULES -- Number of rules.  */
#define YYNRULES  262
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  451
/* YYMAXRHS -- Maximum number of symbols on right-hand side of rule.  */
#define YYMAXRHS 10
/* YYMAXLEFT -- Maximum number of symbols to the left of a handle
   accessed by $0, $-1, etc., in any rule.  */
#define YYMAXLEFT 0

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   305

/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    59,     2,     2,     2,     2,    73,     2,
      51,    52,    62,    60,    57,    61,    58,    63,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    67,    69,
      64,    70,    65,    55,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    53,    56,    54,     2,    68,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    71,     2,    72,    66,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50
};

#if YYDEBUG
/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   164,   164,   173,   177,   181,   185,   189,   190,   191,
     192,   196,   200,   204,   208,   212,   216,   220,   224,   228,
     229,   230,   231,   232,   233,   234,   235,   239,   240,   244,
     245,   249,   253,   254,   255,   256,   257,   258,   259,   265,
     266,   270,   271,   272,   276,   277,   281,   282,   286,   287,
     291,   292,   296,   297,   301,   302,   303,   304,   313,   314,
     318,   319,   323,   324,   328,   332,   333,   337,   341,   342,
     346,   347,   348,   349,   350,   354,   355,   359,   363,   364,
     368,   369,   373,   377,   378,   382,   386,   387,   391,   392,
     396,   397,   401,   405,   406,   410,   411,   415,   416,   420,
     421,   425,   426,   430,   431,   435,   436,   440,   441,   445,
     449,   450,   454,   455,   459,   460,   464,   468,   469,   478,
     479,   480,   484,   485,   486,   487,   488,   492,   493,   494,
     495,   496,   500,   501,   502,   503,   504,   505,   506,   510,
     510,   514,   515,   516,   517,   523,   523,   524,   524,   528,
     528,   532,   533,   534,   535,   536,   537,   541,   545,   545,
     549,   549,   553,   553,   557,   557,   561,   561,   565,   566,
     567,   568,   572,   572,   573,   573,   574,   574,   578,   579,
     580,   584,   588,   592,   596,   597,   598,   602,   606,   610,
     616,   617,   621,   625,   629,   633,   637,   641,   645,   649,
     650,   651,   652,   653,   654,   655,   656,   657,   658,   659,
     660,   661,   665,   666,   670,   671,   675,   676,   677,   678,
     679,   680,   684,   685,   689,   690,   694,   695,   696,   697,
     698,   699,   700,   701,   702,   706,   707,   711,   712,   716,
     720,   724,   725,   729,   733,   734,   738,   742,   743,   747,
     756,   757,   761,   762,   766,   767,   768,   769,   770,   774,
     775,   779,   780
};
#endif

#define YYPACT_NINF (-331)
#define YYTABLE_NINF (-239)

  /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
     STATE-NUM.  */
static const yytype_int16 yypact[] =
{
     138,     2,     2,     2,     4,    47,    47,  -331,  -331,  -331,
    -331,    36,  -331,  -331,  -331,  -331,  -331,    90,  -331,  -331,
    -331,  -331,   258,  -331,  -331,   119,    79,    41,    71,    93,
     106,  -331,  -331,    12,     2,  -331,  -331,     6,  -331,     2,
    -331,     2,     9,  -331,    96,  -331,  -331,  -331,    84,  -331,
     443,     2,  -331,    12,   109,    99,   112,  -331,    95,   121,
    -331,   126,   134,   137,     7,   139,   146,  -331,  -331,   142,
     162,    10,   190,    12,  -331,  -331,  -331,  -331,  -331,  -331,
    -331,  -331,  -331,  -331,  -331,  -331,  -331,  -331,  -331,  -331,
    -331,  -331,     2,   177,   198,   182,    12,     1,  -331,   163,
       2,  -331,  -331,   425,   153,  -331,  -331,  -331,    -4,   172,
     314,   -21,    12,  -331,     2,  -331,   384,  -331,  -331,  -331,
    -331,  -331,     2,  -331,   191,   199,    12,  -331,  -331,    -5,
     194,   190,   192,    12,  -331,  -331,   205,  -331,   201,   214,
      -5,  -331,  -331,  -331,  -331,   215,  -331,  -331,  -331,  -331,
    -331,   314,  -331,   314,    96,   216,  -331,  -331,  -331,  -331,
    -331,  -331,  -331,  -331,  -331,  -331,  -331,   225,  -331,  -331,
     169,  -331,   314,  -331,    94,    25,   256,   125,   242,   160,
    -331,   234,   241,   240,  -331,   247,   245,   246,  -331,   237,
    -331,   238,     2,  -331,   250,    60,  -331,     2,     2,   314,
       2,   314,   239,   314,   314,   314,   314,   299,  -331,    23,
     248,  -331,  -331,  -331,  -331,  -331,   291,  -331,  -331,  -331,
    -331,  -331,  -331,  -331,  -331,   384,  -331,   251,  -331,  -331,
    -331,     2,    87,     7,   190,  -331,  -331,   190,  -331,    12,
       2,   267,   268,   190,   271,     2,   314,  -331,     2,  -331,
    -331,  -331,  -331,   314,   314,   314,   314,   314,  -331,  -331,
    -331,  -331,  -331,   314,   314,   314,  -331,   192,   314,  -331,
    -331,  -331,  -331,  -331,     2,   111,   314,    15,    15,   239,
    -331,   317,   239,   313,   239,   266,  -331,   277,   278,     2,
      12,  -331,   328,  -331,  -331,  -331,  -331,  -331,     7,  -331,
    -331,   293,  -331,  -331,  -331,     7,   304,  -331,   302,   309,
     318,  -331,  -331,    94,    25,   256,   125,   242,  -331,  -331,
    -331,  -331,   295,   320,  -331,   189,  -331,  -331,  -331,   314,
     314,   365,   314,  -331,   314,  -331,  -331,  -331,  -331,   364,
     243,     2,     7,  -331,  -331,  -331,   314,   314,  -331,   314,
    -331,  -331,  -331,     2,    78,  -331,  -331,   350,   312,  -331,
     374,  -331,  -331,  -331,  -331,  -331,   189,  -331,   310,   315,
     316,    22,   331,   319,   314,  -331,     8,   326,   314,   370,
    -331,   337,  -331,  -331,   111,    71,     2,     2,  -331,  -331,
      12,     2,  -331,  -331,  -331,  -331,  -331,  -331,   314,  -331,
     347,  -331,   336,  -331,   342,   314,  -331,  -331,    96,  -331,
     358,     7,   303,    71,   239,   314,  -331,  -331,   363,   190,
       7,   190,  -331,  -331,    13,   345,   314,    96,  -331,   239,
     314,  -331,  -331,  -331,  -331,   348,  -331,   354,   190,  -331,
     239,     7,     7,  -331,  -331,  -331,  -331,  -331,  -331,     7,
    -331
};

  /* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
     Performed when YYTABLE does not specify something else to do.  Zero
     means the default is an error.  */
static const yytype_int16 yydefact[] =
{
     171,     0,     0,     0,     0,     0,     0,   168,   169,   170,
       2,     0,   226,   227,   228,   229,   230,     0,   231,   232,
     233,   234,   171,   237,   239,     0,     0,     0,   111,     0,
       0,   181,   182,     0,     0,   236,     1,     0,   149,     0,
     180,     0,     0,   110,     0,    43,    41,    42,     0,   157,
       0,     0,   249,     0,     0,   118,   252,   254,     0,   111,
      93,     0,     0,    95,     0,     0,     0,   105,   109,     0,
     107,     0,   242,     0,    64,    67,    56,    57,    60,    61,
      50,    51,    46,    47,    54,    55,   151,   152,   153,   154,
     155,   156,     0,     0,   259,     0,   262,     0,   117,   250,
       0,   119,   120,     0,     0,   255,   121,   122,     0,     0,
       0,    89,     0,    94,     0,   245,   215,   244,   150,   178,
     179,   106,     0,    86,     0,    90,     0,   241,   139,    92,
       0,   242,     0,     0,   253,   261,     0,   112,     0,   114,
     116,   251,   256,    16,    17,     0,    18,     3,     4,     5,
       6,     0,    99,     0,     0,   118,     7,     8,     9,    10,
      19,    20,    21,    22,    23,    24,    25,     0,    26,    32,
      39,    44,     0,    48,    52,    58,    62,    65,    68,    75,
      77,    80,     0,   103,    82,    83,     0,     0,   125,     0,
     123,     0,     0,    88,   174,    97,    96,     0,     0,     0,
       0,     0,     0,     0,     0,    79,    79,     0,   189,   118,
       0,   199,   211,   200,   201,   202,     0,   203,   204,   205,
     206,   207,   208,   209,   210,   212,   214,     0,   195,   108,
      87,     0,   240,     0,   242,   160,   260,   242,   113,     0,
       0,     0,     0,   242,    11,     0,     0,    40,     0,    38,
      36,    37,    45,     0,     0,     0,     0,     0,    70,    72,
      73,    71,    74,     0,     0,     0,   100,     0,     0,    85,
     257,   126,   124,   176,     0,     0,     0,     0,     0,     0,
     187,     0,     0,     0,     0,     0,    78,     0,     0,     0,
       0,   183,     0,   213,   243,    91,   140,   158,     0,   258,
     115,   118,    34,    12,    13,     0,     0,    33,    29,     0,
      28,    35,    49,    53,    59,    63,    66,    69,    76,    81,
     104,    84,     0,   102,   248,   225,   247,   175,    98,     0,
       0,   186,     0,   192,     0,   194,   196,   197,   198,     0,
       0,     0,     0,   161,    11,    15,     0,     0,    31,     0,
     177,   101,   172,     0,     0,   141,   143,   142,     0,   216,
       0,   217,   218,   219,   220,   221,   222,   224,     0,     0,
       0,     0,     0,     0,     0,   134,     0,     0,     0,     0,
     159,     0,    30,    27,     0,   111,     0,     0,   164,   144,
       0,     0,   223,   246,   132,   133,   185,   184,     0,   193,
       0,   137,     0,   135,     0,     0,    14,   173,     0,   162,
       0,     0,     0,   111,     0,     0,   138,   136,     0,   242,
       0,     0,   165,   127,     0,     0,     0,     0,   188,     0,
       0,   147,   163,   166,   130,     0,   128,     0,   242,   191,
       0,     0,     0,   131,   129,   145,   190,   148,   167,     0,
     146
};

  /* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -331,     0,  -331,  -331,  -331,  -331,  -331,    27,  -331,  -331,
    -331,  -331,  -331,  -331,  -331,  -331,  -331,    69,  -331,  -331,
    -331,   395,  -158,   375,   173,   376,   174,   378,   175,   380,
     176,   382,   171,   257,  -331,  -331,   178,   -97,   232,  -128,
    -331,   183,  -324,   -93,  -331,  -221,   -25,  -331,   325,  -331,
     -81,  -331,   179,  -331,   330,  -331,   -53,  -331,   202,  -331,
     -47,  -257,  -331,  -331,  -331,  -331,  -331,  -331,  -331,  -331,
    -331,  -331,  -331,  -331,  -331,  -331,  -331,  -331,  -331,  -331,
    -331,  -331,  -331,  -331,  -331,  -331,  -331,  -331,  -331,  -331,
    -331,  -104,  -294,  -331,    82,  -261,  -331,  -331,  -331,  -331,
    -331,  -331,  -331,  -331,  -331,  -331,  -331,   229,  -331,  -331,
      91,  -331,  -331,   428,  -331,  -331,  -330,  -114,  -101,  -173,
    -331,    74,   458,   -30,  -331,   -28,   -58,  -331
};

  /* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,   155,   156,   157,   158,   159,   160,   161,   162,   163,
     164,   165,   166,   167,   168,   169,   308,   309,   250,   170,
     171,   172,   173,   253,   174,   254,   175,   255,   176,   256,
     177,   257,   178,    91,   179,   264,   180,   181,   287,   182,
     185,   186,   108,    72,   194,   124,   125,    38,    62,    63,
     109,   352,   187,    43,    69,    70,    44,    98,   138,   139,
     244,   110,    12,   359,   211,    13,   233,   360,   361,   449,
     441,    14,    64,    92,    51,    15,   342,    16,   298,   362,
     420,   363,   411,   364,   442,    17,    18,   384,   275,   322,
      19,    20,    21,   213,   214,   281,   215,   216,   217,   218,
     219,   220,   221,   222,   223,   224,   225,   226,   227,   366,
     367,   368,    22,    23,    24,    25,   127,   128,   117,   118,
     326,   327,    31,    56,    57,    94,    95,   136
};

  /* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
     positive, shift that token.  If negative, reduce the rule whose
     number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      11,    26,    27,    28,    50,    58,   111,   184,    99,    65,
     295,    66,   212,   191,   252,   228,   376,   235,   193,   210,
     329,   330,    11,   241,   388,   242,    93,   189,   339,    48,
      71,   365,   199,    55,    59,    10,    10,    61,   135,    55,
      10,    55,    68,    10,    10,   129,    10,   103,   132,   192,
     105,    48,    53,    55,   101,    29,   102,    54,    60,   103,
     296,   243,   123,    53,   103,   188,   137,   130,    54,   140,
     142,    48,   365,    55,    67,   236,   115,   401,   116,    30,
     379,   106,   434,   378,   195,    80,    81,    97,   424,   251,
     290,   433,    48,   116,    34,   312,    55,    55,   232,   276,
      55,   283,   279,    33,   282,    39,   284,   285,   286,   286,
      40,    41,    55,   132,    61,   105,   209,   386,   126,    36,
     297,   212,    68,   299,   228,   343,    55,    10,   210,   305,
      37,   387,   345,    55,   101,    42,   102,   319,  -238,    52,
     132,     1,   105,     2,     3,     4,   103,    71,   104,   310,
     105,    73,    45,    46,    47,   426,    82,    83,     5,     6,
      96,   106,   273,    97,   107,     7,   410,     8,     9,   380,
     100,   184,    10,    78,    79,   143,   144,   145,   331,   328,
     324,   333,   325,   335,   146,    42,   113,    10,   147,   148,
     149,   150,    55,   112,   114,   353,   354,   277,   278,   258,
     280,   259,   260,   261,   151,    75,   153,   121,   119,   154,
       6,   140,    45,    46,    47,   120,   355,   356,   357,   122,
     103,   183,   246,    10,   247,   209,   262,   248,   249,   131,
     126,    48,   369,   370,   134,   372,   141,   373,   422,    55,
     301,   190,   351,   230,   323,   301,   234,   432,   301,   381,
     310,   132,   383,   105,   344,   133,   231,   237,  -235,   377,
     183,     1,   340,     2,     3,     4,   238,   302,   447,   448,
     397,   239,   307,   240,    55,   311,   450,   400,     5,     6,
      97,   404,   101,   245,   102,     7,    74,     8,     9,   280,
      55,   265,    10,   266,   103,   402,   104,   267,   105,   269,
     270,   414,    76,    77,   268,   431,   271,   272,   418,   106,
     116,   289,   375,   428,   274,   419,   292,   291,   429,   303,
      84,    85,   304,   294,   445,   358,   306,   334,   439,   437,
     332,   425,   408,   440,   438,   336,   143,   144,   145,   446,
     341,   280,   101,   435,   102,   146,   337,   338,    10,   147,
     148,   149,   150,   385,   103,   346,   104,    97,   105,   347,
     427,   409,   412,   348,   350,   151,   358,   153,   349,   106,
     154,   103,   423,    45,    46,    47,   371,   374,   389,   390,
     391,   398,   393,   405,   394,   395,    48,    48,   399,   406,
      55,   413,   197,   198,   199,   403,   200,   415,   201,   202,
     203,   204,   205,   206,     5,   416,   143,   144,   145,   207,
     208,   417,   421,   430,   436,   146,   382,   443,    10,   147,
     148,   149,   150,   444,    49,    86,    87,   313,    88,   314,
      89,   315,    90,   316,   317,   151,   263,   153,   288,   196,
     154,   300,   318,    45,    46,    47,   320,   143,   144,   145,
      35,   321,   229,   396,   293,   116,   146,   392,   407,    10,
     147,   148,   149,   150,    32,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   151,   152,   153,     0,
       0,   154,     0,     0,    45,    46,    47,    74,    75,    76,
      77,    78,    79,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    80,    81,    82,    83,    84,    85
};

static const yytype_int16 yycheck[] =
{
       0,     1,     2,     3,    29,    33,    59,   104,    55,    39,
     231,    41,   116,   110,   172,   116,   340,   131,   111,   116,
     277,   278,    22,   151,   354,   153,    51,   108,   289,    29,
      51,   325,    10,    33,    34,    34,    34,    37,    96,    39,
      34,    41,    42,    34,    34,    73,    34,    51,    53,    70,
      55,    51,    51,    53,    39,    51,    41,    56,    52,    51,
     233,   154,    52,    51,    51,    69,    65,    92,    56,    97,
     100,    71,   366,    73,    65,   133,    69,    69,    71,    32,
     341,    66,    69,   340,   112,    60,    61,    64,   412,   170,
      67,   421,    92,    71,     4,   253,    96,    97,   126,    39,
     100,   202,   199,    67,   201,    64,   203,   204,   205,   206,
      69,    70,   112,    53,   114,    55,   116,    39,    40,     0,
     234,   225,   122,   237,   225,   298,   126,    34,   225,   243,
      51,    53,   305,   133,    39,    64,    41,   265,     0,    33,
      53,     3,    55,     5,     6,     7,    51,    51,    53,   246,
      55,    67,    59,    60,    61,   412,    62,    63,    20,    21,
      51,    66,   192,    64,    69,    27,   387,    29,    30,   342,
      58,   268,    34,    48,    49,    22,    23,    24,   279,   276,
      69,   282,    71,   284,    31,    64,    52,    34,    35,    36,
      37,    38,   192,    67,    57,     6,     7,   197,   198,    39,
     200,    41,    42,    43,    51,    45,    53,    65,    69,    56,
      21,   239,    59,    60,    61,    69,    27,    28,    29,    57,
      51,    68,    53,    34,    55,   225,    66,    58,    59,    52,
      40,   231,   329,   330,    52,   332,    73,   334,   411,   239,
     240,    69,   323,    52,   274,   245,    52,   420,   248,   346,
     347,    53,   349,    55,   301,    57,    57,    52,     0,   340,
      68,     3,   290,     5,     6,     7,    65,   240,   441,   442,
     371,    57,   245,    58,   274,   248,   449,   374,    20,    21,
      64,   378,    39,    58,    41,    27,    44,    29,    30,   289,
     290,    57,    34,    52,    51,   376,    53,    57,    55,    54,
      54,   398,    46,    47,    57,   419,    69,    69,   405,    66,
      71,    12,    69,   414,    64,   408,    25,    69,   415,    52,
      64,    65,    54,    72,   438,   325,    55,    14,   429,   426,
      13,   412,   385,   430,   427,    69,    22,    23,    24,   440,
      12,   341,    39,   424,    41,    31,    69,    69,    34,    35,
      36,    37,    38,   353,    51,    51,    53,    64,    55,    57,
     413,   386,   390,    54,    69,    51,   366,    53,    50,    66,
      56,    51,    69,    59,    60,    61,    11,    13,    28,    67,
       6,    50,    72,    13,    69,    69,   386,   387,    69,    52,
     390,   391,     8,     9,    10,    69,    12,    50,    14,    15,
      16,    17,    18,    19,    20,    69,    22,    23,    24,    25,
      26,    69,    54,    50,    69,    31,   347,    69,    34,    35,
      36,    37,    38,    69,    29,    50,    50,   254,    50,   255,
      50,   256,    50,   257,   263,    51,   179,    53,   206,   114,
      56,   239,   264,    59,    60,    61,   267,    22,    23,    24,
      22,   268,   122,   371,   225,    71,    31,   366,   384,    34,
      35,    36,    37,    38,     6,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    51,    52,    53,    -1,
      -1,    56,    -1,    -1,    59,    60,    61,    44,    45,    46,
      47,    48,    49,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    60,    61,    62,    63,    64,    65
};

  /* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
     symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     3,     5,     6,     7,    20,    21,    27,    29,    30,
      34,    75,   136,   139,   145,   149,   151,   159,   160,   164,
     165,   166,   186,   187,   188,   189,    75,    75,    75,    51,
      32,   196,   196,    67,     4,   187,     0,    51,   121,    64,
      69,    70,    64,   127,   130,    59,    60,    61,    75,    95,
     120,   148,    33,    51,    56,    75,   197,   198,   199,    75,
      52,    75,   122,   123,   146,   197,   197,    65,    75,   128,
     129,    51,   117,    67,    44,    45,    46,    47,    48,    49,
      60,    61,    62,    63,    64,    65,    97,    99,   101,   103,
     105,   107,   147,   120,   199,   200,    51,    64,   131,   134,
      58,    39,    41,    51,    53,    55,    66,    69,   116,   124,
     135,   130,    67,    52,    57,    69,    71,   192,   193,    69,
      69,    65,    57,    52,   119,   120,    40,   190,   191,   199,
     120,    52,    53,    57,    52,   200,   201,    65,   132,   133,
     199,    73,   197,    22,    23,    24,    31,    35,    36,    37,
      38,    51,    52,    53,    56,    75,    76,    77,    78,    79,
      80,    81,    82,    83,    84,    85,    86,    87,    88,    89,
      93,    94,    95,    96,    98,   100,   102,   104,   106,   108,
     110,   111,   113,    68,   111,   114,   115,   126,    69,   124,
      69,   111,    70,   117,   118,   199,   122,     8,     9,    10,
      12,    14,    15,    16,    17,    18,    19,    25,    26,    75,
     111,   138,   165,   167,   168,   170,   171,   172,   173,   174,
     175,   176,   177,   178,   179,   180,   181,   182,   192,   128,
      52,    57,   199,   140,    52,   191,   200,    52,    65,    57,
      58,   113,   113,   117,   134,    58,    53,    55,    58,    59,
      92,   124,    96,    97,    99,   101,   103,   105,    39,    41,
      42,    43,    66,   107,   109,    57,    52,    57,    57,    54,
      54,    69,    69,   197,    64,   162,    39,    75,    75,   111,
      75,   169,   111,   192,   111,   111,   111,   112,   112,    12,
      67,    69,    25,   181,    72,   119,   193,   191,   152,   191,
     132,    75,    81,    52,    54,   191,    55,    81,    90,    91,
     111,    81,    96,    98,   100,   102,   104,   106,   110,   113,
     126,   115,   163,   197,    69,    71,   194,   195,   111,   135,
     135,   192,    13,   192,    14,   192,    69,    69,    69,   169,
     199,    12,   150,   193,   134,   193,    51,    57,    54,    50,
      69,   124,   125,     6,     7,    27,    28,    29,    75,   137,
     141,   142,   153,   155,   157,   166,   183,   184,   185,   111,
     111,    11,   111,   111,    13,    69,   116,   124,   135,   169,
     193,   111,    91,   111,   161,    75,    39,    53,   190,    28,
      67,     6,   184,    72,    69,    69,   168,   192,    50,    69,
     111,    69,   124,    69,   111,    13,    52,   195,   130,   120,
     119,   156,   199,    75,   111,    50,    69,    69,   111,   117,
     154,    54,   193,    69,   116,   124,   135,   130,   192,   111,
      50,   191,   193,   190,    69,   124,    69,   111,   117,   192,
     111,   144,   158,    69,    69,   191,   192,   193,   193,   143,
     193
};

  /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    74,    75,    76,    77,    78,    79,    80,    80,    80,
      80,    81,    82,    83,    84,    85,    86,    87,    88,    89,
      89,    89,    89,    89,    89,    89,    89,    90,    90,    91,
      91,    92,    93,    93,    93,    93,    93,    93,    93,    94,
      94,    95,    95,    95,    96,    96,    97,    97,    98,    98,
      99,    99,   100,   100,   101,   101,   101,   101,   102,   102,
     103,   103,   104,   104,   105,   106,   106,   107,   108,   108,
     109,   109,   109,   109,   109,   110,   110,   111,   112,   112,
     113,   113,   114,   115,   115,   116,   117,   117,   118,   118,
     119,   119,   120,   121,   121,   122,   122,   123,   123,   124,
     124,   125,   125,   126,   126,   127,   127,   128,   128,   129,
     130,   130,   131,   131,   132,   132,   133,   134,   134,   135,
     135,   135,   136,   136,   136,   136,   136,   137,   137,   137,
     137,   137,   138,   138,   138,   138,   138,   138,   138,   140,
     139,   141,   141,   141,   141,   143,   142,   144,   142,   146,
     145,   147,   147,   147,   147,   147,   147,   148,   150,   149,
     152,   151,   154,   153,   156,   155,   158,   157,   159,   159,
     159,   159,   161,   160,   162,   160,   163,   160,   164,   164,
     164,   165,   166,   167,   168,   168,   168,   169,   170,   171,
     172,   172,   173,   174,   175,   176,   177,   178,   179,   180,
     180,   180,   180,   180,   180,   180,   180,   180,   180,   180,
     180,   180,   181,   181,   182,   182,   183,   183,   183,   183,
     183,   183,   184,   184,   185,   185,   186,   186,   186,   186,
     186,   186,   186,   186,   186,   187,   187,   188,   188,   189,
     190,   191,   191,   192,   193,   193,   194,   195,   195,   196,
     197,   197,   198,   198,   199,   199,   199,   199,   199,   200,
     200,   201,   201
};

  /* YYR2[YYN] -- Number of symbols on the right hand side of rule YYN.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     2,     3,     3,     6,     4,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     3,     1,     1,
       3,     3,     1,     3,     3,     3,     2,     2,     2,     1,
       2,     1,     1,     1,     1,     2,     1,     1,     1,     3,
       1,     1,     1,     3,     1,     1,     1,     1,     1,     3,
       1,     1,     1,     3,     1,     1,     3,     1,     1,     3,
       1,     1,     1,     1,     1,     1,     3,     1,     1,     0,
       1,     3,     1,     1,     3,     3,     2,     3,     1,     0,
       1,     3,     3,     2,     3,     1,     3,     3,     5,     2,
       3,     1,     0,     1,     3,     2,     3,     1,     3,     1,
       1,     0,     2,     3,     1,     3,     1,     1,     0,     1,
       1,     1,     4,     5,     6,     5,     6,     4,     5,     6,
       5,     6,     5,     5,     4,     5,     6,     5,     6,     0,
       7,     1,     1,     1,     2,     0,     8,     0,     7,     0,
       5,     1,     1,     1,     1,     1,     1,     1,     0,     9,
       0,     8,     0,     5,     0,     4,     0,     7,     1,     1,
       1,     0,     0,    10,     0,     7,     0,     8,     5,     5,
       3,     2,     2,     2,     5,     5,     3,     1,     7,     1,
       9,     8,     3,     5,     3,     1,     3,     3,     3,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     2,     1,     0,     1,     1,     1,     1,
       1,     1,     1,     2,     1,     0,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     2,     1,     0,     1,
       2,     1,     0,     3,     1,     1,     3,     1,     1,     2,
       2,     3,     1,     3,     1,     2,     3,     4,     5,     1,
       3,     1,     0
};


/* YYDPREC[RULE-NUM] -- Dynamic precedence of rule #RULE-NUM (0 if none).  */
static const yytype_int8 yydprec[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     3,     2,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0
};

/* YYMERGER[RULE-NUM] -- Index of merging function for rule #RULE-NUM.  */
static const yytype_int8 yymerger[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0
};

/* YYIMMEDIATE[RULE-NUM] -- True iff rule #RULE-NUM is not to be deferred, as
   in the case of predicates.  */
static const yybool yyimmediate[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0
};

/* YYCONFLP[YYPACT[STATE-NUM]] -- Pointer into YYCONFL of start of
   list of conflicting reductions corresponding to action entry for
   state STATE-NUM in yytable.  0 means no conflicts.  The list in
   yyconfl is terminated by a rule number of 0.  */
static const yytype_int8 yyconflp[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     7,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       9,     0,    11,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     1,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     3,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       5,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    13,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    15,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0
};

/* YYCONFL[I] -- lists of conflicting rule numbers, each terminated by
   0, pointed into by YYCONFLP.  */
static const short yyconfl[] =
{
       0,   118,     0,   111,     0,   118,     0,   118,     0,   240,
       0,   240,     0,    11,     0,   118,     0
};


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)                                \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;        \
          (Current).first_column = YYRHSLOC (Rhs, 1).first_column;      \
          (Current).last_line    = YYRHSLOC (Rhs, N).last_line;         \
          (Current).last_column  = YYRHSLOC (Rhs, N).last_column;       \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).first_line   = (Current).last_line   =              \
            YYRHSLOC (Rhs, 0).last_line;                                \
          (Current).first_column = (Current).last_column =              \
            YYRHSLOC (Rhs, 0).last_column;                              \
        }                                                               \
    while (0)
#endif

# define YYRHSLOC(Rhs, K) ((Rhs)[K].yystate.yyloc)


YYSTYPE yylval;
YYLTYPE yylloc;

int yynerrs;
int yychar;

enum { YYENOMEM = -2 };

typedef enum { yyok, yyaccept, yyabort, yyerr } YYRESULTTAG;

#define YYCHK(YYE)                              \
  do {                                          \
    YYRESULTTAG yychk_flag = YYE;               \
    if (yychk_flag != yyok)                     \
      return yychk_flag;                        \
  } while (0)

/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYMAXDEPTH * sizeof (GLRStackItem)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif

/* Minimum number of free items on the stack allowed after an
   allocation.  This is to allow allocation and initialization
   to be completed by functions that call yyexpandGLRStack before the
   stack is expanded, thus insuring that all necessary pointers get
   properly redirected to new data.  */
#define YYHEADROOM 2

#ifndef YYSTACKEXPANDABLE
#  define YYSTACKEXPANDABLE 1
#endif

#if YYSTACKEXPANDABLE
# define YY_RESERVE_GLRSTACK(Yystack)                   \
  do {                                                  \
    if (Yystack->yyspaceLeft < YYHEADROOM)              \
      yyexpandGLRStack (Yystack);                       \
  } while (0)
#else
# define YY_RESERVE_GLRSTACK(Yystack)                   \
  do {                                                  \
    if (Yystack->yyspaceLeft < YYHEADROOM)              \
      yyMemoryExhausted (Yystack);                      \
  } while (0)
#endif

/** State numbers. */
typedef int yy_state_t;

/** Rule numbers. */
typedef int yyRuleNum;

/** Item references. */
typedef short yyItemNum;

typedef struct yyGLRState yyGLRState;
typedef struct yyGLRStateSet yyGLRStateSet;
typedef struct yySemanticOption yySemanticOption;
typedef union yyGLRStackItem yyGLRStackItem;
typedef struct yyGLRStack yyGLRStack;

struct yyGLRState {
  /** Type tag: always true.  */
  yybool yyisState;
  /** Type tag for yysemantics.  If true, yysval applies, otherwise
   *  yyfirstVal applies.  */
  yybool yyresolved;
  /** Number of corresponding LALR(1) machine state.  */
  yy_state_t yylrState;
  /** Preceding state in this stack */
  yyGLRState* yypred;
  /** Source position of the last token produced by my symbol */
  YYPTRDIFF_T yyposn;
  union {
    /** First in a chain of alternative reductions producing the
     *  nonterminal corresponding to this state, threaded through
     *  yynext.  */
    yySemanticOption* yyfirstVal;
    /** Semantic value for this state.  */
    YYSTYPE yysval;
  } yysemantics;
  /** Source location for this state.  */
  YYLTYPE yyloc;
};

struct yyGLRStateSet {
  yyGLRState** yystates;
  /** During nondeterministic operation, yylookaheadNeeds tracks which
   *  stacks have actually needed the current lookahead.  During deterministic
   *  operation, yylookaheadNeeds[0] is not maintained since it would merely
   *  duplicate yychar != YYEMPTY.  */
  yybool* yylookaheadNeeds;
  YYPTRDIFF_T yysize;
  YYPTRDIFF_T yycapacity;
};

struct yySemanticOption {
  /** Type tag: always false.  */
  yybool yyisState;
  /** Rule number for this reduction */
  yyRuleNum yyrule;
  /** The last RHS state in the list of states to be reduced.  */
  yyGLRState* yystate;
  /** The lookahead for this reduction.  */
  int yyrawchar;
  YYSTYPE yyval;
  YYLTYPE yyloc;
  /** Next sibling in chain of options.  To facilitate merging,
   *  options are chained in decreasing order by address.  */
  yySemanticOption* yynext;
};

/** Type of the items in the GLR stack.  The yyisState field
 *  indicates which item of the union is valid.  */
union yyGLRStackItem {
  yyGLRState yystate;
  yySemanticOption yyoption;
};

struct yyGLRStack {
  int yyerrState;
  /* To compute the location of the error token.  */
  yyGLRStackItem yyerror_range[3];

  YYJMP_BUF yyexception_buffer;
  yyGLRStackItem* yyitems;
  yyGLRStackItem* yynextFree;
  YYPTRDIFF_T yyspaceLeft;
  yyGLRState* yysplitPoint;
  yyGLRState* yylastDeleted;
  yyGLRStateSet yytops;
};

#if YYSTACKEXPANDABLE
static void yyexpandGLRStack (yyGLRStack* yystackp);
#endif

_Noreturn static void
yyFail (yyGLRStack* yystackp, const char* yymsg)
{
  if (yymsg != YY_NULLPTR)
    yyerror (yymsg);
  YYLONGJMP (yystackp->yyexception_buffer, 1);
}

_Noreturn static void
yyMemoryExhausted (yyGLRStack* yystackp)
{
  YYLONGJMP (yystackp->yyexception_buffer, 2);
}

/** Accessing symbol of state YYSTATE.  */
static inline yysymbol_kind_t
yy_accessing_symbol (yy_state_t yystate)
{
  return YY_CAST (yysymbol_kind_t, yystos[yystate]);
}

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "PROGRAM", "CLASS",
  "TYPE", "FUNCTION", "OPERATOR", "AUTO", "LET", "IF", "ELSE", "FOR", "IN",
  "WHILE", "DO", "WITH", "ASSERT", "RETURN", "FACTOR", "CPP", "HPP",
  "THIS", "SUPER", "GLOBAL", "PARALLEL", "DYNAMIC", "ABSTRACT", "OVERRIDE",
  "FINAL", "ACYCLIC", "NIL", "DOUBLE_BRACE_OPEN", "DOUBLE_BRACE_CLOSE",
  "NAME", "BOOL_LITERAL", "INT_LITERAL", "REAL_LITERAL", "STRING_LITERAL",
  "LEFT_OP", "RIGHT_OP", "LEFT_TILDE_OP", "RIGHT_TILDE_OP",
  "LEFT_QUERY_OP", "AND_OP", "OR_OP", "LE_OP", "GE_OP", "EQ_OP", "NE_OP",
  "RANGE_OP", "'('", "')'", "'['", "']'", "'?'", "'\\\\'", "','", "'.'",
  "'!'", "'+'", "'-'", "'*'", "'/'", "'<'", "'>'", "'~'", "':'", "'_'",
  "';'", "'='", "'{'", "'}'", "'&'", "$accept", "name", "bool_literal",
  "int_literal", "real_literal", "string_literal", "literal", "identifier",
  "parens_expression", "sequence_expression", "cast_expression",
  "function_expression", "this_expression", "super_expression",
  "nil_expression", "primary_expression", "slice_expression",
  "slice_expression_list", "slice", "postfix_expression",
  "query_expression", "prefix_operator", "prefix_expression",
  "multiplicative_operator", "multiplicative_expression",
  "additive_operator", "additive_expression", "relational_operator",
  "relational_expression", "equality_operator", "equality_expression",
  "logical_and_operator", "logical_and_expression", "logical_or_operator",
  "logical_or_expression", "assign_operator", "assign_expression",
  "expression", "optional_expression", "expression_list",
  "span_expression", "span_list", "brackets", "parameters",
  "optional_parameters", "parameter_list", "parameter", "options",
  "option_list", "option", "arguments", "optional_arguments", "shape",
  "generics", "generic_list", "generic", "optional_generics",
  "generic_arguments", "generic_argument_list", "generic_argument",
  "optional_generic_arguments", "init_operator",
  "global_variable_declaration", "member_variable_declaration",
  "local_variable_declaration", "function_declaration", "$@1",
  "member_function_annotation", "member_function_declaration", "$@2",
  "$@3", "program_declaration", "$@4", "binary_operator", "unary_operator",
  "binary_operator_declaration", "$@5", "unary_operator_declaration",
  "$@6", "assignment_operator_declaration", "$@7",
  "conversion_operator_declaration", "$@8", "slice_operator_declaration",
  "$@9", "class_annotation", "class_declaration", "$@10", "$@11", "$@12",
  "basic_declaration", "cpp", "hpp", "expression_statement", "if",
  "for_variable_declaration", "for", "parallel_annotation", "parallel",
  "while", "do_while", "with", "block", "assertion", "return", "factor",
  "statement", "statements", "optional_statements", "class_statement",
  "class_statements", "optional_class_statements", "file_statement",
  "file_statements", "optional_file_statements", "file", "return_type",
  "optional_return_type", "braces", "optional_braces", "class_braces",
  "optional_class_braces", "double_braces", "named_type", "primary_type",
  "type", "type_list", "optional_type_list", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#if YYDEBUG

# ifndef YYFPRINTF
#  define YYFPRINTF fprintf
# endif

# define YY_FPRINTF                             \
  YY_IGNORE_USELESS_CAST_BEGIN YY_FPRINTF_

# define YY_FPRINTF_(Args)                      \
  do {                                          \
    YYFPRINTF Args;                             \
    YY_IGNORE_USELESS_CAST_END                  \
  } while (0)

# define YY_DPRINTF                             \
  YY_IGNORE_USELESS_CAST_BEGIN YY_DPRINTF_

# define YY_DPRINTF_(Args)                      \
  do {                                          \
    if (yydebug)                                \
      YYFPRINTF Args;                           \
    YY_IGNORE_USELESS_CAST_END                  \
  } while (0)


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

# ifndef YY_LOCATION_PRINT
#  if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL

/* Print *YYLOCP on YYO.  Private, do not rely on its existence. */

YY_ATTRIBUTE_UNUSED
static int
yy_location_print_ (FILE *yyo, YYLTYPE const * const yylocp)
{
  int res = 0;
  int end_col = 0 != yylocp->last_column ? yylocp->last_column - 1 : 0;
  if (0 <= yylocp->first_line)
    {
      res += YYFPRINTF (yyo, "%d", yylocp->first_line);
      if (0 <= yylocp->first_column)
        res += YYFPRINTF (yyo, ".%d", yylocp->first_column);
    }
  if (0 <= yylocp->last_line)
    {
      if (yylocp->first_line < yylocp->last_line)
        {
          res += YYFPRINTF (yyo, "-%d", yylocp->last_line);
          if (0 <= end_col)
            res += YYFPRINTF (yyo, ".%d", end_col);
        }
      else if (0 <= end_col && yylocp->first_column < end_col)
        res += YYFPRINTF (yyo, "-%d", end_col);
    }
  return res;
 }

#   define YY_LOCATION_PRINT(File, Loc)          \
  yy_location_print_ (File, &(Loc))

#  else
#   define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#  endif
# endif /* !defined YY_LOCATION_PRINT */



/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp)
{
  FILE *yyoutput = yyo;
  YYUSE (yyoutput);
  YYUSE (yylocationp);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  YY_LOCATION_PRINT (yyo, *yylocationp);
  YYFPRINTF (yyo, ": ");
  yy_symbol_value_print (yyo, yykind, yyvaluep, yylocationp);
  YYFPRINTF (yyo, ")");
}

# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                  \
  do {                                                                  \
    if (yydebug)                                                        \
      {                                                                 \
        YY_FPRINTF ((stderr, "%s ", Title));                            \
        yy_symbol_print (stderr, Kind, Value, Location);        \
        YY_FPRINTF ((stderr, "\n"));                                    \
      }                                                                 \
  } while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;

static void yypstack (yyGLRStack* yystackp, YYPTRDIFF_T yyk)
  YY_ATTRIBUTE_UNUSED;
static void yypdumpstack (yyGLRStack* yystackp)
  YY_ATTRIBUTE_UNUSED;

#else /* !YYDEBUG */

# define YY_DPRINTF(Args) do {} while (yyfalse)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)

#endif /* !YYDEBUG */



/** Fill in YYVSP[YYLOW1 .. YYLOW0-1] from the chain of states starting
 *  at YYVSP[YYLOW0].yystate.yypred.  Leaves YYVSP[YYLOW1].yystate.yypred
 *  containing the pointer to the next state in the chain.  */
static void yyfillin (yyGLRStackItem *, int, int) YY_ATTRIBUTE_UNUSED;
static void
yyfillin (yyGLRStackItem *yyvsp, int yylow0, int yylow1)
{
  int i;
  yyGLRState *s = yyvsp[yylow0].yystate.yypred;
  for (i = yylow0-1; i >= yylow1; i -= 1)
    {
#if YYDEBUG
      yyvsp[i].yystate.yylrState = s->yylrState;
#endif
      yyvsp[i].yystate.yyresolved = s->yyresolved;
      if (s->yyresolved)
        yyvsp[i].yystate.yysemantics.yysval = s->yysemantics.yysval;
      else
        /* The effect of using yysval or yyloc (in an immediate rule) is
         * undefined.  */
        yyvsp[i].yystate.yysemantics.yyfirstVal = YY_NULLPTR;
      yyvsp[i].yystate.yyloc = s->yyloc;
      s = yyvsp[i].yystate.yypred = s->yypred;
    }
}


/** If yychar is empty, fetch the next token.  */
static inline yysymbol_kind_t
yygetToken (int *yycharp)
{
  yysymbol_kind_t yytoken;
  if (*yycharp == YYEMPTY)
    {
      YY_DPRINTF ((stderr, "Reading a token\n"));
      *yycharp = yylex ();
    }
  if (*yycharp <= YYEOF)
    {
      *yycharp = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YY_DPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (*yycharp);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }
  return yytoken;
}

/* Do nothing if YYNORMAL or if *YYLOW <= YYLOW1.  Otherwise, fill in
 * YYVSP[YYLOW1 .. *YYLOW-1] as in yyfillin and set *YYLOW = YYLOW1.
 * For convenience, always return YYLOW1.  */
static inline int yyfill (yyGLRStackItem *, int *, int, yybool)
     YY_ATTRIBUTE_UNUSED;
static inline int
yyfill (yyGLRStackItem *yyvsp, int *yylow, int yylow1, yybool yynormal)
{
  if (!yynormal && yylow1 < *yylow)
    {
      yyfillin (yyvsp, *yylow, yylow1);
      *yylow = yylow1;
    }
  return yylow1;
}

/** Perform user action for rule number YYN, with RHS length YYRHSLEN,
 *  and top stack item YYVSP.  YYLVALP points to place to put semantic
 *  value ($$), and yylocp points to place for location information
 *  (@$).  Returns yyok for normal return, yyaccept for YYACCEPT,
 *  yyerr for YYERROR, yyabort for YYABORT.  */
static YYRESULTTAG
yyuserAction (yyRuleNum yyn, int yyrhslen, yyGLRStackItem* yyvsp,
              yyGLRStack* yystackp,
              YYSTYPE* yyvalp, YYLTYPE *yylocp)
{
  yybool yynormal YY_ATTRIBUTE_UNUSED = yystackp->yysplitPoint == YY_NULLPTR;
  int yylow;
  YYUSE (yyvalp);
  YYUSE (yylocp);
  YYUSE (yyrhslen);
# undef yyerrok
# define yyerrok (yystackp->yyerrState = 0)
# undef YYACCEPT
# define YYACCEPT return yyaccept
# undef YYABORT
# define YYABORT return yyabort
# undef YYERROR
# define YYERROR return yyerrok, yyerr
# undef YYRECOVERING
# define YYRECOVERING() (yystackp->yyerrState != 0)
# undef yyclearin
# define yyclearin (yychar = YYEMPTY)
# undef YYFILL
# define YYFILL(N) yyfill (yyvsp, &yylow, (N), yynormal)
# undef YYBACKUP
# define YYBACKUP(Token, Value)                                              \
  return yyerror (YY_("syntax error: cannot back up")),     \
         yyerrok, yyerr

  yylow = 1;
  if (yyrhslen == 0)
    *yyvalp = yyval_default;
  else
    *yyvalp = yyvsp[YYFILL (1-yyrhslen)].yystate.yysemantics.yysval;
  /* Default location. */
  YYLLOC_DEFAULT ((*yylocp), (yyvsp - yyrhslen), yyrhslen);
  yystackp->yyerror_range[1].yystate.yyloc = *yylocp;

  switch (yyn)
    {
  case 2: /* name: NAME  */
#line 164 "src/parser.ypp"
            { ((*yyvalp).valName) = new birch::Name((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valString)); }
#line 1755 "src/parser.cpp"
    break;

  case 3: /* bool_literal: BOOL_LITERAL  */
#line 173 "src/parser.ypp"
                    { ((*yyvalp).valExpression) = new birch::Literal<bool>((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valString), make_loc((*yylocp))); }
#line 1761 "src/parser.cpp"
    break;

  case 4: /* int_literal: INT_LITERAL  */
#line 177 "src/parser.ypp"
                   { ((*yyvalp).valExpression) = new birch::Literal<int64_t>((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valString), make_loc((*yylocp))); }
#line 1767 "src/parser.cpp"
    break;

  case 5: /* real_literal: REAL_LITERAL  */
#line 181 "src/parser.ypp"
                    { ((*yyvalp).valExpression) = new birch::Literal<double>((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valString), make_loc((*yylocp))); }
#line 1773 "src/parser.cpp"
    break;

  case 6: /* string_literal: STRING_LITERAL  */
#line 185 "src/parser.ypp"
                      { ((*yyvalp).valExpression) = new birch::Literal<const char*>((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valString), make_loc((*yylocp))); }
#line 1779 "src/parser.cpp"
    break;

  case 11: /* identifier: name optional_generic_arguments  */
#line 196 "src/parser.ypp"
                                       { ((*yyvalp).valExpression) = new birch::NamedExpression((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valType), make_loc((*yylocp))); }
#line 1785 "src/parser.cpp"
    break;

  case 12: /* parens_expression: '(' expression_list ')'  */
#line 200 "src/parser.ypp"
                               { ((*yyvalp).valExpression) = new birch::Parentheses((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1791 "src/parser.cpp"
    break;

  case 13: /* sequence_expression: '[' expression_list ']'  */
#line 204 "src/parser.ypp"
                               { ((*yyvalp).valExpression) = new birch::Sequence((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1797 "src/parser.cpp"
    break;

  case 14: /* cast_expression: name optional_generic_arguments '?' '(' expression ')'  */
#line 208 "src/parser.ypp"
                                                              { ((*yyvalp).valExpression) = new birch::Cast(new birch::NamedType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valType), make_loc((*yylocp))), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1803 "src/parser.cpp"
    break;

  case 15: /* function_expression: '\\' parameters optional_return_type optional_braces  */
#line 212 "src/parser.ypp"
                                                            { ((*yyvalp).valExpression) = new birch::LambdaFunction((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 1809 "src/parser.cpp"
    break;

  case 16: /* this_expression: THIS  */
#line 216 "src/parser.ypp"
            { ((*yyvalp).valExpression) = new birch::This(make_loc((*yylocp))); }
#line 1815 "src/parser.cpp"
    break;

  case 17: /* super_expression: SUPER  */
#line 220 "src/parser.ypp"
             { ((*yyvalp).valExpression) = new birch::Super(make_loc((*yylocp))); }
#line 1821 "src/parser.cpp"
    break;

  case 18: /* nil_expression: NIL  */
#line 224 "src/parser.ypp"
           { ((*yyvalp).valExpression) = new birch::Nil(make_loc((*yylocp))); }
#line 1827 "src/parser.cpp"
    break;

  case 27: /* slice_expression: expression RANGE_OP expression  */
#line 239 "src/parser.ypp"
                                      { ((*yyvalp).valExpression) = new birch::Range((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1833 "src/parser.cpp"
    break;

  case 30: /* slice_expression_list: slice_expression ',' slice_expression_list  */
#line 245 "src/parser.ypp"
                                                  { ((*yyvalp).valExpression) = new birch::ExpressionList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1839 "src/parser.cpp"
    break;

  case 31: /* slice: '[' slice_expression_list ']'  */
#line 249 "src/parser.ypp"
                                     { ((*yyvalp).valExpression) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression); }
#line 1845 "src/parser.cpp"
    break;

  case 33: /* postfix_expression: super_expression '.' identifier  */
#line 254 "src/parser.ypp"
                                         { ((*yyvalp).valExpression) = new birch::Member((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1851 "src/parser.cpp"
    break;

  case 34: /* postfix_expression: GLOBAL '.' identifier  */
#line 255 "src/parser.ypp"
                                         { ((*yyvalp).valExpression) = new birch::Global((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1857 "src/parser.cpp"
    break;

  case 35: /* postfix_expression: postfix_expression '.' identifier  */
#line 256 "src/parser.ypp"
                                         { ((*yyvalp).valExpression) = new birch::Member((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1863 "src/parser.cpp"
    break;

  case 36: /* postfix_expression: postfix_expression slice  */
#line 257 "src/parser.ypp"
                                         { ((*yyvalp).valExpression) = new birch::Slice((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1869 "src/parser.cpp"
    break;

  case 37: /* postfix_expression: postfix_expression arguments  */
#line 258 "src/parser.ypp"
                                         { ((*yyvalp).valExpression) = new birch::Call((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1875 "src/parser.cpp"
    break;

  case 38: /* postfix_expression: postfix_expression '!'  */
#line 259 "src/parser.ypp"
                                         { ((*yyvalp).valExpression) = new birch::Get((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1881 "src/parser.cpp"
    break;

  case 40: /* query_expression: postfix_expression '?'  */
#line 266 "src/parser.ypp"
                              { ((*yyvalp).valExpression) = new birch::Query((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1887 "src/parser.cpp"
    break;

  case 41: /* prefix_operator: '+'  */
#line 270 "src/parser.ypp"
           { ((*yyvalp).valName) = new birch::Name("+"); }
#line 1893 "src/parser.cpp"
    break;

  case 42: /* prefix_operator: '-'  */
#line 271 "src/parser.ypp"
           { ((*yyvalp).valName) = new birch::Name("-"); }
#line 1899 "src/parser.cpp"
    break;

  case 43: /* prefix_operator: '!'  */
#line 272 "src/parser.ypp"
           { ((*yyvalp).valName) = new birch::Name("!"); }
#line 1905 "src/parser.cpp"
    break;

  case 45: /* prefix_expression: prefix_operator prefix_expression  */
#line 277 "src/parser.ypp"
                                         { ((*yyvalp).valExpression) = new birch::UnaryCall((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1911 "src/parser.cpp"
    break;

  case 46: /* multiplicative_operator: '*'  */
#line 281 "src/parser.ypp"
           { ((*yyvalp).valName) = new birch::Name("*"); }
#line 1917 "src/parser.cpp"
    break;

  case 47: /* multiplicative_operator: '/'  */
#line 282 "src/parser.ypp"
           { ((*yyvalp).valName) = new birch::Name("/"); }
#line 1923 "src/parser.cpp"
    break;

  case 49: /* multiplicative_expression: multiplicative_expression multiplicative_operator prefix_expression  */
#line 287 "src/parser.ypp"
                                                                           { ((*yyvalp).valExpression) = new birch::BinaryCall((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1929 "src/parser.cpp"
    break;

  case 50: /* additive_operator: '+'  */
#line 291 "src/parser.ypp"
           { ((*yyvalp).valName) = new birch::Name("+"); }
#line 1935 "src/parser.cpp"
    break;

  case 51: /* additive_operator: '-'  */
#line 292 "src/parser.ypp"
           { ((*yyvalp).valName) = new birch::Name("-"); }
#line 1941 "src/parser.cpp"
    break;

  case 53: /* additive_expression: additive_expression additive_operator multiplicative_expression  */
#line 297 "src/parser.ypp"
                                                                       { ((*yyvalp).valExpression) = new birch::BinaryCall((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1947 "src/parser.cpp"
    break;

  case 54: /* relational_operator: '<'  */
#line 301 "src/parser.ypp"
             { ((*yyvalp).valName) = new birch::Name("<"); }
#line 1953 "src/parser.cpp"
    break;

  case 55: /* relational_operator: '>'  */
#line 302 "src/parser.ypp"
             { ((*yyvalp).valName) = new birch::Name(">"); }
#line 1959 "src/parser.cpp"
    break;

  case 56: /* relational_operator: LE_OP  */
#line 303 "src/parser.ypp"
             { ((*yyvalp).valName) = new birch::Name("<="); }
#line 1965 "src/parser.cpp"
    break;

  case 57: /* relational_operator: GE_OP  */
#line 304 "src/parser.ypp"
             { ((*yyvalp).valName) = new birch::Name(">="); }
#line 1971 "src/parser.cpp"
    break;

  case 59: /* relational_expression: relational_expression relational_operator additive_expression  */
#line 314 "src/parser.ypp"
                                                                               { ((*yyvalp).valExpression) = new birch::BinaryCall((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1977 "src/parser.cpp"
    break;

  case 60: /* equality_operator: EQ_OP  */
#line 318 "src/parser.ypp"
             { ((*yyvalp).valName) = new birch::Name("=="); }
#line 1983 "src/parser.cpp"
    break;

  case 61: /* equality_operator: NE_OP  */
#line 319 "src/parser.ypp"
             { ((*yyvalp).valName) = new birch::Name("!="); }
#line 1989 "src/parser.cpp"
    break;

  case 63: /* equality_expression: equality_expression equality_operator relational_expression  */
#line 324 "src/parser.ypp"
                                                                   { ((*yyvalp).valExpression) = new birch::BinaryCall((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 1995 "src/parser.cpp"
    break;

  case 64: /* logical_and_operator: AND_OP  */
#line 328 "src/parser.ypp"
              { ((*yyvalp).valName) = new birch::Name("&&"); }
#line 2001 "src/parser.cpp"
    break;

  case 66: /* logical_and_expression: logical_and_expression logical_and_operator equality_expression  */
#line 333 "src/parser.ypp"
                                                                       { ((*yyvalp).valExpression) = new birch::BinaryCall((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2007 "src/parser.cpp"
    break;

  case 67: /* logical_or_operator: OR_OP  */
#line 337 "src/parser.ypp"
             { ((*yyvalp).valName) = new birch::Name("||"); }
#line 2013 "src/parser.cpp"
    break;

  case 69: /* logical_or_expression: logical_or_expression logical_or_operator logical_and_expression  */
#line 342 "src/parser.ypp"
                                                                        { ((*yyvalp).valExpression) = new birch::BinaryCall((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2019 "src/parser.cpp"
    break;

  case 70: /* assign_operator: LEFT_OP  */
#line 346 "src/parser.ypp"
                      { ((*yyvalp).valName) = new birch::Name("<-"); }
#line 2025 "src/parser.cpp"
    break;

  case 71: /* assign_operator: LEFT_QUERY_OP  */
#line 347 "src/parser.ypp"
                      { ((*yyvalp).valName) = new birch::Name("<-?"); }
#line 2031 "src/parser.cpp"
    break;

  case 72: /* assign_operator: LEFT_TILDE_OP  */
#line 348 "src/parser.ypp"
                      { ((*yyvalp).valName) = new birch::Name("<~"); }
#line 2037 "src/parser.cpp"
    break;

  case 73: /* assign_operator: RIGHT_TILDE_OP  */
#line 349 "src/parser.ypp"
                      { ((*yyvalp).valName) = new birch::Name("~>"); }
#line 2043 "src/parser.cpp"
    break;

  case 74: /* assign_operator: '~'  */
#line 350 "src/parser.ypp"
                      { ((*yyvalp).valName) = new birch::Name("~"); }
#line 2049 "src/parser.cpp"
    break;

  case 76: /* assign_expression: logical_or_expression assign_operator assign_expression  */
#line 355 "src/parser.ypp"
                                                               { ((*yyvalp).valExpression) = new birch::Assign((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2055 "src/parser.cpp"
    break;

  case 79: /* optional_expression: %empty  */
#line 364 "src/parser.ypp"
                  { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2061 "src/parser.cpp"
    break;

  case 81: /* expression_list: expression ',' expression_list  */
#line 369 "src/parser.ypp"
                                      { ((*yyvalp).valExpression) = new birch::ExpressionList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2067 "src/parser.cpp"
    break;

  case 82: /* span_expression: expression  */
#line 373 "src/parser.ypp"
                   { ((*yyvalp).valExpression) = new birch::Span((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2073 "src/parser.cpp"
    break;

  case 84: /* span_list: span_expression ',' span_list  */
#line 378 "src/parser.ypp"
                                     { ((*yyvalp).valExpression) = new birch::ExpressionList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2079 "src/parser.cpp"
    break;

  case 85: /* brackets: '[' span_list ']'  */
#line 382 "src/parser.ypp"
                         { ((*yyvalp).valExpression) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression); }
#line 2085 "src/parser.cpp"
    break;

  case 86: /* parameters: '(' ')'  */
#line 386 "src/parser.ypp"
                              { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2091 "src/parser.cpp"
    break;

  case 87: /* parameters: '(' parameter_list ')'  */
#line 387 "src/parser.ypp"
                              { ((*yyvalp).valExpression) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression); }
#line 2097 "src/parser.cpp"
    break;

  case 89: /* optional_parameters: %empty  */
#line 392 "src/parser.ypp"
                  { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2103 "src/parser.cpp"
    break;

  case 91: /* parameter_list: parameter ',' parameter_list  */
#line 397 "src/parser.ypp"
                                    { ((*yyvalp).valExpression) = new birch::ExpressionList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2109 "src/parser.cpp"
    break;

  case 92: /* parameter: name ':' type  */
#line 401 "src/parser.ypp"
                     { ((*yyvalp).valExpression) = new birch::Parameter(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valType), empty_name((*yylocp)), empty_expr((*yylocp)), make_loc((*yylocp))); }
#line 2115 "src/parser.cpp"
    break;

  case 93: /* options: '(' ')'  */
#line 405 "src/parser.ypp"
                           { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2121 "src/parser.cpp"
    break;

  case 94: /* options: '(' option_list ')'  */
#line 406 "src/parser.ypp"
                           { ((*yyvalp).valExpression) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression); }
#line 2127 "src/parser.cpp"
    break;

  case 96: /* option_list: option ',' option_list  */
#line 411 "src/parser.ypp"
                              { ((*yyvalp).valExpression) = new birch::ExpressionList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2133 "src/parser.cpp"
    break;

  case 97: /* option: name ':' type  */
#line 415 "src/parser.ypp"
                                        { ((*yyvalp).valExpression) = new birch::Parameter(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valType), empty_name((*yylocp)), empty_expr((*yylocp)), make_loc((*yylocp))); }
#line 2139 "src/parser.cpp"
    break;

  case 98: /* option: name ':' type LEFT_OP expression  */
#line 416 "src/parser.ypp"
                                        { ((*yyvalp).valExpression) = new birch::Parameter(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), new birch::Name((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valString)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2145 "src/parser.cpp"
    break;

  case 99: /* arguments: '(' ')'  */
#line 420 "src/parser.ypp"
                               { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2151 "src/parser.cpp"
    break;

  case 100: /* arguments: '(' expression_list ')'  */
#line 421 "src/parser.ypp"
                               { ((*yyvalp).valExpression) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression); }
#line 2157 "src/parser.cpp"
    break;

  case 102: /* optional_arguments: %empty  */
#line 426 "src/parser.ypp"
                 { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2163 "src/parser.cpp"
    break;

  case 103: /* shape: '_'  */
#line 430 "src/parser.ypp"
                     { ((*yyvalp).valInt) = 1; }
#line 2169 "src/parser.cpp"
    break;

  case 104: /* shape: '_' ',' shape  */
#line 431 "src/parser.ypp"
                     { ((*yyvalp).valInt) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valInt) + 1; }
#line 2175 "src/parser.cpp"
    break;

  case 105: /* generics: '<' '>'  */
#line 435 "src/parser.ypp"
                            { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2181 "src/parser.cpp"
    break;

  case 106: /* generics: '<' generic_list '>'  */
#line 436 "src/parser.ypp"
                            { ((*yyvalp).valExpression) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression); }
#line 2187 "src/parser.cpp"
    break;

  case 108: /* generic_list: generic ',' generic_list  */
#line 441 "src/parser.ypp"
                                { ((*yyvalp).valExpression) = new birch::ExpressionList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2193 "src/parser.cpp"
    break;

  case 109: /* generic: name  */
#line 445 "src/parser.ypp"
            { ((*yyvalp).valExpression) = new birch::Generic(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valName), empty_type((*yylocp)), make_loc((*yylocp))); }
#line 2199 "src/parser.cpp"
    break;

  case 111: /* optional_generics: %empty  */
#line 450 "src/parser.ypp"
                { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2205 "src/parser.cpp"
    break;

  case 112: /* generic_arguments: '<' '>'  */
#line 454 "src/parser.ypp"
                                     { ((*yyvalp).valType) = empty_type((*yylocp)); }
#line 2211 "src/parser.cpp"
    break;

  case 113: /* generic_arguments: '<' generic_argument_list '>'  */
#line 455 "src/parser.ypp"
                                     { ((*yyvalp).valType) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valType); }
#line 2217 "src/parser.cpp"
    break;

  case 115: /* generic_argument_list: generic_argument ',' generic_argument_list  */
#line 460 "src/parser.ypp"
                                                  { ((*yyvalp).valType) = new birch::TypeList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valType), make_loc((*yylocp))); }
#line 2223 "src/parser.cpp"
    break;

  case 118: /* optional_generic_arguments: %empty  */
#line 469 "src/parser.ypp"
                         { ((*yyvalp).valType) = empty_type((*yylocp)); }
#line 2229 "src/parser.cpp"
    break;

  case 119: /* init_operator: LEFT_OP  */
#line 478 "src/parser.ypp"
                      { ((*yyvalp).valName) = new birch::Name("<-"); }
#line 2235 "src/parser.cpp"
    break;

  case 120: /* init_operator: LEFT_TILDE_OP  */
#line 479 "src/parser.ypp"
                      { ((*yyvalp).valName) = new birch::Name("<~"); }
#line 2241 "src/parser.cpp"
    break;

  case 121: /* init_operator: '~'  */
#line 480 "src/parser.ypp"
                      { ((*yyvalp).valName) = new birch::Name("~"); }
#line 2247 "src/parser.cpp"
    break;

  case 122: /* global_variable_declaration: name ':' type ';'  */
#line 484 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::GlobalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valType), empty_expr((*yylocp)), empty_expr((*yylocp)), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2253 "src/parser.cpp"
    break;

  case 123: /* global_variable_declaration: name ':' type arguments ';'  */
#line 485 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::GlobalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2259 "src/parser.cpp"
    break;

  case 124: /* global_variable_declaration: name ':' type init_operator expression ';'  */
#line 486 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::GlobalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valType), empty_expr((*yylocp)), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_doc_loc((*yylocp))); }
#line 2265 "src/parser.cpp"
    break;

  case 125: /* global_variable_declaration: name ':' type brackets ';'  */
#line 487 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::GlobalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valName), new birch::ArrayType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression)->width(), make_loc((*yylocp))), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), empty_expr((*yylocp)), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2271 "src/parser.cpp"
    break;

  case 126: /* global_variable_declaration: name ':' type brackets arguments ';'  */
#line 488 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::GlobalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valName), new birch::ArrayType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression)->width(), make_loc((*yylocp))), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2277 "src/parser.cpp"
    break;

  case 127: /* member_variable_declaration: name ':' type ';'  */
#line 492 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::MemberVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valType), empty_expr((*yylocp)), empty_expr((*yylocp)), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2283 "src/parser.cpp"
    break;

  case 128: /* member_variable_declaration: name ':' type arguments ';'  */
#line 493 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::MemberVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2289 "src/parser.cpp"
    break;

  case 129: /* member_variable_declaration: name ':' type init_operator expression ';'  */
#line 494 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::MemberVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valType), empty_expr((*yylocp)), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_doc_loc((*yylocp))); }
#line 2295 "src/parser.cpp"
    break;

  case 130: /* member_variable_declaration: name ':' type brackets ';'  */
#line 495 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::MemberVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valName), new birch::ArrayType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression)->width(), make_loc((*yylocp))), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), empty_expr((*yylocp)), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2301 "src/parser.cpp"
    break;

  case 131: /* member_variable_declaration: name ':' type brackets arguments ';'  */
#line 496 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::MemberVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valName), new birch::ArrayType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression)->width(), make_loc((*yylocp))), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2307 "src/parser.cpp"
    break;

  case 132: /* local_variable_declaration: AUTO name init_operator expression ';'  */
#line 500 "src/parser.ypp"
                                                  { yywarn("the auto keyword is deprecated, use let instead"); push_raw(); ((*yyvalp).valStatement) = new birch::LocalVariable(birch::LET, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valName), empty_type((*yylocp)), empty_expr((*yylocp)), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_doc_loc((*yylocp))); }
#line 2313 "src/parser.cpp"
    break;

  case 133: /* local_variable_declaration: LET name init_operator expression ';'  */
#line 501 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::LocalVariable(birch::LET, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valName), empty_type((*yylocp)), empty_expr((*yylocp)), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_doc_loc((*yylocp))); }
#line 2319 "src/parser.cpp"
    break;

  case 134: /* local_variable_declaration: name ':' type ';'  */
#line 502 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::LocalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valType), empty_expr((*yylocp)), empty_expr((*yylocp)), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2325 "src/parser.cpp"
    break;

  case 135: /* local_variable_declaration: name ':' type arguments ';'  */
#line 503 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::LocalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2331 "src/parser.cpp"
    break;

  case 136: /* local_variable_declaration: name ':' type init_operator expression ';'  */
#line 504 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::LocalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valType), empty_expr((*yylocp)), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_doc_loc((*yylocp))); }
#line 2337 "src/parser.cpp"
    break;

  case 137: /* local_variable_declaration: name ':' type brackets ';'  */
#line 505 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::LocalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valName), new birch::ArrayType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression)->width(), make_loc((*yylocp))), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), empty_expr((*yylocp)), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2343 "src/parser.cpp"
    break;

  case 138: /* local_variable_declaration: name ':' type brackets arguments ';'  */
#line 506 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::LocalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valName), new birch::ArrayType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression)->width(), make_loc((*yylocp))), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2349 "src/parser.cpp"
    break;

  case 139: /* $@1: %empty  */
#line 510 "src/parser.ypp"
                                                                      { push_raw(); }
#line 2355 "src/parser.cpp"
    break;

  case 140: /* function_declaration: FUNCTION name optional_generics parameters optional_return_type $@1 optional_braces  */
#line 510 "src/parser.ypp"
                                                                                                       { ((*yyvalp).valStatement) = new birch::Function(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_doc_loc((*yylocp))); }
#line 2361 "src/parser.cpp"
    break;

  case 141: /* member_function_annotation: ABSTRACT  */
#line 514 "src/parser.ypp"
                      { ((*yyvalp).valAnnotation) = birch::ABSTRACT; }
#line 2367 "src/parser.cpp"
    break;

  case 142: /* member_function_annotation: FINAL  */
#line 515 "src/parser.ypp"
                      { ((*yyvalp).valAnnotation) = birch::FINAL; }
#line 2373 "src/parser.cpp"
    break;

  case 143: /* member_function_annotation: OVERRIDE  */
#line 516 "src/parser.ypp"
                      { ((*yyvalp).valAnnotation) = birch::OVERRIDE; }
#line 2379 "src/parser.cpp"
    break;

  case 144: /* member_function_annotation: FINAL OVERRIDE  */
#line 517 "src/parser.ypp"
                      { ((*yyvalp).valAnnotation) = birch::Annotation(birch::FINAL|birch::OVERRIDE); }
#line 2385 "src/parser.cpp"
    break;

  case 145: /* $@2: %empty  */
#line 523 "src/parser.ypp"
                                                                                                 { push_raw(); }
#line 2391 "src/parser.cpp"
    break;

  case 146: /* member_function_declaration: member_function_annotation FUNCTION name optional_generics parameters optional_return_type $@2 optional_braces  */
#line 523 "src/parser.ypp"
                                                                                                                                  { ((*yyvalp).valStatement) = new birch::MemberFunction((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-7)].yystate.yysemantics.yysval.valAnnotation), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_doc_loc((*yylocp))); }
#line 2397 "src/parser.cpp"
    break;

  case 147: /* $@3: %empty  */
#line 524 "src/parser.ypp"
                                                                      { push_raw(); }
#line 2403 "src/parser.cpp"
    break;

  case 148: /* member_function_declaration: FUNCTION name optional_generics parameters optional_return_type $@3 optional_braces  */
#line 524 "src/parser.ypp"
                                                                                                                                  { ((*yyvalp).valStatement) = new birch::MemberFunction(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_doc_loc((*yylocp))); }
#line 2409 "src/parser.cpp"
    break;

  case 149: /* $@4: %empty  */
#line 528 "src/parser.ypp"
                           { push_raw(); }
#line 2415 "src/parser.cpp"
    break;

  case 150: /* program_declaration: PROGRAM name options $@4 optional_braces  */
#line 528 "src/parser.ypp"
                                                            { ((*yyvalp).valStatement) = new birch::Program((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_doc_loc((*yylocp))); }
#line 2421 "src/parser.cpp"
    break;

  case 158: /* $@5: %empty  */
#line 545 "src/parser.ypp"
                                                                                { push_raw(); }
#line 2427 "src/parser.cpp"
    break;

  case 159: /* binary_operator_declaration: OPERATOR '(' parameter binary_operator parameter ')' optional_return_type $@5 optional_braces  */
#line 545 "src/parser.ypp"
                                                                                                                 { ((*yyvalp).valStatement) = new birch::BinaryOperator(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-6)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_doc_loc((*yylocp))); }
#line 2433 "src/parser.cpp"
    break;

  case 160: /* $@6: %empty  */
#line 549 "src/parser.ypp"
                                                                     { push_raw(); }
#line 2439 "src/parser.cpp"
    break;

  case 161: /* unary_operator_declaration: OPERATOR '(' unary_operator parameter ')' optional_return_type $@6 optional_braces  */
#line 549 "src/parser.ypp"
                                                                                                      { ((*yyvalp).valStatement) = new birch::UnaryOperator(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_doc_loc((*yylocp))); }
#line 2445 "src/parser.cpp"
    break;

  case 162: /* $@7: %empty  */
#line 553 "src/parser.ypp"
                                 { push_raw(); }
#line 2451 "src/parser.cpp"
    break;

  case 163: /* assignment_operator_declaration: OPERATOR LEFT_OP parameter $@7 optional_braces  */
#line 553 "src/parser.ypp"
                                                                  { ((*yyvalp).valStatement) = new birch::AssignmentOperator((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_doc_loc((*yylocp))); }
#line 2457 "src/parser.cpp"
    break;

  case 164: /* $@8: %empty  */
#line 557 "src/parser.ypp"
                           { push_raw(); }
#line 2463 "src/parser.cpp"
    break;

  case 165: /* conversion_operator_declaration: OPERATOR return_type $@8 optional_braces  */
#line 557 "src/parser.ypp"
                                                            { ((*yyvalp).valStatement) = new birch::ConversionOperator((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_doc_loc((*yylocp))); }
#line 2469 "src/parser.cpp"
    break;

  case 166: /* $@9: %empty  */
#line 561 "src/parser.ypp"
                                                  { push_raw(); }
#line 2475 "src/parser.cpp"
    break;

  case 167: /* slice_operator_declaration: OPERATOR '[' parameter_list ']' return_type $@9 optional_braces  */
#line 561 "src/parser.ypp"
                                                                                   { ((*yyvalp).valStatement) = new birch::SliceOperator((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_doc_loc((*yylocp))); }
#line 2481 "src/parser.cpp"
    break;

  case 168: /* class_annotation: ABSTRACT  */
#line 565 "src/parser.ypp"
                { ((*yyvalp).valAnnotation) = birch::ABSTRACT; }
#line 2487 "src/parser.cpp"
    break;

  case 169: /* class_annotation: FINAL  */
#line 566 "src/parser.ypp"
                { ((*yyvalp).valAnnotation) = birch::FINAL; }
#line 2493 "src/parser.cpp"
    break;

  case 170: /* class_annotation: ACYCLIC  */
#line 567 "src/parser.ypp"
                { ((*yyvalp).valAnnotation) = birch::ACYCLIC; }
#line 2499 "src/parser.cpp"
    break;

  case 171: /* class_annotation: %empty  */
#line 568 "src/parser.ypp"
                { ((*yyvalp).valAnnotation) = birch::NONE; }
#line 2505 "src/parser.cpp"
    break;

  case 172: /* $@10: %empty  */
#line 572 "src/parser.ypp"
                                                                                                          { push_raw(); }
#line 2511 "src/parser.cpp"
    break;

  case 173: /* class_declaration: class_annotation CLASS name optional_generics optional_parameters '<' named_type optional_arguments $@10 optional_class_braces  */
#line 572 "src/parser.ypp"
                                                                                                                                                 { ((*yyvalp).valStatement) = new birch::Class((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-9)].yystate.yysemantics.yysval.valAnnotation), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-7)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-6)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valType), false, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_doc_loc((*yylocp))); }
#line 2517 "src/parser.cpp"
    break;

  case 174: /* $@11: %empty  */
#line 573 "src/parser.ypp"
                                                                        { push_raw(); }
#line 2523 "src/parser.cpp"
    break;

  case 175: /* class_declaration: class_annotation CLASS name optional_generics optional_parameters $@11 optional_class_braces  */
#line 573 "src/parser.ypp"
                                                                                                                                                 { ((*yyvalp).valStatement) = new birch::Class((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-6)].yystate.yysemantics.yysval.valAnnotation), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valExpression), empty_type((*yylocp)), false, empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_doc_loc((*yylocp))); }
#line 2529 "src/parser.cpp"
    break;

  case 176: /* $@12: %empty  */
#line 574 "src/parser.ypp"
                                                                   { push_raw(); }
#line 2535 "src/parser.cpp"
    break;

  case 177: /* class_declaration: class_annotation CLASS name optional_generics '=' named_type $@12 ';'  */
#line 574 "src/parser.ypp"
                                                                                                                                                 { ((*yyvalp).valStatement) = new birch::Class((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-7)].yystate.yysemantics.yysval.valAnnotation), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yysval.valExpression), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), true, empty_expr((*yylocp)), empty_stmt((*yylocp)), make_doc_loc((*yylocp))); }
#line 2541 "src/parser.cpp"
    break;

  case 178: /* basic_declaration: TYPE name '<' named_type ';'  */
#line 578 "src/parser.ypp"
                                    { push_raw(); ((*yyvalp).valStatement) = new birch::Basic(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valName), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valType), false, make_doc_loc((*yylocp))); }
#line 2547 "src/parser.cpp"
    break;

  case 179: /* basic_declaration: TYPE name '=' named_type ';'  */
#line 579 "src/parser.ypp"
                                    { push_raw(); ((*yyvalp).valStatement) = new birch::Basic(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valName), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valType), true, make_doc_loc((*yylocp))); }
#line 2553 "src/parser.cpp"
    break;

  case 180: /* basic_declaration: TYPE name ';'  */
#line 580 "src/parser.ypp"
                                    { push_raw(); ((*yyvalp).valStatement) = new birch::Basic(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valName), empty_expr((*yylocp)), empty_type((*yylocp)), false, make_doc_loc((*yylocp))); }
#line 2559 "src/parser.cpp"
    break;

  case 181: /* cpp: CPP double_braces  */
#line 584 "src/parser.ypp"
                         { push_raw(); ((*yyvalp).valStatement) = new birch::Raw(new birch::Name("cpp"), pop_raw(), make_loc((*yylocp))); }
#line 2565 "src/parser.cpp"
    break;

  case 182: /* hpp: HPP double_braces  */
#line 588 "src/parser.ypp"
                         { push_raw(); ((*yyvalp).valStatement) = new birch::Raw(new birch::Name("hpp"), pop_raw(), make_loc((*yylocp))); }
#line 2571 "src/parser.cpp"
    break;

  case 183: /* expression_statement: expression ';'  */
#line 592 "src/parser.ypp"
                      { ((*yyvalp).valStatement) = new birch::ExpressionStatement((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2577 "src/parser.cpp"
    break;

  case 184: /* if: IF expression braces ELSE braces  */
#line 596 "src/parser.ypp"
                                        { ((*yyvalp).valStatement) = new birch::If((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2583 "src/parser.cpp"
    break;

  case 185: /* if: IF expression braces ELSE if  */
#line 597 "src/parser.ypp"
                                        { ((*yyvalp).valStatement) = new birch::If((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2589 "src/parser.cpp"
    break;

  case 186: /* if: IF expression braces  */
#line 598 "src/parser.ypp"
                                        { ((*yyvalp).valStatement) = new birch::If((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), empty_stmt((*yylocp)), make_loc((*yylocp))); }
#line 2595 "src/parser.cpp"
    break;

  case 187: /* for_variable_declaration: name  */
#line 602 "src/parser.ypp"
                          { ((*yyvalp).valStatement) = new birch::LocalVariable((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valName), new birch::NamedType(new birch::Name("Integer")), make_loc((*yylocp))); }
#line 2601 "src/parser.cpp"
    break;

  case 188: /* for: FOR for_variable_declaration IN expression RANGE_OP expression braces  */
#line 606 "src/parser.ypp"
                                                                             { ((*yyvalp).valStatement) = new birch::For(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2607 "src/parser.cpp"
    break;

  case 189: /* parallel_annotation: DYNAMIC  */
#line 610 "src/parser.ypp"
               { ((*yyvalp).valAnnotation) = birch::DYNAMIC; }
#line 2613 "src/parser.cpp"
    break;

  case 190: /* parallel: parallel_annotation PARALLEL FOR for_variable_declaration IN expression RANGE_OP expression braces  */
#line 616 "src/parser.ypp"
                                                                                                          { ((*yyvalp).valStatement) = new birch::Parallel((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-8)].yystate.yysemantics.yysval.valAnnotation), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2619 "src/parser.cpp"
    break;

  case 191: /* parallel: PARALLEL FOR for_variable_declaration IN expression RANGE_OP expression braces  */
#line 617 "src/parser.ypp"
                                                                                                          { ((*yyvalp).valStatement) = new birch::Parallel(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yysval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2625 "src/parser.cpp"
    break;

  case 192: /* while: WHILE expression braces  */
#line 621 "src/parser.ypp"
                               { ((*yyvalp).valStatement) = new birch::While((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2631 "src/parser.cpp"
    break;

  case 193: /* do_while: DO braces WHILE expression ';'  */
#line 625 "src/parser.ypp"
                                      { ((*yyvalp).valStatement) = new birch::DoWhile((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2637 "src/parser.cpp"
    break;

  case 194: /* with: WITH expression braces  */
#line 629 "src/parser.ypp"
                              { ((*yyvalp).valStatement) = new birch::With((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2643 "src/parser.cpp"
    break;

  case 195: /* block: braces  */
#line 633 "src/parser.ypp"
              { ((*yyvalp).valStatement) = new birch::Block((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2649 "src/parser.cpp"
    break;

  case 196: /* assertion: ASSERT expression ';'  */
#line 637 "src/parser.ypp"
                             { ((*yyvalp).valStatement) = new birch::Assert((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2655 "src/parser.cpp"
    break;

  case 197: /* return: RETURN optional_expression ';'  */
#line 641 "src/parser.ypp"
                                      { ((*yyvalp).valStatement) = new birch::Return((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2661 "src/parser.cpp"
    break;

  case 198: /* factor: FACTOR optional_expression ';'  */
#line 645 "src/parser.ypp"
                                      { ((*yyvalp).valStatement) = new birch::Factor((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valExpression), make_loc((*yylocp))); }
#line 2667 "src/parser.cpp"
    break;

  case 213: /* statements: statement statements  */
#line 666 "src/parser.ypp"
                            { ((*yyvalp).valStatement) = new birch::StatementList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2673 "src/parser.cpp"
    break;

  case 215: /* optional_statements: %empty  */
#line 671 "src/parser.ypp"
                  { ((*yyvalp).valStatement) = empty_stmt((*yylocp)); }
#line 2679 "src/parser.cpp"
    break;

  case 223: /* class_statements: class_statement class_statements  */
#line 685 "src/parser.ypp"
                                        { ((*yyvalp).valStatement) = new birch::StatementList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2685 "src/parser.cpp"
    break;

  case 225: /* optional_class_statements: %empty  */
#line 690 "src/parser.ypp"
                        { ((*yyvalp).valStatement) = empty_stmt((*yylocp)); }
#line 2691 "src/parser.cpp"
    break;

  case 236: /* file_statements: file_statement file_statements  */
#line 707 "src/parser.ypp"
                                      { ((*yyvalp).valStatement) = new birch::StatementList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2697 "src/parser.cpp"
    break;

  case 238: /* optional_file_statements: %empty  */
#line 712 "src/parser.ypp"
                       { ((*yyvalp).valStatement) = empty_stmt((*yylocp)); }
#line 2703 "src/parser.cpp"
    break;

  case 239: /* file: optional_file_statements  */
#line 716 "src/parser.ypp"
                                { compiler->setRoot((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valStatement)); }
#line 2709 "src/parser.cpp"
    break;

  case 240: /* return_type: RIGHT_OP type  */
#line 720 "src/parser.ypp"
                     { ((*yyvalp).valType) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valType); }
#line 2715 "src/parser.cpp"
    break;

  case 242: /* optional_return_type: %empty  */
#line 725 "src/parser.ypp"
                   { ((*yyvalp).valType) = empty_type((*yylocp)); }
#line 2721 "src/parser.cpp"
    break;

  case 243: /* braces: '{' optional_statements '}'  */
#line 729 "src/parser.ypp"
                                   { ((*yyvalp).valStatement) = new birch::Braces((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2727 "src/parser.cpp"
    break;

  case 245: /* optional_braces: ';'  */
#line 734 "src/parser.ypp"
              { ((*yyvalp).valStatement) = empty_stmt((*yylocp)); }
#line 2733 "src/parser.cpp"
    break;

  case 246: /* class_braces: '{' optional_class_statements '}'  */
#line 738 "src/parser.ypp"
                                         { ((*yyvalp).valStatement) = new birch::Braces((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valStatement), make_loc((*yylocp))); }
#line 2739 "src/parser.cpp"
    break;

  case 248: /* optional_class_braces: ';'  */
#line 743 "src/parser.ypp"
                    { ((*yyvalp).valStatement) = empty_stmt((*yylocp)); }
#line 2745 "src/parser.cpp"
    break;

  case 250: /* named_type: name optional_generic_arguments  */
#line 756 "src/parser.ypp"
                                           { ((*yyvalp).valType) = new birch::NamedType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valType), make_loc((*yylocp))); }
#line 2751 "src/parser.cpp"
    break;

  case 251: /* named_type: name optional_generic_arguments '&'  */
#line 757 "src/parser.ypp"
                                           { yywarn("using weak pointers is no longer necessary"); ((*yyvalp).valType) = new birch::NamedType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valType), make_loc((*yylocp))); }
#line 2757 "src/parser.cpp"
    break;

  case 253: /* primary_type: '(' type_list ')'  */
#line 762 "src/parser.ypp"
                         { ((*yyvalp).valType) = new birch::TupleType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valType), make_loc((*yylocp))); }
#line 2763 "src/parser.cpp"
    break;

  case 255: /* type: type '?'  */
#line 767 "src/parser.ypp"
                                                            { ((*yyvalp).valType) = new birch::OptionalType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valType), make_loc((*yylocp))); }
#line 2769 "src/parser.cpp"
    break;

  case 256: /* type: named_type '.' named_type  */
#line 768 "src/parser.ypp"
                                                            { ((*yyvalp).valType) = new birch::MemberType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valType), make_loc((*yylocp))); }
#line 2775 "src/parser.cpp"
    break;

  case 257: /* type: type '[' shape ']'  */
#line 769 "src/parser.ypp"
                                                            { ((*yyvalp).valType) = new birch::ArrayType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.valInt), make_loc((*yylocp))); }
#line 2781 "src/parser.cpp"
    break;

  case 258: /* type: '\\' '(' optional_type_list ')' optional_return_type  */
#line 770 "src/parser.ypp"
                                                            { ((*yyvalp).valType) = new birch::FunctionType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valType), make_loc((*yylocp))); }
#line 2787 "src/parser.cpp"
    break;

  case 260: /* type_list: type ',' type_list  */
#line 775 "src/parser.ypp"
                          { ((*yyvalp).valType) = new birch::TypeList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yysval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.valType), make_loc((*yylocp))); }
#line 2793 "src/parser.cpp"
    break;

  case 262: /* optional_type_list: %empty  */
#line 780 "src/parser.ypp"
                 { ((*yyvalp).valType) = empty_type((*yylocp)); }
#line 2799 "src/parser.cpp"
    break;


#line 2803 "src/parser.cpp"

      default: break;
    }

  return yyok;
# undef yyerrok
# undef YYABORT
# undef YYACCEPT
# undef YYERROR
# undef YYBACKUP
# undef yyclearin
# undef YYRECOVERING
}


static void
yyuserMerge (int yyn, YYSTYPE* yy0, YYSTYPE* yy1)
{
  YYUSE (yy0);
  YYUSE (yy1);

  switch (yyn)
    {

      default: break;
    }
}

                              /* Bison grammar-table manipulation.  */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
{
  YYUSE (yyvaluep);
  YYUSE (yylocationp);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}

/** Number of symbols composing the right hand side of rule #RULE.  */
static inline int
yyrhsLength (yyRuleNum yyrule)
{
  return yyr2[yyrule];
}

static void
yydestroyGLRState (char const *yymsg, yyGLRState *yys)
{
  if (yys->yyresolved)
    yydestruct (yymsg, yy_accessing_symbol (yys->yylrState),
                &yys->yysemantics.yysval, &yys->yyloc);
  else
    {
#if YYDEBUG
      if (yydebug)
        {
          if (yys->yysemantics.yyfirstVal)
            YY_FPRINTF ((stderr, "%s unresolved", yymsg));
          else
            YY_FPRINTF ((stderr, "%s incomplete", yymsg));
          YY_SYMBOL_PRINT ("", yy_accessing_symbol (yys->yylrState), YY_NULLPTR, &yys->yyloc);
        }
#endif

      if (yys->yysemantics.yyfirstVal)
        {
          yySemanticOption *yyoption = yys->yysemantics.yyfirstVal;
          yyGLRState *yyrh;
          int yyn;
          for (yyrh = yyoption->yystate, yyn = yyrhsLength (yyoption->yyrule);
               yyn > 0;
               yyrh = yyrh->yypred, yyn -= 1)
            yydestroyGLRState (yymsg, yyrh);
        }
    }
}

/** Left-hand-side symbol for rule #YYRULE.  */
static inline yysymbol_kind_t
yylhsNonterm (yyRuleNum yyrule)
{
  return YY_CAST (yysymbol_kind_t, yyr1[yyrule]);
}

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

/** True iff LR state YYSTATE has only a default reduction (regardless
 *  of token).  */
static inline yybool
yyisDefaultedState (yy_state_t yystate)
{
  return yypact_value_is_default (yypact[yystate]);
}

/** The default reduction for YYSTATE, assuming it has one.  */
static inline yyRuleNum
yydefaultAction (yy_state_t yystate)
{
  return yydefact[yystate];
}

#define yytable_value_is_error(Yyn) \
  0

/** The action to take in YYSTATE on seeing YYTOKEN.
 *  Result R means
 *    R < 0:  Reduce on rule -R.
 *    R = 0:  Error.
 *    R > 0:  Shift to state R.
 *  Set *YYCONFLICTS to a pointer into yyconfl to a 0-terminated list
 *  of conflicting reductions.
 */
static inline int
yygetLRActions (yy_state_t yystate, yysymbol_kind_t yytoken, const short** yyconflicts)
{
  int yyindex = yypact[yystate] + yytoken;
  if (yytoken == YYSYMBOL_YYerror)
    {
      // This is the error token.
      *yyconflicts = yyconfl;
      return 0;
    }
  else if (yyisDefaultedState (yystate)
           || yyindex < 0 || YYLAST < yyindex || yycheck[yyindex] != yytoken)
    {
      *yyconflicts = yyconfl;
      return -yydefact[yystate];
    }
  else if (! yytable_value_is_error (yytable[yyindex]))
    {
      *yyconflicts = yyconfl + yyconflp[yyindex];
      return yytable[yyindex];
    }
  else
    {
      *yyconflicts = yyconfl + yyconflp[yyindex];
      return 0;
    }
}

/** Compute post-reduction state.
 * \param yystate   the current state
 * \param yysym     the nonterminal to push on the stack
 */
static inline yy_state_t
yyLRgotoState (yy_state_t yystate, yysymbol_kind_t yysym)
{
  int yyr = yypgoto[yysym - YYNTOKENS] + yystate;
  if (0 <= yyr && yyr <= YYLAST && yycheck[yyr] == yystate)
    return yytable[yyr];
  else
    return yydefgoto[yysym - YYNTOKENS];
}

static inline yybool
yyisShiftAction (int yyaction)
{
  return 0 < yyaction;
}

static inline yybool
yyisErrorAction (int yyaction)
{
  return yyaction == 0;
}

                                /* GLRStates */

/** Return a fresh GLRStackItem in YYSTACKP.  The item is an LR state
 *  if YYISSTATE, and otherwise a semantic option.  Callers should call
 *  YY_RESERVE_GLRSTACK afterwards to make sure there is sufficient
 *  headroom.  */

static inline yyGLRStackItem*
yynewGLRStackItem (yyGLRStack* yystackp, yybool yyisState)
{
  yyGLRStackItem* yynewItem = yystackp->yynextFree;
  yystackp->yyspaceLeft -= 1;
  yystackp->yynextFree += 1;
  yynewItem->yystate.yyisState = yyisState;
  return yynewItem;
}

/** Add a new semantic action that will execute the action for rule
 *  YYRULE on the semantic values in YYRHS to the list of
 *  alternative actions for YYSTATE.  Assumes that YYRHS comes from
 *  stack #YYK of *YYSTACKP. */
static void
yyaddDeferredAction (yyGLRStack* yystackp, YYPTRDIFF_T yyk, yyGLRState* yystate,
                     yyGLRState* yyrhs, yyRuleNum yyrule)
{
  yySemanticOption* yynewOption =
    &yynewGLRStackItem (yystackp, yyfalse)->yyoption;
  YY_ASSERT (!yynewOption->yyisState);
  yynewOption->yystate = yyrhs;
  yynewOption->yyrule = yyrule;
  if (yystackp->yytops.yylookaheadNeeds[yyk])
    {
      yynewOption->yyrawchar = yychar;
      yynewOption->yyval = yylval;
      yynewOption->yyloc = yylloc;
    }
  else
    yynewOption->yyrawchar = YYEMPTY;
  yynewOption->yynext = yystate->yysemantics.yyfirstVal;
  yystate->yysemantics.yyfirstVal = yynewOption;

  YY_RESERVE_GLRSTACK (yystackp);
}

                                /* GLRStacks */

/** Initialize YYSET to a singleton set containing an empty stack.  */
static yybool
yyinitStateSet (yyGLRStateSet* yyset)
{
  yyset->yysize = 1;
  yyset->yycapacity = 16;
  yyset->yystates
    = YY_CAST (yyGLRState**,
               YYMALLOC (YY_CAST (YYSIZE_T, yyset->yycapacity)
                         * sizeof yyset->yystates[0]));
  if (! yyset->yystates)
    return yyfalse;
  yyset->yystates[0] = YY_NULLPTR;
  yyset->yylookaheadNeeds
    = YY_CAST (yybool*,
               YYMALLOC (YY_CAST (YYSIZE_T, yyset->yycapacity)
                         * sizeof yyset->yylookaheadNeeds[0]));
  if (! yyset->yylookaheadNeeds)
    {
      YYFREE (yyset->yystates);
      return yyfalse;
    }
  memset (yyset->yylookaheadNeeds,
          0,
          YY_CAST (YYSIZE_T, yyset->yycapacity) * sizeof yyset->yylookaheadNeeds[0]);
  return yytrue;
}

static void yyfreeStateSet (yyGLRStateSet* yyset)
{
  YYFREE (yyset->yystates);
  YYFREE (yyset->yylookaheadNeeds);
}

/** Initialize *YYSTACKP to a single empty stack, with total maximum
 *  capacity for all stacks of YYSIZE.  */
static yybool
yyinitGLRStack (yyGLRStack* yystackp, YYPTRDIFF_T yysize)
{
  yystackp->yyerrState = 0;
  yynerrs = 0;
  yystackp->yyspaceLeft = yysize;
  yystackp->yyitems
    = YY_CAST (yyGLRStackItem*,
               YYMALLOC (YY_CAST (YYSIZE_T, yysize)
                         * sizeof yystackp->yynextFree[0]));
  if (!yystackp->yyitems)
    return yyfalse;
  yystackp->yynextFree = yystackp->yyitems;
  yystackp->yysplitPoint = YY_NULLPTR;
  yystackp->yylastDeleted = YY_NULLPTR;
  return yyinitStateSet (&yystackp->yytops);
}


#if YYSTACKEXPANDABLE
# define YYRELOC(YYFROMITEMS, YYTOITEMS, YYX, YYTYPE)                   \
  &((YYTOITEMS)                                                         \
    - ((YYFROMITEMS) - YY_REINTERPRET_CAST (yyGLRStackItem*, (YYX))))->YYTYPE

/** If *YYSTACKP is expandable, extend it.  WARNING: Pointers into the
    stack from outside should be considered invalid after this call.
    We always expand when there are 1 or fewer items left AFTER an
    allocation, so that we can avoid having external pointers exist
    across an allocation.  */
static void
yyexpandGLRStack (yyGLRStack* yystackp)
{
  yyGLRStackItem* yynewItems;
  yyGLRStackItem* yyp0, *yyp1;
  YYPTRDIFF_T yynewSize;
  YYPTRDIFF_T yyn;
  YYPTRDIFF_T yysize = yystackp->yynextFree - yystackp->yyitems;
  if (YYMAXDEPTH - YYHEADROOM < yysize)
    yyMemoryExhausted (yystackp);
  yynewSize = 2*yysize;
  if (YYMAXDEPTH < yynewSize)
    yynewSize = YYMAXDEPTH;
  yynewItems
    = YY_CAST (yyGLRStackItem*,
               YYMALLOC (YY_CAST (YYSIZE_T, yynewSize)
                         * sizeof yynewItems[0]));
  if (! yynewItems)
    yyMemoryExhausted (yystackp);
  for (yyp0 = yystackp->yyitems, yyp1 = yynewItems, yyn = yysize;
       0 < yyn;
       yyn -= 1, yyp0 += 1, yyp1 += 1)
    {
      *yyp1 = *yyp0;
      if (*YY_REINTERPRET_CAST (yybool *, yyp0))
        {
          yyGLRState* yys0 = &yyp0->yystate;
          yyGLRState* yys1 = &yyp1->yystate;
          if (yys0->yypred != YY_NULLPTR)
            yys1->yypred =
              YYRELOC (yyp0, yyp1, yys0->yypred, yystate);
          if (! yys0->yyresolved && yys0->yysemantics.yyfirstVal != YY_NULLPTR)
            yys1->yysemantics.yyfirstVal =
              YYRELOC (yyp0, yyp1, yys0->yysemantics.yyfirstVal, yyoption);
        }
      else
        {
          yySemanticOption* yyv0 = &yyp0->yyoption;
          yySemanticOption* yyv1 = &yyp1->yyoption;
          if (yyv0->yystate != YY_NULLPTR)
            yyv1->yystate = YYRELOC (yyp0, yyp1, yyv0->yystate, yystate);
          if (yyv0->yynext != YY_NULLPTR)
            yyv1->yynext = YYRELOC (yyp0, yyp1, yyv0->yynext, yyoption);
        }
    }
  if (yystackp->yysplitPoint != YY_NULLPTR)
    yystackp->yysplitPoint = YYRELOC (yystackp->yyitems, yynewItems,
                                      yystackp->yysplitPoint, yystate);

  for (yyn = 0; yyn < yystackp->yytops.yysize; yyn += 1)
    if (yystackp->yytops.yystates[yyn] != YY_NULLPTR)
      yystackp->yytops.yystates[yyn] =
        YYRELOC (yystackp->yyitems, yynewItems,
                 yystackp->yytops.yystates[yyn], yystate);
  YYFREE (yystackp->yyitems);
  yystackp->yyitems = yynewItems;
  yystackp->yynextFree = yynewItems + yysize;
  yystackp->yyspaceLeft = yynewSize - yysize;
}
#endif

static void
yyfreeGLRStack (yyGLRStack* yystackp)
{
  YYFREE (yystackp->yyitems);
  yyfreeStateSet (&yystackp->yytops);
}

/** Assuming that YYS is a GLRState somewhere on *YYSTACKP, update the
 *  splitpoint of *YYSTACKP, if needed, so that it is at least as deep as
 *  YYS.  */
static inline void
yyupdateSplit (yyGLRStack* yystackp, yyGLRState* yys)
{
  if (yystackp->yysplitPoint != YY_NULLPTR && yystackp->yysplitPoint > yys)
    yystackp->yysplitPoint = yys;
}

/** Invalidate stack #YYK in *YYSTACKP.  */
static inline void
yymarkStackDeleted (yyGLRStack* yystackp, YYPTRDIFF_T yyk)
{
  if (yystackp->yytops.yystates[yyk] != YY_NULLPTR)
    yystackp->yylastDeleted = yystackp->yytops.yystates[yyk];
  yystackp->yytops.yystates[yyk] = YY_NULLPTR;
}

/** Undelete the last stack in *YYSTACKP that was marked as deleted.  Can
    only be done once after a deletion, and only when all other stacks have
    been deleted.  */
static void
yyundeleteLastStack (yyGLRStack* yystackp)
{
  if (yystackp->yylastDeleted == YY_NULLPTR || yystackp->yytops.yysize != 0)
    return;
  yystackp->yytops.yystates[0] = yystackp->yylastDeleted;
  yystackp->yytops.yysize = 1;
  YY_DPRINTF ((stderr, "Restoring last deleted stack as stack #0.\n"));
  yystackp->yylastDeleted = YY_NULLPTR;
}

static inline void
yyremoveDeletes (yyGLRStack* yystackp)
{
  YYPTRDIFF_T yyi, yyj;
  yyi = yyj = 0;
  while (yyj < yystackp->yytops.yysize)
    {
      if (yystackp->yytops.yystates[yyi] == YY_NULLPTR)
        {
          if (yyi == yyj)
            YY_DPRINTF ((stderr, "Removing dead stacks.\n"));
          yystackp->yytops.yysize -= 1;
        }
      else
        {
          yystackp->yytops.yystates[yyj] = yystackp->yytops.yystates[yyi];
          /* In the current implementation, it's unnecessary to copy
             yystackp->yytops.yylookaheadNeeds[yyi] since, after
             yyremoveDeletes returns, the parser immediately either enters
             deterministic operation or shifts a token.  However, it doesn't
             hurt, and the code might evolve to need it.  */
          yystackp->yytops.yylookaheadNeeds[yyj] =
            yystackp->yytops.yylookaheadNeeds[yyi];
          if (yyj != yyi)
            YY_DPRINTF ((stderr, "Rename stack %ld -> %ld.\n",
                        YY_CAST (long, yyi), YY_CAST (long, yyj)));
          yyj += 1;
        }
      yyi += 1;
    }
}

/** Shift to a new state on stack #YYK of *YYSTACKP, corresponding to LR
 * state YYLRSTATE, at input position YYPOSN, with (resolved) semantic
 * value *YYVALP and source location *YYLOCP.  */
static inline void
yyglrShift (yyGLRStack* yystackp, YYPTRDIFF_T yyk, yy_state_t yylrState,
            YYPTRDIFF_T yyposn,
            YYSTYPE* yyvalp, YYLTYPE* yylocp)
{
  yyGLRState* yynewState = &yynewGLRStackItem (yystackp, yytrue)->yystate;

  yynewState->yylrState = yylrState;
  yynewState->yyposn = yyposn;
  yynewState->yyresolved = yytrue;
  yynewState->yypred = yystackp->yytops.yystates[yyk];
  yynewState->yysemantics.yysval = *yyvalp;
  yynewState->yyloc = *yylocp;
  yystackp->yytops.yystates[yyk] = yynewState;

  YY_RESERVE_GLRSTACK (yystackp);
}

/** Shift stack #YYK of *YYSTACKP, to a new state corresponding to LR
 *  state YYLRSTATE, at input position YYPOSN, with the (unresolved)
 *  semantic value of YYRHS under the action for YYRULE.  */
static inline void
yyglrShiftDefer (yyGLRStack* yystackp, YYPTRDIFF_T yyk, yy_state_t yylrState,
                 YYPTRDIFF_T yyposn, yyGLRState* yyrhs, yyRuleNum yyrule)
{
  yyGLRState* yynewState = &yynewGLRStackItem (yystackp, yytrue)->yystate;
  YY_ASSERT (yynewState->yyisState);

  yynewState->yylrState = yylrState;
  yynewState->yyposn = yyposn;
  yynewState->yyresolved = yyfalse;
  yynewState->yypred = yystackp->yytops.yystates[yyk];
  yynewState->yysemantics.yyfirstVal = YY_NULLPTR;
  yystackp->yytops.yystates[yyk] = yynewState;

  /* Invokes YY_RESERVE_GLRSTACK.  */
  yyaddDeferredAction (yystackp, yyk, yynewState, yyrhs, yyrule);
}

#if !YYDEBUG
# define YY_REDUCE_PRINT(Args)
#else
# define YY_REDUCE_PRINT(Args)          \
  do {                                  \
    if (yydebug)                        \
      yy_reduce_print Args;             \
  } while (0)

/*----------------------------------------------------------------------.
| Report that stack #YYK of *YYSTACKP is going to be reduced by YYRULE. |
`----------------------------------------------------------------------*/

static inline void
yy_reduce_print (yybool yynormal, yyGLRStackItem* yyvsp, YYPTRDIFF_T yyk,
                 yyRuleNum yyrule)
{
  int yynrhs = yyrhsLength (yyrule);
  int yylow = 1;
  int yyi;
  YY_FPRINTF ((stderr, "Reducing stack %ld by rule %d (line %d):\n",
               YY_CAST (long, yyk), yyrule - 1, yyrline[yyrule]));
  if (! yynormal)
    yyfillin (yyvsp, 1, -yynrhs);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YY_FPRINTF ((stderr, "   $%d = ", yyi + 1));
      yy_symbol_print (stderr,
                       yy_accessing_symbol (yyvsp[yyi - yynrhs + 1].yystate.yylrState),
                       &yyvsp[yyi - yynrhs + 1].yystate.yysemantics.yysval,
                       &(YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL ((yyi + 1) - (yynrhs))].yystate.yyloc)                       );
      if (!yyvsp[yyi - yynrhs + 1].yystate.yyresolved)
        YY_FPRINTF ((stderr, " (unresolved)"));
      YY_FPRINTF ((stderr, "\n"));
    }
}
#endif

/** Pop the symbols consumed by reduction #YYRULE from the top of stack
 *  #YYK of *YYSTACKP, and perform the appropriate semantic action on their
 *  semantic values.  Assumes that all ambiguities in semantic values
 *  have been previously resolved.  Set *YYVALP to the resulting value,
 *  and *YYLOCP to the computed location (if any).  Return value is as
 *  for userAction.  */
static inline YYRESULTTAG
yydoAction (yyGLRStack* yystackp, YYPTRDIFF_T yyk, yyRuleNum yyrule,
            YYSTYPE* yyvalp, YYLTYPE *yylocp)
{
  int yynrhs = yyrhsLength (yyrule);

  if (yystackp->yysplitPoint == YY_NULLPTR)
    {
      /* Standard special case: single stack.  */
      yyGLRStackItem* yyrhs
        = YY_REINTERPRET_CAST (yyGLRStackItem*, yystackp->yytops.yystates[yyk]);
      YY_ASSERT (yyk == 0);
      yystackp->yynextFree -= yynrhs;
      yystackp->yyspaceLeft += yynrhs;
      yystackp->yytops.yystates[0] = & yystackp->yynextFree[-1].yystate;
      YY_REDUCE_PRINT ((yytrue, yyrhs, yyk, yyrule));
      return yyuserAction (yyrule, yynrhs, yyrhs, yystackp,
                           yyvalp, yylocp);
    }
  else
    {
      yyGLRStackItem yyrhsVals[YYMAXRHS + YYMAXLEFT + 1];
      yyGLRState* yys = yyrhsVals[YYMAXRHS + YYMAXLEFT].yystate.yypred
        = yystackp->yytops.yystates[yyk];
      int yyi;
      if (yynrhs == 0)
        /* Set default location.  */
        yyrhsVals[YYMAXRHS + YYMAXLEFT - 1].yystate.yyloc = yys->yyloc;
      for (yyi = 0; yyi < yynrhs; yyi += 1)
        {
          yys = yys->yypred;
          YY_ASSERT (yys);
        }
      yyupdateSplit (yystackp, yys);
      yystackp->yytops.yystates[yyk] = yys;
      YY_REDUCE_PRINT ((yyfalse, yyrhsVals + YYMAXRHS + YYMAXLEFT - 1, yyk, yyrule));
      return yyuserAction (yyrule, yynrhs, yyrhsVals + YYMAXRHS + YYMAXLEFT - 1,
                           yystackp, yyvalp, yylocp);
    }
}

/** Pop items off stack #YYK of *YYSTACKP according to grammar rule YYRULE,
 *  and push back on the resulting nonterminal symbol.  Perform the
 *  semantic action associated with YYRULE and store its value with the
 *  newly pushed state, if YYFORCEEVAL or if *YYSTACKP is currently
 *  unambiguous.  Otherwise, store the deferred semantic action with
 *  the new state.  If the new state would have an identical input
 *  position, LR state, and predecessor to an existing state on the stack,
 *  it is identified with that existing state, eliminating stack #YYK from
 *  *YYSTACKP.  In this case, the semantic value is
 *  added to the options for the existing state's semantic value.
 */
static inline YYRESULTTAG
yyglrReduce (yyGLRStack* yystackp, YYPTRDIFF_T yyk, yyRuleNum yyrule,
             yybool yyforceEval)
{
  YYPTRDIFF_T yyposn = yystackp->yytops.yystates[yyk]->yyposn;

  if (yyforceEval || yystackp->yysplitPoint == YY_NULLPTR)
    {
      YYSTYPE yysval;
      YYLTYPE yyloc;

      YYRESULTTAG yyflag = yydoAction (yystackp, yyk, yyrule, &yysval, &yyloc);
      if (yyflag == yyerr && yystackp->yysplitPoint != YY_NULLPTR)
        YY_DPRINTF ((stderr,
                     "Parse on stack %ld rejected by rule %d (line %d).\n",
                     YY_CAST (long, yyk), yyrule - 1, yyrline[yyrule - 1]));
      if (yyflag != yyok)
        return yyflag;
      YY_SYMBOL_PRINT ("-> $$ =", yylhsNonterm (yyrule), &yysval, &yyloc);
      yyglrShift (yystackp, yyk,
                  yyLRgotoState (yystackp->yytops.yystates[yyk]->yylrState,
                                 yylhsNonterm (yyrule)),
                  yyposn, &yysval, &yyloc);
    }
  else
    {
      YYPTRDIFF_T yyi;
      int yyn;
      yyGLRState* yys, *yys0 = yystackp->yytops.yystates[yyk];
      yy_state_t yynewLRState;

      for (yys = yystackp->yytops.yystates[yyk], yyn = yyrhsLength (yyrule);
           0 < yyn; yyn -= 1)
        {
          yys = yys->yypred;
          YY_ASSERT (yys);
        }
      yyupdateSplit (yystackp, yys);
      yynewLRState = yyLRgotoState (yys->yylrState, yylhsNonterm (yyrule));
      YY_DPRINTF ((stderr,
                   "Reduced stack %ld by rule %d (line %d); action deferred.  "
                   "Now in state %d.\n",
                   YY_CAST (long, yyk), yyrule - 1, yyrline[yyrule - 1],
                   yynewLRState));
      for (yyi = 0; yyi < yystackp->yytops.yysize; yyi += 1)
        if (yyi != yyk && yystackp->yytops.yystates[yyi] != YY_NULLPTR)
          {
            yyGLRState *yysplit = yystackp->yysplitPoint;
            yyGLRState *yyp = yystackp->yytops.yystates[yyi];
            while (yyp != yys && yyp != yysplit && yyp->yyposn >= yyposn)
              {
                if (yyp->yylrState == yynewLRState && yyp->yypred == yys)
                  {
                    yyaddDeferredAction (yystackp, yyk, yyp, yys0, yyrule);
                    yymarkStackDeleted (yystackp, yyk);
                    YY_DPRINTF ((stderr, "Merging stack %ld into stack %ld.\n",
                                 YY_CAST (long, yyk), YY_CAST (long, yyi)));
                    return yyok;
                  }
                yyp = yyp->yypred;
              }
          }
      yystackp->yytops.yystates[yyk] = yys;
      yyglrShiftDefer (yystackp, yyk, yynewLRState, yyposn, yys0, yyrule);
    }
  return yyok;
}

static YYPTRDIFF_T
yysplitStack (yyGLRStack* yystackp, YYPTRDIFF_T yyk)
{
  if (yystackp->yysplitPoint == YY_NULLPTR)
    {
      YY_ASSERT (yyk == 0);
      yystackp->yysplitPoint = yystackp->yytops.yystates[yyk];
    }
  if (yystackp->yytops.yycapacity <= yystackp->yytops.yysize)
    {
      YYPTRDIFF_T state_size = YYSIZEOF (yystackp->yytops.yystates[0]);
      YYPTRDIFF_T half_max_capacity = YYSIZE_MAXIMUM / 2 / state_size;
      if (half_max_capacity < yystackp->yytops.yycapacity)
        yyMemoryExhausted (yystackp);
      yystackp->yytops.yycapacity *= 2;

      {
        yyGLRState** yynewStates
          = YY_CAST (yyGLRState**,
                     YYREALLOC (yystackp->yytops.yystates,
                                (YY_CAST (YYSIZE_T, yystackp->yytops.yycapacity)
                                 * sizeof yynewStates[0])));
        if (yynewStates == YY_NULLPTR)
          yyMemoryExhausted (yystackp);
        yystackp->yytops.yystates = yynewStates;
      }

      {
        yybool* yynewLookaheadNeeds
          = YY_CAST (yybool*,
                     YYREALLOC (yystackp->yytops.yylookaheadNeeds,
                                (YY_CAST (YYSIZE_T, yystackp->yytops.yycapacity)
                                 * sizeof yynewLookaheadNeeds[0])));
        if (yynewLookaheadNeeds == YY_NULLPTR)
          yyMemoryExhausted (yystackp);
        yystackp->yytops.yylookaheadNeeds = yynewLookaheadNeeds;
      }
    }
  yystackp->yytops.yystates[yystackp->yytops.yysize]
    = yystackp->yytops.yystates[yyk];
  yystackp->yytops.yylookaheadNeeds[yystackp->yytops.yysize]
    = yystackp->yytops.yylookaheadNeeds[yyk];
  yystackp->yytops.yysize += 1;
  return yystackp->yytops.yysize - 1;
}

/** True iff YYY0 and YYY1 represent identical options at the top level.
 *  That is, they represent the same rule applied to RHS symbols
 *  that produce the same terminal symbols.  */
static yybool
yyidenticalOptions (yySemanticOption* yyy0, yySemanticOption* yyy1)
{
  if (yyy0->yyrule == yyy1->yyrule)
    {
      yyGLRState *yys0, *yys1;
      int yyn;
      for (yys0 = yyy0->yystate, yys1 = yyy1->yystate,
           yyn = yyrhsLength (yyy0->yyrule);
           yyn > 0;
           yys0 = yys0->yypred, yys1 = yys1->yypred, yyn -= 1)
        if (yys0->yyposn != yys1->yyposn)
          return yyfalse;
      return yytrue;
    }
  else
    return yyfalse;
}

/** Assuming identicalOptions (YYY0,YYY1), destructively merge the
 *  alternative semantic values for the RHS-symbols of YYY1 and YYY0.  */
static void
yymergeOptionSets (yySemanticOption* yyy0, yySemanticOption* yyy1)
{
  yyGLRState *yys0, *yys1;
  int yyn;
  for (yys0 = yyy0->yystate, yys1 = yyy1->yystate,
       yyn = yyrhsLength (yyy0->yyrule);
       0 < yyn;
       yys0 = yys0->yypred, yys1 = yys1->yypred, yyn -= 1)
    {
      if (yys0 == yys1)
        break;
      else if (yys0->yyresolved)
        {
          yys1->yyresolved = yytrue;
          yys1->yysemantics.yysval = yys0->yysemantics.yysval;
        }
      else if (yys1->yyresolved)
        {
          yys0->yyresolved = yytrue;
          yys0->yysemantics.yysval = yys1->yysemantics.yysval;
        }
      else
        {
          yySemanticOption** yyz0p = &yys0->yysemantics.yyfirstVal;
          yySemanticOption* yyz1 = yys1->yysemantics.yyfirstVal;
          while (yytrue)
            {
              if (yyz1 == *yyz0p || yyz1 == YY_NULLPTR)
                break;
              else if (*yyz0p == YY_NULLPTR)
                {
                  *yyz0p = yyz1;
                  break;
                }
              else if (*yyz0p < yyz1)
                {
                  yySemanticOption* yyz = *yyz0p;
                  *yyz0p = yyz1;
                  yyz1 = yyz1->yynext;
                  (*yyz0p)->yynext = yyz;
                }
              yyz0p = &(*yyz0p)->yynext;
            }
          yys1->yysemantics.yyfirstVal = yys0->yysemantics.yyfirstVal;
        }
    }
}

/** Y0 and Y1 represent two possible actions to take in a given
 *  parsing state; return 0 if no combination is possible,
 *  1 if user-mergeable, 2 if Y0 is preferred, 3 if Y1 is preferred.  */
static int
yypreference (yySemanticOption* y0, yySemanticOption* y1)
{
  yyRuleNum r0 = y0->yyrule, r1 = y1->yyrule;
  int p0 = yydprec[r0], p1 = yydprec[r1];

  if (p0 == p1)
    {
      if (yymerger[r0] == 0 || yymerger[r0] != yymerger[r1])
        return 0;
      else
        return 1;
    }
  if (p0 == 0 || p1 == 0)
    return 0;
  if (p0 < p1)
    return 3;
  if (p1 < p0)
    return 2;
  return 0;
}

static YYRESULTTAG yyresolveValue (yyGLRState* yys,
                                   yyGLRStack* yystackp);


/** Resolve the previous YYN states starting at and including state YYS
 *  on *YYSTACKP. If result != yyok, some states may have been left
 *  unresolved possibly with empty semantic option chains.  Regardless
 *  of whether result = yyok, each state has been left with consistent
 *  data so that yydestroyGLRState can be invoked if necessary.  */
static YYRESULTTAG
yyresolveStates (yyGLRState* yys, int yyn,
                 yyGLRStack* yystackp)
{
  if (0 < yyn)
    {
      YY_ASSERT (yys->yypred);
      YYCHK (yyresolveStates (yys->yypred, yyn-1, yystackp));
      if (! yys->yyresolved)
        YYCHK (yyresolveValue (yys, yystackp));
    }
  return yyok;
}

/** Resolve the states for the RHS of YYOPT on *YYSTACKP, perform its
 *  user action, and return the semantic value and location in *YYVALP
 *  and *YYLOCP.  Regardless of whether result = yyok, all RHS states
 *  have been destroyed (assuming the user action destroys all RHS
 *  semantic values if invoked).  */
static YYRESULTTAG
yyresolveAction (yySemanticOption* yyopt, yyGLRStack* yystackp,
                 YYSTYPE* yyvalp, YYLTYPE *yylocp)
{
  yyGLRStackItem yyrhsVals[YYMAXRHS + YYMAXLEFT + 1];
  int yynrhs = yyrhsLength (yyopt->yyrule);
  YYRESULTTAG yyflag =
    yyresolveStates (yyopt->yystate, yynrhs, yystackp);
  if (yyflag != yyok)
    {
      yyGLRState *yys;
      for (yys = yyopt->yystate; yynrhs > 0; yys = yys->yypred, yynrhs -= 1)
        yydestroyGLRState ("Cleanup: popping", yys);
      return yyflag;
    }

  yyrhsVals[YYMAXRHS + YYMAXLEFT].yystate.yypred = yyopt->yystate;
  if (yynrhs == 0)
    /* Set default location.  */
    yyrhsVals[YYMAXRHS + YYMAXLEFT - 1].yystate.yyloc = yyopt->yystate->yyloc;
  {
    int yychar_current = yychar;
    YYSTYPE yylval_current = yylval;
    YYLTYPE yylloc_current = yylloc;
    yychar = yyopt->yyrawchar;
    yylval = yyopt->yyval;
    yylloc = yyopt->yyloc;
    yyflag = yyuserAction (yyopt->yyrule, yynrhs,
                           yyrhsVals + YYMAXRHS + YYMAXLEFT - 1,
                           yystackp, yyvalp, yylocp);
    yychar = yychar_current;
    yylval = yylval_current;
    yylloc = yylloc_current;
  }
  return yyflag;
}

#if YYDEBUG
static void
yyreportTree (yySemanticOption* yyx, int yyindent)
{
  int yynrhs = yyrhsLength (yyx->yyrule);
  int yyi;
  yyGLRState* yys;
  yyGLRState* yystates[1 + YYMAXRHS];
  yyGLRState yyleftmost_state;

  for (yyi = yynrhs, yys = yyx->yystate; 0 < yyi; yyi -= 1, yys = yys->yypred)
    yystates[yyi] = yys;
  if (yys == YY_NULLPTR)
    {
      yyleftmost_state.yyposn = 0;
      yystates[0] = &yyleftmost_state;
    }
  else
    yystates[0] = yys;

  if (yyx->yystate->yyposn < yys->yyposn + 1)
    YY_FPRINTF ((stderr, "%*s%s -> <Rule %d, empty>\n",
                 yyindent, "", yysymbol_name (yylhsNonterm (yyx->yyrule)),
                 yyx->yyrule - 1));
  else
    YY_FPRINTF ((stderr, "%*s%s -> <Rule %d, tokens %ld .. %ld>\n",
                 yyindent, "", yysymbol_name (yylhsNonterm (yyx->yyrule)),
                 yyx->yyrule - 1, YY_CAST (long, yys->yyposn + 1),
                 YY_CAST (long, yyx->yystate->yyposn)));
  for (yyi = 1; yyi <= yynrhs; yyi += 1)
    {
      if (yystates[yyi]->yyresolved)
        {
          if (yystates[yyi-1]->yyposn+1 > yystates[yyi]->yyposn)
            YY_FPRINTF ((stderr, "%*s%s <empty>\n", yyindent+2, "",
                         yysymbol_name (yy_accessing_symbol (yystates[yyi]->yylrState))));
          else
            YY_FPRINTF ((stderr, "%*s%s <tokens %ld .. %ld>\n", yyindent+2, "",
                         yysymbol_name (yy_accessing_symbol (yystates[yyi]->yylrState)),
                         YY_CAST (long, yystates[yyi-1]->yyposn + 1),
                         YY_CAST (long, yystates[yyi]->yyposn)));
        }
      else
        yyreportTree (yystates[yyi]->yysemantics.yyfirstVal, yyindent+2);
    }
}
#endif

static YYRESULTTAG
yyreportAmbiguity (yySemanticOption* yyx0,
                   yySemanticOption* yyx1)
{
  YYUSE (yyx0);
  YYUSE (yyx1);

#if YYDEBUG
  YY_FPRINTF ((stderr, "Ambiguity detected.\n"));
  YY_FPRINTF ((stderr, "Option 1,\n"));
  yyreportTree (yyx0, 2);
  YY_FPRINTF ((stderr, "\nOption 2,\n"));
  yyreportTree (yyx1, 2);
  YY_FPRINTF ((stderr, "\n"));
#endif

  yyerror (YY_("syntax is ambiguous"));
  return yyabort;
}

/** Resolve the locations for each of the YYN1 states in *YYSTACKP,
 *  ending at YYS1.  Has no effect on previously resolved states.
 *  The first semantic option of a state is always chosen.  */
static void
yyresolveLocations (yyGLRState *yys1, int yyn1,
                    yyGLRStack *yystackp)
{
  if (0 < yyn1)
    {
      yyresolveLocations (yys1->yypred, yyn1 - 1, yystackp);
      if (!yys1->yyresolved)
        {
          yyGLRStackItem yyrhsloc[1 + YYMAXRHS];
          int yynrhs;
          yySemanticOption *yyoption = yys1->yysemantics.yyfirstVal;
          YY_ASSERT (yyoption);
          yynrhs = yyrhsLength (yyoption->yyrule);
          if (0 < yynrhs)
            {
              yyGLRState *yys;
              int yyn;
              yyresolveLocations (yyoption->yystate, yynrhs,
                                  yystackp);
              for (yys = yyoption->yystate, yyn = yynrhs;
                   yyn > 0;
                   yys = yys->yypred, yyn -= 1)
                yyrhsloc[yyn].yystate.yyloc = yys->yyloc;
            }
          else
            {
              /* Both yyresolveAction and yyresolveLocations traverse the GSS
                 in reverse rightmost order.  It is only necessary to invoke
                 yyresolveLocations on a subforest for which yyresolveAction
                 would have been invoked next had an ambiguity not been
                 detected.  Thus the location of the previous state (but not
                 necessarily the previous state itself) is guaranteed to be
                 resolved already.  */
              yyGLRState *yyprevious = yyoption->yystate;
              yyrhsloc[0].yystate.yyloc = yyprevious->yyloc;
            }
          YYLLOC_DEFAULT ((yys1->yyloc), yyrhsloc, yynrhs);
        }
    }
}

/** Resolve the ambiguity represented in state YYS in *YYSTACKP,
 *  perform the indicated actions, and set the semantic value of YYS.
 *  If result != yyok, the chain of semantic options in YYS has been
 *  cleared instead or it has been left unmodified except that
 *  redundant options may have been removed.  Regardless of whether
 *  result = yyok, YYS has been left with consistent data so that
 *  yydestroyGLRState can be invoked if necessary.  */
static YYRESULTTAG
yyresolveValue (yyGLRState* yys, yyGLRStack* yystackp)
{
  yySemanticOption* yyoptionList = yys->yysemantics.yyfirstVal;
  yySemanticOption* yybest = yyoptionList;
  yySemanticOption** yypp;
  yybool yymerge = yyfalse;
  YYSTYPE yysval;
  YYRESULTTAG yyflag;
  YYLTYPE *yylocp = &yys->yyloc;

  for (yypp = &yyoptionList->yynext; *yypp != YY_NULLPTR; )
    {
      yySemanticOption* yyp = *yypp;

      if (yyidenticalOptions (yybest, yyp))
        {
          yymergeOptionSets (yybest, yyp);
          *yypp = yyp->yynext;
        }
      else
        {
          switch (yypreference (yybest, yyp))
            {
            case 0:
              yyresolveLocations (yys, 1, yystackp);
              return yyreportAmbiguity (yybest, yyp);
              break;
            case 1:
              yymerge = yytrue;
              break;
            case 2:
              break;
            case 3:
              yybest = yyp;
              yymerge = yyfalse;
              break;
            default:
              /* This cannot happen so it is not worth a YY_ASSERT (yyfalse),
                 but some compilers complain if the default case is
                 omitted.  */
              break;
            }
          yypp = &yyp->yynext;
        }
    }

  if (yymerge)
    {
      yySemanticOption* yyp;
      int yyprec = yydprec[yybest->yyrule];
      yyflag = yyresolveAction (yybest, yystackp, &yysval, yylocp);
      if (yyflag == yyok)
        for (yyp = yybest->yynext; yyp != YY_NULLPTR; yyp = yyp->yynext)
          {
            if (yyprec == yydprec[yyp->yyrule])
              {
                YYSTYPE yysval_other;
                YYLTYPE yydummy;
                yyflag = yyresolveAction (yyp, yystackp, &yysval_other, &yydummy);
                if (yyflag != yyok)
                  {
                    yydestruct ("Cleanup: discarding incompletely merged value for",
                                yy_accessing_symbol (yys->yylrState),
                                &yysval, yylocp);
                    break;
                  }
                yyuserMerge (yymerger[yyp->yyrule], &yysval, &yysval_other);
              }
          }
    }
  else
    yyflag = yyresolveAction (yybest, yystackp, &yysval, yylocp);

  if (yyflag == yyok)
    {
      yys->yyresolved = yytrue;
      yys->yysemantics.yysval = yysval;
    }
  else
    yys->yysemantics.yyfirstVal = YY_NULLPTR;
  return yyflag;
}

static YYRESULTTAG
yyresolveStack (yyGLRStack* yystackp)
{
  if (yystackp->yysplitPoint != YY_NULLPTR)
    {
      yyGLRState* yys;
      int yyn;

      for (yyn = 0, yys = yystackp->yytops.yystates[0];
           yys != yystackp->yysplitPoint;
           yys = yys->yypred, yyn += 1)
        continue;
      YYCHK (yyresolveStates (yystackp->yytops.yystates[0], yyn, yystackp
                             ));
    }
  return yyok;
}

static void
yycompressStack (yyGLRStack* yystackp)
{
  yyGLRState* yyp, *yyq, *yyr;

  if (yystackp->yytops.yysize != 1 || yystackp->yysplitPoint == YY_NULLPTR)
    return;

  for (yyp = yystackp->yytops.yystates[0], yyq = yyp->yypred, yyr = YY_NULLPTR;
       yyp != yystackp->yysplitPoint;
       yyr = yyp, yyp = yyq, yyq = yyp->yypred)
    yyp->yypred = yyr;

  yystackp->yyspaceLeft += yystackp->yynextFree - yystackp->yyitems;
  yystackp->yynextFree = YY_REINTERPRET_CAST (yyGLRStackItem*, yystackp->yysplitPoint) + 1;
  yystackp->yyspaceLeft -= yystackp->yynextFree - yystackp->yyitems;
  yystackp->yysplitPoint = YY_NULLPTR;
  yystackp->yylastDeleted = YY_NULLPTR;

  while (yyr != YY_NULLPTR)
    {
      yystackp->yynextFree->yystate = *yyr;
      yyr = yyr->yypred;
      yystackp->yynextFree->yystate.yypred = &yystackp->yynextFree[-1].yystate;
      yystackp->yytops.yystates[0] = &yystackp->yynextFree->yystate;
      yystackp->yynextFree += 1;
      yystackp->yyspaceLeft -= 1;
    }
}

static YYRESULTTAG
yyprocessOneStack (yyGLRStack* yystackp, YYPTRDIFF_T yyk,
                   YYPTRDIFF_T yyposn)
{
  while (yystackp->yytops.yystates[yyk] != YY_NULLPTR)
    {
      yy_state_t yystate = yystackp->yytops.yystates[yyk]->yylrState;
      YY_DPRINTF ((stderr, "Stack %ld Entering state %d\n",
                   YY_CAST (long, yyk), yystate));

      YY_ASSERT (yystate != YYFINAL);

      if (yyisDefaultedState (yystate))
        {
          YYRESULTTAG yyflag;
          yyRuleNum yyrule = yydefaultAction (yystate);
          if (yyrule == 0)
            {
              YY_DPRINTF ((stderr, "Stack %ld dies.\n", YY_CAST (long, yyk)));
              yymarkStackDeleted (yystackp, yyk);
              return yyok;
            }
          yyflag = yyglrReduce (yystackp, yyk, yyrule, yyimmediate[yyrule]);
          if (yyflag == yyerr)
            {
              YY_DPRINTF ((stderr,
                           "Stack %ld dies "
                           "(predicate failure or explicit user error).\n",
                           YY_CAST (long, yyk)));
              yymarkStackDeleted (yystackp, yyk);
              return yyok;
            }
          if (yyflag != yyok)
            return yyflag;
        }
      else
        {
          yysymbol_kind_t yytoken = yygetToken (&yychar);
          const short* yyconflicts;
          const int yyaction = yygetLRActions (yystate, yytoken, &yyconflicts);
          yystackp->yytops.yylookaheadNeeds[yyk] = yytrue;

          for (/* nothing */; *yyconflicts; yyconflicts += 1)
            {
              YYRESULTTAG yyflag;
              YYPTRDIFF_T yynewStack = yysplitStack (yystackp, yyk);
              YY_DPRINTF ((stderr, "Splitting off stack %ld from %ld.\n",
                           YY_CAST (long, yynewStack), YY_CAST (long, yyk)));
              yyflag = yyglrReduce (yystackp, yynewStack,
                                    *yyconflicts,
                                    yyimmediate[*yyconflicts]);
              if (yyflag == yyok)
                YYCHK (yyprocessOneStack (yystackp, yynewStack,
                                          yyposn));
              else if (yyflag == yyerr)
                {
                  YY_DPRINTF ((stderr, "Stack %ld dies.\n", YY_CAST (long, yynewStack)));
                  yymarkStackDeleted (yystackp, yynewStack);
                }
              else
                return yyflag;
            }

          if (yyisShiftAction (yyaction))
            break;
          else if (yyisErrorAction (yyaction))
            {
              YY_DPRINTF ((stderr, "Stack %ld dies.\n", YY_CAST (long, yyk)));
              yymarkStackDeleted (yystackp, yyk);
              break;
            }
          else
            {
              YYRESULTTAG yyflag = yyglrReduce (yystackp, yyk, -yyaction,
                                                yyimmediate[-yyaction]);
              if (yyflag == yyerr)
                {
                  YY_DPRINTF ((stderr,
                               "Stack %ld dies "
                               "(predicate failure or explicit user error).\n",
                               YY_CAST (long, yyk)));
                  yymarkStackDeleted (yystackp, yyk);
                  break;
                }
              else if (yyflag != yyok)
                return yyflag;
            }
        }
    }
  return yyok;
}






static void
yyreportSyntaxError (yyGLRStack* yystackp)
{
  if (yystackp->yyerrState != 0)
    return;
  yyerror (YY_("syntax error"));
  yynerrs += 1;
}

/* Recover from a syntax error on *YYSTACKP, assuming that *YYSTACKP->YYTOKENP,
   yylval, and yylloc are the syntactic category, semantic value, and location
   of the lookahead.  */
static void
yyrecoverSyntaxError (yyGLRStack* yystackp)
{
  if (yystackp->yyerrState == 3)
    /* We just shifted the error token and (perhaps) took some
       reductions.  Skip tokens until we can proceed.  */
    while (yytrue)
      {
        yysymbol_kind_t yytoken;
        int yyj;
        if (yychar == YYEOF)
          yyFail (yystackp, YY_NULLPTR);
        if (yychar != YYEMPTY)
          {
            /* We throw away the lookahead, but the error range
               of the shifted error token must take it into account.  */
            yyGLRState *yys = yystackp->yytops.yystates[0];
            yyGLRStackItem yyerror_range[3];
            yyerror_range[1].yystate.yyloc = yys->yyloc;
            yyerror_range[2].yystate.yyloc = yylloc;
            YYLLOC_DEFAULT ((yys->yyloc), yyerror_range, 2);
            yytoken = YYTRANSLATE (yychar);
            yydestruct ("Error: discarding",
                        yytoken, &yylval, &yylloc);
            yychar = YYEMPTY;
          }
        yytoken = yygetToken (&yychar);
        yyj = yypact[yystackp->yytops.yystates[0]->yylrState];
        if (yypact_value_is_default (yyj))
          return;
        yyj += yytoken;
        if (yyj < 0 || YYLAST < yyj || yycheck[yyj] != yytoken)
          {
            if (yydefact[yystackp->yytops.yystates[0]->yylrState] != 0)
              return;
          }
        else if (! yytable_value_is_error (yytable[yyj]))
          return;
      }

  /* Reduce to one stack.  */
  {
    YYPTRDIFF_T yyk;
    for (yyk = 0; yyk < yystackp->yytops.yysize; yyk += 1)
      if (yystackp->yytops.yystates[yyk] != YY_NULLPTR)
        break;
    if (yyk >= yystackp->yytops.yysize)
      yyFail (yystackp, YY_NULLPTR);
    for (yyk += 1; yyk < yystackp->yytops.yysize; yyk += 1)
      yymarkStackDeleted (yystackp, yyk);
    yyremoveDeletes (yystackp);
    yycompressStack (yystackp);
  }

  /* Pop stack until we find a state that shifts the error token.  */
  yystackp->yyerrState = 3;
  while (yystackp->yytops.yystates[0] != YY_NULLPTR)
    {
      yyGLRState *yys = yystackp->yytops.yystates[0];
      int yyj = yypact[yys->yylrState];
      if (! yypact_value_is_default (yyj))
        {
          yyj += YYSYMBOL_YYerror;
          if (0 <= yyj && yyj <= YYLAST && yycheck[yyj] == YYSYMBOL_YYerror
              && yyisShiftAction (yytable[yyj]))
            {
              /* Shift the error token.  */
              int yyaction = yytable[yyj];
              /* First adjust its location.*/
              YYLTYPE yyerrloc;
              yystackp->yyerror_range[2].yystate.yyloc = yylloc;
              YYLLOC_DEFAULT (yyerrloc, (yystackp->yyerror_range), 2);
              YY_SYMBOL_PRINT ("Shifting", yy_accessing_symbol (yyaction),
                               &yylval, &yyerrloc);
              yyglrShift (yystackp, 0, yyaction,
                          yys->yyposn, &yylval, &yyerrloc);
              yys = yystackp->yytops.yystates[0];
              break;
            }
        }
      yystackp->yyerror_range[1].yystate.yyloc = yys->yyloc;
      if (yys->yypred != YY_NULLPTR)
        yydestroyGLRState ("Error: popping", yys);
      yystackp->yytops.yystates[0] = yys->yypred;
      yystackp->yynextFree -= 1;
      yystackp->yyspaceLeft += 1;
    }
  if (yystackp->yytops.yystates[0] == YY_NULLPTR)
    yyFail (yystackp, YY_NULLPTR);
}

#define YYCHK1(YYE)                                                          \
  do {                                                                       \
    switch (YYE) {                                                           \
    case yyok:                                                               \
      break;                                                                 \
    case yyabort:                                                            \
      goto yyabortlab;                                                       \
    case yyaccept:                                                           \
      goto yyacceptlab;                                                      \
    case yyerr:                                                              \
      goto yyuser_error;                                                     \
    default:                                                                 \
      goto yybuglab;                                                         \
    }                                                                        \
  } while (0)

/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
  int yyresult;
  yyGLRStack yystack;
  yyGLRStack* const yystackp = &yystack;
  YYPTRDIFF_T yyposn;

  YY_DPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY;
  yylval = yyval_default;
  yylloc = yyloc_default;

  if (! yyinitGLRStack (yystackp, YYINITDEPTH))
    goto yyexhaustedlab;
  switch (YYSETJMP (yystack.yyexception_buffer))
    {
    case 0: break;
    case 1: goto yyabortlab;
    case 2: goto yyexhaustedlab;
    default: goto yybuglab;
    }
  yyglrShift (&yystack, 0, 0, 0, &yylval, &yylloc);
  yyposn = 0;

  while (yytrue)
    {
      /* For efficiency, we have two loops, the first of which is
         specialized to deterministic operation (single stack, no
         potential ambiguity).  */
      /* Standard mode. */
      while (yytrue)
        {
          yy_state_t yystate = yystack.yytops.yystates[0]->yylrState;
          YY_DPRINTF ((stderr, "Entering state %d\n", yystate));
          if (yystate == YYFINAL)
            goto yyacceptlab;
          if (yyisDefaultedState (yystate))
            {
              yyRuleNum yyrule = yydefaultAction (yystate);
              if (yyrule == 0)
                {
                  yystack.yyerror_range[1].yystate.yyloc = yylloc;
                  yyreportSyntaxError (&yystack);
                  goto yyuser_error;
                }
              YYCHK1 (yyglrReduce (&yystack, 0, yyrule, yytrue));
            }
          else
            {
              yysymbol_kind_t yytoken = yygetToken (&yychar);
              const short* yyconflicts;
              int yyaction = yygetLRActions (yystate, yytoken, &yyconflicts);
              if (*yyconflicts)
                /* Enter nondeterministic mode.  */
                break;
              if (yyisShiftAction (yyaction))
                {
                  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
                  yychar = YYEMPTY;
                  yyposn += 1;
                  yyglrShift (&yystack, 0, yyaction, yyposn, &yylval, &yylloc);
                  if (0 < yystack.yyerrState)
                    yystack.yyerrState -= 1;
                }
              else if (yyisErrorAction (yyaction))
                {
                  yystack.yyerror_range[1].yystate.yyloc = yylloc;
                  /* Issue an error message unless the scanner already
                     did. */
                  if (yychar != YYerror)
                    yyreportSyntaxError (&yystack);
                  goto yyuser_error;
                }
              else
                YYCHK1 (yyglrReduce (&yystack, 0, -yyaction, yytrue));
            }
        }

      /* Nondeterministic mode. */
      while (yytrue)
        {
          yysymbol_kind_t yytoken_to_shift;
          YYPTRDIFF_T yys;

          for (yys = 0; yys < yystack.yytops.yysize; yys += 1)
            yystackp->yytops.yylookaheadNeeds[yys] = yychar != YYEMPTY;

          /* yyprocessOneStack returns one of three things:

              - An error flag.  If the caller is yyprocessOneStack, it
                immediately returns as well.  When the caller is finally
                yyparse, it jumps to an error label via YYCHK1.

              - yyok, but yyprocessOneStack has invoked yymarkStackDeleted
                (&yystack, yys), which sets the top state of yys to NULL.  Thus,
                yyparse's following invocation of yyremoveDeletes will remove
                the stack.

              - yyok, when ready to shift a token.

             Except in the first case, yyparse will invoke yyremoveDeletes and
             then shift the next token onto all remaining stacks.  This
             synchronization of the shift (that is, after all preceding
             reductions on all stacks) helps prevent double destructor calls
             on yylval in the event of memory exhaustion.  */

          for (yys = 0; yys < yystack.yytops.yysize; yys += 1)
            YYCHK1 (yyprocessOneStack (&yystack, yys, yyposn));
          yyremoveDeletes (&yystack);
          if (yystack.yytops.yysize == 0)
            {
              yyundeleteLastStack (&yystack);
              if (yystack.yytops.yysize == 0)
                yyFail (&yystack, YY_("syntax error"));
              YYCHK1 (yyresolveStack (&yystack));
              YY_DPRINTF ((stderr, "Returning to deterministic operation.\n"));
              yystack.yyerror_range[1].yystate.yyloc = yylloc;
              yyreportSyntaxError (&yystack);
              goto yyuser_error;
            }

          /* If any yyglrShift call fails, it will fail after shifting.  Thus,
             a copy of yylval will already be on stack 0 in the event of a
             failure in the following loop.  Thus, yychar is set to YYEMPTY
             before the loop to make sure the user destructor for yylval isn't
             called twice.  */
          yytoken_to_shift = YYTRANSLATE (yychar);
          yychar = YYEMPTY;
          yyposn += 1;
          for (yys = 0; yys < yystack.yytops.yysize; yys += 1)
            {
              yy_state_t yystate = yystack.yytops.yystates[yys]->yylrState;
              const short* yyconflicts;
              int yyaction = yygetLRActions (yystate, yytoken_to_shift,
                              &yyconflicts);
              /* Note that yyconflicts were handled by yyprocessOneStack.  */
              YY_DPRINTF ((stderr, "On stack %ld, ", YY_CAST (long, yys)));
              YY_SYMBOL_PRINT ("shifting", yytoken_to_shift, &yylval, &yylloc);
              yyglrShift (&yystack, yys, yyaction, yyposn,
                          &yylval, &yylloc);
              YY_DPRINTF ((stderr, "Stack %ld now in state #%d\n",
                           YY_CAST (long, yys),
                           yystack.yytops.yystates[yys]->yylrState));
            }

          if (yystack.yytops.yysize == 1)
            {
              YYCHK1 (yyresolveStack (&yystack));
              YY_DPRINTF ((stderr, "Returning to deterministic operation.\n"));
              yycompressStack (&yystack);
              break;
            }
        }
      continue;
    yyuser_error:
      yyrecoverSyntaxError (&yystack);
      yyposn = yystack.yytops.yystates[0]->yyposn;
    }

 yyacceptlab:
  yyresult = 0;
  goto yyreturn;

 yybuglab:
  YY_ASSERT (yyfalse);
  goto yyabortlab;

 yyabortlab:
  yyresult = 1;
  goto yyreturn;

 yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturn;

 yyreturn:
  if (yychar != YYEMPTY)
    yydestruct ("Cleanup: discarding lookahead",
                YYTRANSLATE (yychar), &yylval, &yylloc);

  /* If the stack is well-formed, pop the stack until it is empty,
     destroying its entries as we go.  But free the stack regardless
     of whether it is well-formed.  */
  if (yystack.yyitems)
    {
      yyGLRState** yystates = yystack.yytops.yystates;
      if (yystates)
        {
          YYPTRDIFF_T yysize = yystack.yytops.yysize;
          YYPTRDIFF_T yyk;
          for (yyk = 0; yyk < yysize; yyk += 1)
            if (yystates[yyk])
              {
                while (yystates[yyk])
                  {
                    yyGLRState *yys = yystates[yyk];
                    yystack.yyerror_range[1].yystate.yyloc = yys->yyloc;
                    if (yys->yypred != YY_NULLPTR)
                      yydestroyGLRState ("Cleanup: popping", yys);
                    yystates[yyk] = yys->yypred;
                    yystack.yynextFree -= 1;
                    yystack.yyspaceLeft += 1;
                  }
                break;
              }
        }
      yyfreeGLRStack (&yystack);
    }

  return yyresult;
}

/* DEBUGGING ONLY */
#if YYDEBUG
static void
yy_yypstack (yyGLRState* yys)
{
  if (yys->yypred)
    {
      yy_yypstack (yys->yypred);
      YY_FPRINTF ((stderr, " -> "));
    }
  YY_FPRINTF ((stderr, "%d@%ld", yys->yylrState, YY_CAST (long, yys->yyposn)));
}

static void
yypstates (yyGLRState* yyst)
{
  if (yyst == YY_NULLPTR)
    YY_FPRINTF ((stderr, "<null>"));
  else
    yy_yypstack (yyst);
  YY_FPRINTF ((stderr, "\n"));
}

static void
yypstack (yyGLRStack* yystackp, YYPTRDIFF_T yyk)
{
  yypstates (yystackp->yytops.yystates[yyk]);
}

static void
yypdumpstack (yyGLRStack* yystackp)
{
#define YYINDEX(YYX)                                                    \
  YY_CAST (long,                                                        \
           ((YYX)                                                       \
            ? YY_REINTERPRET_CAST (yyGLRStackItem*, (YYX)) - yystackp->yyitems \
            : -1))

  yyGLRStackItem* yyp;
  for (yyp = yystackp->yyitems; yyp < yystackp->yynextFree; yyp += 1)
    {
      YY_FPRINTF ((stderr, "%3ld. ",
                   YY_CAST (long, yyp - yystackp->yyitems)));
      if (*YY_REINTERPRET_CAST (yybool *, yyp))
        {
          YY_ASSERT (yyp->yystate.yyisState);
          YY_ASSERT (yyp->yyoption.yyisState);
          YY_FPRINTF ((stderr, "Res: %d, LR State: %d, posn: %ld, pred: %ld",
                       yyp->yystate.yyresolved, yyp->yystate.yylrState,
                       YY_CAST (long, yyp->yystate.yyposn),
                       YYINDEX (yyp->yystate.yypred)));
          if (! yyp->yystate.yyresolved)
            YY_FPRINTF ((stderr, ", firstVal: %ld",
                         YYINDEX (yyp->yystate.yysemantics.yyfirstVal)));
        }
      else
        {
          YY_ASSERT (!yyp->yystate.yyisState);
          YY_ASSERT (!yyp->yyoption.yyisState);
          YY_FPRINTF ((stderr, "Option. rule: %d, state: %ld, next: %ld",
                       yyp->yyoption.yyrule - 1,
                       YYINDEX (yyp->yyoption.yystate),
                       YYINDEX (yyp->yyoption.yynext)));
        }
      YY_FPRINTF ((stderr, "\n"));
    }

  YY_FPRINTF ((stderr, "Tops:"));
  {
    YYPTRDIFF_T yyi;
    for (yyi = 0; yyi < yystackp->yytops.yysize; yyi += 1)
      YY_FPRINTF ((stderr, "%ld: %ld; ", YY_CAST (long, yyi),
                   YYINDEX (yystackp->yytops.yystates[yyi])));
    YY_FPRINTF ((stderr, "\n"));
  }
#undef YYINDEX
}
#endif

#undef yylval
#undef yychar
#undef yynerrs
#undef yylloc




#line 783 "src/parser.ypp"

