/**
 * @file
 */
#include "src/common/Valued.hpp"

birch::Valued::Valued(Name* op, Expression* value) : op(op), value(value) {
  //
}

birch::Valued::~Valued() {
  //
}
