/**
 * @file
 */
#include "src/common/Valued.hpp"

birch::Valued::Valued(Expression* value) : value(value) {
  //
}

birch::Valued::~Valued() {
  //
}
