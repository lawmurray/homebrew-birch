/**
 * @file
 */
#include "src/common/Located.hpp"

birch::Located::Located(Location* loc) :
    loc(loc) {
  //
}

birch::Located::~Located() {
  //
}
