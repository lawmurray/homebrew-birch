/**
 * @file
 */
#include "src/common/TypeArgumented.hpp"

birch::TypeArgumented::TypeArgumented(Type* typeArgs) : typeArgs(typeArgs) {
  //
}

birch::TypeArgumented::~TypeArgumented() {
  //
}
