/**
 * @file
 */
#include "src/common/Used.hpp"

birch::Used::Used() : useCount(0) {
  //
}

birch::Used::~Used() {
  //
}
