/**
 * @file
 */
#include "src/common/ReturnTyped.hpp"

birch::ReturnTyped::ReturnTyped(Type* returnType) :
    returnType(returnType) {
  //
}

birch::ReturnTyped::~ReturnTyped() {
  //
}
