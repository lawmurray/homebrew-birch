/**
 * @file
 */
#include "src/common/Parameterised.hpp"

birch::Parameterised::Parameterised(Expression* params) :
    params(params) {
  //
}

birch::Parameterised::~Parameterised() {
  //
}
