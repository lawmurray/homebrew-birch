/**
 * @file
 */
#include "src/common/Argumented.hpp"

birch::Argumented::Argumented(Expression* args) :
    args(args) {
  //
}

birch::Argumented::~Argumented() {
  //
}
