/**
 * @file
 */
#include "src/common/Typed.hpp"

birch::Typed::Typed(Type* type) :
    type(type) {
  //
}

birch::Typed::~Typed() {
  //
}
