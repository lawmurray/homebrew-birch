/**
 * @file
 */
#include "src/visitor/Gatherer.hpp"
