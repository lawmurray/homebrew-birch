/**
 * @file
 */
#include "src/exception/Exception.hpp"

 birch::Exception::Exception() {
  //
}

birch::Exception::Exception(const std::string& msg) : msg(msg) {
  //
}
