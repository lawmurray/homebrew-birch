/* A Bison parser, made by GNU Bison 3.7.2.  */

/* Skeleton interface for Bison GLR parsers in C

   Copyright (C) 2002-2015, 2018-2020 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_SRC_PARSER_HPP_INCLUDED
# define YY_YY_SRC_PARSER_HPP_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif
/* "%code requires" blocks.  */
#line 1 "src/parser.ypp"

  #include "src/lexer.hpp"
  #include "src/build/Compiler.hpp"

#line 49 "src/parser.hpp"

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    PROGRAM = 258,                 /* PROGRAM  */
    CLASS = 259,                   /* CLASS  */
    TYPE = 260,                    /* TYPE  */
    FUNCTION = 261,                /* FUNCTION  */
    OPERATOR = 262,                /* OPERATOR  */
    AUTO = 263,                    /* AUTO  */
    LET = 264,                     /* LET  */
    IF = 265,                      /* IF  */
    ELSE = 266,                    /* ELSE  */
    FOR = 267,                     /* FOR  */
    IN = 268,                      /* IN  */
    WHILE = 269,                   /* WHILE  */
    DO = 270,                      /* DO  */
    WITH = 271,                    /* WITH  */
    ASSERT = 272,                  /* ASSERT  */
    RETURN = 273,                  /* RETURN  */
    FACTOR = 274,                  /* FACTOR  */
    CPP = 275,                     /* CPP  */
    HPP = 276,                     /* HPP  */
    THIS = 277,                    /* THIS  */
    SUPER = 278,                   /* SUPER  */
    GLOBAL = 279,                  /* GLOBAL  */
    PARALLEL = 280,                /* PARALLEL  */
    DYNAMIC = 281,                 /* DYNAMIC  */
    ABSTRACT = 282,                /* ABSTRACT  */
    OVERRIDE = 283,                /* OVERRIDE  */
    FINAL = 284,                   /* FINAL  */
    NIL = 285,                     /* NIL  */
    DOUBLE_BRACE_OPEN = 286,       /* DOUBLE_BRACE_OPEN  */
    DOUBLE_BRACE_CLOSE = 287,      /* DOUBLE_BRACE_CLOSE  */
    NAME = 288,                    /* NAME  */
    BOOL_LITERAL = 289,            /* BOOL_LITERAL  */
    INT_LITERAL = 290,             /* INT_LITERAL  */
    REAL_LITERAL = 291,            /* REAL_LITERAL  */
    STRING_LITERAL = 292,          /* STRING_LITERAL  */
    LEFT_OP = 293,                 /* LEFT_OP  */
    RIGHT_OP = 294,                /* RIGHT_OP  */
    LEFT_TILDE_OP = 295,           /* LEFT_TILDE_OP  */
    RIGHT_TILDE_OP = 296,          /* RIGHT_TILDE_OP  */
    LEFT_QUERY_OP = 297,           /* LEFT_QUERY_OP  */
    AND_OP = 298,                  /* AND_OP  */
    OR_OP = 299,                   /* OR_OP  */
    LE_OP = 300,                   /* LE_OP  */
    GE_OP = 301,                   /* GE_OP  */
    EQ_OP = 302,                   /* EQ_OP  */
    NE_OP = 303,                   /* NE_OP  */
    RANGE_OP = 304                 /* RANGE_OP  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 71 "src/parser.ypp"

  int32_t valInt;
  double valReal;
  const char* valString;
  
  birch::Annotation valAnnotation;
  birch::Name* valName;
  birch::Expression* valExpression;
  birch::Type* valType;
  birch::Statement* valStatement;

#line 127 "src/parser.hpp"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif

/* Location type.  */
#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE YYLTYPE;
struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif


extern YYSTYPE yylval;
extern YYLTYPE yylloc;
int yyparse (void);

#endif /* !YY_YY_SRC_PARSER_HPP_INCLUDED  */
