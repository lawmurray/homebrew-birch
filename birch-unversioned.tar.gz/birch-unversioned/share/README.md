# PACKAGE_NAME package

## Installation

To build and install, use:

    birch build
    birch install
