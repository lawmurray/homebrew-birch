#line 3 "birch/Context.birch"
birch::type::Context::Context(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 3 "birch/Context.birch"
    super_type_() {
  //
}

#line 13 "birch/Context.birch"
void birch::type::Context::destroy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 13 "birch/Context.birch"
  libbirch_function_("destroy", "birch/Context.birch", 13);
  #line 14 "birch/Context.birch"
cairo_destroy(this->cr);
    }

#line 23 "birch/Context.birch"
void birch::type::Context::newPath(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "birch/Context.birch"
  libbirch_function_("newPath", "birch/Context.birch", 23);
  #line 24 "birch/Context.birch"
cairo_new_path(this->cr);
    }

#line 29 "birch/Context.birch"
void birch::type::Context::closePath(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "birch/Context.birch"
  libbirch_function_("closePath", "birch/Context.birch", 29);
  #line 30 "birch/Context.birch"
cairo_close_path(this->cr);
    }

#line 35 "birch/Context.birch"
void birch::type::Context::arc(const birch::type::Real& xc, const birch::type::Real& yc, const birch::type::Real& radius, const birch::type::Real& angle1, const birch::type::Real& angle2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "birch/Context.birch"
  libbirch_function_("arc", "birch/Context.birch", 35);
  #line 36 "birch/Context.birch"
cairo_arc(this->cr, xc, yc, radius, angle1, angle2);
    }

#line 41 "birch/Context.birch"
void birch::type::Context::arcNegative(const birch::type::Real& xc, const birch::type::Real& yc, const birch::type::Real& radius, const birch::type::Real& angle1, const birch::type::Real& angle2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "birch/Context.birch"
  libbirch_function_("arcNegative", "birch/Context.birch", 41);
  #line 42 "birch/Context.birch"
cairo_arc_negative(this->cr, xc, yc, radius, angle1, angle2);
    }

#line 47 "birch/Context.birch"
void birch::type::Context::curveTo(const birch::type::Real& x1, const birch::type::Real& y1, const birch::type::Real& x2, const birch::type::Real& y2, const birch::type::Real& x3, const birch::type::Real& y3, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "birch/Context.birch"
  libbirch_function_("curveTo", "birch/Context.birch", 47);
  #line 48 "birch/Context.birch"
cairo_curve_to(this->cr, x1, y1, x2, y2, x3, y3);
    }

#line 53 "birch/Context.birch"
void birch::type::Context::lineTo(const birch::type::Real& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "birch/Context.birch"
  libbirch_function_("lineTo", "birch/Context.birch", 53);
  #line 54 "birch/Context.birch"
cairo_line_to(this->cr, x, y);
    }

#line 59 "birch/Context.birch"
void birch::type::Context::moveTo(const birch::type::Real& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "birch/Context.birch"
  libbirch_function_("moveTo", "birch/Context.birch", 59);
  #line 60 "birch/Context.birch"
cairo_move_to(this->cr, x, y);
    }

#line 65 "birch/Context.birch"
void birch::type::Context::rectangle(const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& width, const birch::type::Real& height, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "birch/Context.birch"
  libbirch_function_("rectangle", "birch/Context.birch", 65);
  #line 66 "birch/Context.birch"
cairo_rectangle(this->cr, x, y, width, height);
    }

#line 71 "birch/Context.birch"
void birch::type::Context::relCurveTo(const birch::type::Real& dx1, const birch::type::Real& dy1, const birch::type::Real& dx2, const birch::type::Real& dy2, const birch::type::Real& dx3, const birch::type::Real& dy3, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 71 "birch/Context.birch"
  libbirch_function_("relCurveTo", "birch/Context.birch", 71);
  #line 72 "birch/Context.birch"
cairo_curve_to(this->cr, dx1, dy1, dx2, dy2, dx3, dy3);
    }

#line 77 "birch/Context.birch"
void birch::type::Context::relLineTo(const birch::type::Real& dx, const birch::type::Real& dy, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 77 "birch/Context.birch"
  libbirch_function_("relLineTo", "birch/Context.birch", 77);
  #line 78 "birch/Context.birch"
cairo_line_to(this->cr, dx, dy);
    }

#line 83 "birch/Context.birch"
void birch::type::Context::relMoveTo(const birch::type::Real& dx, const birch::type::Real& dy, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 83 "birch/Context.birch"
  libbirch_function_("relMoveTo", "birch/Context.birch", 83);
  #line 84 "birch/Context.birch"
cairo_move_to(this->cr, dx, dy);
    }

#line 89 "birch/Context.birch"
void birch::type::Context::stroke(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 89 "birch/Context.birch"
  libbirch_function_("stroke", "birch/Context.birch", 89);
  #line 90 "birch/Context.birch"
cairo_stroke(this->cr);
    }

#line 95 "birch/Context.birch"
void birch::type::Context::strokePreserve(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "birch/Context.birch"
  libbirch_function_("strokePreserve", "birch/Context.birch", 95);
  #line 96 "birch/Context.birch"
cairo_stroke_preserve(this->cr);
    }

#line 101 "birch/Context.birch"
void birch::type::Context::fill(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 101 "birch/Context.birch"
  libbirch_function_("fill", "birch/Context.birch", 101);
  #line 102 "birch/Context.birch"
cairo_fill(this->cr);
    }

#line 107 "birch/Context.birch"
void birch::type::Context::fillPreserve(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 107 "birch/Context.birch"
  libbirch_function_("fillPreserve", "birch/Context.birch", 107);
  #line 108 "birch/Context.birch"
cairo_fill_preserve(this->cr);
    }

#line 113 "birch/Context.birch"
void birch::type::Context::paint(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 113 "birch/Context.birch"
  libbirch_function_("paint", "birch/Context.birch", 113);
  #line 114 "birch/Context.birch"
cairo_paint(this->cr);
    }

#line 123 "birch/Context.birch"
void birch::type::Context::translate(const birch::type::Real& tx, const birch::type::Real& ty, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 123 "birch/Context.birch"
  libbirch_function_("translate", "birch/Context.birch", 123);
  #line 124 "birch/Context.birch"
cairo_translate(this->cr, tx, ty);
    }

#line 129 "birch/Context.birch"
void birch::type::Context::scale(const birch::type::Real& sx, const birch::type::Real& sy, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 129 "birch/Context.birch"
  libbirch_function_("scale", "birch/Context.birch", 129);
  #line 130 "birch/Context.birch"
cairo_scale(this->cr, sx, sy);
    }

#line 135 "birch/Context.birch"
void birch::type::Context::rotate(const birch::type::Real& angle, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 135 "birch/Context.birch"
  libbirch_function_("rotate", "birch/Context.birch", 135);
  #line 136 "birch/Context.birch"
cairo_rotate(this->cr, angle);
    }

#line 141 "birch/Context.birch"
libbirch::Tuple<birch::type::Real, birch::type::Real> birch::type::Context::deviceToUserDistance(const birch::type::Real& ux, const birch::type::Real& uy, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 141 "birch/Context.birch"
  libbirch_function_("deviceToUserDistance", "birch/Context.birch", 141);
  #line 142 "birch/Context.birch"
  libbirch_line_(142);
  #line 142 "birch/Context.birch"
  birch::type::Real ux1 = ux;
  #line 143 "birch/Context.birch"
  libbirch_line_(143);
  #line 143 "birch/Context.birch"
  birch::type::Real uy1 = uy;
  #line 144 "birch/Context.birch"
cairo_device_to_user_distance(this->cr, &ux1, &uy1);
      #line 147 "birch/Context.birch"
  libbirch_line_(147);
  #line 147 "birch/Context.birch"
  return libbirch::make_tuple(ux1, uy1);
}

#line 154 "birch/Context.birch"
void birch::type::Context::setSourceRGB(const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 154 "birch/Context.birch"
  libbirch_function_("setSourceRGB", "birch/Context.birch", 154);
  #line 155 "birch/Context.birch"
cairo_set_source_rgb(this->cr, red, green, blue);
    }

#line 160 "birch/Context.birch"
void birch::type::Context::setSourceRGBA(const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue, const birch::type::Real& alpha, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 160 "birch/Context.birch"
  libbirch_function_("setSourceRGBA", "birch/Context.birch", 160);
  #line 161 "birch/Context.birch"
cairo_set_source_rgba(this->cr, red, green, blue, alpha);
    }

#line 166 "birch/Context.birch"
void birch::type::Context::setSource(const libbirch::Lazy<libbirch::Shared<birch::type::Pattern>>& pattern, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 166 "birch/Context.birch"
  libbirch_function_("setSource", "birch/Context.birch", 166);
  #line 167 "birch/Context.birch"
cairo_set_source(this->cr, pattern->pattern);
    }

#line 172 "birch/Context.birch"
void birch::type::Context::setLineWidth(const birch::type::Real& width, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 172 "birch/Context.birch"
  libbirch_function_("setLineWidth", "birch/Context.birch", 172);
  #line 173 "birch/Context.birch"
cairo_set_line_width(this->cr, width);
    }

#line 182 "birch/Context.birch"
void birch::type::Context::showText(const birch::type::String& utf8, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 182 "birch/Context.birch"
  libbirch_function_("showText", "birch/Context.birch", 182);
  #line 183 "birch/Context.birch"
cairo_show_text(this->cr, utf8.c_str());
    }

#line 188 "birch/Context.birch"
void birch::type::Context::setFontSize(const birch::type::Real& size, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 188 "birch/Context.birch"
  libbirch_function_("setFontSize", "birch/Context.birch", 188);
  #line 189 "birch/Context.birch"
cairo_set_font_size(this->cr, size);
    }

#line 198 "birch/Context.birch"
void birch::type::Context::pushGroup(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 198 "birch/Context.birch"
  libbirch_function_("pushGroup", "birch/Context.birch", 198);
  #line 199 "birch/Context.birch"
cairo_push_group(this->cr);
    }

#line 204 "birch/Context.birch"
void birch::type::Context::popGroupToSource(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 204 "birch/Context.birch"
  libbirch_function_("popGroupToSource", "birch/Context.birch", 204);
  #line 205 "birch/Context.birch"
cairo_pop_group_to_source(this->cr);
    }

#line 3 "birch/Context.birch"
birch::type::Context* birch::type::make_Context_() {
  #line 3 "birch/Context.birch"
  return new birch::type::Context();
  #line 3 "birch/Context.birch"
}

#line 211 "birch/Context.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Context>> birch::create(const libbirch::Lazy<libbirch::Shared<birch::type::Surface>>& surface, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 211 "birch/Context.birch"
  libbirch_function_("create", "birch/Context.birch", 211);
  #line 212 "birch/Context.birch"
  libbirch_line_(212);
  #line 212 "birch/Context.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Context>> cr;
  #line 213 "birch/Context.birch"
cr->cr = cairo_create(surface->surface);
    #line 216 "birch/Context.birch"
  libbirch_line_(216);
  #line 216 "birch/Context.birch"
  return cr;
}

#line 1 "birch/Pattern.birch"
birch::type::Pattern::Pattern(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/Pattern.birch"
    super_type_() {
  //
}

#line 9 "birch/Pattern.birch"
void birch::type::Pattern::addColorStopRGB(const birch::type::Real& offset, const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "birch/Pattern.birch"
  libbirch_function_("addColorStopRGB", "birch/Pattern.birch", 9);
  #line 10 "birch/Pattern.birch"
cairo_pattern_add_color_stop_rgb(this->pattern, offset, red, green, blue);
    }

#line 15 "birch/Pattern.birch"
void birch::type::Pattern::addColorStopRGBA(const birch::type::Real& offset, const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue, const birch::type::Real& alpha, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "birch/Pattern.birch"
  libbirch_function_("addColorStopRGBA", "birch/Pattern.birch", 15);
  #line 17 "birch/Pattern.birch"
cairo_pattern_add_color_stop_rgba(this->pattern, offset, red, green, blue,
        alpha);
    }

#line 23 "birch/Pattern.birch"
void birch::type::Pattern::destroy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "birch/Pattern.birch"
  libbirch_function_("destroy", "birch/Pattern.birch", 23);
  #line 24 "birch/Pattern.birch"
cairo_pattern_destroy(this->pattern);
    }

#line 1 "birch/Pattern.birch"
birch::type::Pattern* birch::type::make_Pattern_() {
  #line 1 "birch/Pattern.birch"
  return new birch::type::Pattern();
  #line 1 "birch/Pattern.birch"
}

#line 30 "birch/Pattern.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Pattern>> birch::createRGB(const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "birch/Pattern.birch"
  libbirch_function_("createRGB", "birch/Pattern.birch", 30);
  #line 31 "birch/Pattern.birch"
  libbirch_line_(31);
  #line 31 "birch/Pattern.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Pattern>> result;
  #line 32 "birch/Pattern.birch"
result->pattern = cairo_pattern_create_rgb(red, green, blue);
    #line 35 "birch/Pattern.birch"
  libbirch_line_(35);
  #line 35 "birch/Pattern.birch"
  return result;
}

#line 38 "birch/Pattern.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Pattern>> birch::createRGBA(const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue, const birch::type::Real& alpha, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "birch/Pattern.birch"
  libbirch_function_("createRGBA", "birch/Pattern.birch", 38);
  #line 39 "birch/Pattern.birch"
  libbirch_line_(39);
  #line 39 "birch/Pattern.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Pattern>> result;
  #line 40 "birch/Pattern.birch"
result->pattern = cairo_pattern_create_rgba(red, green, blue, alpha);
    #line 43 "birch/Pattern.birch"
  libbirch_line_(43);
  #line 43 "birch/Pattern.birch"
  return result;
}

#line 46 "birch/Pattern.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Pattern>> birch::createLinear(const birch::type::Real& x0, const birch::type::Real& y0, const birch::type::Real& x1, const birch::type::Real& y1, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "birch/Pattern.birch"
  libbirch_function_("createLinear", "birch/Pattern.birch", 46);
  #line 47 "birch/Pattern.birch"
  libbirch_line_(47);
  #line 47 "birch/Pattern.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Pattern>> result;
  #line 48 "birch/Pattern.birch"
result->pattern = cairo_pattern_create_linear(x0, y0, x1, y1);
    #line 51 "birch/Pattern.birch"
  libbirch_line_(51);
  #line 51 "birch/Pattern.birch"
  return result;
}

#line 54 "birch/Pattern.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Pattern>> birch::createRadial(const birch::type::Real& cx0, const birch::type::Real& cy0, const birch::type::Real& radius0, const birch::type::Real& cx1, const birch::type::Real& cy1, const birch::type::Real& radius1, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "birch/Pattern.birch"
  libbirch_function_("createRadial", "birch/Pattern.birch", 54);
  #line 56 "birch/Pattern.birch"
  libbirch_line_(56);
  #line 56 "birch/Pattern.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Pattern>> result;
  #line 57 "birch/Pattern.birch"
result->pattern = cairo_pattern_create_radial(cx0, cy0, radius0, cx1,
      cy1, radius1);
    #line 61 "birch/Pattern.birch"
  libbirch_line_(61);
  #line 61 "birch/Pattern.birch"
  return result;
}

#line 1 "birch/Surface.birch"
birch::type::Surface::Surface(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/Surface.birch"
    super_type_() {
  //
}

#line 9 "birch/Surface.birch"
void birch::type::Surface::destroy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "birch/Surface.birch"
  libbirch_function_("destroy", "birch/Surface.birch", 9);
  #line 10 "birch/Surface.birch"
cairo_surface_destroy(this->surface);
    }

#line 1 "birch/Surface.birch"
birch::type::Surface* birch::type::make_Surface_() {
  #line 1 "birch/Surface.birch"
  return new birch::type::Surface();
  #line 1 "birch/Surface.birch"
}

#line 3 "birch/SurfacePDF.birch"
birch::type::SurfacePDF::SurfacePDF(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 3 "birch/SurfacePDF.birch"
    super_type_() {
  //
}

#line 3 "birch/SurfacePDF.birch"
birch::type::SurfacePDF* birch::type::make_SurfacePDF_() {
  #line 3 "birch/SurfacePDF.birch"
  return new birch::type::SurfacePDF();
  #line 3 "birch/SurfacePDF.birch"
}

#line 12 "birch/SurfacePDF.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Surface>> birch::createPDF(const birch::type::String& filename, const birch::type::Real& widthInPoints, const birch::type::Real& heightInPoints, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 12 "birch/SurfacePDF.birch"
  libbirch_function_("createPDF", "birch/SurfacePDF.birch", 12);
  #line 14 "birch/SurfacePDF.birch"
  libbirch_line_(14);
  #line 14 "birch/SurfacePDF.birch"
  birch::mkdir(filename, handler_);
  #line 15 "birch/SurfacePDF.birch"
  libbirch_line_(15);
  #line 15 "birch/SurfacePDF.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::SurfacePDF>> surface;
  #line 16 "birch/SurfacePDF.birch"
surface->surface = cairo_pdf_surface_create(filename.c_str(),
      widthInPoints, heightInPoints);
    #line 20 "birch/SurfacePDF.birch"
  libbirch_line_(20);
  #line 20 "birch/SurfacePDF.birch"
  return surface;
}

#line 1 "birch/SurfacePNG.birch"
birch::type::SurfacePNG::SurfacePNG(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/SurfacePNG.birch"
    super_type_(),
    #line 5 "birch/SurfacePNG.birch"
    filename() {
  //
}

#line 7 "birch/SurfacePNG.birch"
void birch::type::SurfacePNG::destroy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "birch/SurfacePNG.birch"
  libbirch_function_("destroy", "birch/SurfacePNG.birch", 7);
  #line 9 "birch/SurfacePNG.birch"
  libbirch_line_(9);
  #line 9 "birch/SurfacePNG.birch"
  birch::mkdir(this_()->filename, handler_);
  #line 10 "birch/SurfacePNG.birch"
cairo_surface_write_to_png(this->surface, this->filename.c_str());
      #line 13 "birch/SurfacePNG.birch"
  libbirch_line_(13);
  #line 13 "birch/SurfacePNG.birch"
  this_()->super_type_::destroy(handler_);
}

#line 1 "birch/SurfacePNG.birch"
birch::type::SurfacePNG* birch::type::make_SurfacePNG_() {
  #line 1 "birch/SurfacePNG.birch"
  return new birch::type::SurfacePNG();
  #line 1 "birch/SurfacePNG.birch"
}

#line 17 "birch/SurfacePNG.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Surface>> birch::createPNG(const birch::type::String& filename, const birch::type::Integer& width, const birch::type::Integer& height, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 17 "birch/SurfacePNG.birch"
  libbirch_function_("createPNG", "birch/SurfacePNG.birch", 17);
  #line 19 "birch/SurfacePNG.birch"
  libbirch_line_(19);
  #line 19 "birch/SurfacePNG.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::SurfacePNG>> surface;
  #line 20 "birch/SurfacePNG.birch"
surface->filename = filename;
  surface->surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32,
      width, height);
    #line 25 "birch/SurfacePNG.birch"
  libbirch_line_(25);
  #line 25 "birch/SurfacePNG.birch"
  return surface;
}

#line 3 "birch/SurfaceSVG.birch"
birch::type::SurfaceSVG::SurfaceSVG(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 3 "birch/SurfaceSVG.birch"
    super_type_() {
  //
}

#line 3 "birch/SurfaceSVG.birch"
birch::type::SurfaceSVG* birch::type::make_SurfaceSVG_() {
  #line 3 "birch/SurfaceSVG.birch"
  return new birch::type::SurfaceSVG();
  #line 3 "birch/SurfaceSVG.birch"
}

#line 12 "birch/SurfaceSVG.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Surface>> birch::createSVG(const birch::type::String& filename, const birch::type::Real& widthInPoints, const birch::type::Real& heightInPoints, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 12 "birch/SurfaceSVG.birch"
  libbirch_function_("createSVG", "birch/SurfaceSVG.birch", 12);
  #line 14 "birch/SurfaceSVG.birch"
  libbirch_line_(14);
  #line 14 "birch/SurfaceSVG.birch"
  birch::mkdir(filename, handler_);
  #line 15 "birch/SurfaceSVG.birch"
  libbirch_line_(15);
  #line 15 "birch/SurfaceSVG.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::SurfaceSVG>> surface;
  #line 16 "birch/SurfaceSVG.birch"
surface->surface = cairo_svg_surface_create(filename.c_str(),
      widthInPoints, heightInPoints);
    #line 20 "birch/SurfaceSVG.birch"
  libbirch_line_(20);
  #line 20 "birch/SurfaceSVG.birch"
  return surface;
}

