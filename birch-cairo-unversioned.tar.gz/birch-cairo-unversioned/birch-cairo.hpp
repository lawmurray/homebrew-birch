#ifndef BI_BIRCH_CAIRO_HPP
#define BI_BIRCH_CAIRO_HPP

#include "libbirch.hpp"

#include "birch-standard.hpp"

#include <cairo/cairo.h>

#include <cairo/cairo-pdf.h>

#include <cairo/cairo-svg.h>

namespace birch {
namespace type {
class Context;
class Pattern;
class Surface;
class SurfacePDF;
class SurfacePNG;
class SurfaceSVG;


#line 3 "src/Context.birch"
class Context : public Object {
public:
  #line 3 "src/Context.birch"
  using class_type_ = Context;
  #line 3 "src/Context.birch"
  using this_type_ = class_type_;
  #line 3 "src/Context.birch"
  using super_type_ = Object;

  #line 3 "src/Context.birch"
  using super_type_::operator=;
  
  #line 3 "src/Context.birch"
  Context(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);


  cairo_t* cr;
    #line 13 "src/Context.birch"
  virtual void destroy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 23 "src/Context.birch"
  virtual void newPath(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 29 "src/Context.birch"
  virtual void closePath(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 35 "src/Context.birch"
  virtual void arc(const birch::type::Real& xc, const birch::type::Real& yc, const birch::type::Real& radius, const birch::type::Real& angle1, const birch::type::Real& angle2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 41 "src/Context.birch"
  virtual void arcNegative(const birch::type::Real& xc, const birch::type::Real& yc, const birch::type::Real& radius, const birch::type::Real& angle1, const birch::type::Real& angle2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 47 "src/Context.birch"
  virtual void curveTo(const birch::type::Real& x1, const birch::type::Real& y1, const birch::type::Real& x2, const birch::type::Real& y2, const birch::type::Real& x3, const birch::type::Real& y3, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 53 "src/Context.birch"
  virtual void lineTo(const birch::type::Real& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 59 "src/Context.birch"
  virtual void moveTo(const birch::type::Real& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 65 "src/Context.birch"
  virtual void rectangle(const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& width, const birch::type::Real& height, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 71 "src/Context.birch"
  virtual void relCurveTo(const birch::type::Real& dx1, const birch::type::Real& dy1, const birch::type::Real& dx2, const birch::type::Real& dy2, const birch::type::Real& dx3, const birch::type::Real& dy3, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 77 "src/Context.birch"
  virtual void relLineTo(const birch::type::Real& dx, const birch::type::Real& dy, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 83 "src/Context.birch"
  virtual void relMoveTo(const birch::type::Real& dx, const birch::type::Real& dy, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 89 "src/Context.birch"
  virtual void stroke(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 95 "src/Context.birch"
  virtual void strokePreserve(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 101 "src/Context.birch"
  virtual void fill(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 107 "src/Context.birch"
  virtual void fillPreserve(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 113 "src/Context.birch"
  virtual void paint(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 123 "src/Context.birch"
  virtual void translate(const birch::type::Real& tx, const birch::type::Real& ty, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 129 "src/Context.birch"
  virtual void scale(const birch::type::Real& sx, const birch::type::Real& sy, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 135 "src/Context.birch"
  virtual void rotate(const birch::type::Real& angle, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 141 "src/Context.birch"
  virtual libbirch::Tuple<birch::type::Real, birch::type::Real> deviceToUserDistance(const birch::type::Real& ux, const birch::type::Real& uy, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 154 "src/Context.birch"
  virtual void setSourceRGB(const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 160 "src/Context.birch"
  virtual void setSourceRGBA(const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue, const birch::type::Real& alpha, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 166 "src/Context.birch"
  virtual void setSource(const libbirch::Lazy<libbirch::Shared<birch::type::Pattern>>& pattern, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 172 "src/Context.birch"
  virtual void setLineWidth(const birch::type::Real& width, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 182 "src/Context.birch"
  virtual void showText(const birch::type::String& utf8, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 188 "src/Context.birch"
  virtual void setFontSize(const birch::type::Real& size, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 198 "src/Context.birch"
  virtual void pushGroup(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 204 "src/Context.birch"
  virtual void popGroupToSource(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  
  #line 3 "src/Context.birch"
  LIBBIRCH_CLASS(Context, Object)
  #line 3 "src/Context.birch"
  LIBBIRCH_MEMBERS()
};

#line 3 "src/Context.birch"
extern "C" birch::type::Context* make_Context_();

#line 1 "src/Pattern.birch"
class Pattern : public Object {
public:
  #line 1 "src/Pattern.birch"
  using class_type_ = Pattern;
  #line 1 "src/Pattern.birch"
  using this_type_ = class_type_;
  #line 1 "src/Pattern.birch"
  using super_type_ = Object;

  #line 1 "src/Pattern.birch"
  using super_type_::operator=;
  
  #line 1 "src/Pattern.birch"
  Pattern(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);


  cairo_pattern_t* pattern;
    #line 9 "src/Pattern.birch"
  virtual void addColorStopRGB(const birch::type::Real& offset, const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 15 "src/Pattern.birch"
  virtual void addColorStopRGBA(const birch::type::Real& offset, const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue, const birch::type::Real& alpha, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 23 "src/Pattern.birch"
  virtual void destroy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  
  #line 1 "src/Pattern.birch"
  LIBBIRCH_CLASS(Pattern, Object)
  #line 1 "src/Pattern.birch"
  LIBBIRCH_MEMBERS()
};

#line 1 "src/Pattern.birch"
extern "C" birch::type::Pattern* make_Pattern_();

#line 1 "src/Surface.birch"
class Surface : public Object {
public:
  #line 1 "src/Surface.birch"
  using class_type_ = Surface;
  #line 1 "src/Surface.birch"
  using this_type_ = class_type_;
  #line 1 "src/Surface.birch"
  using super_type_ = Object;

  #line 1 "src/Surface.birch"
  using super_type_::operator=;
  
  #line 1 "src/Surface.birch"
  Surface(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);


  cairo_surface_t* surface;
    #line 9 "src/Surface.birch"
  virtual void destroy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  
  #line 1 "src/Surface.birch"
  LIBBIRCH_CLASS(Surface, Object)
  #line 1 "src/Surface.birch"
  LIBBIRCH_MEMBERS()
};

#line 1 "src/Surface.birch"
extern "C" birch::type::Surface* make_Surface_();

#line 3 "src/SurfacePDF.birch"
class SurfacePDF : public Surface {
public:
  #line 3 "src/SurfacePDF.birch"
  using class_type_ = SurfacePDF;
  #line 3 "src/SurfacePDF.birch"
  using this_type_ = class_type_;
  #line 3 "src/SurfacePDF.birch"
  using super_type_ = Surface;

  #line 3 "src/SurfacePDF.birch"
  using super_type_::operator=;
  
  #line 3 "src/SurfacePDF.birch"
  SurfacePDF(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);

  
  #line 3 "src/SurfacePDF.birch"
  LIBBIRCH_CLASS(SurfacePDF, Surface)
  #line 3 "src/SurfacePDF.birch"
  LIBBIRCH_MEMBERS()
};

#line 3 "src/SurfacePDF.birch"
extern "C" birch::type::SurfacePDF* make_SurfacePDF_();

#line 1 "src/SurfacePNG.birch"
class SurfacePNG : public Surface {
public:
  #line 1 "src/SurfacePNG.birch"
  using class_type_ = SurfacePNG;
  #line 1 "src/SurfacePNG.birch"
  using this_type_ = class_type_;
  #line 1 "src/SurfacePNG.birch"
  using super_type_ = Surface;

  #line 1 "src/SurfacePNG.birch"
  using super_type_::operator=;
  #line 1 "src/SurfacePNG.birch"
  using super_type_::destroy;
  
  #line 1 "src/SurfacePNG.birch"
  SurfacePNG(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);

  birch::type::String filename;
  #line 7 "src/SurfacePNG.birch"
  virtual void destroy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  
  #line 1 "src/SurfacePNG.birch"
  LIBBIRCH_CLASS(SurfacePNG, Surface)
  #line 1 "src/SurfacePNG.birch"
  LIBBIRCH_MEMBERS(filename)
};

#line 1 "src/SurfacePNG.birch"
extern "C" birch::type::SurfacePNG* make_SurfacePNG_();

#line 3 "src/SurfaceSVG.birch"
class SurfaceSVG : public Surface {
public:
  #line 3 "src/SurfaceSVG.birch"
  using class_type_ = SurfaceSVG;
  #line 3 "src/SurfaceSVG.birch"
  using this_type_ = class_type_;
  #line 3 "src/SurfaceSVG.birch"
  using super_type_ = Surface;

  #line 3 "src/SurfaceSVG.birch"
  using super_type_::operator=;
  
  #line 3 "src/SurfaceSVG.birch"
  SurfaceSVG(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);

  
  #line 3 "src/SurfaceSVG.birch"
  LIBBIRCH_CLASS(SurfaceSVG, Surface)
  #line 3 "src/SurfaceSVG.birch"
  LIBBIRCH_MEMBERS()
};

#line 3 "src/SurfaceSVG.birch"
extern "C" birch::type::SurfaceSVG* make_SurfaceSVG_();


}

#line 211 "src/Context.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Context>> create(const libbirch::Lazy<libbirch::Shared<birch::type::Surface>>& surface, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
#line 30 "src/Pattern.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Pattern>> createRGB(const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
#line 38 "src/Pattern.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Pattern>> createRGBA(const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue, const birch::type::Real& alpha, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
#line 46 "src/Pattern.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Pattern>> createLinear(const birch::type::Real& x0, const birch::type::Real& y0, const birch::type::Real& x1, const birch::type::Real& y1, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
#line 54 "src/Pattern.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Pattern>> createRadial(const birch::type::Real& cx0, const birch::type::Real& cy0, const birch::type::Real& radius0, const birch::type::Real& cx1, const birch::type::Real& cy1, const birch::type::Real& radius1, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
#line 12 "src/SurfacePDF.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Surface>> createPDF(const birch::type::String& filename, const birch::type::Real& widthInPoints, const birch::type::Real& heightInPoints, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
#line 17 "src/SurfacePNG.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Surface>> createPNG(const birch::type::String& filename, const birch::type::Integer& width, const birch::type::Integer& height, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
#line 12 "src/SurfaceSVG.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Surface>> createSVG(const birch::type::String& filename, const birch::type::Real& widthInPoints, const birch::type::Real& heightInPoints, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
}

#endif
