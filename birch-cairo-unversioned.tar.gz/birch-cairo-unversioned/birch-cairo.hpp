#ifndef BI_BIRCH_CAIRO_HPP
#define BI_BIRCH_CAIRO_HPP

#include "libbirch.hpp"

#include "birch-standard.hpp"

#include <cairo/cairo.h>

#include <cairo/cairo-pdf.h>

#include <cairo/cairo-svg.h>

namespace birch {
namespace type {
class Context;
class Pattern;
class Surface;
class SurfacePDF;
class SurfacePNG;
class SurfaceSVG;


#line 3 "src/Context.birch"
class Context : public Object {
public:
  #line 3 "src/Context.birch"
  LIBBIRCH_CLASS(Context, Object)
  #line 3 "src/Context.birch"
  #line 3 "src/Context.birch"
  using base_type_::operator=;
  
  #line 3 "src/Context.birch"
  Context();


  cairo_t* cr;
    #line 16 "src/Context.birch"
  virtual void destroy();
  #line 25 "src/Context.birch"
  virtual void newPath();
  #line 34 "src/Context.birch"
  virtual void closePath();
  #line 43 "src/Context.birch"
  virtual void arc(const birch::type::Real& xc, const birch::type::Real& yc, const birch::type::Real& radius, const birch::type::Real& angle1, const birch::type::Real& angle2);
  #line 52 "src/Context.birch"
  virtual void arcNegative(const birch::type::Real& xc, const birch::type::Real& yc, const birch::type::Real& radius, const birch::type::Real& angle1, const birch::type::Real& angle2);
  #line 61 "src/Context.birch"
  virtual void curveTo(const birch::type::Real& x1, const birch::type::Real& y1, const birch::type::Real& x2, const birch::type::Real& y2, const birch::type::Real& x3, const birch::type::Real& y3);
  #line 70 "src/Context.birch"
  virtual void lineTo(const birch::type::Real& x, const birch::type::Real& y);
  #line 79 "src/Context.birch"
  virtual void moveTo(const birch::type::Real& x, const birch::type::Real& y);
  #line 88 "src/Context.birch"
  virtual void rectangle(const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& width, const birch::type::Real& height);
  #line 97 "src/Context.birch"
  virtual void relCurveTo(const birch::type::Real& dx1, const birch::type::Real& dy1, const birch::type::Real& dx2, const birch::type::Real& dy2, const birch::type::Real& dx3, const birch::type::Real& dy3);
  #line 106 "src/Context.birch"
  virtual void relLineTo(const birch::type::Real& dx, const birch::type::Real& dy);
  #line 115 "src/Context.birch"
  virtual void relMoveTo(const birch::type::Real& dx, const birch::type::Real& dy);
  #line 124 "src/Context.birch"
  virtual void stroke();
  #line 133 "src/Context.birch"
  virtual void strokePreserve();
  #line 142 "src/Context.birch"
  virtual void fill();
  #line 151 "src/Context.birch"
  virtual void fillPreserve();
  #line 160 "src/Context.birch"
  virtual void paint();
  #line 169 "src/Context.birch"
  virtual void translate(const birch::type::Real& tx, const birch::type::Real& ty);
  #line 178 "src/Context.birch"
  virtual void scale(const birch::type::Real& sx, const birch::type::Real& sy);
  #line 187 "src/Context.birch"
  virtual void rotate(const birch::type::Real& angle);
  #line 196 "src/Context.birch"
  virtual std::tuple<birch::type::Real, birch::type::Real> deviceToUserDistance(const birch::type::Real& ux, const birch::type::Real& uy);
  #line 208 "src/Context.birch"
  virtual void setSourceRGB(const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue);
  #line 217 "src/Context.birch"
  virtual void setSourceRGBA(const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue, const birch::type::Real& alpha);
  #line 226 "src/Context.birch"
  virtual void setSource(const libbirch::Shared<birch::type::Pattern>& pattern);
  #line 235 "src/Context.birch"
  virtual void setLineWidth(const birch::type::Real& width);
  #line 244 "src/Context.birch"
  virtual void showText(const birch::type::String& utf8);
  #line 253 "src/Context.birch"
  virtual void setFontSize(const birch::type::Real& size);
  #line 262 "src/Context.birch"
  virtual void pushGroup();
  #line 271 "src/Context.birch"
  virtual void popGroupToSource();
};

#line 3 "src/Context.birch"
extern "C" birch::type::Context* make_Context_();

#line 1 "src/Pattern.birch"
class Pattern : public Object {
public:
  #line 1 "src/Pattern.birch"
  LIBBIRCH_CLASS(Pattern, Object)
  #line 1 "src/Pattern.birch"
  #line 1 "src/Pattern.birch"
  using base_type_::operator=;
  
  #line 1 "src/Pattern.birch"
  Pattern();


  cairo_pattern_t* pattern;
    #line 12 "src/Pattern.birch"
  virtual void addColorStopRGB(const birch::type::Real& offset, const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue);
  #line 21 "src/Pattern.birch"
  virtual void addColorStopRGBA(const birch::type::Real& offset, const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue, const birch::type::Real& alpha);
  #line 32 "src/Pattern.birch"
  virtual void destroy();
};

#line 1 "src/Pattern.birch"
extern "C" birch::type::Pattern* make_Pattern_();

#line 1 "src/Surface.birch"
class Surface : public Object {
public:
  #line 1 "src/Surface.birch"
  LIBBIRCH_CLASS(Surface, Object)
  #line 1 "src/Surface.birch"
  #line 1 "src/Surface.birch"
  using base_type_::operator=;
  
  #line 1 "src/Surface.birch"
  Surface();


  cairo_surface_t* surface;
    #line 12 "src/Surface.birch"
  virtual void destroy();
};

#line 1 "src/Surface.birch"
extern "C" birch::type::Surface* make_Surface_();

#line 3 "src/SurfacePDF.birch"
class SurfacePDF : public Surface {
public:
  #line 3 "src/SurfacePDF.birch"
  LIBBIRCH_CLASS(SurfacePDF, Surface)
  #line 3 "src/SurfacePDF.birch"
  #line 3 "src/SurfacePDF.birch"
  using base_type_::operator=;
  
  #line 3 "src/SurfacePDF.birch"
  SurfacePDF();

};

#line 3 "src/SurfacePDF.birch"
extern "C" birch::type::SurfacePDF* make_SurfacePDF_();

#line 1 "src/SurfacePNG.birch"
class SurfacePNG : public Surface {
public:
  #line 1 "src/SurfacePNG.birch"
  LIBBIRCH_CLASS(SurfacePNG, Surface)
  #line 1 "src/SurfacePNG.birch"
  LIBBIRCH_MEMBERS(filename)
  #line 1 "src/SurfacePNG.birch"
  using base_type_::operator=;
  #line 1 "src/SurfacePNG.birch"
  using base_type_::destroy;
  
  #line 1 "src/SurfacePNG.birch"
  SurfacePNG();

  birch::type::String filename;
  #line 10 "src/SurfacePNG.birch"
  virtual void destroy();
};

#line 1 "src/SurfacePNG.birch"
extern "C" birch::type::SurfacePNG* make_SurfacePNG_();

#line 3 "src/SurfaceSVG.birch"
class SurfaceSVG : public Surface {
public:
  #line 3 "src/SurfaceSVG.birch"
  LIBBIRCH_CLASS(SurfaceSVG, Surface)
  #line 3 "src/SurfaceSVG.birch"
  #line 3 "src/SurfaceSVG.birch"
  using base_type_::operator=;
  
  #line 3 "src/SurfaceSVG.birch"
  SurfaceSVG();

};

#line 3 "src/SurfaceSVG.birch"
extern "C" birch::type::SurfaceSVG* make_SurfaceSVG_();


}

#line 281 "src/Context.birch"
libbirch::Shared<birch::type::Context> create(const libbirch::Shared<birch::type::Surface>& surface);
#line 42 "src/Pattern.birch"
libbirch::Shared<birch::type::Pattern> createRGB(const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue);
#line 53 "src/Pattern.birch"
libbirch::Shared<birch::type::Pattern> createRGBA(const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue, const birch::type::Real& alpha);
#line 64 "src/Pattern.birch"
libbirch::Shared<birch::type::Pattern> createLinear(const birch::type::Real& x0, const birch::type::Real& y0, const birch::type::Real& x1, const birch::type::Real& y1);
#line 75 "src/Pattern.birch"
libbirch::Shared<birch::type::Pattern> createRadial(const birch::type::Real& cx0, const birch::type::Real& cy0, const birch::type::Real& radius0, const birch::type::Real& cx1, const birch::type::Real& cy1, const birch::type::Real& radius1);
#line 15 "src/SurfacePDF.birch"
libbirch::Shared<birch::type::Surface> createPDF(const birch::type::String& filename, const birch::type::Real& widthInPoints, const birch::type::Real& heightInPoints);
#line 23 "src/SurfacePNG.birch"
libbirch::Shared<birch::type::Surface> createPNG(const birch::type::String& filename, const birch::type::Integer& width, const birch::type::Integer& height);
#line 15 "src/SurfaceSVG.birch"
libbirch::Shared<birch::type::Surface> createSVG(const birch::type::String& filename, const birch::type::Real& widthInPoints, const birch::type::Real& heightInPoints);
}

#endif
