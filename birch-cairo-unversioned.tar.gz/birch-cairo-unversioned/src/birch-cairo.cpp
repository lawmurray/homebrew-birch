#line 3 "src/Context.birch"
birch::type::Context::Context() :
    #line 3 "src/Context.birch"
    base_type_() {
  //
}

#line 16 "src/Context.birch"
void birch::type::Context::destroy() {
  #line 16 "src/Context.birch"
  libbirch_function_("destroy", "src/Context.birch", 16);
  #line 17 "src/Context.birch"

    cairo_destroy(this->cr);
    }

#line 25 "src/Context.birch"
void birch::type::Context::newPath() {
  #line 25 "src/Context.birch"
  libbirch_function_("newPath", "src/Context.birch", 25);
  #line 26 "src/Context.birch"

    cairo_new_path(this->cr);
    }

#line 34 "src/Context.birch"
void birch::type::Context::closePath() {
  #line 34 "src/Context.birch"
  libbirch_function_("closePath", "src/Context.birch", 34);
  #line 35 "src/Context.birch"

    cairo_close_path(this->cr);
    }

#line 43 "src/Context.birch"
void birch::type::Context::arc(const birch::type::Real& xc, const birch::type::Real& yc, const birch::type::Real& radius, const birch::type::Real& angle1, const birch::type::Real& angle2) {
  #line 43 "src/Context.birch"
  libbirch_function_("arc", "src/Context.birch", 43);
  #line 44 "src/Context.birch"

    cairo_arc(this->cr, xc, yc, radius, angle1, angle2);
    }

#line 52 "src/Context.birch"
void birch::type::Context::arcNegative(const birch::type::Real& xc, const birch::type::Real& yc, const birch::type::Real& radius, const birch::type::Real& angle1, const birch::type::Real& angle2) {
  #line 52 "src/Context.birch"
  libbirch_function_("arcNegative", "src/Context.birch", 52);
  #line 53 "src/Context.birch"

    cairo_arc_negative(this->cr, xc, yc, radius, angle1, angle2);
    }

#line 61 "src/Context.birch"
void birch::type::Context::curveTo(const birch::type::Real& x1, const birch::type::Real& y1, const birch::type::Real& x2, const birch::type::Real& y2, const birch::type::Real& x3, const birch::type::Real& y3) {
  #line 61 "src/Context.birch"
  libbirch_function_("curveTo", "src/Context.birch", 61);
  #line 62 "src/Context.birch"

    cairo_curve_to(this->cr, x1, y1, x2, y2, x3, y3);
    }

#line 70 "src/Context.birch"
void birch::type::Context::lineTo(const birch::type::Real& x, const birch::type::Real& y) {
  #line 70 "src/Context.birch"
  libbirch_function_("lineTo", "src/Context.birch", 70);
  #line 71 "src/Context.birch"

    cairo_line_to(this->cr, x, y);
    }

#line 79 "src/Context.birch"
void birch::type::Context::moveTo(const birch::type::Real& x, const birch::type::Real& y) {
  #line 79 "src/Context.birch"
  libbirch_function_("moveTo", "src/Context.birch", 79);
  #line 80 "src/Context.birch"

    cairo_move_to(this->cr, x, y);
    }

#line 88 "src/Context.birch"
void birch::type::Context::rectangle(const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& width, const birch::type::Real& height) {
  #line 88 "src/Context.birch"
  libbirch_function_("rectangle", "src/Context.birch", 88);
  #line 89 "src/Context.birch"

    cairo_rectangle(this->cr, x, y, width, height);
    }

#line 97 "src/Context.birch"
void birch::type::Context::relCurveTo(const birch::type::Real& dx1, const birch::type::Real& dy1, const birch::type::Real& dx2, const birch::type::Real& dy2, const birch::type::Real& dx3, const birch::type::Real& dy3) {
  #line 97 "src/Context.birch"
  libbirch_function_("relCurveTo", "src/Context.birch", 97);
  #line 98 "src/Context.birch"

    cairo_curve_to(this->cr, dx1, dy1, dx2, dy2, dx3, dy3);
    }

#line 106 "src/Context.birch"
void birch::type::Context::relLineTo(const birch::type::Real& dx, const birch::type::Real& dy) {
  #line 106 "src/Context.birch"
  libbirch_function_("relLineTo", "src/Context.birch", 106);
  #line 107 "src/Context.birch"

    cairo_line_to(this->cr, dx, dy);
    }

#line 115 "src/Context.birch"
void birch::type::Context::relMoveTo(const birch::type::Real& dx, const birch::type::Real& dy) {
  #line 115 "src/Context.birch"
  libbirch_function_("relMoveTo", "src/Context.birch", 115);
  #line 116 "src/Context.birch"

    cairo_move_to(this->cr, dx, dy);
    }

#line 124 "src/Context.birch"
void birch::type::Context::stroke() {
  #line 124 "src/Context.birch"
  libbirch_function_("stroke", "src/Context.birch", 124);
  #line 125 "src/Context.birch"

    cairo_stroke(this->cr);
    }

#line 133 "src/Context.birch"
void birch::type::Context::strokePreserve() {
  #line 133 "src/Context.birch"
  libbirch_function_("strokePreserve", "src/Context.birch", 133);
  #line 134 "src/Context.birch"

    cairo_stroke_preserve(this->cr);
    }

#line 142 "src/Context.birch"
void birch::type::Context::fill() {
  #line 142 "src/Context.birch"
  libbirch_function_("fill", "src/Context.birch", 142);
  #line 143 "src/Context.birch"

    cairo_fill(this->cr);
    }

#line 151 "src/Context.birch"
void birch::type::Context::fillPreserve() {
  #line 151 "src/Context.birch"
  libbirch_function_("fillPreserve", "src/Context.birch", 151);
  #line 152 "src/Context.birch"

    cairo_fill_preserve(this->cr);
    }

#line 160 "src/Context.birch"
void birch::type::Context::paint() {
  #line 160 "src/Context.birch"
  libbirch_function_("paint", "src/Context.birch", 160);
  #line 161 "src/Context.birch"

    cairo_paint(this->cr);
    }

#line 169 "src/Context.birch"
void birch::type::Context::translate(const birch::type::Real& tx, const birch::type::Real& ty) {
  #line 169 "src/Context.birch"
  libbirch_function_("translate", "src/Context.birch", 169);
  #line 170 "src/Context.birch"

    cairo_translate(this->cr, tx, ty);
    }

#line 178 "src/Context.birch"
void birch::type::Context::scale(const birch::type::Real& sx, const birch::type::Real& sy) {
  #line 178 "src/Context.birch"
  libbirch_function_("scale", "src/Context.birch", 178);
  #line 179 "src/Context.birch"

    cairo_scale(this->cr, sx, sy);
    }

#line 187 "src/Context.birch"
void birch::type::Context::rotate(const birch::type::Real& angle) {
  #line 187 "src/Context.birch"
  libbirch_function_("rotate", "src/Context.birch", 187);
  #line 188 "src/Context.birch"

    cairo_rotate(this->cr, angle);
    }

#line 196 "src/Context.birch"
std::tuple<birch::type::Real, birch::type::Real> birch::type::Context::deviceToUserDistance(const birch::type::Real& ux, const birch::type::Real& uy) {
  #line 196 "src/Context.birch"
  libbirch_function_("deviceToUserDistance", "src/Context.birch", 196);
  #line 197 "src/Context.birch"
  libbirch_line_(197);
  #line 197 "src/Context.birch"
  birch::type::Real ux1 = ux;
  #line 198 "src/Context.birch"
  libbirch_line_(198);
  #line 198 "src/Context.birch"
  birch::type::Real uy1 = uy;
  #line 199 "src/Context.birch"

    cairo_device_to_user_distance(this->cr, &ux1, &uy1);
      #line 202 "src/Context.birch"
  libbirch_line_(202);
  #line 202 "src/Context.birch"
  return std::make_tuple(ux1, uy1);
}

#line 208 "src/Context.birch"
void birch::type::Context::setSourceRGB(const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue) {
  #line 208 "src/Context.birch"
  libbirch_function_("setSourceRGB", "src/Context.birch", 208);
  #line 209 "src/Context.birch"

    cairo_set_source_rgb(this->cr, red, green, blue);
    }

#line 217 "src/Context.birch"
void birch::type::Context::setSourceRGBA(const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue, const birch::type::Real& alpha) {
  #line 217 "src/Context.birch"
  libbirch_function_("setSourceRGBA", "src/Context.birch", 217);
  #line 218 "src/Context.birch"

    cairo_set_source_rgba(this->cr, red, green, blue, alpha);
    }

#line 226 "src/Context.birch"
void birch::type::Context::setSource(const libbirch::Shared<birch::type::Pattern>& pattern) {
  #line 226 "src/Context.birch"
  libbirch_function_("setSource", "src/Context.birch", 226);
  #line 227 "src/Context.birch"

    cairo_set_source(this->cr, pattern->pattern);
    }

#line 235 "src/Context.birch"
void birch::type::Context::setLineWidth(const birch::type::Real& width) {
  #line 235 "src/Context.birch"
  libbirch_function_("setLineWidth", "src/Context.birch", 235);
  #line 236 "src/Context.birch"

    cairo_set_line_width(this->cr, width);
    }

#line 244 "src/Context.birch"
void birch::type::Context::showText(const birch::type::String& utf8) {
  #line 244 "src/Context.birch"
  libbirch_function_("showText", "src/Context.birch", 244);
  #line 245 "src/Context.birch"

    cairo_show_text(this->cr, utf8.c_str());
    }

#line 253 "src/Context.birch"
void birch::type::Context::setFontSize(const birch::type::Real& size) {
  #line 253 "src/Context.birch"
  libbirch_function_("setFontSize", "src/Context.birch", 253);
  #line 254 "src/Context.birch"

    cairo_set_font_size(this->cr, size);
    }

#line 262 "src/Context.birch"
void birch::type::Context::pushGroup() {
  #line 262 "src/Context.birch"
  libbirch_function_("pushGroup", "src/Context.birch", 262);
  #line 263 "src/Context.birch"

    cairo_push_group(this->cr);
    }

#line 271 "src/Context.birch"
void birch::type::Context::popGroupToSource() {
  #line 271 "src/Context.birch"
  libbirch_function_("popGroupToSource", "src/Context.birch", 271);
  #line 272 "src/Context.birch"

    cairo_pop_group_to_source(this->cr);
    }

#line 3 "src/Context.birch"
birch::type::Context* birch::type::make_Context_() {
  #line 3 "src/Context.birch"
  return new birch::type::Context();
  #line 3 "src/Context.birch"
}

#line 281 "src/Context.birch"
libbirch::Shared<birch::type::Context> birch::create(const libbirch::Shared<birch::type::Surface>& surface) {
  #line 281 "src/Context.birch"
  libbirch_function_("create", "src/Context.birch", 281);
  #line 282 "src/Context.birch"
  libbirch_line_(282);
  #line 282 "src/Context.birch"
  libbirch::Shared<birch::type::Context> cr = libbirch::make<libbirch::Shared<birch::type::Context>>();
  #line 283 "src/Context.birch"

  cr->cr = cairo_create(surface->surface);
    #line 286 "src/Context.birch"
  libbirch_line_(286);
  #line 286 "src/Context.birch"
  return cr;
}

#line 1 "src/Pattern.birch"
birch::type::Pattern::Pattern() :
    #line 1 "src/Pattern.birch"
    base_type_() {
  //
}

#line 12 "src/Pattern.birch"
void birch::type::Pattern::addColorStopRGB(const birch::type::Real& offset, const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue) {
  #line 12 "src/Pattern.birch"
  libbirch_function_("addColorStopRGB", "src/Pattern.birch", 12);
  #line 13 "src/Pattern.birch"

    cairo_pattern_add_color_stop_rgb(this->pattern, offset, red, green, blue);
    }

#line 21 "src/Pattern.birch"
void birch::type::Pattern::addColorStopRGBA(const birch::type::Real& offset, const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue, const birch::type::Real& alpha) {
  #line 21 "src/Pattern.birch"
  libbirch_function_("addColorStopRGBA", "src/Pattern.birch", 21);
  #line 23 "src/Pattern.birch"

    cairo_pattern_add_color_stop_rgba(this->pattern, offset, red, green, blue,
        alpha);
    }

#line 32 "src/Pattern.birch"
void birch::type::Pattern::destroy() {
  #line 32 "src/Pattern.birch"
  libbirch_function_("destroy", "src/Pattern.birch", 32);
  #line 33 "src/Pattern.birch"

    cairo_pattern_destroy(this->pattern);
    }

#line 1 "src/Pattern.birch"
birch::type::Pattern* birch::type::make_Pattern_() {
  #line 1 "src/Pattern.birch"
  return new birch::type::Pattern();
  #line 1 "src/Pattern.birch"
}

#line 42 "src/Pattern.birch"
libbirch::Shared<birch::type::Pattern> birch::createRGB(const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue) {
  #line 42 "src/Pattern.birch"
  libbirch_function_("createRGB", "src/Pattern.birch", 42);
  #line 43 "src/Pattern.birch"
  libbirch_line_(43);
  #line 43 "src/Pattern.birch"
  libbirch::Shared<birch::type::Pattern> result = libbirch::make<libbirch::Shared<birch::type::Pattern>>();
  #line 44 "src/Pattern.birch"

  result->pattern = cairo_pattern_create_rgb(red, green, blue);
    #line 47 "src/Pattern.birch"
  libbirch_line_(47);
  #line 47 "src/Pattern.birch"
  return result;
}

#line 53 "src/Pattern.birch"
libbirch::Shared<birch::type::Pattern> birch::createRGBA(const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue, const birch::type::Real& alpha) {
  #line 53 "src/Pattern.birch"
  libbirch_function_("createRGBA", "src/Pattern.birch", 53);
  #line 54 "src/Pattern.birch"
  libbirch_line_(54);
  #line 54 "src/Pattern.birch"
  libbirch::Shared<birch::type::Pattern> result = libbirch::make<libbirch::Shared<birch::type::Pattern>>();
  #line 55 "src/Pattern.birch"

  result->pattern = cairo_pattern_create_rgba(red, green, blue, alpha);
    #line 58 "src/Pattern.birch"
  libbirch_line_(58);
  #line 58 "src/Pattern.birch"
  return result;
}

#line 64 "src/Pattern.birch"
libbirch::Shared<birch::type::Pattern> birch::createLinear(const birch::type::Real& x0, const birch::type::Real& y0, const birch::type::Real& x1, const birch::type::Real& y1) {
  #line 64 "src/Pattern.birch"
  libbirch_function_("createLinear", "src/Pattern.birch", 64);
  #line 65 "src/Pattern.birch"
  libbirch_line_(65);
  #line 65 "src/Pattern.birch"
  libbirch::Shared<birch::type::Pattern> result = libbirch::make<libbirch::Shared<birch::type::Pattern>>();
  #line 66 "src/Pattern.birch"

  result->pattern = cairo_pattern_create_linear(x0, y0, x1, y1);
    #line 69 "src/Pattern.birch"
  libbirch_line_(69);
  #line 69 "src/Pattern.birch"
  return result;
}

#line 75 "src/Pattern.birch"
libbirch::Shared<birch::type::Pattern> birch::createRadial(const birch::type::Real& cx0, const birch::type::Real& cy0, const birch::type::Real& radius0, const birch::type::Real& cx1, const birch::type::Real& cy1, const birch::type::Real& radius1) {
  #line 75 "src/Pattern.birch"
  libbirch_function_("createRadial", "src/Pattern.birch", 75);
  #line 77 "src/Pattern.birch"
  libbirch_line_(77);
  #line 77 "src/Pattern.birch"
  libbirch::Shared<birch::type::Pattern> result = libbirch::make<libbirch::Shared<birch::type::Pattern>>();
  #line 78 "src/Pattern.birch"

  result->pattern = cairo_pattern_create_radial(cx0, cy0, radius0, cx1,
      cy1, radius1);
    #line 82 "src/Pattern.birch"
  libbirch_line_(82);
  #line 82 "src/Pattern.birch"
  return result;
}

#line 1 "src/Surface.birch"
birch::type::Surface::Surface() :
    #line 1 "src/Surface.birch"
    base_type_() {
  //
}

#line 12 "src/Surface.birch"
void birch::type::Surface::destroy() {
  #line 12 "src/Surface.birch"
  libbirch_function_("destroy", "src/Surface.birch", 12);
  #line 13 "src/Surface.birch"

    cairo_surface_destroy(this->surface);
    }

#line 1 "src/Surface.birch"
birch::type::Surface* birch::type::make_Surface_() {
  #line 1 "src/Surface.birch"
  return new birch::type::Surface();
  #line 1 "src/Surface.birch"
}

#line 3 "src/SurfacePDF.birch"
birch::type::SurfacePDF::SurfacePDF() :
    #line 3 "src/SurfacePDF.birch"
    base_type_() {
  //
}

#line 3 "src/SurfacePDF.birch"
birch::type::SurfacePDF* birch::type::make_SurfacePDF_() {
  #line 3 "src/SurfacePDF.birch"
  return new birch::type::SurfacePDF();
  #line 3 "src/SurfacePDF.birch"
}

#line 15 "src/SurfacePDF.birch"
libbirch::Shared<birch::type::Surface> birch::createPDF(const birch::type::String& filename, const birch::type::Real& widthInPoints, const birch::type::Real& heightInPoints) {
  #line 15 "src/SurfacePDF.birch"
  libbirch_function_("createPDF", "src/SurfacePDF.birch", 15);
  #line 17 "src/SurfacePDF.birch"
  libbirch_line_(17);
  #line 17 "src/SurfacePDF.birch"
  birch::mkdir(filename);
  #line 18 "src/SurfacePDF.birch"
  libbirch_line_(18);
  #line 18 "src/SurfacePDF.birch"
  libbirch::Shared<birch::type::SurfacePDF> surface = libbirch::make<libbirch::Shared<birch::type::SurfacePDF>>();
  #line 19 "src/SurfacePDF.birch"

  surface->surface = cairo_pdf_surface_create(filename.c_str(),
      widthInPoints, heightInPoints);
    #line 23 "src/SurfacePDF.birch"
  libbirch_line_(23);
  #line 23 "src/SurfacePDF.birch"
  return surface;
}

#line 1 "src/SurfacePNG.birch"
birch::type::SurfacePNG::SurfacePNG() :
    #line 1 "src/SurfacePNG.birch"
    base_type_(),
    #line 5 "src/SurfacePNG.birch"
    filename(libbirch::make<birch::type::String>()) {
  //
}

#line 10 "src/SurfacePNG.birch"
void birch::type::SurfacePNG::destroy() {
  #line 10 "src/SurfacePNG.birch"
  libbirch_function_("destroy", "src/SurfacePNG.birch", 10);
  #line 12 "src/SurfacePNG.birch"
  libbirch_line_(12);
  #line 12 "src/SurfacePNG.birch"
  birch::mkdir(this->filename);
  #line 13 "src/SurfacePNG.birch"

    cairo_surface_write_to_png(this->surface, this->filename.c_str());
      #line 16 "src/SurfacePNG.birch"
  libbirch_line_(16);
  #line 16 "src/SurfacePNG.birch"
  this->base_type_::destroy();
}

#line 1 "src/SurfacePNG.birch"
birch::type::SurfacePNG* birch::type::make_SurfacePNG_() {
  #line 1 "src/SurfacePNG.birch"
  return new birch::type::SurfacePNG();
  #line 1 "src/SurfacePNG.birch"
}

#line 23 "src/SurfacePNG.birch"
libbirch::Shared<birch::type::Surface> birch::createPNG(const birch::type::String& filename, const birch::type::Integer& width, const birch::type::Integer& height) {
  #line 23 "src/SurfacePNG.birch"
  libbirch_function_("createPNG", "src/SurfacePNG.birch", 23);
  #line 25 "src/SurfacePNG.birch"
  libbirch_line_(25);
  #line 25 "src/SurfacePNG.birch"
  libbirch::Shared<birch::type::SurfacePNG> surface = libbirch::make<libbirch::Shared<birch::type::SurfacePNG>>();
  #line 26 "src/SurfacePNG.birch"

  surface->filename = filename;
  surface->surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32,
      width, height);
    #line 31 "src/SurfacePNG.birch"
  libbirch_line_(31);
  #line 31 "src/SurfacePNG.birch"
  return surface;
}

#line 3 "src/SurfaceSVG.birch"
birch::type::SurfaceSVG::SurfaceSVG() :
    #line 3 "src/SurfaceSVG.birch"
    base_type_() {
  //
}

#line 3 "src/SurfaceSVG.birch"
birch::type::SurfaceSVG* birch::type::make_SurfaceSVG_() {
  #line 3 "src/SurfaceSVG.birch"
  return new birch::type::SurfaceSVG();
  #line 3 "src/SurfaceSVG.birch"
}

#line 15 "src/SurfaceSVG.birch"
libbirch::Shared<birch::type::Surface> birch::createSVG(const birch::type::String& filename, const birch::type::Real& widthInPoints, const birch::type::Real& heightInPoints) {
  #line 15 "src/SurfaceSVG.birch"
  libbirch_function_("createSVG", "src/SurfaceSVG.birch", 15);
  #line 17 "src/SurfaceSVG.birch"
  libbirch_line_(17);
  #line 17 "src/SurfaceSVG.birch"
  birch::mkdir(filename);
  #line 18 "src/SurfaceSVG.birch"
  libbirch_line_(18);
  #line 18 "src/SurfaceSVG.birch"
  libbirch::Shared<birch::type::SurfaceSVG> surface = libbirch::make<libbirch::Shared<birch::type::SurfaceSVG>>();
  #line 19 "src/SurfaceSVG.birch"

  surface->surface = cairo_svg_surface_create(filename.c_str(),
      widthInPoints, heightInPoints);
    #line 23 "src/SurfaceSVG.birch"
  libbirch_line_(23);
  #line 23 "src/SurfaceSVG.birch"
  return surface;
}

