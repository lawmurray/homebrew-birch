#line 3 "src/Context.birch"
birch::type::Context::Context(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 3 "src/Context.birch"
    super_type_() {
  //
}

#line 13 "src/Context.birch"
void birch::type::Context::destroy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 13 "src/Context.birch"
  libbirch_function_("destroy", "src/Context.birch", 13);
  #line 14 "src/Context.birch"
cairo_destroy(this->cr);
    }

#line 23 "src/Context.birch"
void birch::type::Context::newPath(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "src/Context.birch"
  libbirch_function_("newPath", "src/Context.birch", 23);
  #line 24 "src/Context.birch"
cairo_new_path(this->cr);
    }

#line 29 "src/Context.birch"
void birch::type::Context::closePath(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "src/Context.birch"
  libbirch_function_("closePath", "src/Context.birch", 29);
  #line 30 "src/Context.birch"
cairo_close_path(this->cr);
    }

#line 35 "src/Context.birch"
void birch::type::Context::arc(const birch::type::Real& xc, const birch::type::Real& yc, const birch::type::Real& radius, const birch::type::Real& angle1, const birch::type::Real& angle2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "src/Context.birch"
  libbirch_function_("arc", "src/Context.birch", 35);
  #line 36 "src/Context.birch"
cairo_arc(this->cr, xc, yc, radius, angle1, angle2);
    }

#line 41 "src/Context.birch"
void birch::type::Context::arcNegative(const birch::type::Real& xc, const birch::type::Real& yc, const birch::type::Real& radius, const birch::type::Real& angle1, const birch::type::Real& angle2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "src/Context.birch"
  libbirch_function_("arcNegative", "src/Context.birch", 41);
  #line 42 "src/Context.birch"
cairo_arc_negative(this->cr, xc, yc, radius, angle1, angle2);
    }

#line 47 "src/Context.birch"
void birch::type::Context::curveTo(const birch::type::Real& x1, const birch::type::Real& y1, const birch::type::Real& x2, const birch::type::Real& y2, const birch::type::Real& x3, const birch::type::Real& y3, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "src/Context.birch"
  libbirch_function_("curveTo", "src/Context.birch", 47);
  #line 48 "src/Context.birch"
cairo_curve_to(this->cr, x1, y1, x2, y2, x3, y3);
    }

#line 53 "src/Context.birch"
void birch::type::Context::lineTo(const birch::type::Real& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "src/Context.birch"
  libbirch_function_("lineTo", "src/Context.birch", 53);
  #line 54 "src/Context.birch"
cairo_line_to(this->cr, x, y);
    }

#line 59 "src/Context.birch"
void birch::type::Context::moveTo(const birch::type::Real& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/Context.birch"
  libbirch_function_("moveTo", "src/Context.birch", 59);
  #line 60 "src/Context.birch"
cairo_move_to(this->cr, x, y);
    }

#line 65 "src/Context.birch"
void birch::type::Context::rectangle(const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& width, const birch::type::Real& height, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "src/Context.birch"
  libbirch_function_("rectangle", "src/Context.birch", 65);
  #line 66 "src/Context.birch"
cairo_rectangle(this->cr, x, y, width, height);
    }

#line 71 "src/Context.birch"
void birch::type::Context::relCurveTo(const birch::type::Real& dx1, const birch::type::Real& dy1, const birch::type::Real& dx2, const birch::type::Real& dy2, const birch::type::Real& dx3, const birch::type::Real& dy3, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 71 "src/Context.birch"
  libbirch_function_("relCurveTo", "src/Context.birch", 71);
  #line 72 "src/Context.birch"
cairo_curve_to(this->cr, dx1, dy1, dx2, dy2, dx3, dy3);
    }

#line 77 "src/Context.birch"
void birch::type::Context::relLineTo(const birch::type::Real& dx, const birch::type::Real& dy, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 77 "src/Context.birch"
  libbirch_function_("relLineTo", "src/Context.birch", 77);
  #line 78 "src/Context.birch"
cairo_line_to(this->cr, dx, dy);
    }

#line 83 "src/Context.birch"
void birch::type::Context::relMoveTo(const birch::type::Real& dx, const birch::type::Real& dy, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 83 "src/Context.birch"
  libbirch_function_("relMoveTo", "src/Context.birch", 83);
  #line 84 "src/Context.birch"
cairo_move_to(this->cr, dx, dy);
    }

#line 89 "src/Context.birch"
void birch::type::Context::stroke(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 89 "src/Context.birch"
  libbirch_function_("stroke", "src/Context.birch", 89);
  #line 90 "src/Context.birch"
cairo_stroke(this->cr);
    }

#line 95 "src/Context.birch"
void birch::type::Context::strokePreserve(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "src/Context.birch"
  libbirch_function_("strokePreserve", "src/Context.birch", 95);
  #line 96 "src/Context.birch"
cairo_stroke_preserve(this->cr);
    }

#line 101 "src/Context.birch"
void birch::type::Context::fill(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 101 "src/Context.birch"
  libbirch_function_("fill", "src/Context.birch", 101);
  #line 102 "src/Context.birch"
cairo_fill(this->cr);
    }

#line 107 "src/Context.birch"
void birch::type::Context::fillPreserve(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 107 "src/Context.birch"
  libbirch_function_("fillPreserve", "src/Context.birch", 107);
  #line 108 "src/Context.birch"
cairo_fill_preserve(this->cr);
    }

#line 113 "src/Context.birch"
void birch::type::Context::paint(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 113 "src/Context.birch"
  libbirch_function_("paint", "src/Context.birch", 113);
  #line 114 "src/Context.birch"
cairo_paint(this->cr);
    }

#line 123 "src/Context.birch"
void birch::type::Context::translate(const birch::type::Real& tx, const birch::type::Real& ty, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 123 "src/Context.birch"
  libbirch_function_("translate", "src/Context.birch", 123);
  #line 124 "src/Context.birch"
cairo_translate(this->cr, tx, ty);
    }

#line 129 "src/Context.birch"
void birch::type::Context::scale(const birch::type::Real& sx, const birch::type::Real& sy, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 129 "src/Context.birch"
  libbirch_function_("scale", "src/Context.birch", 129);
  #line 130 "src/Context.birch"
cairo_scale(this->cr, sx, sy);
    }

#line 135 "src/Context.birch"
void birch::type::Context::rotate(const birch::type::Real& angle, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 135 "src/Context.birch"
  libbirch_function_("rotate", "src/Context.birch", 135);
  #line 136 "src/Context.birch"
cairo_rotate(this->cr, angle);
    }

#line 141 "src/Context.birch"
libbirch::Tuple<birch::type::Real, birch::type::Real> birch::type::Context::deviceToUserDistance(const birch::type::Real& ux, const birch::type::Real& uy, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 141 "src/Context.birch"
  libbirch_function_("deviceToUserDistance", "src/Context.birch", 141);
  #line 142 "src/Context.birch"
  libbirch_line_(142);
  #line 142 "src/Context.birch"
  birch::type::Real ux1 = ux;
  #line 143 "src/Context.birch"
  libbirch_line_(143);
  #line 143 "src/Context.birch"
  birch::type::Real uy1 = uy;
  #line 144 "src/Context.birch"
cairo_device_to_user_distance(this->cr, &ux1, &uy1);
      #line 147 "src/Context.birch"
  libbirch_line_(147);
  #line 147 "src/Context.birch"
  return libbirch::make_tuple(ux1, uy1);
}

#line 154 "src/Context.birch"
void birch::type::Context::setSourceRGB(const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 154 "src/Context.birch"
  libbirch_function_("setSourceRGB", "src/Context.birch", 154);
  #line 155 "src/Context.birch"
cairo_set_source_rgb(this->cr, red, green, blue);
    }

#line 160 "src/Context.birch"
void birch::type::Context::setSourceRGBA(const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue, const birch::type::Real& alpha, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 160 "src/Context.birch"
  libbirch_function_("setSourceRGBA", "src/Context.birch", 160);
  #line 161 "src/Context.birch"
cairo_set_source_rgba(this->cr, red, green, blue, alpha);
    }

#line 166 "src/Context.birch"
void birch::type::Context::setSource(const libbirch::Lazy<libbirch::Shared<birch::type::Pattern>>& pattern, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 166 "src/Context.birch"
  libbirch_function_("setSource", "src/Context.birch", 166);
  #line 167 "src/Context.birch"
cairo_set_source(this->cr, pattern->pattern);
    }

#line 172 "src/Context.birch"
void birch::type::Context::setLineWidth(const birch::type::Real& width, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 172 "src/Context.birch"
  libbirch_function_("setLineWidth", "src/Context.birch", 172);
  #line 173 "src/Context.birch"
cairo_set_line_width(this->cr, width);
    }

#line 182 "src/Context.birch"
void birch::type::Context::showText(const birch::type::String& utf8, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 182 "src/Context.birch"
  libbirch_function_("showText", "src/Context.birch", 182);
  #line 183 "src/Context.birch"
cairo_show_text(this->cr, utf8.c_str());
    }

#line 188 "src/Context.birch"
void birch::type::Context::setFontSize(const birch::type::Real& size, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 188 "src/Context.birch"
  libbirch_function_("setFontSize", "src/Context.birch", 188);
  #line 189 "src/Context.birch"
cairo_set_font_size(this->cr, size);
    }

#line 198 "src/Context.birch"
void birch::type::Context::pushGroup(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 198 "src/Context.birch"
  libbirch_function_("pushGroup", "src/Context.birch", 198);
  #line 199 "src/Context.birch"
cairo_push_group(this->cr);
    }

#line 204 "src/Context.birch"
void birch::type::Context::popGroupToSource(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 204 "src/Context.birch"
  libbirch_function_("popGroupToSource", "src/Context.birch", 204);
  #line 205 "src/Context.birch"
cairo_pop_group_to_source(this->cr);
    }

#line 3 "src/Context.birch"
birch::type::Context* birch::type::make_Context_() {
  #line 3 "src/Context.birch"
  return new birch::type::Context();
  #line 3 "src/Context.birch"
}

#line 211 "src/Context.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Context>> birch::create(const libbirch::Lazy<libbirch::Shared<birch::type::Surface>>& surface, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 211 "src/Context.birch"
  libbirch_function_("create", "src/Context.birch", 211);
  #line 212 "src/Context.birch"
  libbirch_line_(212);
  #line 212 "src/Context.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Context>> cr;
  #line 213 "src/Context.birch"
cr->cr = cairo_create(surface->surface);
    #line 216 "src/Context.birch"
  libbirch_line_(216);
  #line 216 "src/Context.birch"
  return cr;
}

#line 1 "src/Pattern.birch"
birch::type::Pattern::Pattern(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/Pattern.birch"
    super_type_() {
  //
}

#line 9 "src/Pattern.birch"
void birch::type::Pattern::addColorStopRGB(const birch::type::Real& offset, const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/Pattern.birch"
  libbirch_function_("addColorStopRGB", "src/Pattern.birch", 9);
  #line 10 "src/Pattern.birch"
cairo_pattern_add_color_stop_rgb(this->pattern, offset, red, green, blue);
    }

#line 15 "src/Pattern.birch"
void birch::type::Pattern::addColorStopRGBA(const birch::type::Real& offset, const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue, const birch::type::Real& alpha, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/Pattern.birch"
  libbirch_function_("addColorStopRGBA", "src/Pattern.birch", 15);
  #line 17 "src/Pattern.birch"
cairo_pattern_add_color_stop_rgba(this->pattern, offset, red, green, blue,
        alpha);
    }

#line 23 "src/Pattern.birch"
void birch::type::Pattern::destroy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "src/Pattern.birch"
  libbirch_function_("destroy", "src/Pattern.birch", 23);
  #line 24 "src/Pattern.birch"
cairo_pattern_destroy(this->pattern);
    }

#line 1 "src/Pattern.birch"
birch::type::Pattern* birch::type::make_Pattern_() {
  #line 1 "src/Pattern.birch"
  return new birch::type::Pattern();
  #line 1 "src/Pattern.birch"
}

#line 30 "src/Pattern.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Pattern>> birch::createRGB(const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/Pattern.birch"
  libbirch_function_("createRGB", "src/Pattern.birch", 30);
  #line 31 "src/Pattern.birch"
  libbirch_line_(31);
  #line 31 "src/Pattern.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Pattern>> result;
  #line 32 "src/Pattern.birch"
result->pattern = cairo_pattern_create_rgb(red, green, blue);
    #line 35 "src/Pattern.birch"
  libbirch_line_(35);
  #line 35 "src/Pattern.birch"
  return result;
}

#line 38 "src/Pattern.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Pattern>> birch::createRGBA(const birch::type::Real& red, const birch::type::Real& green, const birch::type::Real& blue, const birch::type::Real& alpha, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "src/Pattern.birch"
  libbirch_function_("createRGBA", "src/Pattern.birch", 38);
  #line 39 "src/Pattern.birch"
  libbirch_line_(39);
  #line 39 "src/Pattern.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Pattern>> result;
  #line 40 "src/Pattern.birch"
result->pattern = cairo_pattern_create_rgba(red, green, blue, alpha);
    #line 43 "src/Pattern.birch"
  libbirch_line_(43);
  #line 43 "src/Pattern.birch"
  return result;
}

#line 46 "src/Pattern.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Pattern>> birch::createLinear(const birch::type::Real& x0, const birch::type::Real& y0, const birch::type::Real& x1, const birch::type::Real& y1, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/Pattern.birch"
  libbirch_function_("createLinear", "src/Pattern.birch", 46);
  #line 47 "src/Pattern.birch"
  libbirch_line_(47);
  #line 47 "src/Pattern.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Pattern>> result;
  #line 48 "src/Pattern.birch"
result->pattern = cairo_pattern_create_linear(x0, y0, x1, y1);
    #line 51 "src/Pattern.birch"
  libbirch_line_(51);
  #line 51 "src/Pattern.birch"
  return result;
}

#line 54 "src/Pattern.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Pattern>> birch::createRadial(const birch::type::Real& cx0, const birch::type::Real& cy0, const birch::type::Real& radius0, const birch::type::Real& cx1, const birch::type::Real& cy1, const birch::type::Real& radius1, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "src/Pattern.birch"
  libbirch_function_("createRadial", "src/Pattern.birch", 54);
  #line 56 "src/Pattern.birch"
  libbirch_line_(56);
  #line 56 "src/Pattern.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Pattern>> result;
  #line 57 "src/Pattern.birch"
result->pattern = cairo_pattern_create_radial(cx0, cy0, radius0, cx1,
      cy1, radius1);
    #line 61 "src/Pattern.birch"
  libbirch_line_(61);
  #line 61 "src/Pattern.birch"
  return result;
}

#line 1 "src/Surface.birch"
birch::type::Surface::Surface(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/Surface.birch"
    super_type_() {
  //
}

#line 9 "src/Surface.birch"
void birch::type::Surface::destroy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/Surface.birch"
  libbirch_function_("destroy", "src/Surface.birch", 9);
  #line 10 "src/Surface.birch"
cairo_surface_destroy(this->surface);
    }

#line 1 "src/Surface.birch"
birch::type::Surface* birch::type::make_Surface_() {
  #line 1 "src/Surface.birch"
  return new birch::type::Surface();
  #line 1 "src/Surface.birch"
}

#line 3 "src/SurfacePDF.birch"
birch::type::SurfacePDF::SurfacePDF(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 3 "src/SurfacePDF.birch"
    super_type_() {
  //
}

#line 3 "src/SurfacePDF.birch"
birch::type::SurfacePDF* birch::type::make_SurfacePDF_() {
  #line 3 "src/SurfacePDF.birch"
  return new birch::type::SurfacePDF();
  #line 3 "src/SurfacePDF.birch"
}

#line 12 "src/SurfacePDF.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Surface>> birch::createPDF(const birch::type::String& filename, const birch::type::Real& widthInPoints, const birch::type::Real& heightInPoints, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 12 "src/SurfacePDF.birch"
  libbirch_function_("createPDF", "src/SurfacePDF.birch", 12);
  #line 14 "src/SurfacePDF.birch"
  libbirch_line_(14);
  #line 14 "src/SurfacePDF.birch"
  birch::mkdir(filename, handler_);
  #line 15 "src/SurfacePDF.birch"
  libbirch_line_(15);
  #line 15 "src/SurfacePDF.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::SurfacePDF>> surface;
  #line 16 "src/SurfacePDF.birch"
surface->surface = cairo_pdf_surface_create(filename.c_str(),
      widthInPoints, heightInPoints);
    #line 20 "src/SurfacePDF.birch"
  libbirch_line_(20);
  #line 20 "src/SurfacePDF.birch"
  return surface;
}

#line 1 "src/SurfacePNG.birch"
birch::type::SurfacePNG::SurfacePNG(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/SurfacePNG.birch"
    super_type_(),
    #line 5 "src/SurfacePNG.birch"
    filename() {
  //
}

#line 7 "src/SurfacePNG.birch"
void birch::type::SurfacePNG::destroy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/SurfacePNG.birch"
  libbirch_function_("destroy", "src/SurfacePNG.birch", 7);
  #line 9 "src/SurfacePNG.birch"
  libbirch_line_(9);
  #line 9 "src/SurfacePNG.birch"
  birch::mkdir(this_()->filename, handler_);
  #line 10 "src/SurfacePNG.birch"
cairo_surface_write_to_png(this->surface, this->filename.c_str());
      #line 13 "src/SurfacePNG.birch"
  libbirch_line_(13);
  #line 13 "src/SurfacePNG.birch"
  this_()->super_type_::destroy(handler_);
}

#line 1 "src/SurfacePNG.birch"
birch::type::SurfacePNG* birch::type::make_SurfacePNG_() {
  #line 1 "src/SurfacePNG.birch"
  return new birch::type::SurfacePNG();
  #line 1 "src/SurfacePNG.birch"
}

#line 17 "src/SurfacePNG.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Surface>> birch::createPNG(const birch::type::String& filename, const birch::type::Integer& width, const birch::type::Integer& height, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 17 "src/SurfacePNG.birch"
  libbirch_function_("createPNG", "src/SurfacePNG.birch", 17);
  #line 19 "src/SurfacePNG.birch"
  libbirch_line_(19);
  #line 19 "src/SurfacePNG.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::SurfacePNG>> surface;
  #line 20 "src/SurfacePNG.birch"
surface->filename = filename;
  surface->surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32,
      width, height);
    #line 25 "src/SurfacePNG.birch"
  libbirch_line_(25);
  #line 25 "src/SurfacePNG.birch"
  return surface;
}

#line 3 "src/SurfaceSVG.birch"
birch::type::SurfaceSVG::SurfaceSVG(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 3 "src/SurfaceSVG.birch"
    super_type_() {
  //
}

#line 3 "src/SurfaceSVG.birch"
birch::type::SurfaceSVG* birch::type::make_SurfaceSVG_() {
  #line 3 "src/SurfaceSVG.birch"
  return new birch::type::SurfaceSVG();
  #line 3 "src/SurfaceSVG.birch"
}

#line 12 "src/SurfaceSVG.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Surface>> birch::createSVG(const birch::type::String& filename, const birch::type::Real& widthInPoints, const birch::type::Real& heightInPoints, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 12 "src/SurfaceSVG.birch"
  libbirch_function_("createSVG", "src/SurfaceSVG.birch", 12);
  #line 14 "src/SurfaceSVG.birch"
  libbirch_line_(14);
  #line 14 "src/SurfaceSVG.birch"
  birch::mkdir(filename, handler_);
  #line 15 "src/SurfaceSVG.birch"
  libbirch_line_(15);
  #line 15 "src/SurfaceSVG.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::SurfaceSVG>> surface;
  #line 16 "src/SurfaceSVG.birch"
surface->surface = cairo_svg_surface_create(filename.c_str(),
      widthInPoints, heightInPoints);
    #line 20 "src/SurfaceSVG.birch"
  libbirch_line_(20);
  #line 20 "src/SurfaceSVG.birch"
  return surface;
}

