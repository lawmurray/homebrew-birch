#line 4 "src/expression/Abs.birch"
birch::type::Abs::Abs(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) :
    #line 4 "src/expression/Abs.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 6 "src/expression/Abs.birch"
birch::type::Real birch::type::Abs::doEvaluate(const birch::type::Real& y) {
  #line 6 "src/expression/Abs.birch"
  libbirch_function_("doEvaluate", "src/expression/Abs.birch", 6);
  #line 7 "src/expression/Abs.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Abs.birch"
  return birch::abs(y);
}

#line 10 "src/expression/Abs.birch"
birch::type::Real birch::type::Abs::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y) {
  #line 10 "src/expression/Abs.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Abs.birch", 10);
  #line 11 "src/expression/Abs.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Abs.birch"
  if (x >= 0.0) {
    #line 12 "src/expression/Abs.birch"
    libbirch_line_(12);
    #line 12 "src/expression/Abs.birch"
    return d;
  } else {
    #line 14 "src/expression/Abs.birch"
    libbirch_line_(14);
    #line 14 "src/expression/Abs.birch"
    return -(d);
  }
}

#line 22 "src/expression/Abs.birch"
libbirch::Shared<birch::type::Abs> birch::abs(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) {
  #line 22 "src/expression/Abs.birch"
  libbirch_function_("abs", "src/expression/Abs.birch", 22);
  #line 23 "src/expression/Abs.birch"
  libbirch_line_(23);
  #line 23 "src/expression/Abs.birch"
  return birch::construct<libbirch::Shared<birch::type::Abs>>(y);
}

#line 4 "src/expression/Acos.birch"
birch::type::Acos::Acos(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) :
    #line 4 "src/expression/Acos.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 6 "src/expression/Acos.birch"
birch::type::Real birch::type::Acos::doEvaluate(const birch::type::Real& y) {
  #line 6 "src/expression/Acos.birch"
  libbirch_function_("doEvaluate", "src/expression/Acos.birch", 6);
  #line 7 "src/expression/Acos.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Acos.birch"
  return birch::acos(y);
}

#line 10 "src/expression/Acos.birch"
birch::type::Real birch::type::Acos::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y) {
  #line 10 "src/expression/Acos.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Acos.birch", 10);
  #line 11 "src/expression/Acos.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Acos.birch"
  return -(d) / birch::sqrt(1.0 - y * y);
}

#line 18 "src/expression/Acos.birch"
libbirch::Shared<birch::type::Acos> birch::acos(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) {
  #line 18 "src/expression/Acos.birch"
  libbirch_function_("acos", "src/expression/Acos.birch", 18);
  #line 19 "src/expression/Acos.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Acos.birch"
  return birch::construct<libbirch::Shared<birch::type::Acos>>(y);
}

#line 4 "src/expression/Add.birch"
birch::type::Add::Add(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) :
    #line 4 "src/expression/Add.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/Add.birch"
birch::type::Real birch::type::Add::doEvaluate(const birch::type::Real& y, const birch::type::Real& z) {
  #line 7 "src/expression/Add.birch"
  libbirch_function_("doEvaluate", "src/expression/Add.birch", 7);
  #line 8 "src/expression/Add.birch"
  libbirch_line_(8);
  #line 8 "src/expression/Add.birch"
  return y + z;
}

#line 11 "src/expression/Add.birch"
birch::type::Real birch::type::Add::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z) {
  #line 11 "src/expression/Add.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/Add.birch", 11);
  #line 13 "src/expression/Add.birch"
  libbirch_line_(13);
  #line 13 "src/expression/Add.birch"
  return d;
}

#line 16 "src/expression/Add.birch"
birch::type::Real birch::type::Add::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z) {
  #line 16 "src/expression/Add.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/Add.birch", 16);
  #line 18 "src/expression/Add.birch"
  libbirch_line_(18);
  #line 18 "src/expression/Add.birch"
  return d;
}

#line 21 "src/expression/Add.birch"
std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gaussian>>>> birch::type::Add::graftLinearGaussian() {
  #line 21 "src/expression/Add.birch"
  libbirch_function_("graftLinearGaussian", "src/expression/Add.birch", 21);
  #line 22 "src/expression/Add.birch"
  libbirch_line_(22);
  #line 22 "src/expression/Add.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gaussian>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gaussian>>>>>();
  #line 23 "src/expression/Add.birch"
  libbirch_line_(23);
  #line 23 "src/expression/Add.birch"
  if (!(this->hasValue())) {
    #line 24 "src/expression/Add.birch"
    libbirch_line_(24);
    #line 24 "src/expression/Add.birch"
    std::optional<libbirch::Shared<birch::type::Gaussian>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::Gaussian>>>();
    #line 26 "src/expression/Add.birch"
    libbirch_line_(26);
    #line 26 "src/expression/Add.birch"
    if ((r = this->y.value()->graftLinearGaussian()).has_value()) {
      #line 27 "src/expression/Add.birch"
      libbirch_line_(27);
      #line 27 "src/expression/Add.birch"
      r.value()->add(this->z.value());
    } else {
      #line 28 "src/expression/Add.birch"
      libbirch_line_(28);
      #line 28 "src/expression/Add.birch"
      if ((r = this->z.value()->graftLinearGaussian()).has_value()) {
        #line 29 "src/expression/Add.birch"
        libbirch_line_(29);
        #line 29 "src/expression/Add.birch"
        r.value()->add(this->y.value());
      } else {
        #line 30 "src/expression/Add.birch"
        libbirch_line_(30);
        #line 30 "src/expression/Add.birch"
        if ((x1 = this->y.value()->graftGaussian()).has_value()) {
          #line 31 "src/expression/Add.birch"
          libbirch_line_(31);
          #line 31 "src/expression/Add.birch"
          r = birch::TransformLinear<libbirch::Shared<birch::type::Gaussian>>(birch::box(1.0), x1.value(), this->z.value());
        } else {
          #line 32 "src/expression/Add.birch"
          libbirch_line_(32);
          #line 32 "src/expression/Add.birch"
          if ((x1 = this->z.value()->graftGaussian()).has_value()) {
            #line 33 "src/expression/Add.birch"
            libbirch_line_(33);
            #line 33 "src/expression/Add.birch"
            r = birch::TransformLinear<libbirch::Shared<birch::type::Gaussian>>(birch::box(1.0), x1.value(), this->y.value());
          }
        }
      }
    }
  }
  #line 36 "src/expression/Add.birch"
  libbirch_line_(36);
  #line 36 "src/expression/Add.birch"
  return r;
}

#line 39 "src/expression/Add.birch"
std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateGaussian>>>> birch::type::Add::graftDotMultivariateGaussian() {
  #line 39 "src/expression/Add.birch"
  libbirch_function_("graftDotMultivariateGaussian", "src/expression/Add.birch", 39);
  #line 41 "src/expression/Add.birch"
  libbirch_line_(41);
  #line 41 "src/expression/Add.birch"
  std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateGaussian>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateGaussian>>>>>();
  #line 42 "src/expression/Add.birch"
  libbirch_line_(42);
  #line 42 "src/expression/Add.birch"
  if (!(this->hasValue())) {
    #line 43 "src/expression/Add.birch"
    libbirch_line_(43);
    #line 43 "src/expression/Add.birch"
    if ((r = this->y.value()->graftDotMultivariateGaussian()).has_value()) {
      #line 44 "src/expression/Add.birch"
      libbirch_line_(44);
      #line 44 "src/expression/Add.birch"
      r.value()->add(this->z.value());
    } else {
      #line 45 "src/expression/Add.birch"
      libbirch_line_(45);
      #line 45 "src/expression/Add.birch"
      if ((r = this->z.value()->graftDotMultivariateGaussian()).has_value()) {
        #line 46 "src/expression/Add.birch"
        libbirch_line_(46);
        #line 46 "src/expression/Add.birch"
        r.value()->add(this->y.value());
      }
    }
  }
  #line 49 "src/expression/Add.birch"
  libbirch_line_(49);
  #line 49 "src/expression/Add.birch"
  return r;
}

#line 52 "src/expression/Add.birch"
std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>>> birch::type::Add::graftLinearNormalInverseGamma(const libbirch::Shared<birch::type::Distribution<birch::type::Real>>& compare) {
  #line 52 "src/expression/Add.birch"
  libbirch_function_("graftLinearNormalInverseGamma", "src/expression/Add.birch", 52);
  #line 54 "src/expression/Add.birch"
  libbirch_line_(54);
  #line 54 "src/expression/Add.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>>>>();
  #line 55 "src/expression/Add.birch"
  libbirch_line_(55);
  #line 55 "src/expression/Add.birch"
  std::optional<libbirch::Shared<birch::type::NormalInverseGamma>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::NormalInverseGamma>>>();
  #line 56 "src/expression/Add.birch"
  libbirch_line_(56);
  #line 56 "src/expression/Add.birch"
  if (!(this->hasValue())) {
    #line 57 "src/expression/Add.birch"
    libbirch_line_(57);
    #line 57 "src/expression/Add.birch"
    if ((r = this->y.value()->graftLinearNormalInverseGamma(compare)).has_value()) {
      #line 58 "src/expression/Add.birch"
      libbirch_line_(58);
      #line 58 "src/expression/Add.birch"
      r.value()->add(this->z.value());
    } else {
      #line 59 "src/expression/Add.birch"
      libbirch_line_(59);
      #line 59 "src/expression/Add.birch"
      if ((r = this->z.value()->graftLinearNormalInverseGamma(compare)).has_value()) {
        #line 60 "src/expression/Add.birch"
        libbirch_line_(60);
        #line 60 "src/expression/Add.birch"
        r.value()->add(this->y.value());
      } else {
        #line 61 "src/expression/Add.birch"
        libbirch_line_(61);
        #line 61 "src/expression/Add.birch"
        if ((x1 = this->y.value()->graftNormalInverseGamma(compare)).has_value()) {
          #line 62 "src/expression/Add.birch"
          libbirch_line_(62);
          #line 62 "src/expression/Add.birch"
          r = birch::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>(birch::box(1.0), x1.value(), this->z.value());
        } else {
          #line 63 "src/expression/Add.birch"
          libbirch_line_(63);
          #line 63 "src/expression/Add.birch"
          if ((x1 = this->z.value()->graftNormalInverseGamma(compare)).has_value()) {
            #line 64 "src/expression/Add.birch"
            libbirch_line_(64);
            #line 64 "src/expression/Add.birch"
            r = birch::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>(birch::box(1.0), x1.value(), this->y.value());
          }
        }
      }
    }
  }
  #line 67 "src/expression/Add.birch"
  libbirch_line_(67);
  #line 67 "src/expression/Add.birch"
  return r;
}

#line 70 "src/expression/Add.birch"
std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>> birch::type::Add::graftDotMultivariateNormalInverseGamma(const libbirch::Shared<birch::type::Distribution<birch::type::Real>>& compare) {
  #line 70 "src/expression/Add.birch"
  libbirch_function_("graftDotMultivariateNormalInverseGamma", "src/expression/Add.birch", 70);
  #line 72 "src/expression/Add.birch"
  libbirch_line_(72);
  #line 72 "src/expression/Add.birch"
  std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>();
  #line 73 "src/expression/Add.birch"
  libbirch_line_(73);
  #line 73 "src/expression/Add.birch"
  if (!(this->hasValue())) {
    #line 74 "src/expression/Add.birch"
    libbirch_line_(74);
    #line 74 "src/expression/Add.birch"
    if ((r = this->y.value()->graftDotMultivariateNormalInverseGamma(compare)).has_value()) {
      #line 75 "src/expression/Add.birch"
      libbirch_line_(75);
      #line 75 "src/expression/Add.birch"
      r.value()->add(this->z.value());
    } else {
      #line 76 "src/expression/Add.birch"
      libbirch_line_(76);
      #line 76 "src/expression/Add.birch"
      if ((r = this->z.value()->graftDotMultivariateNormalInverseGamma(compare)).has_value()) {
        #line 77 "src/expression/Add.birch"
        libbirch_line_(77);
        #line 77 "src/expression/Add.birch"
        r.value()->add(this->y.value());
      }
    }
  }
  #line 80 "src/expression/Add.birch"
  libbirch_line_(80);
  #line 80 "src/expression/Add.birch"
  return r;
}

#line 87 "src/expression/Add.birch"
libbirch::Shared<birch::type::Add> birch::operator+(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 87 "src/expression/Add.birch"
  libbirch_function_("+", "src/expression/Add.birch", 87);
  #line 88 "src/expression/Add.birch"
  libbirch_line_(88);
  #line 88 "src/expression/Add.birch"
  return birch::construct<libbirch::Shared<birch::type::Add>>(y, z);
}

#line 94 "src/expression/Add.birch"
libbirch::Shared<birch::type::Add> birch::operator+(const birch::type::Real& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 94 "src/expression/Add.birch"
  libbirch_function_("+", "src/expression/Add.birch", 94);
  #line 95 "src/expression/Add.birch"
  libbirch_line_(95);
  #line 95 "src/expression/Add.birch"
  return birch::box(y) + z;
}

#line 101 "src/expression/Add.birch"
libbirch::Shared<birch::type::Add> birch::operator+(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const birch::type::Real& z) {
  #line 101 "src/expression/Add.birch"
  libbirch_function_("+", "src/expression/Add.birch", 101);
  #line 102 "src/expression/Add.birch"
  libbirch_line_(102);
  #line 102 "src/expression/Add.birch"
  return y + birch::box(z);
}

#line 4 "src/expression/Asin.birch"
birch::type::Asin::Asin(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) :
    #line 4 "src/expression/Asin.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 6 "src/expression/Asin.birch"
birch::type::Real birch::type::Asin::doEvaluate(const birch::type::Real& y) {
  #line 6 "src/expression/Asin.birch"
  libbirch_function_("doEvaluate", "src/expression/Asin.birch", 6);
  #line 7 "src/expression/Asin.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Asin.birch"
  return birch::asin(y);
}

#line 10 "src/expression/Asin.birch"
birch::type::Real birch::type::Asin::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y) {
  #line 10 "src/expression/Asin.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Asin.birch", 10);
  #line 11 "src/expression/Asin.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Asin.birch"
  return d / birch::sqrt(1.0 - y * y);
}

#line 18 "src/expression/Asin.birch"
libbirch::Shared<birch::type::Asin> birch::asin(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) {
  #line 18 "src/expression/Asin.birch"
  libbirch_function_("asin", "src/expression/Asin.birch", 18);
  #line 19 "src/expression/Asin.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Asin.birch"
  return birch::construct<libbirch::Shared<birch::type::Asin>>(y);
}

#line 4 "src/expression/Atan.birch"
birch::type::Atan::Atan(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) :
    #line 4 "src/expression/Atan.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 6 "src/expression/Atan.birch"
birch::type::Real birch::type::Atan::doEvaluate(const birch::type::Real& y) {
  #line 6 "src/expression/Atan.birch"
  libbirch_function_("doEvaluate", "src/expression/Atan.birch", 6);
  #line 7 "src/expression/Atan.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Atan.birch"
  return birch::atan(y);
}

#line 10 "src/expression/Atan.birch"
birch::type::Real birch::type::Atan::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y) {
  #line 10 "src/expression/Atan.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Atan.birch", 10);
  #line 11 "src/expression/Atan.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Atan.birch"
  return d / (1.0 + y * y);
}

#line 18 "src/expression/Atan.birch"
libbirch::Shared<birch::type::Atan> birch::atan(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) {
  #line 18 "src/expression/Atan.birch"
  libbirch_function_("atan", "src/expression/Atan.birch", 18);
  #line 19 "src/expression/Atan.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Atan.birch"
  return birch::construct<libbirch::Shared<birch::type::Atan>>(y);
}

#line 18 "src/expression/Cast.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::Real(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) {
  #line 18 "src/expression/Cast.birch"
  libbirch_function_("Real", "src/expression/Cast.birch", 18);
  #line 19 "src/expression/Cast.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Cast.birch"
  return y;
}

#line 25 "src/expression/Cast.birch"
libbirch::Shared<birch::type::Cast<birch::type::Integer, birch::type::Real>> birch::Real(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& y) {
  #line 25 "src/expression/Cast.birch"
  libbirch_function_("Real", "src/expression/Cast.birch", 25);
  #line 26 "src/expression/Cast.birch"
  libbirch_line_(26);
  #line 26 "src/expression/Cast.birch"
  return birch::construct<libbirch::Shared<birch::type::Cast<birch::type::Integer, birch::type::Real>>>(y);
}

#line 32 "src/expression/Cast.birch"
libbirch::Shared<birch::type::Cast<birch::type::Boolean, birch::type::Real>> birch::Real(const libbirch::Shared<birch::type::Expression<birch::type::Boolean>>& y) {
  #line 32 "src/expression/Cast.birch"
  libbirch_function_("Real", "src/expression/Cast.birch", 32);
  #line 33 "src/expression/Cast.birch"
  libbirch_line_(33);
  #line 33 "src/expression/Cast.birch"
  return birch::construct<libbirch::Shared<birch::type::Cast<birch::type::Boolean, birch::type::Real>>>(y);
}

#line 4 "src/expression/CopySign.birch"
birch::type::CopySign::CopySign(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) :
    #line 4 "src/expression/CopySign.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/CopySign.birch"
birch::type::Real birch::type::CopySign::doEvaluate(const birch::type::Real& y, const birch::type::Real& z) {
  #line 7 "src/expression/CopySign.birch"
  libbirch_function_("doEvaluate", "src/expression/CopySign.birch", 7);
  #line 8 "src/expression/CopySign.birch"
  libbirch_line_(8);
  #line 8 "src/expression/CopySign.birch"
  return birch::copysign(y, z);
}

#line 11 "src/expression/CopySign.birch"
birch::type::Real birch::type::CopySign::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z) {
  #line 11 "src/expression/CopySign.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/CopySign.birch", 11);
  #line 13 "src/expression/CopySign.birch"
  libbirch_line_(13);
  #line 13 "src/expression/CopySign.birch"
  if (x == y) {
    #line 14 "src/expression/CopySign.birch"
    libbirch_line_(14);
    #line 14 "src/expression/CopySign.birch"
    return d;
  } else {
    #line 16 "src/expression/CopySign.birch"
    libbirch_line_(16);
    #line 16 "src/expression/CopySign.birch"
    return -(d);
  }
}

#line 20 "src/expression/CopySign.birch"
birch::type::Real birch::type::CopySign::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z) {
  #line 20 "src/expression/CopySign.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/CopySign.birch", 20);
  #line 22 "src/expression/CopySign.birch"
  libbirch_line_(22);
  #line 22 "src/expression/CopySign.birch"
  return 0.0;
}

#line 29 "src/expression/CopySign.birch"
libbirch::Shared<birch::type::CopySign> birch::copysign(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 29 "src/expression/CopySign.birch"
  libbirch_function_("copysign", "src/expression/CopySign.birch", 29);
  #line 30 "src/expression/CopySign.birch"
  libbirch_line_(30);
  #line 30 "src/expression/CopySign.birch"
  return birch::construct<libbirch::Shared<birch::type::CopySign>>(y, z);
}

#line 36 "src/expression/CopySign.birch"
libbirch::Shared<birch::type::CopySign> birch::copysign(const birch::type::Real& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 36 "src/expression/CopySign.birch"
  libbirch_function_("copysign", "src/expression/CopySign.birch", 36);
  #line 37 "src/expression/CopySign.birch"
  libbirch_line_(37);
  #line 37 "src/expression/CopySign.birch"
  return birch::copysign(birch::box(y), z);
}

#line 43 "src/expression/CopySign.birch"
libbirch::Shared<birch::type::CopySign> birch::copysign(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const birch::type::Real& z) {
  #line 43 "src/expression/CopySign.birch"
  libbirch_function_("copysign", "src/expression/CopySign.birch", 43);
  #line 44 "src/expression/CopySign.birch"
  libbirch_line_(44);
  #line 44 "src/expression/CopySign.birch"
  return birch::copysign(y, birch::box(z));
}

#line 4 "src/expression/Cos.birch"
birch::type::Cos::Cos(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) :
    #line 4 "src/expression/Cos.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 6 "src/expression/Cos.birch"
birch::type::Real birch::type::Cos::doEvaluate(const birch::type::Real& y) {
  #line 6 "src/expression/Cos.birch"
  libbirch_function_("doEvaluate", "src/expression/Cos.birch", 6);
  #line 7 "src/expression/Cos.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Cos.birch"
  return birch::cos(y);
}

#line 10 "src/expression/Cos.birch"
birch::type::Real birch::type::Cos::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y) {
  #line 10 "src/expression/Cos.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Cos.birch", 10);
  #line 11 "src/expression/Cos.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Cos.birch"
  return -(d) * birch::sin(y);
}

#line 18 "src/expression/Cos.birch"
libbirch::Shared<birch::type::Cos> birch::cos(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) {
  #line 18 "src/expression/Cos.birch"
  libbirch_function_("cos", "src/expression/Cos.birch", 18);
  #line 19 "src/expression/Cos.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Cos.birch"
  return birch::construct<libbirch::Shared<birch::type::Cos>>(y);
}

#line 4 "src/expression/Cosh.birch"
birch::type::Cosh::Cosh(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) :
    #line 4 "src/expression/Cosh.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 6 "src/expression/Cosh.birch"
birch::type::Real birch::type::Cosh::doEvaluate(const birch::type::Real& y) {
  #line 6 "src/expression/Cosh.birch"
  libbirch_function_("doEvaluate", "src/expression/Cosh.birch", 6);
  #line 7 "src/expression/Cosh.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Cosh.birch"
  return birch::cosh(y);
}

#line 10 "src/expression/Cosh.birch"
birch::type::Real birch::type::Cosh::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y) {
  #line 10 "src/expression/Cosh.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Cosh.birch", 10);
  #line 11 "src/expression/Cosh.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Cosh.birch"
  return -(d) * birch::sinh(y);
}

#line 18 "src/expression/Cosh.birch"
libbirch::Shared<birch::type::Cosh> birch::cosh(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 18 "src/expression/Cosh.birch"
  libbirch_function_("cosh", "src/expression/Cosh.birch", 18);
  #line 19 "src/expression/Cosh.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Cosh.birch"
  return birch::construct<libbirch::Shared<birch::type::Cosh>>(x);
}

#line 6 "src/expression/DelayExpression.birch"
birch::type::DelayExpression::DelayExpression() :
    #line 6 "src/expression/DelayExpression.birch"
    base_type_(),
    #line 13 "src/expression/DelayExpression.birch"
    generation(birch::type::Integer(0)),
    #line 18 "src/expression/DelayExpression.birch"
    pilotCount(birch::type::Integer(0)),
    #line 27 "src/expression/DelayExpression.birch"
    gradCount(birch::type::Integer(0)),
    #line 33 "src/expression/DelayExpression.birch"
    flagConstant(false),
    #line 39 "src/expression/DelayExpression.birch"
    flagPrior(false) {
  //
}

#line 44 "src/expression/DelayExpression.birch"
birch::type::Boolean birch::type::DelayExpression::isRandom() {
  #line 44 "src/expression/DelayExpression.birch"
  libbirch_function_("isRandom", "src/expression/DelayExpression.birch", 44);
  #line 45 "src/expression/DelayExpression.birch"
  libbirch_line_(45);
  #line 45 "src/expression/DelayExpression.birch"
  return false;
}

#line 51 "src/expression/DelayExpression.birch"
birch::type::Boolean birch::type::DelayExpression::isConstant() {
  #line 51 "src/expression/DelayExpression.birch"
  libbirch_function_("isConstant", "src/expression/DelayExpression.birch", 51);
  #line 52 "src/expression/DelayExpression.birch"
  libbirch_line_(52);
  #line 52 "src/expression/DelayExpression.birch"
  return this->flagConstant;
}

#line 58 "src/expression/DelayExpression.birch"
birch::type::Integer birch::type::DelayExpression::length() {
  #line 58 "src/expression/DelayExpression.birch"
  libbirch_function_("length", "src/expression/DelayExpression.birch", 58);
  #line 59 "src/expression/DelayExpression.birch"
  libbirch_line_(59);
  #line 59 "src/expression/DelayExpression.birch"
  return this->rows();
}

#line 84 "src/expression/DelayExpression.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::DelayExpression::prior() {
  #line 84 "src/expression/DelayExpression.birch"
  libbirch_function_("prior", "src/expression/DelayExpression.birch", 84);
  #line 85 "src/expression/DelayExpression.birch"
  libbirch_line_(85);
  #line 85 "src/expression/DelayExpression.birch"
  if (!(this->flagPrior)) {
    #line 86 "src/expression/DelayExpression.birch"
    libbirch_line_(86);
    #line 86 "src/expression/DelayExpression.birch"
    this->flagPrior = true;
    #line 87 "src/expression/DelayExpression.birch"
    libbirch_line_(87);
    #line 87 "src/expression/DelayExpression.birch"
    return this->doPrior();
  } else {
    #line 89 "src/expression/DelayExpression.birch"
    libbirch_line_(89);
    #line 89 "src/expression/DelayExpression.birch"
    return std::nullopt;
  }
}

#line 99 "src/expression/DelayExpression.birch"
birch::type::Integer birch::length(const libbirch::Shared<birch::type::DelayExpression>& x) {
  #line 99 "src/expression/DelayExpression.birch"
  libbirch_function_("length", "src/expression/DelayExpression.birch", 99);
  #line 100 "src/expression/DelayExpression.birch"
  libbirch_line_(100);
  #line 100 "src/expression/DelayExpression.birch"
  return x->length();
}

#line 106 "src/expression/DelayExpression.birch"
birch::type::Integer birch::rows(const libbirch::Shared<birch::type::DelayExpression>& x) {
  #line 106 "src/expression/DelayExpression.birch"
  libbirch_function_("rows", "src/expression/DelayExpression.birch", 106);
  #line 107 "src/expression/DelayExpression.birch"
  libbirch_line_(107);
  #line 107 "src/expression/DelayExpression.birch"
  return x->rows();
}

#line 113 "src/expression/DelayExpression.birch"
birch::type::Integer birch::columns(const libbirch::Shared<birch::type::DelayExpression>& x) {
  #line 113 "src/expression/DelayExpression.birch"
  libbirch_function_("columns", "src/expression/DelayExpression.birch", 113);
  #line 114 "src/expression/DelayExpression.birch"
  libbirch_line_(114);
  #line 114 "src/expression/DelayExpression.birch"
  return x->columns();
}

#line 4 "src/expression/Diagonal.birch"
birch::type::Diagonal::Diagonal(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const birch::type::Integer& z) :
    #line 4 "src/expression/Diagonal.birch"
    base_type_(y),
    #line 9 "src/expression/Diagonal.birch"
    z(std::move(z)) {
  this->libbirch::Any::acyclic_();
}

#line 11 "src/expression/Diagonal.birch"
birch::type::Integer birch::type::Diagonal::doRows() {
  #line 11 "src/expression/Diagonal.birch"
  libbirch_function_("doRows", "src/expression/Diagonal.birch", 11);
  #line 12 "src/expression/Diagonal.birch"
  libbirch_line_(12);
  #line 12 "src/expression/Diagonal.birch"
  return this->z;
}

#line 15 "src/expression/Diagonal.birch"
birch::type::Integer birch::type::Diagonal::doColumns() {
  #line 15 "src/expression/Diagonal.birch"
  libbirch_function_("doColumns", "src/expression/Diagonal.birch", 15);
  #line 16 "src/expression/Diagonal.birch"
  libbirch_line_(16);
  #line 16 "src/expression/Diagonal.birch"
  return this->z;
}

#line 19 "src/expression/Diagonal.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::Diagonal::doEvaluate(const birch::type::Real& y) {
  #line 19 "src/expression/Diagonal.birch"
  libbirch_function_("doEvaluate", "src/expression/Diagonal.birch", 19);
  #line 20 "src/expression/Diagonal.birch"
  libbirch_line_(20);
  #line 20 "src/expression/Diagonal.birch"
  return birch::diagonal(y, this->z);
}

#line 23 "src/expression/Diagonal.birch"
birch::type::Real birch::type::Diagonal::doEvaluateGrad(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const birch::type::Real& y) {
  #line 23 "src/expression/Diagonal.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Diagonal.birch", 23);
  #line 24 "src/expression/Diagonal.birch"
  libbirch_line_(24);
  #line 24 "src/expression/Diagonal.birch"
  return birch::trace(d);
}

#line 31 "src/expression/Diagonal.birch"
libbirch::Shared<birch::type::Diagonal> birch::diagonal(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const birch::type::Integer& z) {
  #line 31 "src/expression/Diagonal.birch"
  libbirch_function_("diagonal", "src/expression/Diagonal.birch", 31);
  #line 32 "src/expression/Diagonal.birch"
  libbirch_line_(32);
  #line 32 "src/expression/Diagonal.birch"
  return birch::construct<libbirch::Shared<birch::type::Diagonal>>(y, z);
}

#line 4 "src/expression/DiscreteAdd.birch"
birch::type::DiscreteAdd::DiscreteAdd(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& z) :
    #line 4 "src/expression/DiscreteAdd.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/DiscreteAdd.birch"
birch::type::Integer birch::type::DiscreteAdd::doEvaluate(const birch::type::Integer& y, const birch::type::Integer& z) {
  #line 7 "src/expression/DiscreteAdd.birch"
  libbirch_function_("doEvaluate", "src/expression/DiscreteAdd.birch", 7);
  #line 8 "src/expression/DiscreteAdd.birch"
  libbirch_line_(8);
  #line 8 "src/expression/DiscreteAdd.birch"
  return y + z;
}

#line 11 "src/expression/DiscreteAdd.birch"
birch::type::Real birch::type::DiscreteAdd::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Integer& x, const birch::type::Integer& y, const birch::type::Integer& z) {
  #line 11 "src/expression/DiscreteAdd.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/DiscreteAdd.birch", 11);
  #line 13 "src/expression/DiscreteAdd.birch"
  libbirch_line_(13);
  #line 13 "src/expression/DiscreteAdd.birch"
  return d;
}

#line 16 "src/expression/DiscreteAdd.birch"
birch::type::Real birch::type::DiscreteAdd::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Integer& x, const birch::type::Integer& y, const birch::type::Integer& z) {
  #line 16 "src/expression/DiscreteAdd.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/DiscreteAdd.birch", 16);
  #line 18 "src/expression/DiscreteAdd.birch"
  libbirch_line_(18);
  #line 18 "src/expression/DiscreteAdd.birch"
  return d;
}

#line 21 "src/expression/DiscreteAdd.birch"
std::optional<libbirch::Shared<birch::type::Discrete>> birch::type::DiscreteAdd::graftDiscrete() {
  #line 21 "src/expression/DiscreteAdd.birch"
  libbirch_function_("graftDiscrete", "src/expression/DiscreteAdd.birch", 21);
  #line 22 "src/expression/DiscreteAdd.birch"
  libbirch_line_(22);
  #line 22 "src/expression/DiscreteAdd.birch"
  std::optional<libbirch::Shared<birch::type::Discrete>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::Discrete>>>();
  #line 23 "src/expression/DiscreteAdd.birch"
  libbirch_line_(23);
  #line 23 "src/expression/DiscreteAdd.birch"
  if (!(this->hasValue())) {
    #line 24 "src/expression/DiscreteAdd.birch"
    libbirch_line_(24);
    #line 24 "src/expression/DiscreteAdd.birch"
    r = this->graftBoundedDiscrete();
    #line 25 "src/expression/DiscreteAdd.birch"
    libbirch_line_(25);
    #line 25 "src/expression/DiscreteAdd.birch"
    if (!(r.has_value())) {
      #line 26 "src/expression/DiscreteAdd.birch"
      libbirch_line_(26);
      #line 26 "src/expression/DiscreteAdd.birch"
      std::optional<libbirch::Shared<birch::type::Discrete>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::Discrete>>>();
      #line 27 "src/expression/DiscreteAdd.birch"
      libbirch_line_(27);
      #line 27 "src/expression/DiscreteAdd.birch"
      if ((x1 = this->y.value()->graftDiscrete()).has_value()) {
        #line 28 "src/expression/DiscreteAdd.birch"
        libbirch_line_(28);
        #line 28 "src/expression/DiscreteAdd.birch"
        r = birch::LinearDiscrete(birch::box(birch::type::Integer(1)), x1.value(), this->z.value());
      } else {
        #line 29 "src/expression/DiscreteAdd.birch"
        libbirch_line_(29);
        #line 29 "src/expression/DiscreteAdd.birch"
        if ((x1 = this->z.value()->graftDiscrete()).has_value()) {
          #line 30 "src/expression/DiscreteAdd.birch"
          libbirch_line_(30);
          #line 30 "src/expression/DiscreteAdd.birch"
          r = birch::LinearDiscrete(birch::box(birch::type::Integer(1)), x1.value(), this->y.value());
        }
      }
    }
  }
  #line 34 "src/expression/DiscreteAdd.birch"
  libbirch_line_(34);
  #line 34 "src/expression/DiscreteAdd.birch"
  return r;
}

#line 37 "src/expression/DiscreteAdd.birch"
std::optional<libbirch::Shared<birch::type::BoundedDiscrete>> birch::type::DiscreteAdd::graftBoundedDiscrete() {
  #line 37 "src/expression/DiscreteAdd.birch"
  libbirch_function_("graftBoundedDiscrete", "src/expression/DiscreteAdd.birch", 37);
  #line 38 "src/expression/DiscreteAdd.birch"
  libbirch_line_(38);
  #line 38 "src/expression/DiscreteAdd.birch"
  std::optional<libbirch::Shared<birch::type::BoundedDiscrete>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::BoundedDiscrete>>>();
  #line 39 "src/expression/DiscreteAdd.birch"
  libbirch_line_(39);
  #line 39 "src/expression/DiscreteAdd.birch"
  if (!(this->hasValue())) {
    #line 40 "src/expression/DiscreteAdd.birch"
    libbirch_line_(40);
    #line 40 "src/expression/DiscreteAdd.birch"
    auto x1 = this->y.value()->graftBoundedDiscrete();
    #line 41 "src/expression/DiscreteAdd.birch"
    libbirch_line_(41);
    #line 41 "src/expression/DiscreteAdd.birch"
    auto x2 = this->z.value()->graftBoundedDiscrete();
    #line 42 "src/expression/DiscreteAdd.birch"
    libbirch_line_(42);
    #line 42 "src/expression/DiscreteAdd.birch"
    if (x1.has_value() && x2.has_value()) {
      #line 43 "src/expression/DiscreteAdd.birch"
      libbirch_line_(43);
      #line 43 "src/expression/DiscreteAdd.birch"
      r = birch::AddBoundedDiscrete(x1.value(), x2.value());
    } else {
      #line 44 "src/expression/DiscreteAdd.birch"
      libbirch_line_(44);
      #line 44 "src/expression/DiscreteAdd.birch"
      if (x1.has_value()) {
        #line 45 "src/expression/DiscreteAdd.birch"
        libbirch_line_(45);
        #line 45 "src/expression/DiscreteAdd.birch"
        r = birch::LinearBoundedDiscrete(birch::box(birch::type::Integer(1)), x1.value(), this->z.value());
      } else {
        #line 46 "src/expression/DiscreteAdd.birch"
        libbirch_line_(46);
        #line 46 "src/expression/DiscreteAdd.birch"
        if (x2.has_value()) {
          #line 47 "src/expression/DiscreteAdd.birch"
          libbirch_line_(47);
          #line 47 "src/expression/DiscreteAdd.birch"
          r = birch::LinearBoundedDiscrete(birch::box(birch::type::Integer(1)), x2.value(), this->y.value());
        }
      }
    }
  }
  #line 50 "src/expression/DiscreteAdd.birch"
  libbirch_line_(50);
  #line 50 "src/expression/DiscreteAdd.birch"
  return r;
}

#line 57 "src/expression/DiscreteAdd.birch"
libbirch::Shared<birch::type::DiscreteAdd> birch::operator+(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& z) {
  #line 57 "src/expression/DiscreteAdd.birch"
  libbirch_function_("+", "src/expression/DiscreteAdd.birch", 57);
  #line 58 "src/expression/DiscreteAdd.birch"
  libbirch_line_(58);
  #line 58 "src/expression/DiscreteAdd.birch"
  return birch::construct<libbirch::Shared<birch::type::DiscreteAdd>>(y, z);
}

#line 64 "src/expression/DiscreteAdd.birch"
libbirch::Shared<birch::type::DiscreteAdd> birch::operator+(const birch::type::Integer& y, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& z) {
  #line 64 "src/expression/DiscreteAdd.birch"
  libbirch_function_("+", "src/expression/DiscreteAdd.birch", 64);
  #line 65 "src/expression/DiscreteAdd.birch"
  libbirch_line_(65);
  #line 65 "src/expression/DiscreteAdd.birch"
  return birch::box(y) + z;
}

#line 71 "src/expression/DiscreteAdd.birch"
libbirch::Shared<birch::type::DiscreteAdd> birch::operator+(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& y, const birch::type::Integer& z) {
  #line 71 "src/expression/DiscreteAdd.birch"
  libbirch_function_("+", "src/expression/DiscreteAdd.birch", 71);
  #line 72 "src/expression/DiscreteAdd.birch"
  libbirch_line_(72);
  #line 72 "src/expression/DiscreteAdd.birch"
  return y + birch::box(z);
}

#line 18 "src/expression/DiscreteCast.birch"
libbirch::Shared<birch::type::DiscreteCast<birch::type::Real, birch::type::Integer>> birch::Integer(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) {
  #line 18 "src/expression/DiscreteCast.birch"
  libbirch_function_("Integer", "src/expression/DiscreteCast.birch", 18);
  #line 19 "src/expression/DiscreteCast.birch"
  libbirch_line_(19);
  #line 19 "src/expression/DiscreteCast.birch"
  return birch::construct<libbirch::Shared<birch::type::DiscreteCast<birch::type::Real, birch::type::Integer>>>(y);
}

#line 25 "src/expression/DiscreteCast.birch"
libbirch::Shared<birch::type::Expression<birch::type::Integer>> birch::Integer(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& y) {
  #line 25 "src/expression/DiscreteCast.birch"
  libbirch_function_("Integer", "src/expression/DiscreteCast.birch", 25);
  #line 26 "src/expression/DiscreteCast.birch"
  libbirch_line_(26);
  #line 26 "src/expression/DiscreteCast.birch"
  return y;
}

#line 32 "src/expression/DiscreteCast.birch"
libbirch::Shared<birch::type::DiscreteCast<birch::type::Boolean, birch::type::Integer>> birch::Integer(const libbirch::Shared<birch::type::Expression<birch::type::Boolean>>& y) {
  #line 32 "src/expression/DiscreteCast.birch"
  libbirch_function_("Integer", "src/expression/DiscreteCast.birch", 32);
  #line 33 "src/expression/DiscreteCast.birch"
  libbirch_line_(33);
  #line 33 "src/expression/DiscreteCast.birch"
  return birch::construct<libbirch::Shared<birch::type::DiscreteCast<birch::type::Boolean, birch::type::Integer>>>(y);
}

#line 39 "src/expression/DiscreteCast.birch"
libbirch::Shared<birch::type::DiscreteCast<birch::type::Real, birch::type::Boolean>> birch::Boolean(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) {
  #line 39 "src/expression/DiscreteCast.birch"
  libbirch_function_("Boolean", "src/expression/DiscreteCast.birch", 39);
  #line 40 "src/expression/DiscreteCast.birch"
  libbirch_line_(40);
  #line 40 "src/expression/DiscreteCast.birch"
  return birch::construct<libbirch::Shared<birch::type::DiscreteCast<birch::type::Real, birch::type::Boolean>>>(y);
}

#line 46 "src/expression/DiscreteCast.birch"
libbirch::Shared<birch::type::DiscreteCast<birch::type::Integer, birch::type::Boolean>> birch::Boolean(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& y) {
  #line 46 "src/expression/DiscreteCast.birch"
  libbirch_function_("Boolean", "src/expression/DiscreteCast.birch", 46);
  #line 47 "src/expression/DiscreteCast.birch"
  libbirch_line_(47);
  #line 47 "src/expression/DiscreteCast.birch"
  return birch::construct<libbirch::Shared<birch::type::DiscreteCast<birch::type::Integer, birch::type::Boolean>>>(y);
}

#line 53 "src/expression/DiscreteCast.birch"
libbirch::Shared<birch::type::Expression<birch::type::Boolean>> birch::Boolean(const libbirch::Shared<birch::type::Expression<birch::type::Boolean>>& y) {
  #line 53 "src/expression/DiscreteCast.birch"
  libbirch_function_("Boolean", "src/expression/DiscreteCast.birch", 53);
  #line 54 "src/expression/DiscreteCast.birch"
  libbirch_line_(54);
  #line 54 "src/expression/DiscreteCast.birch"
  return y;
}

#line 4 "src/expression/DiscreteMultiply.birch"
birch::type::DiscreteMultiply::DiscreteMultiply(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& z) :
    #line 4 "src/expression/DiscreteMultiply.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/DiscreteMultiply.birch"
birch::type::Integer birch::type::DiscreteMultiply::doEvaluate(const birch::type::Integer& y, const birch::type::Integer& z) {
  #line 7 "src/expression/DiscreteMultiply.birch"
  libbirch_function_("doEvaluate", "src/expression/DiscreteMultiply.birch", 7);
  #line 8 "src/expression/DiscreteMultiply.birch"
  libbirch_line_(8);
  #line 8 "src/expression/DiscreteMultiply.birch"
  return y * z;
}

#line 11 "src/expression/DiscreteMultiply.birch"
birch::type::Real birch::type::DiscreteMultiply::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Integer& x, const birch::type::Integer& y, const birch::type::Integer& z) {
  #line 11 "src/expression/DiscreteMultiply.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/DiscreteMultiply.birch", 11);
  #line 13 "src/expression/DiscreteMultiply.birch"
  libbirch_line_(13);
  #line 13 "src/expression/DiscreteMultiply.birch"
  return d * z;
}

#line 16 "src/expression/DiscreteMultiply.birch"
birch::type::Real birch::type::DiscreteMultiply::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Integer& x, const birch::type::Integer& y, const birch::type::Integer& z) {
  #line 16 "src/expression/DiscreteMultiply.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/DiscreteMultiply.birch", 16);
  #line 18 "src/expression/DiscreteMultiply.birch"
  libbirch_line_(18);
  #line 18 "src/expression/DiscreteMultiply.birch"
  return d * y;
}

#line 21 "src/expression/DiscreteMultiply.birch"
std::optional<libbirch::Shared<birch::type::Discrete>> birch::type::DiscreteMultiply::graftDiscrete() {
  #line 21 "src/expression/DiscreteMultiply.birch"
  libbirch_function_("graftDiscrete", "src/expression/DiscreteMultiply.birch", 21);
  #line 22 "src/expression/DiscreteMultiply.birch"
  libbirch_line_(22);
  #line 22 "src/expression/DiscreteMultiply.birch"
  std::optional<libbirch::Shared<birch::type::Discrete>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::Discrete>>>();
  #line 23 "src/expression/DiscreteMultiply.birch"
  libbirch_line_(23);
  #line 23 "src/expression/DiscreteMultiply.birch"
  if (!(this->hasValue())) {
    #line 24 "src/expression/DiscreteMultiply.birch"
    libbirch_line_(24);
    #line 24 "src/expression/DiscreteMultiply.birch"
    r = this->graftBoundedDiscrete();
    #line 25 "src/expression/DiscreteMultiply.birch"
    libbirch_line_(25);
    #line 25 "src/expression/DiscreteMultiply.birch"
    if (!(r.has_value())) {
      #line 26 "src/expression/DiscreteMultiply.birch"
      libbirch_line_(26);
      #line 26 "src/expression/DiscreteMultiply.birch"
      std::optional<libbirch::Shared<birch::type::Discrete>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::Discrete>>>();
      #line 27 "src/expression/DiscreteMultiply.birch"
      libbirch_line_(27);
      #line 27 "src/expression/DiscreteMultiply.birch"
      if ((x1 = this->y.value()->graftDiscrete()).has_value()) {
        #line 28 "src/expression/DiscreteMultiply.birch"
        libbirch_line_(28);
        #line 28 "src/expression/DiscreteMultiply.birch"
        r = birch::LinearDiscrete(this->z.value(), x1.value(), birch::box(birch::type::Integer(0)));
      } else {
        #line 29 "src/expression/DiscreteMultiply.birch"
        libbirch_line_(29);
        #line 29 "src/expression/DiscreteMultiply.birch"
        if ((x1 = this->z.value()->graftDiscrete()).has_value()) {
          #line 30 "src/expression/DiscreteMultiply.birch"
          libbirch_line_(30);
          #line 30 "src/expression/DiscreteMultiply.birch"
          r = birch::LinearDiscrete(this->y.value(), x1.value(), birch::box(birch::type::Integer(0)));
        }
      }
    }
  }
  #line 34 "src/expression/DiscreteMultiply.birch"
  libbirch_line_(34);
  #line 34 "src/expression/DiscreteMultiply.birch"
  return r;
}

#line 37 "src/expression/DiscreteMultiply.birch"
std::optional<libbirch::Shared<birch::type::BoundedDiscrete>> birch::type::DiscreteMultiply::graftBoundedDiscrete() {
  #line 37 "src/expression/DiscreteMultiply.birch"
  libbirch_function_("graftBoundedDiscrete", "src/expression/DiscreteMultiply.birch", 37);
  #line 38 "src/expression/DiscreteMultiply.birch"
  libbirch_line_(38);
  #line 38 "src/expression/DiscreteMultiply.birch"
  std::optional<libbirch::Shared<birch::type::BoundedDiscrete>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::BoundedDiscrete>>>();
  #line 39 "src/expression/DiscreteMultiply.birch"
  libbirch_line_(39);
  #line 39 "src/expression/DiscreteMultiply.birch"
  if (!(this->hasValue())) {
    #line 40 "src/expression/DiscreteMultiply.birch"
    libbirch_line_(40);
    #line 40 "src/expression/DiscreteMultiply.birch"
    auto x1 = this->y.value()->graftBoundedDiscrete();
    #line 41 "src/expression/DiscreteMultiply.birch"
    libbirch_line_(41);
    #line 41 "src/expression/DiscreteMultiply.birch"
    auto x2 = this->z.value()->graftBoundedDiscrete();
    #line 42 "src/expression/DiscreteMultiply.birch"
    libbirch_line_(42);
    #line 42 "src/expression/DiscreteMultiply.birch"
    if (x1.has_value()) {
      #line 43 "src/expression/DiscreteMultiply.birch"
      libbirch_line_(43);
      #line 43 "src/expression/DiscreteMultiply.birch"
      r = birch::LinearBoundedDiscrete(this->z.value(), x1.value(), birch::box(birch::type::Integer(0)));
    } else {
      #line 44 "src/expression/DiscreteMultiply.birch"
      libbirch_line_(44);
      #line 44 "src/expression/DiscreteMultiply.birch"
      if (x2.has_value()) {
        #line 45 "src/expression/DiscreteMultiply.birch"
        libbirch_line_(45);
        #line 45 "src/expression/DiscreteMultiply.birch"
        r = birch::LinearBoundedDiscrete(this->y.value(), x2.value(), birch::box(birch::type::Integer(0)));
      }
    }
  }
  #line 48 "src/expression/DiscreteMultiply.birch"
  libbirch_line_(48);
  #line 48 "src/expression/DiscreteMultiply.birch"
  return r;
}

#line 55 "src/expression/DiscreteMultiply.birch"
libbirch::Shared<birch::type::DiscreteMultiply> birch::operator*(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& z) {
  #line 55 "src/expression/DiscreteMultiply.birch"
  libbirch_function_("*", "src/expression/DiscreteMultiply.birch", 55);
  #line 56 "src/expression/DiscreteMultiply.birch"
  libbirch_line_(56);
  #line 56 "src/expression/DiscreteMultiply.birch"
  return birch::construct<libbirch::Shared<birch::type::DiscreteMultiply>>(y, z);
}

#line 62 "src/expression/DiscreteMultiply.birch"
libbirch::Shared<birch::type::DiscreteMultiply> birch::operator*(const birch::type::Integer& y, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& z) {
  #line 62 "src/expression/DiscreteMultiply.birch"
  libbirch_function_("*", "src/expression/DiscreteMultiply.birch", 62);
  #line 63 "src/expression/DiscreteMultiply.birch"
  libbirch_line_(63);
  #line 63 "src/expression/DiscreteMultiply.birch"
  return birch::box(y) * z;
}

#line 69 "src/expression/DiscreteMultiply.birch"
libbirch::Shared<birch::type::DiscreteMultiply> birch::operator*(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& y, const birch::type::Integer& z) {
  #line 69 "src/expression/DiscreteMultiply.birch"
  libbirch_function_("*", "src/expression/DiscreteMultiply.birch", 69);
  #line 70 "src/expression/DiscreteMultiply.birch"
  libbirch_line_(70);
  #line 70 "src/expression/DiscreteMultiply.birch"
  return y * birch::box(z);
}

#line 4 "src/expression/DiscreteNegate.birch"
birch::type::DiscreteNegate::DiscreteNegate(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& y) :
    #line 4 "src/expression/DiscreteNegate.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 6 "src/expression/DiscreteNegate.birch"
birch::type::Integer birch::type::DiscreteNegate::doEvaluate(const birch::type::Integer& y) {
  #line 6 "src/expression/DiscreteNegate.birch"
  libbirch_function_("doEvaluate", "src/expression/DiscreteNegate.birch", 6);
  #line 7 "src/expression/DiscreteNegate.birch"
  libbirch_line_(7);
  #line 7 "src/expression/DiscreteNegate.birch"
  return -(y);
}

#line 10 "src/expression/DiscreteNegate.birch"
birch::type::Real birch::type::DiscreteNegate::doEvaluateGrad(const birch::type::Real& d, const birch::type::Integer& x, const birch::type::Integer& y) {
  #line 10 "src/expression/DiscreteNegate.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/DiscreteNegate.birch", 10);
  #line 11 "src/expression/DiscreteNegate.birch"
  libbirch_line_(11);
  #line 11 "src/expression/DiscreteNegate.birch"
  return -(d);
}

#line 14 "src/expression/DiscreteNegate.birch"
std::optional<libbirch::Shared<birch::type::Discrete>> birch::type::DiscreteNegate::graftDiscrete() {
  #line 14 "src/expression/DiscreteNegate.birch"
  libbirch_function_("graftDiscrete", "src/expression/DiscreteNegate.birch", 14);
  #line 15 "src/expression/DiscreteNegate.birch"
  libbirch_line_(15);
  #line 15 "src/expression/DiscreteNegate.birch"
  std::optional<libbirch::Shared<birch::type::Discrete>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::Discrete>>>();
  #line 16 "src/expression/DiscreteNegate.birch"
  libbirch_line_(16);
  #line 16 "src/expression/DiscreteNegate.birch"
  if (!(this->hasValue())) {
    #line 17 "src/expression/DiscreteNegate.birch"
    libbirch_line_(17);
    #line 17 "src/expression/DiscreteNegate.birch"
    r = this->graftBoundedDiscrete();
    #line 18 "src/expression/DiscreteNegate.birch"
    libbirch_line_(18);
    #line 18 "src/expression/DiscreteNegate.birch"
    if (!(r.has_value())) {
      #line 19 "src/expression/DiscreteNegate.birch"
      libbirch_line_(19);
      #line 19 "src/expression/DiscreteNegate.birch"
      std::optional<libbirch::Shared<birch::type::Discrete>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::Discrete>>>();
      #line 20 "src/expression/DiscreteNegate.birch"
      libbirch_line_(20);
      #line 20 "src/expression/DiscreteNegate.birch"
      if ((x1 = this->y.value()->graftDiscrete()).has_value()) {
        #line 21 "src/expression/DiscreteNegate.birch"
        libbirch_line_(21);
        #line 21 "src/expression/DiscreteNegate.birch"
        r = birch::LinearDiscrete(birch::box(-(birch::type::Integer(1))), x1.value(), birch::box(birch::type::Integer(0)));
      }
    }
  }
  #line 25 "src/expression/DiscreteNegate.birch"
  libbirch_line_(25);
  #line 25 "src/expression/DiscreteNegate.birch"
  return r;
}

#line 28 "src/expression/DiscreteNegate.birch"
std::optional<libbirch::Shared<birch::type::BoundedDiscrete>> birch::type::DiscreteNegate::graftBoundedDiscrete() {
  #line 28 "src/expression/DiscreteNegate.birch"
  libbirch_function_("graftBoundedDiscrete", "src/expression/DiscreteNegate.birch", 28);
  #line 29 "src/expression/DiscreteNegate.birch"
  libbirch_line_(29);
  #line 29 "src/expression/DiscreteNegate.birch"
  std::optional<libbirch::Shared<birch::type::BoundedDiscrete>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::BoundedDiscrete>>>();
  #line 30 "src/expression/DiscreteNegate.birch"
  libbirch_line_(30);
  #line 30 "src/expression/DiscreteNegate.birch"
  if (!(this->hasValue())) {
    #line 31 "src/expression/DiscreteNegate.birch"
    libbirch_line_(31);
    #line 31 "src/expression/DiscreteNegate.birch"
    std::optional<libbirch::Shared<birch::type::BoundedDiscrete>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::BoundedDiscrete>>>();
    #line 32 "src/expression/DiscreteNegate.birch"
    libbirch_line_(32);
    #line 32 "src/expression/DiscreteNegate.birch"
    if ((x1 = this->y.value()->graftBoundedDiscrete()).has_value()) {
      #line 33 "src/expression/DiscreteNegate.birch"
      libbirch_line_(33);
      #line 33 "src/expression/DiscreteNegate.birch"
      r = birch::LinearBoundedDiscrete(birch::box(-(birch::type::Integer(1))), x1.value(), birch::box(birch::type::Integer(0)));
    }
  }
  #line 36 "src/expression/DiscreteNegate.birch"
  libbirch_line_(36);
  #line 36 "src/expression/DiscreteNegate.birch"
  return r;
}

#line 43 "src/expression/DiscreteNegate.birch"
libbirch::Shared<birch::type::DiscreteNegate> birch::operator-(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& x) {
  #line 43 "src/expression/DiscreteNegate.birch"
  libbirch_function_("-", "src/expression/DiscreteNegate.birch", 43);
  #line 44 "src/expression/DiscreteNegate.birch"
  libbirch_line_(44);
  #line 44 "src/expression/DiscreteNegate.birch"
  return birch::construct<libbirch::Shared<birch::type::DiscreteNegate>>(x);
}

#line 4 "src/expression/DiscreteSubtract.birch"
birch::type::DiscreteSubtract::DiscreteSubtract(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& z) :
    #line 4 "src/expression/DiscreteSubtract.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/DiscreteSubtract.birch"
birch::type::Integer birch::type::DiscreteSubtract::doEvaluate(const birch::type::Integer& y, const birch::type::Integer& z) {
  #line 7 "src/expression/DiscreteSubtract.birch"
  libbirch_function_("doEvaluate", "src/expression/DiscreteSubtract.birch", 7);
  #line 8 "src/expression/DiscreteSubtract.birch"
  libbirch_line_(8);
  #line 8 "src/expression/DiscreteSubtract.birch"
  return y - z;
}

#line 11 "src/expression/DiscreteSubtract.birch"
birch::type::Real birch::type::DiscreteSubtract::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Integer& x, const birch::type::Integer& y, const birch::type::Integer& z) {
  #line 11 "src/expression/DiscreteSubtract.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/DiscreteSubtract.birch", 11);
  #line 13 "src/expression/DiscreteSubtract.birch"
  libbirch_line_(13);
  #line 13 "src/expression/DiscreteSubtract.birch"
  return d;
}

#line 16 "src/expression/DiscreteSubtract.birch"
birch::type::Real birch::type::DiscreteSubtract::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Integer& x, const birch::type::Integer& y, const birch::type::Integer& z) {
  #line 16 "src/expression/DiscreteSubtract.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/DiscreteSubtract.birch", 16);
  #line 18 "src/expression/DiscreteSubtract.birch"
  libbirch_line_(18);
  #line 18 "src/expression/DiscreteSubtract.birch"
  return -(d);
}

#line 21 "src/expression/DiscreteSubtract.birch"
std::optional<libbirch::Shared<birch::type::Discrete>> birch::type::DiscreteSubtract::graftDiscrete() {
  #line 21 "src/expression/DiscreteSubtract.birch"
  libbirch_function_("graftDiscrete", "src/expression/DiscreteSubtract.birch", 21);
  #line 22 "src/expression/DiscreteSubtract.birch"
  libbirch_line_(22);
  #line 22 "src/expression/DiscreteSubtract.birch"
  std::optional<libbirch::Shared<birch::type::Discrete>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::Discrete>>>();
  #line 23 "src/expression/DiscreteSubtract.birch"
  libbirch_line_(23);
  #line 23 "src/expression/DiscreteSubtract.birch"
  if (!(this->hasValue())) {
    #line 24 "src/expression/DiscreteSubtract.birch"
    libbirch_line_(24);
    #line 24 "src/expression/DiscreteSubtract.birch"
    r = this->graftBoundedDiscrete();
    #line 25 "src/expression/DiscreteSubtract.birch"
    libbirch_line_(25);
    #line 25 "src/expression/DiscreteSubtract.birch"
    if (!(r.has_value())) {
      #line 26 "src/expression/DiscreteSubtract.birch"
      libbirch_line_(26);
      #line 26 "src/expression/DiscreteSubtract.birch"
      std::optional<libbirch::Shared<birch::type::Discrete>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::Discrete>>>();
      #line 27 "src/expression/DiscreteSubtract.birch"
      libbirch_line_(27);
      #line 27 "src/expression/DiscreteSubtract.birch"
      if ((x1 = this->y.value()->graftDiscrete()).has_value()) {
        #line 28 "src/expression/DiscreteSubtract.birch"
        libbirch_line_(28);
        #line 28 "src/expression/DiscreteSubtract.birch"
        r = birch::LinearDiscrete(birch::box(birch::type::Integer(1)), x1.value(), -(this->z.value()));
      } else {
        #line 29 "src/expression/DiscreteSubtract.birch"
        libbirch_line_(29);
        #line 29 "src/expression/DiscreteSubtract.birch"
        if ((x1 = this->z.value()->graftDiscrete()).has_value()) {
          #line 30 "src/expression/DiscreteSubtract.birch"
          libbirch_line_(30);
          #line 30 "src/expression/DiscreteSubtract.birch"
          r = birch::LinearDiscrete(birch::box(-(birch::type::Integer(1))), x1.value(), this->y.value());
        }
      }
    }
  }
  #line 34 "src/expression/DiscreteSubtract.birch"
  libbirch_line_(34);
  #line 34 "src/expression/DiscreteSubtract.birch"
  return r;
}

#line 37 "src/expression/DiscreteSubtract.birch"
std::optional<libbirch::Shared<birch::type::BoundedDiscrete>> birch::type::DiscreteSubtract::graftBoundedDiscrete() {
  #line 37 "src/expression/DiscreteSubtract.birch"
  libbirch_function_("graftBoundedDiscrete", "src/expression/DiscreteSubtract.birch", 37);
  #line 38 "src/expression/DiscreteSubtract.birch"
  libbirch_line_(38);
  #line 38 "src/expression/DiscreteSubtract.birch"
  std::optional<libbirch::Shared<birch::type::BoundedDiscrete>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::BoundedDiscrete>>>();
  #line 39 "src/expression/DiscreteSubtract.birch"
  libbirch_line_(39);
  #line 39 "src/expression/DiscreteSubtract.birch"
  if (!(this->hasValue())) {
    #line 40 "src/expression/DiscreteSubtract.birch"
    libbirch_line_(40);
    #line 40 "src/expression/DiscreteSubtract.birch"
    auto x1 = this->y.value()->graftBoundedDiscrete();
    #line 41 "src/expression/DiscreteSubtract.birch"
    libbirch_line_(41);
    #line 41 "src/expression/DiscreteSubtract.birch"
    auto x2 = this->z.value()->graftBoundedDiscrete();
    #line 42 "src/expression/DiscreteSubtract.birch"
    libbirch_line_(42);
    #line 42 "src/expression/DiscreteSubtract.birch"
    if (x1.has_value() && x2.has_value()) {
      #line 43 "src/expression/DiscreteSubtract.birch"
      libbirch_line_(43);
      #line 43 "src/expression/DiscreteSubtract.birch"
      r = birch::SubtractBoundedDiscrete(x1.value(), x2.value());
    } else {
      #line 44 "src/expression/DiscreteSubtract.birch"
      libbirch_line_(44);
      #line 44 "src/expression/DiscreteSubtract.birch"
      if (x1.has_value()) {
        #line 45 "src/expression/DiscreteSubtract.birch"
        libbirch_line_(45);
        #line 45 "src/expression/DiscreteSubtract.birch"
        r = birch::LinearBoundedDiscrete(birch::box(birch::type::Integer(1)), x1.value(), -(this->z.value()));
      } else {
        #line 46 "src/expression/DiscreteSubtract.birch"
        libbirch_line_(46);
        #line 46 "src/expression/DiscreteSubtract.birch"
        if (x2.has_value()) {
          #line 47 "src/expression/DiscreteSubtract.birch"
          libbirch_line_(47);
          #line 47 "src/expression/DiscreteSubtract.birch"
          r = birch::LinearBoundedDiscrete(birch::box(-(birch::type::Integer(1))), x2.value(), this->y.value());
        }
      }
    }
  }
  #line 50 "src/expression/DiscreteSubtract.birch"
  libbirch_line_(50);
  #line 50 "src/expression/DiscreteSubtract.birch"
  return r;
}

#line 57 "src/expression/DiscreteSubtract.birch"
libbirch::Shared<birch::type::DiscreteSubtract> birch::operator-(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& z) {
  #line 57 "src/expression/DiscreteSubtract.birch"
  libbirch_function_("-", "src/expression/DiscreteSubtract.birch", 57);
  #line 59 "src/expression/DiscreteSubtract.birch"
  libbirch_line_(59);
  #line 59 "src/expression/DiscreteSubtract.birch"
  return birch::construct<libbirch::Shared<birch::type::DiscreteSubtract>>(y, z);
}

#line 65 "src/expression/DiscreteSubtract.birch"
libbirch::Shared<birch::type::DiscreteSubtract> birch::operator-(const birch::type::Integer& y, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& z) {
  #line 65 "src/expression/DiscreteSubtract.birch"
  libbirch_function_("-", "src/expression/DiscreteSubtract.birch", 65);
  #line 66 "src/expression/DiscreteSubtract.birch"
  libbirch_line_(66);
  #line 66 "src/expression/DiscreteSubtract.birch"
  return birch::box(y) - z;
}

#line 72 "src/expression/DiscreteSubtract.birch"
libbirch::Shared<birch::type::DiscreteSubtract> birch::operator-(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& y, const birch::type::Integer& z) {
  #line 72 "src/expression/DiscreteSubtract.birch"
  libbirch_function_("-", "src/expression/DiscreteSubtract.birch", 72);
  #line 73 "src/expression/DiscreteSubtract.birch"
  libbirch_line_(73);
  #line 73 "src/expression/DiscreteSubtract.birch"
  return y - birch::box(z);
}

#line 4 "src/expression/Divide.birch"
birch::type::Divide::Divide(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) :
    #line 4 "src/expression/Divide.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/Divide.birch"
birch::type::Real birch::type::Divide::doEvaluate(const birch::type::Real& y, const birch::type::Real& z) {
  #line 7 "src/expression/Divide.birch"
  libbirch_function_("doEvaluate", "src/expression/Divide.birch", 7);
  #line 8 "src/expression/Divide.birch"
  libbirch_line_(8);
  #line 8 "src/expression/Divide.birch"
  return y / z;
}

#line 11 "src/expression/Divide.birch"
birch::type::Real birch::type::Divide::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z) {
  #line 11 "src/expression/Divide.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/Divide.birch", 11);
  #line 12 "src/expression/Divide.birch"
  libbirch_line_(12);
  #line 12 "src/expression/Divide.birch"
  return d / z;
}

#line 15 "src/expression/Divide.birch"
birch::type::Real birch::type::Divide::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z) {
  #line 15 "src/expression/Divide.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/Divide.birch", 15);
  #line 16 "src/expression/Divide.birch"
  libbirch_line_(16);
  #line 16 "src/expression/Divide.birch"
  return -(d) * y / (z * z);
}

#line 19 "src/expression/Divide.birch"
std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gaussian>>>> birch::type::Divide::graftLinearGaussian() {
  #line 19 "src/expression/Divide.birch"
  libbirch_function_("graftLinearGaussian", "src/expression/Divide.birch", 19);
  #line 20 "src/expression/Divide.birch"
  libbirch_line_(20);
  #line 20 "src/expression/Divide.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gaussian>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gaussian>>>>>();
  #line 21 "src/expression/Divide.birch"
  libbirch_line_(21);
  #line 21 "src/expression/Divide.birch"
  if (!(this->hasValue())) {
    #line 22 "src/expression/Divide.birch"
    libbirch_line_(22);
    #line 22 "src/expression/Divide.birch"
    std::optional<libbirch::Shared<birch::type::Gaussian>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::Gaussian>>>();
    #line 23 "src/expression/Divide.birch"
    libbirch_line_(23);
    #line 23 "src/expression/Divide.birch"
    if ((r = this->y.value()->graftLinearGaussian()).has_value()) {
      #line 24 "src/expression/Divide.birch"
      libbirch_line_(24);
      #line 24 "src/expression/Divide.birch"
      r.value()->divide(this->z.value());
    } else {
      #line 25 "src/expression/Divide.birch"
      libbirch_line_(25);
      #line 25 "src/expression/Divide.birch"
      if ((x1 = this->y.value()->graftGaussian()).has_value()) {
        #line 26 "src/expression/Divide.birch"
        libbirch_line_(26);
        #line 26 "src/expression/Divide.birch"
        r = birch::TransformLinear<libbirch::Shared<birch::type::Gaussian>>(1.0 / this->z.value(), x1.value());
      }
    }
  }
  #line 29 "src/expression/Divide.birch"
  libbirch_line_(29);
  #line 29 "src/expression/Divide.birch"
  return r;
}

#line 32 "src/expression/Divide.birch"
std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateGaussian>>>> birch::type::Divide::graftDotMultivariateGaussian() {
  #line 32 "src/expression/Divide.birch"
  libbirch_function_("graftDotMultivariateGaussian", "src/expression/Divide.birch", 32);
  #line 34 "src/expression/Divide.birch"
  libbirch_line_(34);
  #line 34 "src/expression/Divide.birch"
  std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateGaussian>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateGaussian>>>>>();
  #line 35 "src/expression/Divide.birch"
  libbirch_line_(35);
  #line 35 "src/expression/Divide.birch"
  if (!(this->hasValue())) {
    #line 36 "src/expression/Divide.birch"
    libbirch_line_(36);
    #line 36 "src/expression/Divide.birch"
    if ((r = this->y.value()->graftDotMultivariateGaussian()).has_value()) {
      #line 37 "src/expression/Divide.birch"
      libbirch_line_(37);
      #line 37 "src/expression/Divide.birch"
      r.value()->divide(this->z.value());
    }
  }
  #line 40 "src/expression/Divide.birch"
  libbirch_line_(40);
  #line 40 "src/expression/Divide.birch"
  return r;
}

#line 43 "src/expression/Divide.birch"
std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>>> birch::type::Divide::graftLinearNormalInverseGamma(const libbirch::Shared<birch::type::Distribution<birch::type::Real>>& compare) {
  #line 43 "src/expression/Divide.birch"
  libbirch_function_("graftLinearNormalInverseGamma", "src/expression/Divide.birch", 43);
  #line 45 "src/expression/Divide.birch"
  libbirch_line_(45);
  #line 45 "src/expression/Divide.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>>>>();
  #line 46 "src/expression/Divide.birch"
  libbirch_line_(46);
  #line 46 "src/expression/Divide.birch"
  if (!(this->hasValue())) {
    #line 47 "src/expression/Divide.birch"
    libbirch_line_(47);
    #line 47 "src/expression/Divide.birch"
    std::optional<libbirch::Shared<birch::type::NormalInverseGamma>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::NormalInverseGamma>>>();
    #line 48 "src/expression/Divide.birch"
    libbirch_line_(48);
    #line 48 "src/expression/Divide.birch"
    if ((r = this->y.value()->graftLinearNormalInverseGamma(compare)).has_value()) {
      #line 49 "src/expression/Divide.birch"
      libbirch_line_(49);
      #line 49 "src/expression/Divide.birch"
      r.value()->divide(this->z.value());
    } else {
      #line 50 "src/expression/Divide.birch"
      libbirch_line_(50);
      #line 50 "src/expression/Divide.birch"
      if ((x1 = this->y.value()->graftNormalInverseGamma(compare)).has_value()) {
        #line 51 "src/expression/Divide.birch"
        libbirch_line_(51);
        #line 51 "src/expression/Divide.birch"
        r = birch::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>(1.0 / this->z.value(), x1.value());
      }
    }
  }
  #line 54 "src/expression/Divide.birch"
  libbirch_line_(54);
  #line 54 "src/expression/Divide.birch"
  return r;
}

#line 57 "src/expression/Divide.birch"
std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>> birch::type::Divide::graftDotMultivariateNormalInverseGamma(const libbirch::Shared<birch::type::Distribution<birch::type::Real>>& compare) {
  #line 57 "src/expression/Divide.birch"
  libbirch_function_("graftDotMultivariateNormalInverseGamma", "src/expression/Divide.birch", 57);
  #line 59 "src/expression/Divide.birch"
  libbirch_line_(59);
  #line 59 "src/expression/Divide.birch"
  std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>();
  #line 60 "src/expression/Divide.birch"
  libbirch_line_(60);
  #line 60 "src/expression/Divide.birch"
  if (!(this->hasValue())) {
    #line 61 "src/expression/Divide.birch"
    libbirch_line_(61);
    #line 61 "src/expression/Divide.birch"
    if ((r = this->y.value()->graftDotMultivariateNormalInverseGamma(compare)).has_value()) {
      #line 62 "src/expression/Divide.birch"
      libbirch_line_(62);
      #line 62 "src/expression/Divide.birch"
      r.value()->divide(this->z.value());
    }
  }
  #line 65 "src/expression/Divide.birch"
  libbirch_line_(65);
  #line 65 "src/expression/Divide.birch"
  return r;
}

#line 68 "src/expression/Divide.birch"
std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gamma>>>> birch::type::Divide::graftScaledGamma() {
  #line 68 "src/expression/Divide.birch"
  libbirch_function_("graftScaledGamma", "src/expression/Divide.birch", 68);
  #line 69 "src/expression/Divide.birch"
  libbirch_line_(69);
  #line 69 "src/expression/Divide.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gamma>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gamma>>>>>();
  #line 70 "src/expression/Divide.birch"
  libbirch_line_(70);
  #line 70 "src/expression/Divide.birch"
  if (!(this->hasValue())) {
    #line 71 "src/expression/Divide.birch"
    libbirch_line_(71);
    #line 71 "src/expression/Divide.birch"
    std::optional<libbirch::Shared<birch::type::Gamma>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::Gamma>>>();
    #line 72 "src/expression/Divide.birch"
    libbirch_line_(72);
    #line 72 "src/expression/Divide.birch"
    if ((r = this->y.value()->graftScaledGamma()).has_value()) {
      #line 73 "src/expression/Divide.birch"
      libbirch_line_(73);
      #line 73 "src/expression/Divide.birch"
      r.value()->divide(this->z.value());
    } else {
      #line 74 "src/expression/Divide.birch"
      libbirch_line_(74);
      #line 74 "src/expression/Divide.birch"
      if ((x1 = this->y.value()->graftGamma()).has_value()) {
        #line 75 "src/expression/Divide.birch"
        libbirch_line_(75);
        #line 75 "src/expression/Divide.birch"
        r = birch::TransformLinear<libbirch::Shared<birch::type::Gamma>>(1.0 / this->z.value(), x1.value());
      }
    }
  }
  #line 78 "src/expression/Divide.birch"
  libbirch_line_(78);
  #line 78 "src/expression/Divide.birch"
  return r;
}

#line 85 "src/expression/Divide.birch"
libbirch::Shared<birch::type::Divide> birch::operator/(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 85 "src/expression/Divide.birch"
  libbirch_function_("/", "src/expression/Divide.birch", 85);
  #line 86 "src/expression/Divide.birch"
  libbirch_line_(86);
  #line 86 "src/expression/Divide.birch"
  return birch::construct<libbirch::Shared<birch::type::Divide>>(y, z);
}

#line 92 "src/expression/Divide.birch"
libbirch::Shared<birch::type::Divide> birch::operator/(const birch::type::Real& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 92 "src/expression/Divide.birch"
  libbirch_function_("/", "src/expression/Divide.birch", 92);
  #line 93 "src/expression/Divide.birch"
  libbirch_line_(93);
  #line 93 "src/expression/Divide.birch"
  return birch::box(y) / z;
}

#line 99 "src/expression/Divide.birch"
libbirch::Shared<birch::type::Divide> birch::operator/(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const birch::type::Real& z) {
  #line 99 "src/expression/Divide.birch"
  libbirch_function_("/", "src/expression/Divide.birch", 99);
  #line 100 "src/expression/Divide.birch"
  libbirch_line_(100);
  #line 100 "src/expression/Divide.birch"
  return y / birch::box(z);
}

#line 4 "src/expression/Dot.birch"
birch::type::Dot::Dot(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) :
    #line 4 "src/expression/Dot.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/Dot.birch"
birch::type::Real birch::type::Dot::doEvaluate(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 7 "src/expression/Dot.birch"
  libbirch_function_("doEvaluate", "src/expression/Dot.birch", 7);
  #line 8 "src/expression/Dot.birch"
  libbirch_line_(8);
  #line 8 "src/expression/Dot.birch"
  return birch::dot(y, z);
}

#line 11 "src/expression/Dot.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::Dot::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Real& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 11 "src/expression/Dot.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/Dot.birch", 11);
  #line 13 "src/expression/Dot.birch"
  libbirch_line_(13);
  #line 13 "src/expression/Dot.birch"
  return d * z;
}

#line 16 "src/expression/Dot.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::Dot::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Real& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 16 "src/expression/Dot.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/Dot.birch", 16);
  #line 18 "src/expression/Dot.birch"
  libbirch_line_(18);
  #line 18 "src/expression/Dot.birch"
  return d * y;
}

#line 21 "src/expression/Dot.birch"
std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateGaussian>>>> birch::type::Dot::graftDotMultivariateGaussian() {
  #line 21 "src/expression/Dot.birch"
  libbirch_function_("graftDotMultivariateGaussian", "src/expression/Dot.birch", 21);
  #line 23 "src/expression/Dot.birch"
  libbirch_line_(23);
  #line 23 "src/expression/Dot.birch"
  if (!(this->hasValue())) {
    #line 24 "src/expression/Dot.birch"
    libbirch_line_(24);
    #line 24 "src/expression/Dot.birch"
    std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>>>>();
    #line 25 "src/expression/Dot.birch"
    libbirch_line_(25);
    #line 25 "src/expression/Dot.birch"
    std::optional<libbirch::Shared<birch::type::MultivariateGaussian>> x2 = libbirch::make<std::optional<libbirch::Shared<birch::type::MultivariateGaussian>>>();
    #line 27 "src/expression/Dot.birch"
    libbirch_line_(27);
    #line 27 "src/expression/Dot.birch"
    if ((x1 = this->z.value()->graftLinearMultivariateGaussian()).has_value()) {
      #line 28 "src/expression/Dot.birch"
      libbirch_line_(28);
      #line 28 "src/expression/Dot.birch"
      return birch::TransformDot<libbirch::Shared<birch::type::MultivariateGaussian>>(x1.value()->A * this->y.value(), x1.value()->x, birch::dot(x1.value()->c, this->y.value()));
    } else {
      #line 29 "src/expression/Dot.birch"
      libbirch_line_(29);
      #line 29 "src/expression/Dot.birch"
      if ((x1 = this->y.value()->graftLinearMultivariateGaussian()).has_value()) {
        #line 30 "src/expression/Dot.birch"
        libbirch_line_(30);
        #line 30 "src/expression/Dot.birch"
        return birch::TransformDot<libbirch::Shared<birch::type::MultivariateGaussian>>(x1.value()->A * this->z.value(), x1.value()->x, birch::dot(x1.value()->c, this->z.value()));
      } else {
        #line 31 "src/expression/Dot.birch"
        libbirch_line_(31);
        #line 31 "src/expression/Dot.birch"
        if ((x2 = this->z.value()->graftMultivariateGaussian()).has_value()) {
          #line 32 "src/expression/Dot.birch"
          libbirch_line_(32);
          #line 32 "src/expression/Dot.birch"
          return birch::TransformDot<libbirch::Shared<birch::type::MultivariateGaussian>>(this->y.value(), x2.value(), birch::box(0.0));
        } else {
          #line 33 "src/expression/Dot.birch"
          libbirch_line_(33);
          #line 33 "src/expression/Dot.birch"
          if ((x2 = this->y.value()->graftMultivariateGaussian()).has_value()) {
            #line 34 "src/expression/Dot.birch"
            libbirch_line_(34);
            #line 34 "src/expression/Dot.birch"
            return birch::TransformDot<libbirch::Shared<birch::type::MultivariateGaussian>>(this->z.value(), x2.value(), birch::box(0.0));
          }
        }
      }
    }
  }
  #line 37 "src/expression/Dot.birch"
  libbirch_line_(37);
  #line 37 "src/expression/Dot.birch"
  return std::nullopt;
}

#line 40 "src/expression/Dot.birch"
std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>> birch::type::Dot::graftDotMultivariateNormalInverseGamma(const libbirch::Shared<birch::type::Distribution<birch::type::Real>>& compare) {
  #line 40 "src/expression/Dot.birch"
  libbirch_function_("graftDotMultivariateNormalInverseGamma", "src/expression/Dot.birch", 40);
  #line 43 "src/expression/Dot.birch"
  libbirch_line_(43);
  #line 43 "src/expression/Dot.birch"
  if (!(this->hasValue())) {
    #line 44 "src/expression/Dot.birch"
    libbirch_line_(44);
    #line 44 "src/expression/Dot.birch"
    std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>();
    #line 45 "src/expression/Dot.birch"
    libbirch_line_(45);
    #line 45 "src/expression/Dot.birch"
    std::optional<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>> x2 = libbirch::make<std::optional<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>();
    #line 47 "src/expression/Dot.birch"
    libbirch_line_(47);
    #line 47 "src/expression/Dot.birch"
    if ((x1 = this->z.value()->graftLinearMultivariateNormalInverseGamma(compare)).has_value()) {
      #line 48 "src/expression/Dot.birch"
      libbirch_line_(48);
      #line 48 "src/expression/Dot.birch"
      return birch::TransformDot<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>(birch::transpose(x1.value()->A) * this->y.value(), x1.value()->x, birch::dot(this->y.value(), x1.value()->c));
    } else {
      #line 49 "src/expression/Dot.birch"
      libbirch_line_(49);
      #line 49 "src/expression/Dot.birch"
      if ((x1 = this->y.value()->graftLinearMultivariateNormalInverseGamma(compare)).has_value()) {
        #line 50 "src/expression/Dot.birch"
        libbirch_line_(50);
        #line 50 "src/expression/Dot.birch"
        return birch::TransformDot<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>(x1.value()->A * this->z.value(), x1.value()->x, birch::dot(x1.value()->c, this->z.value()));
      } else {
        #line 51 "src/expression/Dot.birch"
        libbirch_line_(51);
        #line 51 "src/expression/Dot.birch"
        if ((x2 = this->z.value()->graftMultivariateNormalInverseGamma(compare)).has_value()) {
          #line 52 "src/expression/Dot.birch"
          libbirch_line_(52);
          #line 52 "src/expression/Dot.birch"
          return birch::TransformDot<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>(this->y.value(), x2.value(), birch::box(0.0));
        } else {
          #line 53 "src/expression/Dot.birch"
          libbirch_line_(53);
          #line 53 "src/expression/Dot.birch"
          if ((x2 = this->y.value()->graftMultivariateNormalInverseGamma(compare)).has_value()) {
            #line 54 "src/expression/Dot.birch"
            libbirch_line_(54);
            #line 54 "src/expression/Dot.birch"
            return birch::TransformDot<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>(this->z.value(), x2.value(), birch::box(0.0));
          }
        }
      }
    }
  }
  #line 57 "src/expression/Dot.birch"
  libbirch_line_(57);
  #line 57 "src/expression/Dot.birch"
  return std::nullopt;
}

#line 64 "src/expression/Dot.birch"
libbirch::Shared<birch::type::Dot> birch::dot(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) {
  #line 64 "src/expression/Dot.birch"
  libbirch_function_("dot", "src/expression/Dot.birch", 64);
  #line 65 "src/expression/Dot.birch"
  libbirch_line_(65);
  #line 65 "src/expression/Dot.birch"
  libbirch_assert_(y->rows() == z->rows());
  #line 66 "src/expression/Dot.birch"
  libbirch_line_(66);
  #line 66 "src/expression/Dot.birch"
  return birch::construct<libbirch::Shared<birch::type::Dot>>(y, z);
}

#line 72 "src/expression/Dot.birch"
libbirch::Shared<birch::type::Dot> birch::dot(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) {
  #line 72 "src/expression/Dot.birch"
  libbirch_function_("dot", "src/expression/Dot.birch", 72);
  #line 73 "src/expression/Dot.birch"
  libbirch_line_(73);
  #line 73 "src/expression/Dot.birch"
  return birch::dot(birch::box(y), z);
}

#line 79 "src/expression/Dot.birch"
libbirch::Shared<birch::type::Dot> birch::dot(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 79 "src/expression/Dot.birch"
  libbirch_function_("dot", "src/expression/Dot.birch", 79);
  #line 80 "src/expression/Dot.birch"
  libbirch_line_(80);
  #line 80 "src/expression/Dot.birch"
  return birch::dot(y, birch::box(z));
}

#line 86 "src/expression/Dot.birch"
libbirch::Shared<birch::type::Dot> birch::dot(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y) {
  #line 86 "src/expression/Dot.birch"
  libbirch_function_("dot", "src/expression/Dot.birch", 86);
  #line 87 "src/expression/Dot.birch"
  libbirch_line_(87);
  #line 87 "src/expression/Dot.birch"
  return birch::dot(y, y);
}

#line 4 "src/expression/Exp.birch"
birch::type::Exp::Exp(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) :
    #line 4 "src/expression/Exp.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 6 "src/expression/Exp.birch"
birch::type::Real birch::type::Exp::doEvaluate(const birch::type::Real& y) {
  #line 6 "src/expression/Exp.birch"
  libbirch_function_("doEvaluate", "src/expression/Exp.birch", 6);
  #line 7 "src/expression/Exp.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Exp.birch"
  return birch::exp(y);
}

#line 10 "src/expression/Exp.birch"
birch::type::Real birch::type::Exp::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y) {
  #line 10 "src/expression/Exp.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Exp.birch", 10);
  #line 11 "src/expression/Exp.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Exp.birch"
  return d * x;
}

#line 18 "src/expression/Exp.birch"
libbirch::Shared<birch::type::Exp> birch::exp(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) {
  #line 18 "src/expression/Exp.birch"
  libbirch_function_("exp", "src/expression/Exp.birch", 18);
  #line 19 "src/expression/Exp.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Exp.birch"
  return birch::construct<libbirch::Shared<birch::type::Exp>>(y);
}

#line 4 "src/expression/IfThenElse.birch"
birch::type::IfThenElse::IfThenElse(const libbirch::Shared<birch::type::Expression<birch::type::Boolean>>& cond, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) :
    #line 4 "src/expression/IfThenElse.birch"
    base_type_(),
    #line 9 "src/expression/IfThenElse.birch"
    cond(std::move(cond)),
    #line 14 "src/expression/IfThenElse.birch"
    y(std::move(y)),
    #line 19 "src/expression/IfThenElse.birch"
    z(std::move(z)) {
  this->libbirch::Any::acyclic_();
}

#line 21 "src/expression/IfThenElse.birch"
birch::type::Integer birch::type::IfThenElse::doDepth() {
  #line 21 "src/expression/IfThenElse.birch"
  libbirch_function_("doDepth", "src/expression/IfThenElse.birch", 21);
  #line 22 "src/expression/IfThenElse.birch"
  libbirch_line_(22);
  #line 22 "src/expression/IfThenElse.birch"
  return birch::max(this->cond.value()->depth(), birch::max(this->y.value()->depth(), this->z.value()->depth())) + birch::type::Integer(1);
}

#line 25 "src/expression/IfThenElse.birch"
birch::type::Real birch::type::IfThenElse::doValue() {
  #line 25 "src/expression/IfThenElse.birch"
  libbirch_function_("doValue", "src/expression/IfThenElse.birch", 25);
  #line 26 "src/expression/IfThenElse.birch"
  libbirch_line_(26);
  #line 26 "src/expression/IfThenElse.birch"
  return birch::if_then_else(this->cond.value()->value(), this->y.value()->value(), this->z.value()->value());
}

#line 29 "src/expression/IfThenElse.birch"
birch::type::Real birch::type::IfThenElse::doPilot(const birch::type::Integer& gen) {
  #line 29 "src/expression/IfThenElse.birch"
  libbirch_function_("doPilot", "src/expression/IfThenElse.birch", 29);
  #line 30 "src/expression/IfThenElse.birch"
  libbirch_line_(30);
  #line 30 "src/expression/IfThenElse.birch"
  return birch::if_then_else(this->cond.value()->pilot(gen), this->y.value()->pilot(gen), this->z.value()->pilot(gen));
}

#line 33 "src/expression/IfThenElse.birch"
birch::type::Real birch::type::IfThenElse::doGet() {
  #line 33 "src/expression/IfThenElse.birch"
  libbirch_function_("doGet", "src/expression/IfThenElse.birch", 33);
  #line 34 "src/expression/IfThenElse.birch"
  libbirch_line_(34);
  #line 34 "src/expression/IfThenElse.birch"
  return birch::if_then_else(this->cond.value()->get(), this->y.value()->get(), this->z.value()->get());
}

#line 37 "src/expression/IfThenElse.birch"
birch::type::Real birch::type::IfThenElse::doMove(const birch::type::Integer& gen, const libbirch::Shared<birch::type::Kernel>& κ) {
  #line 37 "src/expression/IfThenElse.birch"
  libbirch_function_("doMove", "src/expression/IfThenElse.birch", 37);
  #line 38 "src/expression/IfThenElse.birch"
  libbirch_line_(38);
  #line 38 "src/expression/IfThenElse.birch"
  return birch::if_then_else(this->cond.value()->move(gen, κ), this->y.value()->move(gen, κ), this->z.value()->move(gen, κ));
}

#line 41 "src/expression/IfThenElse.birch"
void birch::type::IfThenElse::doGrad(const birch::type::Integer& gen) {
  #line 41 "src/expression/IfThenElse.birch"
  libbirch_function_("doGrad", "src/expression/IfThenElse.birch", 41);
  #line 42 "src/expression/IfThenElse.birch"
  libbirch_line_(42);
  #line 42 "src/expression/IfThenElse.birch"
  this->cond.value()->grad(gen, 0.0);
  #line 43 "src/expression/IfThenElse.birch"
  libbirch_line_(43);
  #line 43 "src/expression/IfThenElse.birch"
  if (this->cond.value()->get()) {
    #line 44 "src/expression/IfThenElse.birch"
    libbirch_line_(44);
    #line 44 "src/expression/IfThenElse.birch"
    this->y.value()->grad(gen, this->d.value());
    #line 45 "src/expression/IfThenElse.birch"
    libbirch_line_(45);
    #line 45 "src/expression/IfThenElse.birch"
    this->z.value()->grad(gen, 0.0);
  } else {
    #line 47 "src/expression/IfThenElse.birch"
    libbirch_line_(47);
    #line 47 "src/expression/IfThenElse.birch"
    this->y.value()->grad(gen, 0.0);
    #line 48 "src/expression/IfThenElse.birch"
    libbirch_line_(48);
    #line 48 "src/expression/IfThenElse.birch"
    this->z.value()->grad(gen, this->d.value());
  }
}

#line 52 "src/expression/IfThenElse.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::IfThenElse::doPrior() {
  #line 52 "src/expression/IfThenElse.birch"
  libbirch_function_("doPrior", "src/expression/IfThenElse.birch", 52);
  #line 53 "src/expression/IfThenElse.birch"
  libbirch_line_(53);
  #line 53 "src/expression/IfThenElse.birch"
  auto c = this->cond.value()->prior();
  #line 54 "src/expression/IfThenElse.birch"
  libbirch_line_(54);
  #line 54 "src/expression/IfThenElse.birch"
  auto l = this->y.value()->prior();
  #line 55 "src/expression/IfThenElse.birch"
  libbirch_line_(55);
  #line 55 "src/expression/IfThenElse.birch"
  auto r = this->z.value()->prior();
  #line 56 "src/expression/IfThenElse.birch"
  libbirch_line_(56);
  #line 56 "src/expression/IfThenElse.birch"
  if (c.has_value() && l.has_value() && r.has_value()) {
    #line 57 "src/expression/IfThenElse.birch"
    libbirch_line_(57);
    #line 57 "src/expression/IfThenElse.birch"
    return c.value() + l.value() + r.value();
  } else {
    #line 58 "src/expression/IfThenElse.birch"
    libbirch_line_(58);
    #line 58 "src/expression/IfThenElse.birch"
    if (c.has_value() && l.has_value()) {
      #line 59 "src/expression/IfThenElse.birch"
      libbirch_line_(59);
      #line 59 "src/expression/IfThenElse.birch"
      return c.value() + l.value();
    } else {
      #line 60 "src/expression/IfThenElse.birch"
      libbirch_line_(60);
      #line 60 "src/expression/IfThenElse.birch"
      if (c.has_value() && r.has_value()) {
        #line 61 "src/expression/IfThenElse.birch"
        libbirch_line_(61);
        #line 61 "src/expression/IfThenElse.birch"
        return c.value() + r.value();
      } else {
        #line 62 "src/expression/IfThenElse.birch"
        libbirch_line_(62);
        #line 62 "src/expression/IfThenElse.birch"
        if (c.has_value()) {
          #line 63 "src/expression/IfThenElse.birch"
          libbirch_line_(63);
          #line 63 "src/expression/IfThenElse.birch"
          return c.value();
        } else {
          #line 64 "src/expression/IfThenElse.birch"
          libbirch_line_(64);
          #line 64 "src/expression/IfThenElse.birch"
          if (l.has_value() && r.has_value()) {
            #line 65 "src/expression/IfThenElse.birch"
            libbirch_line_(65);
            #line 65 "src/expression/IfThenElse.birch"
            return l.value() + r.value();
          } else {
            #line 66 "src/expression/IfThenElse.birch"
            libbirch_line_(66);
            #line 66 "src/expression/IfThenElse.birch"
            if (l.has_value()) {
              #line 67 "src/expression/IfThenElse.birch"
              libbirch_line_(67);
              #line 67 "src/expression/IfThenElse.birch"
              return l.value();
            } else {
              #line 68 "src/expression/IfThenElse.birch"
              libbirch_line_(68);
              #line 68 "src/expression/IfThenElse.birch"
              if (r.has_value()) {
                #line 69 "src/expression/IfThenElse.birch"
                libbirch_line_(69);
                #line 69 "src/expression/IfThenElse.birch"
                return r.value();
              } else {
                #line 71 "src/expression/IfThenElse.birch"
                libbirch_line_(71);
                #line 71 "src/expression/IfThenElse.birch"
                return std::nullopt;
              }
            }
          }
        }
      }
    }
  }
}

#line 75 "src/expression/IfThenElse.birch"
birch::type::Real birch::type::IfThenElse::doCompare(const birch::type::Integer& gen, const libbirch::Shared<birch::type::DelayExpression>& x, const libbirch::Shared<birch::type::Kernel>& κ) {
  #line 75 "src/expression/IfThenElse.birch"
  libbirch_function_("doCompare", "src/expression/IfThenElse.birch", 75);
  #line 77 "src/expression/IfThenElse.birch"
  libbirch_line_(77);
  #line 77 "src/expression/IfThenElse.birch"
  auto o = libbirch::cast<libbirch::Shared<birch::type::IfThenElse>>(x).value();
  #line 78 "src/expression/IfThenElse.birch"
  libbirch_line_(78);
  #line 78 "src/expression/IfThenElse.birch"
  return this->cond.value()->compare(gen, o->cond.value(), κ) + this->y.value()->compare(gen, o->y.value(), κ) + this->z.value()->compare(gen, o->z.value(), κ);
}

#line 82 "src/expression/IfThenElse.birch"
void birch::type::IfThenElse::doConstant() {
  #line 82 "src/expression/IfThenElse.birch"
  libbirch_function_("doConstant", "src/expression/IfThenElse.birch", 82);
  #line 83 "src/expression/IfThenElse.birch"
  libbirch_line_(83);
  #line 83 "src/expression/IfThenElse.birch"
  this->cond.value()->constant();
  #line 84 "src/expression/IfThenElse.birch"
  libbirch_line_(84);
  #line 84 "src/expression/IfThenElse.birch"
  this->y.value()->constant();
  #line 85 "src/expression/IfThenElse.birch"
  libbirch_line_(85);
  #line 85 "src/expression/IfThenElse.birch"
  this->z.value()->constant();
}

#line 88 "src/expression/IfThenElse.birch"
void birch::type::IfThenElse::doCount(const birch::type::Integer& gen) {
  #line 88 "src/expression/IfThenElse.birch"
  libbirch_function_("doCount", "src/expression/IfThenElse.birch", 88);
  #line 89 "src/expression/IfThenElse.birch"
  libbirch_line_(89);
  #line 89 "src/expression/IfThenElse.birch"
  this->cond.value()->count(gen);
  #line 90 "src/expression/IfThenElse.birch"
  libbirch_line_(90);
  #line 90 "src/expression/IfThenElse.birch"
  this->y.value()->count(gen);
  #line 91 "src/expression/IfThenElse.birch"
  libbirch_line_(91);
  #line 91 "src/expression/IfThenElse.birch"
  this->z.value()->count(gen);
}

#line 94 "src/expression/IfThenElse.birch"
void birch::type::IfThenElse::doDetach() {
  #line 94 "src/expression/IfThenElse.birch"
  libbirch_function_("doDetach", "src/expression/IfThenElse.birch", 94);
  #line 95 "src/expression/IfThenElse.birch"
  libbirch_line_(95);
  #line 95 "src/expression/IfThenElse.birch"
  this->cond = std::nullopt;
  #line 96 "src/expression/IfThenElse.birch"
  libbirch_line_(96);
  #line 96 "src/expression/IfThenElse.birch"
  this->y = std::nullopt;
  #line 97 "src/expression/IfThenElse.birch"
  libbirch_line_(97);
  #line 97 "src/expression/IfThenElse.birch"
  this->z = std::nullopt;
}

#line 104 "src/expression/IfThenElse.birch"
libbirch::Shared<birch::type::IfThenElse> birch::if_then_else(const libbirch::Shared<birch::type::Expression<birch::type::Boolean>>& cond, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 104 "src/expression/IfThenElse.birch"
  libbirch_function_("if_then_else", "src/expression/IfThenElse.birch", 104);
  #line 106 "src/expression/IfThenElse.birch"
  libbirch_line_(106);
  #line 106 "src/expression/IfThenElse.birch"
  return birch::construct<libbirch::Shared<birch::type::IfThenElse>>(cond, y, z);
}

#line 112 "src/expression/IfThenElse.birch"
libbirch::Shared<birch::type::IfThenElse> birch::if_then_else(const libbirch::Shared<birch::type::Expression<birch::type::Boolean>>& cond, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const birch::type::Real& z) {
  #line 112 "src/expression/IfThenElse.birch"
  libbirch_function_("if_then_else", "src/expression/IfThenElse.birch", 112);
  #line 114 "src/expression/IfThenElse.birch"
  libbirch_line_(114);
  #line 114 "src/expression/IfThenElse.birch"
  return birch::if_then_else(cond, y, birch::box(z));
}

#line 120 "src/expression/IfThenElse.birch"
libbirch::Shared<birch::type::IfThenElse> birch::if_then_else(const libbirch::Shared<birch::type::Expression<birch::type::Boolean>>& cond, const birch::type::Real& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 120 "src/expression/IfThenElse.birch"
  libbirch_function_("if_then_else", "src/expression/IfThenElse.birch", 120);
  #line 122 "src/expression/IfThenElse.birch"
  libbirch_line_(122);
  #line 122 "src/expression/IfThenElse.birch"
  return birch::if_then_else(cond, birch::box(y), z);
}

#line 128 "src/expression/IfThenElse.birch"
libbirch::Shared<birch::type::IfThenElse> birch::if_then_else(const libbirch::Shared<birch::type::Expression<birch::type::Boolean>>& cond, const birch::type::Real& y, const birch::type::Real& z) {
  #line 128 "src/expression/IfThenElse.birch"
  libbirch_function_("if_then_else", "src/expression/IfThenElse.birch", 128);
  #line 130 "src/expression/IfThenElse.birch"
  libbirch_line_(130);
  #line 130 "src/expression/IfThenElse.birch"
  return birch::if_then_else(cond, birch::box(y), birch::box(z));
}

#line 136 "src/expression/IfThenElse.birch"
libbirch::Shared<birch::type::IfThenElse> birch::if_then_else(const birch::type::Boolean& cond, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 136 "src/expression/IfThenElse.birch"
  libbirch_function_("if_then_else", "src/expression/IfThenElse.birch", 136);
  #line 138 "src/expression/IfThenElse.birch"
  libbirch_line_(138);
  #line 138 "src/expression/IfThenElse.birch"
  return birch::if_then_else(birch::box(cond), y, z);
}

#line 144 "src/expression/IfThenElse.birch"
libbirch::Shared<birch::type::IfThenElse> birch::if_then_else(const birch::type::Boolean& cond, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const birch::type::Real& z) {
  #line 144 "src/expression/IfThenElse.birch"
  libbirch_function_("if_then_else", "src/expression/IfThenElse.birch", 144);
  #line 146 "src/expression/IfThenElse.birch"
  libbirch_line_(146);
  #line 146 "src/expression/IfThenElse.birch"
  return birch::if_then_else(birch::box(cond), y, birch::box(z));
}

#line 152 "src/expression/IfThenElse.birch"
libbirch::Shared<birch::type::IfThenElse> birch::if_then_else(const birch::type::Boolean& cond, const birch::type::Real& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 152 "src/expression/IfThenElse.birch"
  libbirch_function_("if_then_else", "src/expression/IfThenElse.birch", 152);
  #line 154 "src/expression/IfThenElse.birch"
  libbirch_line_(154);
  #line 154 "src/expression/IfThenElse.birch"
  return birch::if_then_else(birch::box(cond), birch::box(y), z);
}

#line 4 "src/expression/LessThan.birch"
birch::type::LessThan::LessThan(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) :
    #line 4 "src/expression/LessThan.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/LessThan.birch"
birch::type::Boolean birch::type::LessThan::doEvaluate(const birch::type::Real& y, const birch::type::Real& z) {
  #line 7 "src/expression/LessThan.birch"
  libbirch_function_("doEvaluate", "src/expression/LessThan.birch", 7);
  #line 8 "src/expression/LessThan.birch"
  libbirch_line_(8);
  #line 8 "src/expression/LessThan.birch"
  return y < z;
}

#line 11 "src/expression/LessThan.birch"
birch::type::Real birch::type::LessThan::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Boolean& x, const birch::type::Real& y, const birch::type::Real& z) {
  #line 11 "src/expression/LessThan.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/LessThan.birch", 11);
  #line 13 "src/expression/LessThan.birch"
  libbirch_line_(13);
  #line 13 "src/expression/LessThan.birch"
  return 0.0;
}

#line 16 "src/expression/LessThan.birch"
birch::type::Real birch::type::LessThan::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Boolean& x, const birch::type::Real& y, const birch::type::Real& z) {
  #line 16 "src/expression/LessThan.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/LessThan.birch", 16);
  #line 18 "src/expression/LessThan.birch"
  libbirch_line_(18);
  #line 18 "src/expression/LessThan.birch"
  return 0.0;
}

#line 25 "src/expression/LessThan.birch"
libbirch::Shared<birch::type::LessThan> birch::operator<(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 25 "src/expression/LessThan.birch"
  libbirch_function_("<", "src/expression/LessThan.birch", 25);
  #line 26 "src/expression/LessThan.birch"
  libbirch_line_(26);
  #line 26 "src/expression/LessThan.birch"
  return birch::construct<libbirch::Shared<birch::type::LessThan>>(y, z);
}

#line 32 "src/expression/LessThan.birch"
libbirch::Shared<birch::type::LessThan> birch::operator<(const birch::type::Real& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 32 "src/expression/LessThan.birch"
  libbirch_function_("<", "src/expression/LessThan.birch", 32);
  #line 33 "src/expression/LessThan.birch"
  libbirch_line_(33);
  #line 33 "src/expression/LessThan.birch"
  return birch::box(y) < z;
}

#line 39 "src/expression/LessThan.birch"
libbirch::Shared<birch::type::LessThan> birch::operator<(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const birch::type::Real& z) {
  #line 39 "src/expression/LessThan.birch"
  libbirch_function_("<", "src/expression/LessThan.birch", 39);
  #line 40 "src/expression/LessThan.birch"
  libbirch_line_(40);
  #line 40 "src/expression/LessThan.birch"
  return y < birch::box(z);
}

#line 4 "src/expression/Log.birch"
birch::type::Log::Log(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) :
    #line 4 "src/expression/Log.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 6 "src/expression/Log.birch"
birch::type::Real birch::type::Log::doEvaluate(const birch::type::Real& y) {
  #line 6 "src/expression/Log.birch"
  libbirch_function_("doEvaluate", "src/expression/Log.birch", 6);
  #line 7 "src/expression/Log.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Log.birch"
  return birch::log(y);
}

#line 10 "src/expression/Log.birch"
birch::type::Real birch::type::Log::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y) {
  #line 10 "src/expression/Log.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Log.birch", 10);
  #line 11 "src/expression/Log.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Log.birch"
  return d / y;
}

#line 18 "src/expression/Log.birch"
libbirch::Shared<birch::type::Log> birch::log(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) {
  #line 18 "src/expression/Log.birch"
  libbirch_function_("log", "src/expression/Log.birch", 18);
  #line 19 "src/expression/Log.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Log.birch"
  return birch::construct<libbirch::Shared<birch::type::Log>>(y);
}

#line 4 "src/expression/Log1p.birch"
birch::type::Log1p::Log1p(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) :
    #line 4 "src/expression/Log1p.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 6 "src/expression/Log1p.birch"
birch::type::Real birch::type::Log1p::doEvaluate(const birch::type::Real& y) {
  #line 6 "src/expression/Log1p.birch"
  libbirch_function_("doEvaluate", "src/expression/Log1p.birch", 6);
  #line 7 "src/expression/Log1p.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Log1p.birch"
  return birch::log1p(y);
}

#line 10 "src/expression/Log1p.birch"
birch::type::Real birch::type::Log1p::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y) {
  #line 10 "src/expression/Log1p.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Log1p.birch", 10);
  #line 11 "src/expression/Log1p.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Log1p.birch"
  return d / (1.0 + y);
}

#line 18 "src/expression/Log1p.birch"
libbirch::Shared<birch::type::Log1p> birch::log1p(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) {
  #line 18 "src/expression/Log1p.birch"
  libbirch_function_("log1p", "src/expression/Log1p.birch", 18);
  #line 19 "src/expression/Log1p.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Log1p.birch"
  return birch::construct<libbirch::Shared<birch::type::Log1p>>(y);
}

#line 4 "src/expression/LogBeta.birch"
birch::type::LogBeta::LogBeta(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) :
    #line 4 "src/expression/LogBeta.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/LogBeta.birch"
birch::type::Real birch::type::LogBeta::doEvaluate(const birch::type::Real& y, const birch::type::Real& z) {
  #line 7 "src/expression/LogBeta.birch"
  libbirch_function_("doEvaluate", "src/expression/LogBeta.birch", 7);
  #line 8 "src/expression/LogBeta.birch"
  libbirch_line_(8);
  #line 8 "src/expression/LogBeta.birch"
  return birch::lbeta(y, z);
}

#line 11 "src/expression/LogBeta.birch"
birch::type::Real birch::type::LogBeta::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z) {
  #line 11 "src/expression/LogBeta.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/LogBeta.birch", 11);
  #line 12 "src/expression/LogBeta.birch"
  libbirch_line_(12);
  #line 12 "src/expression/LogBeta.birch"
  return d * (birch::digamma(y) + birch::digamma(y + z));
}

#line 15 "src/expression/LogBeta.birch"
birch::type::Real birch::type::LogBeta::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z) {
  #line 15 "src/expression/LogBeta.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/LogBeta.birch", 15);
  #line 16 "src/expression/LogBeta.birch"
  libbirch_line_(16);
  #line 16 "src/expression/LogBeta.birch"
  return d * (birch::digamma(z) + birch::digamma(y + z));
}

#line 23 "src/expression/LogBeta.birch"
libbirch::Shared<birch::type::LogBeta> birch::lbeta(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) {
  #line 23 "src/expression/LogBeta.birch"
  libbirch_function_("lbeta", "src/expression/LogBeta.birch", 23);
  #line 24 "src/expression/LogBeta.birch"
  libbirch_line_(24);
  #line 24 "src/expression/LogBeta.birch"
  return birch::construct<libbirch::Shared<birch::type::LogBeta>>(x, y);
}

#line 30 "src/expression/LogBeta.birch"
libbirch::Shared<birch::type::LogBeta> birch::lbeta(const birch::type::Real& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) {
  #line 30 "src/expression/LogBeta.birch"
  libbirch_function_("lbeta", "src/expression/LogBeta.birch", 30);
  #line 31 "src/expression/LogBeta.birch"
  libbirch_line_(31);
  #line 31 "src/expression/LogBeta.birch"
  return birch::lbeta(birch::box(x), y);
}

#line 37 "src/expression/LogBeta.birch"
libbirch::Shared<birch::type::LogBeta> birch::lbeta(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const birch::type::Real& y) {
  #line 37 "src/expression/LogBeta.birch"
  libbirch_function_("lbeta", "src/expression/LogBeta.birch", 37);
  #line 38 "src/expression/LogBeta.birch"
  libbirch_line_(38);
  #line 38 "src/expression/LogBeta.birch"
  return birch::lbeta(x, birch::box(y));
}

#line 4 "src/expression/LogChoose.birch"
birch::type::LogChoose::LogChoose(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& z) :
    #line 4 "src/expression/LogChoose.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/LogChoose.birch"
birch::type::Real birch::type::LogChoose::doEvaluate(const birch::type::Integer& y, const birch::type::Integer& z) {
  #line 7 "src/expression/LogChoose.birch"
  libbirch_function_("doEvaluate", "src/expression/LogChoose.birch", 7);
  #line 8 "src/expression/LogChoose.birch"
  libbirch_line_(8);
  #line 8 "src/expression/LogChoose.birch"
  return birch::lchoose(y, z);
}

#line 11 "src/expression/LogChoose.birch"
birch::type::Real birch::type::LogChoose::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Integer& y, const birch::type::Integer& z) {
  #line 11 "src/expression/LogChoose.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/LogChoose.birch", 11);
  #line 13 "src/expression/LogChoose.birch"
  libbirch_line_(13);
  #line 13 "src/expression/LogChoose.birch"
  return 0.0;
}

#line 16 "src/expression/LogChoose.birch"
birch::type::Real birch::type::LogChoose::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Integer& y, const birch::type::Integer& z) {
  #line 16 "src/expression/LogChoose.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/LogChoose.birch", 16);
  #line 18 "src/expression/LogChoose.birch"
  libbirch_line_(18);
  #line 18 "src/expression/LogChoose.birch"
  return 0.0;
}

#line 25 "src/expression/LogChoose.birch"
libbirch::Shared<birch::type::LogChoose> birch::lchoose(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& z) {
  #line 25 "src/expression/LogChoose.birch"
  libbirch_function_("lchoose", "src/expression/LogChoose.birch", 25);
  #line 26 "src/expression/LogChoose.birch"
  libbirch_line_(26);
  #line 26 "src/expression/LogChoose.birch"
  return birch::construct<libbirch::Shared<birch::type::LogChoose>>(y, z);
}

#line 32 "src/expression/LogChoose.birch"
libbirch::Shared<birch::type::LogChoose> birch::lchoose(const birch::type::Integer& y, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& z) {
  #line 32 "src/expression/LogChoose.birch"
  libbirch_function_("lchoose", "src/expression/LogChoose.birch", 32);
  #line 33 "src/expression/LogChoose.birch"
  libbirch_line_(33);
  #line 33 "src/expression/LogChoose.birch"
  return birch::lchoose(birch::box(y), z);
}

#line 39 "src/expression/LogChoose.birch"
libbirch::Shared<birch::type::LogChoose> birch::lchoose(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& y, const birch::type::Integer& z) {
  #line 39 "src/expression/LogChoose.birch"
  libbirch_function_("lchoose", "src/expression/LogChoose.birch", 39);
  #line 40 "src/expression/LogChoose.birch"
  libbirch_line_(40);
  #line 40 "src/expression/LogChoose.birch"
  return birch::lchoose(y, birch::box(z));
}

#line 19 "src/expression/LogDet.birch"
libbirch::Shared<birch::type::LogDet<libbirch::Shared<birch::type::Expression<birch::type::LLT>>, birch::type::LLT>> birch::ldet(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& y) {
  #line 19 "src/expression/LogDet.birch"
  libbirch_function_("ldet", "src/expression/LogDet.birch", 19);
  #line 20 "src/expression/LogDet.birch"
  libbirch_line_(20);
  #line 20 "src/expression/LogDet.birch"
  return birch::construct<libbirch::Shared<birch::type::LogDet<libbirch::Shared<birch::type::Expression<birch::type::LLT>>, birch::type::LLT>>>(y);
}

#line 26 "src/expression/LogDet.birch"
libbirch::Shared<birch::type::LogDet<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::DefaultArray<birch::type::Real,2>>> birch::ldet(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y) {
  #line 26 "src/expression/LogDet.birch"
  libbirch_function_("ldet", "src/expression/LogDet.birch", 26);
  #line 28 "src/expression/LogDet.birch"
  libbirch_line_(28);
  #line 28 "src/expression/LogDet.birch"
  return birch::construct<libbirch::Shared<birch::type::LogDet<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::DefaultArray<birch::type::Real,2>>>>(y);
}

#line 4 "src/expression/LogGamma.birch"
birch::type::LogGamma::LogGamma(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) :
    #line 4 "src/expression/LogGamma.birch"
    base_type_(x) {
  this->libbirch::Any::acyclic_();
}

#line 6 "src/expression/LogGamma.birch"
birch::type::Real birch::type::LogGamma::doEvaluate(const birch::type::Real& y) {
  #line 6 "src/expression/LogGamma.birch"
  libbirch_function_("doEvaluate", "src/expression/LogGamma.birch", 6);
  #line 7 "src/expression/LogGamma.birch"
  libbirch_line_(7);
  #line 7 "src/expression/LogGamma.birch"
  return birch::lgamma(y);
}

#line 10 "src/expression/LogGamma.birch"
birch::type::Real birch::type::LogGamma::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y) {
  #line 10 "src/expression/LogGamma.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/LogGamma.birch", 10);
  #line 11 "src/expression/LogGamma.birch"
  libbirch_line_(11);
  #line 11 "src/expression/LogGamma.birch"
  return d * birch::digamma(y);
}

#line 18 "src/expression/LogGamma.birch"
libbirch::Shared<birch::type::LogGamma> birch::lgamma(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 18 "src/expression/LogGamma.birch"
  libbirch_function_("lgamma", "src/expression/LogGamma.birch", 18);
  #line 19 "src/expression/LogGamma.birch"
  libbirch_line_(19);
  #line 19 "src/expression/LogGamma.birch"
  return birch::construct<libbirch::Shared<birch::type::LogGamma>>(x);
}

#line 4 "src/expression/LogGammaP.birch"
birch::type::LogGammaP::LogGammaP(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const birch::type::Integer& z) :
    #line 4 "src/expression/LogGammaP.birch"
    base_type_(y),
    #line 9 "src/expression/LogGammaP.birch"
    z(std::move(z)) {
  this->libbirch::Any::acyclic_();
}

#line 11 "src/expression/LogGammaP.birch"
birch::type::Real birch::type::LogGammaP::doEvaluate(const birch::type::Real& y) {
  #line 11 "src/expression/LogGammaP.birch"
  libbirch_function_("doEvaluate", "src/expression/LogGammaP.birch", 11);
  #line 12 "src/expression/LogGammaP.birch"
  libbirch_line_(12);
  #line 12 "src/expression/LogGammaP.birch"
  return birch::lgamma(y, this->z);
}

#line 15 "src/expression/LogGammaP.birch"
birch::type::Real birch::type::LogGammaP::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y) {
  #line 15 "src/expression/LogGammaP.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/LogGammaP.birch", 15);
  #line 16 "src/expression/LogGammaP.birch"
  libbirch_line_(16);
  #line 16 "src/expression/LogGammaP.birch"
  auto r = 0.0;
  #line 17 "src/expression/LogGammaP.birch"
  libbirch_line_(17);
  #line 17 "src/expression/LogGammaP.birch"
  for (auto i = birch::type::Integer(1); i <= this->z; ++i) {
    #line 18 "src/expression/LogGammaP.birch"
    libbirch_line_(18);
    #line 18 "src/expression/LogGammaP.birch"
    r = r + birch::digamma(y + 0.5 * (birch::type::Integer(1) - i));
  }
  #line 20 "src/expression/LogGammaP.birch"
  libbirch_line_(20);
  #line 20 "src/expression/LogGammaP.birch"
  return d * r;
}

#line 27 "src/expression/LogGammaP.birch"
libbirch::Shared<birch::type::LogGammaP> birch::lgamma(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const birch::type::Integer& z) {
  #line 27 "src/expression/LogGammaP.birch"
  libbirch_function_("lgamma", "src/expression/LogGammaP.birch", 27);
  #line 28 "src/expression/LogGammaP.birch"
  libbirch_line_(28);
  #line 28 "src/expression/LogGammaP.birch"
  return birch::construct<libbirch::Shared<birch::type::LogGammaP>>(y, z);
}

#line 4 "src/expression/MatrixAbs.birch"
birch::type::MatrixAbs::MatrixAbs(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y) :
    #line 4 "src/expression/MatrixAbs.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/MatrixAbs.birch"
birch::type::Integer birch::type::MatrixAbs::doRows() {
  #line 7 "src/expression/MatrixAbs.birch"
  libbirch_function_("doRows", "src/expression/MatrixAbs.birch", 7);
  #line 8 "src/expression/MatrixAbs.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MatrixAbs.birch"
  return this->y.value()->rows();
}

#line 11 "src/expression/MatrixAbs.birch"
birch::type::Integer birch::type::MatrixAbs::doColumns() {
  #line 11 "src/expression/MatrixAbs.birch"
  libbirch_function_("doColumns", "src/expression/MatrixAbs.birch", 11);
  #line 12 "src/expression/MatrixAbs.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MatrixAbs.birch"
  return this->y.value()->columns();
}

#line 15 "src/expression/MatrixAbs.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixAbs::doEvaluate(const libbirch::DefaultArray<birch::type::Real,2>& y) {
  #line 15 "src/expression/MatrixAbs.birch"
  libbirch_function_("doEvaluate", "src/expression/MatrixAbs.birch", 15);
  #line 16 "src/expression/MatrixAbs.birch"
  libbirch_line_(16);
  #line 16 "src/expression/MatrixAbs.birch"
  return birch::transform(y, std::function<birch::type::Real(birch::type::Real)>([=](const birch::type::Real& y) {
    #line 16 "src/expression/MatrixAbs.birch"
    libbirch_line_(16);
    #line 16 "src/expression/MatrixAbs.birch"
    return birch::abs(y);
  }));
}

#line 19 "src/expression/MatrixAbs.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixAbs::doEvaluateGrad(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y) {
  #line 19 "src/expression/MatrixAbs.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/MatrixAbs.birch", 19);
  #line 21 "src/expression/MatrixAbs.birch"
  libbirch_line_(21);
  #line 21 "src/expression/MatrixAbs.birch"
  return birch::transform(d, x, std::function<birch::type::Real(birch::type::Real,birch::type::Real)>([=](const birch::type::Real& d, const birch::type::Real& x) {
    #line 22 "src/expression/MatrixAbs.birch"
    libbirch_line_(22);
    #line 22 "src/expression/MatrixAbs.birch"
    if (x >= 0.0) {
      #line 23 "src/expression/MatrixAbs.birch"
      libbirch_line_(23);
      #line 23 "src/expression/MatrixAbs.birch"
      return d;
    } else {
      #line 25 "src/expression/MatrixAbs.birch"
      libbirch_line_(25);
      #line 25 "src/expression/MatrixAbs.birch"
      return -(d);
    }
  }));
}

#line 34 "src/expression/MatrixAbs.birch"
libbirch::Shared<birch::type::MatrixAbs> birch::abs(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y) {
  #line 34 "src/expression/MatrixAbs.birch"
  libbirch_function_("abs", "src/expression/MatrixAbs.birch", 34);
  #line 35 "src/expression/MatrixAbs.birch"
  libbirch_line_(35);
  #line 35 "src/expression/MatrixAbs.birch"
  return birch::construct<libbirch::Shared<birch::type::MatrixAbs>>(y);
}

#line 4 "src/expression/MatrixAdd.birch"
birch::type::MatrixAdd::MatrixAdd(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) :
    #line 4 "src/expression/MatrixAdd.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/MatrixAdd.birch"
birch::type::Integer birch::type::MatrixAdd::doRows() {
  #line 7 "src/expression/MatrixAdd.birch"
  libbirch_function_("doRows", "src/expression/MatrixAdd.birch", 7);
  #line 8 "src/expression/MatrixAdd.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MatrixAdd.birch"
  return this->y.value()->rows();
}

#line 11 "src/expression/MatrixAdd.birch"
birch::type::Integer birch::type::MatrixAdd::doColumns() {
  #line 11 "src/expression/MatrixAdd.birch"
  libbirch_function_("doColumns", "src/expression/MatrixAdd.birch", 11);
  #line 12 "src/expression/MatrixAdd.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MatrixAdd.birch"
  return this->y.value()->columns();
}

#line 15 "src/expression/MatrixAdd.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixAdd::doEvaluate(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 15 "src/expression/MatrixAdd.birch"
  libbirch_function_("doEvaluate", "src/expression/MatrixAdd.birch", 15);
  #line 16 "src/expression/MatrixAdd.birch"
  libbirch_line_(16);
  #line 16 "src/expression/MatrixAdd.birch"
  return y + z;
}

#line 19 "src/expression/MatrixAdd.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixAdd::doEvaluateGradLeft(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 19 "src/expression/MatrixAdd.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/MatrixAdd.birch", 19);
  #line 20 "src/expression/MatrixAdd.birch"
  libbirch_line_(20);
  #line 20 "src/expression/MatrixAdd.birch"
  return d;
}

#line 23 "src/expression/MatrixAdd.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixAdd::doEvaluateGradRight(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 23 "src/expression/MatrixAdd.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/MatrixAdd.birch", 23);
  #line 24 "src/expression/MatrixAdd.birch"
  libbirch_line_(24);
  #line 24 "src/expression/MatrixAdd.birch"
  return d;
}

#line 27 "src/expression/MatrixAdd.birch"
std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixGaussian>>>> birch::type::MatrixAdd::graftLinearMatrixGaussian() {
  #line 27 "src/expression/MatrixAdd.birch"
  libbirch_function_("graftLinearMatrixGaussian", "src/expression/MatrixAdd.birch", 27);
  #line 29 "src/expression/MatrixAdd.birch"
  libbirch_line_(29);
  #line 29 "src/expression/MatrixAdd.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixGaussian>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixGaussian>>>>>();
  #line 30 "src/expression/MatrixAdd.birch"
  libbirch_line_(30);
  #line 30 "src/expression/MatrixAdd.birch"
  if (!(this->hasValue())) {
    #line 31 "src/expression/MatrixAdd.birch"
    libbirch_line_(31);
    #line 31 "src/expression/MatrixAdd.birch"
    std::optional<libbirch::Shared<birch::type::MatrixGaussian>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::MatrixGaussian>>>();
    #line 33 "src/expression/MatrixAdd.birch"
    libbirch_line_(33);
    #line 33 "src/expression/MatrixAdd.birch"
    if ((r = this->y.value()->graftLinearMatrixGaussian()).has_value()) {
      #line 34 "src/expression/MatrixAdd.birch"
      libbirch_line_(34);
      #line 34 "src/expression/MatrixAdd.birch"
      r.value()->add(this->z.value());
    } else {
      #line 35 "src/expression/MatrixAdd.birch"
      libbirch_line_(35);
      #line 35 "src/expression/MatrixAdd.birch"
      if ((r = this->z.value()->graftLinearMatrixGaussian()).has_value()) {
        #line 36 "src/expression/MatrixAdd.birch"
        libbirch_line_(36);
        #line 36 "src/expression/MatrixAdd.birch"
        r.value()->add(this->y.value());
      } else {
        #line 37 "src/expression/MatrixAdd.birch"
        libbirch_line_(37);
        #line 37 "src/expression/MatrixAdd.birch"
        if ((x1 = this->y.value()->graftMatrixGaussian()).has_value()) {
          #line 38 "src/expression/MatrixAdd.birch"
          libbirch_line_(38);
          #line 38 "src/expression/MatrixAdd.birch"
          r = birch::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixGaussian>>(birch::box(birch::identity(this->z.value()->rows())), x1.value(), this->z.value());
        } else {
          #line 39 "src/expression/MatrixAdd.birch"
          libbirch_line_(39);
          #line 39 "src/expression/MatrixAdd.birch"
          if ((x1 = this->z.value()->graftMatrixGaussian()).has_value()) {
            #line 40 "src/expression/MatrixAdd.birch"
            libbirch_line_(40);
            #line 40 "src/expression/MatrixAdd.birch"
            r = birch::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixGaussian>>(birch::box(birch::identity(this->z.value()->rows())), x1.value(), this->y.value());
          }
        }
      }
    }
  }
  #line 43 "src/expression/MatrixAdd.birch"
  libbirch_line_(43);
  #line 43 "src/expression/MatrixAdd.birch"
  return r;
}

#line 46 "src/expression/MatrixAdd.birch"
std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>> birch::type::MatrixAdd::graftLinearMatrixNormalInverseWishart(const libbirch::Shared<birch::type::Distribution<birch::type::LLT>>& compare) {
  #line 46 "src/expression/MatrixAdd.birch"
  libbirch_function_("graftLinearMatrixNormalInverseWishart", "src/expression/MatrixAdd.birch", 46);
  #line 48 "src/expression/MatrixAdd.birch"
  libbirch_line_(48);
  #line 48 "src/expression/MatrixAdd.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>>>();
  #line 49 "src/expression/MatrixAdd.birch"
  libbirch_line_(49);
  #line 49 "src/expression/MatrixAdd.birch"
  if (!(this->hasValue())) {
    #line 50 "src/expression/MatrixAdd.birch"
    libbirch_line_(50);
    #line 50 "src/expression/MatrixAdd.birch"
    std::optional<libbirch::Shared<birch::type::MatrixNormalInverseWishart>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>();
    #line 52 "src/expression/MatrixAdd.birch"
    libbirch_line_(52);
    #line 52 "src/expression/MatrixAdd.birch"
    if ((r = this->y.value()->graftLinearMatrixNormalInverseWishart(compare)).has_value()) {
      #line 53 "src/expression/MatrixAdd.birch"
      libbirch_line_(53);
      #line 53 "src/expression/MatrixAdd.birch"
      r.value()->add(this->z.value());
    } else {
      #line 54 "src/expression/MatrixAdd.birch"
      libbirch_line_(54);
      #line 54 "src/expression/MatrixAdd.birch"
      if ((r = this->z.value()->graftLinearMatrixNormalInverseWishart(compare)).has_value()) {
        #line 55 "src/expression/MatrixAdd.birch"
        libbirch_line_(55);
        #line 55 "src/expression/MatrixAdd.birch"
        r.value()->add(this->y.value());
      } else {
        #line 56 "src/expression/MatrixAdd.birch"
        libbirch_line_(56);
        #line 56 "src/expression/MatrixAdd.birch"
        if ((x1 = this->y.value()->graftMatrixNormalInverseWishart(compare)).has_value()) {
          #line 57 "src/expression/MatrixAdd.birch"
          libbirch_line_(57);
          #line 57 "src/expression/MatrixAdd.birch"
          r = birch::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>(birch::box(birch::identity(this->z.value()->rows())), x1.value(), this->z.value());
        } else {
          #line 58 "src/expression/MatrixAdd.birch"
          libbirch_line_(58);
          #line 58 "src/expression/MatrixAdd.birch"
          if ((x1 = this->z.value()->graftMatrixNormalInverseWishart(compare)).has_value()) {
            #line 59 "src/expression/MatrixAdd.birch"
            libbirch_line_(59);
            #line 59 "src/expression/MatrixAdd.birch"
            r = birch::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>(birch::box(birch::identity(this->z.value()->rows())), x1.value(), this->y.value());
          }
        }
      }
    }
  }
  #line 62 "src/expression/MatrixAdd.birch"
  libbirch_line_(62);
  #line 62 "src/expression/MatrixAdd.birch"
  return r;
}

#line 69 "src/expression/MatrixAdd.birch"
libbirch::Shared<birch::type::MatrixAdd> birch::operator+(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) {
  #line 69 "src/expression/MatrixAdd.birch"
  libbirch_function_("+", "src/expression/MatrixAdd.birch", 69);
  #line 70 "src/expression/MatrixAdd.birch"
  libbirch_line_(70);
  #line 70 "src/expression/MatrixAdd.birch"
  libbirch_assert_(y->rows() == z->rows());
  #line 71 "src/expression/MatrixAdd.birch"
  libbirch_line_(71);
  #line 71 "src/expression/MatrixAdd.birch"
  libbirch_assert_(y->columns() == z->columns());
  #line 72 "src/expression/MatrixAdd.birch"
  libbirch_line_(72);
  #line 72 "src/expression/MatrixAdd.birch"
  return birch::construct<libbirch::Shared<birch::type::MatrixAdd>>(y, z);
}

#line 78 "src/expression/MatrixAdd.birch"
libbirch::Shared<birch::type::MatrixAdd> birch::operator+(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) {
  #line 78 "src/expression/MatrixAdd.birch"
  libbirch_function_("+", "src/expression/MatrixAdd.birch", 78);
  #line 79 "src/expression/MatrixAdd.birch"
  libbirch_line_(79);
  #line 79 "src/expression/MatrixAdd.birch"
  return birch::box(y) + z;
}

#line 85 "src/expression/MatrixAdd.birch"
libbirch::Shared<birch::type::MatrixAdd> birch::operator+(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 85 "src/expression/MatrixAdd.birch"
  libbirch_function_("+", "src/expression/MatrixAdd.birch", 85);
  #line 86 "src/expression/MatrixAdd.birch"
  libbirch_line_(86);
  #line 86 "src/expression/MatrixAdd.birch"
  return y + birch::box(z);
}

#line 27 "src/expression/MatrixCanonical.birch"
libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>> birch::canonical(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& y) {
  #line 27 "src/expression/MatrixCanonical.birch"
  libbirch_function_("canonical", "src/expression/MatrixCanonical.birch", 27);
  #line 28 "src/expression/MatrixCanonical.birch"
  libbirch_line_(28);
  #line 28 "src/expression/MatrixCanonical.birch"
  return birch::construct<libbirch::Shared<birch::type::MatrixCanonical<libbirch::Shared<birch::type::Expression<birch::type::LLT>>, birch::type::LLT>>>(y);
}

#line 34 "src/expression/MatrixCanonical.birch"
libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>> birch::canonical(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y) {
  #line 34 "src/expression/MatrixCanonical.birch"
  libbirch_function_("canonical", "src/expression/MatrixCanonical.birch", 34);
  #line 35 "src/expression/MatrixCanonical.birch"
  libbirch_line_(35);
  #line 35 "src/expression/MatrixCanonical.birch"
  if (!(y->isRandom())) {
    #line 37 "src/expression/MatrixCanonical.birch"
    libbirch_line_(37);
    #line 37 "src/expression/MatrixCanonical.birch"
    return y;
  } else {
    #line 41 "src/expression/MatrixCanonical.birch"
    libbirch_line_(41);
    #line 41 "src/expression/MatrixCanonical.birch"
    return birch::construct<libbirch::Shared<birch::type::MatrixCanonical<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::DefaultArray<birch::type::Real,2>>>>(y);
  }
}

#line 4 "src/expression/MatrixDiagonal.birch"
birch::type::MatrixDiagonal::MatrixDiagonal(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y) :
    #line 4 "src/expression/MatrixDiagonal.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 6 "src/expression/MatrixDiagonal.birch"
birch::type::Integer birch::type::MatrixDiagonal::doRows() {
  #line 6 "src/expression/MatrixDiagonal.birch"
  libbirch_function_("doRows", "src/expression/MatrixDiagonal.birch", 6);
  #line 7 "src/expression/MatrixDiagonal.birch"
  libbirch_line_(7);
  #line 7 "src/expression/MatrixDiagonal.birch"
  return this->y.value()->rows();
}

#line 10 "src/expression/MatrixDiagonal.birch"
birch::type::Integer birch::type::MatrixDiagonal::doColumns() {
  #line 10 "src/expression/MatrixDiagonal.birch"
  libbirch_function_("doColumns", "src/expression/MatrixDiagonal.birch", 10);
  #line 11 "src/expression/MatrixDiagonal.birch"
  libbirch_line_(11);
  #line 11 "src/expression/MatrixDiagonal.birch"
  return this->y.value()->rows();
}

#line 14 "src/expression/MatrixDiagonal.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixDiagonal::doEvaluate(const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 14 "src/expression/MatrixDiagonal.birch"
  libbirch_function_("doEvaluate", "src/expression/MatrixDiagonal.birch", 14);
  #line 15 "src/expression/MatrixDiagonal.birch"
  libbirch_line_(15);
  #line 15 "src/expression/MatrixDiagonal.birch"
  return birch::diagonal(y);
}

#line 18 "src/expression/MatrixDiagonal.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MatrixDiagonal::doEvaluateGrad(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 18 "src/expression/MatrixDiagonal.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/MatrixDiagonal.birch", 18);
  #line 20 "src/expression/MatrixDiagonal.birch"
  libbirch_line_(20);
  #line 20 "src/expression/MatrixDiagonal.birch"
  return birch::diagonal(d);
}

#line 27 "src/expression/MatrixDiagonal.birch"
libbirch::Shared<birch::type::MatrixDiagonal> birch::diagonal(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x) {
  #line 27 "src/expression/MatrixDiagonal.birch"
  libbirch_function_("diagonal", "src/expression/MatrixDiagonal.birch", 27);
  #line 28 "src/expression/MatrixDiagonal.birch"
  libbirch_line_(28);
  #line 28 "src/expression/MatrixDiagonal.birch"
  return birch::construct<libbirch::Shared<birch::type::MatrixDiagonal>>(x);
}

#line 71 "src/expression/MatrixElement.birch"
libbirch::Shared<birch::type::MatrixElement<birch::type::Real>> birch::MatrixElement(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const birch::type::Integer& i, const birch::type::Integer& j) {
  #line 71 "src/expression/MatrixElement.birch"
  libbirch_function_("MatrixElement", "src/expression/MatrixElement.birch", 71);
  #line 73 "src/expression/MatrixElement.birch"
  libbirch_line_(73);
  #line 73 "src/expression/MatrixElement.birch"
  return birch::construct<libbirch::Shared<birch::type::MatrixElement<birch::type::Real>>>(y, i, j);
}

#line 79 "src/expression/MatrixElement.birch"
libbirch::Shared<birch::type::MatrixElement<birch::type::Integer>> birch::MatrixElement(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Integer,2>>>& y, const birch::type::Integer& i, const birch::type::Integer& j) {
  #line 79 "src/expression/MatrixElement.birch"
  libbirch_function_("MatrixElement", "src/expression/MatrixElement.birch", 79);
  #line 81 "src/expression/MatrixElement.birch"
  libbirch_line_(81);
  #line 81 "src/expression/MatrixElement.birch"
  return birch::construct<libbirch::Shared<birch::type::MatrixElement<birch::type::Integer>>>(y, i, j);
}

#line 87 "src/expression/MatrixElement.birch"
libbirch::Shared<birch::type::MatrixElement<birch::type::Boolean>> birch::MatrixElement(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Boolean,2>>>& y, const birch::type::Integer& i, const birch::type::Integer& j) {
  #line 87 "src/expression/MatrixElement.birch"
  libbirch_function_("MatrixElement", "src/expression/MatrixElement.birch", 87);
  #line 89 "src/expression/MatrixElement.birch"
  libbirch_line_(89);
  #line 89 "src/expression/MatrixElement.birch"
  return birch::construct<libbirch::Shared<birch::type::MatrixElement<birch::type::Boolean>>>(y, i, j);
}

#line 28 "src/expression/MatrixInv.birch"
libbirch::Shared<birch::type::MatrixInv<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::DefaultArray<birch::type::Real,2>, libbirch::DefaultArray<birch::type::Real,2>>> birch::inv(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& x) {
  #line 28 "src/expression/MatrixInv.birch"
  libbirch_function_("inv", "src/expression/MatrixInv.birch", 28);
  #line 30 "src/expression/MatrixInv.birch"
  libbirch_line_(30);
  #line 30 "src/expression/MatrixInv.birch"
  return birch::construct<libbirch::Shared<birch::type::MatrixInv<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::DefaultArray<birch::type::Real,2>, libbirch::DefaultArray<birch::type::Real,2>>>>(x);
}

#line 36 "src/expression/MatrixInv.birch"
libbirch::Shared<birch::type::MatrixInv<libbirch::Shared<birch::type::Expression<birch::type::LLT>>, birch::type::LLT, birch::type::LLT>> birch::inv(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& x) {
  #line 36 "src/expression/MatrixInv.birch"
  libbirch_function_("inv", "src/expression/MatrixInv.birch", 36);
  #line 37 "src/expression/MatrixInv.birch"
  libbirch_line_(37);
  #line 37 "src/expression/MatrixInv.birch"
  return birch::construct<libbirch::Shared<birch::type::MatrixInv<libbirch::Shared<birch::type::Expression<birch::type::LLT>>, birch::type::LLT, birch::type::LLT>>>(x);
}

#line 4 "src/expression/MatrixLLT.birch"
birch::type::MatrixLLT::MatrixLLT(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y) :
    #line 4 "src/expression/MatrixLLT.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 6 "src/expression/MatrixLLT.birch"
birch::type::Integer birch::type::MatrixLLT::doRows() {
  #line 6 "src/expression/MatrixLLT.birch"
  libbirch_function_("doRows", "src/expression/MatrixLLT.birch", 6);
  #line 7 "src/expression/MatrixLLT.birch"
  libbirch_line_(7);
  #line 7 "src/expression/MatrixLLT.birch"
  return this->y.value()->rows();
}

#line 10 "src/expression/MatrixLLT.birch"
birch::type::Integer birch::type::MatrixLLT::doColumns() {
  #line 10 "src/expression/MatrixLLT.birch"
  libbirch_function_("doColumns", "src/expression/MatrixLLT.birch", 10);
  #line 11 "src/expression/MatrixLLT.birch"
  libbirch_line_(11);
  #line 11 "src/expression/MatrixLLT.birch"
  return this->y.value()->columns();
}

#line 14 "src/expression/MatrixLLT.birch"
birch::type::LLT birch::type::MatrixLLT::doEvaluate(const libbirch::DefaultArray<birch::type::Real,2>& y) {
  #line 14 "src/expression/MatrixLLT.birch"
  libbirch_function_("doEvaluate", "src/expression/MatrixLLT.birch", 14);
  #line 15 "src/expression/MatrixLLT.birch"
  libbirch_line_(15);
  #line 15 "src/expression/MatrixLLT.birch"
  return birch::llt(y);
}

#line 18 "src/expression/MatrixLLT.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixLLT::doEvaluateGrad(const libbirch::DefaultArray<birch::type::Real,2>& d, const birch::type::LLT& x, const libbirch::DefaultArray<birch::type::Real,2>& y) {
  #line 18 "src/expression/MatrixLLT.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/MatrixLLT.birch", 18);
  #line 20 "src/expression/MatrixLLT.birch"
  libbirch_line_(20);
  #line 20 "src/expression/MatrixLLT.birch"
  return d;
}

#line 27 "src/expression/MatrixLLT.birch"
libbirch::Shared<birch::type::MatrixLLT> birch::llt(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y) {
  #line 27 "src/expression/MatrixLLT.birch"
  libbirch_function_("llt", "src/expression/MatrixLLT.birch", 27);
  #line 28 "src/expression/MatrixLLT.birch"
  libbirch_line_(28);
  #line 28 "src/expression/MatrixLLT.birch"
  return birch::construct<libbirch::Shared<birch::type::MatrixLLT>>(y);
}

#line 4 "src/expression/MatrixMultiply.birch"
birch::type::MatrixMultiply::MatrixMultiply(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) :
    #line 4 "src/expression/MatrixMultiply.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 8 "src/expression/MatrixMultiply.birch"
birch::type::Integer birch::type::MatrixMultiply::doRows() {
  #line 8 "src/expression/MatrixMultiply.birch"
  libbirch_function_("doRows", "src/expression/MatrixMultiply.birch", 8);
  #line 9 "src/expression/MatrixMultiply.birch"
  libbirch_line_(9);
  #line 9 "src/expression/MatrixMultiply.birch"
  return this->y.value()->rows();
}

#line 12 "src/expression/MatrixMultiply.birch"
birch::type::Integer birch::type::MatrixMultiply::doColumns() {
  #line 12 "src/expression/MatrixMultiply.birch"
  libbirch_function_("doColumns", "src/expression/MatrixMultiply.birch", 12);
  #line 13 "src/expression/MatrixMultiply.birch"
  libbirch_line_(13);
  #line 13 "src/expression/MatrixMultiply.birch"
  return this->z.value()->columns();
}

#line 16 "src/expression/MatrixMultiply.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixMultiply::doEvaluate(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 16 "src/expression/MatrixMultiply.birch"
  libbirch_function_("doEvaluate", "src/expression/MatrixMultiply.birch", 16);
  #line 17 "src/expression/MatrixMultiply.birch"
  libbirch_line_(17);
  #line 17 "src/expression/MatrixMultiply.birch"
  return y * z;
}

#line 20 "src/expression/MatrixMultiply.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixMultiply::doEvaluateGradLeft(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 20 "src/expression/MatrixMultiply.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/MatrixMultiply.birch", 20);
  #line 22 "src/expression/MatrixMultiply.birch"
  libbirch_line_(22);
  #line 22 "src/expression/MatrixMultiply.birch"
  return d * birch::transpose(z);
}

#line 25 "src/expression/MatrixMultiply.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixMultiply::doEvaluateGradRight(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 25 "src/expression/MatrixMultiply.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/MatrixMultiply.birch", 25);
  #line 27 "src/expression/MatrixMultiply.birch"
  libbirch_line_(27);
  #line 27 "src/expression/MatrixMultiply.birch"
  return birch::transpose(y) * d;
}

#line 30 "src/expression/MatrixMultiply.birch"
std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixGaussian>>>> birch::type::MatrixMultiply::graftLinearMatrixGaussian() {
  #line 30 "src/expression/MatrixMultiply.birch"
  libbirch_function_("graftLinearMatrixGaussian", "src/expression/MatrixMultiply.birch", 30);
  #line 31 "src/expression/MatrixMultiply.birch"
  libbirch_line_(31);
  #line 31 "src/expression/MatrixMultiply.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixGaussian>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixGaussian>>>>>();
  #line 32 "src/expression/MatrixMultiply.birch"
  libbirch_line_(32);
  #line 32 "src/expression/MatrixMultiply.birch"
  if (!(this->hasValue())) {
    #line 33 "src/expression/MatrixMultiply.birch"
    libbirch_line_(33);
    #line 33 "src/expression/MatrixMultiply.birch"
    std::optional<libbirch::Shared<birch::type::MatrixGaussian>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::MatrixGaussian>>>();
    #line 35 "src/expression/MatrixMultiply.birch"
    libbirch_line_(35);
    #line 35 "src/expression/MatrixMultiply.birch"
    if ((r = this->z.value()->graftLinearMatrixGaussian()).has_value()) {
      #line 36 "src/expression/MatrixMultiply.birch"
      libbirch_line_(36);
      #line 36 "src/expression/MatrixMultiply.birch"
      r.value()->leftMultiply(this->y.value());
    } else {
      #line 37 "src/expression/MatrixMultiply.birch"
      libbirch_line_(37);
      #line 37 "src/expression/MatrixMultiply.birch"
      if ((x1 = this->z.value()->graftMatrixGaussian()).has_value()) {
        #line 38 "src/expression/MatrixMultiply.birch"
        libbirch_line_(38);
        #line 38 "src/expression/MatrixMultiply.birch"
        r = birch::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixGaussian>>(this->y.value(), x1.value());
      }
    }
  }
  #line 41 "src/expression/MatrixMultiply.birch"
  libbirch_line_(41);
  #line 41 "src/expression/MatrixMultiply.birch"
  return r;
}

#line 44 "src/expression/MatrixMultiply.birch"
std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>> birch::type::MatrixMultiply::graftLinearMatrixNormalInverseWishart(const libbirch::Shared<birch::type::Distribution<birch::type::LLT>>& compare) {
  #line 44 "src/expression/MatrixMultiply.birch"
  libbirch_function_("graftLinearMatrixNormalInverseWishart", "src/expression/MatrixMultiply.birch", 44);
  #line 46 "src/expression/MatrixMultiply.birch"
  libbirch_line_(46);
  #line 46 "src/expression/MatrixMultiply.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>>>();
  #line 47 "src/expression/MatrixMultiply.birch"
  libbirch_line_(47);
  #line 47 "src/expression/MatrixMultiply.birch"
  if (!(this->hasValue())) {
    #line 48 "src/expression/MatrixMultiply.birch"
    libbirch_line_(48);
    #line 48 "src/expression/MatrixMultiply.birch"
    std::optional<libbirch::Shared<birch::type::MatrixNormalInverseWishart>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>();
    #line 50 "src/expression/MatrixMultiply.birch"
    libbirch_line_(50);
    #line 50 "src/expression/MatrixMultiply.birch"
    if ((r = this->z.value()->graftLinearMatrixNormalInverseWishart(compare)).has_value()) {
      #line 51 "src/expression/MatrixMultiply.birch"
      libbirch_line_(51);
      #line 51 "src/expression/MatrixMultiply.birch"
      r.value()->leftMultiply(this->y.value());
    } else {
      #line 52 "src/expression/MatrixMultiply.birch"
      libbirch_line_(52);
      #line 52 "src/expression/MatrixMultiply.birch"
      if ((x1 = this->z.value()->graftMatrixNormalInverseWishart(compare)).has_value()) {
        #line 53 "src/expression/MatrixMultiply.birch"
        libbirch_line_(53);
        #line 53 "src/expression/MatrixMultiply.birch"
        r = birch::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>(this->y.value(), x1.value());
      }
    }
  }
  #line 56 "src/expression/MatrixMultiply.birch"
  libbirch_line_(56);
  #line 56 "src/expression/MatrixMultiply.birch"
  return r;
}

#line 63 "src/expression/MatrixMultiply.birch"
libbirch::Shared<birch::type::MatrixMultiply> birch::operator*(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) {
  #line 63 "src/expression/MatrixMultiply.birch"
  libbirch_function_("*", "src/expression/MatrixMultiply.birch", 63);
  #line 65 "src/expression/MatrixMultiply.birch"
  libbirch_line_(65);
  #line 65 "src/expression/MatrixMultiply.birch"
  return birch::construct<libbirch::Shared<birch::type::MatrixMultiply>>(y, z);
}

#line 71 "src/expression/MatrixMultiply.birch"
libbirch::Shared<birch::type::MatrixMultiply> birch::operator*(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) {
  #line 71 "src/expression/MatrixMultiply.birch"
  libbirch_function_("*", "src/expression/MatrixMultiply.birch", 71);
  #line 72 "src/expression/MatrixMultiply.birch"
  libbirch_line_(72);
  #line 72 "src/expression/MatrixMultiply.birch"
  return birch::box(y) * z;
}

#line 78 "src/expression/MatrixMultiply.birch"
libbirch::Shared<birch::type::MatrixMultiply> birch::operator*(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 78 "src/expression/MatrixMultiply.birch"
  libbirch_function_("*", "src/expression/MatrixMultiply.birch", 78);
  #line 79 "src/expression/MatrixMultiply.birch"
  libbirch_line_(79);
  #line 79 "src/expression/MatrixMultiply.birch"
  return y * birch::box(z);
}

#line 4 "src/expression/MatrixNegate.birch"
birch::type::MatrixNegate::MatrixNegate(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y) :
    #line 4 "src/expression/MatrixNegate.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/MatrixNegate.birch"
birch::type::Integer birch::type::MatrixNegate::doRows() {
  #line 7 "src/expression/MatrixNegate.birch"
  libbirch_function_("doRows", "src/expression/MatrixNegate.birch", 7);
  #line 8 "src/expression/MatrixNegate.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MatrixNegate.birch"
  return this->y.value()->rows();
}

#line 11 "src/expression/MatrixNegate.birch"
birch::type::Integer birch::type::MatrixNegate::doColumns() {
  #line 11 "src/expression/MatrixNegate.birch"
  libbirch_function_("doColumns", "src/expression/MatrixNegate.birch", 11);
  #line 12 "src/expression/MatrixNegate.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MatrixNegate.birch"
  return this->y.value()->columns();
}

#line 15 "src/expression/MatrixNegate.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixNegate::doEvaluate(const libbirch::DefaultArray<birch::type::Real,2>& y) {
  #line 15 "src/expression/MatrixNegate.birch"
  libbirch_function_("doEvaluate", "src/expression/MatrixNegate.birch", 15);
  #line 16 "src/expression/MatrixNegate.birch"
  libbirch_line_(16);
  #line 16 "src/expression/MatrixNegate.birch"
  return -(y);
}

#line 19 "src/expression/MatrixNegate.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixNegate::doEvaluateGrad(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y) {
  #line 19 "src/expression/MatrixNegate.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/MatrixNegate.birch", 19);
  #line 21 "src/expression/MatrixNegate.birch"
  libbirch_line_(21);
  #line 21 "src/expression/MatrixNegate.birch"
  return -(d);
}

#line 24 "src/expression/MatrixNegate.birch"
std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixGaussian>>>> birch::type::MatrixNegate::graftLinearMatrixGaussian() {
  #line 24 "src/expression/MatrixNegate.birch"
  libbirch_function_("graftLinearMatrixGaussian", "src/expression/MatrixNegate.birch", 24);
  #line 26 "src/expression/MatrixNegate.birch"
  libbirch_line_(26);
  #line 26 "src/expression/MatrixNegate.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixGaussian>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixGaussian>>>>>();
  #line 27 "src/expression/MatrixNegate.birch"
  libbirch_line_(27);
  #line 27 "src/expression/MatrixNegate.birch"
  if (!(this->hasValue())) {
    #line 28 "src/expression/MatrixNegate.birch"
    libbirch_line_(28);
    #line 28 "src/expression/MatrixNegate.birch"
    std::optional<libbirch::Shared<birch::type::MatrixGaussian>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::MatrixGaussian>>>();
    #line 30 "src/expression/MatrixNegate.birch"
    libbirch_line_(30);
    #line 30 "src/expression/MatrixNegate.birch"
    if ((r = this->y.value()->graftLinearMatrixGaussian()).has_value()) {
      #line 31 "src/expression/MatrixNegate.birch"
      libbirch_line_(31);
      #line 31 "src/expression/MatrixNegate.birch"
      r.value()->negate();
    } else {
      #line 32 "src/expression/MatrixNegate.birch"
      libbirch_line_(32);
      #line 32 "src/expression/MatrixNegate.birch"
      if ((x1 = this->y.value()->graftMatrixGaussian()).has_value()) {
        #line 33 "src/expression/MatrixNegate.birch"
        libbirch_line_(33);
        #line 33 "src/expression/MatrixNegate.birch"
        auto R = x1.value()->rows();
        #line 34 "src/expression/MatrixNegate.birch"
        libbirch_line_(34);
        #line 34 "src/expression/MatrixNegate.birch"
        auto C = x1.value()->columns();
        #line 35 "src/expression/MatrixNegate.birch"
        libbirch_line_(35);
        #line 35 "src/expression/MatrixNegate.birch"
        r = birch::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixGaussian>>(birch::diagonal(birch::box(-(1.0)), R), x1.value(), birch::box(birch::matrix(0.0, R, C)));
      }
    }
  }
  #line 39 "src/expression/MatrixNegate.birch"
  libbirch_line_(39);
  #line 39 "src/expression/MatrixNegate.birch"
  return r;
}

#line 42 "src/expression/MatrixNegate.birch"
std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>> birch::type::MatrixNegate::graftLinearMatrixNormalInverseWishart(const libbirch::Shared<birch::type::Distribution<birch::type::LLT>>& compare) {
  #line 42 "src/expression/MatrixNegate.birch"
  libbirch_function_("graftLinearMatrixNormalInverseWishart", "src/expression/MatrixNegate.birch", 42);
  #line 44 "src/expression/MatrixNegate.birch"
  libbirch_line_(44);
  #line 44 "src/expression/MatrixNegate.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>>>();
  #line 45 "src/expression/MatrixNegate.birch"
  libbirch_line_(45);
  #line 45 "src/expression/MatrixNegate.birch"
  std::optional<libbirch::Shared<birch::type::MatrixNormalInverseWishart>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>();
  #line 47 "src/expression/MatrixNegate.birch"
  libbirch_line_(47);
  #line 47 "src/expression/MatrixNegate.birch"
  if ((r = this->y.value()->graftLinearMatrixNormalInverseWishart(compare)).has_value()) {
    #line 48 "src/expression/MatrixNegate.birch"
    libbirch_line_(48);
    #line 48 "src/expression/MatrixNegate.birch"
    r.value()->negate();
  } else {
    #line 49 "src/expression/MatrixNegate.birch"
    libbirch_line_(49);
    #line 49 "src/expression/MatrixNegate.birch"
    if ((x1 = this->y.value()->graftMatrixNormalInverseWishart(compare)).has_value()) {
      #line 50 "src/expression/MatrixNegate.birch"
      libbirch_line_(50);
      #line 50 "src/expression/MatrixNegate.birch"
      auto R = x1.value()->rows();
      #line 51 "src/expression/MatrixNegate.birch"
      libbirch_line_(51);
      #line 51 "src/expression/MatrixNegate.birch"
      auto C = x1.value()->columns();
      #line 52 "src/expression/MatrixNegate.birch"
      libbirch_line_(52);
      #line 52 "src/expression/MatrixNegate.birch"
      r = birch::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>(birch::diagonal(birch::box(-(1.0)), R), x1.value(), birch::box(birch::matrix(0.0, R, C)));
    }
  }
  #line 55 "src/expression/MatrixNegate.birch"
  libbirch_line_(55);
  #line 55 "src/expression/MatrixNegate.birch"
  return r;
}

#line 62 "src/expression/MatrixNegate.birch"
libbirch::Shared<birch::type::MatrixNegate> birch::operator-(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y) {
  #line 62 "src/expression/MatrixNegate.birch"
  libbirch_function_("-", "src/expression/MatrixNegate.birch", 62);
  #line 63 "src/expression/MatrixNegate.birch"
  libbirch_line_(63);
  #line 63 "src/expression/MatrixNegate.birch"
  return birch::construct<libbirch::Shared<birch::type::MatrixNegate>>(y);
}

#line 4 "src/expression/MatrixPack.birch"
birch::type::MatrixPack::MatrixPack(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) :
    #line 4 "src/expression/MatrixPack.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/MatrixPack.birch"
birch::type::Integer birch::type::MatrixPack::doRows() {
  #line 7 "src/expression/MatrixPack.birch"
  libbirch_function_("doRows", "src/expression/MatrixPack.birch", 7);
  #line 8 "src/expression/MatrixPack.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MatrixPack.birch"
  return this->y.value()->rows();
}

#line 11 "src/expression/MatrixPack.birch"
birch::type::Integer birch::type::MatrixPack::doColumns() {
  #line 11 "src/expression/MatrixPack.birch"
  libbirch_function_("doColumns", "src/expression/MatrixPack.birch", 11);
  #line 12 "src/expression/MatrixPack.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MatrixPack.birch"
  return this->y.value()->columns() + this->z.value()->columns();
}

#line 15 "src/expression/MatrixPack.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixPack::doEvaluate(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 15 "src/expression/MatrixPack.birch"
  libbirch_function_("doEvaluate", "src/expression/MatrixPack.birch", 15);
  #line 16 "src/expression/MatrixPack.birch"
  libbirch_line_(16);
  #line 16 "src/expression/MatrixPack.birch"
  return birch::pack(y, z);
}

#line 19 "src/expression/MatrixPack.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixPack::doEvaluateGradLeft(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 19 "src/expression/MatrixPack.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/MatrixPack.birch", 19);
  #line 21 "src/expression/MatrixPack.birch"
  libbirch_line_(21);
  #line 21 "src/expression/MatrixPack.birch"
  return d(libbirch::make_range(birch::type::Integer(1), birch::rows(y)), libbirch::make_range(birch::type::Integer(1), birch::columns(y)));
}

#line 24 "src/expression/MatrixPack.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixPack::doEvaluateGradRight(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 24 "src/expression/MatrixPack.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/MatrixPack.birch", 24);
  #line 26 "src/expression/MatrixPack.birch"
  libbirch_line_(26);
  #line 26 "src/expression/MatrixPack.birch"
  return d(libbirch::make_range(birch::type::Integer(1), birch::rows(y)), libbirch::make_range((birch::columns(y) + birch::type::Integer(1)), birch::columns(x)));
}

#line 33 "src/expression/MatrixPack.birch"
libbirch::Shared<birch::type::MatrixPack> birch::pack(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) {
  #line 33 "src/expression/MatrixPack.birch"
  libbirch_function_("pack", "src/expression/MatrixPack.birch", 33);
  #line 35 "src/expression/MatrixPack.birch"
  libbirch_line_(35);
  #line 35 "src/expression/MatrixPack.birch"
  return birch::construct<libbirch::Shared<birch::type::MatrixPack>>(y, z);
}

#line 41 "src/expression/MatrixPack.birch"
libbirch::Shared<birch::type::MatrixPack> birch::pack(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) {
  #line 41 "src/expression/MatrixPack.birch"
  libbirch_function_("pack", "src/expression/MatrixPack.birch", 41);
  #line 42 "src/expression/MatrixPack.birch"
  libbirch_line_(42);
  #line 42 "src/expression/MatrixPack.birch"
  return birch::pack(birch::box(y), z);
}

#line 48 "src/expression/MatrixPack.birch"
libbirch::Shared<birch::type::MatrixPack> birch::pack(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 48 "src/expression/MatrixPack.birch"
  libbirch_function_("pack", "src/expression/MatrixPack.birch", 48);
  #line 49 "src/expression/MatrixPack.birch"
  libbirch_line_(49);
  #line 49 "src/expression/MatrixPack.birch"
  return birch::pack(y, birch::box(z));
}

#line 33 "src/expression/MatrixRankDowndate.birch"
libbirch::Shared<birch::type::MatrixRankDowndate<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>, libbirch::DefaultArray<birch::type::Real,1>, libbirch::DefaultArray<birch::type::Real,1>>> birch::rank_downdate(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) {
  #line 33 "src/expression/MatrixRankDowndate.birch"
  libbirch_function_("rank_downdate", "src/expression/MatrixRankDowndate.birch", 33);
  #line 35 "src/expression/MatrixRankDowndate.birch"
  libbirch_line_(35);
  #line 35 "src/expression/MatrixRankDowndate.birch"
  libbirch_assert_(y->columns() == z->rows());
  #line 36 "src/expression/MatrixRankDowndate.birch"
  libbirch_line_(36);
  #line 36 "src/expression/MatrixRankDowndate.birch"
  return birch::construct<libbirch::Shared<birch::type::MatrixRankDowndate<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>, libbirch::DefaultArray<birch::type::Real,1>, libbirch::DefaultArray<birch::type::Real,1>>>>(y, z);
}

#line 42 "src/expression/MatrixRankDowndate.birch"
libbirch::Shared<birch::type::MatrixRankDowndate<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>, libbirch::DefaultArray<birch::type::Real,1>, libbirch::DefaultArray<birch::type::Real,1>>> birch::rank_downdate(const birch::type::LLT& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) {
  #line 42 "src/expression/MatrixRankDowndate.birch"
  libbirch_function_("rank_downdate", "src/expression/MatrixRankDowndate.birch", 42);
  #line 44 "src/expression/MatrixRankDowndate.birch"
  libbirch_line_(44);
  #line 44 "src/expression/MatrixRankDowndate.birch"
  return birch::rank_downdate(birch::box(y), z);
}

#line 50 "src/expression/MatrixRankDowndate.birch"
libbirch::Shared<birch::type::MatrixRankDowndate<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>, libbirch::DefaultArray<birch::type::Real,1>, libbirch::DefaultArray<birch::type::Real,1>>> birch::rank_downdate(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 50 "src/expression/MatrixRankDowndate.birch"
  libbirch_function_("rank_downdate", "src/expression/MatrixRankDowndate.birch", 50);
  #line 52 "src/expression/MatrixRankDowndate.birch"
  libbirch_line_(52);
  #line 52 "src/expression/MatrixRankDowndate.birch"
  return birch::rank_downdate(y, birch::box(z));
}

#line 58 "src/expression/MatrixRankDowndate.birch"
libbirch::Shared<birch::type::MatrixRankDowndate<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::DefaultArray<birch::type::Real,2>, libbirch::DefaultArray<birch::type::Real,2>>> birch::rank_downdate(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) {
  #line 58 "src/expression/MatrixRankDowndate.birch"
  libbirch_function_("rank_downdate", "src/expression/MatrixRankDowndate.birch", 58);
  #line 60 "src/expression/MatrixRankDowndate.birch"
  libbirch_line_(60);
  #line 60 "src/expression/MatrixRankDowndate.birch"
  libbirch_assert_(y->columns() == z->rows());
  #line 61 "src/expression/MatrixRankDowndate.birch"
  libbirch_line_(61);
  #line 61 "src/expression/MatrixRankDowndate.birch"
  return birch::construct<libbirch::Shared<birch::type::MatrixRankDowndate<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::DefaultArray<birch::type::Real,2>, libbirch::DefaultArray<birch::type::Real,2>>>>(y, z);
}

#line 67 "src/expression/MatrixRankDowndate.birch"
libbirch::Shared<birch::type::MatrixRankDowndate<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::DefaultArray<birch::type::Real,2>, libbirch::DefaultArray<birch::type::Real,2>>> birch::rank_downdate(const birch::type::LLT& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) {
  #line 67 "src/expression/MatrixRankDowndate.birch"
  libbirch_function_("rank_downdate", "src/expression/MatrixRankDowndate.birch", 67);
  #line 69 "src/expression/MatrixRankDowndate.birch"
  libbirch_line_(69);
  #line 69 "src/expression/MatrixRankDowndate.birch"
  return birch::rank_downdate(birch::box(y), z);
}

#line 75 "src/expression/MatrixRankDowndate.birch"
libbirch::Shared<birch::type::MatrixRankDowndate<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::DefaultArray<birch::type::Real,2>, libbirch::DefaultArray<birch::type::Real,2>>> birch::rank_downdate(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 75 "src/expression/MatrixRankDowndate.birch"
  libbirch_function_("rank_downdate", "src/expression/MatrixRankDowndate.birch", 75);
  #line 77 "src/expression/MatrixRankDowndate.birch"
  libbirch_line_(77);
  #line 77 "src/expression/MatrixRankDowndate.birch"
  return birch::rank_downdate(y, birch::box(z));
}

#line 33 "src/expression/MatrixRankUpdate.birch"
libbirch::Shared<birch::type::MatrixRankUpdate<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>, libbirch::DefaultArray<birch::type::Real,1>, libbirch::DefaultArray<birch::type::Real,1>>> birch::rank_update(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) {
  #line 33 "src/expression/MatrixRankUpdate.birch"
  libbirch_function_("rank_update", "src/expression/MatrixRankUpdate.birch", 33);
  #line 35 "src/expression/MatrixRankUpdate.birch"
  libbirch_line_(35);
  #line 35 "src/expression/MatrixRankUpdate.birch"
  libbirch_assert_(y->columns() == z->rows());
  #line 36 "src/expression/MatrixRankUpdate.birch"
  libbirch_line_(36);
  #line 36 "src/expression/MatrixRankUpdate.birch"
  return birch::construct<libbirch::Shared<birch::type::MatrixRankUpdate<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>, libbirch::DefaultArray<birch::type::Real,1>, libbirch::DefaultArray<birch::type::Real,1>>>>(y, z);
}

#line 42 "src/expression/MatrixRankUpdate.birch"
libbirch::Shared<birch::type::MatrixRankUpdate<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>, libbirch::DefaultArray<birch::type::Real,1>, libbirch::DefaultArray<birch::type::Real,1>>> birch::rank_update(const birch::type::LLT& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) {
  #line 42 "src/expression/MatrixRankUpdate.birch"
  libbirch_function_("rank_update", "src/expression/MatrixRankUpdate.birch", 42);
  #line 44 "src/expression/MatrixRankUpdate.birch"
  libbirch_line_(44);
  #line 44 "src/expression/MatrixRankUpdate.birch"
  return birch::rank_update(birch::box(y), z);
}

#line 50 "src/expression/MatrixRankUpdate.birch"
libbirch::Shared<birch::type::MatrixRankUpdate<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>, libbirch::DefaultArray<birch::type::Real,1>, libbirch::DefaultArray<birch::type::Real,1>>> birch::rank_update(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 50 "src/expression/MatrixRankUpdate.birch"
  libbirch_function_("rank_update", "src/expression/MatrixRankUpdate.birch", 50);
  #line 52 "src/expression/MatrixRankUpdate.birch"
  libbirch_line_(52);
  #line 52 "src/expression/MatrixRankUpdate.birch"
  return birch::rank_update(y, birch::box(z));
}

#line 58 "src/expression/MatrixRankUpdate.birch"
libbirch::Shared<birch::type::MatrixRankUpdate<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::DefaultArray<birch::type::Real,2>, libbirch::DefaultArray<birch::type::Real,2>>> birch::rank_update(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) {
  #line 58 "src/expression/MatrixRankUpdate.birch"
  libbirch_function_("rank_update", "src/expression/MatrixRankUpdate.birch", 58);
  #line 60 "src/expression/MatrixRankUpdate.birch"
  libbirch_line_(60);
  #line 60 "src/expression/MatrixRankUpdate.birch"
  libbirch_assert_(y->columns() == z->rows());
  #line 61 "src/expression/MatrixRankUpdate.birch"
  libbirch_line_(61);
  #line 61 "src/expression/MatrixRankUpdate.birch"
  return birch::construct<libbirch::Shared<birch::type::MatrixRankUpdate<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::DefaultArray<birch::type::Real,2>, libbirch::DefaultArray<birch::type::Real,2>>>>(y, z);
}

#line 68 "src/expression/MatrixRankUpdate.birch"
libbirch::Shared<birch::type::MatrixRankUpdate<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::DefaultArray<birch::type::Real,2>, libbirch::DefaultArray<birch::type::Real,2>>> birch::rank_update(const birch::type::LLT& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) {
  #line 68 "src/expression/MatrixRankUpdate.birch"
  libbirch_function_("rank_update", "src/expression/MatrixRankUpdate.birch", 68);
  #line 70 "src/expression/MatrixRankUpdate.birch"
  libbirch_line_(70);
  #line 70 "src/expression/MatrixRankUpdate.birch"
  return birch::rank_update(birch::box(y), z);
}

#line 76 "src/expression/MatrixRankUpdate.birch"
libbirch::Shared<birch::type::MatrixRankUpdate<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::DefaultArray<birch::type::Real,2>, libbirch::DefaultArray<birch::type::Real,2>>> birch::rank_update(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 76 "src/expression/MatrixRankUpdate.birch"
  libbirch_function_("rank_update", "src/expression/MatrixRankUpdate.birch", 76);
  #line 78 "src/expression/MatrixRankUpdate.birch"
  libbirch_line_(78);
  #line 78 "src/expression/MatrixRankUpdate.birch"
  return birch::rank_update(y, birch::box(z));
}

#line 4 "src/expression/MatrixRectify.birch"
birch::type::MatrixRectify::MatrixRectify(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y) :
    #line 4 "src/expression/MatrixRectify.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/MatrixRectify.birch"
birch::type::Integer birch::type::MatrixRectify::doRows() {
  #line 7 "src/expression/MatrixRectify.birch"
  libbirch_function_("doRows", "src/expression/MatrixRectify.birch", 7);
  #line 8 "src/expression/MatrixRectify.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MatrixRectify.birch"
  return this->y.value()->rows();
}

#line 11 "src/expression/MatrixRectify.birch"
birch::type::Integer birch::type::MatrixRectify::doColumns() {
  #line 11 "src/expression/MatrixRectify.birch"
  libbirch_function_("doColumns", "src/expression/MatrixRectify.birch", 11);
  #line 12 "src/expression/MatrixRectify.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MatrixRectify.birch"
  return this->y.value()->columns();
}

#line 15 "src/expression/MatrixRectify.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixRectify::doEvaluate(const libbirch::DefaultArray<birch::type::Real,2>& y) {
  #line 15 "src/expression/MatrixRectify.birch"
  libbirch_function_("doEvaluate", "src/expression/MatrixRectify.birch", 15);
  #line 16 "src/expression/MatrixRectify.birch"
  libbirch_line_(16);
  #line 16 "src/expression/MatrixRectify.birch"
  return birch::transform(y, std::function<birch::type::Real(birch::type::Real)>([=](const birch::type::Real& y) {
    #line 16 "src/expression/MatrixRectify.birch"
    libbirch_line_(16);
    #line 16 "src/expression/MatrixRectify.birch"
    return birch::rectify(y);
  }));
}

#line 19 "src/expression/MatrixRectify.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixRectify::doEvaluateGrad(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y) {
  #line 19 "src/expression/MatrixRectify.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/MatrixRectify.birch", 19);
  #line 21 "src/expression/MatrixRectify.birch"
  libbirch_line_(21);
  #line 21 "src/expression/MatrixRectify.birch"
  return birch::transform(d, x, std::function<birch::type::Real(birch::type::Real,birch::type::Real)>([=](const birch::type::Real& d, const birch::type::Real& x) {
    #line 22 "src/expression/MatrixRectify.birch"
    libbirch_line_(22);
    #line 22 "src/expression/MatrixRectify.birch"
    if (x > 0.0) {
      #line 23 "src/expression/MatrixRectify.birch"
      libbirch_line_(23);
      #line 23 "src/expression/MatrixRectify.birch"
      return d;
    } else {
      #line 25 "src/expression/MatrixRectify.birch"
      libbirch_line_(25);
      #line 25 "src/expression/MatrixRectify.birch"
      return 0.0;
    }
  }));
}

#line 34 "src/expression/MatrixRectify.birch"
libbirch::Shared<birch::type::MatrixRectify> birch::rectify(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y) {
  #line 34 "src/expression/MatrixRectify.birch"
  libbirch_function_("rectify", "src/expression/MatrixRectify.birch", 34);
  #line 35 "src/expression/MatrixRectify.birch"
  libbirch_line_(35);
  #line 35 "src/expression/MatrixRectify.birch"
  return birch::construct<libbirch::Shared<birch::type::MatrixRectify>>(y);
}

#line 4 "src/expression/MatrixScalarDivide.birch"
libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>> birch::operator/(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 4 "src/expression/MatrixScalarDivide.birch"
  libbirch_function_("/", "src/expression/MatrixScalarDivide.birch", 4);
  #line 6 "src/expression/MatrixScalarDivide.birch"
  libbirch_line_(6);
  #line 6 "src/expression/MatrixScalarDivide.birch"
  return (1.0 / z) * y;
}

#line 12 "src/expression/MatrixScalarDivide.birch"
libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>> birch::operator/(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 12 "src/expression/MatrixScalarDivide.birch"
  libbirch_function_("/", "src/expression/MatrixScalarDivide.birch", 12);
  #line 13 "src/expression/MatrixScalarDivide.birch"
  libbirch_line_(13);
  #line 13 "src/expression/MatrixScalarDivide.birch"
  return (1.0 / z) * birch::box(y);
}

#line 19 "src/expression/MatrixScalarDivide.birch"
libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>> birch::operator/(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const birch::type::Real& z) {
  #line 19 "src/expression/MatrixScalarDivide.birch"
  libbirch_function_("/", "src/expression/MatrixScalarDivide.birch", 19);
  #line 20 "src/expression/MatrixScalarDivide.birch"
  libbirch_line_(20);
  #line 20 "src/expression/MatrixScalarDivide.birch"
  return birch::box(1.0 / z) * y;
}

#line 4 "src/expression/MatrixScalarMultiply.birch"
birch::type::MatrixScalarMultiply::MatrixScalarMultiply(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) :
    #line 4 "src/expression/MatrixScalarMultiply.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/MatrixScalarMultiply.birch"
birch::type::Integer birch::type::MatrixScalarMultiply::doRows() {
  #line 7 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("doRows", "src/expression/MatrixScalarMultiply.birch", 7);
  #line 8 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MatrixScalarMultiply.birch"
  return this->z.value()->rows();
}

#line 11 "src/expression/MatrixScalarMultiply.birch"
birch::type::Integer birch::type::MatrixScalarMultiply::doColumns() {
  #line 11 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("doColumns", "src/expression/MatrixScalarMultiply.birch", 11);
  #line 12 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MatrixScalarMultiply.birch"
  return this->z.value()->columns();
}

#line 15 "src/expression/MatrixScalarMultiply.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixScalarMultiply::doEvaluate(const birch::type::Real& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 15 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("doEvaluate", "src/expression/MatrixScalarMultiply.birch", 15);
  #line 16 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(16);
  #line 16 "src/expression/MatrixScalarMultiply.birch"
  return y * z;
}

#line 19 "src/expression/MatrixScalarMultiply.birch"
birch::type::Real birch::type::MatrixScalarMultiply::doEvaluateGradLeft(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const birch::type::Real& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 19 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/MatrixScalarMultiply.birch", 19);
  #line 21 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(21);
  #line 21 "src/expression/MatrixScalarMultiply.birch"
  return birch::trace(d * birch::transpose(z));
}

#line 24 "src/expression/MatrixScalarMultiply.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixScalarMultiply::doEvaluateGradRight(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const birch::type::Real& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 24 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/MatrixScalarMultiply.birch", 24);
  #line 26 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(26);
  #line 26 "src/expression/MatrixScalarMultiply.birch"
  return y * d;
}

#line 29 "src/expression/MatrixScalarMultiply.birch"
std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixGaussian>>>> birch::type::MatrixScalarMultiply::graftLinearMatrixGaussian() {
  #line 29 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("graftLinearMatrixGaussian", "src/expression/MatrixScalarMultiply.birch", 29);
  #line 30 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(30);
  #line 30 "src/expression/MatrixScalarMultiply.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixGaussian>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixGaussian>>>>>();
  #line 31 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(31);
  #line 31 "src/expression/MatrixScalarMultiply.birch"
  if (!(this->hasValue())) {
    #line 32 "src/expression/MatrixScalarMultiply.birch"
    libbirch_line_(32);
    #line 32 "src/expression/MatrixScalarMultiply.birch"
    std::optional<libbirch::Shared<birch::type::MatrixGaussian>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::MatrixGaussian>>>();
    #line 34 "src/expression/MatrixScalarMultiply.birch"
    libbirch_line_(34);
    #line 34 "src/expression/MatrixScalarMultiply.birch"
    if ((r = this->z.value()->graftLinearMatrixGaussian()).has_value()) {
      #line 35 "src/expression/MatrixScalarMultiply.birch"
      libbirch_line_(35);
      #line 35 "src/expression/MatrixScalarMultiply.birch"
      r.value()->multiply(this->y.value());
    } else {
      #line 36 "src/expression/MatrixScalarMultiply.birch"
      libbirch_line_(36);
      #line 36 "src/expression/MatrixScalarMultiply.birch"
      if ((x1 = this->z.value()->graftMatrixGaussian()).has_value()) {
        #line 37 "src/expression/MatrixScalarMultiply.birch"
        libbirch_line_(37);
        #line 37 "src/expression/MatrixScalarMultiply.birch"
        r = birch::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixGaussian>>(birch::diagonal(this->y.value(), this->z.value()->rows()), x1.value());
      }
    }
  }
  #line 40 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(40);
  #line 40 "src/expression/MatrixScalarMultiply.birch"
  return r;
}

#line 43 "src/expression/MatrixScalarMultiply.birch"
std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>> birch::type::MatrixScalarMultiply::graftLinearMatrixNormalInverseWishart(const libbirch::Shared<birch::type::Distribution<birch::type::LLT>>& compare) {
  #line 43 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("graftLinearMatrixNormalInverseWishart", "src/expression/MatrixScalarMultiply.birch", 43);
  #line 45 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(45);
  #line 45 "src/expression/MatrixScalarMultiply.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>>>();
  #line 46 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(46);
  #line 46 "src/expression/MatrixScalarMultiply.birch"
  if (!(this->hasValue())) {
    #line 47 "src/expression/MatrixScalarMultiply.birch"
    libbirch_line_(47);
    #line 47 "src/expression/MatrixScalarMultiply.birch"
    std::optional<libbirch::Shared<birch::type::MatrixNormalInverseWishart>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>();
    #line 49 "src/expression/MatrixScalarMultiply.birch"
    libbirch_line_(49);
    #line 49 "src/expression/MatrixScalarMultiply.birch"
    if ((r = this->z.value()->graftLinearMatrixNormalInverseWishart(compare)).has_value()) {
      #line 50 "src/expression/MatrixScalarMultiply.birch"
      libbirch_line_(50);
      #line 50 "src/expression/MatrixScalarMultiply.birch"
      r.value()->multiply(this->y.value());
    } else {
      #line 51 "src/expression/MatrixScalarMultiply.birch"
      libbirch_line_(51);
      #line 51 "src/expression/MatrixScalarMultiply.birch"
      if ((x1 = this->z.value()->graftMatrixNormalInverseWishart(compare)).has_value()) {
        #line 52 "src/expression/MatrixScalarMultiply.birch"
        libbirch_line_(52);
        #line 52 "src/expression/MatrixScalarMultiply.birch"
        r = birch::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>(birch::diagonal(this->y.value(), this->z.value()->rows()), x1.value());
      }
    }
  }
  #line 55 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(55);
  #line 55 "src/expression/MatrixScalarMultiply.birch"
  return r;
}

#line 62 "src/expression/MatrixScalarMultiply.birch"
libbirch::Shared<birch::type::MatrixScalarMultiply> birch::operator*(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) {
  #line 62 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("*", "src/expression/MatrixScalarMultiply.birch", 62);
  #line 64 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(64);
  #line 64 "src/expression/MatrixScalarMultiply.birch"
  return birch::construct<libbirch::Shared<birch::type::MatrixScalarMultiply>>(y, z);
}

#line 70 "src/expression/MatrixScalarMultiply.birch"
libbirch::Shared<birch::type::MatrixScalarMultiply> birch::operator*(const birch::type::Real& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) {
  #line 70 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("*", "src/expression/MatrixScalarMultiply.birch", 70);
  #line 71 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(71);
  #line 71 "src/expression/MatrixScalarMultiply.birch"
  return birch::box(y) * z;
}

#line 77 "src/expression/MatrixScalarMultiply.birch"
libbirch::Shared<birch::type::MatrixScalarMultiply> birch::operator*(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 77 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("*", "src/expression/MatrixScalarMultiply.birch", 77);
  #line 78 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(78);
  #line 78 "src/expression/MatrixScalarMultiply.birch"
  return y * birch::box(z);
}

#line 84 "src/expression/MatrixScalarMultiply.birch"
libbirch::Shared<birch::type::MatrixScalarMultiply> birch::operator*(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 84 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("*", "src/expression/MatrixScalarMultiply.birch", 84);
  #line 85 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(85);
  #line 85 "src/expression/MatrixScalarMultiply.birch"
  return z * y;
}

#line 91 "src/expression/MatrixScalarMultiply.birch"
libbirch::Shared<birch::type::MatrixScalarMultiply> birch::operator*(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 91 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("*", "src/expression/MatrixScalarMultiply.birch", 91);
  #line 92 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(92);
  #line 92 "src/expression/MatrixScalarMultiply.birch"
  return z * y;
}

#line 98 "src/expression/MatrixScalarMultiply.birch"
libbirch::Shared<birch::type::MatrixScalarMultiply> birch::operator*(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const birch::type::Real& z) {
  #line 98 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("*", "src/expression/MatrixScalarMultiply.birch", 98);
  #line 99 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(99);
  #line 99 "src/expression/MatrixScalarMultiply.birch"
  return z * y;
}

#line 33 "src/expression/MatrixSolve.birch"
libbirch::Shared<birch::type::MatrixSolve<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::DefaultArray<birch::type::Real,2>>> birch::solve(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) {
  #line 33 "src/expression/MatrixSolve.birch"
  libbirch_function_("solve", "src/expression/MatrixSolve.birch", 33);
  #line 35 "src/expression/MatrixSolve.birch"
  libbirch_line_(35);
  #line 35 "src/expression/MatrixSolve.birch"
  libbirch_assert_(y->columns() == z->rows());
  #line 36 "src/expression/MatrixSolve.birch"
  libbirch_line_(36);
  #line 36 "src/expression/MatrixSolve.birch"
  return birch::construct<libbirch::Shared<birch::type::MatrixSolve<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::DefaultArray<birch::type::Real,2>>>>(y, z);
}

#line 42 "src/expression/MatrixSolve.birch"
libbirch::Shared<birch::type::MatrixSolve<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::DefaultArray<birch::type::Real,2>>> birch::solve(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) {
  #line 42 "src/expression/MatrixSolve.birch"
  libbirch_function_("solve", "src/expression/MatrixSolve.birch", 42);
  #line 44 "src/expression/MatrixSolve.birch"
  libbirch_line_(44);
  #line 44 "src/expression/MatrixSolve.birch"
  return birch::solve(birch::box(y), z);
}

#line 50 "src/expression/MatrixSolve.birch"
libbirch::Shared<birch::type::MatrixSolve<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::DefaultArray<birch::type::Real,2>>> birch::solve(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 50 "src/expression/MatrixSolve.birch"
  libbirch_function_("solve", "src/expression/MatrixSolve.birch", 50);
  #line 52 "src/expression/MatrixSolve.birch"
  libbirch_line_(52);
  #line 52 "src/expression/MatrixSolve.birch"
  return birch::solve(y, birch::box(z));
}

#line 58 "src/expression/MatrixSolve.birch"
libbirch::Shared<birch::type::MatrixSolve<libbirch::Shared<birch::type::Expression<birch::type::LLT>>, birch::type::LLT>> birch::solve(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) {
  #line 58 "src/expression/MatrixSolve.birch"
  libbirch_function_("solve", "src/expression/MatrixSolve.birch", 58);
  #line 60 "src/expression/MatrixSolve.birch"
  libbirch_line_(60);
  #line 60 "src/expression/MatrixSolve.birch"
  libbirch_assert_(y->columns() == z->rows());
  #line 61 "src/expression/MatrixSolve.birch"
  libbirch_line_(61);
  #line 61 "src/expression/MatrixSolve.birch"
  return birch::construct<libbirch::Shared<birch::type::MatrixSolve<libbirch::Shared<birch::type::Expression<birch::type::LLT>>, birch::type::LLT>>>(y, z);
}

#line 67 "src/expression/MatrixSolve.birch"
libbirch::Shared<birch::type::MatrixSolve<libbirch::Shared<birch::type::Expression<birch::type::LLT>>, birch::type::LLT>> birch::solve(const birch::type::LLT& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) {
  #line 67 "src/expression/MatrixSolve.birch"
  libbirch_function_("solve", "src/expression/MatrixSolve.birch", 67);
  #line 69 "src/expression/MatrixSolve.birch"
  libbirch_line_(69);
  #line 69 "src/expression/MatrixSolve.birch"
  return birch::solve(birch::box(y), z);
}

#line 75 "src/expression/MatrixSolve.birch"
libbirch::Shared<birch::type::MatrixSolve<libbirch::Shared<birch::type::Expression<birch::type::LLT>>, birch::type::LLT>> birch::solve(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 75 "src/expression/MatrixSolve.birch"
  libbirch_function_("solve", "src/expression/MatrixSolve.birch", 75);
  #line 77 "src/expression/MatrixSolve.birch"
  libbirch_line_(77);
  #line 77 "src/expression/MatrixSolve.birch"
  return birch::solve(y, birch::box(z));
}

#line 4 "src/expression/MatrixStack.birch"
birch::type::MatrixStack::MatrixStack(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) :
    #line 4 "src/expression/MatrixStack.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/MatrixStack.birch"
birch::type::Integer birch::type::MatrixStack::doRows() {
  #line 7 "src/expression/MatrixStack.birch"
  libbirch_function_("doRows", "src/expression/MatrixStack.birch", 7);
  #line 8 "src/expression/MatrixStack.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MatrixStack.birch"
  return this->y.value()->rows() + this->z.value()->rows();
}

#line 11 "src/expression/MatrixStack.birch"
birch::type::Integer birch::type::MatrixStack::doColumns() {
  #line 11 "src/expression/MatrixStack.birch"
  libbirch_function_("doColumns", "src/expression/MatrixStack.birch", 11);
  #line 12 "src/expression/MatrixStack.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MatrixStack.birch"
  libbirch_assert_(this->y.value()->columns() == this->z.value()->columns());
  #line 13 "src/expression/MatrixStack.birch"
  libbirch_line_(13);
  #line 13 "src/expression/MatrixStack.birch"
  return this->y.value()->columns();
}

#line 16 "src/expression/MatrixStack.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixStack::doEvaluate(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 16 "src/expression/MatrixStack.birch"
  libbirch_function_("doEvaluate", "src/expression/MatrixStack.birch", 16);
  #line 17 "src/expression/MatrixStack.birch"
  libbirch_line_(17);
  #line 17 "src/expression/MatrixStack.birch"
  return birch::stack(y, z);
}

#line 20 "src/expression/MatrixStack.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixStack::doEvaluateGradLeft(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 20 "src/expression/MatrixStack.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/MatrixStack.birch", 20);
  #line 22 "src/expression/MatrixStack.birch"
  libbirch_line_(22);
  #line 22 "src/expression/MatrixStack.birch"
  return d(libbirch::make_range(birch::type::Integer(1), birch::rows(y)), libbirch::make_range(birch::type::Integer(1), birch::columns(y)));
}

#line 25 "src/expression/MatrixStack.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixStack::doEvaluateGradRight(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 25 "src/expression/MatrixStack.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/MatrixStack.birch", 25);
  #line 27 "src/expression/MatrixStack.birch"
  libbirch_line_(27);
  #line 27 "src/expression/MatrixStack.birch"
  return d(libbirch::make_range((birch::rows(y) + birch::type::Integer(1)), birch::rows(x)), libbirch::make_range(birch::type::Integer(1), birch::columns(z)));
}

#line 34 "src/expression/MatrixStack.birch"
libbirch::Shared<birch::type::MatrixStack> birch::stack(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) {
  #line 34 "src/expression/MatrixStack.birch"
  libbirch_function_("stack", "src/expression/MatrixStack.birch", 34);
  #line 36 "src/expression/MatrixStack.birch"
  libbirch_line_(36);
  #line 36 "src/expression/MatrixStack.birch"
  libbirch_assert_(y->columns() == z->columns());
  #line 37 "src/expression/MatrixStack.birch"
  libbirch_line_(37);
  #line 37 "src/expression/MatrixStack.birch"
  return birch::construct<libbirch::Shared<birch::type::MatrixStack>>(y, z);
}

#line 43 "src/expression/MatrixStack.birch"
libbirch::Shared<birch::type::MatrixStack> birch::stack(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) {
  #line 43 "src/expression/MatrixStack.birch"
  libbirch_function_("stack", "src/expression/MatrixStack.birch", 43);
  #line 44 "src/expression/MatrixStack.birch"
  libbirch_line_(44);
  #line 44 "src/expression/MatrixStack.birch"
  return birch::stack(birch::box(y), z);
}

#line 50 "src/expression/MatrixStack.birch"
libbirch::Shared<birch::type::MatrixStack> birch::stack(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 50 "src/expression/MatrixStack.birch"
  libbirch_function_("stack", "src/expression/MatrixStack.birch", 50);
  #line 51 "src/expression/MatrixStack.birch"
  libbirch_line_(51);
  #line 51 "src/expression/MatrixStack.birch"
  return birch::stack(y, birch::box(z));
}

#line 4 "src/expression/MatrixSubtract.birch"
birch::type::MatrixSubtract::MatrixSubtract(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) :
    #line 4 "src/expression/MatrixSubtract.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 8 "src/expression/MatrixSubtract.birch"
birch::type::Integer birch::type::MatrixSubtract::doRows() {
  #line 8 "src/expression/MatrixSubtract.birch"
  libbirch_function_("doRows", "src/expression/MatrixSubtract.birch", 8);
  #line 9 "src/expression/MatrixSubtract.birch"
  libbirch_line_(9);
  #line 9 "src/expression/MatrixSubtract.birch"
  return this->y.value()->rows();
}

#line 12 "src/expression/MatrixSubtract.birch"
birch::type::Integer birch::type::MatrixSubtract::doColumns() {
  #line 12 "src/expression/MatrixSubtract.birch"
  libbirch_function_("doColumns", "src/expression/MatrixSubtract.birch", 12);
  #line 13 "src/expression/MatrixSubtract.birch"
  libbirch_line_(13);
  #line 13 "src/expression/MatrixSubtract.birch"
  return this->y.value()->columns();
}

#line 16 "src/expression/MatrixSubtract.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixSubtract::doEvaluate(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 16 "src/expression/MatrixSubtract.birch"
  libbirch_function_("doEvaluate", "src/expression/MatrixSubtract.birch", 16);
  #line 17 "src/expression/MatrixSubtract.birch"
  libbirch_line_(17);
  #line 17 "src/expression/MatrixSubtract.birch"
  return y - z;
}

#line 20 "src/expression/MatrixSubtract.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixSubtract::doEvaluateGradLeft(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 20 "src/expression/MatrixSubtract.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/MatrixSubtract.birch", 20);
  #line 22 "src/expression/MatrixSubtract.birch"
  libbirch_line_(22);
  #line 22 "src/expression/MatrixSubtract.birch"
  return d;
}

#line 25 "src/expression/MatrixSubtract.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixSubtract::doEvaluateGradRight(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 25 "src/expression/MatrixSubtract.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/MatrixSubtract.birch", 25);
  #line 27 "src/expression/MatrixSubtract.birch"
  libbirch_line_(27);
  #line 27 "src/expression/MatrixSubtract.birch"
  return -(d);
}

#line 30 "src/expression/MatrixSubtract.birch"
std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixGaussian>>>> birch::type::MatrixSubtract::graftLinearMatrixGaussian() {
  #line 30 "src/expression/MatrixSubtract.birch"
  libbirch_function_("graftLinearMatrixGaussian", "src/expression/MatrixSubtract.birch", 30);
  #line 32 "src/expression/MatrixSubtract.birch"
  libbirch_line_(32);
  #line 32 "src/expression/MatrixSubtract.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixGaussian>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixGaussian>>>>>();
  #line 33 "src/expression/MatrixSubtract.birch"
  libbirch_line_(33);
  #line 33 "src/expression/MatrixSubtract.birch"
  if (!(this->hasValue())) {
    #line 34 "src/expression/MatrixSubtract.birch"
    libbirch_line_(34);
    #line 34 "src/expression/MatrixSubtract.birch"
    std::optional<libbirch::Shared<birch::type::MatrixGaussian>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::MatrixGaussian>>>();
    #line 36 "src/expression/MatrixSubtract.birch"
    libbirch_line_(36);
    #line 36 "src/expression/MatrixSubtract.birch"
    if ((r = this->y.value()->graftLinearMatrixGaussian()).has_value()) {
      #line 37 "src/expression/MatrixSubtract.birch"
      libbirch_line_(37);
      #line 37 "src/expression/MatrixSubtract.birch"
      r.value()->subtract(this->z.value());
    } else {
      #line 38 "src/expression/MatrixSubtract.birch"
      libbirch_line_(38);
      #line 38 "src/expression/MatrixSubtract.birch"
      if ((r = this->z.value()->graftLinearMatrixGaussian()).has_value()) {
        #line 39 "src/expression/MatrixSubtract.birch"
        libbirch_line_(39);
        #line 39 "src/expression/MatrixSubtract.birch"
        r.value()->negateAndAdd(this->y.value());
      } else {
        #line 40 "src/expression/MatrixSubtract.birch"
        libbirch_line_(40);
        #line 40 "src/expression/MatrixSubtract.birch"
        if ((x1 = this->y.value()->graftMatrixGaussian()).has_value()) {
          #line 41 "src/expression/MatrixSubtract.birch"
          libbirch_line_(41);
          #line 41 "src/expression/MatrixSubtract.birch"
          r = birch::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixGaussian>>(birch::box(birch::identity(x1.value()->rows())), x1.value(), -(this->z.value()));
        } else {
          #line 42 "src/expression/MatrixSubtract.birch"
          libbirch_line_(42);
          #line 42 "src/expression/MatrixSubtract.birch"
          if ((x1 = this->z.value()->graftMatrixGaussian()).has_value()) {
            #line 43 "src/expression/MatrixSubtract.birch"
            libbirch_line_(43);
            #line 43 "src/expression/MatrixSubtract.birch"
            r = birch::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixGaussian>>(birch::box(birch::diagonal(-(1.0), x1.value()->rows())), x1.value(), this->y.value());
          }
        }
      }
    }
  }
  #line 46 "src/expression/MatrixSubtract.birch"
  libbirch_line_(46);
  #line 46 "src/expression/MatrixSubtract.birch"
  return r;
}

#line 49 "src/expression/MatrixSubtract.birch"
std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>> birch::type::MatrixSubtract::graftLinearMatrixNormalInverseWishart(const libbirch::Shared<birch::type::Distribution<birch::type::LLT>>& compare) {
  #line 49 "src/expression/MatrixSubtract.birch"
  libbirch_function_("graftLinearMatrixNormalInverseWishart", "src/expression/MatrixSubtract.birch", 49);
  #line 51 "src/expression/MatrixSubtract.birch"
  libbirch_line_(51);
  #line 51 "src/expression/MatrixSubtract.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>>>();
  #line 52 "src/expression/MatrixSubtract.birch"
  libbirch_line_(52);
  #line 52 "src/expression/MatrixSubtract.birch"
  if (!(this->hasValue())) {
    #line 53 "src/expression/MatrixSubtract.birch"
    libbirch_line_(53);
    #line 53 "src/expression/MatrixSubtract.birch"
    std::optional<libbirch::Shared<birch::type::MatrixNormalInverseWishart>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>();
    #line 55 "src/expression/MatrixSubtract.birch"
    libbirch_line_(55);
    #line 55 "src/expression/MatrixSubtract.birch"
    if ((r = this->y.value()->graftLinearMatrixNormalInverseWishart(compare)).has_value()) {
      #line 56 "src/expression/MatrixSubtract.birch"
      libbirch_line_(56);
      #line 56 "src/expression/MatrixSubtract.birch"
      r.value()->subtract(this->z.value());
    } else {
      #line 57 "src/expression/MatrixSubtract.birch"
      libbirch_line_(57);
      #line 57 "src/expression/MatrixSubtract.birch"
      if ((r = this->z.value()->graftLinearMatrixNormalInverseWishart(compare)).has_value()) {
        #line 58 "src/expression/MatrixSubtract.birch"
        libbirch_line_(58);
        #line 58 "src/expression/MatrixSubtract.birch"
        r.value()->negateAndAdd(this->y.value());
      } else {
        #line 59 "src/expression/MatrixSubtract.birch"
        libbirch_line_(59);
        #line 59 "src/expression/MatrixSubtract.birch"
        if ((x1 = this->y.value()->graftMatrixNormalInverseWishart(compare)).has_value()) {
          #line 60 "src/expression/MatrixSubtract.birch"
          libbirch_line_(60);
          #line 60 "src/expression/MatrixSubtract.birch"
          r = birch::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>(birch::box(birch::identity(x1.value()->rows())), x1.value(), -(this->z.value()));
        } else {
          #line 61 "src/expression/MatrixSubtract.birch"
          libbirch_line_(61);
          #line 61 "src/expression/MatrixSubtract.birch"
          if ((x1 = this->z.value()->graftMatrixNormalInverseWishart(compare)).has_value()) {
            #line 62 "src/expression/MatrixSubtract.birch"
            libbirch_line_(62);
            #line 62 "src/expression/MatrixSubtract.birch"
            r = birch::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>(birch::box(birch::diagonal(-(1.0), x1.value()->rows())), x1.value(), this->y.value());
          }
        }
      }
    }
  }
  #line 65 "src/expression/MatrixSubtract.birch"
  libbirch_line_(65);
  #line 65 "src/expression/MatrixSubtract.birch"
  return r;
}

#line 72 "src/expression/MatrixSubtract.birch"
libbirch::Shared<birch::type::MatrixSubtract> birch::operator-(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) {
  #line 72 "src/expression/MatrixSubtract.birch"
  libbirch_function_("-", "src/expression/MatrixSubtract.birch", 72);
  #line 74 "src/expression/MatrixSubtract.birch"
  libbirch_line_(74);
  #line 74 "src/expression/MatrixSubtract.birch"
  libbirch_assert_(y->rows() == z->rows());
  #line 75 "src/expression/MatrixSubtract.birch"
  libbirch_line_(75);
  #line 75 "src/expression/MatrixSubtract.birch"
  libbirch_assert_(y->columns() == z->columns());
  #line 76 "src/expression/MatrixSubtract.birch"
  libbirch_line_(76);
  #line 76 "src/expression/MatrixSubtract.birch"
  return birch::construct<libbirch::Shared<birch::type::MatrixSubtract>>(y, z);
}

#line 82 "src/expression/MatrixSubtract.birch"
libbirch::Shared<birch::type::MatrixSubtract> birch::operator-(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) {
  #line 82 "src/expression/MatrixSubtract.birch"
  libbirch_function_("-", "src/expression/MatrixSubtract.birch", 82);
  #line 83 "src/expression/MatrixSubtract.birch"
  libbirch_line_(83);
  #line 83 "src/expression/MatrixSubtract.birch"
  return birch::box(y) - z;
}

#line 89 "src/expression/MatrixSubtract.birch"
libbirch::Shared<birch::type::MatrixSubtract> birch::operator-(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 89 "src/expression/MatrixSubtract.birch"
  libbirch_function_("-", "src/expression/MatrixSubtract.birch", 89);
  #line 90 "src/expression/MatrixSubtract.birch"
  libbirch_line_(90);
  #line 90 "src/expression/MatrixSubtract.birch"
  return y - birch::box(z);
}

#line 4 "src/expression/MatrixTranspose.birch"
birch::type::MatrixTranspose::MatrixTranspose(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& x) :
    #line 4 "src/expression/MatrixTranspose.birch"
    base_type_(x) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/MatrixTranspose.birch"
birch::type::Integer birch::type::MatrixTranspose::doRows() {
  #line 7 "src/expression/MatrixTranspose.birch"
  libbirch_function_("doRows", "src/expression/MatrixTranspose.birch", 7);
  #line 8 "src/expression/MatrixTranspose.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MatrixTranspose.birch"
  return this->y.value()->columns();
}

#line 11 "src/expression/MatrixTranspose.birch"
birch::type::Integer birch::type::MatrixTranspose::doColumns() {
  #line 11 "src/expression/MatrixTranspose.birch"
  libbirch_function_("doColumns", "src/expression/MatrixTranspose.birch", 11);
  #line 12 "src/expression/MatrixTranspose.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MatrixTranspose.birch"
  return this->y.value()->rows();
}

#line 15 "src/expression/MatrixTranspose.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixTranspose::doEvaluate(const libbirch::DefaultArray<birch::type::Real,2>& y) {
  #line 15 "src/expression/MatrixTranspose.birch"
  libbirch_function_("doEvaluate", "src/expression/MatrixTranspose.birch", 15);
  #line 16 "src/expression/MatrixTranspose.birch"
  libbirch_line_(16);
  #line 16 "src/expression/MatrixTranspose.birch"
  return birch::transpose(y);
}

#line 19 "src/expression/MatrixTranspose.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixTranspose::doEvaluateGrad(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y) {
  #line 19 "src/expression/MatrixTranspose.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/MatrixTranspose.birch", 19);
  #line 21 "src/expression/MatrixTranspose.birch"
  libbirch_line_(21);
  #line 21 "src/expression/MatrixTranspose.birch"
  return birch::transpose(d);
}

#line 28 "src/expression/MatrixTranspose.birch"
libbirch::Shared<birch::type::MatrixTranspose> birch::transpose(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y) {
  #line 28 "src/expression/MatrixTranspose.birch"
  libbirch_function_("transpose", "src/expression/MatrixTranspose.birch", 28);
  #line 29 "src/expression/MatrixTranspose.birch"
  libbirch_line_(29);
  #line 29 "src/expression/MatrixTranspose.birch"
  return birch::construct<libbirch::Shared<birch::type::MatrixTranspose>>(y);
}

#line 35 "src/expression/MatrixTranspose.birch"
libbirch::Shared<birch::type::Expression<birch::type::LLT>> birch::transpose(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& y) {
  #line 35 "src/expression/MatrixTranspose.birch"
  libbirch_function_("transpose", "src/expression/MatrixTranspose.birch", 35);
  #line 36 "src/expression/MatrixTranspose.birch"
  libbirch_line_(36);
  #line 36 "src/expression/MatrixTranspose.birch"
  return y;
}

#line 4 "src/expression/Multiply.birch"
birch::type::Multiply::Multiply(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) :
    #line 4 "src/expression/Multiply.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/Multiply.birch"
birch::type::Real birch::type::Multiply::doEvaluate(const birch::type::Real& y, const birch::type::Real& z) {
  #line 7 "src/expression/Multiply.birch"
  libbirch_function_("doEvaluate", "src/expression/Multiply.birch", 7);
  #line 8 "src/expression/Multiply.birch"
  libbirch_line_(8);
  #line 8 "src/expression/Multiply.birch"
  return y * z;
}

#line 11 "src/expression/Multiply.birch"
birch::type::Real birch::type::Multiply::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z) {
  #line 11 "src/expression/Multiply.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/Multiply.birch", 11);
  #line 12 "src/expression/Multiply.birch"
  libbirch_line_(12);
  #line 12 "src/expression/Multiply.birch"
  return d * z;
}

#line 15 "src/expression/Multiply.birch"
birch::type::Real birch::type::Multiply::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z) {
  #line 15 "src/expression/Multiply.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/Multiply.birch", 15);
  #line 16 "src/expression/Multiply.birch"
  libbirch_line_(16);
  #line 16 "src/expression/Multiply.birch"
  return d * y;
}

#line 19 "src/expression/Multiply.birch"
std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gamma>>>> birch::type::Multiply::graftScaledGamma() {
  #line 19 "src/expression/Multiply.birch"
  libbirch_function_("graftScaledGamma", "src/expression/Multiply.birch", 19);
  #line 20 "src/expression/Multiply.birch"
  libbirch_line_(20);
  #line 20 "src/expression/Multiply.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gamma>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gamma>>>>>();
  #line 21 "src/expression/Multiply.birch"
  libbirch_line_(21);
  #line 21 "src/expression/Multiply.birch"
  if (!(this->hasValue())) {
    #line 22 "src/expression/Multiply.birch"
    libbirch_line_(22);
    #line 22 "src/expression/Multiply.birch"
    std::optional<libbirch::Shared<birch::type::Gamma>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::Gamma>>>();
    #line 24 "src/expression/Multiply.birch"
    libbirch_line_(24);
    #line 24 "src/expression/Multiply.birch"
    if ((r = this->y.value()->graftScaledGamma()).has_value()) {
      #line 25 "src/expression/Multiply.birch"
      libbirch_line_(25);
      #line 25 "src/expression/Multiply.birch"
      r.value()->multiply(this->z.value());
    } else {
      #line 26 "src/expression/Multiply.birch"
      libbirch_line_(26);
      #line 26 "src/expression/Multiply.birch"
      if ((r = this->z.value()->graftScaledGamma()).has_value()) {
        #line 27 "src/expression/Multiply.birch"
        libbirch_line_(27);
        #line 27 "src/expression/Multiply.birch"
        r.value()->multiply(this->y.value());
      } else {
        #line 28 "src/expression/Multiply.birch"
        libbirch_line_(28);
        #line 28 "src/expression/Multiply.birch"
        if ((x1 = this->y.value()->graftGamma()).has_value()) {
          #line 29 "src/expression/Multiply.birch"
          libbirch_line_(29);
          #line 29 "src/expression/Multiply.birch"
          r = birch::TransformLinear<libbirch::Shared<birch::type::Gamma>>(this->z.value(), x1.value());
        } else {
          #line 30 "src/expression/Multiply.birch"
          libbirch_line_(30);
          #line 30 "src/expression/Multiply.birch"
          if ((x1 = this->z.value()->graftGamma()).has_value()) {
            #line 31 "src/expression/Multiply.birch"
            libbirch_line_(31);
            #line 31 "src/expression/Multiply.birch"
            r = birch::TransformLinear<libbirch::Shared<birch::type::Gamma>>(this->y.value(), x1.value());
          }
        }
      }
    }
  }
  #line 34 "src/expression/Multiply.birch"
  libbirch_line_(34);
  #line 34 "src/expression/Multiply.birch"
  return r;
}

#line 37 "src/expression/Multiply.birch"
std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gaussian>>>> birch::type::Multiply::graftLinearGaussian() {
  #line 37 "src/expression/Multiply.birch"
  libbirch_function_("graftLinearGaussian", "src/expression/Multiply.birch", 37);
  #line 38 "src/expression/Multiply.birch"
  libbirch_line_(38);
  #line 38 "src/expression/Multiply.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gaussian>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gaussian>>>>>();
  #line 39 "src/expression/Multiply.birch"
  libbirch_line_(39);
  #line 39 "src/expression/Multiply.birch"
  if (!(this->hasValue())) {
    #line 40 "src/expression/Multiply.birch"
    libbirch_line_(40);
    #line 40 "src/expression/Multiply.birch"
    std::optional<libbirch::Shared<birch::type::Gaussian>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::Gaussian>>>();
    #line 42 "src/expression/Multiply.birch"
    libbirch_line_(42);
    #line 42 "src/expression/Multiply.birch"
    if ((r = this->y.value()->graftLinearGaussian()).has_value()) {
      #line 43 "src/expression/Multiply.birch"
      libbirch_line_(43);
      #line 43 "src/expression/Multiply.birch"
      r.value()->multiply(this->z.value());
    } else {
      #line 44 "src/expression/Multiply.birch"
      libbirch_line_(44);
      #line 44 "src/expression/Multiply.birch"
      if ((r = this->z.value()->graftLinearGaussian()).has_value()) {
        #line 45 "src/expression/Multiply.birch"
        libbirch_line_(45);
        #line 45 "src/expression/Multiply.birch"
        r.value()->multiply(this->y.value());
      } else {
        #line 46 "src/expression/Multiply.birch"
        libbirch_line_(46);
        #line 46 "src/expression/Multiply.birch"
        if ((x1 = this->y.value()->graftGaussian()).has_value()) {
          #line 47 "src/expression/Multiply.birch"
          libbirch_line_(47);
          #line 47 "src/expression/Multiply.birch"
          r = birch::TransformLinear<libbirch::Shared<birch::type::Gaussian>>(this->z.value(), x1.value());
        } else {
          #line 48 "src/expression/Multiply.birch"
          libbirch_line_(48);
          #line 48 "src/expression/Multiply.birch"
          if ((x1 = this->z.value()->graftGaussian()).has_value()) {
            #line 49 "src/expression/Multiply.birch"
            libbirch_line_(49);
            #line 49 "src/expression/Multiply.birch"
            r = birch::TransformLinear<libbirch::Shared<birch::type::Gaussian>>(this->y.value(), x1.value());
          }
        }
      }
    }
  }
  #line 52 "src/expression/Multiply.birch"
  libbirch_line_(52);
  #line 52 "src/expression/Multiply.birch"
  return r;
}

#line 55 "src/expression/Multiply.birch"
std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateGaussian>>>> birch::type::Multiply::graftDotMultivariateGaussian() {
  #line 55 "src/expression/Multiply.birch"
  libbirch_function_("graftDotMultivariateGaussian", "src/expression/Multiply.birch", 55);
  #line 57 "src/expression/Multiply.birch"
  libbirch_line_(57);
  #line 57 "src/expression/Multiply.birch"
  std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateGaussian>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateGaussian>>>>>();
  #line 58 "src/expression/Multiply.birch"
  libbirch_line_(58);
  #line 58 "src/expression/Multiply.birch"
  if (!(this->hasValue())) {
    #line 59 "src/expression/Multiply.birch"
    libbirch_line_(59);
    #line 59 "src/expression/Multiply.birch"
    if ((r = this->y.value()->graftDotMultivariateGaussian()).has_value()) {
      #line 60 "src/expression/Multiply.birch"
      libbirch_line_(60);
      #line 60 "src/expression/Multiply.birch"
      r.value()->multiply(this->z.value());
    } else {
      #line 61 "src/expression/Multiply.birch"
      libbirch_line_(61);
      #line 61 "src/expression/Multiply.birch"
      if ((r = this->z.value()->graftDotMultivariateGaussian()).has_value()) {
        #line 62 "src/expression/Multiply.birch"
        libbirch_line_(62);
        #line 62 "src/expression/Multiply.birch"
        r.value()->multiply(this->y.value());
      }
    }
  }
  #line 65 "src/expression/Multiply.birch"
  libbirch_line_(65);
  #line 65 "src/expression/Multiply.birch"
  return r;
}

#line 68 "src/expression/Multiply.birch"
std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>>> birch::type::Multiply::graftLinearNormalInverseGamma(const libbirch::Shared<birch::type::Distribution<birch::type::Real>>& compare) {
  #line 68 "src/expression/Multiply.birch"
  libbirch_function_("graftLinearNormalInverseGamma", "src/expression/Multiply.birch", 68);
  #line 70 "src/expression/Multiply.birch"
  libbirch_line_(70);
  #line 70 "src/expression/Multiply.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>>>>();
  #line 71 "src/expression/Multiply.birch"
  libbirch_line_(71);
  #line 71 "src/expression/Multiply.birch"
  if (!(this->hasValue())) {
    #line 72 "src/expression/Multiply.birch"
    libbirch_line_(72);
    #line 72 "src/expression/Multiply.birch"
    std::optional<libbirch::Shared<birch::type::NormalInverseGamma>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::NormalInverseGamma>>>();
    #line 74 "src/expression/Multiply.birch"
    libbirch_line_(74);
    #line 74 "src/expression/Multiply.birch"
    if ((r = this->y.value()->graftLinearNormalInverseGamma(compare)).has_value()) {
      #line 75 "src/expression/Multiply.birch"
      libbirch_line_(75);
      #line 75 "src/expression/Multiply.birch"
      r.value()->multiply(this->z.value());
    } else {
      #line 76 "src/expression/Multiply.birch"
      libbirch_line_(76);
      #line 76 "src/expression/Multiply.birch"
      if ((r = this->z.value()->graftLinearNormalInverseGamma(compare)).has_value()) {
        #line 77 "src/expression/Multiply.birch"
        libbirch_line_(77);
        #line 77 "src/expression/Multiply.birch"
        r.value()->multiply(this->y.value());
      } else {
        #line 78 "src/expression/Multiply.birch"
        libbirch_line_(78);
        #line 78 "src/expression/Multiply.birch"
        if ((x1 = this->y.value()->graftNormalInverseGamma(compare)).has_value()) {
          #line 79 "src/expression/Multiply.birch"
          libbirch_line_(79);
          #line 79 "src/expression/Multiply.birch"
          r = birch::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>(this->z.value(), x1.value());
        } else {
          #line 80 "src/expression/Multiply.birch"
          libbirch_line_(80);
          #line 80 "src/expression/Multiply.birch"
          if ((x1 = this->z.value()->graftNormalInverseGamma(compare)).has_value()) {
            #line 81 "src/expression/Multiply.birch"
            libbirch_line_(81);
            #line 81 "src/expression/Multiply.birch"
            r = birch::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>(this->y.value(), x1.value());
          }
        }
      }
    }
  }
  #line 84 "src/expression/Multiply.birch"
  libbirch_line_(84);
  #line 84 "src/expression/Multiply.birch"
  return r;
}

#line 87 "src/expression/Multiply.birch"
std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>> birch::type::Multiply::graftDotMultivariateNormalInverseGamma(const libbirch::Shared<birch::type::Distribution<birch::type::Real>>& compare) {
  #line 87 "src/expression/Multiply.birch"
  libbirch_function_("graftDotMultivariateNormalInverseGamma", "src/expression/Multiply.birch", 87);
  #line 89 "src/expression/Multiply.birch"
  libbirch_line_(89);
  #line 89 "src/expression/Multiply.birch"
  std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>();
  #line 90 "src/expression/Multiply.birch"
  libbirch_line_(90);
  #line 90 "src/expression/Multiply.birch"
  if (!(this->hasValue())) {
    #line 91 "src/expression/Multiply.birch"
    libbirch_line_(91);
    #line 91 "src/expression/Multiply.birch"
    if ((r = this->y.value()->graftDotMultivariateNormalInverseGamma(compare)).has_value()) {
      #line 92 "src/expression/Multiply.birch"
      libbirch_line_(92);
      #line 92 "src/expression/Multiply.birch"
      r.value()->multiply(this->z.value());
    } else {
      #line 93 "src/expression/Multiply.birch"
      libbirch_line_(93);
      #line 93 "src/expression/Multiply.birch"
      if ((r = this->z.value()->graftDotMultivariateNormalInverseGamma(compare)).has_value()) {
        #line 94 "src/expression/Multiply.birch"
        libbirch_line_(94);
        #line 94 "src/expression/Multiply.birch"
        r.value()->multiply(this->y.value());
      }
    }
  }
  #line 97 "src/expression/Multiply.birch"
  libbirch_line_(97);
  #line 97 "src/expression/Multiply.birch"
  return r;
}

#line 104 "src/expression/Multiply.birch"
libbirch::Shared<birch::type::Multiply> birch::operator*(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 104 "src/expression/Multiply.birch"
  libbirch_function_("*", "src/expression/Multiply.birch", 104);
  #line 105 "src/expression/Multiply.birch"
  libbirch_line_(105);
  #line 105 "src/expression/Multiply.birch"
  return birch::construct<libbirch::Shared<birch::type::Multiply>>(y, z);
}

#line 111 "src/expression/Multiply.birch"
libbirch::Shared<birch::type::Multiply> birch::operator*(const birch::type::Real& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 111 "src/expression/Multiply.birch"
  libbirch_function_("*", "src/expression/Multiply.birch", 111);
  #line 112 "src/expression/Multiply.birch"
  libbirch_line_(112);
  #line 112 "src/expression/Multiply.birch"
  return birch::box(y) * z;
}

#line 118 "src/expression/Multiply.birch"
libbirch::Shared<birch::type::Multiply> birch::operator*(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const birch::type::Real& z) {
  #line 118 "src/expression/Multiply.birch"
  libbirch_function_("*", "src/expression/Multiply.birch", 118);
  #line 119 "src/expression/Multiply.birch"
  libbirch_line_(119);
  #line 119 "src/expression/Multiply.birch"
  return y * birch::box(z);
}

#line 4 "src/expression/MultivariateAbs.birch"
birch::type::MultivariateAbs::MultivariateAbs(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y) :
    #line 4 "src/expression/MultivariateAbs.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/MultivariateAbs.birch"
birch::type::Integer birch::type::MultivariateAbs::doRows() {
  #line 7 "src/expression/MultivariateAbs.birch"
  libbirch_function_("doRows", "src/expression/MultivariateAbs.birch", 7);
  #line 8 "src/expression/MultivariateAbs.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MultivariateAbs.birch"
  return this->y.value()->rows();
}

#line 11 "src/expression/MultivariateAbs.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateAbs::doEvaluate(const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 11 "src/expression/MultivariateAbs.birch"
  libbirch_function_("doEvaluate", "src/expression/MultivariateAbs.birch", 11);
  #line 12 "src/expression/MultivariateAbs.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MultivariateAbs.birch"
  return birch::transform(y, std::function<birch::type::Real(birch::type::Real)>([=](const birch::type::Real& y) {
    #line 12 "src/expression/MultivariateAbs.birch"
    libbirch_line_(12);
    #line 12 "src/expression/MultivariateAbs.birch"
    return birch::abs(y);
  }));
}

#line 15 "src/expression/MultivariateAbs.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateAbs::doEvaluateGrad(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 15 "src/expression/MultivariateAbs.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/MultivariateAbs.birch", 15);
  #line 17 "src/expression/MultivariateAbs.birch"
  libbirch_line_(17);
  #line 17 "src/expression/MultivariateAbs.birch"
  return birch::transform(d, x, std::function<birch::type::Real(birch::type::Real,birch::type::Real)>([=](const birch::type::Real& d, const birch::type::Real& x) {
    #line 18 "src/expression/MultivariateAbs.birch"
    libbirch_line_(18);
    #line 18 "src/expression/MultivariateAbs.birch"
    if (x >= 0.0) {
      #line 19 "src/expression/MultivariateAbs.birch"
      libbirch_line_(19);
      #line 19 "src/expression/MultivariateAbs.birch"
      return d;
    } else {
      #line 21 "src/expression/MultivariateAbs.birch"
      libbirch_line_(21);
      #line 21 "src/expression/MultivariateAbs.birch"
      return -(d);
    }
  }));
}

#line 30 "src/expression/MultivariateAbs.birch"
libbirch::Shared<birch::type::MultivariateAbs> birch::abs(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x) {
  #line 30 "src/expression/MultivariateAbs.birch"
  libbirch_function_("abs", "src/expression/MultivariateAbs.birch", 30);
  #line 31 "src/expression/MultivariateAbs.birch"
  libbirch_line_(31);
  #line 31 "src/expression/MultivariateAbs.birch"
  return birch::construct<libbirch::Shared<birch::type::MultivariateAbs>>(x);
}

#line 4 "src/expression/MultivariateAdd.birch"
birch::type::MultivariateAdd::MultivariateAdd(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) :
    #line 4 "src/expression/MultivariateAdd.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/MultivariateAdd.birch"
birch::type::Integer birch::type::MultivariateAdd::doRows() {
  #line 7 "src/expression/MultivariateAdd.birch"
  libbirch_function_("doRows", "src/expression/MultivariateAdd.birch", 7);
  #line 8 "src/expression/MultivariateAdd.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MultivariateAdd.birch"
  return this->y.value()->rows();
}

#line 11 "src/expression/MultivariateAdd.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateAdd::doEvaluate(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 11 "src/expression/MultivariateAdd.birch"
  libbirch_function_("doEvaluate", "src/expression/MultivariateAdd.birch", 11);
  #line 12 "src/expression/MultivariateAdd.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MultivariateAdd.birch"
  return y + z;
}

#line 15 "src/expression/MultivariateAdd.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateAdd::doEvaluateGradLeft(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 15 "src/expression/MultivariateAdd.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/MultivariateAdd.birch", 15);
  #line 17 "src/expression/MultivariateAdd.birch"
  libbirch_line_(17);
  #line 17 "src/expression/MultivariateAdd.birch"
  return d;
}

#line 20 "src/expression/MultivariateAdd.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateAdd::doEvaluateGradRight(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 20 "src/expression/MultivariateAdd.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/MultivariateAdd.birch", 20);
  #line 22 "src/expression/MultivariateAdd.birch"
  libbirch_line_(22);
  #line 22 "src/expression/MultivariateAdd.birch"
  return d;
}

#line 25 "src/expression/MultivariateAdd.birch"
std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>>> birch::type::MultivariateAdd::graftLinearMultivariateGaussian() {
  #line 25 "src/expression/MultivariateAdd.birch"
  libbirch_function_("graftLinearMultivariateGaussian", "src/expression/MultivariateAdd.birch", 25);
  #line 27 "src/expression/MultivariateAdd.birch"
  libbirch_line_(27);
  #line 27 "src/expression/MultivariateAdd.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>>>>();
  #line 28 "src/expression/MultivariateAdd.birch"
  libbirch_line_(28);
  #line 28 "src/expression/MultivariateAdd.birch"
  if (!(this->hasValue())) {
    #line 29 "src/expression/MultivariateAdd.birch"
    libbirch_line_(29);
    #line 29 "src/expression/MultivariateAdd.birch"
    std::optional<libbirch::Shared<birch::type::MultivariateGaussian>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::MultivariateGaussian>>>();
    #line 31 "src/expression/MultivariateAdd.birch"
    libbirch_line_(31);
    #line 31 "src/expression/MultivariateAdd.birch"
    if ((r = this->y.value()->graftLinearMultivariateGaussian()).has_value()) {
      #line 32 "src/expression/MultivariateAdd.birch"
      libbirch_line_(32);
      #line 32 "src/expression/MultivariateAdd.birch"
      r.value()->add(this->z.value());
    } else {
      #line 33 "src/expression/MultivariateAdd.birch"
      libbirch_line_(33);
      #line 33 "src/expression/MultivariateAdd.birch"
      if ((r = this->z.value()->graftLinearMultivariateGaussian()).has_value()) {
        #line 34 "src/expression/MultivariateAdd.birch"
        libbirch_line_(34);
        #line 34 "src/expression/MultivariateAdd.birch"
        r.value()->add(this->y.value());
      } else {
        #line 35 "src/expression/MultivariateAdd.birch"
        libbirch_line_(35);
        #line 35 "src/expression/MultivariateAdd.birch"
        if ((x1 = this->y.value()->graftMultivariateGaussian()).has_value()) {
          #line 36 "src/expression/MultivariateAdd.birch"
          libbirch_line_(36);
          #line 36 "src/expression/MultivariateAdd.birch"
          r = birch::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>(birch::box(birch::identity(this->z.value()->rows())), x1.value(), this->z.value());
        } else {
          #line 38 "src/expression/MultivariateAdd.birch"
          libbirch_line_(38);
          #line 38 "src/expression/MultivariateAdd.birch"
          if ((x1 = this->z.value()->graftMultivariateGaussian()).has_value()) {
            #line 39 "src/expression/MultivariateAdd.birch"
            libbirch_line_(39);
            #line 39 "src/expression/MultivariateAdd.birch"
            r = birch::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>(birch::box(birch::identity(this->z.value()->rows())), x1.value(), this->y.value());
          }
        }
      }
    }
  }
  #line 43 "src/expression/MultivariateAdd.birch"
  libbirch_line_(43);
  #line 43 "src/expression/MultivariateAdd.birch"
  return r;
}

#line 46 "src/expression/MultivariateAdd.birch"
std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>> birch::type::MultivariateAdd::graftLinearMultivariateNormalInverseGamma(const libbirch::Shared<birch::type::Distribution<birch::type::Real>>& compare) {
  #line 46 "src/expression/MultivariateAdd.birch"
  libbirch_function_("graftLinearMultivariateNormalInverseGamma", "src/expression/MultivariateAdd.birch", 46);
  #line 48 "src/expression/MultivariateAdd.birch"
  libbirch_line_(48);
  #line 48 "src/expression/MultivariateAdd.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>();
  #line 49 "src/expression/MultivariateAdd.birch"
  libbirch_line_(49);
  #line 49 "src/expression/MultivariateAdd.birch"
  if (!(this->hasValue())) {
    #line 50 "src/expression/MultivariateAdd.birch"
    libbirch_line_(50);
    #line 50 "src/expression/MultivariateAdd.birch"
    std::optional<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>();
    #line 52 "src/expression/MultivariateAdd.birch"
    libbirch_line_(52);
    #line 52 "src/expression/MultivariateAdd.birch"
    if ((r = this->y.value()->graftLinearMultivariateNormalInverseGamma(compare)).has_value()) {
      #line 53 "src/expression/MultivariateAdd.birch"
      libbirch_line_(53);
      #line 53 "src/expression/MultivariateAdd.birch"
      r.value()->add(this->z.value());
    } else {
      #line 54 "src/expression/MultivariateAdd.birch"
      libbirch_line_(54);
      #line 54 "src/expression/MultivariateAdd.birch"
      if ((r = this->z.value()->graftLinearMultivariateNormalInverseGamma(compare)).has_value()) {
        #line 55 "src/expression/MultivariateAdd.birch"
        libbirch_line_(55);
        #line 55 "src/expression/MultivariateAdd.birch"
        r.value()->add(this->y.value());
      } else {
        #line 56 "src/expression/MultivariateAdd.birch"
        libbirch_line_(56);
        #line 56 "src/expression/MultivariateAdd.birch"
        if ((x1 = this->y.value()->graftMultivariateNormalInverseGamma(compare)).has_value()) {
          #line 57 "src/expression/MultivariateAdd.birch"
          libbirch_line_(57);
          #line 57 "src/expression/MultivariateAdd.birch"
          r = birch::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>(birch::box(birch::identity(this->z.value()->rows())), x1.value(), this->z.value());
        } else {
          #line 59 "src/expression/MultivariateAdd.birch"
          libbirch_line_(59);
          #line 59 "src/expression/MultivariateAdd.birch"
          if ((x1 = this->z.value()->graftMultivariateNormalInverseGamma(compare)).has_value()) {
            #line 60 "src/expression/MultivariateAdd.birch"
            libbirch_line_(60);
            #line 60 "src/expression/MultivariateAdd.birch"
            r = birch::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>(birch::box(birch::identity(this->z.value()->rows())), x1.value(), this->y.value());
          }
        }
      }
    }
  }
  #line 64 "src/expression/MultivariateAdd.birch"
  libbirch_line_(64);
  #line 64 "src/expression/MultivariateAdd.birch"
  return r;
}

#line 67 "src/expression/MultivariateAdd.birch"
std::optional<libbirch::Shared<birch::type::TransformDotMultivariate<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>> birch::type::MultivariateAdd::graftDotMatrixNormalInverseWishart(const libbirch::Shared<birch::type::Distribution<birch::type::LLT>>& compare) {
  #line 67 "src/expression/MultivariateAdd.birch"
  libbirch_function_("graftDotMatrixNormalInverseWishart", "src/expression/MultivariateAdd.birch", 67);
  #line 69 "src/expression/MultivariateAdd.birch"
  libbirch_line_(69);
  #line 69 "src/expression/MultivariateAdd.birch"
  std::optional<libbirch::Shared<birch::type::TransformDotMultivariate<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformDotMultivariate<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>>>();
  #line 70 "src/expression/MultivariateAdd.birch"
  libbirch_line_(70);
  #line 70 "src/expression/MultivariateAdd.birch"
  if (!(this->hasValue())) {
    #line 71 "src/expression/MultivariateAdd.birch"
    libbirch_line_(71);
    #line 71 "src/expression/MultivariateAdd.birch"
    if ((r = this->y.value()->graftDotMatrixNormalInverseWishart(compare)).has_value()) {
      #line 72 "src/expression/MultivariateAdd.birch"
      libbirch_line_(72);
      #line 72 "src/expression/MultivariateAdd.birch"
      r.value()->add(this->z.value());
    } else {
      #line 73 "src/expression/MultivariateAdd.birch"
      libbirch_line_(73);
      #line 73 "src/expression/MultivariateAdd.birch"
      if ((r = this->z.value()->graftDotMatrixNormalInverseWishart(compare)).has_value()) {
        #line 74 "src/expression/MultivariateAdd.birch"
        libbirch_line_(74);
        #line 74 "src/expression/MultivariateAdd.birch"
        r.value()->add(this->y.value());
      }
    }
  }
  #line 77 "src/expression/MultivariateAdd.birch"
  libbirch_line_(77);
  #line 77 "src/expression/MultivariateAdd.birch"
  return r;
}

#line 84 "src/expression/MultivariateAdd.birch"
libbirch::Shared<birch::type::MultivariateAdd> birch::operator+(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) {
  #line 84 "src/expression/MultivariateAdd.birch"
  libbirch_function_("+", "src/expression/MultivariateAdd.birch", 84);
  #line 85 "src/expression/MultivariateAdd.birch"
  libbirch_line_(85);
  #line 85 "src/expression/MultivariateAdd.birch"
  libbirch_assert_(y->rows() == z->rows());
  #line 86 "src/expression/MultivariateAdd.birch"
  libbirch_line_(86);
  #line 86 "src/expression/MultivariateAdd.birch"
  return birch::construct<libbirch::Shared<birch::type::MultivariateAdd>>(y, z);
}

#line 92 "src/expression/MultivariateAdd.birch"
libbirch::Shared<birch::type::MultivariateAdd> birch::operator+(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) {
  #line 92 "src/expression/MultivariateAdd.birch"
  libbirch_function_("+", "src/expression/MultivariateAdd.birch", 92);
  #line 93 "src/expression/MultivariateAdd.birch"
  libbirch_line_(93);
  #line 93 "src/expression/MultivariateAdd.birch"
  return birch::box(y) + z;
}

#line 99 "src/expression/MultivariateAdd.birch"
libbirch::Shared<birch::type::MultivariateAdd> birch::operator+(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 99 "src/expression/MultivariateAdd.birch"
  libbirch_function_("+", "src/expression/MultivariateAdd.birch", 99);
  #line 100 "src/expression/MultivariateAdd.birch"
  libbirch_line_(100);
  #line 100 "src/expression/MultivariateAdd.birch"
  return y + birch::box(z);
}

#line 4 "src/expression/MultivariateCanonical.birch"
birch::type::MultivariateCanonical::MultivariateCanonical(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y) :
    #line 4 "src/expression/MultivariateCanonical.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/MultivariateCanonical.birch"
birch::type::Integer birch::type::MultivariateCanonical::doRows() {
  #line 7 "src/expression/MultivariateCanonical.birch"
  libbirch_function_("doRows", "src/expression/MultivariateCanonical.birch", 7);
  #line 8 "src/expression/MultivariateCanonical.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MultivariateCanonical.birch"
  return this->y.value()->rows();
}

#line 11 "src/expression/MultivariateCanonical.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateCanonical::doEvaluate(const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 11 "src/expression/MultivariateCanonical.birch"
  libbirch_function_("doEvaluate", "src/expression/MultivariateCanonical.birch", 11);
  #line 12 "src/expression/MultivariateCanonical.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MultivariateCanonical.birch"
  return y;
}

#line 15 "src/expression/MultivariateCanonical.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateCanonical::doEvaluateGrad(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 15 "src/expression/MultivariateCanonical.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/MultivariateCanonical.birch", 15);
  #line 17 "src/expression/MultivariateCanonical.birch"
  libbirch_line_(17);
  #line 17 "src/expression/MultivariateCanonical.birch"
  return d;
}

#line 24 "src/expression/MultivariateCanonical.birch"
libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>> birch::canonical(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y) {
  #line 24 "src/expression/MultivariateCanonical.birch"
  libbirch_function_("canonical", "src/expression/MultivariateCanonical.birch", 24);
  #line 25 "src/expression/MultivariateCanonical.birch"
  libbirch_line_(25);
  #line 25 "src/expression/MultivariateCanonical.birch"
  if (!(y->isRandom())) {
    #line 27 "src/expression/MultivariateCanonical.birch"
    libbirch_line_(27);
    #line 27 "src/expression/MultivariateCanonical.birch"
    return y;
  } else {
    #line 31 "src/expression/MultivariateCanonical.birch"
    libbirch_line_(31);
    #line 31 "src/expression/MultivariateCanonical.birch"
    return birch::construct<libbirch::Shared<birch::type::MultivariateCanonical>>(y);
  }
}

#line 4 "src/expression/MultivariateDiagonal.birch"
birch::type::MultivariateDiagonal::MultivariateDiagonal(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y) :
    #line 4 "src/expression/MultivariateDiagonal.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/MultivariateDiagonal.birch"
birch::type::Integer birch::type::MultivariateDiagonal::doRows() {
  #line 7 "src/expression/MultivariateDiagonal.birch"
  libbirch_function_("doRows", "src/expression/MultivariateDiagonal.birch", 7);
  #line 8 "src/expression/MultivariateDiagonal.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MultivariateDiagonal.birch"
  return birch::min(this->y.value()->rows(), this->y.value()->columns());
}

#line 11 "src/expression/MultivariateDiagonal.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateDiagonal::doEvaluate(const libbirch::DefaultArray<birch::type::Real,2>& y) {
  #line 11 "src/expression/MultivariateDiagonal.birch"
  libbirch_function_("doEvaluate", "src/expression/MultivariateDiagonal.birch", 11);
  #line 12 "src/expression/MultivariateDiagonal.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MultivariateDiagonal.birch"
  return birch::diagonal(y);
}

#line 15 "src/expression/MultivariateDiagonal.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MultivariateDiagonal::doEvaluateGrad(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,2>& y) {
  #line 15 "src/expression/MultivariateDiagonal.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/MultivariateDiagonal.birch", 15);
  #line 17 "src/expression/MultivariateDiagonal.birch"
  libbirch_line_(17);
  #line 17 "src/expression/MultivariateDiagonal.birch"
  return birch::diagonal(d);
}

#line 24 "src/expression/MultivariateDiagonal.birch"
libbirch::Shared<birch::type::MultivariateDiagonal> birch::diagonal(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y) {
  #line 24 "src/expression/MultivariateDiagonal.birch"
  libbirch_function_("diagonal", "src/expression/MultivariateDiagonal.birch", 24);
  #line 25 "src/expression/MultivariateDiagonal.birch"
  libbirch_line_(25);
  #line 25 "src/expression/MultivariateDiagonal.birch"
  return birch::construct<libbirch::Shared<birch::type::MultivariateDiagonal>>(y);
}

#line 4 "src/expression/MultivariateDot.birch"
birch::type::MultivariateDot::MultivariateDot(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) :
    #line 4 "src/expression/MultivariateDot.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/MultivariateDot.birch"
birch::type::Integer birch::type::MultivariateDot::doRows() {
  #line 7 "src/expression/MultivariateDot.birch"
  libbirch_function_("doRows", "src/expression/MultivariateDot.birch", 7);
  #line 8 "src/expression/MultivariateDot.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MultivariateDot.birch"
  return this->z.value()->columns();
}

#line 11 "src/expression/MultivariateDot.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateDot::doEvaluate(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 11 "src/expression/MultivariateDot.birch"
  libbirch_function_("doEvaluate", "src/expression/MultivariateDot.birch", 11);
  #line 12 "src/expression/MultivariateDot.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MultivariateDot.birch"
  return birch::dot(y, z);
}

#line 15 "src/expression/MultivariateDot.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateDot::doEvaluateGradLeft(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 15 "src/expression/MultivariateDot.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/MultivariateDot.birch", 15);
  #line 17 "src/expression/MultivariateDot.birch"
  libbirch_line_(17);
  #line 17 "src/expression/MultivariateDot.birch"
  return z * d;
}

#line 20 "src/expression/MultivariateDot.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MultivariateDot::doEvaluateGradRight(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 20 "src/expression/MultivariateDot.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/MultivariateDot.birch", 20);
  #line 22 "src/expression/MultivariateDot.birch"
  libbirch_line_(22);
  #line 22 "src/expression/MultivariateDot.birch"
  return birch::outer(y, d);
}

#line 25 "src/expression/MultivariateDot.birch"
std::optional<libbirch::Shared<birch::type::TransformDotMultivariate<libbirch::Shared<birch::type::MatrixGaussian>>>> birch::type::MultivariateDot::graftDotMatrixGaussian() {
  #line 25 "src/expression/MultivariateDot.birch"
  libbirch_function_("graftDotMatrixGaussian", "src/expression/MultivariateDot.birch", 25);
  #line 27 "src/expression/MultivariateDot.birch"
  libbirch_line_(27);
  #line 27 "src/expression/MultivariateDot.birch"
  if (!(this->hasValue())) {
    #line 28 "src/expression/MultivariateDot.birch"
    libbirch_line_(28);
    #line 28 "src/expression/MultivariateDot.birch"
    std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixGaussian>>>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixGaussian>>>>>();
    #line 29 "src/expression/MultivariateDot.birch"
    libbirch_line_(29);
    #line 29 "src/expression/MultivariateDot.birch"
    std::optional<libbirch::Shared<birch::type::MatrixGaussian>> x2 = libbirch::make<std::optional<libbirch::Shared<birch::type::MatrixGaussian>>>();
    #line 31 "src/expression/MultivariateDot.birch"
    libbirch_line_(31);
    #line 31 "src/expression/MultivariateDot.birch"
    if ((x1 = this->z.value()->graftLinearMatrixGaussian()).has_value()) {
      #line 32 "src/expression/MultivariateDot.birch"
      libbirch_line_(32);
      #line 32 "src/expression/MultivariateDot.birch"
      return birch::TransformDotMultivariate<libbirch::Shared<birch::type::MatrixGaussian>>(birch::dot(this->y.value(), x1.value()->A), x1.value()->X, birch::dot(this->y.value(), x1.value()->C));
    } else {
      #line 33 "src/expression/MultivariateDot.birch"
      libbirch_line_(33);
      #line 33 "src/expression/MultivariateDot.birch"
      if ((x2 = this->z.value()->graftMatrixGaussian()).has_value()) {
        #line 34 "src/expression/MultivariateDot.birch"
        libbirch_line_(34);
        #line 34 "src/expression/MultivariateDot.birch"
        return birch::TransformDotMultivariate<libbirch::Shared<birch::type::MatrixGaussian>>(this->y.value(), x2.value());
      }
    }
  }
  #line 37 "src/expression/MultivariateDot.birch"
  libbirch_line_(37);
  #line 37 "src/expression/MultivariateDot.birch"
  return std::nullopt;
}

#line 40 "src/expression/MultivariateDot.birch"
std::optional<libbirch::Shared<birch::type::TransformDotMultivariate<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>> birch::type::MultivariateDot::graftDotMatrixNormalInverseWishart(const libbirch::Shared<birch::type::Distribution<birch::type::LLT>>& compare) {
  #line 40 "src/expression/MultivariateDot.birch"
  libbirch_function_("graftDotMatrixNormalInverseWishart", "src/expression/MultivariateDot.birch", 40);
  #line 42 "src/expression/MultivariateDot.birch"
  libbirch_line_(42);
  #line 42 "src/expression/MultivariateDot.birch"
  if (!(this->hasValue())) {
    #line 43 "src/expression/MultivariateDot.birch"
    libbirch_line_(43);
    #line 43 "src/expression/MultivariateDot.birch"
    std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>>>();
    #line 44 "src/expression/MultivariateDot.birch"
    libbirch_line_(44);
    #line 44 "src/expression/MultivariateDot.birch"
    std::optional<libbirch::Shared<birch::type::MatrixNormalInverseWishart>> x2 = libbirch::make<std::optional<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>();
    #line 46 "src/expression/MultivariateDot.birch"
    libbirch_line_(46);
    #line 46 "src/expression/MultivariateDot.birch"
    if ((x1 = this->z.value()->graftLinearMatrixNormalInverseWishart(compare)).has_value()) {
      #line 47 "src/expression/MultivariateDot.birch"
      libbirch_line_(47);
      #line 47 "src/expression/MultivariateDot.birch"
      return birch::TransformDotMultivariate<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>(birch::dot(this->y.value(), x1.value()->A), x1.value()->X, birch::dot(this->y.value(), x1.value()->C));
    } else {
      #line 48 "src/expression/MultivariateDot.birch"
      libbirch_line_(48);
      #line 48 "src/expression/MultivariateDot.birch"
      if ((x2 = this->z.value()->graftMatrixNormalInverseWishart(compare)).has_value()) {
        #line 49 "src/expression/MultivariateDot.birch"
        libbirch_line_(49);
        #line 49 "src/expression/MultivariateDot.birch"
        return birch::TransformDotMultivariate<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>(this->y.value(), x2.value());
      }
    }
  }
  #line 52 "src/expression/MultivariateDot.birch"
  libbirch_line_(52);
  #line 52 "src/expression/MultivariateDot.birch"
  return std::nullopt;
}

#line 59 "src/expression/MultivariateDot.birch"
libbirch::Shared<birch::type::MultivariateDot> birch::dot(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) {
  #line 59 "src/expression/MultivariateDot.birch"
  libbirch_function_("dot", "src/expression/MultivariateDot.birch", 59);
  #line 61 "src/expression/MultivariateDot.birch"
  libbirch_line_(61);
  #line 61 "src/expression/MultivariateDot.birch"
  libbirch_assert_(y->rows() == z->rows());
  #line 62 "src/expression/MultivariateDot.birch"
  libbirch_line_(62);
  #line 62 "src/expression/MultivariateDot.birch"
  return birch::construct<libbirch::Shared<birch::type::MultivariateDot>>(y, z);
}

#line 68 "src/expression/MultivariateDot.birch"
libbirch::Shared<birch::type::MultivariateDot> birch::dot(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& z) {
  #line 68 "src/expression/MultivariateDot.birch"
  libbirch_function_("dot", "src/expression/MultivariateDot.birch", 68);
  #line 69 "src/expression/MultivariateDot.birch"
  libbirch_line_(69);
  #line 69 "src/expression/MultivariateDot.birch"
  return birch::dot(birch::box(y), z);
}

#line 75 "src/expression/MultivariateDot.birch"
libbirch::Shared<birch::type::MultivariateDot> birch::dot(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 75 "src/expression/MultivariateDot.birch"
  libbirch_function_("dot", "src/expression/MultivariateDot.birch", 75);
  #line 76 "src/expression/MultivariateDot.birch"
  libbirch_line_(76);
  #line 76 "src/expression/MultivariateDot.birch"
  return birch::dot(y, birch::box(z));
}

#line 66 "src/expression/MultivariateElement.birch"
libbirch::Shared<birch::type::MultivariateElement<birch::type::Real>> birch::MultivariateElement(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y, const birch::type::Integer& i) {
  #line 66 "src/expression/MultivariateElement.birch"
  libbirch_function_("MultivariateElement", "src/expression/MultivariateElement.birch", 66);
  #line 68 "src/expression/MultivariateElement.birch"
  libbirch_line_(68);
  #line 68 "src/expression/MultivariateElement.birch"
  return birch::construct<libbirch::Shared<birch::type::MultivariateElement<birch::type::Real>>>(y, i);
}

#line 74 "src/expression/MultivariateElement.birch"
libbirch::Shared<birch::type::MultivariateElement<birch::type::Integer>> birch::MultivariateElement(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Integer,1>>>& y, const birch::type::Integer& i) {
  #line 74 "src/expression/MultivariateElement.birch"
  libbirch_function_("MultivariateElement", "src/expression/MultivariateElement.birch", 74);
  #line 76 "src/expression/MultivariateElement.birch"
  libbirch_line_(76);
  #line 76 "src/expression/MultivariateElement.birch"
  return birch::construct<libbirch::Shared<birch::type::MultivariateElement<birch::type::Integer>>>(y, i);
}

#line 82 "src/expression/MultivariateElement.birch"
libbirch::Shared<birch::type::MultivariateElement<birch::type::Boolean>> birch::MultivariateElement(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Boolean,1>>>& y, const birch::type::Integer& i) {
  #line 82 "src/expression/MultivariateElement.birch"
  libbirch_function_("MultivariateElement", "src/expression/MultivariateElement.birch", 82);
  #line 84 "src/expression/MultivariateElement.birch"
  libbirch_line_(84);
  #line 84 "src/expression/MultivariateElement.birch"
  return birch::construct<libbirch::Shared<birch::type::MultivariateElement<birch::type::Boolean>>>(y, i);
}

#line 4 "src/expression/MultivariateMultiply.birch"
birch::type::MultivariateMultiply::MultivariateMultiply(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) :
    #line 4 "src/expression/MultivariateMultiply.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 8 "src/expression/MultivariateMultiply.birch"
birch::type::Integer birch::type::MultivariateMultiply::doRows() {
  #line 8 "src/expression/MultivariateMultiply.birch"
  libbirch_function_("doRows", "src/expression/MultivariateMultiply.birch", 8);
  #line 9 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(9);
  #line 9 "src/expression/MultivariateMultiply.birch"
  return this->y.value()->rows();
}

#line 12 "src/expression/MultivariateMultiply.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateMultiply::doEvaluate(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 12 "src/expression/MultivariateMultiply.birch"
  libbirch_function_("doEvaluate", "src/expression/MultivariateMultiply.birch", 12);
  #line 13 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(13);
  #line 13 "src/expression/MultivariateMultiply.birch"
  return y * z;
}

#line 16 "src/expression/MultivariateMultiply.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MultivariateMultiply::doEvaluateGradLeft(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 16 "src/expression/MultivariateMultiply.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/MultivariateMultiply.birch", 16);
  #line 18 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(18);
  #line 18 "src/expression/MultivariateMultiply.birch"
  return birch::outer(d, z);
}

#line 21 "src/expression/MultivariateMultiply.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateMultiply::doEvaluateGradRight(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 21 "src/expression/MultivariateMultiply.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/MultivariateMultiply.birch", 21);
  #line 23 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(23);
  #line 23 "src/expression/MultivariateMultiply.birch"
  return birch::transpose(y) * d;
}

#line 26 "src/expression/MultivariateMultiply.birch"
std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>>> birch::type::MultivariateMultiply::graftLinearMultivariateGaussian() {
  #line 26 "src/expression/MultivariateMultiply.birch"
  libbirch_function_("graftLinearMultivariateGaussian", "src/expression/MultivariateMultiply.birch", 26);
  #line 28 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(28);
  #line 28 "src/expression/MultivariateMultiply.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>>>>();
  #line 29 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(29);
  #line 29 "src/expression/MultivariateMultiply.birch"
  if (!(this->hasValue())) {
    #line 30 "src/expression/MultivariateMultiply.birch"
    libbirch_line_(30);
    #line 30 "src/expression/MultivariateMultiply.birch"
    std::optional<libbirch::Shared<birch::type::MultivariateGaussian>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::MultivariateGaussian>>>();
    #line 31 "src/expression/MultivariateMultiply.birch"
    libbirch_line_(31);
    #line 31 "src/expression/MultivariateMultiply.birch"
    if ((r = this->z.value()->graftLinearMultivariateGaussian()).has_value()) {
      #line 32 "src/expression/MultivariateMultiply.birch"
      libbirch_line_(32);
      #line 32 "src/expression/MultivariateMultiply.birch"
      r.value()->leftMultiply(this->y.value());
    } else {
      #line 33 "src/expression/MultivariateMultiply.birch"
      libbirch_line_(33);
      #line 33 "src/expression/MultivariateMultiply.birch"
      if ((x1 = this->z.value()->graftMultivariateGaussian()).has_value()) {
        #line 34 "src/expression/MultivariateMultiply.birch"
        libbirch_line_(34);
        #line 34 "src/expression/MultivariateMultiply.birch"
        r = birch::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>(this->y.value(), x1.value());
      }
    }
  }
  #line 37 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(37);
  #line 37 "src/expression/MultivariateMultiply.birch"
  return r;
}

#line 40 "src/expression/MultivariateMultiply.birch"
std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>> birch::type::MultivariateMultiply::graftLinearMultivariateNormalInverseGamma(const libbirch::Shared<birch::type::Distribution<birch::type::Real>>& compare) {
  #line 40 "src/expression/MultivariateMultiply.birch"
  libbirch_function_("graftLinearMultivariateNormalInverseGamma", "src/expression/MultivariateMultiply.birch", 40);
  #line 42 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(42);
  #line 42 "src/expression/MultivariateMultiply.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>();
  #line 43 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(43);
  #line 43 "src/expression/MultivariateMultiply.birch"
  if (!(this->hasValue())) {
    #line 44 "src/expression/MultivariateMultiply.birch"
    libbirch_line_(44);
    #line 44 "src/expression/MultivariateMultiply.birch"
    std::optional<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>();
    #line 46 "src/expression/MultivariateMultiply.birch"
    libbirch_line_(46);
    #line 46 "src/expression/MultivariateMultiply.birch"
    if ((r = this->z.value()->graftLinearMultivariateNormalInverseGamma(compare)).has_value()) {
      #line 47 "src/expression/MultivariateMultiply.birch"
      libbirch_line_(47);
      #line 47 "src/expression/MultivariateMultiply.birch"
      r.value()->leftMultiply(this->y.value());
    } else {
      #line 48 "src/expression/MultivariateMultiply.birch"
      libbirch_line_(48);
      #line 48 "src/expression/MultivariateMultiply.birch"
      if ((x1 = this->z.value()->graftMultivariateNormalInverseGamma(compare)).has_value()) {
        #line 49 "src/expression/MultivariateMultiply.birch"
        libbirch_line_(49);
        #line 49 "src/expression/MultivariateMultiply.birch"
        r = birch::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>(this->y.value(), x1.value());
      }
    }
  }
  #line 52 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(52);
  #line 52 "src/expression/MultivariateMultiply.birch"
  return r;
}

#line 59 "src/expression/MultivariateMultiply.birch"
libbirch::Shared<birch::type::MultivariateMultiply> birch::operator*(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) {
  #line 59 "src/expression/MultivariateMultiply.birch"
  libbirch_function_("*", "src/expression/MultivariateMultiply.birch", 59);
  #line 61 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(61);
  #line 61 "src/expression/MultivariateMultiply.birch"
  libbirch_assert_(y->columns() == z->rows());
  #line 62 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(62);
  #line 62 "src/expression/MultivariateMultiply.birch"
  return birch::construct<libbirch::Shared<birch::type::MultivariateMultiply>>(y, z);
}

#line 68 "src/expression/MultivariateMultiply.birch"
libbirch::Shared<birch::type::MultivariateMultiply> birch::operator*(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) {
  #line 68 "src/expression/MultivariateMultiply.birch"
  libbirch_function_("*", "src/expression/MultivariateMultiply.birch", 68);
  #line 69 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(69);
  #line 69 "src/expression/MultivariateMultiply.birch"
  return birch::box(y) * z;
}

#line 75 "src/expression/MultivariateMultiply.birch"
libbirch::Shared<birch::type::MultivariateMultiply> birch::operator*(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 75 "src/expression/MultivariateMultiply.birch"
  libbirch_function_("*", "src/expression/MultivariateMultiply.birch", 75);
  #line 76 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(76);
  #line 76 "src/expression/MultivariateMultiply.birch"
  return y * birch::box(z);
}

#line 4 "src/expression/MultivariateNegate.birch"
birch::type::MultivariateNegate::MultivariateNegate(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y) :
    #line 4 "src/expression/MultivariateNegate.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/MultivariateNegate.birch"
birch::type::Integer birch::type::MultivariateNegate::doRows() {
  #line 7 "src/expression/MultivariateNegate.birch"
  libbirch_function_("doRows", "src/expression/MultivariateNegate.birch", 7);
  #line 8 "src/expression/MultivariateNegate.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MultivariateNegate.birch"
  return this->y.value()->rows();
}

#line 11 "src/expression/MultivariateNegate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateNegate::doEvaluate(const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 11 "src/expression/MultivariateNegate.birch"
  libbirch_function_("doEvaluate", "src/expression/MultivariateNegate.birch", 11);
  #line 12 "src/expression/MultivariateNegate.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MultivariateNegate.birch"
  return -(y);
}

#line 15 "src/expression/MultivariateNegate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateNegate::doEvaluateGrad(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 15 "src/expression/MultivariateNegate.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/MultivariateNegate.birch", 15);
  #line 17 "src/expression/MultivariateNegate.birch"
  libbirch_line_(17);
  #line 17 "src/expression/MultivariateNegate.birch"
  return -(d);
}

#line 20 "src/expression/MultivariateNegate.birch"
std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>>> birch::type::MultivariateNegate::graftLinearMultivariateGaussian() {
  #line 20 "src/expression/MultivariateNegate.birch"
  libbirch_function_("graftLinearMultivariateGaussian", "src/expression/MultivariateNegate.birch", 20);
  #line 22 "src/expression/MultivariateNegate.birch"
  libbirch_line_(22);
  #line 22 "src/expression/MultivariateNegate.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>>>>();
  #line 23 "src/expression/MultivariateNegate.birch"
  libbirch_line_(23);
  #line 23 "src/expression/MultivariateNegate.birch"
  if (!(this->hasValue())) {
    #line 24 "src/expression/MultivariateNegate.birch"
    libbirch_line_(24);
    #line 24 "src/expression/MultivariateNegate.birch"
    std::optional<libbirch::Shared<birch::type::MultivariateGaussian>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::MultivariateGaussian>>>();
    #line 26 "src/expression/MultivariateNegate.birch"
    libbirch_line_(26);
    #line 26 "src/expression/MultivariateNegate.birch"
    if ((r = this->y.value()->graftLinearMultivariateGaussian()).has_value()) {
      #line 27 "src/expression/MultivariateNegate.birch"
      libbirch_line_(27);
      #line 27 "src/expression/MultivariateNegate.birch"
      r.value()->negate();
    } else {
      #line 28 "src/expression/MultivariateNegate.birch"
      libbirch_line_(28);
      #line 28 "src/expression/MultivariateNegate.birch"
      if ((x1 = this->y.value()->graftMultivariateGaussian()).has_value()) {
        #line 29 "src/expression/MultivariateNegate.birch"
        libbirch_line_(29);
        #line 29 "src/expression/MultivariateNegate.birch"
        auto R = x1.value()->rows();
        #line 30 "src/expression/MultivariateNegate.birch"
        libbirch_line_(30);
        #line 30 "src/expression/MultivariateNegate.birch"
        r = birch::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>(birch::box(birch::diagonal(-(1.0), R)), x1.value(), birch::box(birch::vector(0.0, R)));
      }
    }
  }
  #line 34 "src/expression/MultivariateNegate.birch"
  libbirch_line_(34);
  #line 34 "src/expression/MultivariateNegate.birch"
  return r;
}

#line 37 "src/expression/MultivariateNegate.birch"
std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>> birch::type::MultivariateNegate::graftLinearMultivariateNormalInverseGamma(const libbirch::Shared<birch::type::Distribution<birch::type::Real>>& compare) {
  #line 37 "src/expression/MultivariateNegate.birch"
  libbirch_function_("graftLinearMultivariateNormalInverseGamma", "src/expression/MultivariateNegate.birch", 37);
  #line 39 "src/expression/MultivariateNegate.birch"
  libbirch_line_(39);
  #line 39 "src/expression/MultivariateNegate.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>();
  #line 40 "src/expression/MultivariateNegate.birch"
  libbirch_line_(40);
  #line 40 "src/expression/MultivariateNegate.birch"
  if (!(this->hasValue())) {
    #line 41 "src/expression/MultivariateNegate.birch"
    libbirch_line_(41);
    #line 41 "src/expression/MultivariateNegate.birch"
    std::optional<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>();
    #line 43 "src/expression/MultivariateNegate.birch"
    libbirch_line_(43);
    #line 43 "src/expression/MultivariateNegate.birch"
    if ((r = this->y.value()->graftLinearMultivariateNormalInverseGamma(compare)).has_value()) {
      #line 44 "src/expression/MultivariateNegate.birch"
      libbirch_line_(44);
      #line 44 "src/expression/MultivariateNegate.birch"
      r.value()->negate();
    } else {
      #line 45 "src/expression/MultivariateNegate.birch"
      libbirch_line_(45);
      #line 45 "src/expression/MultivariateNegate.birch"
      if ((x1 = this->y.value()->graftMultivariateNormalInverseGamma(compare)).has_value()) {
        #line 46 "src/expression/MultivariateNegate.birch"
        libbirch_line_(46);
        #line 46 "src/expression/MultivariateNegate.birch"
        auto R = x1.value()->rows();
        #line 47 "src/expression/MultivariateNegate.birch"
        libbirch_line_(47);
        #line 47 "src/expression/MultivariateNegate.birch"
        r = birch::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>(birch::box(birch::diagonal(-(1.0), R)), x1.value(), birch::box(birch::vector(0.0, R)));
      }
    }
  }
  #line 51 "src/expression/MultivariateNegate.birch"
  libbirch_line_(51);
  #line 51 "src/expression/MultivariateNegate.birch"
  return r;
}

#line 58 "src/expression/MultivariateNegate.birch"
libbirch::Shared<birch::type::MultivariateNegate> birch::operator-(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y) {
  #line 58 "src/expression/MultivariateNegate.birch"
  libbirch_function_("-", "src/expression/MultivariateNegate.birch", 58);
  #line 59 "src/expression/MultivariateNegate.birch"
  libbirch_line_(59);
  #line 59 "src/expression/MultivariateNegate.birch"
  return birch::construct<libbirch::Shared<birch::type::MultivariateNegate>>(y);
}

#line 4 "src/expression/MultivariateRectify.birch"
birch::type::MultivariateRectify::MultivariateRectify(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y) :
    #line 4 "src/expression/MultivariateRectify.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/MultivariateRectify.birch"
birch::type::Integer birch::type::MultivariateRectify::doRows() {
  #line 7 "src/expression/MultivariateRectify.birch"
  libbirch_function_("doRows", "src/expression/MultivariateRectify.birch", 7);
  #line 8 "src/expression/MultivariateRectify.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MultivariateRectify.birch"
  return this->y.value()->rows();
}

#line 11 "src/expression/MultivariateRectify.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateRectify::doEvaluate(const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 11 "src/expression/MultivariateRectify.birch"
  libbirch_function_("doEvaluate", "src/expression/MultivariateRectify.birch", 11);
  #line 12 "src/expression/MultivariateRectify.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MultivariateRectify.birch"
  return birch::transform(y, std::function<birch::type::Real(birch::type::Real)>([=](const birch::type::Real& y) {
    #line 12 "src/expression/MultivariateRectify.birch"
    libbirch_line_(12);
    #line 12 "src/expression/MultivariateRectify.birch"
    return birch::rectify(y);
  }));
}

#line 15 "src/expression/MultivariateRectify.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateRectify::doEvaluateGrad(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 15 "src/expression/MultivariateRectify.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/MultivariateRectify.birch", 15);
  #line 17 "src/expression/MultivariateRectify.birch"
  libbirch_line_(17);
  #line 17 "src/expression/MultivariateRectify.birch"
  return birch::transform(d, x, std::function<birch::type::Real(birch::type::Real,birch::type::Real)>([=](const birch::type::Real& d, const birch::type::Real& x) {
    #line 18 "src/expression/MultivariateRectify.birch"
    libbirch_line_(18);
    #line 18 "src/expression/MultivariateRectify.birch"
    if (x > 0.0) {
      #line 19 "src/expression/MultivariateRectify.birch"
      libbirch_line_(19);
      #line 19 "src/expression/MultivariateRectify.birch"
      return d;
    } else {
      #line 21 "src/expression/MultivariateRectify.birch"
      libbirch_line_(21);
      #line 21 "src/expression/MultivariateRectify.birch"
      return 0.0;
    }
  }));
}

#line 30 "src/expression/MultivariateRectify.birch"
libbirch::Shared<birch::type::MultivariateRectify> birch::rectify(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x) {
  #line 30 "src/expression/MultivariateRectify.birch"
  libbirch_function_("rectify", "src/expression/MultivariateRectify.birch", 30);
  #line 31 "src/expression/MultivariateRectify.birch"
  libbirch_line_(31);
  #line 31 "src/expression/MultivariateRectify.birch"
  return birch::construct<libbirch::Shared<birch::type::MultivariateRectify>>(x);
}

#line 4 "src/expression/MultivariateScalarDivide.birch"
libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>> birch::operator/(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 4 "src/expression/MultivariateScalarDivide.birch"
  libbirch_function_("/", "src/expression/MultivariateScalarDivide.birch", 4);
  #line 6 "src/expression/MultivariateScalarDivide.birch"
  libbirch_line_(6);
  #line 6 "src/expression/MultivariateScalarDivide.birch"
  return birch::diagonal(1.0 / z, y->rows()) * y;
}

#line 12 "src/expression/MultivariateScalarDivide.birch"
libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>> birch::operator/(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 12 "src/expression/MultivariateScalarDivide.birch"
  libbirch_function_("/", "src/expression/MultivariateScalarDivide.birch", 12);
  #line 13 "src/expression/MultivariateScalarDivide.birch"
  libbirch_line_(13);
  #line 13 "src/expression/MultivariateScalarDivide.birch"
  return birch::box(y) / z;
}

#line 19 "src/expression/MultivariateScalarDivide.birch"
libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>> birch::operator/(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y, const birch::type::Real& z) {
  #line 19 "src/expression/MultivariateScalarDivide.birch"
  libbirch_function_("/", "src/expression/MultivariateScalarDivide.birch", 19);
  #line 20 "src/expression/MultivariateScalarDivide.birch"
  libbirch_line_(20);
  #line 20 "src/expression/MultivariateScalarDivide.birch"
  return y / birch::box(z);
}

#line 4 "src/expression/MultivariateScalarMultiply.birch"
birch::type::MultivariateScalarMultiply::MultivariateScalarMultiply(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) :
    #line 4 "src/expression/MultivariateScalarMultiply.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/MultivariateScalarMultiply.birch"
birch::type::Integer birch::type::MultivariateScalarMultiply::doRows() {
  #line 7 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_function_("doRows", "src/expression/MultivariateScalarMultiply.birch", 7);
  #line 8 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MultivariateScalarMultiply.birch"
  return this->z.value()->rows();
}

#line 11 "src/expression/MultivariateScalarMultiply.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateScalarMultiply::doEvaluate(const birch::type::Real& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 11 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_function_("doEvaluate", "src/expression/MultivariateScalarMultiply.birch", 11);
  #line 12 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MultivariateScalarMultiply.birch"
  return y * z;
}

#line 15 "src/expression/MultivariateScalarMultiply.birch"
birch::type::Real birch::type::MultivariateScalarMultiply::doEvaluateGradLeft(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const birch::type::Real& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 15 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/MultivariateScalarMultiply.birch", 15);
  #line 17 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(17);
  #line 17 "src/expression/MultivariateScalarMultiply.birch"
  return birch::dot(d, z);
}

#line 20 "src/expression/MultivariateScalarMultiply.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateScalarMultiply::doEvaluateGradRight(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const birch::type::Real& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 20 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/MultivariateScalarMultiply.birch", 20);
  #line 22 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(22);
  #line 22 "src/expression/MultivariateScalarMultiply.birch"
  return y * d;
}

#line 25 "src/expression/MultivariateScalarMultiply.birch"
std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>>> birch::type::MultivariateScalarMultiply::graftLinearMultivariateGaussian() {
  #line 25 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_function_("graftLinearMultivariateGaussian", "src/expression/MultivariateScalarMultiply.birch", 25);
  #line 27 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(27);
  #line 27 "src/expression/MultivariateScalarMultiply.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>>>>();
  #line 28 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(28);
  #line 28 "src/expression/MultivariateScalarMultiply.birch"
  if (!(this->hasValue())) {
    #line 29 "src/expression/MultivariateScalarMultiply.birch"
    libbirch_line_(29);
    #line 29 "src/expression/MultivariateScalarMultiply.birch"
    std::optional<libbirch::Shared<birch::type::MultivariateGaussian>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::MultivariateGaussian>>>();
    #line 31 "src/expression/MultivariateScalarMultiply.birch"
    libbirch_line_(31);
    #line 31 "src/expression/MultivariateScalarMultiply.birch"
    if ((r = this->z.value()->graftLinearMultivariateGaussian()).has_value()) {
      #line 32 "src/expression/MultivariateScalarMultiply.birch"
      libbirch_line_(32);
      #line 32 "src/expression/MultivariateScalarMultiply.birch"
      r.value()->multiply(this->y.value());
    } else {
      #line 33 "src/expression/MultivariateScalarMultiply.birch"
      libbirch_line_(33);
      #line 33 "src/expression/MultivariateScalarMultiply.birch"
      if ((x1 = this->z.value()->graftMultivariateGaussian()).has_value()) {
        #line 34 "src/expression/MultivariateScalarMultiply.birch"
        libbirch_line_(34);
        #line 34 "src/expression/MultivariateScalarMultiply.birch"
        r = birch::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>(birch::diagonal(this->y.value(), this->z.value()->rows()), x1.value());
      }
    }
  }
  #line 37 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(37);
  #line 37 "src/expression/MultivariateScalarMultiply.birch"
  return r;
}

#line 40 "src/expression/MultivariateScalarMultiply.birch"
std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>> birch::type::MultivariateScalarMultiply::graftLinearMultivariateNormalInverseGamma(const libbirch::Shared<birch::type::Distribution<birch::type::Real>>& compare) {
  #line 40 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_function_("graftLinearMultivariateNormalInverseGamma", "src/expression/MultivariateScalarMultiply.birch", 40);
  #line 42 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(42);
  #line 42 "src/expression/MultivariateScalarMultiply.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>();
  #line 43 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(43);
  #line 43 "src/expression/MultivariateScalarMultiply.birch"
  if (!(this->hasValue())) {
    #line 44 "src/expression/MultivariateScalarMultiply.birch"
    libbirch_line_(44);
    #line 44 "src/expression/MultivariateScalarMultiply.birch"
    std::optional<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>();
    #line 46 "src/expression/MultivariateScalarMultiply.birch"
    libbirch_line_(46);
    #line 46 "src/expression/MultivariateScalarMultiply.birch"
    if ((r = this->z.value()->graftLinearMultivariateNormalInverseGamma(compare)).has_value()) {
      #line 47 "src/expression/MultivariateScalarMultiply.birch"
      libbirch_line_(47);
      #line 47 "src/expression/MultivariateScalarMultiply.birch"
      r.value()->multiply(this->y.value());
    } else {
      #line 48 "src/expression/MultivariateScalarMultiply.birch"
      libbirch_line_(48);
      #line 48 "src/expression/MultivariateScalarMultiply.birch"
      if ((x1 = this->z.value()->graftMultivariateNormalInverseGamma(compare)).has_value()) {
        #line 49 "src/expression/MultivariateScalarMultiply.birch"
        libbirch_line_(49);
        #line 49 "src/expression/MultivariateScalarMultiply.birch"
        r = birch::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>(birch::diagonal(this->y.value(), this->z.value()->rows()), x1.value());
      }
    }
  }
  #line 52 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(52);
  #line 52 "src/expression/MultivariateScalarMultiply.birch"
  return r;
}

#line 59 "src/expression/MultivariateScalarMultiply.birch"
libbirch::Shared<birch::type::MultivariateScalarMultiply> birch::operator*(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) {
  #line 59 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_function_("*", "src/expression/MultivariateScalarMultiply.birch", 59);
  #line 61 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(61);
  #line 61 "src/expression/MultivariateScalarMultiply.birch"
  return birch::construct<libbirch::Shared<birch::type::MultivariateScalarMultiply>>(y, z);
}

#line 67 "src/expression/MultivariateScalarMultiply.birch"
libbirch::Shared<birch::type::MultivariateScalarMultiply> birch::operator*(const birch::type::Real& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) {
  #line 67 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_function_("*", "src/expression/MultivariateScalarMultiply.birch", 67);
  #line 68 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(68);
  #line 68 "src/expression/MultivariateScalarMultiply.birch"
  return birch::box(y) * z;
}

#line 74 "src/expression/MultivariateScalarMultiply.birch"
libbirch::Shared<birch::type::MultivariateScalarMultiply> birch::operator*(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 74 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_function_("*", "src/expression/MultivariateScalarMultiply.birch", 74);
  #line 75 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(75);
  #line 75 "src/expression/MultivariateScalarMultiply.birch"
  return y * birch::box(z);
}

#line 81 "src/expression/MultivariateScalarMultiply.birch"
libbirch::Shared<birch::type::MultivariateScalarMultiply> birch::operator*(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 81 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_function_("*", "src/expression/MultivariateScalarMultiply.birch", 81);
  #line 83 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(83);
  #line 83 "src/expression/MultivariateScalarMultiply.birch"
  return z * y;
}

#line 89 "src/expression/MultivariateScalarMultiply.birch"
libbirch::Shared<birch::type::MultivariateScalarMultiply> birch::operator*(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 89 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_function_("*", "src/expression/MultivariateScalarMultiply.birch", 89);
  #line 90 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(90);
  #line 90 "src/expression/MultivariateScalarMultiply.birch"
  return z * y;
}

#line 96 "src/expression/MultivariateScalarMultiply.birch"
libbirch::Shared<birch::type::MultivariateScalarMultiply> birch::operator*(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y, const birch::type::Real& z) {
  #line 96 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_function_("*", "src/expression/MultivariateScalarMultiply.birch", 96);
  #line 97 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(97);
  #line 97 "src/expression/MultivariateScalarMultiply.birch"
  return z * y;
}

#line 29 "src/expression/MultivariateSolve.birch"
libbirch::Shared<birch::type::MultivariateSolve<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::DefaultArray<birch::type::Real,2>>> birch::solve(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) {
  #line 29 "src/expression/MultivariateSolve.birch"
  libbirch_function_("solve", "src/expression/MultivariateSolve.birch", 29);
  #line 31 "src/expression/MultivariateSolve.birch"
  libbirch_line_(31);
  #line 31 "src/expression/MultivariateSolve.birch"
  libbirch_assert_(y->columns() == z->rows());
  #line 32 "src/expression/MultivariateSolve.birch"
  libbirch_line_(32);
  #line 32 "src/expression/MultivariateSolve.birch"
  return birch::construct<libbirch::Shared<birch::type::MultivariateSolve<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::DefaultArray<birch::type::Real,2>>>>(y, z);
}

#line 38 "src/expression/MultivariateSolve.birch"
libbirch::Shared<birch::type::MultivariateSolve<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::DefaultArray<birch::type::Real,2>>> birch::solve(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) {
  #line 38 "src/expression/MultivariateSolve.birch"
  libbirch_function_("solve", "src/expression/MultivariateSolve.birch", 38);
  #line 40 "src/expression/MultivariateSolve.birch"
  libbirch_line_(40);
  #line 40 "src/expression/MultivariateSolve.birch"
  return birch::solve(birch::box(y), z);
}

#line 46 "src/expression/MultivariateSolve.birch"
libbirch::Shared<birch::type::MultivariateSolve<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::DefaultArray<birch::type::Real,2>>> birch::solve(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 46 "src/expression/MultivariateSolve.birch"
  libbirch_function_("solve", "src/expression/MultivariateSolve.birch", 46);
  #line 48 "src/expression/MultivariateSolve.birch"
  libbirch_line_(48);
  #line 48 "src/expression/MultivariateSolve.birch"
  return birch::solve(y, birch::box(z));
}

#line 54 "src/expression/MultivariateSolve.birch"
libbirch::Shared<birch::type::MultivariateSolve<libbirch::Shared<birch::type::Expression<birch::type::LLT>>, birch::type::LLT>> birch::solve(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) {
  #line 54 "src/expression/MultivariateSolve.birch"
  libbirch_function_("solve", "src/expression/MultivariateSolve.birch", 54);
  #line 56 "src/expression/MultivariateSolve.birch"
  libbirch_line_(56);
  #line 56 "src/expression/MultivariateSolve.birch"
  libbirch_assert_(y->columns() == z->rows());
  #line 57 "src/expression/MultivariateSolve.birch"
  libbirch_line_(57);
  #line 57 "src/expression/MultivariateSolve.birch"
  return birch::construct<libbirch::Shared<birch::type::MultivariateSolve<libbirch::Shared<birch::type::Expression<birch::type::LLT>>, birch::type::LLT>>>(y, z);
}

#line 63 "src/expression/MultivariateSolve.birch"
libbirch::Shared<birch::type::MultivariateSolve<libbirch::Shared<birch::type::Expression<birch::type::LLT>>, birch::type::LLT>> birch::solve(const birch::type::LLT& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) {
  #line 63 "src/expression/MultivariateSolve.birch"
  libbirch_function_("solve", "src/expression/MultivariateSolve.birch", 63);
  #line 65 "src/expression/MultivariateSolve.birch"
  libbirch_line_(65);
  #line 65 "src/expression/MultivariateSolve.birch"
  return birch::solve(birch::box(y), z);
}

#line 71 "src/expression/MultivariateSolve.birch"
libbirch::Shared<birch::type::MultivariateSolve<libbirch::Shared<birch::type::Expression<birch::type::LLT>>, birch::type::LLT>> birch::solve(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 71 "src/expression/MultivariateSolve.birch"
  libbirch_function_("solve", "src/expression/MultivariateSolve.birch", 71);
  #line 73 "src/expression/MultivariateSolve.birch"
  libbirch_line_(73);
  #line 73 "src/expression/MultivariateSolve.birch"
  return birch::solve(y, birch::box(z));
}

#line 4 "src/expression/MultivariateStack.birch"
birch::type::MultivariateStack::MultivariateStack(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) :
    #line 4 "src/expression/MultivariateStack.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/MultivariateStack.birch"
birch::type::Integer birch::type::MultivariateStack::doRows() {
  #line 7 "src/expression/MultivariateStack.birch"
  libbirch_function_("doRows", "src/expression/MultivariateStack.birch", 7);
  #line 8 "src/expression/MultivariateStack.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MultivariateStack.birch"
  return this->y.value()->rows() + this->z.value()->rows();
}

#line 11 "src/expression/MultivariateStack.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateStack::doEvaluate(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 11 "src/expression/MultivariateStack.birch"
  libbirch_function_("doEvaluate", "src/expression/MultivariateStack.birch", 11);
  #line 12 "src/expression/MultivariateStack.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MultivariateStack.birch"
  return birch::stack(y, z);
}

#line 15 "src/expression/MultivariateStack.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateStack::doEvaluateGradLeft(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 15 "src/expression/MultivariateStack.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/MultivariateStack.birch", 15);
  #line 17 "src/expression/MultivariateStack.birch"
  libbirch_line_(17);
  #line 17 "src/expression/MultivariateStack.birch"
  return d(libbirch::make_range(birch::type::Integer(1), birch::rows(y)));
}

#line 20 "src/expression/MultivariateStack.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateStack::doEvaluateGradRight(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 20 "src/expression/MultivariateStack.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/MultivariateStack.birch", 20);
  #line 22 "src/expression/MultivariateStack.birch"
  libbirch_line_(22);
  #line 22 "src/expression/MultivariateStack.birch"
  return d(libbirch::make_range((birch::rows(y) + birch::type::Integer(1)), birch::rows(x)));
}

#line 29 "src/expression/MultivariateStack.birch"
libbirch::Shared<birch::type::MultivariateStack> birch::stack(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) {
  #line 29 "src/expression/MultivariateStack.birch"
  libbirch_function_("stack", "src/expression/MultivariateStack.birch", 29);
  #line 31 "src/expression/MultivariateStack.birch"
  libbirch_line_(31);
  #line 31 "src/expression/MultivariateStack.birch"
  return birch::construct<libbirch::Shared<birch::type::MultivariateStack>>(y, z);
}

#line 37 "src/expression/MultivariateStack.birch"
libbirch::Shared<birch::type::MultivariateStack> birch::stack(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) {
  #line 37 "src/expression/MultivariateStack.birch"
  libbirch_function_("stack", "src/expression/MultivariateStack.birch", 37);
  #line 38 "src/expression/MultivariateStack.birch"
  libbirch_line_(38);
  #line 38 "src/expression/MultivariateStack.birch"
  return birch::stack(birch::box(y), z);
}

#line 44 "src/expression/MultivariateStack.birch"
libbirch::Shared<birch::type::MultivariateStack> birch::stack(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 44 "src/expression/MultivariateStack.birch"
  libbirch_function_("stack", "src/expression/MultivariateStack.birch", 44);
  #line 45 "src/expression/MultivariateStack.birch"
  libbirch_line_(45);
  #line 45 "src/expression/MultivariateStack.birch"
  return birch::stack(y, birch::box(z));
}

#line 4 "src/expression/MultivariateSubtract.birch"
birch::type::MultivariateSubtract::MultivariateSubtract(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) :
    #line 4 "src/expression/MultivariateSubtract.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 8 "src/expression/MultivariateSubtract.birch"
birch::type::Integer birch::type::MultivariateSubtract::doRows() {
  #line 8 "src/expression/MultivariateSubtract.birch"
  libbirch_function_("doRows", "src/expression/MultivariateSubtract.birch", 8);
  #line 9 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(9);
  #line 9 "src/expression/MultivariateSubtract.birch"
  return this->y.value()->rows();
}

#line 12 "src/expression/MultivariateSubtract.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateSubtract::doEvaluate(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 12 "src/expression/MultivariateSubtract.birch"
  libbirch_function_("doEvaluate", "src/expression/MultivariateSubtract.birch", 12);
  #line 13 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(13);
  #line 13 "src/expression/MultivariateSubtract.birch"
  return y - z;
}

#line 16 "src/expression/MultivariateSubtract.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateSubtract::doEvaluateGradLeft(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 16 "src/expression/MultivariateSubtract.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/MultivariateSubtract.birch", 16);
  #line 18 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(18);
  #line 18 "src/expression/MultivariateSubtract.birch"
  return d;
}

#line 21 "src/expression/MultivariateSubtract.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateSubtract::doEvaluateGradRight(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 21 "src/expression/MultivariateSubtract.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/MultivariateSubtract.birch", 21);
  #line 23 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(23);
  #line 23 "src/expression/MultivariateSubtract.birch"
  return -(d);
}

#line 26 "src/expression/MultivariateSubtract.birch"
std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>>> birch::type::MultivariateSubtract::graftLinearMultivariateGaussian() {
  #line 26 "src/expression/MultivariateSubtract.birch"
  libbirch_function_("graftLinearMultivariateGaussian", "src/expression/MultivariateSubtract.birch", 26);
  #line 28 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(28);
  #line 28 "src/expression/MultivariateSubtract.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>>>>();
  #line 29 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(29);
  #line 29 "src/expression/MultivariateSubtract.birch"
  if (!(this->hasValue())) {
    #line 30 "src/expression/MultivariateSubtract.birch"
    libbirch_line_(30);
    #line 30 "src/expression/MultivariateSubtract.birch"
    std::optional<libbirch::Shared<birch::type::MultivariateGaussian>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::MultivariateGaussian>>>();
    #line 32 "src/expression/MultivariateSubtract.birch"
    libbirch_line_(32);
    #line 32 "src/expression/MultivariateSubtract.birch"
    if ((r = this->y.value()->graftLinearMultivariateGaussian()).has_value()) {
      #line 33 "src/expression/MultivariateSubtract.birch"
      libbirch_line_(33);
      #line 33 "src/expression/MultivariateSubtract.birch"
      r.value()->subtract(this->z.value());
    } else {
      #line 34 "src/expression/MultivariateSubtract.birch"
      libbirch_line_(34);
      #line 34 "src/expression/MultivariateSubtract.birch"
      if ((r = this->z.value()->graftLinearMultivariateGaussian()).has_value()) {
        #line 35 "src/expression/MultivariateSubtract.birch"
        libbirch_line_(35);
        #line 35 "src/expression/MultivariateSubtract.birch"
        r.value()->negateAndAdd(this->y.value());
      } else {
        #line 36 "src/expression/MultivariateSubtract.birch"
        libbirch_line_(36);
        #line 36 "src/expression/MultivariateSubtract.birch"
        if ((x1 = this->y.value()->graftMultivariateGaussian()).has_value()) {
          #line 37 "src/expression/MultivariateSubtract.birch"
          libbirch_line_(37);
          #line 37 "src/expression/MultivariateSubtract.birch"
          r = birch::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>(birch::box(birch::identity(this->z.value()->rows())), x1.value(), -(this->z.value()));
        } else {
          #line 38 "src/expression/MultivariateSubtract.birch"
          libbirch_line_(38);
          #line 38 "src/expression/MultivariateSubtract.birch"
          if ((x1 = this->z.value()->graftMultivariateGaussian()).has_value()) {
            #line 39 "src/expression/MultivariateSubtract.birch"
            libbirch_line_(39);
            #line 39 "src/expression/MultivariateSubtract.birch"
            r = birch::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>(birch::box(birch::diagonal(-(1.0), this->z.value()->rows())), x1.value(), this->y.value());
          }
        }
      }
    }
  }
  #line 42 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(42);
  #line 42 "src/expression/MultivariateSubtract.birch"
  return r;
}

#line 45 "src/expression/MultivariateSubtract.birch"
std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>> birch::type::MultivariateSubtract::graftLinearMultivariateNormalInverseGamma(const libbirch::Shared<birch::type::Distribution<birch::type::Real>>& compare) {
  #line 45 "src/expression/MultivariateSubtract.birch"
  libbirch_function_("graftLinearMultivariateNormalInverseGamma", "src/expression/MultivariateSubtract.birch", 45);
  #line 47 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(47);
  #line 47 "src/expression/MultivariateSubtract.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>();
  #line 48 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(48);
  #line 48 "src/expression/MultivariateSubtract.birch"
  if (!(this->hasValue())) {
    #line 49 "src/expression/MultivariateSubtract.birch"
    libbirch_line_(49);
    #line 49 "src/expression/MultivariateSubtract.birch"
    std::optional<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>();
    #line 51 "src/expression/MultivariateSubtract.birch"
    libbirch_line_(51);
    #line 51 "src/expression/MultivariateSubtract.birch"
    if ((r = this->y.value()->graftLinearMultivariateNormalInverseGamma(compare)).has_value()) {
      #line 52 "src/expression/MultivariateSubtract.birch"
      libbirch_line_(52);
      #line 52 "src/expression/MultivariateSubtract.birch"
      r.value()->subtract(this->z.value());
    } else {
      #line 53 "src/expression/MultivariateSubtract.birch"
      libbirch_line_(53);
      #line 53 "src/expression/MultivariateSubtract.birch"
      if ((r = this->z.value()->graftLinearMultivariateNormalInverseGamma(compare)).has_value()) {
        #line 54 "src/expression/MultivariateSubtract.birch"
        libbirch_line_(54);
        #line 54 "src/expression/MultivariateSubtract.birch"
        r.value()->negateAndAdd(this->y.value());
      } else {
        #line 55 "src/expression/MultivariateSubtract.birch"
        libbirch_line_(55);
        #line 55 "src/expression/MultivariateSubtract.birch"
        if ((x1 = this->y.value()->graftMultivariateNormalInverseGamma(compare)).has_value()) {
          #line 56 "src/expression/MultivariateSubtract.birch"
          libbirch_line_(56);
          #line 56 "src/expression/MultivariateSubtract.birch"
          r = birch::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>(birch::box(birch::identity(this->z.value()->rows())), x1.value(), -(this->z.value()));
        } else {
          #line 57 "src/expression/MultivariateSubtract.birch"
          libbirch_line_(57);
          #line 57 "src/expression/MultivariateSubtract.birch"
          if ((x1 = this->z.value()->graftMultivariateNormalInverseGamma(compare)).has_value()) {
            #line 58 "src/expression/MultivariateSubtract.birch"
            libbirch_line_(58);
            #line 58 "src/expression/MultivariateSubtract.birch"
            r = birch::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>(birch::box(birch::diagonal(-(1.0), this->z.value()->rows())), x1.value(), this->y.value());
          }
        }
      }
    }
  }
  #line 61 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(61);
  #line 61 "src/expression/MultivariateSubtract.birch"
  return r;
}

#line 64 "src/expression/MultivariateSubtract.birch"
std::optional<libbirch::Shared<birch::type::TransformDotMultivariate<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>> birch::type::MultivariateSubtract::graftDotMatrixNormalInverseWishart(const libbirch::Shared<birch::type::Distribution<birch::type::LLT>>& compare) {
  #line 64 "src/expression/MultivariateSubtract.birch"
  libbirch_function_("graftDotMatrixNormalInverseWishart", "src/expression/MultivariateSubtract.birch", 64);
  #line 66 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(66);
  #line 66 "src/expression/MultivariateSubtract.birch"
  std::optional<libbirch::Shared<birch::type::TransformDotMultivariate<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformDotMultivariate<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>>>();
  #line 67 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(67);
  #line 67 "src/expression/MultivariateSubtract.birch"
  if (!(this->hasValue())) {
    #line 68 "src/expression/MultivariateSubtract.birch"
    libbirch_line_(68);
    #line 68 "src/expression/MultivariateSubtract.birch"
    if ((r = this->y.value()->graftDotMatrixNormalInverseWishart(compare)).has_value()) {
      #line 69 "src/expression/MultivariateSubtract.birch"
      libbirch_line_(69);
      #line 69 "src/expression/MultivariateSubtract.birch"
      r.value()->subtract(this->z.value());
    } else {
      #line 70 "src/expression/MultivariateSubtract.birch"
      libbirch_line_(70);
      #line 70 "src/expression/MultivariateSubtract.birch"
      if ((r = this->z.value()->graftDotMatrixNormalInverseWishart(compare)).has_value()) {
        #line 71 "src/expression/MultivariateSubtract.birch"
        libbirch_line_(71);
        #line 71 "src/expression/MultivariateSubtract.birch"
        r.value()->negateAndAdd(this->y.value());
      }
    }
  }
  #line 74 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(74);
  #line 74 "src/expression/MultivariateSubtract.birch"
  return r;
}

#line 81 "src/expression/MultivariateSubtract.birch"
libbirch::Shared<birch::type::MultivariateSubtract> birch::operator-(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) {
  #line 81 "src/expression/MultivariateSubtract.birch"
  libbirch_function_("-", "src/expression/MultivariateSubtract.birch", 81);
  #line 83 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(83);
  #line 83 "src/expression/MultivariateSubtract.birch"
  libbirch_assert_(y->rows() == z->rows());
  #line 84 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(84);
  #line 84 "src/expression/MultivariateSubtract.birch"
  return birch::construct<libbirch::Shared<birch::type::MultivariateSubtract>>(y, z);
}

#line 90 "src/expression/MultivariateSubtract.birch"
libbirch::Shared<birch::type::MultivariateSubtract> birch::operator-(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) {
  #line 90 "src/expression/MultivariateSubtract.birch"
  libbirch_function_("-", "src/expression/MultivariateSubtract.birch", 90);
  #line 91 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(91);
  #line 91 "src/expression/MultivariateSubtract.birch"
  return birch::box(y) - z;
}

#line 97 "src/expression/MultivariateSubtract.birch"
libbirch::Shared<birch::type::MultivariateSubtract> birch::operator-(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 97 "src/expression/MultivariateSubtract.birch"
  libbirch_function_("-", "src/expression/MultivariateSubtract.birch", 97);
  #line 98 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(98);
  #line 98 "src/expression/MultivariateSubtract.birch"
  return y - birch::box(z);
}

#line 4 "src/expression/MultivariateTranspose.birch"
birch::type::MultivariateTranspose::MultivariateTranspose(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x) :
    #line 4 "src/expression/MultivariateTranspose.birch"
    base_type_(x) {
  this->libbirch::Any::acyclic_();
}

#line 6 "src/expression/MultivariateTranspose.birch"
birch::type::Integer birch::type::MultivariateTranspose::doRows() {
  #line 6 "src/expression/MultivariateTranspose.birch"
  libbirch_function_("doRows", "src/expression/MultivariateTranspose.birch", 6);
  #line 7 "src/expression/MultivariateTranspose.birch"
  libbirch_line_(7);
  #line 7 "src/expression/MultivariateTranspose.birch"
  return this->y.value()->columns();
}

#line 10 "src/expression/MultivariateTranspose.birch"
birch::type::Integer birch::type::MultivariateTranspose::doColumns() {
  #line 10 "src/expression/MultivariateTranspose.birch"
  libbirch_function_("doColumns", "src/expression/MultivariateTranspose.birch", 10);
  #line 11 "src/expression/MultivariateTranspose.birch"
  libbirch_line_(11);
  #line 11 "src/expression/MultivariateTranspose.birch"
  return this->y.value()->rows();
}

#line 14 "src/expression/MultivariateTranspose.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MultivariateTranspose::doEvaluate(const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 14 "src/expression/MultivariateTranspose.birch"
  libbirch_function_("doEvaluate", "src/expression/MultivariateTranspose.birch", 14);
  #line 15 "src/expression/MultivariateTranspose.birch"
  libbirch_line_(15);
  #line 15 "src/expression/MultivariateTranspose.birch"
  return birch::transpose(y);
}

#line 18 "src/expression/MultivariateTranspose.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateTranspose::doEvaluateGrad(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 18 "src/expression/MultivariateTranspose.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/MultivariateTranspose.birch", 18);
  #line 20 "src/expression/MultivariateTranspose.birch"
  libbirch_line_(20);
  #line 20 "src/expression/MultivariateTranspose.birch"
  return birch::vec(d);
}

#line 27 "src/expression/MultivariateTranspose.birch"
libbirch::Shared<birch::type::MultivariateTranspose> birch::transpose(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y) {
  #line 27 "src/expression/MultivariateTranspose.birch"
  libbirch_function_("transpose", "src/expression/MultivariateTranspose.birch", 27);
  #line 28 "src/expression/MultivariateTranspose.birch"
  libbirch_line_(28);
  #line 28 "src/expression/MultivariateTranspose.birch"
  return birch::construct<libbirch::Shared<birch::type::MultivariateTranspose>>(y);
}

#line 4 "src/expression/Negate.birch"
birch::type::Negate::Negate(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) :
    #line 4 "src/expression/Negate.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 6 "src/expression/Negate.birch"
birch::type::Real birch::type::Negate::doEvaluate(const birch::type::Real& y) {
  #line 6 "src/expression/Negate.birch"
  libbirch_function_("doEvaluate", "src/expression/Negate.birch", 6);
  #line 7 "src/expression/Negate.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Negate.birch"
  return -(y);
}

#line 10 "src/expression/Negate.birch"
birch::type::Real birch::type::Negate::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y) {
  #line 10 "src/expression/Negate.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Negate.birch", 10);
  #line 11 "src/expression/Negate.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Negate.birch"
  return -(d);
}

#line 14 "src/expression/Negate.birch"
std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gaussian>>>> birch::type::Negate::graftLinearGaussian() {
  #line 14 "src/expression/Negate.birch"
  libbirch_function_("graftLinearGaussian", "src/expression/Negate.birch", 14);
  #line 15 "src/expression/Negate.birch"
  libbirch_line_(15);
  #line 15 "src/expression/Negate.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gaussian>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gaussian>>>>>();
  #line 16 "src/expression/Negate.birch"
  libbirch_line_(16);
  #line 16 "src/expression/Negate.birch"
  if (!(this->hasValue())) {
    #line 17 "src/expression/Negate.birch"
    libbirch_line_(17);
    #line 17 "src/expression/Negate.birch"
    std::optional<libbirch::Shared<birch::type::Gaussian>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::Gaussian>>>();
    #line 18 "src/expression/Negate.birch"
    libbirch_line_(18);
    #line 18 "src/expression/Negate.birch"
    if ((r = this->y.value()->graftLinearGaussian()).has_value()) {
      #line 19 "src/expression/Negate.birch"
      libbirch_line_(19);
      #line 19 "src/expression/Negate.birch"
      r.value()->negate();
    } else {
      #line 20 "src/expression/Negate.birch"
      libbirch_line_(20);
      #line 20 "src/expression/Negate.birch"
      if ((x1 = this->y.value()->graftGaussian()).has_value()) {
        #line 21 "src/expression/Negate.birch"
        libbirch_line_(21);
        #line 21 "src/expression/Negate.birch"
        r = birch::TransformLinear<libbirch::Shared<birch::type::Gaussian>>(birch::box(-(1.0)), x1.value(), birch::box(0.0));
      }
    }
  }
  #line 24 "src/expression/Negate.birch"
  libbirch_line_(24);
  #line 24 "src/expression/Negate.birch"
  return r;
}

#line 27 "src/expression/Negate.birch"
std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateGaussian>>>> birch::type::Negate::graftDotMultivariateGaussian() {
  #line 27 "src/expression/Negate.birch"
  libbirch_function_("graftDotMultivariateGaussian", "src/expression/Negate.birch", 27);
  #line 29 "src/expression/Negate.birch"
  libbirch_line_(29);
  #line 29 "src/expression/Negate.birch"
  std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateGaussian>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateGaussian>>>>>();
  #line 30 "src/expression/Negate.birch"
  libbirch_line_(30);
  #line 30 "src/expression/Negate.birch"
  if (!(this->hasValue())) {
    #line 31 "src/expression/Negate.birch"
    libbirch_line_(31);
    #line 31 "src/expression/Negate.birch"
    if ((r = this->y.value()->graftDotMultivariateGaussian()).has_value()) {
      #line 32 "src/expression/Negate.birch"
      libbirch_line_(32);
      #line 32 "src/expression/Negate.birch"
      r.value()->negate();
    }
  }
  #line 35 "src/expression/Negate.birch"
  libbirch_line_(35);
  #line 35 "src/expression/Negate.birch"
  return r;
}

#line 38 "src/expression/Negate.birch"
std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>>> birch::type::Negate::graftLinearNormalInverseGamma(const libbirch::Shared<birch::type::Distribution<birch::type::Real>>& compare) {
  #line 38 "src/expression/Negate.birch"
  libbirch_function_("graftLinearNormalInverseGamma", "src/expression/Negate.birch", 38);
  #line 40 "src/expression/Negate.birch"
  libbirch_line_(40);
  #line 40 "src/expression/Negate.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>>>>();
  #line 41 "src/expression/Negate.birch"
  libbirch_line_(41);
  #line 41 "src/expression/Negate.birch"
  if (!(this->hasValue())) {
    #line 42 "src/expression/Negate.birch"
    libbirch_line_(42);
    #line 42 "src/expression/Negate.birch"
    std::optional<libbirch::Shared<birch::type::NormalInverseGamma>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::NormalInverseGamma>>>();
    #line 43 "src/expression/Negate.birch"
    libbirch_line_(43);
    #line 43 "src/expression/Negate.birch"
    if ((r = this->y.value()->graftLinearNormalInverseGamma(compare)).has_value()) {
      #line 44 "src/expression/Negate.birch"
      libbirch_line_(44);
      #line 44 "src/expression/Negate.birch"
      r.value()->negate();
    } else {
      #line 45 "src/expression/Negate.birch"
      libbirch_line_(45);
      #line 45 "src/expression/Negate.birch"
      if ((x1 = this->y.value()->graftNormalInverseGamma(compare)).has_value()) {
        #line 46 "src/expression/Negate.birch"
        libbirch_line_(46);
        #line 46 "src/expression/Negate.birch"
        r = birch::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>(birch::box(-(1.0)), x1.value(), birch::box(0.0));
      }
    }
  }
  #line 49 "src/expression/Negate.birch"
  libbirch_line_(49);
  #line 49 "src/expression/Negate.birch"
  return r;
}

#line 52 "src/expression/Negate.birch"
std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>> birch::type::Negate::graftDotMultivariateNormalInverseGamma(const libbirch::Shared<birch::type::Distribution<birch::type::Real>>& compare) {
  #line 52 "src/expression/Negate.birch"
  libbirch_function_("graftDotMultivariateNormalInverseGamma", "src/expression/Negate.birch", 52);
  #line 54 "src/expression/Negate.birch"
  libbirch_line_(54);
  #line 54 "src/expression/Negate.birch"
  std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>();
  #line 55 "src/expression/Negate.birch"
  libbirch_line_(55);
  #line 55 "src/expression/Negate.birch"
  if (!(this->hasValue())) {
    #line 56 "src/expression/Negate.birch"
    libbirch_line_(56);
    #line 56 "src/expression/Negate.birch"
    if ((r = this->y.value()->graftDotMultivariateNormalInverseGamma(compare)).has_value()) {
      #line 57 "src/expression/Negate.birch"
      libbirch_line_(57);
      #line 57 "src/expression/Negate.birch"
      r.value()->negate();
    }
  }
  #line 60 "src/expression/Negate.birch"
  libbirch_line_(60);
  #line 60 "src/expression/Negate.birch"
  return r;
}

#line 67 "src/expression/Negate.birch"
libbirch::Shared<birch::type::Negate> birch::operator-(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) {
  #line 67 "src/expression/Negate.birch"
  libbirch_function_("-", "src/expression/Negate.birch", 67);
  #line 68 "src/expression/Negate.birch"
  libbirch_line_(68);
  #line 68 "src/expression/Negate.birch"
  return birch::construct<libbirch::Shared<birch::type::Negate>>(y);
}

#line 4 "src/expression/Outer.birch"
birch::type::Outer::Outer(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) :
    #line 4 "src/expression/Outer.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/Outer.birch"
birch::type::Integer birch::type::Outer::doRows() {
  #line 7 "src/expression/Outer.birch"
  libbirch_function_("doRows", "src/expression/Outer.birch", 7);
  #line 8 "src/expression/Outer.birch"
  libbirch_line_(8);
  #line 8 "src/expression/Outer.birch"
  return this->y.value()->rows();
}

#line 11 "src/expression/Outer.birch"
birch::type::Integer birch::type::Outer::doColumns() {
  #line 11 "src/expression/Outer.birch"
  libbirch_function_("doColumns", "src/expression/Outer.birch", 11);
  #line 12 "src/expression/Outer.birch"
  libbirch_line_(12);
  #line 12 "src/expression/Outer.birch"
  return this->z.value()->rows();
}

#line 15 "src/expression/Outer.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::Outer::doEvaluate(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 15 "src/expression/Outer.birch"
  libbirch_function_("doEvaluate", "src/expression/Outer.birch", 15);
  #line 16 "src/expression/Outer.birch"
  libbirch_line_(16);
  #line 16 "src/expression/Outer.birch"
  return birch::outer(y, z);
}

#line 19 "src/expression/Outer.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::Outer::doEvaluateGradLeft(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 19 "src/expression/Outer.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/Outer.birch", 19);
  #line 21 "src/expression/Outer.birch"
  libbirch_line_(21);
  #line 21 "src/expression/Outer.birch"
  return d * z;
}

#line 24 "src/expression/Outer.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::Outer::doEvaluateGradRight(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 24 "src/expression/Outer.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/Outer.birch", 24);
  #line 27 "src/expression/Outer.birch"
  libbirch_line_(27);
  #line 27 "src/expression/Outer.birch"
  return birch::transpose(d) * y;
}

#line 34 "src/expression/Outer.birch"
libbirch::Shared<birch::type::Outer> birch::outer(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) {
  #line 34 "src/expression/Outer.birch"
  libbirch_function_("outer", "src/expression/Outer.birch", 34);
  #line 35 "src/expression/Outer.birch"
  libbirch_line_(35);
  #line 35 "src/expression/Outer.birch"
  return birch::construct<libbirch::Shared<birch::type::Outer>>(y, z);
}

#line 41 "src/expression/Outer.birch"
libbirch::Shared<birch::type::Outer> birch::outer(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& z) {
  #line 41 "src/expression/Outer.birch"
  libbirch_function_("outer", "src/expression/Outer.birch", 41);
  #line 42 "src/expression/Outer.birch"
  libbirch_line_(42);
  #line 42 "src/expression/Outer.birch"
  return birch::outer(birch::box(y), z);
}

#line 48 "src/expression/Outer.birch"
libbirch::Shared<birch::type::Outer> birch::outer(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 48 "src/expression/Outer.birch"
  libbirch_function_("outer", "src/expression/Outer.birch", 48);
  #line 49 "src/expression/Outer.birch"
  libbirch_line_(49);
  #line 49 "src/expression/Outer.birch"
  return birch::outer(y, birch::box(z));
}

#line 55 "src/expression/Outer.birch"
libbirch::Shared<birch::type::Outer> birch::outer(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& y) {
  #line 55 "src/expression/Outer.birch"
  libbirch_function_("outer", "src/expression/Outer.birch", 55);
  #line 56 "src/expression/Outer.birch"
  libbirch_line_(56);
  #line 56 "src/expression/Outer.birch"
  return birch::outer(y, y);
}

#line 4 "src/expression/Pow.birch"
birch::type::Pow::Pow(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) :
    #line 4 "src/expression/Pow.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/Pow.birch"
birch::type::Real birch::type::Pow::doEvaluate(const birch::type::Real& y, const birch::type::Real& z) {
  #line 7 "src/expression/Pow.birch"
  libbirch_function_("doEvaluate", "src/expression/Pow.birch", 7);
  #line 8 "src/expression/Pow.birch"
  libbirch_line_(8);
  #line 8 "src/expression/Pow.birch"
  return birch::pow(y, z);
}

#line 11 "src/expression/Pow.birch"
birch::type::Real birch::type::Pow::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z) {
  #line 11 "src/expression/Pow.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/Pow.birch", 11);
  #line 12 "src/expression/Pow.birch"
  libbirch_line_(12);
  #line 12 "src/expression/Pow.birch"
  return d * z * birch::pow(y, z - 1.0);
}

#line 15 "src/expression/Pow.birch"
birch::type::Real birch::type::Pow::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z) {
  #line 15 "src/expression/Pow.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/Pow.birch", 15);
  #line 16 "src/expression/Pow.birch"
  libbirch_line_(16);
  #line 16 "src/expression/Pow.birch"
  if (y > 0.0) {
    #line 17 "src/expression/Pow.birch"
    libbirch_line_(17);
    #line 17 "src/expression/Pow.birch"
    return d * birch::pow(y, z) * birch::log(y);
  } else {
    #line 19 "src/expression/Pow.birch"
    libbirch_line_(19);
    #line 19 "src/expression/Pow.birch"
    return 0.0;
  }
}

#line 27 "src/expression/Pow.birch"
libbirch::Shared<birch::type::Pow> birch::pow(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 27 "src/expression/Pow.birch"
  libbirch_function_("pow", "src/expression/Pow.birch", 27);
  #line 28 "src/expression/Pow.birch"
  libbirch_line_(28);
  #line 28 "src/expression/Pow.birch"
  return birch::construct<libbirch::Shared<birch::type::Pow>>(y, z);
}

#line 34 "src/expression/Pow.birch"
libbirch::Shared<birch::type::Pow> birch::pow(const birch::type::Real& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 34 "src/expression/Pow.birch"
  libbirch_function_("pow", "src/expression/Pow.birch", 34);
  #line 35 "src/expression/Pow.birch"
  libbirch_line_(35);
  #line 35 "src/expression/Pow.birch"
  return birch::pow(birch::box(y), z);
}

#line 41 "src/expression/Pow.birch"
libbirch::Shared<birch::type::Pow> birch::pow(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const birch::type::Real& z) {
  #line 41 "src/expression/Pow.birch"
  libbirch_function_("pow", "src/expression/Pow.birch", 41);
  #line 42 "src/expression/Pow.birch"
  libbirch_line_(42);
  #line 42 "src/expression/Pow.birch"
  return birch::pow(y, birch::box(z));
}

#line 4 "src/expression/Rectify.birch"
birch::type::Rectify::Rectify(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) :
    #line 4 "src/expression/Rectify.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 6 "src/expression/Rectify.birch"
birch::type::Real birch::type::Rectify::doEvaluate(const birch::type::Real& y) {
  #line 6 "src/expression/Rectify.birch"
  libbirch_function_("doEvaluate", "src/expression/Rectify.birch", 6);
  #line 7 "src/expression/Rectify.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Rectify.birch"
  return birch::rectify(y);
}

#line 10 "src/expression/Rectify.birch"
birch::type::Real birch::type::Rectify::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y) {
  #line 10 "src/expression/Rectify.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Rectify.birch", 10);
  #line 11 "src/expression/Rectify.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Rectify.birch"
  if (x > 0.0) {
    #line 12 "src/expression/Rectify.birch"
    libbirch_line_(12);
    #line 12 "src/expression/Rectify.birch"
    return d;
  } else {
    #line 14 "src/expression/Rectify.birch"
    libbirch_line_(14);
    #line 14 "src/expression/Rectify.birch"
    return 0.0;
  }
}

#line 22 "src/expression/Rectify.birch"
libbirch::Shared<birch::type::Rectify> birch::rectify(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) {
  #line 22 "src/expression/Rectify.birch"
  libbirch_function_("rectify", "src/expression/Rectify.birch", 22);
  #line 23 "src/expression/Rectify.birch"
  libbirch_line_(23);
  #line 23 "src/expression/Rectify.birch"
  return birch::construct<libbirch::Shared<birch::type::Rectify>>(y);
}

#line 4 "src/expression/Sin.birch"
birch::type::Sin::Sin(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) :
    #line 4 "src/expression/Sin.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 6 "src/expression/Sin.birch"
birch::type::Real birch::type::Sin::doEvaluate(const birch::type::Real& y) {
  #line 6 "src/expression/Sin.birch"
  libbirch_function_("doEvaluate", "src/expression/Sin.birch", 6);
  #line 7 "src/expression/Sin.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Sin.birch"
  return birch::sin(y);
}

#line 10 "src/expression/Sin.birch"
birch::type::Real birch::type::Sin::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y) {
  #line 10 "src/expression/Sin.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Sin.birch", 10);
  #line 11 "src/expression/Sin.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Sin.birch"
  return d * birch::cos(y);
}

#line 18 "src/expression/Sin.birch"
libbirch::Shared<birch::type::Sin> birch::sin(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) {
  #line 18 "src/expression/Sin.birch"
  libbirch_function_("sin", "src/expression/Sin.birch", 18);
  #line 19 "src/expression/Sin.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Sin.birch"
  return birch::construct<libbirch::Shared<birch::type::Sin>>(y);
}

#line 4 "src/expression/Sinh.birch"
birch::type::Sinh::Sinh(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) :
    #line 4 "src/expression/Sinh.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 6 "src/expression/Sinh.birch"
birch::type::Real birch::type::Sinh::doEvaluate(const birch::type::Real& y) {
  #line 6 "src/expression/Sinh.birch"
  libbirch_function_("doEvaluate", "src/expression/Sinh.birch", 6);
  #line 7 "src/expression/Sinh.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Sinh.birch"
  return birch::sinh(y);
}

#line 10 "src/expression/Sinh.birch"
birch::type::Real birch::type::Sinh::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y) {
  #line 10 "src/expression/Sinh.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Sinh.birch", 10);
  #line 11 "src/expression/Sinh.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Sinh.birch"
  return d * birch::cosh(y);
}

#line 18 "src/expression/Sinh.birch"
libbirch::Shared<birch::type::Sinh> birch::sinh(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) {
  #line 18 "src/expression/Sinh.birch"
  libbirch_function_("sinh", "src/expression/Sinh.birch", 18);
  #line 19 "src/expression/Sinh.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Sinh.birch"
  return birch::construct<libbirch::Shared<birch::type::Sinh>>(y);
}

#line 4 "src/expression/Sqrt.birch"
birch::type::Sqrt::Sqrt(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) :
    #line 4 "src/expression/Sqrt.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 6 "src/expression/Sqrt.birch"
birch::type::Real birch::type::Sqrt::doEvaluate(const birch::type::Real& y) {
  #line 6 "src/expression/Sqrt.birch"
  libbirch_function_("doEvaluate", "src/expression/Sqrt.birch", 6);
  #line 7 "src/expression/Sqrt.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Sqrt.birch"
  return birch::sqrt(y);
}

#line 10 "src/expression/Sqrt.birch"
birch::type::Real birch::type::Sqrt::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y) {
  #line 10 "src/expression/Sqrt.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Sqrt.birch", 10);
  #line 11 "src/expression/Sqrt.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Sqrt.birch"
  return d * 0.5 / birch::sqrt(y);
}

#line 18 "src/expression/Sqrt.birch"
libbirch::Shared<birch::type::Sqrt> birch::sqrt(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 18 "src/expression/Sqrt.birch"
  libbirch_function_("sqrt", "src/expression/Sqrt.birch", 18);
  #line 19 "src/expression/Sqrt.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Sqrt.birch"
  return birch::construct<libbirch::Shared<birch::type::Sqrt>>(x);
}

#line 4 "src/expression/Subtract.birch"
birch::type::Subtract::Subtract(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) :
    #line 4 "src/expression/Subtract.birch"
    base_type_(y, z) {
  this->libbirch::Any::acyclic_();
}

#line 7 "src/expression/Subtract.birch"
birch::type::Real birch::type::Subtract::doEvaluate(const birch::type::Real& y, const birch::type::Real& z) {
  #line 7 "src/expression/Subtract.birch"
  libbirch_function_("doEvaluate", "src/expression/Subtract.birch", 7);
  #line 8 "src/expression/Subtract.birch"
  libbirch_line_(8);
  #line 8 "src/expression/Subtract.birch"
  return y - z;
}

#line 11 "src/expression/Subtract.birch"
birch::type::Real birch::type::Subtract::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z) {
  #line 11 "src/expression/Subtract.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/Subtract.birch", 11);
  #line 12 "src/expression/Subtract.birch"
  libbirch_line_(12);
  #line 12 "src/expression/Subtract.birch"
  return d;
}

#line 15 "src/expression/Subtract.birch"
birch::type::Real birch::type::Subtract::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z) {
  #line 15 "src/expression/Subtract.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/Subtract.birch", 15);
  #line 16 "src/expression/Subtract.birch"
  libbirch_line_(16);
  #line 16 "src/expression/Subtract.birch"
  return -(d);
}

#line 19 "src/expression/Subtract.birch"
std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gaussian>>>> birch::type::Subtract::graftLinearGaussian() {
  #line 19 "src/expression/Subtract.birch"
  libbirch_function_("graftLinearGaussian", "src/expression/Subtract.birch", 19);
  #line 20 "src/expression/Subtract.birch"
  libbirch_line_(20);
  #line 20 "src/expression/Subtract.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gaussian>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gaussian>>>>>();
  #line 21 "src/expression/Subtract.birch"
  libbirch_line_(21);
  #line 21 "src/expression/Subtract.birch"
  if (!(this->hasValue())) {
    #line 22 "src/expression/Subtract.birch"
    libbirch_line_(22);
    #line 22 "src/expression/Subtract.birch"
    std::optional<libbirch::Shared<birch::type::Gaussian>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::Gaussian>>>();
    #line 24 "src/expression/Subtract.birch"
    libbirch_line_(24);
    #line 24 "src/expression/Subtract.birch"
    if ((r = this->y.value()->graftLinearGaussian()).has_value()) {
      #line 25 "src/expression/Subtract.birch"
      libbirch_line_(25);
      #line 25 "src/expression/Subtract.birch"
      r.value()->add(-(this->z.value()));
    } else {
      #line 26 "src/expression/Subtract.birch"
      libbirch_line_(26);
      #line 26 "src/expression/Subtract.birch"
      if ((r = this->z.value()->graftLinearGaussian()).has_value()) {
        #line 27 "src/expression/Subtract.birch"
        libbirch_line_(27);
        #line 27 "src/expression/Subtract.birch"
        r.value()->negateAndAdd(this->y.value());
      } else {
        #line 28 "src/expression/Subtract.birch"
        libbirch_line_(28);
        #line 28 "src/expression/Subtract.birch"
        if ((x1 = this->y.value()->graftGaussian()).has_value()) {
          #line 29 "src/expression/Subtract.birch"
          libbirch_line_(29);
          #line 29 "src/expression/Subtract.birch"
          r = birch::TransformLinear<libbirch::Shared<birch::type::Gaussian>>(birch::box(1.0), x1.value(), -(this->z.value()));
        } else {
          #line 30 "src/expression/Subtract.birch"
          libbirch_line_(30);
          #line 30 "src/expression/Subtract.birch"
          if ((x1 = this->z.value()->graftGaussian()).has_value()) {
            #line 31 "src/expression/Subtract.birch"
            libbirch_line_(31);
            #line 31 "src/expression/Subtract.birch"
            r = birch::TransformLinear<libbirch::Shared<birch::type::Gaussian>>(birch::box(-(1.0)), x1.value(), this->y.value());
          }
        }
      }
    }
  }
  #line 34 "src/expression/Subtract.birch"
  libbirch_line_(34);
  #line 34 "src/expression/Subtract.birch"
  return r;
}

#line 37 "src/expression/Subtract.birch"
std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateGaussian>>>> birch::type::Subtract::graftDotMultivariateGaussian() {
  #line 37 "src/expression/Subtract.birch"
  libbirch_function_("graftDotMultivariateGaussian", "src/expression/Subtract.birch", 37);
  #line 39 "src/expression/Subtract.birch"
  libbirch_line_(39);
  #line 39 "src/expression/Subtract.birch"
  std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateGaussian>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateGaussian>>>>>();
  #line 40 "src/expression/Subtract.birch"
  libbirch_line_(40);
  #line 40 "src/expression/Subtract.birch"
  if (!(this->hasValue())) {
    #line 41 "src/expression/Subtract.birch"
    libbirch_line_(41);
    #line 41 "src/expression/Subtract.birch"
    if ((r = this->y.value()->graftDotMultivariateGaussian()).has_value()) {
      #line 42 "src/expression/Subtract.birch"
      libbirch_line_(42);
      #line 42 "src/expression/Subtract.birch"
      r.value()->add(-(this->z.value()));
    } else {
      #line 43 "src/expression/Subtract.birch"
      libbirch_line_(43);
      #line 43 "src/expression/Subtract.birch"
      if ((r = this->z.value()->graftDotMultivariateGaussian()).has_value()) {
        #line 44 "src/expression/Subtract.birch"
        libbirch_line_(44);
        #line 44 "src/expression/Subtract.birch"
        r.value()->negateAndAdd(this->y.value());
      }
    }
  }
  #line 47 "src/expression/Subtract.birch"
  libbirch_line_(47);
  #line 47 "src/expression/Subtract.birch"
  return r;
}

#line 50 "src/expression/Subtract.birch"
std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>>> birch::type::Subtract::graftLinearNormalInverseGamma(const libbirch::Shared<birch::type::Distribution<birch::type::Real>>& compare) {
  #line 50 "src/expression/Subtract.birch"
  libbirch_function_("graftLinearNormalInverseGamma", "src/expression/Subtract.birch", 50);
  #line 53 "src/expression/Subtract.birch"
  libbirch_line_(53);
  #line 53 "src/expression/Subtract.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>>>>();
  #line 54 "src/expression/Subtract.birch"
  libbirch_line_(54);
  #line 54 "src/expression/Subtract.birch"
  if (!(this->hasValue())) {
    #line 55 "src/expression/Subtract.birch"
    libbirch_line_(55);
    #line 55 "src/expression/Subtract.birch"
    std::optional<libbirch::Shared<birch::type::NormalInverseGamma>> x1 = libbirch::make<std::optional<libbirch::Shared<birch::type::NormalInverseGamma>>>();
    #line 57 "src/expression/Subtract.birch"
    libbirch_line_(57);
    #line 57 "src/expression/Subtract.birch"
    if ((r = this->y.value()->graftLinearNormalInverseGamma(compare)).has_value()) {
      #line 58 "src/expression/Subtract.birch"
      libbirch_line_(58);
      #line 58 "src/expression/Subtract.birch"
      r.value()->subtract(this->z.value());
    } else {
      #line 59 "src/expression/Subtract.birch"
      libbirch_line_(59);
      #line 59 "src/expression/Subtract.birch"
      if ((r = this->z.value()->graftLinearNormalInverseGamma(compare)).has_value()) {
        #line 60 "src/expression/Subtract.birch"
        libbirch_line_(60);
        #line 60 "src/expression/Subtract.birch"
        r.value()->negateAndAdd(this->y.value());
      } else {
        #line 61 "src/expression/Subtract.birch"
        libbirch_line_(61);
        #line 61 "src/expression/Subtract.birch"
        if ((x1 = this->y.value()->graftNormalInverseGamma(compare)).has_value()) {
          #line 62 "src/expression/Subtract.birch"
          libbirch_line_(62);
          #line 62 "src/expression/Subtract.birch"
          r = birch::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>(birch::box(1.0), x1.value(), -(this->z.value()));
        } else {
          #line 63 "src/expression/Subtract.birch"
          libbirch_line_(63);
          #line 63 "src/expression/Subtract.birch"
          if ((x1 = this->z.value()->graftNormalInverseGamma(compare)).has_value()) {
            #line 64 "src/expression/Subtract.birch"
            libbirch_line_(64);
            #line 64 "src/expression/Subtract.birch"
            r = birch::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>(birch::box(-(1.0)), x1.value(), this->y.value());
          }
        }
      }
    }
  }
  #line 67 "src/expression/Subtract.birch"
  libbirch_line_(67);
  #line 67 "src/expression/Subtract.birch"
  return r;
}

#line 70 "src/expression/Subtract.birch"
std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>> birch::type::Subtract::graftDotMultivariateNormalInverseGamma(const libbirch::Shared<birch::type::Distribution<birch::type::Real>>& compare) {
  #line 70 "src/expression/Subtract.birch"
  libbirch_function_("graftDotMultivariateNormalInverseGamma", "src/expression/Subtract.birch", 70);
  #line 73 "src/expression/Subtract.birch"
  libbirch_line_(73);
  #line 73 "src/expression/Subtract.birch"
  std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>> r = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>();
  #line 74 "src/expression/Subtract.birch"
  libbirch_line_(74);
  #line 74 "src/expression/Subtract.birch"
  if (!(this->hasValue())) {
    #line 75 "src/expression/Subtract.birch"
    libbirch_line_(75);
    #line 75 "src/expression/Subtract.birch"
    if ((r = this->y.value()->graftDotMultivariateNormalInverseGamma(compare)).has_value()) {
      #line 76 "src/expression/Subtract.birch"
      libbirch_line_(76);
      #line 76 "src/expression/Subtract.birch"
      r.value()->subtract(this->z.value());
    } else {
      #line 77 "src/expression/Subtract.birch"
      libbirch_line_(77);
      #line 77 "src/expression/Subtract.birch"
      if ((r = this->z.value()->graftDotMultivariateNormalInverseGamma(compare)).has_value()) {
        #line 78 "src/expression/Subtract.birch"
        libbirch_line_(78);
        #line 78 "src/expression/Subtract.birch"
        r.value()->negateAndAdd(this->y.value());
      }
    }
  }
  #line 81 "src/expression/Subtract.birch"
  libbirch_line_(81);
  #line 81 "src/expression/Subtract.birch"
  return r;
}

#line 88 "src/expression/Subtract.birch"
libbirch::Shared<birch::type::Subtract> birch::operator-(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 88 "src/expression/Subtract.birch"
  libbirch_function_("-", "src/expression/Subtract.birch", 88);
  #line 89 "src/expression/Subtract.birch"
  libbirch_line_(89);
  #line 89 "src/expression/Subtract.birch"
  return birch::construct<libbirch::Shared<birch::type::Subtract>>(y, z);
}

#line 95 "src/expression/Subtract.birch"
libbirch::Shared<birch::type::Subtract> birch::operator-(const birch::type::Real& y, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& z) {
  #line 95 "src/expression/Subtract.birch"
  libbirch_function_("-", "src/expression/Subtract.birch", 95);
  #line 96 "src/expression/Subtract.birch"
  libbirch_line_(96);
  #line 96 "src/expression/Subtract.birch"
  return birch::box(y) - z;
}

#line 102 "src/expression/Subtract.birch"
libbirch::Shared<birch::type::Subtract> birch::operator-(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y, const birch::type::Real& z) {
  #line 102 "src/expression/Subtract.birch"
  libbirch_function_("-", "src/expression/Subtract.birch", 102);
  #line 103 "src/expression/Subtract.birch"
  libbirch_line_(103);
  #line 103 "src/expression/Subtract.birch"
  return y - birch::box(z);
}

#line 4 "src/expression/Tan.birch"
birch::type::Tan::Tan(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) :
    #line 4 "src/expression/Tan.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 6 "src/expression/Tan.birch"
birch::type::Real birch::type::Tan::doEvaluate(const birch::type::Real& y) {
  #line 6 "src/expression/Tan.birch"
  libbirch_function_("doEvaluate", "src/expression/Tan.birch", 6);
  #line 7 "src/expression/Tan.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Tan.birch"
  return birch::tan(y);
}

#line 10 "src/expression/Tan.birch"
birch::type::Real birch::type::Tan::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y) {
  #line 10 "src/expression/Tan.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Tan.birch", 10);
  #line 11 "src/expression/Tan.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Tan.birch"
  return d * (1.0 + birch::pow(birch::tan(y), 2.0));
}

#line 18 "src/expression/Tan.birch"
libbirch::Shared<birch::type::Tan> birch::tan(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) {
  #line 18 "src/expression/Tan.birch"
  libbirch_function_("tan", "src/expression/Tan.birch", 18);
  #line 19 "src/expression/Tan.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Tan.birch"
  return birch::construct<libbirch::Shared<birch::type::Tan>>(y);
}

#line 4 "src/expression/Tanh.birch"
birch::type::Tanh::Tanh(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& y) :
    #line 4 "src/expression/Tanh.birch"
    base_type_(y) {
  this->libbirch::Any::acyclic_();
}

#line 6 "src/expression/Tanh.birch"
birch::type::Real birch::type::Tanh::doEvaluate(const birch::type::Real& y) {
  #line 6 "src/expression/Tanh.birch"
  libbirch_function_("doEvaluate", "src/expression/Tanh.birch", 6);
  #line 7 "src/expression/Tanh.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Tanh.birch"
  return birch::tanh(y);
}

#line 10 "src/expression/Tanh.birch"
birch::type::Real birch::type::Tanh::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y) {
  #line 10 "src/expression/Tanh.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Tanh.birch", 10);
  #line 11 "src/expression/Tanh.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Tanh.birch"
  return d * (1.0 + birch::pow(birch::tanh(y), 2.0));
}

#line 18 "src/expression/Tanh.birch"
libbirch::Shared<birch::type::Tanh> birch::tanh(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 18 "src/expression/Tanh.birch"
  libbirch_function_("tanh", "src/expression/Tanh.birch", 18);
  #line 19 "src/expression/Tanh.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Tanh.birch"
  return birch::construct<libbirch::Shared<birch::type::Tanh>>(x);
}

#line 19 "src/expression/Trace.birch"
libbirch::Shared<birch::type::Trace<libbirch::Shared<birch::type::Expression<birch::type::LLT>>, birch::type::LLT>> birch::trace(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& y) {
  #line 19 "src/expression/Trace.birch"
  libbirch_function_("trace", "src/expression/Trace.birch", 19);
  #line 20 "src/expression/Trace.birch"
  libbirch_line_(20);
  #line 20 "src/expression/Trace.birch"
  return birch::construct<libbirch::Shared<birch::type::Trace<libbirch::Shared<birch::type::Expression<birch::type::LLT>>, birch::type::LLT>>>(y);
}

#line 26 "src/expression/Trace.birch"
libbirch::Shared<birch::type::Trace<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::DefaultArray<birch::type::Real,2>>> birch::trace(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& y) {
  #line 26 "src/expression/Trace.birch"
  libbirch_function_("trace", "src/expression/Trace.birch", 26);
  #line 28 "src/expression/Trace.birch"
  libbirch_line_(28);
  #line 28 "src/expression/Trace.birch"
  return birch::construct<libbirch::Shared<birch::type::Trace<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::DefaultArray<birch::type::Real,2>>>>(y);
}

