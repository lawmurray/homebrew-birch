#line 4 "src/expression/Acos.birch"
birch::type::Acos::Acos(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/Acos.birch"
    super_type_(y) {
  //
}

#line 6 "src/expression/Acos.birch"
birch::type::Real birch::type::Acos::doEvaluate(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 6 "src/expression/Acos.birch"
  libbirch_function_("doEvaluate", "src/expression/Acos.birch", 6);
  #line 7 "src/expression/Acos.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Acos.birch"
  return birch::acos(y, handler_);
}

#line 10 "src/expression/Acos.birch"
birch::type::Real birch::type::Acos::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/expression/Acos.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Acos.birch", 10);
  #line 11 "src/expression/Acos.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Acos.birch"
  return -d / birch::sqrt(1.0 - y * y, handler_);
}

#line 18 "src/expression/Acos.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Acos>> birch::acos(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/expression/Acos.birch"
  libbirch_function_("acos", "src/expression/Acos.birch", 18);
  #line 19 "src/expression/Acos.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Acos.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Acos>>>(y, handler_);
}

#line 4 "src/expression/Add.birch"
birch::type::Add::Add(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/Add.birch"
    super_type_(y, z) {
  //
}

#line 7 "src/expression/Add.birch"
birch::type::Real birch::type::Add::doEvaluate(const birch::type::Real& y, const birch::type::Real& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/Add.birch"
  libbirch_function_("doEvaluate", "src/expression/Add.birch", 7);
  #line 8 "src/expression/Add.birch"
  libbirch_line_(8);
  #line 8 "src/expression/Add.birch"
  return y + z;
}

#line 11 "src/expression/Add.birch"
birch::type::Real birch::type::Add::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/Add.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/Add.birch", 11);
  #line 13 "src/expression/Add.birch"
  libbirch_line_(13);
  #line 13 "src/expression/Add.birch"
  return d;
}

#line 16 "src/expression/Add.birch"
birch::type::Real birch::type::Add::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/expression/Add.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/Add.birch", 16);
  #line 18 "src/expression/Add.birch"
  libbirch_line_(18);
  #line 18 "src/expression/Add.birch"
  return d;
}

#line 21 "src/expression/Add.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>>>>> birch::type::Add::graftLinearGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "src/expression/Add.birch"
  libbirch_function_("graftLinearGaussian", "src/expression/Add.birch", 21);
  #line 22 "src/expression/Add.birch"
  libbirch_line_(22);
  #line 22 "src/expression/Add.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>>>>> r;
  #line 23 "src/expression/Add.birch"
  libbirch_line_(23);
  #line 23 "src/expression/Add.birch"
  if (!this_()->hasValue(handler_)) {
    #line 24 "src/expression/Add.birch"
    libbirch_line_(24);
    #line 24 "src/expression/Add.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>> x1;
    #line 26 "src/expression/Add.birch"
    libbirch_line_(26);
    #line 26 "src/expression/Add.birch"
    if ((r = this_()->y.get()->graftLinearGaussian(handler_)).query()) {
      #line 27 "src/expression/Add.birch"
      libbirch_line_(27);
      #line 27 "src/expression/Add.birch"
      r.get()->add(this_()->z.get(), handler_);
    } else {
      #line 28 "src/expression/Add.birch"
      libbirch_line_(28);
      #line 28 "src/expression/Add.birch"
      if ((r = this_()->z.get()->graftLinearGaussian(handler_)).query()) {
        #line 29 "src/expression/Add.birch"
        libbirch_line_(29);
        #line 29 "src/expression/Add.birch"
        r.get()->add(this_()->y.get(), handler_);
      } else {
        #line 30 "src/expression/Add.birch"
        libbirch_line_(30);
        #line 30 "src/expression/Add.birch"
        if ((x1 = this_()->y.get()->graftGaussian(handler_)).query()) {
          #line 31 "src/expression/Add.birch"
          libbirch_line_(31);
          #line 31 "src/expression/Add.birch"
          r = birch::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>>(birch::box(1.0, handler_), x1.get(), this_()->z.get(), handler_);
        } else {
          #line 32 "src/expression/Add.birch"
          libbirch_line_(32);
          #line 32 "src/expression/Add.birch"
          if ((x1 = this_()->z.get()->graftGaussian(handler_)).query()) {
            #line 33 "src/expression/Add.birch"
            libbirch_line_(33);
            #line 33 "src/expression/Add.birch"
            r = birch::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>>(birch::box(1.0, handler_), x1.get(), this_()->y.get(), handler_);
          }
        }
      }
    }
  }
  #line 36 "src/expression/Add.birch"
  libbirch_line_(36);
  #line 36 "src/expression/Add.birch"
  return r;
}

#line 39 "src/expression/Add.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> birch::type::Add::graftDotGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/expression/Add.birch"
  libbirch_function_("graftDotGaussian", "src/expression/Add.birch", 39);
  #line 40 "src/expression/Add.birch"
  libbirch_line_(40);
  #line 40 "src/expression/Add.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> r;
  #line 41 "src/expression/Add.birch"
  libbirch_line_(41);
  #line 41 "src/expression/Add.birch"
  if (!this_()->hasValue(handler_)) {
    #line 42 "src/expression/Add.birch"
    libbirch_line_(42);
    #line 42 "src/expression/Add.birch"
    if ((r = this_()->y.get()->graftDotGaussian(handler_)).query()) {
      #line 43 "src/expression/Add.birch"
      libbirch_line_(43);
      #line 43 "src/expression/Add.birch"
      r.get()->add(this_()->z.get(), handler_);
    } else {
      #line 44 "src/expression/Add.birch"
      libbirch_line_(44);
      #line 44 "src/expression/Add.birch"
      if ((r = this_()->z.get()->graftDotGaussian(handler_)).query()) {
        #line 45 "src/expression/Add.birch"
        libbirch_line_(45);
        #line 45 "src/expression/Add.birch"
        r.get()->add(this_()->y.get(), handler_);
      }
    }
  }
  #line 48 "src/expression/Add.birch"
  libbirch_line_(48);
  #line 48 "src/expression/Add.birch"
  return r;
}

#line 51 "src/expression/Add.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>>>>> birch::type::Add::graftLinearNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 51 "src/expression/Add.birch"
  libbirch_function_("graftLinearNormalInverseGamma", "src/expression/Add.birch", 51);
  #line 53 "src/expression/Add.birch"
  libbirch_line_(53);
  #line 53 "src/expression/Add.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>>>>> r;
  #line 54 "src/expression/Add.birch"
  libbirch_line_(54);
  #line 54 "src/expression/Add.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>> x1;
  #line 55 "src/expression/Add.birch"
  libbirch_line_(55);
  #line 55 "src/expression/Add.birch"
  if (!this_()->hasValue(handler_)) {
    #line 56 "src/expression/Add.birch"
    libbirch_line_(56);
    #line 56 "src/expression/Add.birch"
    if ((r = this_()->y.get()->graftLinearNormalInverseGamma(compare, handler_)).query()) {
      #line 57 "src/expression/Add.birch"
      libbirch_line_(57);
      #line 57 "src/expression/Add.birch"
      r.get()->add(this_()->z.get(), handler_);
    } else {
      #line 58 "src/expression/Add.birch"
      libbirch_line_(58);
      #line 58 "src/expression/Add.birch"
      if ((r = this_()->z.get()->graftLinearNormalInverseGamma(compare, handler_)).query()) {
        #line 59 "src/expression/Add.birch"
        libbirch_line_(59);
        #line 59 "src/expression/Add.birch"
        r.get()->add(this_()->y.get(), handler_);
      } else {
        #line 60 "src/expression/Add.birch"
        libbirch_line_(60);
        #line 60 "src/expression/Add.birch"
        if ((x1 = this_()->y.get()->graftNormalInverseGamma(compare, handler_)).query()) {
          #line 61 "src/expression/Add.birch"
          libbirch_line_(61);
          #line 61 "src/expression/Add.birch"
          r = birch::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>>(birch::box(1.0, handler_), x1.get(), this_()->z.get(), handler_);
        } else {
          #line 62 "src/expression/Add.birch"
          libbirch_line_(62);
          #line 62 "src/expression/Add.birch"
          if ((x1 = this_()->z.get()->graftNormalInverseGamma(compare, handler_)).query()) {
            #line 63 "src/expression/Add.birch"
            libbirch_line_(63);
            #line 63 "src/expression/Add.birch"
            r = birch::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>>(birch::box(1.0, handler_), x1.get(), this_()->y.get(), handler_);
          }
        }
      }
    }
  }
  #line 66 "src/expression/Add.birch"
  libbirch_line_(66);
  #line 66 "src/expression/Add.birch"
  return r;
}

#line 69 "src/expression/Add.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> birch::type::Add::graftDotNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "src/expression/Add.birch"
  libbirch_function_("graftDotNormalInverseGamma", "src/expression/Add.birch", 69);
  #line 71 "src/expression/Add.birch"
  libbirch_line_(71);
  #line 71 "src/expression/Add.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> r;
  #line 72 "src/expression/Add.birch"
  libbirch_line_(72);
  #line 72 "src/expression/Add.birch"
  if (!this_()->hasValue(handler_)) {
    #line 73 "src/expression/Add.birch"
    libbirch_line_(73);
    #line 73 "src/expression/Add.birch"
    if ((r = this_()->y.get()->graftDotNormalInverseGamma(compare, handler_)).query()) {
      #line 74 "src/expression/Add.birch"
      libbirch_line_(74);
      #line 74 "src/expression/Add.birch"
      r.get()->add(this_()->z.get(), handler_);
    } else {
      #line 75 "src/expression/Add.birch"
      libbirch_line_(75);
      #line 75 "src/expression/Add.birch"
      if ((r = this_()->z.get()->graftDotNormalInverseGamma(compare, handler_)).query()) {
        #line 76 "src/expression/Add.birch"
        libbirch_line_(76);
        #line 76 "src/expression/Add.birch"
        r.get()->add(this_()->y.get(), handler_);
      }
    }
  }
  #line 79 "src/expression/Add.birch"
  libbirch_line_(79);
  #line 79 "src/expression/Add.birch"
  return r;
}

#line 86 "src/expression/Add.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Add>> birch::operator+(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z) {
  #line 86 "src/expression/Add.birch"
  libbirch_function_("+", "src/expression/Add.birch", 86);
  #line 87 "src/expression/Add.birch"
  libbirch_line_(87);
  #line 87 "src/expression/Add.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Add>>>(y, z);
}

#line 93 "src/expression/Add.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Add>> birch::operator+(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z) {
  #line 93 "src/expression/Add.birch"
  libbirch_function_("+", "src/expression/Add.birch", 93);
  #line 94 "src/expression/Add.birch"
  libbirch_line_(94);
  #line 94 "src/expression/Add.birch"
  return birch::box(y) + z;
}

#line 100 "src/expression/Add.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Add>> birch::operator+(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const birch::type::Real& z) {
  #line 100 "src/expression/Add.birch"
  libbirch_function_("+", "src/expression/Add.birch", 100);
  #line 101 "src/expression/Add.birch"
  libbirch_line_(101);
  #line 101 "src/expression/Add.birch"
  return y + birch::box(z);
}

#line 4 "src/expression/Asin.birch"
birch::type::Asin::Asin(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/Asin.birch"
    super_type_(y) {
  //
}

#line 6 "src/expression/Asin.birch"
birch::type::Real birch::type::Asin::doEvaluate(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 6 "src/expression/Asin.birch"
  libbirch_function_("doEvaluate", "src/expression/Asin.birch", 6);
  #line 7 "src/expression/Asin.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Asin.birch"
  return birch::asin(y, handler_);
}

#line 10 "src/expression/Asin.birch"
birch::type::Real birch::type::Asin::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/expression/Asin.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Asin.birch", 10);
  #line 11 "src/expression/Asin.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Asin.birch"
  return d / birch::sqrt(1.0 - y * y, handler_);
}

#line 18 "src/expression/Asin.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Asin>> birch::asin(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/expression/Asin.birch"
  libbirch_function_("asin", "src/expression/Asin.birch", 18);
  #line 19 "src/expression/Asin.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Asin.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Asin>>>(y, handler_);
}

#line 4 "src/expression/Atan.birch"
birch::type::Atan::Atan(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/Atan.birch"
    super_type_(y) {
  //
}

#line 6 "src/expression/Atan.birch"
birch::type::Real birch::type::Atan::doEvaluate(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 6 "src/expression/Atan.birch"
  libbirch_function_("doEvaluate", "src/expression/Atan.birch", 6);
  #line 7 "src/expression/Atan.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Atan.birch"
  return birch::atan(y, handler_);
}

#line 10 "src/expression/Atan.birch"
birch::type::Real birch::type::Atan::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/expression/Atan.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Atan.birch", 10);
  #line 11 "src/expression/Atan.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Atan.birch"
  return d / (1.0 + y * y);
}

#line 18 "src/expression/Atan.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Atan>> birch::atan(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/expression/Atan.birch"
  libbirch_function_("atan", "src/expression/Atan.birch", 18);
  #line 19 "src/expression/Atan.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Atan.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Atan>>>(y, handler_);
}

#line 4 "src/expression/CopySign.birch"
birch::type::CopySign::CopySign(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/CopySign.birch"
    super_type_(y, z) {
  //
}

#line 7 "src/expression/CopySign.birch"
birch::type::Real birch::type::CopySign::doEvaluate(const birch::type::Real& y, const birch::type::Real& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/CopySign.birch"
  libbirch_function_("doEvaluate", "src/expression/CopySign.birch", 7);
  #line 8 "src/expression/CopySign.birch"
  libbirch_line_(8);
  #line 8 "src/expression/CopySign.birch"
  return birch::copysign(y, z, handler_);
}

#line 11 "src/expression/CopySign.birch"
birch::type::Real birch::type::CopySign::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/CopySign.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/CopySign.birch", 11);
  #line 13 "src/expression/CopySign.birch"
  libbirch_line_(13);
  #line 13 "src/expression/CopySign.birch"
  if (x == y) {
    #line 14 "src/expression/CopySign.birch"
    libbirch_line_(14);
    #line 14 "src/expression/CopySign.birch"
    return d;
  } else {
    #line 16 "src/expression/CopySign.birch"
    libbirch_line_(16);
    #line 16 "src/expression/CopySign.birch"
    return -d;
  }
}

#line 20 "src/expression/CopySign.birch"
birch::type::Real birch::type::CopySign::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/expression/CopySign.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/CopySign.birch", 20);
  #line 22 "src/expression/CopySign.birch"
  libbirch_line_(22);
  #line 22 "src/expression/CopySign.birch"
  return 0.0;
}

#line 29 "src/expression/CopySign.birch"
libbirch::Lazy<libbirch::Shared<birch::type::CopySign>> birch::copysign(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "src/expression/CopySign.birch"
  libbirch_function_("copysign", "src/expression/CopySign.birch", 29);
  #line 30 "src/expression/CopySign.birch"
  libbirch_line_(30);
  #line 30 "src/expression/CopySign.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::CopySign>>>(y, z, handler_);
}

#line 36 "src/expression/CopySign.birch"
libbirch::Lazy<libbirch::Shared<birch::type::CopySign>> birch::copysign(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/expression/CopySign.birch"
  libbirch_function_("copysign", "src/expression/CopySign.birch", 36);
  #line 37 "src/expression/CopySign.birch"
  libbirch_line_(37);
  #line 37 "src/expression/CopySign.birch"
  return birch::copysign(birch::box(y, handler_), z, handler_);
}

#line 43 "src/expression/CopySign.birch"
libbirch::Lazy<libbirch::Shared<birch::type::CopySign>> birch::copysign(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const birch::type::Real& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "src/expression/CopySign.birch"
  libbirch_function_("copysign", "src/expression/CopySign.birch", 43);
  #line 44 "src/expression/CopySign.birch"
  libbirch_line_(44);
  #line 44 "src/expression/CopySign.birch"
  return birch::copysign(y, birch::box(z, handler_), handler_);
}

#line 18 "src/expression/Cast.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::Real(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/expression/Cast.birch"
  libbirch_function_("Real", "src/expression/Cast.birch", 18);
  #line 19 "src/expression/Cast.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Cast.birch"
  return y;
}

#line 25 "src/expression/Cast.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Cast<birch::type::Integer, birch::type::Real>>> birch::Real(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/expression/Cast.birch"
  libbirch_function_("Real", "src/expression/Cast.birch", 25);
  #line 26 "src/expression/Cast.birch"
  libbirch_line_(26);
  #line 26 "src/expression/Cast.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Cast<birch::type::Integer, birch::type::Real>>>>(y, handler_);
}

#line 32 "src/expression/Cast.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Cast<birch::type::Boolean, birch::type::Real>>> birch::Real(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Boolean>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/expression/Cast.birch"
  libbirch_function_("Real", "src/expression/Cast.birch", 32);
  #line 33 "src/expression/Cast.birch"
  libbirch_line_(33);
  #line 33 "src/expression/Cast.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Cast<birch::type::Boolean, birch::type::Real>>>>(y, handler_);
}

#line 4 "src/expression/Cos.birch"
birch::type::Cos::Cos(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/Cos.birch"
    super_type_(y) {
  //
}

#line 6 "src/expression/Cos.birch"
birch::type::Real birch::type::Cos::doEvaluate(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 6 "src/expression/Cos.birch"
  libbirch_function_("doEvaluate", "src/expression/Cos.birch", 6);
  #line 7 "src/expression/Cos.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Cos.birch"
  return birch::cos(y, handler_);
}

#line 10 "src/expression/Cos.birch"
birch::type::Real birch::type::Cos::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/expression/Cos.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Cos.birch", 10);
  #line 11 "src/expression/Cos.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Cos.birch"
  return -d * birch::sin(y, handler_);
}

#line 18 "src/expression/Cos.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Cos>> birch::cos(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/expression/Cos.birch"
  libbirch_function_("cos", "src/expression/Cos.birch", 18);
  #line 19 "src/expression/Cos.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Cos.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Cos>>>(y, handler_);
}

#line 4 "src/expression/Cosh.birch"
birch::type::Cosh::Cosh(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/Cosh.birch"
    super_type_(y) {
  //
}

#line 6 "src/expression/Cosh.birch"
birch::type::Real birch::type::Cosh::doEvaluate(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 6 "src/expression/Cosh.birch"
  libbirch_function_("doEvaluate", "src/expression/Cosh.birch", 6);
  #line 7 "src/expression/Cosh.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Cosh.birch"
  return birch::cosh(y, handler_);
}

#line 10 "src/expression/Cosh.birch"
birch::type::Real birch::type::Cosh::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/expression/Cosh.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Cosh.birch", 10);
  #line 11 "src/expression/Cosh.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Cosh.birch"
  return -d * birch::sinh(y, handler_);
}

#line 18 "src/expression/Cosh.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Cosh>> birch::cosh(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/expression/Cosh.birch"
  libbirch_function_("cosh", "src/expression/Cosh.birch", 18);
  #line 19 "src/expression/Cosh.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Cosh.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Cosh>>>(x, handler_);
}

#line 6 "src/expression/DelayExpression.birch"
birch::type::DelayExpression::DelayExpression(const birch::type::Boolean& isConstant, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 6 "src/expression/DelayExpression.birch"
    super_type_(),
    #line 13 "src/expression/DelayExpression.birch"
    generation(birch::type::Integer(0)),
    #line 18 "src/expression/DelayExpression.birch"
    pilotCount(birch::type::Integer(0)),
    #line 27 "src/expression/DelayExpression.birch"
    gradCount(birch::type::Integer(0)),
    #line 33 "src/expression/DelayExpression.birch"
    flagConstant(isConstant),
    #line 39 "src/expression/DelayExpression.birch"
    flagPrior(false) {
  //
}

#line 44 "src/expression/DelayExpression.birch"
birch::type::Boolean birch::type::DelayExpression::isRandom(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/expression/DelayExpression.birch"
  libbirch_function_("isRandom", "src/expression/DelayExpression.birch", 44);
  #line 45 "src/expression/DelayExpression.birch"
  libbirch_line_(45);
  #line 45 "src/expression/DelayExpression.birch"
  return false;
}

#line 51 "src/expression/DelayExpression.birch"
birch::type::Boolean birch::type::DelayExpression::isConstant(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 51 "src/expression/DelayExpression.birch"
  libbirch_function_("isConstant", "src/expression/DelayExpression.birch", 51);
  #line 52 "src/expression/DelayExpression.birch"
  libbirch_line_(52);
  #line 52 "src/expression/DelayExpression.birch"
  return this_()->flagConstant;
}

#line 58 "src/expression/DelayExpression.birch"
birch::type::Integer birch::type::DelayExpression::length(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "src/expression/DelayExpression.birch"
  libbirch_function_("length", "src/expression/DelayExpression.birch", 58);
  #line 59 "src/expression/DelayExpression.birch"
  libbirch_line_(59);
  #line 59 "src/expression/DelayExpression.birch"
  return this_()->rows(handler_);
}

#line 84 "src/expression/DelayExpression.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::DelayExpression::prior(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 84 "src/expression/DelayExpression.birch"
  libbirch_function_("prior", "src/expression/DelayExpression.birch", 84);
  #line 85 "src/expression/DelayExpression.birch"
  libbirch_line_(85);
  #line 85 "src/expression/DelayExpression.birch"
  if (!this_()->flagPrior) {
    #line 86 "src/expression/DelayExpression.birch"
    libbirch_line_(86);
    #line 86 "src/expression/DelayExpression.birch"
    this_()->flagPrior = true;
    #line 87 "src/expression/DelayExpression.birch"
    libbirch_line_(87);
    #line 87 "src/expression/DelayExpression.birch"
    return this_()->doPrior(handler_);
  } else {
    #line 89 "src/expression/DelayExpression.birch"
    libbirch_line_(89);
    #line 89 "src/expression/DelayExpression.birch"
    return libbirch::nil;
  }
}

#line 99 "src/expression/DelayExpression.birch"
birch::type::Integer birch::length(const libbirch::Lazy<libbirch::Shared<birch::type::DelayExpression>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 99 "src/expression/DelayExpression.birch"
  libbirch_function_("length", "src/expression/DelayExpression.birch", 99);
  #line 100 "src/expression/DelayExpression.birch"
  libbirch_line_(100);
  #line 100 "src/expression/DelayExpression.birch"
  return x->length(handler_);
}

#line 106 "src/expression/DelayExpression.birch"
birch::type::Integer birch::rows(const libbirch::Lazy<libbirch::Shared<birch::type::DelayExpression>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 106 "src/expression/DelayExpression.birch"
  libbirch_function_("rows", "src/expression/DelayExpression.birch", 106);
  #line 107 "src/expression/DelayExpression.birch"
  libbirch_line_(107);
  #line 107 "src/expression/DelayExpression.birch"
  return x->rows(handler_);
}

#line 113 "src/expression/DelayExpression.birch"
birch::type::Integer birch::columns(const libbirch::Lazy<libbirch::Shared<birch::type::DelayExpression>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 113 "src/expression/DelayExpression.birch"
  libbirch_function_("columns", "src/expression/DelayExpression.birch", 113);
  #line 114 "src/expression/DelayExpression.birch"
  libbirch_line_(114);
  #line 114 "src/expression/DelayExpression.birch"
  return x->columns(handler_);
}

#line 4 "src/expression/Diagonal.birch"
birch::type::Diagonal::Diagonal(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const birch::type::Integer& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/Diagonal.birch"
    super_type_(y),
    #line 9 "src/expression/Diagonal.birch"
    z(z) {
  //
}

#line 11 "src/expression/Diagonal.birch"
birch::type::Integer birch::type::Diagonal::doRows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/Diagonal.birch"
  libbirch_function_("doRows", "src/expression/Diagonal.birch", 11);
  #line 12 "src/expression/Diagonal.birch"
  libbirch_line_(12);
  #line 12 "src/expression/Diagonal.birch"
  return this_()->z;
}

#line 15 "src/expression/Diagonal.birch"
birch::type::Integer birch::type::Diagonal::doColumns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/expression/Diagonal.birch"
  libbirch_function_("doColumns", "src/expression/Diagonal.birch", 15);
  #line 16 "src/expression/Diagonal.birch"
  libbirch_line_(16);
  #line 16 "src/expression/Diagonal.birch"
  return this_()->z;
}

#line 19 "src/expression/Diagonal.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::Diagonal::doEvaluate(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/expression/Diagonal.birch"
  libbirch_function_("doEvaluate", "src/expression/Diagonal.birch", 19);
  #line 20 "src/expression/Diagonal.birch"
  libbirch_line_(20);
  #line 20 "src/expression/Diagonal.birch"
  return birch::diagonal(y, this_()->z, handler_);
}

#line 23 "src/expression/Diagonal.birch"
birch::type::Real birch::type::Diagonal::doEvaluateGrad(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "src/expression/Diagonal.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Diagonal.birch", 23);
  #line 24 "src/expression/Diagonal.birch"
  libbirch_line_(24);
  #line 24 "src/expression/Diagonal.birch"
  return birch::trace(d, handler_);
}

#line 31 "src/expression/Diagonal.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Diagonal>> birch::diagonal(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const birch::type::Integer& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "src/expression/Diagonal.birch"
  libbirch_function_("diagonal", "src/expression/Diagonal.birch", 31);
  #line 32 "src/expression/Diagonal.birch"
  libbirch_line_(32);
  #line 32 "src/expression/Diagonal.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Diagonal>>>(y, z, handler_);
}

#line 4 "src/expression/DiscreteAdd.birch"
birch::type::DiscreteAdd::DiscreteAdd(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/DiscreteAdd.birch"
    super_type_(y, z) {
  //
}

#line 7 "src/expression/DiscreteAdd.birch"
birch::type::Integer birch::type::DiscreteAdd::doEvaluate(const birch::type::Integer& y, const birch::type::Integer& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/DiscreteAdd.birch"
  libbirch_function_("doEvaluate", "src/expression/DiscreteAdd.birch", 7);
  #line 8 "src/expression/DiscreteAdd.birch"
  libbirch_line_(8);
  #line 8 "src/expression/DiscreteAdd.birch"
  return y + z;
}

#line 11 "src/expression/DiscreteAdd.birch"
birch::type::Real birch::type::DiscreteAdd::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Integer& x, const birch::type::Integer& y, const birch::type::Integer& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/DiscreteAdd.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/DiscreteAdd.birch", 11);
  #line 13 "src/expression/DiscreteAdd.birch"
  libbirch_line_(13);
  #line 13 "src/expression/DiscreteAdd.birch"
  return d;
}

#line 16 "src/expression/DiscreteAdd.birch"
birch::type::Real birch::type::DiscreteAdd::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Integer& x, const birch::type::Integer& y, const birch::type::Integer& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/expression/DiscreteAdd.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/DiscreteAdd.birch", 16);
  #line 18 "src/expression/DiscreteAdd.birch"
  libbirch_line_(18);
  #line 18 "src/expression/DiscreteAdd.birch"
  return d;
}

#line 21 "src/expression/DiscreteAdd.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>> birch::type::DiscreteAdd::graftDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "src/expression/DiscreteAdd.birch"
  libbirch_function_("graftDiscrete", "src/expression/DiscreteAdd.birch", 21);
  #line 22 "src/expression/DiscreteAdd.birch"
  libbirch_line_(22);
  #line 22 "src/expression/DiscreteAdd.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>> r;
  #line 23 "src/expression/DiscreteAdd.birch"
  libbirch_line_(23);
  #line 23 "src/expression/DiscreteAdd.birch"
  if (!this_()->hasValue(handler_)) {
    #line 24 "src/expression/DiscreteAdd.birch"
    libbirch_line_(24);
    #line 24 "src/expression/DiscreteAdd.birch"
    r = this_()->graftBoundedDiscrete(handler_);
    #line 25 "src/expression/DiscreteAdd.birch"
    libbirch_line_(25);
    #line 25 "src/expression/DiscreteAdd.birch"
    if (!r.query()) {
      #line 26 "src/expression/DiscreteAdd.birch"
      libbirch_line_(26);
      #line 26 "src/expression/DiscreteAdd.birch"
      libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>> x1;
      #line 27 "src/expression/DiscreteAdd.birch"
      libbirch_line_(27);
      #line 27 "src/expression/DiscreteAdd.birch"
      if ((x1 = this_()->y.get()->graftDiscrete(handler_)).query()) {
        #line 28 "src/expression/DiscreteAdd.birch"
        libbirch_line_(28);
        #line 28 "src/expression/DiscreteAdd.birch"
        r = birch::LinearDiscrete(birch::box(birch::type::Integer(1), handler_), x1.get(), this_()->z.get(), handler_);
      } else {
        #line 29 "src/expression/DiscreteAdd.birch"
        libbirch_line_(29);
        #line 29 "src/expression/DiscreteAdd.birch"
        if ((x1 = this_()->z.get()->graftDiscrete(handler_)).query()) {
          #line 30 "src/expression/DiscreteAdd.birch"
          libbirch_line_(30);
          #line 30 "src/expression/DiscreteAdd.birch"
          r = birch::LinearDiscrete(birch::box(birch::type::Integer(1), handler_), x1.get(), this_()->y.get(), handler_);
        }
      }
    }
  }
  #line 34 "src/expression/DiscreteAdd.birch"
  libbirch_line_(34);
  #line 34 "src/expression/DiscreteAdd.birch"
  return r;
}

#line 37 "src/expression/DiscreteAdd.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>> birch::type::DiscreteAdd::graftBoundedDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/expression/DiscreteAdd.birch"
  libbirch_function_("graftBoundedDiscrete", "src/expression/DiscreteAdd.birch", 37);
  #line 38 "src/expression/DiscreteAdd.birch"
  libbirch_line_(38);
  #line 38 "src/expression/DiscreteAdd.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>> r;
  #line 39 "src/expression/DiscreteAdd.birch"
  libbirch_line_(39);
  #line 39 "src/expression/DiscreteAdd.birch"
  if (!this_()->hasValue(handler_)) {
    #line 40 "src/expression/DiscreteAdd.birch"
    libbirch_line_(40);
    #line 40 "src/expression/DiscreteAdd.birch"
    auto x1 = this_()->y.get()->graftBoundedDiscrete(handler_);
    #line 41 "src/expression/DiscreteAdd.birch"
    libbirch_line_(41);
    #line 41 "src/expression/DiscreteAdd.birch"
    auto x2 = this_()->z.get()->graftBoundedDiscrete(handler_);
    #line 42 "src/expression/DiscreteAdd.birch"
    libbirch_line_(42);
    #line 42 "src/expression/DiscreteAdd.birch"
    if (x1.query() && x2.query()) {
      #line 43 "src/expression/DiscreteAdd.birch"
      libbirch_line_(43);
      #line 43 "src/expression/DiscreteAdd.birch"
      r = birch::AddBoundedDiscrete(x1.get(), x2.get(), handler_);
    } else {
      #line 44 "src/expression/DiscreteAdd.birch"
      libbirch_line_(44);
      #line 44 "src/expression/DiscreteAdd.birch"
      if (x1.query()) {
        #line 45 "src/expression/DiscreteAdd.birch"
        libbirch_line_(45);
        #line 45 "src/expression/DiscreteAdd.birch"
        r = birch::LinearBoundedDiscrete(birch::box(birch::type::Integer(1), handler_), x1.get(), this_()->z.get(), handler_);
      } else {
        #line 46 "src/expression/DiscreteAdd.birch"
        libbirch_line_(46);
        #line 46 "src/expression/DiscreteAdd.birch"
        if (x2.query()) {
          #line 47 "src/expression/DiscreteAdd.birch"
          libbirch_line_(47);
          #line 47 "src/expression/DiscreteAdd.birch"
          r = birch::LinearBoundedDiscrete(birch::box(birch::type::Integer(1), handler_), x2.get(), this_()->y.get(), handler_);
        }
      }
    }
  }
  #line 50 "src/expression/DiscreteAdd.birch"
  libbirch_line_(50);
  #line 50 "src/expression/DiscreteAdd.birch"
  return r;
}

#line 57 "src/expression/DiscreteAdd.birch"
libbirch::Lazy<libbirch::Shared<birch::type::DiscreteAdd>> birch::operator+(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& z) {
  #line 57 "src/expression/DiscreteAdd.birch"
  libbirch_function_("+", "src/expression/DiscreteAdd.birch", 57);
  #line 58 "src/expression/DiscreteAdd.birch"
  libbirch_line_(58);
  #line 58 "src/expression/DiscreteAdd.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::DiscreteAdd>>>(y, z);
}

#line 64 "src/expression/DiscreteAdd.birch"
libbirch::Lazy<libbirch::Shared<birch::type::DiscreteAdd>> birch::operator+(const birch::type::Integer& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& z) {
  #line 64 "src/expression/DiscreteAdd.birch"
  libbirch_function_("+", "src/expression/DiscreteAdd.birch", 64);
  #line 65 "src/expression/DiscreteAdd.birch"
  libbirch_line_(65);
  #line 65 "src/expression/DiscreteAdd.birch"
  return birch::box(y) + z;
}

#line 71 "src/expression/DiscreteAdd.birch"
libbirch::Lazy<libbirch::Shared<birch::type::DiscreteAdd>> birch::operator+(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& y, const birch::type::Integer& z) {
  #line 71 "src/expression/DiscreteAdd.birch"
  libbirch_function_("+", "src/expression/DiscreteAdd.birch", 71);
  #line 72 "src/expression/DiscreteAdd.birch"
  libbirch_line_(72);
  #line 72 "src/expression/DiscreteAdd.birch"
  return y + birch::box(z);
}

#line 18 "src/expression/DiscreteCast.birch"
libbirch::Lazy<libbirch::Shared<birch::type::DiscreteCast<birch::type::Real, birch::type::Integer>>> birch::Integer(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/expression/DiscreteCast.birch"
  libbirch_function_("Integer", "src/expression/DiscreteCast.birch", 18);
  #line 19 "src/expression/DiscreteCast.birch"
  libbirch_line_(19);
  #line 19 "src/expression/DiscreteCast.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::DiscreteCast<birch::type::Real, birch::type::Integer>>>>(y, handler_);
}

#line 25 "src/expression/DiscreteCast.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>> birch::Integer(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/expression/DiscreteCast.birch"
  libbirch_function_("Integer", "src/expression/DiscreteCast.birch", 25);
  #line 26 "src/expression/DiscreteCast.birch"
  libbirch_line_(26);
  #line 26 "src/expression/DiscreteCast.birch"
  return y;
}

#line 32 "src/expression/DiscreteCast.birch"
libbirch::Lazy<libbirch::Shared<birch::type::DiscreteCast<birch::type::Boolean, birch::type::Integer>>> birch::Integer(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Boolean>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/expression/DiscreteCast.birch"
  libbirch_function_("Integer", "src/expression/DiscreteCast.birch", 32);
  #line 33 "src/expression/DiscreteCast.birch"
  libbirch_line_(33);
  #line 33 "src/expression/DiscreteCast.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::DiscreteCast<birch::type::Boolean, birch::type::Integer>>>>(y, handler_);
}

#line 39 "src/expression/DiscreteCast.birch"
libbirch::Lazy<libbirch::Shared<birch::type::DiscreteCast<birch::type::Real, birch::type::Boolean>>> birch::Boolean(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/expression/DiscreteCast.birch"
  libbirch_function_("Boolean", "src/expression/DiscreteCast.birch", 39);
  #line 40 "src/expression/DiscreteCast.birch"
  libbirch_line_(40);
  #line 40 "src/expression/DiscreteCast.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::DiscreteCast<birch::type::Real, birch::type::Boolean>>>>(y, handler_);
}

#line 46 "src/expression/DiscreteCast.birch"
libbirch::Lazy<libbirch::Shared<birch::type::DiscreteCast<birch::type::Integer, birch::type::Boolean>>> birch::Boolean(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/expression/DiscreteCast.birch"
  libbirch_function_("Boolean", "src/expression/DiscreteCast.birch", 46);
  #line 47 "src/expression/DiscreteCast.birch"
  libbirch_line_(47);
  #line 47 "src/expression/DiscreteCast.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::DiscreteCast<birch::type::Integer, birch::type::Boolean>>>>(y, handler_);
}

#line 53 "src/expression/DiscreteCast.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Boolean>>> birch::Boolean(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Boolean>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "src/expression/DiscreteCast.birch"
  libbirch_function_("Boolean", "src/expression/DiscreteCast.birch", 53);
  #line 54 "src/expression/DiscreteCast.birch"
  libbirch_line_(54);
  #line 54 "src/expression/DiscreteCast.birch"
  return y;
}

#line 4 "src/expression/DiscreteMultiply.birch"
birch::type::DiscreteMultiply::DiscreteMultiply(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/DiscreteMultiply.birch"
    super_type_(y, z) {
  //
}

#line 7 "src/expression/DiscreteMultiply.birch"
birch::type::Integer birch::type::DiscreteMultiply::doEvaluate(const birch::type::Integer& y, const birch::type::Integer& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/DiscreteMultiply.birch"
  libbirch_function_("doEvaluate", "src/expression/DiscreteMultiply.birch", 7);
  #line 8 "src/expression/DiscreteMultiply.birch"
  libbirch_line_(8);
  #line 8 "src/expression/DiscreteMultiply.birch"
  return y * z;
}

#line 11 "src/expression/DiscreteMultiply.birch"
birch::type::Real birch::type::DiscreteMultiply::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Integer& x, const birch::type::Integer& y, const birch::type::Integer& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/DiscreteMultiply.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/DiscreteMultiply.birch", 11);
  #line 13 "src/expression/DiscreteMultiply.birch"
  libbirch_line_(13);
  #line 13 "src/expression/DiscreteMultiply.birch"
  return d * z;
}

#line 16 "src/expression/DiscreteMultiply.birch"
birch::type::Real birch::type::DiscreteMultiply::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Integer& x, const birch::type::Integer& y, const birch::type::Integer& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/expression/DiscreteMultiply.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/DiscreteMultiply.birch", 16);
  #line 18 "src/expression/DiscreteMultiply.birch"
  libbirch_line_(18);
  #line 18 "src/expression/DiscreteMultiply.birch"
  return d * y;
}

#line 21 "src/expression/DiscreteMultiply.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>> birch::type::DiscreteMultiply::graftDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "src/expression/DiscreteMultiply.birch"
  libbirch_function_("graftDiscrete", "src/expression/DiscreteMultiply.birch", 21);
  #line 22 "src/expression/DiscreteMultiply.birch"
  libbirch_line_(22);
  #line 22 "src/expression/DiscreteMultiply.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>> r;
  #line 23 "src/expression/DiscreteMultiply.birch"
  libbirch_line_(23);
  #line 23 "src/expression/DiscreteMultiply.birch"
  if (!this_()->hasValue(handler_)) {
    #line 24 "src/expression/DiscreteMultiply.birch"
    libbirch_line_(24);
    #line 24 "src/expression/DiscreteMultiply.birch"
    r = this_()->graftBoundedDiscrete(handler_);
    #line 25 "src/expression/DiscreteMultiply.birch"
    libbirch_line_(25);
    #line 25 "src/expression/DiscreteMultiply.birch"
    if (!r.query()) {
      #line 26 "src/expression/DiscreteMultiply.birch"
      libbirch_line_(26);
      #line 26 "src/expression/DiscreteMultiply.birch"
      libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>> x1;
      #line 27 "src/expression/DiscreteMultiply.birch"
      libbirch_line_(27);
      #line 27 "src/expression/DiscreteMultiply.birch"
      if ((x1 = this_()->y.get()->graftDiscrete(handler_)).query()) {
        #line 28 "src/expression/DiscreteMultiply.birch"
        libbirch_line_(28);
        #line 28 "src/expression/DiscreteMultiply.birch"
        r = birch::LinearDiscrete(this_()->z.get(), x1.get(), birch::box(birch::type::Integer(0), handler_), handler_);
      } else {
        #line 29 "src/expression/DiscreteMultiply.birch"
        libbirch_line_(29);
        #line 29 "src/expression/DiscreteMultiply.birch"
        if ((x1 = this_()->z.get()->graftDiscrete(handler_)).query()) {
          #line 30 "src/expression/DiscreteMultiply.birch"
          libbirch_line_(30);
          #line 30 "src/expression/DiscreteMultiply.birch"
          r = birch::LinearDiscrete(this_()->y.get(), x1.get(), birch::box(birch::type::Integer(0), handler_), handler_);
        }
      }
    }
  }
  #line 34 "src/expression/DiscreteMultiply.birch"
  libbirch_line_(34);
  #line 34 "src/expression/DiscreteMultiply.birch"
  return r;
}

#line 37 "src/expression/DiscreteMultiply.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>> birch::type::DiscreteMultiply::graftBoundedDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/expression/DiscreteMultiply.birch"
  libbirch_function_("graftBoundedDiscrete", "src/expression/DiscreteMultiply.birch", 37);
  #line 38 "src/expression/DiscreteMultiply.birch"
  libbirch_line_(38);
  #line 38 "src/expression/DiscreteMultiply.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>> r;
  #line 39 "src/expression/DiscreteMultiply.birch"
  libbirch_line_(39);
  #line 39 "src/expression/DiscreteMultiply.birch"
  if (!this_()->hasValue(handler_)) {
    #line 40 "src/expression/DiscreteMultiply.birch"
    libbirch_line_(40);
    #line 40 "src/expression/DiscreteMultiply.birch"
    auto x1 = this_()->y.get()->graftBoundedDiscrete(handler_);
    #line 41 "src/expression/DiscreteMultiply.birch"
    libbirch_line_(41);
    #line 41 "src/expression/DiscreteMultiply.birch"
    auto x2 = this_()->z.get()->graftBoundedDiscrete(handler_);
    #line 42 "src/expression/DiscreteMultiply.birch"
    libbirch_line_(42);
    #line 42 "src/expression/DiscreteMultiply.birch"
    if (x1.query()) {
      #line 43 "src/expression/DiscreteMultiply.birch"
      libbirch_line_(43);
      #line 43 "src/expression/DiscreteMultiply.birch"
      r = birch::LinearBoundedDiscrete(this_()->z.get(), x1.get(), birch::box(birch::type::Integer(0), handler_), handler_);
    } else {
      #line 44 "src/expression/DiscreteMultiply.birch"
      libbirch_line_(44);
      #line 44 "src/expression/DiscreteMultiply.birch"
      if (x2.query()) {
        #line 45 "src/expression/DiscreteMultiply.birch"
        libbirch_line_(45);
        #line 45 "src/expression/DiscreteMultiply.birch"
        r = birch::LinearBoundedDiscrete(this_()->y.get(), x2.get(), birch::box(birch::type::Integer(0), handler_), handler_);
      }
    }
  }
  #line 48 "src/expression/DiscreteMultiply.birch"
  libbirch_line_(48);
  #line 48 "src/expression/DiscreteMultiply.birch"
  return r;
}

#line 55 "src/expression/DiscreteMultiply.birch"
libbirch::Lazy<libbirch::Shared<birch::type::DiscreteMultiply>> birch::operator*(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& z) {
  #line 55 "src/expression/DiscreteMultiply.birch"
  libbirch_function_("*", "src/expression/DiscreteMultiply.birch", 55);
  #line 56 "src/expression/DiscreteMultiply.birch"
  libbirch_line_(56);
  #line 56 "src/expression/DiscreteMultiply.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::DiscreteMultiply>>>(y, z);
}

#line 62 "src/expression/DiscreteMultiply.birch"
libbirch::Lazy<libbirch::Shared<birch::type::DiscreteMultiply>> birch::operator*(const birch::type::Integer& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& z) {
  #line 62 "src/expression/DiscreteMultiply.birch"
  libbirch_function_("*", "src/expression/DiscreteMultiply.birch", 62);
  #line 63 "src/expression/DiscreteMultiply.birch"
  libbirch_line_(63);
  #line 63 "src/expression/DiscreteMultiply.birch"
  return birch::box(y) * z;
}

#line 69 "src/expression/DiscreteMultiply.birch"
libbirch::Lazy<libbirch::Shared<birch::type::DiscreteMultiply>> birch::operator*(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& y, const birch::type::Integer& z) {
  #line 69 "src/expression/DiscreteMultiply.birch"
  libbirch_function_("*", "src/expression/DiscreteMultiply.birch", 69);
  #line 70 "src/expression/DiscreteMultiply.birch"
  libbirch_line_(70);
  #line 70 "src/expression/DiscreteMultiply.birch"
  return y * birch::box(z);
}

#line 4 "src/expression/DiscreteNegate.birch"
birch::type::DiscreteNegate::DiscreteNegate(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/DiscreteNegate.birch"
    super_type_(y) {
  //
}

#line 6 "src/expression/DiscreteNegate.birch"
birch::type::Integer birch::type::DiscreteNegate::doEvaluate(const birch::type::Integer& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 6 "src/expression/DiscreteNegate.birch"
  libbirch_function_("doEvaluate", "src/expression/DiscreteNegate.birch", 6);
  #line 7 "src/expression/DiscreteNegate.birch"
  libbirch_line_(7);
  #line 7 "src/expression/DiscreteNegate.birch"
  return -y;
}

#line 10 "src/expression/DiscreteNegate.birch"
birch::type::Real birch::type::DiscreteNegate::doEvaluateGrad(const birch::type::Real& d, const birch::type::Integer& x, const birch::type::Integer& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/expression/DiscreteNegate.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/DiscreteNegate.birch", 10);
  #line 11 "src/expression/DiscreteNegate.birch"
  libbirch_line_(11);
  #line 11 "src/expression/DiscreteNegate.birch"
  return -d;
}

#line 14 "src/expression/DiscreteNegate.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>> birch::type::DiscreteNegate::graftDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/expression/DiscreteNegate.birch"
  libbirch_function_("graftDiscrete", "src/expression/DiscreteNegate.birch", 14);
  #line 15 "src/expression/DiscreteNegate.birch"
  libbirch_line_(15);
  #line 15 "src/expression/DiscreteNegate.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>> r;
  #line 16 "src/expression/DiscreteNegate.birch"
  libbirch_line_(16);
  #line 16 "src/expression/DiscreteNegate.birch"
  if (!this_()->hasValue(handler_)) {
    #line 17 "src/expression/DiscreteNegate.birch"
    libbirch_line_(17);
    #line 17 "src/expression/DiscreteNegate.birch"
    r = this_()->graftBoundedDiscrete(handler_);
    #line 18 "src/expression/DiscreteNegate.birch"
    libbirch_line_(18);
    #line 18 "src/expression/DiscreteNegate.birch"
    if (!r.query()) {
      #line 19 "src/expression/DiscreteNegate.birch"
      libbirch_line_(19);
      #line 19 "src/expression/DiscreteNegate.birch"
      libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>> x1;
      #line 20 "src/expression/DiscreteNegate.birch"
      libbirch_line_(20);
      #line 20 "src/expression/DiscreteNegate.birch"
      if ((x1 = this_()->y.get()->graftDiscrete(handler_)).query()) {
        #line 21 "src/expression/DiscreteNegate.birch"
        libbirch_line_(21);
        #line 21 "src/expression/DiscreteNegate.birch"
        r = birch::LinearDiscrete(birch::box(-birch::type::Integer(1), handler_), x1.get(), birch::box(birch::type::Integer(0), handler_), handler_);
      }
    }
  }
  #line 25 "src/expression/DiscreteNegate.birch"
  libbirch_line_(25);
  #line 25 "src/expression/DiscreteNegate.birch"
  return r;
}

#line 28 "src/expression/DiscreteNegate.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>> birch::type::DiscreteNegate::graftBoundedDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/expression/DiscreteNegate.birch"
  libbirch_function_("graftBoundedDiscrete", "src/expression/DiscreteNegate.birch", 28);
  #line 29 "src/expression/DiscreteNegate.birch"
  libbirch_line_(29);
  #line 29 "src/expression/DiscreteNegate.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>> r;
  #line 30 "src/expression/DiscreteNegate.birch"
  libbirch_line_(30);
  #line 30 "src/expression/DiscreteNegate.birch"
  if (!this_()->hasValue(handler_)) {
    #line 31 "src/expression/DiscreteNegate.birch"
    libbirch_line_(31);
    #line 31 "src/expression/DiscreteNegate.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>> x1;
    #line 32 "src/expression/DiscreteNegate.birch"
    libbirch_line_(32);
    #line 32 "src/expression/DiscreteNegate.birch"
    if ((x1 = this_()->y.get()->graftBoundedDiscrete(handler_)).query()) {
      #line 33 "src/expression/DiscreteNegate.birch"
      libbirch_line_(33);
      #line 33 "src/expression/DiscreteNegate.birch"
      r = birch::LinearBoundedDiscrete(birch::box(-birch::type::Integer(1), handler_), x1.get(), birch::box(birch::type::Integer(0), handler_), handler_);
    }
  }
  #line 36 "src/expression/DiscreteNegate.birch"
  libbirch_line_(36);
  #line 36 "src/expression/DiscreteNegate.birch"
  return r;
}

#line 43 "src/expression/DiscreteNegate.birch"
libbirch::Lazy<libbirch::Shared<birch::type::DiscreteNegate>> birch::operator-(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x) {
  #line 43 "src/expression/DiscreteNegate.birch"
  libbirch_function_("-", "src/expression/DiscreteNegate.birch", 43);
  #line 44 "src/expression/DiscreteNegate.birch"
  libbirch_line_(44);
  #line 44 "src/expression/DiscreteNegate.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::DiscreteNegate>>>(x);
}

#line 4 "src/expression/DiscreteSubtract.birch"
birch::type::DiscreteSubtract::DiscreteSubtract(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/DiscreteSubtract.birch"
    super_type_(y, z) {
  //
}

#line 7 "src/expression/DiscreteSubtract.birch"
birch::type::Integer birch::type::DiscreteSubtract::doEvaluate(const birch::type::Integer& y, const birch::type::Integer& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/DiscreteSubtract.birch"
  libbirch_function_("doEvaluate", "src/expression/DiscreteSubtract.birch", 7);
  #line 8 "src/expression/DiscreteSubtract.birch"
  libbirch_line_(8);
  #line 8 "src/expression/DiscreteSubtract.birch"
  return y - z;
}

#line 11 "src/expression/DiscreteSubtract.birch"
birch::type::Real birch::type::DiscreteSubtract::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Integer& x, const birch::type::Integer& y, const birch::type::Integer& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/DiscreteSubtract.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/DiscreteSubtract.birch", 11);
  #line 13 "src/expression/DiscreteSubtract.birch"
  libbirch_line_(13);
  #line 13 "src/expression/DiscreteSubtract.birch"
  return d;
}

#line 16 "src/expression/DiscreteSubtract.birch"
birch::type::Real birch::type::DiscreteSubtract::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Integer& x, const birch::type::Integer& y, const birch::type::Integer& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/expression/DiscreteSubtract.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/DiscreteSubtract.birch", 16);
  #line 18 "src/expression/DiscreteSubtract.birch"
  libbirch_line_(18);
  #line 18 "src/expression/DiscreteSubtract.birch"
  return -d;
}

#line 21 "src/expression/DiscreteSubtract.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>> birch::type::DiscreteSubtract::graftDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "src/expression/DiscreteSubtract.birch"
  libbirch_function_("graftDiscrete", "src/expression/DiscreteSubtract.birch", 21);
  #line 22 "src/expression/DiscreteSubtract.birch"
  libbirch_line_(22);
  #line 22 "src/expression/DiscreteSubtract.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>> r;
  #line 23 "src/expression/DiscreteSubtract.birch"
  libbirch_line_(23);
  #line 23 "src/expression/DiscreteSubtract.birch"
  if (!this_()->hasValue(handler_)) {
    #line 24 "src/expression/DiscreteSubtract.birch"
    libbirch_line_(24);
    #line 24 "src/expression/DiscreteSubtract.birch"
    r = this_()->graftBoundedDiscrete(handler_);
    #line 25 "src/expression/DiscreteSubtract.birch"
    libbirch_line_(25);
    #line 25 "src/expression/DiscreteSubtract.birch"
    if (!r.query()) {
      #line 26 "src/expression/DiscreteSubtract.birch"
      libbirch_line_(26);
      #line 26 "src/expression/DiscreteSubtract.birch"
      libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>> x1;
      #line 27 "src/expression/DiscreteSubtract.birch"
      libbirch_line_(27);
      #line 27 "src/expression/DiscreteSubtract.birch"
      if ((x1 = this_()->y.get()->graftDiscrete(handler_)).query()) {
        #line 28 "src/expression/DiscreteSubtract.birch"
        libbirch_line_(28);
        #line 28 "src/expression/DiscreteSubtract.birch"
        r = birch::LinearDiscrete(birch::box(birch::type::Integer(1), handler_), x1.get(), -this_()->z.get(), handler_);
      } else {
        #line 29 "src/expression/DiscreteSubtract.birch"
        libbirch_line_(29);
        #line 29 "src/expression/DiscreteSubtract.birch"
        if ((x1 = this_()->z.get()->graftDiscrete(handler_)).query()) {
          #line 30 "src/expression/DiscreteSubtract.birch"
          libbirch_line_(30);
          #line 30 "src/expression/DiscreteSubtract.birch"
          r = birch::LinearDiscrete(birch::box(-birch::type::Integer(1), handler_), x1.get(), this_()->y.get(), handler_);
        }
      }
    }
  }
  #line 34 "src/expression/DiscreteSubtract.birch"
  libbirch_line_(34);
  #line 34 "src/expression/DiscreteSubtract.birch"
  return r;
}

#line 37 "src/expression/DiscreteSubtract.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>> birch::type::DiscreteSubtract::graftBoundedDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/expression/DiscreteSubtract.birch"
  libbirch_function_("graftBoundedDiscrete", "src/expression/DiscreteSubtract.birch", 37);
  #line 38 "src/expression/DiscreteSubtract.birch"
  libbirch_line_(38);
  #line 38 "src/expression/DiscreteSubtract.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>> r;
  #line 39 "src/expression/DiscreteSubtract.birch"
  libbirch_line_(39);
  #line 39 "src/expression/DiscreteSubtract.birch"
  if (!this_()->hasValue(handler_)) {
    #line 40 "src/expression/DiscreteSubtract.birch"
    libbirch_line_(40);
    #line 40 "src/expression/DiscreteSubtract.birch"
    auto x1 = this_()->y.get()->graftBoundedDiscrete(handler_);
    #line 41 "src/expression/DiscreteSubtract.birch"
    libbirch_line_(41);
    #line 41 "src/expression/DiscreteSubtract.birch"
    auto x2 = this_()->z.get()->graftBoundedDiscrete(handler_);
    #line 42 "src/expression/DiscreteSubtract.birch"
    libbirch_line_(42);
    #line 42 "src/expression/DiscreteSubtract.birch"
    if (x1.query() && x2.query()) {
      #line 43 "src/expression/DiscreteSubtract.birch"
      libbirch_line_(43);
      #line 43 "src/expression/DiscreteSubtract.birch"
      r = birch::SubtractBoundedDiscrete(x1.get(), x2.get(), handler_);
    } else {
      #line 44 "src/expression/DiscreteSubtract.birch"
      libbirch_line_(44);
      #line 44 "src/expression/DiscreteSubtract.birch"
      if (x1.query()) {
        #line 45 "src/expression/DiscreteSubtract.birch"
        libbirch_line_(45);
        #line 45 "src/expression/DiscreteSubtract.birch"
        r = birch::LinearBoundedDiscrete(birch::box(birch::type::Integer(1), handler_), x1.get(), -this_()->z.get(), handler_);
      } else {
        #line 46 "src/expression/DiscreteSubtract.birch"
        libbirch_line_(46);
        #line 46 "src/expression/DiscreteSubtract.birch"
        if (x2.query()) {
          #line 47 "src/expression/DiscreteSubtract.birch"
          libbirch_line_(47);
          #line 47 "src/expression/DiscreteSubtract.birch"
          r = birch::LinearBoundedDiscrete(birch::box(-birch::type::Integer(1), handler_), x2.get(), this_()->y.get(), handler_);
        }
      }
    }
  }
  #line 50 "src/expression/DiscreteSubtract.birch"
  libbirch_line_(50);
  #line 50 "src/expression/DiscreteSubtract.birch"
  return r;
}

#line 57 "src/expression/DiscreteSubtract.birch"
libbirch::Lazy<libbirch::Shared<birch::type::DiscreteSubtract>> birch::operator-(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& z) {
  #line 57 "src/expression/DiscreteSubtract.birch"
  libbirch_function_("-", "src/expression/DiscreteSubtract.birch", 57);
  #line 59 "src/expression/DiscreteSubtract.birch"
  libbirch_line_(59);
  #line 59 "src/expression/DiscreteSubtract.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::DiscreteSubtract>>>(y, z);
}

#line 65 "src/expression/DiscreteSubtract.birch"
libbirch::Lazy<libbirch::Shared<birch::type::DiscreteSubtract>> birch::operator-(const birch::type::Integer& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& z) {
  #line 65 "src/expression/DiscreteSubtract.birch"
  libbirch_function_("-", "src/expression/DiscreteSubtract.birch", 65);
  #line 66 "src/expression/DiscreteSubtract.birch"
  libbirch_line_(66);
  #line 66 "src/expression/DiscreteSubtract.birch"
  return birch::box(y) - z;
}

#line 72 "src/expression/DiscreteSubtract.birch"
libbirch::Lazy<libbirch::Shared<birch::type::DiscreteSubtract>> birch::operator-(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& y, const birch::type::Integer& z) {
  #line 72 "src/expression/DiscreteSubtract.birch"
  libbirch_function_("-", "src/expression/DiscreteSubtract.birch", 72);
  #line 73 "src/expression/DiscreteSubtract.birch"
  libbirch_line_(73);
  #line 73 "src/expression/DiscreteSubtract.birch"
  return y - birch::box(z);
}

#line 4 "src/expression/Divide.birch"
birch::type::Divide::Divide(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/Divide.birch"
    super_type_(y, z) {
  //
}

#line 7 "src/expression/Divide.birch"
birch::type::Real birch::type::Divide::doEvaluate(const birch::type::Real& y, const birch::type::Real& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/Divide.birch"
  libbirch_function_("doEvaluate", "src/expression/Divide.birch", 7);
  #line 8 "src/expression/Divide.birch"
  libbirch_line_(8);
  #line 8 "src/expression/Divide.birch"
  return y / z;
}

#line 11 "src/expression/Divide.birch"
birch::type::Real birch::type::Divide::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/Divide.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/Divide.birch", 11);
  #line 12 "src/expression/Divide.birch"
  libbirch_line_(12);
  #line 12 "src/expression/Divide.birch"
  return d / z;
}

#line 15 "src/expression/Divide.birch"
birch::type::Real birch::type::Divide::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/expression/Divide.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/Divide.birch", 15);
  #line 16 "src/expression/Divide.birch"
  libbirch_line_(16);
  #line 16 "src/expression/Divide.birch"
  return -d * y / (z * z);
}

#line 19 "src/expression/Divide.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>>>>> birch::type::Divide::graftLinearGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/expression/Divide.birch"
  libbirch_function_("graftLinearGaussian", "src/expression/Divide.birch", 19);
  #line 20 "src/expression/Divide.birch"
  libbirch_line_(20);
  #line 20 "src/expression/Divide.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>>>>> r;
  #line 21 "src/expression/Divide.birch"
  libbirch_line_(21);
  #line 21 "src/expression/Divide.birch"
  if (!this_()->hasValue(handler_)) {
    #line 22 "src/expression/Divide.birch"
    libbirch_line_(22);
    #line 22 "src/expression/Divide.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>> x1;
    #line 23 "src/expression/Divide.birch"
    libbirch_line_(23);
    #line 23 "src/expression/Divide.birch"
    if ((r = this_()->y.get()->graftLinearGaussian(handler_)).query()) {
      #line 24 "src/expression/Divide.birch"
      libbirch_line_(24);
      #line 24 "src/expression/Divide.birch"
      r.get()->divide(this_()->z.get(), handler_);
    } else {
      #line 25 "src/expression/Divide.birch"
      libbirch_line_(25);
      #line 25 "src/expression/Divide.birch"
      if ((x1 = this_()->y.get()->graftGaussian(handler_)).query()) {
        #line 26 "src/expression/Divide.birch"
        libbirch_line_(26);
        #line 26 "src/expression/Divide.birch"
        r = birch::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>>(1.0 / this_()->z.get(), x1.get(), handler_);
      }
    }
  }
  #line 29 "src/expression/Divide.birch"
  libbirch_line_(29);
  #line 29 "src/expression/Divide.birch"
  return r;
}

#line 32 "src/expression/Divide.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> birch::type::Divide::graftDotGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/expression/Divide.birch"
  libbirch_function_("graftDotGaussian", "src/expression/Divide.birch", 32);
  #line 33 "src/expression/Divide.birch"
  libbirch_line_(33);
  #line 33 "src/expression/Divide.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> r;
  #line 34 "src/expression/Divide.birch"
  libbirch_line_(34);
  #line 34 "src/expression/Divide.birch"
  if (!this_()->hasValue(handler_)) {
    #line 35 "src/expression/Divide.birch"
    libbirch_line_(35);
    #line 35 "src/expression/Divide.birch"
    if ((r = this_()->y.get()->graftDotGaussian(handler_)).query()) {
      #line 36 "src/expression/Divide.birch"
      libbirch_line_(36);
      #line 36 "src/expression/Divide.birch"
      r.get()->divide(this_()->z.get(), handler_);
    }
  }
  #line 39 "src/expression/Divide.birch"
  libbirch_line_(39);
  #line 39 "src/expression/Divide.birch"
  return r;
}

#line 42 "src/expression/Divide.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>>>>> birch::type::Divide::graftLinearNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/expression/Divide.birch"
  libbirch_function_("graftLinearNormalInverseGamma", "src/expression/Divide.birch", 42);
  #line 44 "src/expression/Divide.birch"
  libbirch_line_(44);
  #line 44 "src/expression/Divide.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>>>>> r;
  #line 45 "src/expression/Divide.birch"
  libbirch_line_(45);
  #line 45 "src/expression/Divide.birch"
  if (!this_()->hasValue(handler_)) {
    #line 46 "src/expression/Divide.birch"
    libbirch_line_(46);
    #line 46 "src/expression/Divide.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>> x1;
    #line 47 "src/expression/Divide.birch"
    libbirch_line_(47);
    #line 47 "src/expression/Divide.birch"
    if ((r = this_()->y.get()->graftLinearNormalInverseGamma(compare, handler_)).query()) {
      #line 48 "src/expression/Divide.birch"
      libbirch_line_(48);
      #line 48 "src/expression/Divide.birch"
      r.get()->divide(this_()->z.get(), handler_);
    } else {
      #line 49 "src/expression/Divide.birch"
      libbirch_line_(49);
      #line 49 "src/expression/Divide.birch"
      if ((x1 = this_()->y.get()->graftNormalInverseGamma(compare, handler_)).query()) {
        #line 50 "src/expression/Divide.birch"
        libbirch_line_(50);
        #line 50 "src/expression/Divide.birch"
        r = birch::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>>(1.0 / this_()->z.get(), x1.get(), handler_);
      }
    }
  }
  #line 53 "src/expression/Divide.birch"
  libbirch_line_(53);
  #line 53 "src/expression/Divide.birch"
  return r;
}

#line 56 "src/expression/Divide.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> birch::type::Divide::graftDotNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 56 "src/expression/Divide.birch"
  libbirch_function_("graftDotNormalInverseGamma", "src/expression/Divide.birch", 56);
  #line 58 "src/expression/Divide.birch"
  libbirch_line_(58);
  #line 58 "src/expression/Divide.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> r;
  #line 59 "src/expression/Divide.birch"
  libbirch_line_(59);
  #line 59 "src/expression/Divide.birch"
  if (!this_()->hasValue(handler_)) {
    #line 60 "src/expression/Divide.birch"
    libbirch_line_(60);
    #line 60 "src/expression/Divide.birch"
    if ((r = this_()->y.get()->graftDotNormalInverseGamma(compare, handler_)).query()) {
      #line 61 "src/expression/Divide.birch"
      libbirch_line_(61);
      #line 61 "src/expression/Divide.birch"
      r.get()->divide(this_()->z.get(), handler_);
    }
  }
  #line 64 "src/expression/Divide.birch"
  libbirch_line_(64);
  #line 64 "src/expression/Divide.birch"
  return r;
}

#line 67 "src/expression/Divide.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>>>>> birch::type::Divide::graftScaledGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 67 "src/expression/Divide.birch"
  libbirch_function_("graftScaledGamma", "src/expression/Divide.birch", 67);
  #line 68 "src/expression/Divide.birch"
  libbirch_line_(68);
  #line 68 "src/expression/Divide.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>>>>> r;
  #line 69 "src/expression/Divide.birch"
  libbirch_line_(69);
  #line 69 "src/expression/Divide.birch"
  if (!this_()->hasValue(handler_)) {
    #line 70 "src/expression/Divide.birch"
    libbirch_line_(70);
    #line 70 "src/expression/Divide.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>> x1;
    #line 71 "src/expression/Divide.birch"
    libbirch_line_(71);
    #line 71 "src/expression/Divide.birch"
    if ((r = this_()->y.get()->graftScaledGamma(handler_)).query()) {
      #line 72 "src/expression/Divide.birch"
      libbirch_line_(72);
      #line 72 "src/expression/Divide.birch"
      r.get()->divide(this_()->z.get(), handler_);
    } else {
      #line 73 "src/expression/Divide.birch"
      libbirch_line_(73);
      #line 73 "src/expression/Divide.birch"
      if ((x1 = this_()->y.get()->graftGamma(handler_)).query()) {
        #line 74 "src/expression/Divide.birch"
        libbirch_line_(74);
        #line 74 "src/expression/Divide.birch"
        r = birch::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>>(1.0 / this_()->z.get(), x1.get(), handler_);
      }
    }
  }
  #line 77 "src/expression/Divide.birch"
  libbirch_line_(77);
  #line 77 "src/expression/Divide.birch"
  return r;
}

#line 84 "src/expression/Divide.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Divide>> birch::operator/(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z) {
  #line 84 "src/expression/Divide.birch"
  libbirch_function_("/", "src/expression/Divide.birch", 84);
  #line 85 "src/expression/Divide.birch"
  libbirch_line_(85);
  #line 85 "src/expression/Divide.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Divide>>>(y, z);
}

#line 91 "src/expression/Divide.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Divide>> birch::operator/(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z) {
  #line 91 "src/expression/Divide.birch"
  libbirch_function_("/", "src/expression/Divide.birch", 91);
  #line 92 "src/expression/Divide.birch"
  libbirch_line_(92);
  #line 92 "src/expression/Divide.birch"
  return birch::box(y) / z;
}

#line 98 "src/expression/Divide.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Divide>> birch::operator/(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const birch::type::Real& z) {
  #line 98 "src/expression/Divide.birch"
  libbirch_function_("/", "src/expression/Divide.birch", 98);
  #line 99 "src/expression/Divide.birch"
  libbirch_line_(99);
  #line 99 "src/expression/Divide.birch"
  return y / birch::box(z);
}

#line 4 "src/expression/Dot.birch"
birch::type::Dot::Dot(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/Dot.birch"
    super_type_(y, z) {
  //
}

#line 7 "src/expression/Dot.birch"
birch::type::Real birch::type::Dot::doEvaluate(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/Dot.birch"
  libbirch_function_("doEvaluate", "src/expression/Dot.birch", 7);
  #line 8 "src/expression/Dot.birch"
  libbirch_line_(8);
  #line 8 "src/expression/Dot.birch"
  return birch::dot(y, z, handler_);
}

#line 11 "src/expression/Dot.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::Dot::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Real& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/Dot.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/Dot.birch", 11);
  #line 13 "src/expression/Dot.birch"
  libbirch_line_(13);
  #line 13 "src/expression/Dot.birch"
  return d * z;
}

#line 16 "src/expression/Dot.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::Dot::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Real& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/expression/Dot.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/Dot.birch", 16);
  #line 18 "src/expression/Dot.birch"
  libbirch_line_(18);
  #line 18 "src/expression/Dot.birch"
  return d * y;
}

#line 21 "src/expression/Dot.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> birch::type::Dot::graftDotGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "src/expression/Dot.birch"
  libbirch_function_("graftDotGaussian", "src/expression/Dot.birch", 21);
  #line 22 "src/expression/Dot.birch"
  libbirch_line_(22);
  #line 22 "src/expression/Dot.birch"
  if (!this_()->hasValue(handler_)) {
    #line 23 "src/expression/Dot.birch"
    libbirch_line_(23);
    #line 23 "src/expression/Dot.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> x1;
    #line 24 "src/expression/Dot.birch"
    libbirch_line_(24);
    #line 24 "src/expression/Dot.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>> x2;
    #line 26 "src/expression/Dot.birch"
    libbirch_line_(26);
    #line 26 "src/expression/Dot.birch"
    if ((x1 = this_()->z.get()->graftLinearMultivariateGaussian(handler_)).query()) {
      #line 27 "src/expression/Dot.birch"
      libbirch_line_(27);
      #line 27 "src/expression/Dot.birch"
      return birch::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>(x1.get()->A * this_()->y.get(), x1.get()->x, birch::dot(x1.get()->c, this_()->y.get(), handler_), handler_);
    } else {
      #line 28 "src/expression/Dot.birch"
      libbirch_line_(28);
      #line 28 "src/expression/Dot.birch"
      if ((x1 = this_()->y.get()->graftLinearMultivariateGaussian(handler_)).query()) {
        #line 29 "src/expression/Dot.birch"
        libbirch_line_(29);
        #line 29 "src/expression/Dot.birch"
        return birch::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>(x1.get()->A * this_()->z.get(), x1.get()->x, birch::dot(x1.get()->c, this_()->z.get(), handler_), handler_);
      } else {
        #line 30 "src/expression/Dot.birch"
        libbirch_line_(30);
        #line 30 "src/expression/Dot.birch"
        if ((x2 = this_()->z.get()->graftMultivariateGaussian(handler_)).query()) {
          #line 31 "src/expression/Dot.birch"
          libbirch_line_(31);
          #line 31 "src/expression/Dot.birch"
          return birch::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>(this_()->y.get(), x2.get(), birch::box(0.0, handler_), handler_);
        } else {
          #line 32 "src/expression/Dot.birch"
          libbirch_line_(32);
          #line 32 "src/expression/Dot.birch"
          if ((x2 = this_()->y.get()->graftMultivariateGaussian(handler_)).query()) {
            #line 33 "src/expression/Dot.birch"
            libbirch_line_(33);
            #line 33 "src/expression/Dot.birch"
            return birch::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>(this_()->z.get(), x2.get(), birch::box(0.0, handler_), handler_);
          }
        }
      }
    }
  }
  #line 36 "src/expression/Dot.birch"
  libbirch_line_(36);
  #line 36 "src/expression/Dot.birch"
  return libbirch::nil;
}

#line 39 "src/expression/Dot.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> birch::type::Dot::graftDotNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/expression/Dot.birch"
  libbirch_function_("graftDotNormalInverseGamma", "src/expression/Dot.birch", 39);
  #line 41 "src/expression/Dot.birch"
  libbirch_line_(41);
  #line 41 "src/expression/Dot.birch"
  if (!this_()->hasValue(handler_)) {
    #line 42 "src/expression/Dot.birch"
    libbirch_line_(42);
    #line 42 "src/expression/Dot.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> x1;
    #line 43 "src/expression/Dot.birch"
    libbirch_line_(43);
    #line 43 "src/expression/Dot.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>> x2;
    #line 45 "src/expression/Dot.birch"
    libbirch_line_(45);
    #line 45 "src/expression/Dot.birch"
    if ((x1 = this_()->z.get()->graftLinearMultivariateNormalInverseGamma(compare, handler_)).query()) {
      #line 46 "src/expression/Dot.birch"
      libbirch_line_(46);
      #line 46 "src/expression/Dot.birch"
      return birch::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>(birch::transpose(x1.get()->A, handler_) * this_()->y.get(), x1.get()->x, birch::dot(this_()->y.get(), x1.get()->c, handler_), handler_);
    } else {
      #line 47 "src/expression/Dot.birch"
      libbirch_line_(47);
      #line 47 "src/expression/Dot.birch"
      if ((x1 = this_()->y.get()->graftLinearMultivariateNormalInverseGamma(compare, handler_)).query()) {
        #line 48 "src/expression/Dot.birch"
        libbirch_line_(48);
        #line 48 "src/expression/Dot.birch"
        return birch::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>(x1.get()->A * this_()->z.get(), x1.get()->x, birch::dot(x1.get()->c, this_()->z.get(), handler_), handler_);
      } else {
        #line 49 "src/expression/Dot.birch"
        libbirch_line_(49);
        #line 49 "src/expression/Dot.birch"
        if ((x2 = this_()->z.get()->graftMultivariateNormalInverseGamma(compare, handler_)).query()) {
          #line 50 "src/expression/Dot.birch"
          libbirch_line_(50);
          #line 50 "src/expression/Dot.birch"
          return birch::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>(this_()->y.get(), x2.get(), birch::box(0.0, handler_), handler_);
        } else {
          #line 51 "src/expression/Dot.birch"
          libbirch_line_(51);
          #line 51 "src/expression/Dot.birch"
          if ((x2 = this_()->y.get()->graftMultivariateNormalInverseGamma(compare, handler_)).query()) {
            #line 52 "src/expression/Dot.birch"
            libbirch_line_(52);
            #line 52 "src/expression/Dot.birch"
            return birch::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>(this_()->z.get(), x2.get(), birch::box(0.0, handler_), handler_);
          }
        }
      }
    }
  }
  #line 55 "src/expression/Dot.birch"
  libbirch_line_(55);
  #line 55 "src/expression/Dot.birch"
  return libbirch::nil;
}

#line 62 "src/expression/Dot.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Dot>> birch::dot(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 62 "src/expression/Dot.birch"
  libbirch_function_("dot", "src/expression/Dot.birch", 62);
  #line 63 "src/expression/Dot.birch"
  libbirch_line_(63);
  #line 63 "src/expression/Dot.birch"
  libbirch_assert_(y.get()->rows(handler_) == z.get()->rows(handler_));
  #line 64 "src/expression/Dot.birch"
  libbirch_line_(64);
  #line 64 "src/expression/Dot.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Dot>>>(y, z, handler_);
}

#line 70 "src/expression/Dot.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Dot>> birch::dot(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "src/expression/Dot.birch"
  libbirch_function_("dot", "src/expression/Dot.birch", 70);
  #line 71 "src/expression/Dot.birch"
  libbirch_line_(71);
  #line 71 "src/expression/Dot.birch"
  return birch::dot(birch::box(y, handler_), z, handler_);
}

#line 77 "src/expression/Dot.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Dot>> birch::dot(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y, const libbirch::DefaultArray<birch::type::Real,1>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 77 "src/expression/Dot.birch"
  libbirch_function_("dot", "src/expression/Dot.birch", 77);
  #line 78 "src/expression/Dot.birch"
  libbirch_line_(78);
  #line 78 "src/expression/Dot.birch"
  return birch::dot(y, birch::box(z, handler_), handler_);
}

#line 84 "src/expression/Dot.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Dot>> birch::dot(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 84 "src/expression/Dot.birch"
  libbirch_function_("dot", "src/expression/Dot.birch", 84);
  #line 85 "src/expression/Dot.birch"
  libbirch_line_(85);
  #line 85 "src/expression/Dot.birch"
  return birch::dot(y, y, handler_);
}

#line 4 "src/expression/Exp.birch"
birch::type::Exp::Exp(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/Exp.birch"
    super_type_(y) {
  //
}

#line 6 "src/expression/Exp.birch"
birch::type::Real birch::type::Exp::doEvaluate(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 6 "src/expression/Exp.birch"
  libbirch_function_("doEvaluate", "src/expression/Exp.birch", 6);
  #line 7 "src/expression/Exp.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Exp.birch"
  return birch::exp(y, handler_);
}

#line 10 "src/expression/Exp.birch"
birch::type::Real birch::type::Exp::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/expression/Exp.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Exp.birch", 10);
  #line 11 "src/expression/Exp.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Exp.birch"
  return d * x;
}

#line 18 "src/expression/Exp.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Exp>> birch::exp(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/expression/Exp.birch"
  libbirch_function_("exp", "src/expression/Exp.birch", 18);
  #line 19 "src/expression/Exp.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Exp.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Exp>>>(y, handler_);
}

#line 4 "src/expression/Log.birch"
birch::type::Log::Log(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/Log.birch"
    super_type_(y) {
  //
}

#line 6 "src/expression/Log.birch"
birch::type::Real birch::type::Log::doEvaluate(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 6 "src/expression/Log.birch"
  libbirch_function_("doEvaluate", "src/expression/Log.birch", 6);
  #line 7 "src/expression/Log.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Log.birch"
  return birch::log(y, handler_);
}

#line 10 "src/expression/Log.birch"
birch::type::Real birch::type::Log::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/expression/Log.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Log.birch", 10);
  #line 11 "src/expression/Log.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Log.birch"
  return d / y;
}

#line 18 "src/expression/Log.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Log>> birch::log(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/expression/Log.birch"
  libbirch_function_("log", "src/expression/Log.birch", 18);
  #line 19 "src/expression/Log.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Log.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Log>>>(y, handler_);
}

#line 4 "src/expression/Log1p.birch"
birch::type::Log1p::Log1p(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/Log1p.birch"
    super_type_(y) {
  //
}

#line 6 "src/expression/Log1p.birch"
birch::type::Real birch::type::Log1p::doEvaluate(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 6 "src/expression/Log1p.birch"
  libbirch_function_("doEvaluate", "src/expression/Log1p.birch", 6);
  #line 7 "src/expression/Log1p.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Log1p.birch"
  return birch::log1p(y, handler_);
}

#line 10 "src/expression/Log1p.birch"
birch::type::Real birch::type::Log1p::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/expression/Log1p.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Log1p.birch", 10);
  #line 11 "src/expression/Log1p.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Log1p.birch"
  return d / (1.0 + y);
}

#line 18 "src/expression/Log1p.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Log1p>> birch::log1p(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/expression/Log1p.birch"
  libbirch_function_("log1p", "src/expression/Log1p.birch", 18);
  #line 19 "src/expression/Log1p.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Log1p.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Log1p>>>(y, handler_);
}

#line 4 "src/expression/LogBeta.birch"
birch::type::LogBeta::LogBeta(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/LogBeta.birch"
    super_type_(y, z) {
  //
}

#line 7 "src/expression/LogBeta.birch"
birch::type::Real birch::type::LogBeta::doEvaluate(const birch::type::Real& y, const birch::type::Real& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/LogBeta.birch"
  libbirch_function_("doEvaluate", "src/expression/LogBeta.birch", 7);
  #line 8 "src/expression/LogBeta.birch"
  libbirch_line_(8);
  #line 8 "src/expression/LogBeta.birch"
  return birch::lbeta(y, z, handler_);
}

#line 11 "src/expression/LogBeta.birch"
birch::type::Real birch::type::LogBeta::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/LogBeta.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/LogBeta.birch", 11);
  #line 12 "src/expression/LogBeta.birch"
  libbirch_line_(12);
  #line 12 "src/expression/LogBeta.birch"
  return d * (birch::digamma(y, handler_) + birch::digamma(y + z, handler_));
}

#line 15 "src/expression/LogBeta.birch"
birch::type::Real birch::type::LogBeta::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/expression/LogBeta.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/LogBeta.birch", 15);
  #line 16 "src/expression/LogBeta.birch"
  libbirch_line_(16);
  #line 16 "src/expression/LogBeta.birch"
  return d * (birch::digamma(z, handler_) + birch::digamma(y + z, handler_));
}

#line 23 "src/expression/LogBeta.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LogBeta>> birch::lbeta(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "src/expression/LogBeta.birch"
  libbirch_function_("lbeta", "src/expression/LogBeta.birch", 23);
  #line 24 "src/expression/LogBeta.birch"
  libbirch_line_(24);
  #line 24 "src/expression/LogBeta.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::LogBeta>>>(x, y, handler_);
}

#line 30 "src/expression/LogBeta.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LogBeta>> birch::lbeta(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/expression/LogBeta.birch"
  libbirch_function_("lbeta", "src/expression/LogBeta.birch", 30);
  #line 31 "src/expression/LogBeta.birch"
  libbirch_line_(31);
  #line 31 "src/expression/LogBeta.birch"
  return birch::lbeta(birch::box(x, handler_), y, handler_);
}

#line 37 "src/expression/LogBeta.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LogBeta>> birch::lbeta(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/expression/LogBeta.birch"
  libbirch_function_("lbeta", "src/expression/LogBeta.birch", 37);
  #line 38 "src/expression/LogBeta.birch"
  libbirch_line_(38);
  #line 38 "src/expression/LogBeta.birch"
  return birch::lbeta(x, birch::box(y, handler_), handler_);
}

#line 4 "src/expression/LogChoose.birch"
birch::type::LogChoose::LogChoose(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/LogChoose.birch"
    super_type_(y, z) {
  //
}

#line 7 "src/expression/LogChoose.birch"
birch::type::Real birch::type::LogChoose::doEvaluate(const birch::type::Integer& y, const birch::type::Integer& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/LogChoose.birch"
  libbirch_function_("doEvaluate", "src/expression/LogChoose.birch", 7);
  #line 8 "src/expression/LogChoose.birch"
  libbirch_line_(8);
  #line 8 "src/expression/LogChoose.birch"
  return birch::lchoose(y, z, handler_);
}

#line 11 "src/expression/LogChoose.birch"
birch::type::Real birch::type::LogChoose::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Integer& y, const birch::type::Integer& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/LogChoose.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/LogChoose.birch", 11);
  #line 13 "src/expression/LogChoose.birch"
  libbirch_line_(13);
  #line 13 "src/expression/LogChoose.birch"
  return 0.0;
}

#line 16 "src/expression/LogChoose.birch"
birch::type::Real birch::type::LogChoose::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Integer& y, const birch::type::Integer& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/expression/LogChoose.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/LogChoose.birch", 16);
  #line 18 "src/expression/LogChoose.birch"
  libbirch_line_(18);
  #line 18 "src/expression/LogChoose.birch"
  return 0.0;
}

#line 25 "src/expression/LogChoose.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LogChoose>> birch::lchoose(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/expression/LogChoose.birch"
  libbirch_function_("lchoose", "src/expression/LogChoose.birch", 25);
  #line 26 "src/expression/LogChoose.birch"
  libbirch_line_(26);
  #line 26 "src/expression/LogChoose.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::LogChoose>>>(y, z, handler_);
}

#line 32 "src/expression/LogChoose.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LogChoose>> birch::lchoose(const birch::type::Integer& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/expression/LogChoose.birch"
  libbirch_function_("lchoose", "src/expression/LogChoose.birch", 32);
  #line 33 "src/expression/LogChoose.birch"
  libbirch_line_(33);
  #line 33 "src/expression/LogChoose.birch"
  return birch::lchoose(birch::box(y, handler_), z, handler_);
}

#line 39 "src/expression/LogChoose.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LogChoose>> birch::lchoose(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& y, const birch::type::Integer& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/expression/LogChoose.birch"
  libbirch_function_("lchoose", "src/expression/LogChoose.birch", 39);
  #line 40 "src/expression/LogChoose.birch"
  libbirch_line_(40);
  #line 40 "src/expression/LogChoose.birch"
  return birch::lchoose(y, birch::box(z, handler_), handler_);
}

#line 19 "src/expression/LogDet.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LogDet<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, birch::type::LLT>>> birch::ldet(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/expression/LogDet.birch"
  libbirch_function_("ldet", "src/expression/LogDet.birch", 19);
  #line 20 "src/expression/LogDet.birch"
  libbirch_line_(20);
  #line 20 "src/expression/LogDet.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::LogDet<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, birch::type::LLT>>>>(y, handler_);
}

#line 26 "src/expression/LogDet.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LogDet<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::DefaultArray<birch::type::Real,2>>>> birch::ldet(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/expression/LogDet.birch"
  libbirch_function_("ldet", "src/expression/LogDet.birch", 26);
  #line 28 "src/expression/LogDet.birch"
  libbirch_line_(28);
  #line 28 "src/expression/LogDet.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::LogDet<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::DefaultArray<birch::type::Real,2>>>>>(y, handler_);
}

#line 4 "src/expression/LogGamma.birch"
birch::type::LogGamma::LogGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/LogGamma.birch"
    super_type_(x) {
  //
}

#line 6 "src/expression/LogGamma.birch"
birch::type::Real birch::type::LogGamma::doEvaluate(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 6 "src/expression/LogGamma.birch"
  libbirch_function_("doEvaluate", "src/expression/LogGamma.birch", 6);
  #line 7 "src/expression/LogGamma.birch"
  libbirch_line_(7);
  #line 7 "src/expression/LogGamma.birch"
  return birch::lgamma(y, handler_);
}

#line 10 "src/expression/LogGamma.birch"
birch::type::Real birch::type::LogGamma::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/expression/LogGamma.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/LogGamma.birch", 10);
  #line 11 "src/expression/LogGamma.birch"
  libbirch_line_(11);
  #line 11 "src/expression/LogGamma.birch"
  return d * birch::digamma(y, handler_);
}

#line 18 "src/expression/LogGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LogGamma>> birch::lgamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/expression/LogGamma.birch"
  libbirch_function_("lgamma", "src/expression/LogGamma.birch", 18);
  #line 19 "src/expression/LogGamma.birch"
  libbirch_line_(19);
  #line 19 "src/expression/LogGamma.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::LogGamma>>>(x, handler_);
}

#line 4 "src/expression/LogGammaP.birch"
birch::type::LogGammaP::LogGammaP(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const birch::type::Integer& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/LogGammaP.birch"
    super_type_(y),
    #line 9 "src/expression/LogGammaP.birch"
    z(z) {
  //
}

#line 11 "src/expression/LogGammaP.birch"
birch::type::Real birch::type::LogGammaP::doEvaluate(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/LogGammaP.birch"
  libbirch_function_("doEvaluate", "src/expression/LogGammaP.birch", 11);
  #line 12 "src/expression/LogGammaP.birch"
  libbirch_line_(12);
  #line 12 "src/expression/LogGammaP.birch"
  return birch::lgamma(y, this_()->z, handler_);
}

#line 15 "src/expression/LogGammaP.birch"
birch::type::Real birch::type::LogGammaP::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/expression/LogGammaP.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/LogGammaP.birch", 15);
  #line 16 "src/expression/LogGammaP.birch"
  libbirch_line_(16);
  #line 16 "src/expression/LogGammaP.birch"
  auto r = 0.0;
  #line 17 "src/expression/LogGammaP.birch"
  libbirch_line_(17);
  #line 17 "src/expression/LogGammaP.birch"
  for (auto i = birch::type::Integer(1); i <= this_()->z; ++i) {
    #line 18 "src/expression/LogGammaP.birch"
    libbirch_line_(18);
    #line 18 "src/expression/LogGammaP.birch"
    r = r + birch::digamma(y + 0.5 * (birch::type::Integer(1) - i), handler_);
  }
  #line 20 "src/expression/LogGammaP.birch"
  libbirch_line_(20);
  #line 20 "src/expression/LogGammaP.birch"
  return d * r;
}

#line 27 "src/expression/LogGammaP.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LogGammaP>> birch::lgamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const birch::type::Integer& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/expression/LogGammaP.birch"
  libbirch_function_("lgamma", "src/expression/LogGammaP.birch", 27);
  #line 28 "src/expression/LogGammaP.birch"
  libbirch_line_(28);
  #line 28 "src/expression/LogGammaP.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::LogGammaP>>>(y, z, handler_);
}

#line 4 "src/expression/MatrixAdd.birch"
birch::type::MatrixAdd::MatrixAdd(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/MatrixAdd.birch"
    super_type_(y, z) {
  //
}

#line 7 "src/expression/MatrixAdd.birch"
birch::type::Integer birch::type::MatrixAdd::doRows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/MatrixAdd.birch"
  libbirch_function_("doRows", "src/expression/MatrixAdd.birch", 7);
  #line 8 "src/expression/MatrixAdd.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MatrixAdd.birch"
  return this_()->y.get()->rows(handler_);
}

#line 11 "src/expression/MatrixAdd.birch"
birch::type::Integer birch::type::MatrixAdd::doColumns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/MatrixAdd.birch"
  libbirch_function_("doColumns", "src/expression/MatrixAdd.birch", 11);
  #line 12 "src/expression/MatrixAdd.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MatrixAdd.birch"
  return this_()->y.get()->columns(handler_);
}

#line 15 "src/expression/MatrixAdd.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixAdd::doEvaluate(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/expression/MatrixAdd.birch"
  libbirch_function_("doEvaluate", "src/expression/MatrixAdd.birch", 15);
  #line 16 "src/expression/MatrixAdd.birch"
  libbirch_line_(16);
  #line 16 "src/expression/MatrixAdd.birch"
  return y + z;
}

#line 19 "src/expression/MatrixAdd.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixAdd::doEvaluateGradLeft(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/expression/MatrixAdd.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/MatrixAdd.birch", 19);
  #line 20 "src/expression/MatrixAdd.birch"
  libbirch_line_(20);
  #line 20 "src/expression/MatrixAdd.birch"
  return d;
}

#line 23 "src/expression/MatrixAdd.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixAdd::doEvaluateGradRight(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "src/expression/MatrixAdd.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/MatrixAdd.birch", 23);
  #line 24 "src/expression/MatrixAdd.birch"
  libbirch_line_(24);
  #line 24 "src/expression/MatrixAdd.birch"
  return d;
}

#line 27 "src/expression/MatrixAdd.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>>>>> birch::type::MatrixAdd::graftLinearMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/expression/MatrixAdd.birch"
  libbirch_function_("graftLinearMatrixGaussian", "src/expression/MatrixAdd.birch", 27);
  #line 29 "src/expression/MatrixAdd.birch"
  libbirch_line_(29);
  #line 29 "src/expression/MatrixAdd.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>>>>> r;
  #line 30 "src/expression/MatrixAdd.birch"
  libbirch_line_(30);
  #line 30 "src/expression/MatrixAdd.birch"
  if (!this_()->hasValue(handler_)) {
    #line 31 "src/expression/MatrixAdd.birch"
    libbirch_line_(31);
    #line 31 "src/expression/MatrixAdd.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>> x1;
    #line 33 "src/expression/MatrixAdd.birch"
    libbirch_line_(33);
    #line 33 "src/expression/MatrixAdd.birch"
    if ((r = this_()->y.get()->graftLinearMatrixGaussian(handler_)).query()) {
      #line 34 "src/expression/MatrixAdd.birch"
      libbirch_line_(34);
      #line 34 "src/expression/MatrixAdd.birch"
      r.get()->add(this_()->z.get(), handler_);
    } else {
      #line 35 "src/expression/MatrixAdd.birch"
      libbirch_line_(35);
      #line 35 "src/expression/MatrixAdd.birch"
      if ((r = this_()->z.get()->graftLinearMatrixGaussian(handler_)).query()) {
        #line 36 "src/expression/MatrixAdd.birch"
        libbirch_line_(36);
        #line 36 "src/expression/MatrixAdd.birch"
        r.get()->add(this_()->y.get(), handler_);
      } else {
        #line 37 "src/expression/MatrixAdd.birch"
        libbirch_line_(37);
        #line 37 "src/expression/MatrixAdd.birch"
        if ((x1 = this_()->y.get()->graftMatrixGaussian(handler_)).query()) {
          #line 38 "src/expression/MatrixAdd.birch"
          libbirch_line_(38);
          #line 38 "src/expression/MatrixAdd.birch"
          r = birch::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>>(birch::box(birch::identity(this_()->z.get()->rows(handler_), handler_), handler_), x1.get(), this_()->z.get(), handler_);
        } else {
          #line 39 "src/expression/MatrixAdd.birch"
          libbirch_line_(39);
          #line 39 "src/expression/MatrixAdd.birch"
          if ((x1 = this_()->z.get()->graftMatrixGaussian(handler_)).query()) {
            #line 40 "src/expression/MatrixAdd.birch"
            libbirch_line_(40);
            #line 40 "src/expression/MatrixAdd.birch"
            r = birch::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>>(birch::box(birch::identity(this_()->z.get()->rows(handler_), handler_), handler_), x1.get(), this_()->y.get(), handler_);
          }
        }
      }
    }
  }
  #line 43 "src/expression/MatrixAdd.birch"
  libbirch_line_(43);
  #line 43 "src/expression/MatrixAdd.birch"
  return r;
}

#line 46 "src/expression/MatrixAdd.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>>>>> birch::type::MatrixAdd::graftLinearMatrixNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/expression/MatrixAdd.birch"
  libbirch_function_("graftLinearMatrixNormalInverseGamma", "src/expression/MatrixAdd.birch", 46);
  #line 48 "src/expression/MatrixAdd.birch"
  libbirch_line_(48);
  #line 48 "src/expression/MatrixAdd.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>>>>> r;
  #line 49 "src/expression/MatrixAdd.birch"
  libbirch_line_(49);
  #line 49 "src/expression/MatrixAdd.birch"
  if (!this_()->hasValue(handler_)) {
    #line 50 "src/expression/MatrixAdd.birch"
    libbirch_line_(50);
    #line 50 "src/expression/MatrixAdd.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>> x1;
    #line 52 "src/expression/MatrixAdd.birch"
    libbirch_line_(52);
    #line 52 "src/expression/MatrixAdd.birch"
    if ((r = this_()->y.get()->graftLinearMatrixNormalInverseGamma(compare, handler_)).query()) {
      #line 53 "src/expression/MatrixAdd.birch"
      libbirch_line_(53);
      #line 53 "src/expression/MatrixAdd.birch"
      r.get()->add(this_()->z.get(), handler_);
    } else {
      #line 54 "src/expression/MatrixAdd.birch"
      libbirch_line_(54);
      #line 54 "src/expression/MatrixAdd.birch"
      if ((r = this_()->z.get()->graftLinearMatrixNormalInverseGamma(compare, handler_)).query()) {
        #line 55 "src/expression/MatrixAdd.birch"
        libbirch_line_(55);
        #line 55 "src/expression/MatrixAdd.birch"
        r.get()->add(this_()->y.get(), handler_);
      } else {
        #line 56 "src/expression/MatrixAdd.birch"
        libbirch_line_(56);
        #line 56 "src/expression/MatrixAdd.birch"
        if ((x1 = this_()->y.get()->graftMatrixNormalInverseGamma(compare, handler_)).query()) {
          #line 57 "src/expression/MatrixAdd.birch"
          libbirch_line_(57);
          #line 57 "src/expression/MatrixAdd.birch"
          r = birch::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>>(birch::box(birch::identity(this_()->z.get()->rows(handler_), handler_), handler_), x1.get(), this_()->z.get(), handler_);
        } else {
          #line 58 "src/expression/MatrixAdd.birch"
          libbirch_line_(58);
          #line 58 "src/expression/MatrixAdd.birch"
          if ((x1 = this_()->z.get()->graftMatrixNormalInverseGamma(compare, handler_)).query()) {
            #line 59 "src/expression/MatrixAdd.birch"
            libbirch_line_(59);
            #line 59 "src/expression/MatrixAdd.birch"
            r = birch::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>>(birch::box(birch::identity(this_()->z.get()->rows(handler_), handler_), handler_), x1.get(), this_()->y.get(), handler_);
          }
        }
      }
    }
  }
  #line 62 "src/expression/MatrixAdd.birch"
  libbirch_line_(62);
  #line 62 "src/expression/MatrixAdd.birch"
  return r;
}

#line 65 "src/expression/MatrixAdd.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>>>> birch::type::MatrixAdd::graftLinearMatrixNormalInverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::LLT>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "src/expression/MatrixAdd.birch"
  libbirch_function_("graftLinearMatrixNormalInverseWishart", "src/expression/MatrixAdd.birch", 65);
  #line 67 "src/expression/MatrixAdd.birch"
  libbirch_line_(67);
  #line 67 "src/expression/MatrixAdd.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>>>> r;
  #line 68 "src/expression/MatrixAdd.birch"
  libbirch_line_(68);
  #line 68 "src/expression/MatrixAdd.birch"
  if (!this_()->hasValue(handler_)) {
    #line 69 "src/expression/MatrixAdd.birch"
    libbirch_line_(69);
    #line 69 "src/expression/MatrixAdd.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>> x1;
    #line 71 "src/expression/MatrixAdd.birch"
    libbirch_line_(71);
    #line 71 "src/expression/MatrixAdd.birch"
    if ((r = this_()->y.get()->graftLinearMatrixNormalInverseWishart(compare, handler_)).query()) {
      #line 72 "src/expression/MatrixAdd.birch"
      libbirch_line_(72);
      #line 72 "src/expression/MatrixAdd.birch"
      r.get()->add(this_()->z.get(), handler_);
    } else {
      #line 73 "src/expression/MatrixAdd.birch"
      libbirch_line_(73);
      #line 73 "src/expression/MatrixAdd.birch"
      if ((r = this_()->z.get()->graftLinearMatrixNormalInverseWishart(compare, handler_)).query()) {
        #line 74 "src/expression/MatrixAdd.birch"
        libbirch_line_(74);
        #line 74 "src/expression/MatrixAdd.birch"
        r.get()->add(this_()->y.get(), handler_);
      } else {
        #line 75 "src/expression/MatrixAdd.birch"
        libbirch_line_(75);
        #line 75 "src/expression/MatrixAdd.birch"
        if ((x1 = this_()->y.get()->graftMatrixNormalInverseWishart(compare, handler_)).query()) {
          #line 76 "src/expression/MatrixAdd.birch"
          libbirch_line_(76);
          #line 76 "src/expression/MatrixAdd.birch"
          r = birch::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>(birch::box(birch::identity(this_()->z.get()->rows(handler_), handler_), handler_), x1.get(), this_()->z.get(), handler_);
        } else {
          #line 77 "src/expression/MatrixAdd.birch"
          libbirch_line_(77);
          #line 77 "src/expression/MatrixAdd.birch"
          if ((x1 = this_()->z.get()->graftMatrixNormalInverseWishart(compare, handler_)).query()) {
            #line 78 "src/expression/MatrixAdd.birch"
            libbirch_line_(78);
            #line 78 "src/expression/MatrixAdd.birch"
            r = birch::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>(birch::box(birch::identity(this_()->z.get()->rows(handler_), handler_), handler_), x1.get(), this_()->y.get(), handler_);
          }
        }
      }
    }
  }
  #line 81 "src/expression/MatrixAdd.birch"
  libbirch_line_(81);
  #line 81 "src/expression/MatrixAdd.birch"
  return r;
}

#line 88 "src/expression/MatrixAdd.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixAdd>> birch::operator+(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z) {
  #line 88 "src/expression/MatrixAdd.birch"
  libbirch_function_("+", "src/expression/MatrixAdd.birch", 88);
  #line 89 "src/expression/MatrixAdd.birch"
  libbirch_line_(89);
  #line 89 "src/expression/MatrixAdd.birch"
  libbirch_assert_(y->rows() == z->rows());
  #line 90 "src/expression/MatrixAdd.birch"
  libbirch_line_(90);
  #line 90 "src/expression/MatrixAdd.birch"
  libbirch_assert_(y->columns() == z->columns());
  #line 91 "src/expression/MatrixAdd.birch"
  libbirch_line_(91);
  #line 91 "src/expression/MatrixAdd.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixAdd>>>(y, z);
}

#line 97 "src/expression/MatrixAdd.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixAdd>> birch::operator+(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z) {
  #line 97 "src/expression/MatrixAdd.birch"
  libbirch_function_("+", "src/expression/MatrixAdd.birch", 97);
  #line 98 "src/expression/MatrixAdd.birch"
  libbirch_line_(98);
  #line 98 "src/expression/MatrixAdd.birch"
  return birch::box(y) + z;
}

#line 104 "src/expression/MatrixAdd.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixAdd>> birch::operator+(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 104 "src/expression/MatrixAdd.birch"
  libbirch_function_("+", "src/expression/MatrixAdd.birch", 104);
  #line 105 "src/expression/MatrixAdd.birch"
  libbirch_line_(105);
  #line 105 "src/expression/MatrixAdd.birch"
  return y + birch::box(z);
}

#line 27 "src/expression/MatrixCanonical.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>> birch::canonical(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/expression/MatrixCanonical.birch"
  libbirch_function_("canonical", "src/expression/MatrixCanonical.birch", 27);
  #line 28 "src/expression/MatrixCanonical.birch"
  libbirch_line_(28);
  #line 28 "src/expression/MatrixCanonical.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixCanonical<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, birch::type::LLT>>>>(y, handler_);
}

#line 34 "src/expression/MatrixCanonical.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>> birch::canonical(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/expression/MatrixCanonical.birch"
  libbirch_function_("canonical", "src/expression/MatrixCanonical.birch", 34);
  #line 35 "src/expression/MatrixCanonical.birch"
  libbirch_line_(35);
  #line 35 "src/expression/MatrixCanonical.birch"
  if (!y->isRandom(handler_)) {
    #line 37 "src/expression/MatrixCanonical.birch"
    libbirch_line_(37);
    #line 37 "src/expression/MatrixCanonical.birch"
    return y;
  } else {
    #line 41 "src/expression/MatrixCanonical.birch"
    libbirch_line_(41);
    #line 41 "src/expression/MatrixCanonical.birch"
    return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixCanonical<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::DefaultArray<birch::type::Real,2>>>>>(y, handler_);
  }
}

#line 4 "src/expression/MatrixDiagonal.birch"
birch::type::MatrixDiagonal::MatrixDiagonal(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/MatrixDiagonal.birch"
    super_type_(y) {
  //
}

#line 6 "src/expression/MatrixDiagonal.birch"
birch::type::Integer birch::type::MatrixDiagonal::doRows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 6 "src/expression/MatrixDiagonal.birch"
  libbirch_function_("doRows", "src/expression/MatrixDiagonal.birch", 6);
  #line 7 "src/expression/MatrixDiagonal.birch"
  libbirch_line_(7);
  #line 7 "src/expression/MatrixDiagonal.birch"
  return this_()->y.get()->rows(handler_);
}

#line 10 "src/expression/MatrixDiagonal.birch"
birch::type::Integer birch::type::MatrixDiagonal::doColumns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/expression/MatrixDiagonal.birch"
  libbirch_function_("doColumns", "src/expression/MatrixDiagonal.birch", 10);
  #line 11 "src/expression/MatrixDiagonal.birch"
  libbirch_line_(11);
  #line 11 "src/expression/MatrixDiagonal.birch"
  return this_()->y.get()->rows(handler_);
}

#line 14 "src/expression/MatrixDiagonal.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixDiagonal::doEvaluate(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/expression/MatrixDiagonal.birch"
  libbirch_function_("doEvaluate", "src/expression/MatrixDiagonal.birch", 14);
  #line 15 "src/expression/MatrixDiagonal.birch"
  libbirch_line_(15);
  #line 15 "src/expression/MatrixDiagonal.birch"
  return birch::diagonal(y, handler_);
}

#line 18 "src/expression/MatrixDiagonal.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MatrixDiagonal::doEvaluateGrad(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/expression/MatrixDiagonal.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/MatrixDiagonal.birch", 18);
  #line 20 "src/expression/MatrixDiagonal.birch"
  libbirch_line_(20);
  #line 20 "src/expression/MatrixDiagonal.birch"
  return birch::diagonal(d, handler_);
}

#line 27 "src/expression/MatrixDiagonal.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixDiagonal>> birch::diagonal(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/expression/MatrixDiagonal.birch"
  libbirch_function_("diagonal", "src/expression/MatrixDiagonal.birch", 27);
  #line 28 "src/expression/MatrixDiagonal.birch"
  libbirch_line_(28);
  #line 28 "src/expression/MatrixDiagonal.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixDiagonal>>>(x, handler_);
}

#line 71 "src/expression/MatrixElement.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixElement<birch::type::Real>>> birch::MatrixElement(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const birch::type::Integer& i, const birch::type::Integer& j, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 71 "src/expression/MatrixElement.birch"
  libbirch_function_("MatrixElement", "src/expression/MatrixElement.birch", 71);
  #line 73 "src/expression/MatrixElement.birch"
  libbirch_line_(73);
  #line 73 "src/expression/MatrixElement.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixElement<birch::type::Real>>>>(y, i, j, handler_);
}

#line 79 "src/expression/MatrixElement.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixElement<birch::type::Integer>>> birch::MatrixElement(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Integer,2>>>>& y, const birch::type::Integer& i, const birch::type::Integer& j, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 79 "src/expression/MatrixElement.birch"
  libbirch_function_("MatrixElement", "src/expression/MatrixElement.birch", 79);
  #line 81 "src/expression/MatrixElement.birch"
  libbirch_line_(81);
  #line 81 "src/expression/MatrixElement.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixElement<birch::type::Integer>>>>(y, i, j, handler_);
}

#line 87 "src/expression/MatrixElement.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixElement<birch::type::Boolean>>> birch::MatrixElement(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Boolean,2>>>>& y, const birch::type::Integer& i, const birch::type::Integer& j, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 87 "src/expression/MatrixElement.birch"
  libbirch_function_("MatrixElement", "src/expression/MatrixElement.birch", 87);
  #line 89 "src/expression/MatrixElement.birch"
  libbirch_line_(89);
  #line 89 "src/expression/MatrixElement.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixElement<birch::type::Boolean>>>>(y, i, j, handler_);
}

#line 28 "src/expression/MatrixInv.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixInv<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::DefaultArray<birch::type::Real,2>, libbirch::DefaultArray<birch::type::Real,2>>>> birch::inv(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/expression/MatrixInv.birch"
  libbirch_function_("inv", "src/expression/MatrixInv.birch", 28);
  #line 30 "src/expression/MatrixInv.birch"
  libbirch_line_(30);
  #line 30 "src/expression/MatrixInv.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixInv<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::DefaultArray<birch::type::Real,2>, libbirch::DefaultArray<birch::type::Real,2>>>>>(x, handler_);
}

#line 36 "src/expression/MatrixInv.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixInv<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, birch::type::LLT, birch::type::LLT>>> birch::inv(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/expression/MatrixInv.birch"
  libbirch_function_("inv", "src/expression/MatrixInv.birch", 36);
  #line 37 "src/expression/MatrixInv.birch"
  libbirch_line_(37);
  #line 37 "src/expression/MatrixInv.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixInv<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, birch::type::LLT, birch::type::LLT>>>>(x, handler_);
}

#line 4 "src/expression/MatrixLLT.birch"
birch::type::MatrixLLT::MatrixLLT(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/MatrixLLT.birch"
    super_type_(y) {
  //
}

#line 6 "src/expression/MatrixLLT.birch"
birch::type::Integer birch::type::MatrixLLT::doRows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 6 "src/expression/MatrixLLT.birch"
  libbirch_function_("doRows", "src/expression/MatrixLLT.birch", 6);
  #line 7 "src/expression/MatrixLLT.birch"
  libbirch_line_(7);
  #line 7 "src/expression/MatrixLLT.birch"
  return this_()->y.get()->rows(handler_);
}

#line 10 "src/expression/MatrixLLT.birch"
birch::type::Integer birch::type::MatrixLLT::doColumns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/expression/MatrixLLT.birch"
  libbirch_function_("doColumns", "src/expression/MatrixLLT.birch", 10);
  #line 11 "src/expression/MatrixLLT.birch"
  libbirch_line_(11);
  #line 11 "src/expression/MatrixLLT.birch"
  return this_()->y.get()->columns(handler_);
}

#line 14 "src/expression/MatrixLLT.birch"
birch::type::LLT birch::type::MatrixLLT::doEvaluate(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/expression/MatrixLLT.birch"
  libbirch_function_("doEvaluate", "src/expression/MatrixLLT.birch", 14);
  #line 15 "src/expression/MatrixLLT.birch"
  libbirch_line_(15);
  #line 15 "src/expression/MatrixLLT.birch"
  return birch::llt(y, handler_);
}

#line 18 "src/expression/MatrixLLT.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixLLT::doEvaluateGrad(const libbirch::DefaultArray<birch::type::Real,2>& d, const birch::type::LLT& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/expression/MatrixLLT.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/MatrixLLT.birch", 18);
  #line 20 "src/expression/MatrixLLT.birch"
  libbirch_line_(20);
  #line 20 "src/expression/MatrixLLT.birch"
  return d;
}

#line 27 "src/expression/MatrixLLT.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixLLT>> birch::llt(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/expression/MatrixLLT.birch"
  libbirch_function_("llt", "src/expression/MatrixLLT.birch", 27);
  #line 28 "src/expression/MatrixLLT.birch"
  libbirch_line_(28);
  #line 28 "src/expression/MatrixLLT.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixLLT>>>(y, handler_);
}

#line 4 "src/expression/MatrixMultiply.birch"
birch::type::MatrixMultiply::MatrixMultiply(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/MatrixMultiply.birch"
    super_type_(y, z) {
  //
}

#line 8 "src/expression/MatrixMultiply.birch"
birch::type::Integer birch::type::MatrixMultiply::doRows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 8 "src/expression/MatrixMultiply.birch"
  libbirch_function_("doRows", "src/expression/MatrixMultiply.birch", 8);
  #line 9 "src/expression/MatrixMultiply.birch"
  libbirch_line_(9);
  #line 9 "src/expression/MatrixMultiply.birch"
  return this_()->y.get()->rows(handler_);
}

#line 12 "src/expression/MatrixMultiply.birch"
birch::type::Integer birch::type::MatrixMultiply::doColumns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 12 "src/expression/MatrixMultiply.birch"
  libbirch_function_("doColumns", "src/expression/MatrixMultiply.birch", 12);
  #line 13 "src/expression/MatrixMultiply.birch"
  libbirch_line_(13);
  #line 13 "src/expression/MatrixMultiply.birch"
  return this_()->z.get()->columns(handler_);
}

#line 16 "src/expression/MatrixMultiply.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixMultiply::doEvaluate(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/expression/MatrixMultiply.birch"
  libbirch_function_("doEvaluate", "src/expression/MatrixMultiply.birch", 16);
  #line 17 "src/expression/MatrixMultiply.birch"
  libbirch_line_(17);
  #line 17 "src/expression/MatrixMultiply.birch"
  return y * z;
}

#line 20 "src/expression/MatrixMultiply.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixMultiply::doEvaluateGradLeft(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/expression/MatrixMultiply.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/MatrixMultiply.birch", 20);
  #line 22 "src/expression/MatrixMultiply.birch"
  libbirch_line_(22);
  #line 22 "src/expression/MatrixMultiply.birch"
  return d * birch::transpose(z, handler_);
}

#line 25 "src/expression/MatrixMultiply.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixMultiply::doEvaluateGradRight(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/expression/MatrixMultiply.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/MatrixMultiply.birch", 25);
  #line 27 "src/expression/MatrixMultiply.birch"
  libbirch_line_(27);
  #line 27 "src/expression/MatrixMultiply.birch"
  return birch::transpose(y, handler_) * d;
}

#line 30 "src/expression/MatrixMultiply.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>>>>> birch::type::MatrixMultiply::graftLinearMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/expression/MatrixMultiply.birch"
  libbirch_function_("graftLinearMatrixGaussian", "src/expression/MatrixMultiply.birch", 30);
  #line 31 "src/expression/MatrixMultiply.birch"
  libbirch_line_(31);
  #line 31 "src/expression/MatrixMultiply.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>>>>> r;
  #line 32 "src/expression/MatrixMultiply.birch"
  libbirch_line_(32);
  #line 32 "src/expression/MatrixMultiply.birch"
  if (!this_()->hasValue(handler_)) {
    #line 33 "src/expression/MatrixMultiply.birch"
    libbirch_line_(33);
    #line 33 "src/expression/MatrixMultiply.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>> x1;
    #line 35 "src/expression/MatrixMultiply.birch"
    libbirch_line_(35);
    #line 35 "src/expression/MatrixMultiply.birch"
    if ((r = this_()->z.get()->graftLinearMatrixGaussian(handler_)).query()) {
      #line 36 "src/expression/MatrixMultiply.birch"
      libbirch_line_(36);
      #line 36 "src/expression/MatrixMultiply.birch"
      r.get()->leftMultiply(this_()->y.get(), handler_);
    } else {
      #line 37 "src/expression/MatrixMultiply.birch"
      libbirch_line_(37);
      #line 37 "src/expression/MatrixMultiply.birch"
      if ((x1 = this_()->z.get()->graftMatrixGaussian(handler_)).query()) {
        #line 38 "src/expression/MatrixMultiply.birch"
        libbirch_line_(38);
        #line 38 "src/expression/MatrixMultiply.birch"
        r = birch::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>>(this_()->y.get(), x1.get(), handler_);
      }
    }
  }
  #line 41 "src/expression/MatrixMultiply.birch"
  libbirch_line_(41);
  #line 41 "src/expression/MatrixMultiply.birch"
  return r;
}

#line 44 "src/expression/MatrixMultiply.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>>>>> birch::type::MatrixMultiply::graftLinearMatrixNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/expression/MatrixMultiply.birch"
  libbirch_function_("graftLinearMatrixNormalInverseGamma", "src/expression/MatrixMultiply.birch", 44);
  #line 46 "src/expression/MatrixMultiply.birch"
  libbirch_line_(46);
  #line 46 "src/expression/MatrixMultiply.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>>>>> r;
  #line 47 "src/expression/MatrixMultiply.birch"
  libbirch_line_(47);
  #line 47 "src/expression/MatrixMultiply.birch"
  if (!this_()->hasValue(handler_)) {
    #line 48 "src/expression/MatrixMultiply.birch"
    libbirch_line_(48);
    #line 48 "src/expression/MatrixMultiply.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>> x1;
    #line 50 "src/expression/MatrixMultiply.birch"
    libbirch_line_(50);
    #line 50 "src/expression/MatrixMultiply.birch"
    if ((r = this_()->z.get()->graftLinearMatrixNormalInverseGamma(compare, handler_)).query()) {
      #line 51 "src/expression/MatrixMultiply.birch"
      libbirch_line_(51);
      #line 51 "src/expression/MatrixMultiply.birch"
      r.get()->leftMultiply(this_()->y.get(), handler_);
    } else {
      #line 52 "src/expression/MatrixMultiply.birch"
      libbirch_line_(52);
      #line 52 "src/expression/MatrixMultiply.birch"
      if ((x1 = this_()->z.get()->graftMatrixNormalInverseGamma(compare, handler_)).query()) {
        #line 53 "src/expression/MatrixMultiply.birch"
        libbirch_line_(53);
        #line 53 "src/expression/MatrixMultiply.birch"
        r = birch::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>>(this_()->y.get(), x1.get(), handler_);
      }
    }
  }
  #line 56 "src/expression/MatrixMultiply.birch"
  libbirch_line_(56);
  #line 56 "src/expression/MatrixMultiply.birch"
  return r;
}

#line 59 "src/expression/MatrixMultiply.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>>>> birch::type::MatrixMultiply::graftLinearMatrixNormalInverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::LLT>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/expression/MatrixMultiply.birch"
  libbirch_function_("graftLinearMatrixNormalInverseWishart", "src/expression/MatrixMultiply.birch", 59);
  #line 61 "src/expression/MatrixMultiply.birch"
  libbirch_line_(61);
  #line 61 "src/expression/MatrixMultiply.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>>>> r;
  #line 62 "src/expression/MatrixMultiply.birch"
  libbirch_line_(62);
  #line 62 "src/expression/MatrixMultiply.birch"
  if (!this_()->hasValue(handler_)) {
    #line 63 "src/expression/MatrixMultiply.birch"
    libbirch_line_(63);
    #line 63 "src/expression/MatrixMultiply.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>> x1;
    #line 65 "src/expression/MatrixMultiply.birch"
    libbirch_line_(65);
    #line 65 "src/expression/MatrixMultiply.birch"
    if ((r = this_()->z.get()->graftLinearMatrixNormalInverseWishart(compare, handler_)).query()) {
      #line 66 "src/expression/MatrixMultiply.birch"
      libbirch_line_(66);
      #line 66 "src/expression/MatrixMultiply.birch"
      r.get()->leftMultiply(this_()->y.get(), handler_);
    } else {
      #line 67 "src/expression/MatrixMultiply.birch"
      libbirch_line_(67);
      #line 67 "src/expression/MatrixMultiply.birch"
      if ((x1 = this_()->z.get()->graftMatrixNormalInverseWishart(compare, handler_)).query()) {
        #line 68 "src/expression/MatrixMultiply.birch"
        libbirch_line_(68);
        #line 68 "src/expression/MatrixMultiply.birch"
        r = birch::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>(this_()->y.get(), x1.get(), handler_);
      }
    }
  }
  #line 71 "src/expression/MatrixMultiply.birch"
  libbirch_line_(71);
  #line 71 "src/expression/MatrixMultiply.birch"
  return r;
}

#line 78 "src/expression/MatrixMultiply.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixMultiply>> birch::operator*(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z) {
  #line 78 "src/expression/MatrixMultiply.birch"
  libbirch_function_("*", "src/expression/MatrixMultiply.birch", 78);
  #line 80 "src/expression/MatrixMultiply.birch"
  libbirch_line_(80);
  #line 80 "src/expression/MatrixMultiply.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixMultiply>>>(y, z);
}

#line 86 "src/expression/MatrixMultiply.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixMultiply>> birch::operator*(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z) {
  #line 86 "src/expression/MatrixMultiply.birch"
  libbirch_function_("*", "src/expression/MatrixMultiply.birch", 86);
  #line 87 "src/expression/MatrixMultiply.birch"
  libbirch_line_(87);
  #line 87 "src/expression/MatrixMultiply.birch"
  return birch::box(y) * z;
}

#line 93 "src/expression/MatrixMultiply.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixMultiply>> birch::operator*(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 93 "src/expression/MatrixMultiply.birch"
  libbirch_function_("*", "src/expression/MatrixMultiply.birch", 93);
  #line 94 "src/expression/MatrixMultiply.birch"
  libbirch_line_(94);
  #line 94 "src/expression/MatrixMultiply.birch"
  return y * birch::box(z);
}

#line 4 "src/expression/MatrixNegate.birch"
birch::type::MatrixNegate::MatrixNegate(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/MatrixNegate.birch"
    super_type_(y) {
  //
}

#line 7 "src/expression/MatrixNegate.birch"
birch::type::Integer birch::type::MatrixNegate::doRows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/MatrixNegate.birch"
  libbirch_function_("doRows", "src/expression/MatrixNegate.birch", 7);
  #line 8 "src/expression/MatrixNegate.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MatrixNegate.birch"
  return this_()->y.get()->rows(handler_);
}

#line 11 "src/expression/MatrixNegate.birch"
birch::type::Integer birch::type::MatrixNegate::doColumns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/MatrixNegate.birch"
  libbirch_function_("doColumns", "src/expression/MatrixNegate.birch", 11);
  #line 12 "src/expression/MatrixNegate.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MatrixNegate.birch"
  return this_()->y.get()->columns(handler_);
}

#line 15 "src/expression/MatrixNegate.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixNegate::doEvaluate(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/expression/MatrixNegate.birch"
  libbirch_function_("doEvaluate", "src/expression/MatrixNegate.birch", 15);
  #line 16 "src/expression/MatrixNegate.birch"
  libbirch_line_(16);
  #line 16 "src/expression/MatrixNegate.birch"
  return -y;
}

#line 19 "src/expression/MatrixNegate.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixNegate::doEvaluateGrad(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/expression/MatrixNegate.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/MatrixNegate.birch", 19);
  #line 21 "src/expression/MatrixNegate.birch"
  libbirch_line_(21);
  #line 21 "src/expression/MatrixNegate.birch"
  return -d;
}

#line 24 "src/expression/MatrixNegate.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>>>>> birch::type::MatrixNegate::graftLinearMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/expression/MatrixNegate.birch"
  libbirch_function_("graftLinearMatrixGaussian", "src/expression/MatrixNegate.birch", 24);
  #line 26 "src/expression/MatrixNegate.birch"
  libbirch_line_(26);
  #line 26 "src/expression/MatrixNegate.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>>>>> r;
  #line 27 "src/expression/MatrixNegate.birch"
  libbirch_line_(27);
  #line 27 "src/expression/MatrixNegate.birch"
  if (!this_()->hasValue(handler_)) {
    #line 28 "src/expression/MatrixNegate.birch"
    libbirch_line_(28);
    #line 28 "src/expression/MatrixNegate.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>> x1;
    #line 30 "src/expression/MatrixNegate.birch"
    libbirch_line_(30);
    #line 30 "src/expression/MatrixNegate.birch"
    if ((r = this_()->y.get()->graftLinearMatrixGaussian(handler_)).query()) {
      #line 31 "src/expression/MatrixNegate.birch"
      libbirch_line_(31);
      #line 31 "src/expression/MatrixNegate.birch"
      r.get()->negate(handler_);
    } else {
      #line 32 "src/expression/MatrixNegate.birch"
      libbirch_line_(32);
      #line 32 "src/expression/MatrixNegate.birch"
      if ((x1 = this_()->y.get()->graftMatrixGaussian(handler_)).query()) {
        #line 33 "src/expression/MatrixNegate.birch"
        libbirch_line_(33);
        #line 33 "src/expression/MatrixNegate.birch"
        auto R = x1.get()->rows(handler_);
        #line 34 "src/expression/MatrixNegate.birch"
        libbirch_line_(34);
        #line 34 "src/expression/MatrixNegate.birch"
        auto C = x1.get()->columns(handler_);
        #line 35 "src/expression/MatrixNegate.birch"
        libbirch_line_(35);
        #line 35 "src/expression/MatrixNegate.birch"
        r = birch::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>>(birch::diagonal(birch::box(-1.0, handler_), R, handler_), x1.get(), birch::box(birch::matrix(0.0, R, C, handler_), handler_), handler_);
      }
    }
  }
  #line 39 "src/expression/MatrixNegate.birch"
  libbirch_line_(39);
  #line 39 "src/expression/MatrixNegate.birch"
  return r;
}

#line 42 "src/expression/MatrixNegate.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>>>>> birch::type::MatrixNegate::graftLinearMatrixNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/expression/MatrixNegate.birch"
  libbirch_function_("graftLinearMatrixNormalInverseGamma", "src/expression/MatrixNegate.birch", 42);
  #line 44 "src/expression/MatrixNegate.birch"
  libbirch_line_(44);
  #line 44 "src/expression/MatrixNegate.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>>>>> r;
  #line 45 "src/expression/MatrixNegate.birch"
  libbirch_line_(45);
  #line 45 "src/expression/MatrixNegate.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>> x1;
  #line 47 "src/expression/MatrixNegate.birch"
  libbirch_line_(47);
  #line 47 "src/expression/MatrixNegate.birch"
  if ((r = this_()->y.get()->graftLinearMatrixNormalInverseGamma(compare, handler_)).query()) {
    #line 48 "src/expression/MatrixNegate.birch"
    libbirch_line_(48);
    #line 48 "src/expression/MatrixNegate.birch"
    r.get()->negate(handler_);
  } else {
    #line 49 "src/expression/MatrixNegate.birch"
    libbirch_line_(49);
    #line 49 "src/expression/MatrixNegate.birch"
    if ((x1 = this_()->y.get()->graftMatrixNormalInverseGamma(compare, handler_)).query()) {
      #line 50 "src/expression/MatrixNegate.birch"
      libbirch_line_(50);
      #line 50 "src/expression/MatrixNegate.birch"
      auto R = x1.get()->rows(handler_);
      #line 51 "src/expression/MatrixNegate.birch"
      libbirch_line_(51);
      #line 51 "src/expression/MatrixNegate.birch"
      auto C = x1.get()->columns(handler_);
      #line 52 "src/expression/MatrixNegate.birch"
      libbirch_line_(52);
      #line 52 "src/expression/MatrixNegate.birch"
      r = birch::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>>(birch::diagonal(birch::box(-1.0, handler_), R, handler_), x1.get(), birch::box(birch::matrix(0.0, R, C, handler_), handler_), handler_);
    }
  }
  #line 55 "src/expression/MatrixNegate.birch"
  libbirch_line_(55);
  #line 55 "src/expression/MatrixNegate.birch"
  return r;
}

#line 58 "src/expression/MatrixNegate.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>>>> birch::type::MatrixNegate::graftLinearMatrixNormalInverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::LLT>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "src/expression/MatrixNegate.birch"
  libbirch_function_("graftLinearMatrixNormalInverseWishart", "src/expression/MatrixNegate.birch", 58);
  #line 60 "src/expression/MatrixNegate.birch"
  libbirch_line_(60);
  #line 60 "src/expression/MatrixNegate.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>>>> r;
  #line 61 "src/expression/MatrixNegate.birch"
  libbirch_line_(61);
  #line 61 "src/expression/MatrixNegate.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>> x1;
  #line 63 "src/expression/MatrixNegate.birch"
  libbirch_line_(63);
  #line 63 "src/expression/MatrixNegate.birch"
  if ((r = this_()->y.get()->graftLinearMatrixNormalInverseWishart(compare, handler_)).query()) {
    #line 64 "src/expression/MatrixNegate.birch"
    libbirch_line_(64);
    #line 64 "src/expression/MatrixNegate.birch"
    r.get()->negate(handler_);
  } else {
    #line 65 "src/expression/MatrixNegate.birch"
    libbirch_line_(65);
    #line 65 "src/expression/MatrixNegate.birch"
    if ((x1 = this_()->y.get()->graftMatrixNormalInverseWishart(compare, handler_)).query()) {
      #line 66 "src/expression/MatrixNegate.birch"
      libbirch_line_(66);
      #line 66 "src/expression/MatrixNegate.birch"
      auto R = x1.get()->rows(handler_);
      #line 67 "src/expression/MatrixNegate.birch"
      libbirch_line_(67);
      #line 67 "src/expression/MatrixNegate.birch"
      auto C = x1.get()->columns(handler_);
      #line 68 "src/expression/MatrixNegate.birch"
      libbirch_line_(68);
      #line 68 "src/expression/MatrixNegate.birch"
      r = birch::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>(birch::diagonal(birch::box(-1.0, handler_), R, handler_), x1.get(), birch::box(birch::matrix(0.0, R, C, handler_), handler_), handler_);
    }
  }
  #line 71 "src/expression/MatrixNegate.birch"
  libbirch_line_(71);
  #line 71 "src/expression/MatrixNegate.birch"
  return r;
}

#line 78 "src/expression/MatrixNegate.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixNegate>> birch::operator-(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y) {
  #line 78 "src/expression/MatrixNegate.birch"
  libbirch_function_("-", "src/expression/MatrixNegate.birch", 78);
  #line 79 "src/expression/MatrixNegate.birch"
  libbirch_line_(79);
  #line 79 "src/expression/MatrixNegate.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNegate>>>(y);
}

#line 4 "src/expression/MatrixPack.birch"
birch::type::MatrixPack::MatrixPack(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/MatrixPack.birch"
    super_type_(y, z) {
  //
}

#line 7 "src/expression/MatrixPack.birch"
birch::type::Integer birch::type::MatrixPack::doRows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/MatrixPack.birch"
  libbirch_function_("doRows", "src/expression/MatrixPack.birch", 7);
  #line 8 "src/expression/MatrixPack.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MatrixPack.birch"
  return this_()->y.get()->rows(handler_);
}

#line 11 "src/expression/MatrixPack.birch"
birch::type::Integer birch::type::MatrixPack::doColumns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/MatrixPack.birch"
  libbirch_function_("doColumns", "src/expression/MatrixPack.birch", 11);
  #line 12 "src/expression/MatrixPack.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MatrixPack.birch"
  return this_()->y.get()->columns(handler_) + this_()->z.get()->columns(handler_);
}

#line 15 "src/expression/MatrixPack.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixPack::doEvaluate(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/expression/MatrixPack.birch"
  libbirch_function_("doEvaluate", "src/expression/MatrixPack.birch", 15);
  #line 16 "src/expression/MatrixPack.birch"
  libbirch_line_(16);
  #line 16 "src/expression/MatrixPack.birch"
  return birch::pack(y, z, handler_);
}

#line 19 "src/expression/MatrixPack.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixPack::doEvaluateGradLeft(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/expression/MatrixPack.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/MatrixPack.birch", 19);
  #line 21 "src/expression/MatrixPack.birch"
  libbirch_line_(21);
  #line 21 "src/expression/MatrixPack.birch"
  return d.get(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, birch::rows(y, handler_) - 1), libbirch::make_range(birch::type::Integer(1) - 1, birch::columns(y, handler_) - 1)));
}

#line 24 "src/expression/MatrixPack.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixPack::doEvaluateGradRight(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/expression/MatrixPack.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/MatrixPack.birch", 24);
  #line 26 "src/expression/MatrixPack.birch"
  libbirch_line_(26);
  #line 26 "src/expression/MatrixPack.birch"
  return d.get(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, birch::rows(y, handler_) - 1), libbirch::make_range((birch::columns(y, handler_) + birch::type::Integer(1)) - 1, birch::columns(x, handler_) - 1)));
}

#line 33 "src/expression/MatrixPack.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixPack>> birch::pack(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/expression/MatrixPack.birch"
  libbirch_function_("pack", "src/expression/MatrixPack.birch", 33);
  #line 35 "src/expression/MatrixPack.birch"
  libbirch_line_(35);
  #line 35 "src/expression/MatrixPack.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixPack>>>(y, z, handler_);
}

#line 41 "src/expression/MatrixPack.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixPack>> birch::pack(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "src/expression/MatrixPack.birch"
  libbirch_function_("pack", "src/expression/MatrixPack.birch", 41);
  #line 42 "src/expression/MatrixPack.birch"
  libbirch_line_(42);
  #line 42 "src/expression/MatrixPack.birch"
  return birch::pack(birch::box(y, handler_), z, handler_);
}

#line 48 "src/expression/MatrixPack.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixPack>> birch::pack(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::DefaultArray<birch::type::Real,2>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "src/expression/MatrixPack.birch"
  libbirch_function_("pack", "src/expression/MatrixPack.birch", 48);
  #line 49 "src/expression/MatrixPack.birch"
  libbirch_line_(49);
  #line 49 "src/expression/MatrixPack.birch"
  return birch::pack(y, birch::box(z, handler_), handler_);
}

#line 33 "src/expression/MatrixRankDowndate.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixRankDowndate<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>, libbirch::DefaultArray<birch::type::Real,1>, libbirch::DefaultArray<birch::type::Real,1>>>> birch::rank_downdate(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/expression/MatrixRankDowndate.birch"
  libbirch_function_("rank_downdate", "src/expression/MatrixRankDowndate.birch", 33);
  #line 35 "src/expression/MatrixRankDowndate.birch"
  libbirch_line_(35);
  #line 35 "src/expression/MatrixRankDowndate.birch"
  libbirch_assert_(y.get()->columns(handler_) == z.get()->rows(handler_));
  #line 36 "src/expression/MatrixRankDowndate.birch"
  libbirch_line_(36);
  #line 36 "src/expression/MatrixRankDowndate.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixRankDowndate<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>, libbirch::DefaultArray<birch::type::Real,1>, libbirch::DefaultArray<birch::type::Real,1>>>>>(y, z, handler_);
}

#line 42 "src/expression/MatrixRankDowndate.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixRankDowndate<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>, libbirch::DefaultArray<birch::type::Real,1>, libbirch::DefaultArray<birch::type::Real,1>>>> birch::rank_downdate(const birch::type::LLT& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/expression/MatrixRankDowndate.birch"
  libbirch_function_("rank_downdate", "src/expression/MatrixRankDowndate.birch", 42);
  #line 44 "src/expression/MatrixRankDowndate.birch"
  libbirch_line_(44);
  #line 44 "src/expression/MatrixRankDowndate.birch"
  return birch::rank_downdate(birch::box(y, handler_), z, handler_);
}

#line 50 "src/expression/MatrixRankDowndate.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixRankDowndate<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>, libbirch::DefaultArray<birch::type::Real,1>, libbirch::DefaultArray<birch::type::Real,1>>>> birch::rank_downdate(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& y, const libbirch::DefaultArray<birch::type::Real,1>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "src/expression/MatrixRankDowndate.birch"
  libbirch_function_("rank_downdate", "src/expression/MatrixRankDowndate.birch", 50);
  #line 52 "src/expression/MatrixRankDowndate.birch"
  libbirch_line_(52);
  #line 52 "src/expression/MatrixRankDowndate.birch"
  return birch::rank_downdate(y, birch::box(z, handler_), handler_);
}

#line 58 "src/expression/MatrixRankDowndate.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixRankDowndate<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::DefaultArray<birch::type::Real,2>, libbirch::DefaultArray<birch::type::Real,2>>>> birch::rank_downdate(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "src/expression/MatrixRankDowndate.birch"
  libbirch_function_("rank_downdate", "src/expression/MatrixRankDowndate.birch", 58);
  #line 60 "src/expression/MatrixRankDowndate.birch"
  libbirch_line_(60);
  #line 60 "src/expression/MatrixRankDowndate.birch"
  libbirch_assert_(y.get()->columns(handler_) == z.get()->rows(handler_));
  #line 61 "src/expression/MatrixRankDowndate.birch"
  libbirch_line_(61);
  #line 61 "src/expression/MatrixRankDowndate.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixRankDowndate<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::DefaultArray<birch::type::Real,2>, libbirch::DefaultArray<birch::type::Real,2>>>>>(y, z, handler_);
}

#line 67 "src/expression/MatrixRankDowndate.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixRankDowndate<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::DefaultArray<birch::type::Real,2>, libbirch::DefaultArray<birch::type::Real,2>>>> birch::rank_downdate(const birch::type::LLT& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 67 "src/expression/MatrixRankDowndate.birch"
  libbirch_function_("rank_downdate", "src/expression/MatrixRankDowndate.birch", 67);
  #line 69 "src/expression/MatrixRankDowndate.birch"
  libbirch_line_(69);
  #line 69 "src/expression/MatrixRankDowndate.birch"
  return birch::rank_downdate(birch::box(y, handler_), z, handler_);
}

#line 75 "src/expression/MatrixRankDowndate.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixRankDowndate<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::DefaultArray<birch::type::Real,2>, libbirch::DefaultArray<birch::type::Real,2>>>> birch::rank_downdate(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& y, const libbirch::DefaultArray<birch::type::Real,2>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 75 "src/expression/MatrixRankDowndate.birch"
  libbirch_function_("rank_downdate", "src/expression/MatrixRankDowndate.birch", 75);
  #line 77 "src/expression/MatrixRankDowndate.birch"
  libbirch_line_(77);
  #line 77 "src/expression/MatrixRankDowndate.birch"
  return birch::rank_downdate(y, birch::box(z, handler_), handler_);
}

#line 33 "src/expression/MatrixRankUpdate.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixRankUpdate<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>, libbirch::DefaultArray<birch::type::Real,1>, libbirch::DefaultArray<birch::type::Real,1>>>> birch::rank_update(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/expression/MatrixRankUpdate.birch"
  libbirch_function_("rank_update", "src/expression/MatrixRankUpdate.birch", 33);
  #line 35 "src/expression/MatrixRankUpdate.birch"
  libbirch_line_(35);
  #line 35 "src/expression/MatrixRankUpdate.birch"
  libbirch_assert_(y.get()->columns(handler_) == z.get()->rows(handler_));
  #line 36 "src/expression/MatrixRankUpdate.birch"
  libbirch_line_(36);
  #line 36 "src/expression/MatrixRankUpdate.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixRankUpdate<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>, libbirch::DefaultArray<birch::type::Real,1>, libbirch::DefaultArray<birch::type::Real,1>>>>>(y, z, handler_);
}

#line 42 "src/expression/MatrixRankUpdate.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixRankUpdate<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>, libbirch::DefaultArray<birch::type::Real,1>, libbirch::DefaultArray<birch::type::Real,1>>>> birch::rank_update(const birch::type::LLT& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/expression/MatrixRankUpdate.birch"
  libbirch_function_("rank_update", "src/expression/MatrixRankUpdate.birch", 42);
  #line 44 "src/expression/MatrixRankUpdate.birch"
  libbirch_line_(44);
  #line 44 "src/expression/MatrixRankUpdate.birch"
  return birch::rank_update(birch::box(y, handler_), z, handler_);
}

#line 50 "src/expression/MatrixRankUpdate.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixRankUpdate<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>, libbirch::DefaultArray<birch::type::Real,1>, libbirch::DefaultArray<birch::type::Real,1>>>> birch::rank_update(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& y, const libbirch::DefaultArray<birch::type::Real,1>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "src/expression/MatrixRankUpdate.birch"
  libbirch_function_("rank_update", "src/expression/MatrixRankUpdate.birch", 50);
  #line 52 "src/expression/MatrixRankUpdate.birch"
  libbirch_line_(52);
  #line 52 "src/expression/MatrixRankUpdate.birch"
  return birch::rank_update(y, birch::box(z, handler_), handler_);
}

#line 58 "src/expression/MatrixRankUpdate.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixRankUpdate<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::DefaultArray<birch::type::Real,2>, libbirch::DefaultArray<birch::type::Real,2>>>> birch::rank_update(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "src/expression/MatrixRankUpdate.birch"
  libbirch_function_("rank_update", "src/expression/MatrixRankUpdate.birch", 58);
  #line 60 "src/expression/MatrixRankUpdate.birch"
  libbirch_line_(60);
  #line 60 "src/expression/MatrixRankUpdate.birch"
  libbirch_assert_(y.get()->columns(handler_) == z.get()->rows(handler_));
  #line 61 "src/expression/MatrixRankUpdate.birch"
  libbirch_line_(61);
  #line 61 "src/expression/MatrixRankUpdate.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixRankUpdate<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::DefaultArray<birch::type::Real,2>, libbirch::DefaultArray<birch::type::Real,2>>>>>(y, z, handler_);
}

#line 68 "src/expression/MatrixRankUpdate.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixRankUpdate<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::DefaultArray<birch::type::Real,2>, libbirch::DefaultArray<birch::type::Real,2>>>> birch::rank_update(const birch::type::LLT& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 68 "src/expression/MatrixRankUpdate.birch"
  libbirch_function_("rank_update", "src/expression/MatrixRankUpdate.birch", 68);
  #line 70 "src/expression/MatrixRankUpdate.birch"
  libbirch_line_(70);
  #line 70 "src/expression/MatrixRankUpdate.birch"
  return birch::rank_update(birch::box(y, handler_), z, handler_);
}

#line 76 "src/expression/MatrixRankUpdate.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixRankUpdate<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::DefaultArray<birch::type::Real,2>, libbirch::DefaultArray<birch::type::Real,2>>>> birch::rank_update(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& y, const libbirch::DefaultArray<birch::type::Real,2>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "src/expression/MatrixRankUpdate.birch"
  libbirch_function_("rank_update", "src/expression/MatrixRankUpdate.birch", 76);
  #line 78 "src/expression/MatrixRankUpdate.birch"
  libbirch_line_(78);
  #line 78 "src/expression/MatrixRankUpdate.birch"
  return birch::rank_update(y, birch::box(z, handler_), handler_);
}

#line 4 "src/expression/MatrixRectify.birch"
birch::type::MatrixRectify::MatrixRectify(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/MatrixRectify.birch"
    super_type_(y) {
  //
}

#line 7 "src/expression/MatrixRectify.birch"
birch::type::Integer birch::type::MatrixRectify::doRows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/MatrixRectify.birch"
  libbirch_function_("doRows", "src/expression/MatrixRectify.birch", 7);
  #line 8 "src/expression/MatrixRectify.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MatrixRectify.birch"
  return this_()->y.get()->rows(handler_);
}

#line 11 "src/expression/MatrixRectify.birch"
birch::type::Integer birch::type::MatrixRectify::doColumns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/MatrixRectify.birch"
  libbirch_function_("doColumns", "src/expression/MatrixRectify.birch", 11);
  #line 12 "src/expression/MatrixRectify.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MatrixRectify.birch"
  return this_()->y.get()->columns(handler_);
}

#line 15 "src/expression/MatrixRectify.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixRectify::doEvaluate(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/expression/MatrixRectify.birch"
  libbirch_function_("doEvaluate", "src/expression/MatrixRectify.birch", 15);
  #line 16 "src/expression/MatrixRectify.birch"
  libbirch_line_(16);
  #line 16 "src/expression/MatrixRectify.birch"
  return birch::transform(y, std::function<birch::type::Real(birch::type::Real,const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_
)>([=](const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr) {
    #line 16 "src/expression/MatrixRectify.birch"
    libbirch_line_(16);
    #line 16 "src/expression/MatrixRectify.birch"
    return birch::rectify(y, handler_);
  }), handler_);
}

#line 19 "src/expression/MatrixRectify.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixRectify::doEvaluateGrad(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/expression/MatrixRectify.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/MatrixRectify.birch", 19);
  #line 21 "src/expression/MatrixRectify.birch"
  libbirch_line_(21);
  #line 21 "src/expression/MatrixRectify.birch"
  return birch::transform(d, x, std::function<birch::type::Real(birch::type::Real,birch::type::Real,const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_
)>([=](const birch::type::Real& d, const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr) {
    #line 22 "src/expression/MatrixRectify.birch"
    libbirch_line_(22);
    #line 22 "src/expression/MatrixRectify.birch"
    if (x > 0.0) {
      #line 23 "src/expression/MatrixRectify.birch"
      libbirch_line_(23);
      #line 23 "src/expression/MatrixRectify.birch"
      return d;
    } else {
      #line 25 "src/expression/MatrixRectify.birch"
      libbirch_line_(25);
      #line 25 "src/expression/MatrixRectify.birch"
      return 0.0;
    }
  }), handler_);
}

#line 34 "src/expression/MatrixRectify.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixRectify>> birch::rectify(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/expression/MatrixRectify.birch"
  libbirch_function_("rectify", "src/expression/MatrixRectify.birch", 34);
  #line 35 "src/expression/MatrixRectify.birch"
  libbirch_line_(35);
  #line 35 "src/expression/MatrixRectify.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixRectify>>>(y, handler_);
}

#line 4 "src/expression/MatrixScalarDivide.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>> birch::operator/(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z) {
  #line 4 "src/expression/MatrixScalarDivide.birch"
  libbirch_function_("/", "src/expression/MatrixScalarDivide.birch", 4);
  #line 6 "src/expression/MatrixScalarDivide.birch"
  libbirch_line_(6);
  #line 6 "src/expression/MatrixScalarDivide.birch"
  return (1.0 / z) * y;
}

#line 12 "src/expression/MatrixScalarDivide.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>> birch::operator/(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z) {
  #line 12 "src/expression/MatrixScalarDivide.birch"
  libbirch_function_("/", "src/expression/MatrixScalarDivide.birch", 12);
  #line 13 "src/expression/MatrixScalarDivide.birch"
  libbirch_line_(13);
  #line 13 "src/expression/MatrixScalarDivide.birch"
  return (1.0 / z) * birch::box(y);
}

#line 19 "src/expression/MatrixScalarDivide.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>> birch::operator/(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const birch::type::Real& z) {
  #line 19 "src/expression/MatrixScalarDivide.birch"
  libbirch_function_("/", "src/expression/MatrixScalarDivide.birch", 19);
  #line 20 "src/expression/MatrixScalarDivide.birch"
  libbirch_line_(20);
  #line 20 "src/expression/MatrixScalarDivide.birch"
  return birch::box(1.0 / z) * y;
}

#line 4 "src/expression/MatrixScalarMultiply.birch"
birch::type::MatrixScalarMultiply::MatrixScalarMultiply(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/MatrixScalarMultiply.birch"
    super_type_(y, z) {
  //
}

#line 7 "src/expression/MatrixScalarMultiply.birch"
birch::type::Integer birch::type::MatrixScalarMultiply::doRows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("doRows", "src/expression/MatrixScalarMultiply.birch", 7);
  #line 8 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MatrixScalarMultiply.birch"
  return this_()->z.get()->rows(handler_);
}

#line 11 "src/expression/MatrixScalarMultiply.birch"
birch::type::Integer birch::type::MatrixScalarMultiply::doColumns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("doColumns", "src/expression/MatrixScalarMultiply.birch", 11);
  #line 12 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MatrixScalarMultiply.birch"
  return this_()->z.get()->columns(handler_);
}

#line 15 "src/expression/MatrixScalarMultiply.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixScalarMultiply::doEvaluate(const birch::type::Real& y, const libbirch::DefaultArray<birch::type::Real,2>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("doEvaluate", "src/expression/MatrixScalarMultiply.birch", 15);
  #line 16 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(16);
  #line 16 "src/expression/MatrixScalarMultiply.birch"
  return y * z;
}

#line 19 "src/expression/MatrixScalarMultiply.birch"
birch::type::Real birch::type::MatrixScalarMultiply::doEvaluateGradLeft(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const birch::type::Real& y, const libbirch::DefaultArray<birch::type::Real,2>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/MatrixScalarMultiply.birch", 19);
  #line 21 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(21);
  #line 21 "src/expression/MatrixScalarMultiply.birch"
  return birch::trace(d * birch::transpose(z, handler_), handler_);
}

#line 24 "src/expression/MatrixScalarMultiply.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixScalarMultiply::doEvaluateGradRight(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const birch::type::Real& y, const libbirch::DefaultArray<birch::type::Real,2>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/MatrixScalarMultiply.birch", 24);
  #line 26 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(26);
  #line 26 "src/expression/MatrixScalarMultiply.birch"
  return y * d;
}

#line 29 "src/expression/MatrixScalarMultiply.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>>>>> birch::type::MatrixScalarMultiply::graftLinearMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("graftLinearMatrixGaussian", "src/expression/MatrixScalarMultiply.birch", 29);
  #line 30 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(30);
  #line 30 "src/expression/MatrixScalarMultiply.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>>>>> r;
  #line 31 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(31);
  #line 31 "src/expression/MatrixScalarMultiply.birch"
  if (!this_()->hasValue(handler_)) {
    #line 32 "src/expression/MatrixScalarMultiply.birch"
    libbirch_line_(32);
    #line 32 "src/expression/MatrixScalarMultiply.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>> x1;
    #line 34 "src/expression/MatrixScalarMultiply.birch"
    libbirch_line_(34);
    #line 34 "src/expression/MatrixScalarMultiply.birch"
    if ((r = this_()->z.get()->graftLinearMatrixGaussian(handler_)).query()) {
      #line 35 "src/expression/MatrixScalarMultiply.birch"
      libbirch_line_(35);
      #line 35 "src/expression/MatrixScalarMultiply.birch"
      r.get()->multiply(this_()->y.get(), handler_);
    } else {
      #line 36 "src/expression/MatrixScalarMultiply.birch"
      libbirch_line_(36);
      #line 36 "src/expression/MatrixScalarMultiply.birch"
      if ((x1 = this_()->z.get()->graftMatrixGaussian(handler_)).query()) {
        #line 37 "src/expression/MatrixScalarMultiply.birch"
        libbirch_line_(37);
        #line 37 "src/expression/MatrixScalarMultiply.birch"
        r = birch::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>>(birch::diagonal(this_()->y.get(), this_()->z.get()->rows(handler_), handler_), x1.get(), handler_);
      }
    }
  }
  #line 40 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(40);
  #line 40 "src/expression/MatrixScalarMultiply.birch"
  return r;
}

#line 43 "src/expression/MatrixScalarMultiply.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>>>>> birch::type::MatrixScalarMultiply::graftLinearMatrixNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("graftLinearMatrixNormalInverseGamma", "src/expression/MatrixScalarMultiply.birch", 43);
  #line 45 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(45);
  #line 45 "src/expression/MatrixScalarMultiply.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>>>>> r;
  #line 46 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(46);
  #line 46 "src/expression/MatrixScalarMultiply.birch"
  if (!this_()->hasValue(handler_)) {
    #line 47 "src/expression/MatrixScalarMultiply.birch"
    libbirch_line_(47);
    #line 47 "src/expression/MatrixScalarMultiply.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>> x1;
    #line 49 "src/expression/MatrixScalarMultiply.birch"
    libbirch_line_(49);
    #line 49 "src/expression/MatrixScalarMultiply.birch"
    if ((r = this_()->z.get()->graftLinearMatrixNormalInverseGamma(compare, handler_)).query()) {
      #line 50 "src/expression/MatrixScalarMultiply.birch"
      libbirch_line_(50);
      #line 50 "src/expression/MatrixScalarMultiply.birch"
      r.get()->multiply(this_()->y.get(), handler_);
    } else {
      #line 51 "src/expression/MatrixScalarMultiply.birch"
      libbirch_line_(51);
      #line 51 "src/expression/MatrixScalarMultiply.birch"
      if ((x1 = this_()->z.get()->graftMatrixNormalInverseGamma(compare, handler_)).query()) {
        #line 52 "src/expression/MatrixScalarMultiply.birch"
        libbirch_line_(52);
        #line 52 "src/expression/MatrixScalarMultiply.birch"
        r = birch::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>>(birch::diagonal(this_()->y.get(), this_()->z.get()->rows(handler_), handler_), x1.get(), handler_);
      }
    }
  }
  #line 55 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(55);
  #line 55 "src/expression/MatrixScalarMultiply.birch"
  return r;
}

#line 58 "src/expression/MatrixScalarMultiply.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>>>> birch::type::MatrixScalarMultiply::graftLinearMatrixNormalInverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::LLT>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("graftLinearMatrixNormalInverseWishart", "src/expression/MatrixScalarMultiply.birch", 58);
  #line 60 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(60);
  #line 60 "src/expression/MatrixScalarMultiply.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>>>> r;
  #line 61 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(61);
  #line 61 "src/expression/MatrixScalarMultiply.birch"
  if (!this_()->hasValue(handler_)) {
    #line 62 "src/expression/MatrixScalarMultiply.birch"
    libbirch_line_(62);
    #line 62 "src/expression/MatrixScalarMultiply.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>> x1;
    #line 64 "src/expression/MatrixScalarMultiply.birch"
    libbirch_line_(64);
    #line 64 "src/expression/MatrixScalarMultiply.birch"
    if ((r = this_()->z.get()->graftLinearMatrixNormalInverseWishart(compare, handler_)).query()) {
      #line 65 "src/expression/MatrixScalarMultiply.birch"
      libbirch_line_(65);
      #line 65 "src/expression/MatrixScalarMultiply.birch"
      r.get()->multiply(this_()->y.get(), handler_);
    } else {
      #line 66 "src/expression/MatrixScalarMultiply.birch"
      libbirch_line_(66);
      #line 66 "src/expression/MatrixScalarMultiply.birch"
      if ((x1 = this_()->z.get()->graftMatrixNormalInverseWishart(compare, handler_)).query()) {
        #line 67 "src/expression/MatrixScalarMultiply.birch"
        libbirch_line_(67);
        #line 67 "src/expression/MatrixScalarMultiply.birch"
        r = birch::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>(birch::diagonal(this_()->y.get(), this_()->z.get()->rows(handler_), handler_), x1.get(), handler_);
      }
    }
  }
  #line 70 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(70);
  #line 70 "src/expression/MatrixScalarMultiply.birch"
  return r;
}

#line 77 "src/expression/MatrixScalarMultiply.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixScalarMultiply>> birch::operator*(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z) {
  #line 77 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("*", "src/expression/MatrixScalarMultiply.birch", 77);
  #line 79 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(79);
  #line 79 "src/expression/MatrixScalarMultiply.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixScalarMultiply>>>(y, z);
}

#line 85 "src/expression/MatrixScalarMultiply.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixScalarMultiply>> birch::operator*(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z) {
  #line 85 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("*", "src/expression/MatrixScalarMultiply.birch", 85);
  #line 86 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(86);
  #line 86 "src/expression/MatrixScalarMultiply.birch"
  return birch::box(y) * z;
}

#line 92 "src/expression/MatrixScalarMultiply.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixScalarMultiply>> birch::operator*(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 92 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("*", "src/expression/MatrixScalarMultiply.birch", 92);
  #line 93 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(93);
  #line 93 "src/expression/MatrixScalarMultiply.birch"
  return y * birch::box(z);
}

#line 99 "src/expression/MatrixScalarMultiply.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixScalarMultiply>> birch::operator*(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z) {
  #line 99 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("*", "src/expression/MatrixScalarMultiply.birch", 99);
  #line 100 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(100);
  #line 100 "src/expression/MatrixScalarMultiply.birch"
  return z * y;
}

#line 106 "src/expression/MatrixScalarMultiply.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixScalarMultiply>> birch::operator*(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z) {
  #line 106 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("*", "src/expression/MatrixScalarMultiply.birch", 106);
  #line 107 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(107);
  #line 107 "src/expression/MatrixScalarMultiply.birch"
  return z * y;
}

#line 113 "src/expression/MatrixScalarMultiply.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixScalarMultiply>> birch::operator*(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const birch::type::Real& z) {
  #line 113 "src/expression/MatrixScalarMultiply.birch"
  libbirch_function_("*", "src/expression/MatrixScalarMultiply.birch", 113);
  #line 114 "src/expression/MatrixScalarMultiply.birch"
  libbirch_line_(114);
  #line 114 "src/expression/MatrixScalarMultiply.birch"
  return z * y;
}

#line 33 "src/expression/MatrixSolve.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixSolve<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::DefaultArray<birch::type::Real,2>>>> birch::solve(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/expression/MatrixSolve.birch"
  libbirch_function_("solve", "src/expression/MatrixSolve.birch", 33);
  #line 35 "src/expression/MatrixSolve.birch"
  libbirch_line_(35);
  #line 35 "src/expression/MatrixSolve.birch"
  libbirch_assert_(y.get()->columns(handler_) == z.get()->rows(handler_));
  #line 36 "src/expression/MatrixSolve.birch"
  libbirch_line_(36);
  #line 36 "src/expression/MatrixSolve.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixSolve<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::DefaultArray<birch::type::Real,2>>>>>(y, z, handler_);
}

#line 42 "src/expression/MatrixSolve.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixSolve<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::DefaultArray<birch::type::Real,2>>>> birch::solve(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/expression/MatrixSolve.birch"
  libbirch_function_("solve", "src/expression/MatrixSolve.birch", 42);
  #line 44 "src/expression/MatrixSolve.birch"
  libbirch_line_(44);
  #line 44 "src/expression/MatrixSolve.birch"
  return birch::solve(birch::box(y, handler_), z, handler_);
}

#line 50 "src/expression/MatrixSolve.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixSolve<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::DefaultArray<birch::type::Real,2>>>> birch::solve(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::DefaultArray<birch::type::Real,2>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "src/expression/MatrixSolve.birch"
  libbirch_function_("solve", "src/expression/MatrixSolve.birch", 50);
  #line 52 "src/expression/MatrixSolve.birch"
  libbirch_line_(52);
  #line 52 "src/expression/MatrixSolve.birch"
  return birch::solve(y, birch::box(z, handler_), handler_);
}

#line 58 "src/expression/MatrixSolve.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixSolve<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, birch::type::LLT>>> birch::solve(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "src/expression/MatrixSolve.birch"
  libbirch_function_("solve", "src/expression/MatrixSolve.birch", 58);
  #line 60 "src/expression/MatrixSolve.birch"
  libbirch_line_(60);
  #line 60 "src/expression/MatrixSolve.birch"
  libbirch_assert_(y.get()->columns(handler_) == z.get()->rows(handler_));
  #line 61 "src/expression/MatrixSolve.birch"
  libbirch_line_(61);
  #line 61 "src/expression/MatrixSolve.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixSolve<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, birch::type::LLT>>>>(y, z, handler_);
}

#line 67 "src/expression/MatrixSolve.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixSolve<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, birch::type::LLT>>> birch::solve(const birch::type::LLT& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 67 "src/expression/MatrixSolve.birch"
  libbirch_function_("solve", "src/expression/MatrixSolve.birch", 67);
  #line 69 "src/expression/MatrixSolve.birch"
  libbirch_line_(69);
  #line 69 "src/expression/MatrixSolve.birch"
  return birch::solve(birch::box(y, handler_), z, handler_);
}

#line 75 "src/expression/MatrixSolve.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixSolve<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, birch::type::LLT>>> birch::solve(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& y, const libbirch::DefaultArray<birch::type::Real,2>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 75 "src/expression/MatrixSolve.birch"
  libbirch_function_("solve", "src/expression/MatrixSolve.birch", 75);
  #line 77 "src/expression/MatrixSolve.birch"
  libbirch_line_(77);
  #line 77 "src/expression/MatrixSolve.birch"
  return birch::solve(y, birch::box(z, handler_), handler_);
}

#line 4 "src/expression/MatrixStack.birch"
birch::type::MatrixStack::MatrixStack(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/MatrixStack.birch"
    super_type_(y, z) {
  //
}

#line 7 "src/expression/MatrixStack.birch"
birch::type::Integer birch::type::MatrixStack::doRows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/MatrixStack.birch"
  libbirch_function_("doRows", "src/expression/MatrixStack.birch", 7);
  #line 8 "src/expression/MatrixStack.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MatrixStack.birch"
  return this_()->y.get()->rows(handler_) + this_()->z.get()->rows(handler_);
}

#line 11 "src/expression/MatrixStack.birch"
birch::type::Integer birch::type::MatrixStack::doColumns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/MatrixStack.birch"
  libbirch_function_("doColumns", "src/expression/MatrixStack.birch", 11);
  #line 12 "src/expression/MatrixStack.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MatrixStack.birch"
  libbirch_assert_(this_()->y.get()->columns(handler_) == this_()->z.get()->columns(handler_));
  #line 13 "src/expression/MatrixStack.birch"
  libbirch_line_(13);
  #line 13 "src/expression/MatrixStack.birch"
  return this_()->y.get()->columns(handler_);
}

#line 16 "src/expression/MatrixStack.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixStack::doEvaluate(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/expression/MatrixStack.birch"
  libbirch_function_("doEvaluate", "src/expression/MatrixStack.birch", 16);
  #line 17 "src/expression/MatrixStack.birch"
  libbirch_line_(17);
  #line 17 "src/expression/MatrixStack.birch"
  return birch::stack(y, z, handler_);
}

#line 20 "src/expression/MatrixStack.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixStack::doEvaluateGradLeft(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/expression/MatrixStack.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/MatrixStack.birch", 20);
  #line 22 "src/expression/MatrixStack.birch"
  libbirch_line_(22);
  #line 22 "src/expression/MatrixStack.birch"
  return d.get(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, birch::rows(y, handler_) - 1), libbirch::make_range(birch::type::Integer(1) - 1, birch::columns(y, handler_) - 1)));
}

#line 25 "src/expression/MatrixStack.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixStack::doEvaluateGradRight(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/expression/MatrixStack.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/MatrixStack.birch", 25);
  #line 27 "src/expression/MatrixStack.birch"
  libbirch_line_(27);
  #line 27 "src/expression/MatrixStack.birch"
  return d.get(libbirch::make_slice(libbirch::make_range((birch::rows(y, handler_) + birch::type::Integer(1)) - 1, birch::rows(x, handler_) - 1), libbirch::make_range(birch::type::Integer(1) - 1, birch::columns(z, handler_) - 1)));
}

#line 34 "src/expression/MatrixStack.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixStack>> birch::stack(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/expression/MatrixStack.birch"
  libbirch_function_("stack", "src/expression/MatrixStack.birch", 34);
  #line 36 "src/expression/MatrixStack.birch"
  libbirch_line_(36);
  #line 36 "src/expression/MatrixStack.birch"
  libbirch_assert_(y.get()->columns(handler_) == z.get()->columns(handler_));
  #line 37 "src/expression/MatrixStack.birch"
  libbirch_line_(37);
  #line 37 "src/expression/MatrixStack.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixStack>>>(y, z, handler_);
}

#line 43 "src/expression/MatrixStack.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixStack>> birch::stack(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "src/expression/MatrixStack.birch"
  libbirch_function_("stack", "src/expression/MatrixStack.birch", 43);
  #line 44 "src/expression/MatrixStack.birch"
  libbirch_line_(44);
  #line 44 "src/expression/MatrixStack.birch"
  return birch::stack(birch::box(y, handler_), z, handler_);
}

#line 50 "src/expression/MatrixStack.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixStack>> birch::stack(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::DefaultArray<birch::type::Real,2>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "src/expression/MatrixStack.birch"
  libbirch_function_("stack", "src/expression/MatrixStack.birch", 50);
  #line 51 "src/expression/MatrixStack.birch"
  libbirch_line_(51);
  #line 51 "src/expression/MatrixStack.birch"
  return birch::stack(y, birch::box(z, handler_), handler_);
}

#line 4 "src/expression/MatrixSubtract.birch"
birch::type::MatrixSubtract::MatrixSubtract(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/MatrixSubtract.birch"
    super_type_(y, z) {
  //
}

#line 8 "src/expression/MatrixSubtract.birch"
birch::type::Integer birch::type::MatrixSubtract::doRows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 8 "src/expression/MatrixSubtract.birch"
  libbirch_function_("doRows", "src/expression/MatrixSubtract.birch", 8);
  #line 9 "src/expression/MatrixSubtract.birch"
  libbirch_line_(9);
  #line 9 "src/expression/MatrixSubtract.birch"
  return this_()->y.get()->rows(handler_);
}

#line 12 "src/expression/MatrixSubtract.birch"
birch::type::Integer birch::type::MatrixSubtract::doColumns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 12 "src/expression/MatrixSubtract.birch"
  libbirch_function_("doColumns", "src/expression/MatrixSubtract.birch", 12);
  #line 13 "src/expression/MatrixSubtract.birch"
  libbirch_line_(13);
  #line 13 "src/expression/MatrixSubtract.birch"
  return this_()->y.get()->columns(handler_);
}

#line 16 "src/expression/MatrixSubtract.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixSubtract::doEvaluate(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/expression/MatrixSubtract.birch"
  libbirch_function_("doEvaluate", "src/expression/MatrixSubtract.birch", 16);
  #line 17 "src/expression/MatrixSubtract.birch"
  libbirch_line_(17);
  #line 17 "src/expression/MatrixSubtract.birch"
  return y - z;
}

#line 20 "src/expression/MatrixSubtract.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixSubtract::doEvaluateGradLeft(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/expression/MatrixSubtract.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/MatrixSubtract.birch", 20);
  #line 22 "src/expression/MatrixSubtract.birch"
  libbirch_line_(22);
  #line 22 "src/expression/MatrixSubtract.birch"
  return d;
}

#line 25 "src/expression/MatrixSubtract.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixSubtract::doEvaluateGradRight(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,2>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/expression/MatrixSubtract.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/MatrixSubtract.birch", 25);
  #line 27 "src/expression/MatrixSubtract.birch"
  libbirch_line_(27);
  #line 27 "src/expression/MatrixSubtract.birch"
  return -d;
}

#line 30 "src/expression/MatrixSubtract.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>>>>> birch::type::MatrixSubtract::graftLinearMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/expression/MatrixSubtract.birch"
  libbirch_function_("graftLinearMatrixGaussian", "src/expression/MatrixSubtract.birch", 30);
  #line 32 "src/expression/MatrixSubtract.birch"
  libbirch_line_(32);
  #line 32 "src/expression/MatrixSubtract.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>>>>> r;
  #line 33 "src/expression/MatrixSubtract.birch"
  libbirch_line_(33);
  #line 33 "src/expression/MatrixSubtract.birch"
  if (!this_()->hasValue(handler_)) {
    #line 34 "src/expression/MatrixSubtract.birch"
    libbirch_line_(34);
    #line 34 "src/expression/MatrixSubtract.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>> x1;
    #line 36 "src/expression/MatrixSubtract.birch"
    libbirch_line_(36);
    #line 36 "src/expression/MatrixSubtract.birch"
    if ((r = this_()->y.get()->graftLinearMatrixGaussian(handler_)).query()) {
      #line 37 "src/expression/MatrixSubtract.birch"
      libbirch_line_(37);
      #line 37 "src/expression/MatrixSubtract.birch"
      r.get()->subtract(this_()->z.get(), handler_);
    } else {
      #line 38 "src/expression/MatrixSubtract.birch"
      libbirch_line_(38);
      #line 38 "src/expression/MatrixSubtract.birch"
      if ((r = this_()->z.get()->graftLinearMatrixGaussian(handler_)).query()) {
        #line 39 "src/expression/MatrixSubtract.birch"
        libbirch_line_(39);
        #line 39 "src/expression/MatrixSubtract.birch"
        r.get()->negateAndAdd(this_()->y.get(), handler_);
      } else {
        #line 40 "src/expression/MatrixSubtract.birch"
        libbirch_line_(40);
        #line 40 "src/expression/MatrixSubtract.birch"
        if ((x1 = this_()->y.get()->graftMatrixGaussian(handler_)).query()) {
          #line 41 "src/expression/MatrixSubtract.birch"
          libbirch_line_(41);
          #line 41 "src/expression/MatrixSubtract.birch"
          r = birch::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>>(birch::box(birch::identity(x1.get()->rows(handler_), handler_), handler_), x1.get(), -this_()->z.get(), handler_);
        } else {
          #line 42 "src/expression/MatrixSubtract.birch"
          libbirch_line_(42);
          #line 42 "src/expression/MatrixSubtract.birch"
          if ((x1 = this_()->z.get()->graftMatrixGaussian(handler_)).query()) {
            #line 43 "src/expression/MatrixSubtract.birch"
            libbirch_line_(43);
            #line 43 "src/expression/MatrixSubtract.birch"
            r = birch::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>>(birch::box(birch::diagonal(-1.0, x1.get()->rows(handler_), handler_), handler_), x1.get(), this_()->y.get(), handler_);
          }
        }
      }
    }
  }
  #line 46 "src/expression/MatrixSubtract.birch"
  libbirch_line_(46);
  #line 46 "src/expression/MatrixSubtract.birch"
  return r;
}

#line 49 "src/expression/MatrixSubtract.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>>>>> birch::type::MatrixSubtract::graftLinearMatrixNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/expression/MatrixSubtract.birch"
  libbirch_function_("graftLinearMatrixNormalInverseGamma", "src/expression/MatrixSubtract.birch", 49);
  #line 51 "src/expression/MatrixSubtract.birch"
  libbirch_line_(51);
  #line 51 "src/expression/MatrixSubtract.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>>>>> r;
  #line 52 "src/expression/MatrixSubtract.birch"
  libbirch_line_(52);
  #line 52 "src/expression/MatrixSubtract.birch"
  if (!this_()->hasValue(handler_)) {
    #line 53 "src/expression/MatrixSubtract.birch"
    libbirch_line_(53);
    #line 53 "src/expression/MatrixSubtract.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>> x1;
    #line 55 "src/expression/MatrixSubtract.birch"
    libbirch_line_(55);
    #line 55 "src/expression/MatrixSubtract.birch"
    if ((r = this_()->y.get()->graftLinearMatrixNormalInverseGamma(compare, handler_)).query()) {
      #line 56 "src/expression/MatrixSubtract.birch"
      libbirch_line_(56);
      #line 56 "src/expression/MatrixSubtract.birch"
      r.get()->subtract(this_()->z.get(), handler_);
    } else {
      #line 57 "src/expression/MatrixSubtract.birch"
      libbirch_line_(57);
      #line 57 "src/expression/MatrixSubtract.birch"
      if ((r = this_()->z.get()->graftLinearMatrixNormalInverseGamma(compare, handler_)).query()) {
        #line 58 "src/expression/MatrixSubtract.birch"
        libbirch_line_(58);
        #line 58 "src/expression/MatrixSubtract.birch"
        r.get()->negateAndAdd(this_()->y.get(), handler_);
      } else {
        #line 59 "src/expression/MatrixSubtract.birch"
        libbirch_line_(59);
        #line 59 "src/expression/MatrixSubtract.birch"
        if ((x1 = this_()->y.get()->graftMatrixNormalInverseGamma(compare, handler_)).query()) {
          #line 60 "src/expression/MatrixSubtract.birch"
          libbirch_line_(60);
          #line 60 "src/expression/MatrixSubtract.birch"
          r = birch::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>>(birch::box(birch::identity(x1.get()->rows(handler_), handler_), handler_), x1.get(), -this_()->z.get(), handler_);
        } else {
          #line 61 "src/expression/MatrixSubtract.birch"
          libbirch_line_(61);
          #line 61 "src/expression/MatrixSubtract.birch"
          if ((x1 = this_()->z.get()->graftMatrixNormalInverseGamma(compare, handler_)).query()) {
            #line 62 "src/expression/MatrixSubtract.birch"
            libbirch_line_(62);
            #line 62 "src/expression/MatrixSubtract.birch"
            r = birch::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>>(birch::box(birch::diagonal(-1.0, x1.get()->rows(handler_), handler_), handler_), x1.get(), this_()->y.get(), handler_);
          }
        }
      }
    }
  }
  #line 65 "src/expression/MatrixSubtract.birch"
  libbirch_line_(65);
  #line 65 "src/expression/MatrixSubtract.birch"
  return r;
}

#line 68 "src/expression/MatrixSubtract.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>>>> birch::type::MatrixSubtract::graftLinearMatrixNormalInverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::LLT>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 68 "src/expression/MatrixSubtract.birch"
  libbirch_function_("graftLinearMatrixNormalInverseWishart", "src/expression/MatrixSubtract.birch", 68);
  #line 70 "src/expression/MatrixSubtract.birch"
  libbirch_line_(70);
  #line 70 "src/expression/MatrixSubtract.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>>>> r;
  #line 71 "src/expression/MatrixSubtract.birch"
  libbirch_line_(71);
  #line 71 "src/expression/MatrixSubtract.birch"
  if (!this_()->hasValue(handler_)) {
    #line 72 "src/expression/MatrixSubtract.birch"
    libbirch_line_(72);
    #line 72 "src/expression/MatrixSubtract.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>> x1;
    #line 74 "src/expression/MatrixSubtract.birch"
    libbirch_line_(74);
    #line 74 "src/expression/MatrixSubtract.birch"
    if ((r = this_()->y.get()->graftLinearMatrixNormalInverseWishart(compare, handler_)).query()) {
      #line 75 "src/expression/MatrixSubtract.birch"
      libbirch_line_(75);
      #line 75 "src/expression/MatrixSubtract.birch"
      r.get()->subtract(this_()->z.get(), handler_);
    } else {
      #line 76 "src/expression/MatrixSubtract.birch"
      libbirch_line_(76);
      #line 76 "src/expression/MatrixSubtract.birch"
      if ((r = this_()->z.get()->graftLinearMatrixNormalInverseWishart(compare, handler_)).query()) {
        #line 77 "src/expression/MatrixSubtract.birch"
        libbirch_line_(77);
        #line 77 "src/expression/MatrixSubtract.birch"
        r.get()->negateAndAdd(this_()->y.get(), handler_);
      } else {
        #line 78 "src/expression/MatrixSubtract.birch"
        libbirch_line_(78);
        #line 78 "src/expression/MatrixSubtract.birch"
        if ((x1 = this_()->y.get()->graftMatrixNormalInverseWishart(compare, handler_)).query()) {
          #line 79 "src/expression/MatrixSubtract.birch"
          libbirch_line_(79);
          #line 79 "src/expression/MatrixSubtract.birch"
          r = birch::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>(birch::box(birch::identity(x1.get()->rows(handler_), handler_), handler_), x1.get(), -this_()->z.get(), handler_);
        } else {
          #line 80 "src/expression/MatrixSubtract.birch"
          libbirch_line_(80);
          #line 80 "src/expression/MatrixSubtract.birch"
          if ((x1 = this_()->z.get()->graftMatrixNormalInverseWishart(compare, handler_)).query()) {
            #line 81 "src/expression/MatrixSubtract.birch"
            libbirch_line_(81);
            #line 81 "src/expression/MatrixSubtract.birch"
            r = birch::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>(birch::box(birch::diagonal(-1.0, x1.get()->rows(handler_), handler_), handler_), x1.get(), this_()->y.get(), handler_);
          }
        }
      }
    }
  }
  #line 84 "src/expression/MatrixSubtract.birch"
  libbirch_line_(84);
  #line 84 "src/expression/MatrixSubtract.birch"
  return r;
}

#line 91 "src/expression/MatrixSubtract.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixSubtract>> birch::operator-(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z) {
  #line 91 "src/expression/MatrixSubtract.birch"
  libbirch_function_("-", "src/expression/MatrixSubtract.birch", 91);
  #line 93 "src/expression/MatrixSubtract.birch"
  libbirch_line_(93);
  #line 93 "src/expression/MatrixSubtract.birch"
  libbirch_assert_(y->rows() == z->rows());
  #line 94 "src/expression/MatrixSubtract.birch"
  libbirch_line_(94);
  #line 94 "src/expression/MatrixSubtract.birch"
  libbirch_assert_(y->columns() == z->columns());
  #line 95 "src/expression/MatrixSubtract.birch"
  libbirch_line_(95);
  #line 95 "src/expression/MatrixSubtract.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixSubtract>>>(y, z);
}

#line 101 "src/expression/MatrixSubtract.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixSubtract>> birch::operator-(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& z) {
  #line 101 "src/expression/MatrixSubtract.birch"
  libbirch_function_("-", "src/expression/MatrixSubtract.birch", 101);
  #line 102 "src/expression/MatrixSubtract.birch"
  libbirch_line_(102);
  #line 102 "src/expression/MatrixSubtract.birch"
  return birch::box(y) - z;
}

#line 108 "src/expression/MatrixSubtract.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixSubtract>> birch::operator-(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::DefaultArray<birch::type::Real,2>& z) {
  #line 108 "src/expression/MatrixSubtract.birch"
  libbirch_function_("-", "src/expression/MatrixSubtract.birch", 108);
  #line 109 "src/expression/MatrixSubtract.birch"
  libbirch_line_(109);
  #line 109 "src/expression/MatrixSubtract.birch"
  return y - birch::box(z);
}

#line 4 "src/expression/MatrixTranspose.birch"
birch::type::MatrixTranspose::MatrixTranspose(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/MatrixTranspose.birch"
    super_type_(x) {
  //
}

#line 7 "src/expression/MatrixTranspose.birch"
birch::type::Integer birch::type::MatrixTranspose::doRows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/MatrixTranspose.birch"
  libbirch_function_("doRows", "src/expression/MatrixTranspose.birch", 7);
  #line 8 "src/expression/MatrixTranspose.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MatrixTranspose.birch"
  return this_()->y.get()->columns(handler_);
}

#line 11 "src/expression/MatrixTranspose.birch"
birch::type::Integer birch::type::MatrixTranspose::doColumns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/MatrixTranspose.birch"
  libbirch_function_("doColumns", "src/expression/MatrixTranspose.birch", 11);
  #line 12 "src/expression/MatrixTranspose.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MatrixTranspose.birch"
  return this_()->y.get()->rows(handler_);
}

#line 15 "src/expression/MatrixTranspose.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixTranspose::doEvaluate(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/expression/MatrixTranspose.birch"
  libbirch_function_("doEvaluate", "src/expression/MatrixTranspose.birch", 15);
  #line 16 "src/expression/MatrixTranspose.birch"
  libbirch_line_(16);
  #line 16 "src/expression/MatrixTranspose.birch"
  return birch::transpose(y, handler_);
}

#line 19 "src/expression/MatrixTranspose.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixTranspose::doEvaluateGrad(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/expression/MatrixTranspose.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/MatrixTranspose.birch", 19);
  #line 21 "src/expression/MatrixTranspose.birch"
  libbirch_line_(21);
  #line 21 "src/expression/MatrixTranspose.birch"
  return birch::transpose(d, handler_);
}

#line 28 "src/expression/MatrixTranspose.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixTranspose>> birch::transpose(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/expression/MatrixTranspose.birch"
  libbirch_function_("transpose", "src/expression/MatrixTranspose.birch", 28);
  #line 29 "src/expression/MatrixTranspose.birch"
  libbirch_line_(29);
  #line 29 "src/expression/MatrixTranspose.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixTranspose>>>(y, handler_);
}

#line 35 "src/expression/MatrixTranspose.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>> birch::transpose(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "src/expression/MatrixTranspose.birch"
  libbirch_function_("transpose", "src/expression/MatrixTranspose.birch", 35);
  #line 36 "src/expression/MatrixTranspose.birch"
  libbirch_line_(36);
  #line 36 "src/expression/MatrixTranspose.birch"
  return y;
}

#line 4 "src/expression/Multiply.birch"
birch::type::Multiply::Multiply(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/Multiply.birch"
    super_type_(y, z) {
  //
}

#line 7 "src/expression/Multiply.birch"
birch::type::Real birch::type::Multiply::doEvaluate(const birch::type::Real& y, const birch::type::Real& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/Multiply.birch"
  libbirch_function_("doEvaluate", "src/expression/Multiply.birch", 7);
  #line 8 "src/expression/Multiply.birch"
  libbirch_line_(8);
  #line 8 "src/expression/Multiply.birch"
  return y * z;
}

#line 11 "src/expression/Multiply.birch"
birch::type::Real birch::type::Multiply::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/Multiply.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/Multiply.birch", 11);
  #line 12 "src/expression/Multiply.birch"
  libbirch_line_(12);
  #line 12 "src/expression/Multiply.birch"
  return d * z;
}

#line 15 "src/expression/Multiply.birch"
birch::type::Real birch::type::Multiply::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/expression/Multiply.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/Multiply.birch", 15);
  #line 16 "src/expression/Multiply.birch"
  libbirch_line_(16);
  #line 16 "src/expression/Multiply.birch"
  return d * y;
}

#line 19 "src/expression/Multiply.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>>>>> birch::type::Multiply::graftScaledGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/expression/Multiply.birch"
  libbirch_function_("graftScaledGamma", "src/expression/Multiply.birch", 19);
  #line 20 "src/expression/Multiply.birch"
  libbirch_line_(20);
  #line 20 "src/expression/Multiply.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>>>>> r;
  #line 21 "src/expression/Multiply.birch"
  libbirch_line_(21);
  #line 21 "src/expression/Multiply.birch"
  if (!this_()->hasValue(handler_)) {
    #line 22 "src/expression/Multiply.birch"
    libbirch_line_(22);
    #line 22 "src/expression/Multiply.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>> x1;
    #line 24 "src/expression/Multiply.birch"
    libbirch_line_(24);
    #line 24 "src/expression/Multiply.birch"
    if ((r = this_()->y.get()->graftScaledGamma(handler_)).query()) {
      #line 25 "src/expression/Multiply.birch"
      libbirch_line_(25);
      #line 25 "src/expression/Multiply.birch"
      r.get()->multiply(this_()->z.get(), handler_);
    } else {
      #line 26 "src/expression/Multiply.birch"
      libbirch_line_(26);
      #line 26 "src/expression/Multiply.birch"
      if ((r = this_()->z.get()->graftScaledGamma(handler_)).query()) {
        #line 27 "src/expression/Multiply.birch"
        libbirch_line_(27);
        #line 27 "src/expression/Multiply.birch"
        r.get()->multiply(this_()->y.get(), handler_);
      } else {
        #line 28 "src/expression/Multiply.birch"
        libbirch_line_(28);
        #line 28 "src/expression/Multiply.birch"
        if ((x1 = this_()->y.get()->graftGamma(handler_)).query()) {
          #line 29 "src/expression/Multiply.birch"
          libbirch_line_(29);
          #line 29 "src/expression/Multiply.birch"
          r = birch::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>>(this_()->z.get(), x1.get(), handler_);
        } else {
          #line 30 "src/expression/Multiply.birch"
          libbirch_line_(30);
          #line 30 "src/expression/Multiply.birch"
          if ((x1 = this_()->z.get()->graftGamma(handler_)).query()) {
            #line 31 "src/expression/Multiply.birch"
            libbirch_line_(31);
            #line 31 "src/expression/Multiply.birch"
            r = birch::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>>(this_()->y.get(), x1.get(), handler_);
          }
        }
      }
    }
  }
  #line 34 "src/expression/Multiply.birch"
  libbirch_line_(34);
  #line 34 "src/expression/Multiply.birch"
  return r;
}

#line 37 "src/expression/Multiply.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>>>>> birch::type::Multiply::graftLinearGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/expression/Multiply.birch"
  libbirch_function_("graftLinearGaussian", "src/expression/Multiply.birch", 37);
  #line 38 "src/expression/Multiply.birch"
  libbirch_line_(38);
  #line 38 "src/expression/Multiply.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>>>>> r;
  #line 39 "src/expression/Multiply.birch"
  libbirch_line_(39);
  #line 39 "src/expression/Multiply.birch"
  if (!this_()->hasValue(handler_)) {
    #line 40 "src/expression/Multiply.birch"
    libbirch_line_(40);
    #line 40 "src/expression/Multiply.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>> x1;
    #line 42 "src/expression/Multiply.birch"
    libbirch_line_(42);
    #line 42 "src/expression/Multiply.birch"
    if ((r = this_()->y.get()->graftLinearGaussian(handler_)).query()) {
      #line 43 "src/expression/Multiply.birch"
      libbirch_line_(43);
      #line 43 "src/expression/Multiply.birch"
      r.get()->multiply(this_()->z.get(), handler_);
    } else {
      #line 44 "src/expression/Multiply.birch"
      libbirch_line_(44);
      #line 44 "src/expression/Multiply.birch"
      if ((r = this_()->z.get()->graftLinearGaussian(handler_)).query()) {
        #line 45 "src/expression/Multiply.birch"
        libbirch_line_(45);
        #line 45 "src/expression/Multiply.birch"
        r.get()->multiply(this_()->y.get(), handler_);
      } else {
        #line 46 "src/expression/Multiply.birch"
        libbirch_line_(46);
        #line 46 "src/expression/Multiply.birch"
        if ((x1 = this_()->y.get()->graftGaussian(handler_)).query()) {
          #line 47 "src/expression/Multiply.birch"
          libbirch_line_(47);
          #line 47 "src/expression/Multiply.birch"
          r = birch::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>>(this_()->z.get(), x1.get(), handler_);
        } else {
          #line 48 "src/expression/Multiply.birch"
          libbirch_line_(48);
          #line 48 "src/expression/Multiply.birch"
          if ((x1 = this_()->z.get()->graftGaussian(handler_)).query()) {
            #line 49 "src/expression/Multiply.birch"
            libbirch_line_(49);
            #line 49 "src/expression/Multiply.birch"
            r = birch::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>>(this_()->y.get(), x1.get(), handler_);
          }
        }
      }
    }
  }
  #line 52 "src/expression/Multiply.birch"
  libbirch_line_(52);
  #line 52 "src/expression/Multiply.birch"
  return r;
}

#line 55 "src/expression/Multiply.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> birch::type::Multiply::graftDotGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 55 "src/expression/Multiply.birch"
  libbirch_function_("graftDotGaussian", "src/expression/Multiply.birch", 55);
  #line 56 "src/expression/Multiply.birch"
  libbirch_line_(56);
  #line 56 "src/expression/Multiply.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> r;
  #line 57 "src/expression/Multiply.birch"
  libbirch_line_(57);
  #line 57 "src/expression/Multiply.birch"
  if (!this_()->hasValue(handler_)) {
    #line 58 "src/expression/Multiply.birch"
    libbirch_line_(58);
    #line 58 "src/expression/Multiply.birch"
    if ((r = this_()->y.get()->graftDotGaussian(handler_)).query()) {
      #line 59 "src/expression/Multiply.birch"
      libbirch_line_(59);
      #line 59 "src/expression/Multiply.birch"
      r.get()->multiply(this_()->z.get(), handler_);
    } else {
      #line 60 "src/expression/Multiply.birch"
      libbirch_line_(60);
      #line 60 "src/expression/Multiply.birch"
      if ((r = this_()->z.get()->graftDotGaussian(handler_)).query()) {
        #line 61 "src/expression/Multiply.birch"
        libbirch_line_(61);
        #line 61 "src/expression/Multiply.birch"
        r.get()->multiply(this_()->y.get(), handler_);
      }
    }
  }
  #line 64 "src/expression/Multiply.birch"
  libbirch_line_(64);
  #line 64 "src/expression/Multiply.birch"
  return r;
}

#line 67 "src/expression/Multiply.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>>>>> birch::type::Multiply::graftLinearNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 67 "src/expression/Multiply.birch"
  libbirch_function_("graftLinearNormalInverseGamma", "src/expression/Multiply.birch", 67);
  #line 69 "src/expression/Multiply.birch"
  libbirch_line_(69);
  #line 69 "src/expression/Multiply.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>>>>> r;
  #line 70 "src/expression/Multiply.birch"
  libbirch_line_(70);
  #line 70 "src/expression/Multiply.birch"
  if (!this_()->hasValue(handler_)) {
    #line 71 "src/expression/Multiply.birch"
    libbirch_line_(71);
    #line 71 "src/expression/Multiply.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>> x1;
    #line 73 "src/expression/Multiply.birch"
    libbirch_line_(73);
    #line 73 "src/expression/Multiply.birch"
    if ((r = this_()->y.get()->graftLinearNormalInverseGamma(compare, handler_)).query()) {
      #line 74 "src/expression/Multiply.birch"
      libbirch_line_(74);
      #line 74 "src/expression/Multiply.birch"
      r.get()->multiply(this_()->z.get(), handler_);
    } else {
      #line 75 "src/expression/Multiply.birch"
      libbirch_line_(75);
      #line 75 "src/expression/Multiply.birch"
      if ((r = this_()->z.get()->graftLinearNormalInverseGamma(compare, handler_)).query()) {
        #line 76 "src/expression/Multiply.birch"
        libbirch_line_(76);
        #line 76 "src/expression/Multiply.birch"
        r.get()->multiply(this_()->y.get(), handler_);
      } else {
        #line 77 "src/expression/Multiply.birch"
        libbirch_line_(77);
        #line 77 "src/expression/Multiply.birch"
        if ((x1 = this_()->y.get()->graftNormalInverseGamma(compare, handler_)).query()) {
          #line 78 "src/expression/Multiply.birch"
          libbirch_line_(78);
          #line 78 "src/expression/Multiply.birch"
          r = birch::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>>(this_()->z.get(), x1.get(), handler_);
        } else {
          #line 79 "src/expression/Multiply.birch"
          libbirch_line_(79);
          #line 79 "src/expression/Multiply.birch"
          if ((x1 = this_()->z.get()->graftNormalInverseGamma(compare, handler_)).query()) {
            #line 80 "src/expression/Multiply.birch"
            libbirch_line_(80);
            #line 80 "src/expression/Multiply.birch"
            r = birch::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>>(this_()->y.get(), x1.get(), handler_);
          }
        }
      }
    }
  }
  #line 83 "src/expression/Multiply.birch"
  libbirch_line_(83);
  #line 83 "src/expression/Multiply.birch"
  return r;
}

#line 86 "src/expression/Multiply.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> birch::type::Multiply::graftDotNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 86 "src/expression/Multiply.birch"
  libbirch_function_("graftDotNormalInverseGamma", "src/expression/Multiply.birch", 86);
  #line 88 "src/expression/Multiply.birch"
  libbirch_line_(88);
  #line 88 "src/expression/Multiply.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> r;
  #line 89 "src/expression/Multiply.birch"
  libbirch_line_(89);
  #line 89 "src/expression/Multiply.birch"
  if (!this_()->hasValue(handler_)) {
    #line 90 "src/expression/Multiply.birch"
    libbirch_line_(90);
    #line 90 "src/expression/Multiply.birch"
    if ((r = this_()->y.get()->graftDotNormalInverseGamma(compare, handler_)).query()) {
      #line 91 "src/expression/Multiply.birch"
      libbirch_line_(91);
      #line 91 "src/expression/Multiply.birch"
      r.get()->multiply(this_()->z.get(), handler_);
    } else {
      #line 92 "src/expression/Multiply.birch"
      libbirch_line_(92);
      #line 92 "src/expression/Multiply.birch"
      if ((r = this_()->z.get()->graftDotNormalInverseGamma(compare, handler_)).query()) {
        #line 93 "src/expression/Multiply.birch"
        libbirch_line_(93);
        #line 93 "src/expression/Multiply.birch"
        r.get()->multiply(this_()->y.get(), handler_);
      }
    }
  }
  #line 96 "src/expression/Multiply.birch"
  libbirch_line_(96);
  #line 96 "src/expression/Multiply.birch"
  return r;
}

#line 103 "src/expression/Multiply.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Multiply>> birch::operator*(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z) {
  #line 103 "src/expression/Multiply.birch"
  libbirch_function_("*", "src/expression/Multiply.birch", 103);
  #line 104 "src/expression/Multiply.birch"
  libbirch_line_(104);
  #line 104 "src/expression/Multiply.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Multiply>>>(y, z);
}

#line 110 "src/expression/Multiply.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Multiply>> birch::operator*(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z) {
  #line 110 "src/expression/Multiply.birch"
  libbirch_function_("*", "src/expression/Multiply.birch", 110);
  #line 111 "src/expression/Multiply.birch"
  libbirch_line_(111);
  #line 111 "src/expression/Multiply.birch"
  return birch::box(y) * z;
}

#line 117 "src/expression/Multiply.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Multiply>> birch::operator*(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const birch::type::Real& z) {
  #line 117 "src/expression/Multiply.birch"
  libbirch_function_("*", "src/expression/Multiply.birch", 117);
  #line 118 "src/expression/Multiply.birch"
  libbirch_line_(118);
  #line 118 "src/expression/Multiply.birch"
  return y * birch::box(z);
}

#line 4 "src/expression/MultivariateAdd.birch"
birch::type::MultivariateAdd::MultivariateAdd(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/MultivariateAdd.birch"
    super_type_(y, z) {
  //
}

#line 7 "src/expression/MultivariateAdd.birch"
birch::type::Integer birch::type::MultivariateAdd::doRows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/MultivariateAdd.birch"
  libbirch_function_("doRows", "src/expression/MultivariateAdd.birch", 7);
  #line 8 "src/expression/MultivariateAdd.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MultivariateAdd.birch"
  return this_()->y.get()->rows(handler_);
}

#line 11 "src/expression/MultivariateAdd.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateAdd::doEvaluate(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/MultivariateAdd.birch"
  libbirch_function_("doEvaluate", "src/expression/MultivariateAdd.birch", 11);
  #line 12 "src/expression/MultivariateAdd.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MultivariateAdd.birch"
  return y + z;
}

#line 15 "src/expression/MultivariateAdd.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateAdd::doEvaluateGradLeft(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/expression/MultivariateAdd.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/MultivariateAdd.birch", 15);
  #line 17 "src/expression/MultivariateAdd.birch"
  libbirch_line_(17);
  #line 17 "src/expression/MultivariateAdd.birch"
  return d;
}

#line 20 "src/expression/MultivariateAdd.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateAdd::doEvaluateGradRight(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/expression/MultivariateAdd.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/MultivariateAdd.birch", 20);
  #line 22 "src/expression/MultivariateAdd.birch"
  libbirch_line_(22);
  #line 22 "src/expression/MultivariateAdd.birch"
  return d;
}

#line 25 "src/expression/MultivariateAdd.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> birch::type::MultivariateAdd::graftLinearMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/expression/MultivariateAdd.birch"
  libbirch_function_("graftLinearMultivariateGaussian", "src/expression/MultivariateAdd.birch", 25);
  #line 27 "src/expression/MultivariateAdd.birch"
  libbirch_line_(27);
  #line 27 "src/expression/MultivariateAdd.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> r;
  #line 28 "src/expression/MultivariateAdd.birch"
  libbirch_line_(28);
  #line 28 "src/expression/MultivariateAdd.birch"
  if (!this_()->hasValue(handler_)) {
    #line 29 "src/expression/MultivariateAdd.birch"
    libbirch_line_(29);
    #line 29 "src/expression/MultivariateAdd.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>> x1;
    #line 31 "src/expression/MultivariateAdd.birch"
    libbirch_line_(31);
    #line 31 "src/expression/MultivariateAdd.birch"
    if ((r = this_()->y.get()->graftLinearMultivariateGaussian(handler_)).query()) {
      #line 32 "src/expression/MultivariateAdd.birch"
      libbirch_line_(32);
      #line 32 "src/expression/MultivariateAdd.birch"
      r.get()->add(this_()->z.get(), handler_);
    } else {
      #line 33 "src/expression/MultivariateAdd.birch"
      libbirch_line_(33);
      #line 33 "src/expression/MultivariateAdd.birch"
      if ((r = this_()->z.get()->graftLinearMultivariateGaussian(handler_)).query()) {
        #line 34 "src/expression/MultivariateAdd.birch"
        libbirch_line_(34);
        #line 34 "src/expression/MultivariateAdd.birch"
        r.get()->add(this_()->y.get(), handler_);
      } else {
        #line 35 "src/expression/MultivariateAdd.birch"
        libbirch_line_(35);
        #line 35 "src/expression/MultivariateAdd.birch"
        if ((x1 = this_()->y.get()->graftMultivariateGaussian(handler_)).query()) {
          #line 36 "src/expression/MultivariateAdd.birch"
          libbirch_line_(36);
          #line 36 "src/expression/MultivariateAdd.birch"
          r = birch::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>(birch::box(birch::identity(this_()->z.get()->rows(handler_), handler_), handler_), x1.get(), this_()->z.get(), handler_);
        } else {
          #line 38 "src/expression/MultivariateAdd.birch"
          libbirch_line_(38);
          #line 38 "src/expression/MultivariateAdd.birch"
          if ((x1 = this_()->z.get()->graftMultivariateGaussian(handler_)).query()) {
            #line 39 "src/expression/MultivariateAdd.birch"
            libbirch_line_(39);
            #line 39 "src/expression/MultivariateAdd.birch"
            r = birch::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>(birch::box(birch::identity(this_()->z.get()->rows(handler_), handler_), handler_), x1.get(), this_()->y.get(), handler_);
          }
        }
      }
    }
  }
  #line 43 "src/expression/MultivariateAdd.birch"
  libbirch_line_(43);
  #line 43 "src/expression/MultivariateAdd.birch"
  return r;
}

#line 46 "src/expression/MultivariateAdd.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> birch::type::MultivariateAdd::graftLinearMultivariateNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/expression/MultivariateAdd.birch"
  libbirch_function_("graftLinearMultivariateNormalInverseGamma", "src/expression/MultivariateAdd.birch", 46);
  #line 48 "src/expression/MultivariateAdd.birch"
  libbirch_line_(48);
  #line 48 "src/expression/MultivariateAdd.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> r;
  #line 49 "src/expression/MultivariateAdd.birch"
  libbirch_line_(49);
  #line 49 "src/expression/MultivariateAdd.birch"
  if (!this_()->hasValue(handler_)) {
    #line 50 "src/expression/MultivariateAdd.birch"
    libbirch_line_(50);
    #line 50 "src/expression/MultivariateAdd.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>> x1;
    #line 52 "src/expression/MultivariateAdd.birch"
    libbirch_line_(52);
    #line 52 "src/expression/MultivariateAdd.birch"
    if ((r = this_()->y.get()->graftLinearMultivariateNormalInverseGamma(compare, handler_)).query()) {
      #line 53 "src/expression/MultivariateAdd.birch"
      libbirch_line_(53);
      #line 53 "src/expression/MultivariateAdd.birch"
      r.get()->add(this_()->z.get(), handler_);
    } else {
      #line 54 "src/expression/MultivariateAdd.birch"
      libbirch_line_(54);
      #line 54 "src/expression/MultivariateAdd.birch"
      if ((r = this_()->z.get()->graftLinearMultivariateNormalInverseGamma(compare, handler_)).query()) {
        #line 55 "src/expression/MultivariateAdd.birch"
        libbirch_line_(55);
        #line 55 "src/expression/MultivariateAdd.birch"
        r.get()->add(this_()->y.get(), handler_);
      } else {
        #line 56 "src/expression/MultivariateAdd.birch"
        libbirch_line_(56);
        #line 56 "src/expression/MultivariateAdd.birch"
        if ((x1 = this_()->y.get()->graftMultivariateNormalInverseGamma(compare, handler_)).query()) {
          #line 57 "src/expression/MultivariateAdd.birch"
          libbirch_line_(57);
          #line 57 "src/expression/MultivariateAdd.birch"
          r = birch::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>(birch::box(birch::identity(this_()->z.get()->rows(handler_), handler_), handler_), x1.get(), this_()->z.get(), handler_);
        } else {
          #line 59 "src/expression/MultivariateAdd.birch"
          libbirch_line_(59);
          #line 59 "src/expression/MultivariateAdd.birch"
          if ((x1 = this_()->z.get()->graftMultivariateNormalInverseGamma(compare, handler_)).query()) {
            #line 60 "src/expression/MultivariateAdd.birch"
            libbirch_line_(60);
            #line 60 "src/expression/MultivariateAdd.birch"
            r = birch::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>(birch::box(birch::identity(this_()->z.get()->rows(handler_), handler_), handler_), x1.get(), this_()->y.get(), handler_);
          }
        }
      }
    }
  }
  #line 64 "src/expression/MultivariateAdd.birch"
  libbirch_line_(64);
  #line 64 "src/expression/MultivariateAdd.birch"
  return r;
}

#line 71 "src/expression/MultivariateAdd.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateAdd>> birch::operator+(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z) {
  #line 71 "src/expression/MultivariateAdd.birch"
  libbirch_function_("+", "src/expression/MultivariateAdd.birch", 71);
  #line 72 "src/expression/MultivariateAdd.birch"
  libbirch_line_(72);
  #line 72 "src/expression/MultivariateAdd.birch"
  libbirch_assert_(y->rows() == z->rows());
  #line 73 "src/expression/MultivariateAdd.birch"
  libbirch_line_(73);
  #line 73 "src/expression/MultivariateAdd.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateAdd>>>(y, z);
}

#line 79 "src/expression/MultivariateAdd.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateAdd>> birch::operator+(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z) {
  #line 79 "src/expression/MultivariateAdd.birch"
  libbirch_function_("+", "src/expression/MultivariateAdd.birch", 79);
  #line 80 "src/expression/MultivariateAdd.birch"
  libbirch_line_(80);
  #line 80 "src/expression/MultivariateAdd.birch"
  return birch::box(y) + z;
}

#line 86 "src/expression/MultivariateAdd.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateAdd>> birch::operator+(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 86 "src/expression/MultivariateAdd.birch"
  libbirch_function_("+", "src/expression/MultivariateAdd.birch", 86);
  #line 87 "src/expression/MultivariateAdd.birch"
  libbirch_line_(87);
  #line 87 "src/expression/MultivariateAdd.birch"
  return y + birch::box(z);
}

#line 4 "src/expression/MultivariateCanonical.birch"
birch::type::MultivariateCanonical::MultivariateCanonical(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/MultivariateCanonical.birch"
    super_type_(y) {
  //
}

#line 7 "src/expression/MultivariateCanonical.birch"
birch::type::Integer birch::type::MultivariateCanonical::doRows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/MultivariateCanonical.birch"
  libbirch_function_("doRows", "src/expression/MultivariateCanonical.birch", 7);
  #line 8 "src/expression/MultivariateCanonical.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MultivariateCanonical.birch"
  return this_()->y.get()->rows(handler_);
}

#line 11 "src/expression/MultivariateCanonical.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateCanonical::doEvaluate(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/MultivariateCanonical.birch"
  libbirch_function_("doEvaluate", "src/expression/MultivariateCanonical.birch", 11);
  #line 12 "src/expression/MultivariateCanonical.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MultivariateCanonical.birch"
  return y;
}

#line 15 "src/expression/MultivariateCanonical.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateCanonical::doEvaluateGrad(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/expression/MultivariateCanonical.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/MultivariateCanonical.birch", 15);
  #line 17 "src/expression/MultivariateCanonical.birch"
  libbirch_line_(17);
  #line 17 "src/expression/MultivariateCanonical.birch"
  return d;
}

#line 24 "src/expression/MultivariateCanonical.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>> birch::canonical(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/expression/MultivariateCanonical.birch"
  libbirch_function_("canonical", "src/expression/MultivariateCanonical.birch", 24);
  #line 25 "src/expression/MultivariateCanonical.birch"
  libbirch_line_(25);
  #line 25 "src/expression/MultivariateCanonical.birch"
  if (!y->isRandom(handler_)) {
    #line 27 "src/expression/MultivariateCanonical.birch"
    libbirch_line_(27);
    #line 27 "src/expression/MultivariateCanonical.birch"
    return y;
  } else {
    #line 31 "src/expression/MultivariateCanonical.birch"
    libbirch_line_(31);
    #line 31 "src/expression/MultivariateCanonical.birch"
    return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateCanonical>>>(y, handler_);
  }
}

#line 4 "src/expression/MultivariateDiagonal.birch"
birch::type::MultivariateDiagonal::MultivariateDiagonal(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/MultivariateDiagonal.birch"
    super_type_(y) {
  //
}

#line 7 "src/expression/MultivariateDiagonal.birch"
birch::type::Integer birch::type::MultivariateDiagonal::doRows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/MultivariateDiagonal.birch"
  libbirch_function_("doRows", "src/expression/MultivariateDiagonal.birch", 7);
  #line 8 "src/expression/MultivariateDiagonal.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MultivariateDiagonal.birch"
  return birch::min(this_()->y.get()->rows(handler_), this_()->y.get()->columns(handler_), handler_);
}

#line 11 "src/expression/MultivariateDiagonal.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateDiagonal::doEvaluate(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/MultivariateDiagonal.birch"
  libbirch_function_("doEvaluate", "src/expression/MultivariateDiagonal.birch", 11);
  #line 12 "src/expression/MultivariateDiagonal.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MultivariateDiagonal.birch"
  return birch::diagonal(y, handler_);
}

#line 15 "src/expression/MultivariateDiagonal.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MultivariateDiagonal::doEvaluateGrad(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/expression/MultivariateDiagonal.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/MultivariateDiagonal.birch", 15);
  #line 17 "src/expression/MultivariateDiagonal.birch"
  libbirch_line_(17);
  #line 17 "src/expression/MultivariateDiagonal.birch"
  return birch::diagonal(d, handler_);
}

#line 24 "src/expression/MultivariateDiagonal.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateDiagonal>> birch::diagonal(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/expression/MultivariateDiagonal.birch"
  libbirch_function_("diagonal", "src/expression/MultivariateDiagonal.birch", 24);
  #line 25 "src/expression/MultivariateDiagonal.birch"
  libbirch_line_(25);
  #line 25 "src/expression/MultivariateDiagonal.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateDiagonal>>>(y, handler_);
}

#line 66 "src/expression/MultivariateElement.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateElement<birch::type::Real>>> birch::MultivariateElement(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y, const birch::type::Integer& i, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "src/expression/MultivariateElement.birch"
  libbirch_function_("MultivariateElement", "src/expression/MultivariateElement.birch", 66);
  #line 68 "src/expression/MultivariateElement.birch"
  libbirch_line_(68);
  #line 68 "src/expression/MultivariateElement.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateElement<birch::type::Real>>>>(y, i, handler_);
}

#line 74 "src/expression/MultivariateElement.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateElement<birch::type::Integer>>> birch::MultivariateElement(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Integer,1>>>>& y, const birch::type::Integer& i, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 74 "src/expression/MultivariateElement.birch"
  libbirch_function_("MultivariateElement", "src/expression/MultivariateElement.birch", 74);
  #line 76 "src/expression/MultivariateElement.birch"
  libbirch_line_(76);
  #line 76 "src/expression/MultivariateElement.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateElement<birch::type::Integer>>>>(y, i, handler_);
}

#line 82 "src/expression/MultivariateElement.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateElement<birch::type::Boolean>>> birch::MultivariateElement(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Boolean,1>>>>& y, const birch::type::Integer& i, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 82 "src/expression/MultivariateElement.birch"
  libbirch_function_("MultivariateElement", "src/expression/MultivariateElement.birch", 82);
  #line 84 "src/expression/MultivariateElement.birch"
  libbirch_line_(84);
  #line 84 "src/expression/MultivariateElement.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateElement<birch::type::Boolean>>>>(y, i, handler_);
}

#line 4 "src/expression/MultivariateMultiply.birch"
birch::type::MultivariateMultiply::MultivariateMultiply(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/MultivariateMultiply.birch"
    super_type_(y, z) {
  //
}

#line 8 "src/expression/MultivariateMultiply.birch"
birch::type::Integer birch::type::MultivariateMultiply::doRows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 8 "src/expression/MultivariateMultiply.birch"
  libbirch_function_("doRows", "src/expression/MultivariateMultiply.birch", 8);
  #line 9 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(9);
  #line 9 "src/expression/MultivariateMultiply.birch"
  return this_()->y.get()->rows(handler_);
}

#line 12 "src/expression/MultivariateMultiply.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateMultiply::doEvaluate(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,1>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 12 "src/expression/MultivariateMultiply.birch"
  libbirch_function_("doEvaluate", "src/expression/MultivariateMultiply.birch", 12);
  #line 13 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(13);
  #line 13 "src/expression/MultivariateMultiply.birch"
  return y * z;
}

#line 16 "src/expression/MultivariateMultiply.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MultivariateMultiply::doEvaluateGradLeft(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,1>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/expression/MultivariateMultiply.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/MultivariateMultiply.birch", 16);
  #line 18 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(18);
  #line 18 "src/expression/MultivariateMultiply.birch"
  return birch::outer(d, z, handler_);
}

#line 21 "src/expression/MultivariateMultiply.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateMultiply::doEvaluateGradRight(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::DefaultArray<birch::type::Real,1>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "src/expression/MultivariateMultiply.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/MultivariateMultiply.birch", 21);
  #line 23 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(23);
  #line 23 "src/expression/MultivariateMultiply.birch"
  return birch::transpose(y, handler_) * d;
}

#line 26 "src/expression/MultivariateMultiply.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> birch::type::MultivariateMultiply::graftLinearMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/expression/MultivariateMultiply.birch"
  libbirch_function_("graftLinearMultivariateGaussian", "src/expression/MultivariateMultiply.birch", 26);
  #line 28 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(28);
  #line 28 "src/expression/MultivariateMultiply.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> r;
  #line 29 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(29);
  #line 29 "src/expression/MultivariateMultiply.birch"
  if (!this_()->hasValue(handler_)) {
    #line 30 "src/expression/MultivariateMultiply.birch"
    libbirch_line_(30);
    #line 30 "src/expression/MultivariateMultiply.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>> x1;
    #line 31 "src/expression/MultivariateMultiply.birch"
    libbirch_line_(31);
    #line 31 "src/expression/MultivariateMultiply.birch"
    if ((r = this_()->z.get()->graftLinearMultivariateGaussian(handler_)).query()) {
      #line 32 "src/expression/MultivariateMultiply.birch"
      libbirch_line_(32);
      #line 32 "src/expression/MultivariateMultiply.birch"
      r.get()->leftMultiply(this_()->y.get(), handler_);
    } else {
      #line 33 "src/expression/MultivariateMultiply.birch"
      libbirch_line_(33);
      #line 33 "src/expression/MultivariateMultiply.birch"
      if ((x1 = this_()->z.get()->graftMultivariateGaussian(handler_)).query()) {
        #line 34 "src/expression/MultivariateMultiply.birch"
        libbirch_line_(34);
        #line 34 "src/expression/MultivariateMultiply.birch"
        r = birch::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>(this_()->y.get(), x1.get(), handler_);
      }
    }
  }
  #line 37 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(37);
  #line 37 "src/expression/MultivariateMultiply.birch"
  return r;
}

#line 40 "src/expression/MultivariateMultiply.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> birch::type::MultivariateMultiply::graftLinearMultivariateNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "src/expression/MultivariateMultiply.birch"
  libbirch_function_("graftLinearMultivariateNormalInverseGamma", "src/expression/MultivariateMultiply.birch", 40);
  #line 42 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(42);
  #line 42 "src/expression/MultivariateMultiply.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> r;
  #line 43 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(43);
  #line 43 "src/expression/MultivariateMultiply.birch"
  if (!this_()->hasValue(handler_)) {
    #line 44 "src/expression/MultivariateMultiply.birch"
    libbirch_line_(44);
    #line 44 "src/expression/MultivariateMultiply.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>> x1;
    #line 46 "src/expression/MultivariateMultiply.birch"
    libbirch_line_(46);
    #line 46 "src/expression/MultivariateMultiply.birch"
    if ((r = this_()->z.get()->graftLinearMultivariateNormalInverseGamma(compare, handler_)).query()) {
      #line 47 "src/expression/MultivariateMultiply.birch"
      libbirch_line_(47);
      #line 47 "src/expression/MultivariateMultiply.birch"
      r.get()->leftMultiply(this_()->y.get(), handler_);
    } else {
      #line 48 "src/expression/MultivariateMultiply.birch"
      libbirch_line_(48);
      #line 48 "src/expression/MultivariateMultiply.birch"
      if ((x1 = this_()->z.get()->graftMultivariateNormalInverseGamma(compare, handler_)).query()) {
        #line 49 "src/expression/MultivariateMultiply.birch"
        libbirch_line_(49);
        #line 49 "src/expression/MultivariateMultiply.birch"
        r = birch::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>(this_()->y.get(), x1.get(), handler_);
      }
    }
  }
  #line 52 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(52);
  #line 52 "src/expression/MultivariateMultiply.birch"
  return r;
}

#line 59 "src/expression/MultivariateMultiply.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateMultiply>> birch::operator*(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z) {
  #line 59 "src/expression/MultivariateMultiply.birch"
  libbirch_function_("*", "src/expression/MultivariateMultiply.birch", 59);
  #line 61 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(61);
  #line 61 "src/expression/MultivariateMultiply.birch"
  libbirch_assert_(y->columns() == z->rows());
  #line 62 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(62);
  #line 62 "src/expression/MultivariateMultiply.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateMultiply>>>(y, z);
}

#line 68 "src/expression/MultivariateMultiply.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateMultiply>> birch::operator*(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z) {
  #line 68 "src/expression/MultivariateMultiply.birch"
  libbirch_function_("*", "src/expression/MultivariateMultiply.birch", 68);
  #line 69 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(69);
  #line 69 "src/expression/MultivariateMultiply.birch"
  return birch::box(y) * z;
}

#line 75 "src/expression/MultivariateMultiply.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateMultiply>> birch::operator*(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 75 "src/expression/MultivariateMultiply.birch"
  libbirch_function_("*", "src/expression/MultivariateMultiply.birch", 75);
  #line 76 "src/expression/MultivariateMultiply.birch"
  libbirch_line_(76);
  #line 76 "src/expression/MultivariateMultiply.birch"
  return y * birch::box(z);
}

#line 4 "src/expression/MultivariateNegate.birch"
birch::type::MultivariateNegate::MultivariateNegate(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/MultivariateNegate.birch"
    super_type_(y) {
  //
}

#line 7 "src/expression/MultivariateNegate.birch"
birch::type::Integer birch::type::MultivariateNegate::doRows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/MultivariateNegate.birch"
  libbirch_function_("doRows", "src/expression/MultivariateNegate.birch", 7);
  #line 8 "src/expression/MultivariateNegate.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MultivariateNegate.birch"
  return this_()->y.get()->rows(handler_);
}

#line 11 "src/expression/MultivariateNegate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateNegate::doEvaluate(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/MultivariateNegate.birch"
  libbirch_function_("doEvaluate", "src/expression/MultivariateNegate.birch", 11);
  #line 12 "src/expression/MultivariateNegate.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MultivariateNegate.birch"
  return -y;
}

#line 15 "src/expression/MultivariateNegate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateNegate::doEvaluateGrad(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/expression/MultivariateNegate.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/MultivariateNegate.birch", 15);
  #line 17 "src/expression/MultivariateNegate.birch"
  libbirch_line_(17);
  #line 17 "src/expression/MultivariateNegate.birch"
  return -d;
}

#line 20 "src/expression/MultivariateNegate.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> birch::type::MultivariateNegate::graftLinearMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/expression/MultivariateNegate.birch"
  libbirch_function_("graftLinearMultivariateGaussian", "src/expression/MultivariateNegate.birch", 20);
  #line 22 "src/expression/MultivariateNegate.birch"
  libbirch_line_(22);
  #line 22 "src/expression/MultivariateNegate.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> r;
  #line 23 "src/expression/MultivariateNegate.birch"
  libbirch_line_(23);
  #line 23 "src/expression/MultivariateNegate.birch"
  if (!this_()->hasValue(handler_)) {
    #line 24 "src/expression/MultivariateNegate.birch"
    libbirch_line_(24);
    #line 24 "src/expression/MultivariateNegate.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>> x1;
    #line 26 "src/expression/MultivariateNegate.birch"
    libbirch_line_(26);
    #line 26 "src/expression/MultivariateNegate.birch"
    if ((r = this_()->y.get()->graftLinearMultivariateGaussian(handler_)).query()) {
      #line 27 "src/expression/MultivariateNegate.birch"
      libbirch_line_(27);
      #line 27 "src/expression/MultivariateNegate.birch"
      r.get()->negate(handler_);
    } else {
      #line 28 "src/expression/MultivariateNegate.birch"
      libbirch_line_(28);
      #line 28 "src/expression/MultivariateNegate.birch"
      if ((x1 = this_()->y.get()->graftMultivariateGaussian(handler_)).query()) {
        #line 29 "src/expression/MultivariateNegate.birch"
        libbirch_line_(29);
        #line 29 "src/expression/MultivariateNegate.birch"
        auto R = x1.get()->rows(handler_);
        #line 30 "src/expression/MultivariateNegate.birch"
        libbirch_line_(30);
        #line 30 "src/expression/MultivariateNegate.birch"
        r = birch::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>(birch::box(birch::diagonal(-1.0, R, handler_), handler_), x1.get(), birch::box(birch::vector(0.0, R, handler_), handler_), handler_);
      }
    }
  }
  #line 34 "src/expression/MultivariateNegate.birch"
  libbirch_line_(34);
  #line 34 "src/expression/MultivariateNegate.birch"
  return r;
}

#line 37 "src/expression/MultivariateNegate.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> birch::type::MultivariateNegate::graftLinearMultivariateNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/expression/MultivariateNegate.birch"
  libbirch_function_("graftLinearMultivariateNormalInverseGamma", "src/expression/MultivariateNegate.birch", 37);
  #line 39 "src/expression/MultivariateNegate.birch"
  libbirch_line_(39);
  #line 39 "src/expression/MultivariateNegate.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> r;
  #line 40 "src/expression/MultivariateNegate.birch"
  libbirch_line_(40);
  #line 40 "src/expression/MultivariateNegate.birch"
  if (!this_()->hasValue(handler_)) {
    #line 41 "src/expression/MultivariateNegate.birch"
    libbirch_line_(41);
    #line 41 "src/expression/MultivariateNegate.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>> x1;
    #line 43 "src/expression/MultivariateNegate.birch"
    libbirch_line_(43);
    #line 43 "src/expression/MultivariateNegate.birch"
    if ((r = this_()->y.get()->graftLinearMultivariateNormalInverseGamma(compare, handler_)).query()) {
      #line 44 "src/expression/MultivariateNegate.birch"
      libbirch_line_(44);
      #line 44 "src/expression/MultivariateNegate.birch"
      r.get()->negate(handler_);
    } else {
      #line 45 "src/expression/MultivariateNegate.birch"
      libbirch_line_(45);
      #line 45 "src/expression/MultivariateNegate.birch"
      if ((x1 = this_()->y.get()->graftMultivariateNormalInverseGamma(compare, handler_)).query()) {
        #line 46 "src/expression/MultivariateNegate.birch"
        libbirch_line_(46);
        #line 46 "src/expression/MultivariateNegate.birch"
        auto R = x1.get()->rows(handler_);
        #line 47 "src/expression/MultivariateNegate.birch"
        libbirch_line_(47);
        #line 47 "src/expression/MultivariateNegate.birch"
        r = birch::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>(birch::box(birch::diagonal(-1.0, R, handler_), handler_), x1.get(), birch::box(birch::vector(0.0, R, handler_), handler_), handler_);
      }
    }
  }
  #line 51 "src/expression/MultivariateNegate.birch"
  libbirch_line_(51);
  #line 51 "src/expression/MultivariateNegate.birch"
  return r;
}

#line 58 "src/expression/MultivariateNegate.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNegate>> birch::operator-(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y) {
  #line 58 "src/expression/MultivariateNegate.birch"
  libbirch_function_("-", "src/expression/MultivariateNegate.birch", 58);
  #line 59 "src/expression/MultivariateNegate.birch"
  libbirch_line_(59);
  #line 59 "src/expression/MultivariateNegate.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNegate>>>(y);
}

#line 4 "src/expression/MultivariateRectify.birch"
birch::type::MultivariateRectify::MultivariateRectify(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/MultivariateRectify.birch"
    super_type_(y) {
  //
}

#line 7 "src/expression/MultivariateRectify.birch"
birch::type::Integer birch::type::MultivariateRectify::doRows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/MultivariateRectify.birch"
  libbirch_function_("doRows", "src/expression/MultivariateRectify.birch", 7);
  #line 8 "src/expression/MultivariateRectify.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MultivariateRectify.birch"
  return this_()->y.get()->rows(handler_);
}

#line 11 "src/expression/MultivariateRectify.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateRectify::doEvaluate(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/MultivariateRectify.birch"
  libbirch_function_("doEvaluate", "src/expression/MultivariateRectify.birch", 11);
  #line 12 "src/expression/MultivariateRectify.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MultivariateRectify.birch"
  return birch::transform(y, std::function<birch::type::Real(birch::type::Real,const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_
)>([=](const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr) {
    #line 12 "src/expression/MultivariateRectify.birch"
    libbirch_line_(12);
    #line 12 "src/expression/MultivariateRectify.birch"
    return birch::rectify(y, handler_);
  }), handler_);
}

#line 15 "src/expression/MultivariateRectify.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateRectify::doEvaluateGrad(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/expression/MultivariateRectify.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/MultivariateRectify.birch", 15);
  #line 17 "src/expression/MultivariateRectify.birch"
  libbirch_line_(17);
  #line 17 "src/expression/MultivariateRectify.birch"
  return birch::transform(d, x, std::function<birch::type::Real(birch::type::Real,birch::type::Real,const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_
)>([=](const birch::type::Real& d, const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr) {
    #line 18 "src/expression/MultivariateRectify.birch"
    libbirch_line_(18);
    #line 18 "src/expression/MultivariateRectify.birch"
    if (x > 0.0) {
      #line 19 "src/expression/MultivariateRectify.birch"
      libbirch_line_(19);
      #line 19 "src/expression/MultivariateRectify.birch"
      return d;
    } else {
      #line 21 "src/expression/MultivariateRectify.birch"
      libbirch_line_(21);
      #line 21 "src/expression/MultivariateRectify.birch"
      return 0.0;
    }
  }), handler_);
}

#line 30 "src/expression/MultivariateRectify.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateRectify>> birch::rectify(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/expression/MultivariateRectify.birch"
  libbirch_function_("rectify", "src/expression/MultivariateRectify.birch", 30);
  #line 31 "src/expression/MultivariateRectify.birch"
  libbirch_line_(31);
  #line 31 "src/expression/MultivariateRectify.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateRectify>>>(x, handler_);
}

#line 4 "src/expression/MultivariateScalarDivide.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>> birch::operator/(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z) {
  #line 4 "src/expression/MultivariateScalarDivide.birch"
  libbirch_function_("/", "src/expression/MultivariateScalarDivide.birch", 4);
  #line 6 "src/expression/MultivariateScalarDivide.birch"
  libbirch_line_(6);
  #line 6 "src/expression/MultivariateScalarDivide.birch"
  return birch::diagonal(1.0 / z, y.get()->rows()) * y;
}

#line 12 "src/expression/MultivariateScalarDivide.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>> birch::operator/(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z) {
  #line 12 "src/expression/MultivariateScalarDivide.birch"
  libbirch_function_("/", "src/expression/MultivariateScalarDivide.birch", 12);
  #line 13 "src/expression/MultivariateScalarDivide.birch"
  libbirch_line_(13);
  #line 13 "src/expression/MultivariateScalarDivide.birch"
  return birch::box(y) / z;
}

#line 19 "src/expression/MultivariateScalarDivide.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>> birch::operator/(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y, const birch::type::Real& z) {
  #line 19 "src/expression/MultivariateScalarDivide.birch"
  libbirch_function_("/", "src/expression/MultivariateScalarDivide.birch", 19);
  #line 20 "src/expression/MultivariateScalarDivide.birch"
  libbirch_line_(20);
  #line 20 "src/expression/MultivariateScalarDivide.birch"
  return y / birch::box(z);
}

#line 4 "src/expression/MultivariateScalarMultiply.birch"
birch::type::MultivariateScalarMultiply::MultivariateScalarMultiply(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/MultivariateScalarMultiply.birch"
    super_type_(y, z) {
  //
}

#line 7 "src/expression/MultivariateScalarMultiply.birch"
birch::type::Integer birch::type::MultivariateScalarMultiply::doRows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_function_("doRows", "src/expression/MultivariateScalarMultiply.birch", 7);
  #line 8 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(8);
  #line 8 "src/expression/MultivariateScalarMultiply.birch"
  return this_()->z.get()->rows(handler_);
}

#line 11 "src/expression/MultivariateScalarMultiply.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateScalarMultiply::doEvaluate(const birch::type::Real& y, const libbirch::DefaultArray<birch::type::Real,1>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_function_("doEvaluate", "src/expression/MultivariateScalarMultiply.birch", 11);
  #line 12 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(12);
  #line 12 "src/expression/MultivariateScalarMultiply.birch"
  return y * z;
}

#line 15 "src/expression/MultivariateScalarMultiply.birch"
birch::type::Real birch::type::MultivariateScalarMultiply::doEvaluateGradLeft(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const birch::type::Real& y, const libbirch::DefaultArray<birch::type::Real,1>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/MultivariateScalarMultiply.birch", 15);
  #line 17 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(17);
  #line 17 "src/expression/MultivariateScalarMultiply.birch"
  return birch::dot(d, z, handler_);
}

#line 20 "src/expression/MultivariateScalarMultiply.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateScalarMultiply::doEvaluateGradRight(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const birch::type::Real& y, const libbirch::DefaultArray<birch::type::Real,1>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/MultivariateScalarMultiply.birch", 20);
  #line 22 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(22);
  #line 22 "src/expression/MultivariateScalarMultiply.birch"
  return y * d;
}

#line 25 "src/expression/MultivariateScalarMultiply.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> birch::type::MultivariateScalarMultiply::graftLinearMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_function_("graftLinearMultivariateGaussian", "src/expression/MultivariateScalarMultiply.birch", 25);
  #line 27 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(27);
  #line 27 "src/expression/MultivariateScalarMultiply.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> r;
  #line 28 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(28);
  #line 28 "src/expression/MultivariateScalarMultiply.birch"
  if (!this_()->hasValue(handler_)) {
    #line 29 "src/expression/MultivariateScalarMultiply.birch"
    libbirch_line_(29);
    #line 29 "src/expression/MultivariateScalarMultiply.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>> x1;
    #line 31 "src/expression/MultivariateScalarMultiply.birch"
    libbirch_line_(31);
    #line 31 "src/expression/MultivariateScalarMultiply.birch"
    if ((r = this_()->z.get()->graftLinearMultivariateGaussian(handler_)).query()) {
      #line 32 "src/expression/MultivariateScalarMultiply.birch"
      libbirch_line_(32);
      #line 32 "src/expression/MultivariateScalarMultiply.birch"
      r.get()->multiply(this_()->y.get(), handler_);
    } else {
      #line 33 "src/expression/MultivariateScalarMultiply.birch"
      libbirch_line_(33);
      #line 33 "src/expression/MultivariateScalarMultiply.birch"
      if ((x1 = this_()->z.get()->graftMultivariateGaussian(handler_)).query()) {
        #line 34 "src/expression/MultivariateScalarMultiply.birch"
        libbirch_line_(34);
        #line 34 "src/expression/MultivariateScalarMultiply.birch"
        r = birch::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>(birch::diagonal(this_()->y.get(), this_()->z.get()->rows(handler_), handler_), x1.get(), handler_);
      }
    }
  }
  #line 37 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(37);
  #line 37 "src/expression/MultivariateScalarMultiply.birch"
  return r;
}

#line 40 "src/expression/MultivariateScalarMultiply.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> birch::type::MultivariateScalarMultiply::graftLinearMultivariateNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_function_("graftLinearMultivariateNormalInverseGamma", "src/expression/MultivariateScalarMultiply.birch", 40);
  #line 42 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(42);
  #line 42 "src/expression/MultivariateScalarMultiply.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> r;
  #line 43 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(43);
  #line 43 "src/expression/MultivariateScalarMultiply.birch"
  if (!this_()->hasValue(handler_)) {
    #line 44 "src/expression/MultivariateScalarMultiply.birch"
    libbirch_line_(44);
    #line 44 "src/expression/MultivariateScalarMultiply.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>> x1;
    #line 46 "src/expression/MultivariateScalarMultiply.birch"
    libbirch_line_(46);
    #line 46 "src/expression/MultivariateScalarMultiply.birch"
    if ((r = this_()->z.get()->graftLinearMultivariateNormalInverseGamma(compare, handler_)).query()) {
      #line 47 "src/expression/MultivariateScalarMultiply.birch"
      libbirch_line_(47);
      #line 47 "src/expression/MultivariateScalarMultiply.birch"
      r.get()->multiply(this_()->y.get(), handler_);
    } else {
      #line 48 "src/expression/MultivariateScalarMultiply.birch"
      libbirch_line_(48);
      #line 48 "src/expression/MultivariateScalarMultiply.birch"
      if ((x1 = this_()->z.get()->graftMultivariateNormalInverseGamma(compare, handler_)).query()) {
        #line 49 "src/expression/MultivariateScalarMultiply.birch"
        libbirch_line_(49);
        #line 49 "src/expression/MultivariateScalarMultiply.birch"
        r = birch::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>(birch::diagonal(this_()->y.get(), this_()->z.get()->rows(handler_), handler_), x1.get(), handler_);
      }
    }
  }
  #line 52 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(52);
  #line 52 "src/expression/MultivariateScalarMultiply.birch"
  return r;
}

#line 59 "src/expression/MultivariateScalarMultiply.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateScalarMultiply>> birch::operator*(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z) {
  #line 59 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_function_("*", "src/expression/MultivariateScalarMultiply.birch", 59);
  #line 61 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(61);
  #line 61 "src/expression/MultivariateScalarMultiply.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateScalarMultiply>>>(y, z);
}

#line 67 "src/expression/MultivariateScalarMultiply.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateScalarMultiply>> birch::operator*(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z) {
  #line 67 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_function_("*", "src/expression/MultivariateScalarMultiply.birch", 67);
  #line 68 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(68);
  #line 68 "src/expression/MultivariateScalarMultiply.birch"
  return birch::box(y) * z;
}

#line 74 "src/expression/MultivariateScalarMultiply.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateScalarMultiply>> birch::operator*(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 74 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_function_("*", "src/expression/MultivariateScalarMultiply.birch", 74);
  #line 75 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(75);
  #line 75 "src/expression/MultivariateScalarMultiply.birch"
  return y * birch::box(z);
}

#line 81 "src/expression/MultivariateScalarMultiply.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateScalarMultiply>> birch::operator*(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z) {
  #line 81 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_function_("*", "src/expression/MultivariateScalarMultiply.birch", 81);
  #line 83 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(83);
  #line 83 "src/expression/MultivariateScalarMultiply.birch"
  return z * y;
}

#line 89 "src/expression/MultivariateScalarMultiply.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateScalarMultiply>> birch::operator*(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z) {
  #line 89 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_function_("*", "src/expression/MultivariateScalarMultiply.birch", 89);
  #line 90 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(90);
  #line 90 "src/expression/MultivariateScalarMultiply.birch"
  return z * y;
}

#line 96 "src/expression/MultivariateScalarMultiply.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateScalarMultiply>> birch::operator*(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y, const birch::type::Real& z) {
  #line 96 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_function_("*", "src/expression/MultivariateScalarMultiply.birch", 96);
  #line 97 "src/expression/MultivariateScalarMultiply.birch"
  libbirch_line_(97);
  #line 97 "src/expression/MultivariateScalarMultiply.birch"
  return z * y;
}

#line 29 "src/expression/MultivariateSolve.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateSolve<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::DefaultArray<birch::type::Real,2>>>> birch::solve(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "src/expression/MultivariateSolve.birch"
  libbirch_function_("solve", "src/expression/MultivariateSolve.birch", 29);
  #line 31 "src/expression/MultivariateSolve.birch"
  libbirch_line_(31);
  #line 31 "src/expression/MultivariateSolve.birch"
  libbirch_assert_(y.get()->columns(handler_) == z.get()->rows(handler_));
  #line 32 "src/expression/MultivariateSolve.birch"
  libbirch_line_(32);
  #line 32 "src/expression/MultivariateSolve.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateSolve<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::DefaultArray<birch::type::Real,2>>>>>(y, z, handler_);
}

#line 38 "src/expression/MultivariateSolve.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateSolve<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::DefaultArray<birch::type::Real,2>>>> birch::solve(const libbirch::DefaultArray<birch::type::Real,2>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "src/expression/MultivariateSolve.birch"
  libbirch_function_("solve", "src/expression/MultivariateSolve.birch", 38);
  #line 40 "src/expression/MultivariateSolve.birch"
  libbirch_line_(40);
  #line 40 "src/expression/MultivariateSolve.birch"
  return birch::solve(birch::box(y, handler_), z, handler_);
}

#line 46 "src/expression/MultivariateSolve.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateSolve<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::DefaultArray<birch::type::Real,2>>>> birch::solve(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::DefaultArray<birch::type::Real,1>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/expression/MultivariateSolve.birch"
  libbirch_function_("solve", "src/expression/MultivariateSolve.birch", 46);
  #line 48 "src/expression/MultivariateSolve.birch"
  libbirch_line_(48);
  #line 48 "src/expression/MultivariateSolve.birch"
  return birch::solve(y, birch::box(z, handler_), handler_);
}

#line 54 "src/expression/MultivariateSolve.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateSolve<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, birch::type::LLT>>> birch::solve(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "src/expression/MultivariateSolve.birch"
  libbirch_function_("solve", "src/expression/MultivariateSolve.birch", 54);
  #line 56 "src/expression/MultivariateSolve.birch"
  libbirch_line_(56);
  #line 56 "src/expression/MultivariateSolve.birch"
  libbirch_assert_(y.get()->columns(handler_) == z.get()->rows(handler_));
  #line 57 "src/expression/MultivariateSolve.birch"
  libbirch_line_(57);
  #line 57 "src/expression/MultivariateSolve.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateSolve<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, birch::type::LLT>>>>(y, z, handler_);
}

#line 63 "src/expression/MultivariateSolve.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateSolve<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, birch::type::LLT>>> birch::solve(const birch::type::LLT& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 63 "src/expression/MultivariateSolve.birch"
  libbirch_function_("solve", "src/expression/MultivariateSolve.birch", 63);
  #line 65 "src/expression/MultivariateSolve.birch"
  libbirch_line_(65);
  #line 65 "src/expression/MultivariateSolve.birch"
  return birch::solve(birch::box(y, handler_), z, handler_);
}

#line 71 "src/expression/MultivariateSolve.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateSolve<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, birch::type::LLT>>> birch::solve(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& y, const libbirch::DefaultArray<birch::type::Real,1>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 71 "src/expression/MultivariateSolve.birch"
  libbirch_function_("solve", "src/expression/MultivariateSolve.birch", 71);
  #line 73 "src/expression/MultivariateSolve.birch"
  libbirch_line_(73);
  #line 73 "src/expression/MultivariateSolve.birch"
  return birch::solve(y, birch::box(z, handler_), handler_);
}

#line 4 "src/expression/MultivariateSubtract.birch"
birch::type::MultivariateSubtract::MultivariateSubtract(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/MultivariateSubtract.birch"
    super_type_(y, z) {
  //
}

#line 8 "src/expression/MultivariateSubtract.birch"
birch::type::Integer birch::type::MultivariateSubtract::doRows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 8 "src/expression/MultivariateSubtract.birch"
  libbirch_function_("doRows", "src/expression/MultivariateSubtract.birch", 8);
  #line 9 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(9);
  #line 9 "src/expression/MultivariateSubtract.birch"
  return this_()->y.get()->rows(handler_);
}

#line 12 "src/expression/MultivariateSubtract.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateSubtract::doEvaluate(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 12 "src/expression/MultivariateSubtract.birch"
  libbirch_function_("doEvaluate", "src/expression/MultivariateSubtract.birch", 12);
  #line 13 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(13);
  #line 13 "src/expression/MultivariateSubtract.birch"
  return y - z;
}

#line 16 "src/expression/MultivariateSubtract.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateSubtract::doEvaluateGradLeft(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/expression/MultivariateSubtract.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/MultivariateSubtract.birch", 16);
  #line 18 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(18);
  #line 18 "src/expression/MultivariateSubtract.birch"
  return d;
}

#line 21 "src/expression/MultivariateSubtract.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateSubtract::doEvaluateGradRight(const libbirch::DefaultArray<birch::type::Real,1>& d, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "src/expression/MultivariateSubtract.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/MultivariateSubtract.birch", 21);
  #line 23 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(23);
  #line 23 "src/expression/MultivariateSubtract.birch"
  return -d;
}

#line 26 "src/expression/MultivariateSubtract.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> birch::type::MultivariateSubtract::graftLinearMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/expression/MultivariateSubtract.birch"
  libbirch_function_("graftLinearMultivariateGaussian", "src/expression/MultivariateSubtract.birch", 26);
  #line 28 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(28);
  #line 28 "src/expression/MultivariateSubtract.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> r;
  #line 29 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(29);
  #line 29 "src/expression/MultivariateSubtract.birch"
  if (!this_()->hasValue(handler_)) {
    #line 30 "src/expression/MultivariateSubtract.birch"
    libbirch_line_(30);
    #line 30 "src/expression/MultivariateSubtract.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>> x1;
    #line 32 "src/expression/MultivariateSubtract.birch"
    libbirch_line_(32);
    #line 32 "src/expression/MultivariateSubtract.birch"
    if ((r = this_()->y.get()->graftLinearMultivariateGaussian(handler_)).query()) {
      #line 33 "src/expression/MultivariateSubtract.birch"
      libbirch_line_(33);
      #line 33 "src/expression/MultivariateSubtract.birch"
      r.get()->subtract(this_()->z.get(), handler_);
    } else {
      #line 34 "src/expression/MultivariateSubtract.birch"
      libbirch_line_(34);
      #line 34 "src/expression/MultivariateSubtract.birch"
      if ((r = this_()->z.get()->graftLinearMultivariateGaussian(handler_)).query()) {
        #line 35 "src/expression/MultivariateSubtract.birch"
        libbirch_line_(35);
        #line 35 "src/expression/MultivariateSubtract.birch"
        r.get()->negateAndAdd(this_()->y.get(), handler_);
      } else {
        #line 36 "src/expression/MultivariateSubtract.birch"
        libbirch_line_(36);
        #line 36 "src/expression/MultivariateSubtract.birch"
        if ((x1 = this_()->y.get()->graftMultivariateGaussian(handler_)).query()) {
          #line 37 "src/expression/MultivariateSubtract.birch"
          libbirch_line_(37);
          #line 37 "src/expression/MultivariateSubtract.birch"
          r = birch::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>(birch::box(birch::identity(this_()->z.get()->rows(handler_), handler_), handler_), x1.get(), -this_()->z.get(), handler_);
        } else {
          #line 38 "src/expression/MultivariateSubtract.birch"
          libbirch_line_(38);
          #line 38 "src/expression/MultivariateSubtract.birch"
          if ((x1 = this_()->z.get()->graftMultivariateGaussian(handler_)).query()) {
            #line 39 "src/expression/MultivariateSubtract.birch"
            libbirch_line_(39);
            #line 39 "src/expression/MultivariateSubtract.birch"
            r = birch::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>(birch::box(birch::diagonal(-1.0, this_()->z.get()->rows(handler_), handler_), handler_), x1.get(), this_()->y.get(), handler_);
          }
        }
      }
    }
  }
  #line 42 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(42);
  #line 42 "src/expression/MultivariateSubtract.birch"
  return r;
}

#line 45 "src/expression/MultivariateSubtract.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> birch::type::MultivariateSubtract::graftLinearMultivariateNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "src/expression/MultivariateSubtract.birch"
  libbirch_function_("graftLinearMultivariateNormalInverseGamma", "src/expression/MultivariateSubtract.birch", 45);
  #line 47 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(47);
  #line 47 "src/expression/MultivariateSubtract.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> r;
  #line 48 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(48);
  #line 48 "src/expression/MultivariateSubtract.birch"
  if (!this_()->hasValue(handler_)) {
    #line 49 "src/expression/MultivariateSubtract.birch"
    libbirch_line_(49);
    #line 49 "src/expression/MultivariateSubtract.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>> x1;
    #line 51 "src/expression/MultivariateSubtract.birch"
    libbirch_line_(51);
    #line 51 "src/expression/MultivariateSubtract.birch"
    if ((r = this_()->y.get()->graftLinearMultivariateNormalInverseGamma(compare, handler_)).query()) {
      #line 52 "src/expression/MultivariateSubtract.birch"
      libbirch_line_(52);
      #line 52 "src/expression/MultivariateSubtract.birch"
      r.get()->subtract(this_()->z.get(), handler_);
    } else {
      #line 53 "src/expression/MultivariateSubtract.birch"
      libbirch_line_(53);
      #line 53 "src/expression/MultivariateSubtract.birch"
      if ((r = this_()->z.get()->graftLinearMultivariateNormalInverseGamma(compare, handler_)).query()) {
        #line 54 "src/expression/MultivariateSubtract.birch"
        libbirch_line_(54);
        #line 54 "src/expression/MultivariateSubtract.birch"
        r.get()->negateAndAdd(this_()->y.get(), handler_);
      } else {
        #line 55 "src/expression/MultivariateSubtract.birch"
        libbirch_line_(55);
        #line 55 "src/expression/MultivariateSubtract.birch"
        if ((x1 = this_()->y.get()->graftMultivariateNormalInverseGamma(compare, handler_)).query()) {
          #line 56 "src/expression/MultivariateSubtract.birch"
          libbirch_line_(56);
          #line 56 "src/expression/MultivariateSubtract.birch"
          r = birch::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>(birch::box(birch::identity(this_()->z.get()->rows(handler_), handler_), handler_), x1.get(), -this_()->z.get(), handler_);
        } else {
          #line 57 "src/expression/MultivariateSubtract.birch"
          libbirch_line_(57);
          #line 57 "src/expression/MultivariateSubtract.birch"
          if ((x1 = this_()->z.get()->graftMultivariateNormalInverseGamma(compare, handler_)).query()) {
            #line 58 "src/expression/MultivariateSubtract.birch"
            libbirch_line_(58);
            #line 58 "src/expression/MultivariateSubtract.birch"
            r = birch::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>(birch::box(birch::diagonal(-1.0, this_()->z.get()->rows(handler_), handler_), handler_), x1.get(), this_()->y.get(), handler_);
          }
        }
      }
    }
  }
  #line 61 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(61);
  #line 61 "src/expression/MultivariateSubtract.birch"
  return r;
}

#line 68 "src/expression/MultivariateSubtract.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateSubtract>> birch::operator-(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z) {
  #line 68 "src/expression/MultivariateSubtract.birch"
  libbirch_function_("-", "src/expression/MultivariateSubtract.birch", 68);
  #line 70 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(70);
  #line 70 "src/expression/MultivariateSubtract.birch"
  libbirch_assert_(y->rows() == z->rows());
  #line 71 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(71);
  #line 71 "src/expression/MultivariateSubtract.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateSubtract>>>(y, z);
}

#line 77 "src/expression/MultivariateSubtract.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateSubtract>> birch::operator-(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z) {
  #line 77 "src/expression/MultivariateSubtract.birch"
  libbirch_function_("-", "src/expression/MultivariateSubtract.birch", 77);
  #line 78 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(78);
  #line 78 "src/expression/MultivariateSubtract.birch"
  return birch::box(y) - z;
}

#line 84 "src/expression/MultivariateSubtract.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateSubtract>> birch::operator-(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y, const libbirch::DefaultArray<birch::type::Real,1>& z) {
  #line 84 "src/expression/MultivariateSubtract.birch"
  libbirch_function_("-", "src/expression/MultivariateSubtract.birch", 84);
  #line 85 "src/expression/MultivariateSubtract.birch"
  libbirch_line_(85);
  #line 85 "src/expression/MultivariateSubtract.birch"
  return y - birch::box(z);
}

#line 4 "src/expression/Negate.birch"
birch::type::Negate::Negate(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/Negate.birch"
    super_type_(y) {
  //
}

#line 6 "src/expression/Negate.birch"
birch::type::Real birch::type::Negate::doEvaluate(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 6 "src/expression/Negate.birch"
  libbirch_function_("doEvaluate", "src/expression/Negate.birch", 6);
  #line 7 "src/expression/Negate.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Negate.birch"
  return -y;
}

#line 10 "src/expression/Negate.birch"
birch::type::Real birch::type::Negate::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/expression/Negate.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Negate.birch", 10);
  #line 11 "src/expression/Negate.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Negate.birch"
  return -d;
}

#line 14 "src/expression/Negate.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>>>>> birch::type::Negate::graftLinearGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/expression/Negate.birch"
  libbirch_function_("graftLinearGaussian", "src/expression/Negate.birch", 14);
  #line 15 "src/expression/Negate.birch"
  libbirch_line_(15);
  #line 15 "src/expression/Negate.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>>>>> r;
  #line 16 "src/expression/Negate.birch"
  libbirch_line_(16);
  #line 16 "src/expression/Negate.birch"
  if (!this_()->hasValue(handler_)) {
    #line 17 "src/expression/Negate.birch"
    libbirch_line_(17);
    #line 17 "src/expression/Negate.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>> x1;
    #line 18 "src/expression/Negate.birch"
    libbirch_line_(18);
    #line 18 "src/expression/Negate.birch"
    if ((r = this_()->y.get()->graftLinearGaussian(handler_)).query()) {
      #line 19 "src/expression/Negate.birch"
      libbirch_line_(19);
      #line 19 "src/expression/Negate.birch"
      r.get()->negate(handler_);
    } else {
      #line 20 "src/expression/Negate.birch"
      libbirch_line_(20);
      #line 20 "src/expression/Negate.birch"
      if ((x1 = this_()->y.get()->graftGaussian(handler_)).query()) {
        #line 21 "src/expression/Negate.birch"
        libbirch_line_(21);
        #line 21 "src/expression/Negate.birch"
        r = birch::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>>(birch::box(-1.0, handler_), x1.get(), birch::box(0.0, handler_), handler_);
      }
    }
  }
  #line 24 "src/expression/Negate.birch"
  libbirch_line_(24);
  #line 24 "src/expression/Negate.birch"
  return r;
}

#line 27 "src/expression/Negate.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> birch::type::Negate::graftDotGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/expression/Negate.birch"
  libbirch_function_("graftDotGaussian", "src/expression/Negate.birch", 27);
  #line 28 "src/expression/Negate.birch"
  libbirch_line_(28);
  #line 28 "src/expression/Negate.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> r;
  #line 29 "src/expression/Negate.birch"
  libbirch_line_(29);
  #line 29 "src/expression/Negate.birch"
  if (!this_()->hasValue(handler_)) {
    #line 30 "src/expression/Negate.birch"
    libbirch_line_(30);
    #line 30 "src/expression/Negate.birch"
    if ((r = this_()->y.get()->graftDotGaussian(handler_)).query()) {
      #line 31 "src/expression/Negate.birch"
      libbirch_line_(31);
      #line 31 "src/expression/Negate.birch"
      r.get()->negate(handler_);
    }
  }
  #line 34 "src/expression/Negate.birch"
  libbirch_line_(34);
  #line 34 "src/expression/Negate.birch"
  return r;
}

#line 37 "src/expression/Negate.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>>>>> birch::type::Negate::graftLinearNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/expression/Negate.birch"
  libbirch_function_("graftLinearNormalInverseGamma", "src/expression/Negate.birch", 37);
  #line 39 "src/expression/Negate.birch"
  libbirch_line_(39);
  #line 39 "src/expression/Negate.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>>>>> r;
  #line 40 "src/expression/Negate.birch"
  libbirch_line_(40);
  #line 40 "src/expression/Negate.birch"
  if (!this_()->hasValue(handler_)) {
    #line 41 "src/expression/Negate.birch"
    libbirch_line_(41);
    #line 41 "src/expression/Negate.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>> x1;
    #line 42 "src/expression/Negate.birch"
    libbirch_line_(42);
    #line 42 "src/expression/Negate.birch"
    if ((r = this_()->y.get()->graftLinearNormalInverseGamma(compare, handler_)).query()) {
      #line 43 "src/expression/Negate.birch"
      libbirch_line_(43);
      #line 43 "src/expression/Negate.birch"
      r.get()->negate(handler_);
    } else {
      #line 44 "src/expression/Negate.birch"
      libbirch_line_(44);
      #line 44 "src/expression/Negate.birch"
      if ((x1 = this_()->y.get()->graftNormalInverseGamma(compare, handler_)).query()) {
        #line 45 "src/expression/Negate.birch"
        libbirch_line_(45);
        #line 45 "src/expression/Negate.birch"
        r = birch::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>>(birch::box(-1.0, handler_), x1.get(), birch::box(0.0, handler_), handler_);
      }
    }
  }
  #line 48 "src/expression/Negate.birch"
  libbirch_line_(48);
  #line 48 "src/expression/Negate.birch"
  return r;
}

#line 51 "src/expression/Negate.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> birch::type::Negate::graftDotNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 51 "src/expression/Negate.birch"
  libbirch_function_("graftDotNormalInverseGamma", "src/expression/Negate.birch", 51);
  #line 53 "src/expression/Negate.birch"
  libbirch_line_(53);
  #line 53 "src/expression/Negate.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> r;
  #line 54 "src/expression/Negate.birch"
  libbirch_line_(54);
  #line 54 "src/expression/Negate.birch"
  if (!this_()->hasValue(handler_)) {
    #line 55 "src/expression/Negate.birch"
    libbirch_line_(55);
    #line 55 "src/expression/Negate.birch"
    if ((r = this_()->y.get()->graftDotNormalInverseGamma(compare, handler_)).query()) {
      #line 56 "src/expression/Negate.birch"
      libbirch_line_(56);
      #line 56 "src/expression/Negate.birch"
      r.get()->negate(handler_);
    }
  }
  #line 59 "src/expression/Negate.birch"
  libbirch_line_(59);
  #line 59 "src/expression/Negate.birch"
  return r;
}

#line 66 "src/expression/Negate.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Negate>> birch::operator-(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y) {
  #line 66 "src/expression/Negate.birch"
  libbirch_function_("-", "src/expression/Negate.birch", 66);
  #line 67 "src/expression/Negate.birch"
  libbirch_line_(67);
  #line 67 "src/expression/Negate.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Negate>>>(y);
}

#line 4 "src/expression/Outer.birch"
birch::type::Outer::Outer(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/Outer.birch"
    super_type_(y, z) {
  //
}

#line 7 "src/expression/Outer.birch"
birch::type::Integer birch::type::Outer::doRows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/Outer.birch"
  libbirch_function_("doRows", "src/expression/Outer.birch", 7);
  #line 8 "src/expression/Outer.birch"
  libbirch_line_(8);
  #line 8 "src/expression/Outer.birch"
  return this_()->y.get()->rows(handler_);
}

#line 11 "src/expression/Outer.birch"
birch::type::Integer birch::type::Outer::doColumns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/Outer.birch"
  libbirch_function_("doColumns", "src/expression/Outer.birch", 11);
  #line 12 "src/expression/Outer.birch"
  libbirch_line_(12);
  #line 12 "src/expression/Outer.birch"
  return this_()->z.get()->rows(handler_);
}

#line 15 "src/expression/Outer.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::Outer::doEvaluate(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/expression/Outer.birch"
  libbirch_function_("doEvaluate", "src/expression/Outer.birch", 15);
  #line 16 "src/expression/Outer.birch"
  libbirch_line_(16);
  #line 16 "src/expression/Outer.birch"
  return birch::outer(y, z, handler_);
}

#line 19 "src/expression/Outer.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::Outer::doEvaluateGradLeft(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/expression/Outer.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/Outer.birch", 19);
  #line 21 "src/expression/Outer.birch"
  libbirch_line_(21);
  #line 21 "src/expression/Outer.birch"
  return d * z;
}

#line 24 "src/expression/Outer.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::Outer::doEvaluateGradRight(const libbirch::DefaultArray<birch::type::Real,2>& d, const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::DefaultArray<birch::type::Real,1>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/expression/Outer.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/Outer.birch", 24);
  #line 27 "src/expression/Outer.birch"
  libbirch_line_(27);
  #line 27 "src/expression/Outer.birch"
  return birch::transpose(d, handler_) * y;
}

#line 34 "src/expression/Outer.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Outer>> birch::outer(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/expression/Outer.birch"
  libbirch_function_("outer", "src/expression/Outer.birch", 34);
  #line 35 "src/expression/Outer.birch"
  libbirch_line_(35);
  #line 35 "src/expression/Outer.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Outer>>>(y, z, handler_);
}

#line 41 "src/expression/Outer.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Outer>> birch::outer(const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "src/expression/Outer.birch"
  libbirch_function_("outer", "src/expression/Outer.birch", 41);
  #line 42 "src/expression/Outer.birch"
  libbirch_line_(42);
  #line 42 "src/expression/Outer.birch"
  return birch::outer(birch::box(y, handler_), z, handler_);
}

#line 48 "src/expression/Outer.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Outer>> birch::outer(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y, const libbirch::DefaultArray<birch::type::Real,1>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "src/expression/Outer.birch"
  libbirch_function_("outer", "src/expression/Outer.birch", 48);
  #line 49 "src/expression/Outer.birch"
  libbirch_line_(49);
  #line 49 "src/expression/Outer.birch"
  return birch::outer(y, birch::box(z, handler_), handler_);
}

#line 55 "src/expression/Outer.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Outer>> birch::outer(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 55 "src/expression/Outer.birch"
  libbirch_function_("outer", "src/expression/Outer.birch", 55);
  #line 56 "src/expression/Outer.birch"
  libbirch_line_(56);
  #line 56 "src/expression/Outer.birch"
  return birch::outer(y, y, handler_);
}

#line 4 "src/expression/Pow.birch"
birch::type::Pow::Pow(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/Pow.birch"
    super_type_(y, z) {
  //
}

#line 7 "src/expression/Pow.birch"
birch::type::Real birch::type::Pow::doEvaluate(const birch::type::Real& y, const birch::type::Real& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/Pow.birch"
  libbirch_function_("doEvaluate", "src/expression/Pow.birch", 7);
  #line 8 "src/expression/Pow.birch"
  libbirch_line_(8);
  #line 8 "src/expression/Pow.birch"
  return birch::pow(y, z, handler_);
}

#line 11 "src/expression/Pow.birch"
birch::type::Real birch::type::Pow::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/Pow.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/Pow.birch", 11);
  #line 12 "src/expression/Pow.birch"
  libbirch_line_(12);
  #line 12 "src/expression/Pow.birch"
  return d * z * birch::pow(y, z - 1.0, handler_);
}

#line 15 "src/expression/Pow.birch"
birch::type::Real birch::type::Pow::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/expression/Pow.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/Pow.birch", 15);
  #line 16 "src/expression/Pow.birch"
  libbirch_line_(16);
  #line 16 "src/expression/Pow.birch"
  if (y > 0.0) {
    #line 17 "src/expression/Pow.birch"
    libbirch_line_(17);
    #line 17 "src/expression/Pow.birch"
    return d * birch::pow(y, z, handler_) * birch::log(y, handler_);
  } else {
    #line 19 "src/expression/Pow.birch"
    libbirch_line_(19);
    #line 19 "src/expression/Pow.birch"
    return 0.0;
  }
}

#line 27 "src/expression/Pow.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Pow>> birch::pow(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/expression/Pow.birch"
  libbirch_function_("pow", "src/expression/Pow.birch", 27);
  #line 28 "src/expression/Pow.birch"
  libbirch_line_(28);
  #line 28 "src/expression/Pow.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Pow>>>(y, z, handler_);
}

#line 34 "src/expression/Pow.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Pow>> birch::pow(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/expression/Pow.birch"
  libbirch_function_("pow", "src/expression/Pow.birch", 34);
  #line 35 "src/expression/Pow.birch"
  libbirch_line_(35);
  #line 35 "src/expression/Pow.birch"
  return birch::pow(birch::box(y, handler_), z, handler_);
}

#line 41 "src/expression/Pow.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Pow>> birch::pow(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const birch::type::Real& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "src/expression/Pow.birch"
  libbirch_function_("pow", "src/expression/Pow.birch", 41);
  #line 42 "src/expression/Pow.birch"
  libbirch_line_(42);
  #line 42 "src/expression/Pow.birch"
  return birch::pow(y, birch::box(z, handler_), handler_);
}

#line 4 "src/expression/Rectify.birch"
birch::type::Rectify::Rectify(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/Rectify.birch"
    super_type_(y) {
  //
}

#line 6 "src/expression/Rectify.birch"
birch::type::Real birch::type::Rectify::doEvaluate(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 6 "src/expression/Rectify.birch"
  libbirch_function_("doEvaluate", "src/expression/Rectify.birch", 6);
  #line 7 "src/expression/Rectify.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Rectify.birch"
  return birch::rectify(y, handler_);
}

#line 10 "src/expression/Rectify.birch"
birch::type::Real birch::type::Rectify::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/expression/Rectify.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Rectify.birch", 10);
  #line 11 "src/expression/Rectify.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Rectify.birch"
  if (x > 0.0) {
    #line 12 "src/expression/Rectify.birch"
    libbirch_line_(12);
    #line 12 "src/expression/Rectify.birch"
    return d;
  } else {
    #line 14 "src/expression/Rectify.birch"
    libbirch_line_(14);
    #line 14 "src/expression/Rectify.birch"
    return 0.0;
  }
}

#line 22 "src/expression/Rectify.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Rectify>> birch::rectify(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/expression/Rectify.birch"
  libbirch_function_("rectify", "src/expression/Rectify.birch", 22);
  #line 23 "src/expression/Rectify.birch"
  libbirch_line_(23);
  #line 23 "src/expression/Rectify.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Rectify>>>(y, handler_);
}

#line 4 "src/expression/Sin.birch"
birch::type::Sin::Sin(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/Sin.birch"
    super_type_(y) {
  //
}

#line 6 "src/expression/Sin.birch"
birch::type::Real birch::type::Sin::doEvaluate(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 6 "src/expression/Sin.birch"
  libbirch_function_("doEvaluate", "src/expression/Sin.birch", 6);
  #line 7 "src/expression/Sin.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Sin.birch"
  return birch::sin(y, handler_);
}

#line 10 "src/expression/Sin.birch"
birch::type::Real birch::type::Sin::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/expression/Sin.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Sin.birch", 10);
  #line 11 "src/expression/Sin.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Sin.birch"
  return d * birch::cos(y, handler_);
}

#line 18 "src/expression/Sin.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Sin>> birch::sin(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/expression/Sin.birch"
  libbirch_function_("sin", "src/expression/Sin.birch", 18);
  #line 19 "src/expression/Sin.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Sin.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Sin>>>(y, handler_);
}

#line 4 "src/expression/Sinh.birch"
birch::type::Sinh::Sinh(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/Sinh.birch"
    super_type_(y) {
  //
}

#line 6 "src/expression/Sinh.birch"
birch::type::Real birch::type::Sinh::doEvaluate(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 6 "src/expression/Sinh.birch"
  libbirch_function_("doEvaluate", "src/expression/Sinh.birch", 6);
  #line 7 "src/expression/Sinh.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Sinh.birch"
  return birch::sinh(y, handler_);
}

#line 10 "src/expression/Sinh.birch"
birch::type::Real birch::type::Sinh::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/expression/Sinh.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Sinh.birch", 10);
  #line 11 "src/expression/Sinh.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Sinh.birch"
  return d * birch::cosh(y, handler_);
}

#line 18 "src/expression/Sinh.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Sinh>> birch::sinh(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/expression/Sinh.birch"
  libbirch_function_("sinh", "src/expression/Sinh.birch", 18);
  #line 19 "src/expression/Sinh.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Sinh.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Sinh>>>(y, handler_);
}

#line 4 "src/expression/Sqrt.birch"
birch::type::Sqrt::Sqrt(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/Sqrt.birch"
    super_type_(y) {
  //
}

#line 6 "src/expression/Sqrt.birch"
birch::type::Real birch::type::Sqrt::doEvaluate(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 6 "src/expression/Sqrt.birch"
  libbirch_function_("doEvaluate", "src/expression/Sqrt.birch", 6);
  #line 7 "src/expression/Sqrt.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Sqrt.birch"
  return birch::sqrt(y, handler_);
}

#line 10 "src/expression/Sqrt.birch"
birch::type::Real birch::type::Sqrt::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/expression/Sqrt.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Sqrt.birch", 10);
  #line 11 "src/expression/Sqrt.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Sqrt.birch"
  return d * 0.5 / birch::sqrt(y, handler_);
}

#line 18 "src/expression/Sqrt.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Sqrt>> birch::sqrt(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/expression/Sqrt.birch"
  libbirch_function_("sqrt", "src/expression/Sqrt.birch", 18);
  #line 19 "src/expression/Sqrt.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Sqrt.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Sqrt>>>(x, handler_);
}

#line 4 "src/expression/Subtract.birch"
birch::type::Subtract::Subtract(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/Subtract.birch"
    super_type_(y, z) {
  //
}

#line 7 "src/expression/Subtract.birch"
birch::type::Real birch::type::Subtract::doEvaluate(const birch::type::Real& y, const birch::type::Real& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/expression/Subtract.birch"
  libbirch_function_("doEvaluate", "src/expression/Subtract.birch", 7);
  #line 8 "src/expression/Subtract.birch"
  libbirch_line_(8);
  #line 8 "src/expression/Subtract.birch"
  return y - z;
}

#line 11 "src/expression/Subtract.birch"
birch::type::Real birch::type::Subtract::doEvaluateGradLeft(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/expression/Subtract.birch"
  libbirch_function_("doEvaluateGradLeft", "src/expression/Subtract.birch", 11);
  #line 12 "src/expression/Subtract.birch"
  libbirch_line_(12);
  #line 12 "src/expression/Subtract.birch"
  return d;
}

#line 15 "src/expression/Subtract.birch"
birch::type::Real birch::type::Subtract::doEvaluateGradRight(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const birch::type::Real& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/expression/Subtract.birch"
  libbirch_function_("doEvaluateGradRight", "src/expression/Subtract.birch", 15);
  #line 16 "src/expression/Subtract.birch"
  libbirch_line_(16);
  #line 16 "src/expression/Subtract.birch"
  return -d;
}

#line 19 "src/expression/Subtract.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>>>>> birch::type::Subtract::graftLinearGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/expression/Subtract.birch"
  libbirch_function_("graftLinearGaussian", "src/expression/Subtract.birch", 19);
  #line 20 "src/expression/Subtract.birch"
  libbirch_line_(20);
  #line 20 "src/expression/Subtract.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>>>>> r;
  #line 21 "src/expression/Subtract.birch"
  libbirch_line_(21);
  #line 21 "src/expression/Subtract.birch"
  if (!this_()->hasValue(handler_)) {
    #line 22 "src/expression/Subtract.birch"
    libbirch_line_(22);
    #line 22 "src/expression/Subtract.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>> x1;
    #line 24 "src/expression/Subtract.birch"
    libbirch_line_(24);
    #line 24 "src/expression/Subtract.birch"
    if ((r = this_()->y.get()->graftLinearGaussian(handler_)).query()) {
      #line 25 "src/expression/Subtract.birch"
      libbirch_line_(25);
      #line 25 "src/expression/Subtract.birch"
      r.get()->add(-this_()->z.get(), handler_);
    } else {
      #line 26 "src/expression/Subtract.birch"
      libbirch_line_(26);
      #line 26 "src/expression/Subtract.birch"
      if ((r = this_()->z.get()->graftLinearGaussian(handler_)).query()) {
        #line 27 "src/expression/Subtract.birch"
        libbirch_line_(27);
        #line 27 "src/expression/Subtract.birch"
        r.get()->negateAndAdd(this_()->y.get(), handler_);
      } else {
        #line 28 "src/expression/Subtract.birch"
        libbirch_line_(28);
        #line 28 "src/expression/Subtract.birch"
        if ((x1 = this_()->y.get()->graftGaussian(handler_)).query()) {
          #line 29 "src/expression/Subtract.birch"
          libbirch_line_(29);
          #line 29 "src/expression/Subtract.birch"
          r = birch::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>>(birch::box(1.0, handler_), x1.get(), -this_()->z.get(), handler_);
        } else {
          #line 30 "src/expression/Subtract.birch"
          libbirch_line_(30);
          #line 30 "src/expression/Subtract.birch"
          if ((x1 = this_()->z.get()->graftGaussian(handler_)).query()) {
            #line 31 "src/expression/Subtract.birch"
            libbirch_line_(31);
            #line 31 "src/expression/Subtract.birch"
            r = birch::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>>(birch::box(-1.0, handler_), x1.get(), this_()->y.get(), handler_);
          }
        }
      }
    }
  }
  #line 34 "src/expression/Subtract.birch"
  libbirch_line_(34);
  #line 34 "src/expression/Subtract.birch"
  return r;
}

#line 37 "src/expression/Subtract.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> birch::type::Subtract::graftDotGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/expression/Subtract.birch"
  libbirch_function_("graftDotGaussian", "src/expression/Subtract.birch", 37);
  #line 38 "src/expression/Subtract.birch"
  libbirch_line_(38);
  #line 38 "src/expression/Subtract.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> r;
  #line 39 "src/expression/Subtract.birch"
  libbirch_line_(39);
  #line 39 "src/expression/Subtract.birch"
  if (!this_()->hasValue(handler_)) {
    #line 40 "src/expression/Subtract.birch"
    libbirch_line_(40);
    #line 40 "src/expression/Subtract.birch"
    if ((r = this_()->y.get()->graftDotGaussian(handler_)).query()) {
      #line 41 "src/expression/Subtract.birch"
      libbirch_line_(41);
      #line 41 "src/expression/Subtract.birch"
      r.get()->add(-this_()->z.get(), handler_);
    } else {
      #line 42 "src/expression/Subtract.birch"
      libbirch_line_(42);
      #line 42 "src/expression/Subtract.birch"
      if ((r = this_()->z.get()->graftDotGaussian(handler_)).query()) {
        #line 43 "src/expression/Subtract.birch"
        libbirch_line_(43);
        #line 43 "src/expression/Subtract.birch"
        r.get()->negateAndAdd(this_()->y.get(), handler_);
      }
    }
  }
  #line 46 "src/expression/Subtract.birch"
  libbirch_line_(46);
  #line 46 "src/expression/Subtract.birch"
  return r;
}

#line 49 "src/expression/Subtract.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>>>>> birch::type::Subtract::graftLinearNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/expression/Subtract.birch"
  libbirch_function_("graftLinearNormalInverseGamma", "src/expression/Subtract.birch", 49);
  #line 51 "src/expression/Subtract.birch"
  libbirch_line_(51);
  #line 51 "src/expression/Subtract.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>>>>> r;
  #line 52 "src/expression/Subtract.birch"
  libbirch_line_(52);
  #line 52 "src/expression/Subtract.birch"
  if (!this_()->hasValue(handler_)) {
    #line 53 "src/expression/Subtract.birch"
    libbirch_line_(53);
    #line 53 "src/expression/Subtract.birch"
    libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>> x1;
    #line 55 "src/expression/Subtract.birch"
    libbirch_line_(55);
    #line 55 "src/expression/Subtract.birch"
    if ((r = this_()->y.get()->graftLinearNormalInverseGamma(compare, handler_)).query()) {
      #line 56 "src/expression/Subtract.birch"
      libbirch_line_(56);
      #line 56 "src/expression/Subtract.birch"
      r.get()->subtract(this_()->z.get(), handler_);
    } else {
      #line 57 "src/expression/Subtract.birch"
      libbirch_line_(57);
      #line 57 "src/expression/Subtract.birch"
      if ((r = this_()->z.get()->graftLinearNormalInverseGamma(compare, handler_)).query()) {
        #line 58 "src/expression/Subtract.birch"
        libbirch_line_(58);
        #line 58 "src/expression/Subtract.birch"
        r.get()->negateAndAdd(this_()->y.get(), handler_);
      } else {
        #line 59 "src/expression/Subtract.birch"
        libbirch_line_(59);
        #line 59 "src/expression/Subtract.birch"
        if ((x1 = this_()->y.get()->graftNormalInverseGamma(compare, handler_)).query()) {
          #line 60 "src/expression/Subtract.birch"
          libbirch_line_(60);
          #line 60 "src/expression/Subtract.birch"
          r = birch::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>>(birch::box(1.0, handler_), x1.get(), -this_()->z.get(), handler_);
        } else {
          #line 61 "src/expression/Subtract.birch"
          libbirch_line_(61);
          #line 61 "src/expression/Subtract.birch"
          if ((x1 = this_()->z.get()->graftNormalInverseGamma(compare, handler_)).query()) {
            #line 62 "src/expression/Subtract.birch"
            libbirch_line_(62);
            #line 62 "src/expression/Subtract.birch"
            r = birch::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>>(birch::box(-1.0, handler_), x1.get(), this_()->y.get(), handler_);
          }
        }
      }
    }
  }
  #line 65 "src/expression/Subtract.birch"
  libbirch_line_(65);
  #line 65 "src/expression/Subtract.birch"
  return r;
}

#line 68 "src/expression/Subtract.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> birch::type::Subtract::graftDotNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 68 "src/expression/Subtract.birch"
  libbirch_function_("graftDotNormalInverseGamma", "src/expression/Subtract.birch", 68);
  #line 70 "src/expression/Subtract.birch"
  libbirch_line_(70);
  #line 70 "src/expression/Subtract.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> r;
  #line 71 "src/expression/Subtract.birch"
  libbirch_line_(71);
  #line 71 "src/expression/Subtract.birch"
  if (!this_()->hasValue(handler_)) {
    #line 72 "src/expression/Subtract.birch"
    libbirch_line_(72);
    #line 72 "src/expression/Subtract.birch"
    if ((r = this_()->y.get()->graftDotNormalInverseGamma(compare, handler_)).query()) {
      #line 73 "src/expression/Subtract.birch"
      libbirch_line_(73);
      #line 73 "src/expression/Subtract.birch"
      r.get()->subtract(this_()->z.get(), handler_);
    } else {
      #line 74 "src/expression/Subtract.birch"
      libbirch_line_(74);
      #line 74 "src/expression/Subtract.birch"
      if ((r = this_()->z.get()->graftDotNormalInverseGamma(compare, handler_)).query()) {
        #line 75 "src/expression/Subtract.birch"
        libbirch_line_(75);
        #line 75 "src/expression/Subtract.birch"
        r.get()->negateAndAdd(this_()->y.get(), handler_);
      }
    }
  }
  #line 78 "src/expression/Subtract.birch"
  libbirch_line_(78);
  #line 78 "src/expression/Subtract.birch"
  return r;
}

#line 85 "src/expression/Subtract.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Subtract>> birch::operator-(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z) {
  #line 85 "src/expression/Subtract.birch"
  libbirch_function_("-", "src/expression/Subtract.birch", 85);
  #line 86 "src/expression/Subtract.birch"
  libbirch_line_(86);
  #line 86 "src/expression/Subtract.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Subtract>>>(y, z);
}

#line 92 "src/expression/Subtract.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Subtract>> birch::operator-(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z) {
  #line 92 "src/expression/Subtract.birch"
  libbirch_function_("-", "src/expression/Subtract.birch", 92);
  #line 93 "src/expression/Subtract.birch"
  libbirch_line_(93);
  #line 93 "src/expression/Subtract.birch"
  return birch::box(y) - z;
}

#line 99 "src/expression/Subtract.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Subtract>> birch::operator-(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const birch::type::Real& z) {
  #line 99 "src/expression/Subtract.birch"
  libbirch_function_("-", "src/expression/Subtract.birch", 99);
  #line 100 "src/expression/Subtract.birch"
  libbirch_line_(100);
  #line 100 "src/expression/Subtract.birch"
  return y - birch::box(z);
}

#line 4 "src/expression/Tan.birch"
birch::type::Tan::Tan(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/Tan.birch"
    super_type_(y) {
  //
}

#line 6 "src/expression/Tan.birch"
birch::type::Real birch::type::Tan::doEvaluate(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 6 "src/expression/Tan.birch"
  libbirch_function_("doEvaluate", "src/expression/Tan.birch", 6);
  #line 7 "src/expression/Tan.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Tan.birch"
  return birch::tan(y, handler_);
}

#line 10 "src/expression/Tan.birch"
birch::type::Real birch::type::Tan::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/expression/Tan.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Tan.birch", 10);
  #line 11 "src/expression/Tan.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Tan.birch"
  return d * (1.0 + birch::pow(birch::tan(y, handler_), 2.0, handler_));
}

#line 18 "src/expression/Tan.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Tan>> birch::tan(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/expression/Tan.birch"
  libbirch_function_("tan", "src/expression/Tan.birch", 18);
  #line 19 "src/expression/Tan.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Tan.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Tan>>>(y, handler_);
}

#line 4 "src/expression/Tanh.birch"
birch::type::Tanh::Tanh(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/expression/Tanh.birch"
    super_type_(y) {
  //
}

#line 6 "src/expression/Tanh.birch"
birch::type::Real birch::type::Tanh::doEvaluate(const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 6 "src/expression/Tanh.birch"
  libbirch_function_("doEvaluate", "src/expression/Tanh.birch", 6);
  #line 7 "src/expression/Tanh.birch"
  libbirch_line_(7);
  #line 7 "src/expression/Tanh.birch"
  return birch::tanh(y, handler_);
}

#line 10 "src/expression/Tanh.birch"
birch::type::Real birch::type::Tanh::doEvaluateGrad(const birch::type::Real& d, const birch::type::Real& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/expression/Tanh.birch"
  libbirch_function_("doEvaluateGrad", "src/expression/Tanh.birch", 10);
  #line 11 "src/expression/Tanh.birch"
  libbirch_line_(11);
  #line 11 "src/expression/Tanh.birch"
  return d * (1.0 + birch::pow(birch::tanh(y, handler_), 2.0, handler_));
}

#line 18 "src/expression/Tanh.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Tanh>> birch::tanh(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/expression/Tanh.birch"
  libbirch_function_("tanh", "src/expression/Tanh.birch", 18);
  #line 19 "src/expression/Tanh.birch"
  libbirch_line_(19);
  #line 19 "src/expression/Tanh.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Tanh>>>(x, handler_);
}

#line 19 "src/expression/Trace.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Trace<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, birch::type::LLT>>> birch::trace(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/expression/Trace.birch"
  libbirch_function_("trace", "src/expression/Trace.birch", 19);
  #line 20 "src/expression/Trace.birch"
  libbirch_line_(20);
  #line 20 "src/expression/Trace.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Trace<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, birch::type::LLT>>>>(y, handler_);
}

#line 26 "src/expression/Trace.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Trace<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::DefaultArray<birch::type::Real,2>>>> birch::trace(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/expression/Trace.birch"
  libbirch_function_("trace", "src/expression/Trace.birch", 26);
  #line 28 "src/expression/Trace.birch"
  libbirch_line_(28);
  #line 28 "src/expression/Trace.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Trace<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::DefaultArray<birch::type::Real,2>>>>>(y, handler_);
}

