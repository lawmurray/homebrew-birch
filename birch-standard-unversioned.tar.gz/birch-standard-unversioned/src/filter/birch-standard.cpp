#line 1 "src/filter/AliveParticleFilter.birch"
birch::type::AliveParticleFilter::AliveParticleFilter() :
    #line 1 "src/filter/AliveParticleFilter.birch"
    base_type_(),
    #line 23 "src/filter/AliveParticleFilter.birch"
    p(libbirch::make<libbirch::DefaultArray<birch::type::Integer,1>>()) {
  //
}

#line 25 "src/filter/AliveParticleFilter.birch"
void birch::type::AliveParticleFilter::simulate(const birch::type::Integer& t, const libbirch::Shared<birch::type::Buffer>& input) {
  #line 25 "src/filter/AliveParticleFilter.birch"
  libbirch_function_("simulate", "src/filter/AliveParticleFilter.birch", 25);
  #line 26 "src/filter/AliveParticleFilter.birch"
  libbirch_line_(26);
  #line 26 "src/filter/AliveParticleFilter.birch"
  this->a = birch::resample_systematic(this->w);
  #line 27 "src/filter/AliveParticleFilter.birch"
  libbirch_line_(27);
  #line 27 "src/filter/AliveParticleFilter.birch"
  this->p = birch::vector(birch::type::Integer(0), this->nparticles);
  #line 29 "src/filter/AliveParticleFilter.birch"
  libbirch_line_(29);
  #line 29 "src/filter/AliveParticleFilter.birch"
  auto x0 = this->x;
  #line 30 "src/filter/AliveParticleFilter.birch"
  libbirch_line_(30);
  #line 30 "src/filter/AliveParticleFilter.birch"
  auto w0 = this->w;
  #line 31 "src/filter/AliveParticleFilter.birch"
  libbirch_line_(31);
  #line 31 "src/filter/AliveParticleFilter.birch"
  #pragma omp parallel
  {
    #line 31 "src/filter/AliveParticleFilter.birch"
    libbirch_function_("<parallel for>", "src/filter/AliveParticleFilter.birch", 31);
    #pragma omp for schedule(static)
    for (auto n = birch::type::Integer(1); n <= this->nparticles; ++n) {
      #line 32 "src/filter/AliveParticleFilter.birch"
      libbirch_line_(32);
      #line 32 "src/filter/AliveParticleFilter.birch"
      do {
        #line 33 "src/filter/AliveParticleFilter.birch"
        libbirch_line_(33);
        #line 33 "src/filter/AliveParticleFilter.birch"
        this->x(n) = birch::copy(x0(this->a(n)));
        #line 34 "src/filter/AliveParticleFilter.birch"
        libbirch_line_(34);
        #line 34 "src/filter/AliveParticleFilter.birch"
        this->p(n) = this->p(n) + birch::type::Integer(1);
        #line 35 "src/filter/AliveParticleFilter.birch"
        libbirch_line_(35);
        #line 35 "src/filter/AliveParticleFilter.birch"
        auto handler = birch::PlayHandler(this->delayed);
        #line 36 "src/filter/AliveParticleFilter.birch"
        libbirch_line_(36);
        #line 36 "src/filter/AliveParticleFilter.birch"
        {
          auto handler_ = birch::swap_handler((handler));
          #line 37 "src/filter/AliveParticleFilter.birch"
          libbirch_line_(37);
          #line 37 "src/filter/AliveParticleFilter.birch"
          this->x(n)->m->read(t, input);
          #line 38 "src/filter/AliveParticleFilter.birch"
          libbirch_line_(38);
          #line 38 "src/filter/AliveParticleFilter.birch"
          this->x(n)->m->simulate(t);
          #line 39 "src/filter/AliveParticleFilter.birch"
          libbirch_line_(39);
          #line 39 "src/filter/AliveParticleFilter.birch"
          this->w(n) = handler->w;
          birch::set_handler(handler_);
        }
        #line 41 "src/filter/AliveParticleFilter.birch"
        libbirch_line_(41);
        #line 41 "src/filter/AliveParticleFilter.birch"
        if (this->w(n) == -(birch::inf())) {
          #line 42 "src/filter/AliveParticleFilter.birch"
          libbirch_line_(42);
          #line 42 "src/filter/AliveParticleFilter.birch"
          this->a(n) = birch::ancestor(w0);
        }
      } while (this->w(n) == -(birch::inf()));
    }
  }
  #line 46 "src/filter/AliveParticleFilter.birch"
  libbirch_line_(46);
  #line 46 "src/filter/AliveParticleFilter.birch"
  birch::collect();
  #line 50 "src/filter/AliveParticleFilter.birch"
  libbirch_line_(50);
  #line 50 "src/filter/AliveParticleFilter.birch"
  this->w(birch::simulate_uniform_int(birch::type::Integer(1), this->nparticles)) = -(birch::inf());
}

#line 53 "src/filter/AliveParticleFilter.birch"
void birch::type::AliveParticleFilter::resample() {
  #line 53 "src/filter/AliveParticleFilter.birch"
  libbirch_function_("resample", "src/filter/AliveParticleFilter.birch", 53);
  #line 56 "src/filter/AliveParticleFilter.birch"
  libbirch_line_(56);
  #line 56 "src/filter/AliveParticleFilter.birch"
  this->a = birch::iota(birch::type::Integer(1), this->nparticles);
  #line 57 "src/filter/AliveParticleFilter.birch"
  libbirch_line_(57);
  #line 57 "src/filter/AliveParticleFilter.birch"
  this->w = this->w - birch::vector(this->lsum - birch::log(birch::Real(this->nparticles)), this->nparticles);
}

#line 60 "src/filter/AliveParticleFilter.birch"
void birch::type::AliveParticleFilter::reduce() {
  #line 60 "src/filter/AliveParticleFilter.birch"
  libbirch_function_("reduce", "src/filter/AliveParticleFilter.birch", 60);
  #line 61 "src/filter/AliveParticleFilter.birch"
  libbirch_line_(61);
  #line 61 "src/filter/AliveParticleFilter.birch"
  this->base_type_::reduce();
  #line 62 "src/filter/AliveParticleFilter.birch"
  libbirch_line_(62);
  #line 62 "src/filter/AliveParticleFilter.birch"
  this->npropagations = birch::sum(this->p);
}

#line 1 "src/filter/AliveParticleFilter.birch"
birch::type::AliveParticleFilter* birch::type::make_AliveParticleFilter_() {
  #line 1 "src/filter/AliveParticleFilter.birch"
  return new birch::type::AliveParticleFilter();
  #line 1 "src/filter/AliveParticleFilter.birch"
}

#line 1 "src/filter/ConditionalParticleFilter.birch"
birch::type::ConditionalParticleFilter::ConditionalParticleFilter() :
    #line 1 "src/filter/ConditionalParticleFilter.birch"
    base_type_(),
    #line 22 "src/filter/ConditionalParticleFilter.birch"
    r(libbirch::make<std::optional<libbirch::Shared<birch::type::Tape<libbirch::Shared<birch::type::Record>>>>>()) {
  //
}

#line 24 "src/filter/ConditionalParticleFilter.birch"
libbirch::Shared<birch::type::Particle> birch::type::ConditionalParticleFilter::particle(const libbirch::Shared<birch::type::Model>& model) {
  #line 24 "src/filter/ConditionalParticleFilter.birch"
  libbirch_function_("particle", "src/filter/ConditionalParticleFilter.birch", 24);
  #line 25 "src/filter/ConditionalParticleFilter.birch"
  libbirch_line_(25);
  #line 25 "src/filter/ConditionalParticleFilter.birch"
  return birch::ConditionalParticle(model);
}

#line 28 "src/filter/ConditionalParticleFilter.birch"
void birch::type::ConditionalParticleFilter::simulate(const libbirch::Shared<birch::type::Buffer>& input) {
  #line 28 "src/filter/ConditionalParticleFilter.birch"
  libbirch_function_("simulate", "src/filter/ConditionalParticleFilter.birch", 28);
  #line 29 "src/filter/ConditionalParticleFilter.birch"
  libbirch_line_(29);
  #line 29 "src/filter/ConditionalParticleFilter.birch"
  #pragma omp parallel
  {
    #line 29 "src/filter/ConditionalParticleFilter.birch"
    libbirch_function_("<parallel for>", "src/filter/ConditionalParticleFilter.birch", 29);
    #pragma omp for schedule(static)
    for (auto n = birch::type::Integer(1); n <= this->nparticles; ++n) {
      #line 30 "src/filter/ConditionalParticleFilter.birch"
      libbirch_line_(30);
      #line 30 "src/filter/ConditionalParticleFilter.birch"
      auto x = libbirch::cast<libbirch::Shared<birch::type::ConditionalParticle>>(this->x(n)).value();
      #line 31 "src/filter/ConditionalParticleFilter.birch"
      libbirch_line_(31);
      #line 31 "src/filter/ConditionalParticleFilter.birch"
      auto handler = birch::PlayHandler(this->delayed);
      #line 32 "src/filter/ConditionalParticleFilter.birch"
      libbirch_line_(32);
      #line 32 "src/filter/ConditionalParticleFilter.birch"
      if (this->r.has_value() && n == this->b) {
        #line 33 "src/filter/ConditionalParticleFilter.birch"
        libbirch_line_(33);
        #line 33 "src/filter/ConditionalParticleFilter.birch"
        handler->input = this->r.value();
      }
      #line 35 "src/filter/ConditionalParticleFilter.birch"
      libbirch_line_(35);
      #line 35 "src/filter/ConditionalParticleFilter.birch"
      handler->output = x->trace;
      #line 36 "src/filter/ConditionalParticleFilter.birch"
      libbirch_line_(36);
      #line 36 "src/filter/ConditionalParticleFilter.birch"
      {
        auto handler_ = birch::swap_handler((handler));
        #line 37 "src/filter/ConditionalParticleFilter.birch"
        libbirch_line_(37);
        #line 37 "src/filter/ConditionalParticleFilter.birch"
        x->m->read(input);
        #line 38 "src/filter/ConditionalParticleFilter.birch"
        libbirch_line_(38);
        #line 38 "src/filter/ConditionalParticleFilter.birch"
        x->m->simulate();
        birch::set_handler(handler_);
      }
      #line 40 "src/filter/ConditionalParticleFilter.birch"
      libbirch_line_(40);
      #line 40 "src/filter/ConditionalParticleFilter.birch"
      this->w(n) = handler->w;
    }
  }
}

#line 44 "src/filter/ConditionalParticleFilter.birch"
void birch::type::ConditionalParticleFilter::simulate(const birch::type::Integer& t, const libbirch::Shared<birch::type::Buffer>& input) {
  #line 44 "src/filter/ConditionalParticleFilter.birch"
  libbirch_function_("simulate", "src/filter/ConditionalParticleFilter.birch", 44);
  #line 45 "src/filter/ConditionalParticleFilter.birch"
  libbirch_line_(45);
  #line 45 "src/filter/ConditionalParticleFilter.birch"
  #pragma omp parallel
  {
    #line 45 "src/filter/ConditionalParticleFilter.birch"
    libbirch_function_("<parallel for>", "src/filter/ConditionalParticleFilter.birch", 45);
    #pragma omp for schedule(static)
    for (auto n = birch::type::Integer(1); n <= this->nparticles; ++n) {
      #line 46 "src/filter/ConditionalParticleFilter.birch"
      libbirch_line_(46);
      #line 46 "src/filter/ConditionalParticleFilter.birch"
      auto x = libbirch::cast<libbirch::Shared<birch::type::ConditionalParticle>>(this->x(n)).value();
      #line 47 "src/filter/ConditionalParticleFilter.birch"
      libbirch_line_(47);
      #line 47 "src/filter/ConditionalParticleFilter.birch"
      auto handler = birch::PlayHandler(this->delayed);
      #line 48 "src/filter/ConditionalParticleFilter.birch"
      libbirch_line_(48);
      #line 48 "src/filter/ConditionalParticleFilter.birch"
      if (this->r.has_value() && n == this->b) {
        #line 49 "src/filter/ConditionalParticleFilter.birch"
        libbirch_line_(49);
        #line 49 "src/filter/ConditionalParticleFilter.birch"
        handler->input = this->r.value();
      }
      #line 51 "src/filter/ConditionalParticleFilter.birch"
      libbirch_line_(51);
      #line 51 "src/filter/ConditionalParticleFilter.birch"
      handler->output = x->trace;
      #line 52 "src/filter/ConditionalParticleFilter.birch"
      libbirch_line_(52);
      #line 52 "src/filter/ConditionalParticleFilter.birch"
      {
        auto handler_ = birch::swap_handler((handler));
        #line 53 "src/filter/ConditionalParticleFilter.birch"
        libbirch_line_(53);
        #line 53 "src/filter/ConditionalParticleFilter.birch"
        x->m->read(t, input);
        #line 54 "src/filter/ConditionalParticleFilter.birch"
        libbirch_line_(54);
        #line 54 "src/filter/ConditionalParticleFilter.birch"
        x->m->simulate(t);
        birch::set_handler(handler_);
      }
      #line 56 "src/filter/ConditionalParticleFilter.birch"
      libbirch_line_(56);
      #line 56 "src/filter/ConditionalParticleFilter.birch"
      this->w(n) = this->w(n) + handler->w;
    }
  }
}

#line 61 "src/filter/ConditionalParticleFilter.birch"
void birch::type::ConditionalParticleFilter::resample() {
  #line 61 "src/filter/ConditionalParticleFilter.birch"
  libbirch_function_("resample", "src/filter/ConditionalParticleFilter.birch", 61);
  #line 62 "src/filter/ConditionalParticleFilter.birch"
  libbirch_line_(62);
  #line 62 "src/filter/ConditionalParticleFilter.birch"
  if (this->ess <= this->trigger * this->nparticles) {
    #line 63 "src/filter/ConditionalParticleFilter.birch"
    libbirch_line_(63);
    #line 63 "src/filter/ConditionalParticleFilter.birch"
    if (this->r.has_value()) {
      #line 64 "src/filter/ConditionalParticleFilter.birch"
      libbirch_line_(64);
      #line 64 "src/filter/ConditionalParticleFilter.birch"
      std::tie(this->a, this->b) = birch::conditional_resample_multinomial(this->w, this->b);
    } else {
      #line 66 "src/filter/ConditionalParticleFilter.birch"
      libbirch_line_(66);
      #line 66 "src/filter/ConditionalParticleFilter.birch"
      this->a = birch::resample_multinomial(this->w);
    }
    #line 68 "src/filter/ConditionalParticleFilter.birch"
    libbirch_line_(68);
    #line 68 "src/filter/ConditionalParticleFilter.birch"
    this->w = birch::vector(0.0, this->nparticles);
    #line 69 "src/filter/ConditionalParticleFilter.birch"
    libbirch_line_(69);
    #line 69 "src/filter/ConditionalParticleFilter.birch"
    this->copy();
    #line 70 "src/filter/ConditionalParticleFilter.birch"
    libbirch_line_(70);
    #line 70 "src/filter/ConditionalParticleFilter.birch"
    birch::collect();
  } else {
    #line 73 "src/filter/ConditionalParticleFilter.birch"
    libbirch_line_(73);
    #line 73 "src/filter/ConditionalParticleFilter.birch"
    this->w = this->w - birch::vector(this->lsum - birch::log(birch::Real(this->nparticles)), this->nparticles);
  }
}

#line 1 "src/filter/ConditionalParticleFilter.birch"
birch::type::ConditionalParticleFilter* birch::type::make_ConditionalParticleFilter_() {
  #line 1 "src/filter/ConditionalParticleFilter.birch"
  return new birch::type::ConditionalParticleFilter();
  #line 1 "src/filter/ConditionalParticleFilter.birch"
}

#line 1 "src/filter/MoveParticleFilter.birch"
birch::type::MoveParticleFilter::MoveParticleFilter() :
    #line 1 "src/filter/MoveParticleFilter.birch"
    base_type_(),
    #line 19 "src/filter/MoveParticleFilter.birch"
    naccepts(libbirch::make<libbirch::DefaultArray<birch::type::Integer,1>>()),
    #line 24 "src/filter/MoveParticleFilter.birch"
    scale(0.1),
    #line 29 "src/filter/MoveParticleFilter.birch"
    nmoves(birch::type::Integer(1)),
    #line 34 "src/filter/MoveParticleFilter.birch"
    nlags(birch::type::Integer(1)) {
  //
}

#line 36 "src/filter/MoveParticleFilter.birch"
libbirch::Shared<birch::type::Particle> birch::type::MoveParticleFilter::particle(const libbirch::Shared<birch::type::Model>& model) {
  #line 36 "src/filter/MoveParticleFilter.birch"
  libbirch_function_("particle", "src/filter/MoveParticleFilter.birch", 36);
  #line 37 "src/filter/MoveParticleFilter.birch"
  libbirch_line_(37);
  #line 37 "src/filter/MoveParticleFilter.birch"
  return birch::MoveParticle(model);
}

#line 40 "src/filter/MoveParticleFilter.birch"
void birch::type::MoveParticleFilter::filter(const birch::type::Integer& t, const libbirch::Shared<birch::type::Buffer>& input) {
  #line 40 "src/filter/MoveParticleFilter.birch"
  libbirch_function_("filter", "src/filter/MoveParticleFilter.birch", 40);
  #line 41 "src/filter/MoveParticleFilter.birch"
  libbirch_line_(41);
  #line 41 "src/filter/MoveParticleFilter.birch"
  this->resample();
  #line 42 "src/filter/MoveParticleFilter.birch"
  libbirch_line_(42);
  #line 42 "src/filter/MoveParticleFilter.birch"
  this->move(t);
  #line 43 "src/filter/MoveParticleFilter.birch"
  libbirch_line_(43);
  #line 43 "src/filter/MoveParticleFilter.birch"
  this->simulate(t, input);
  #line 44 "src/filter/MoveParticleFilter.birch"
  libbirch_line_(44);
  #line 44 "src/filter/MoveParticleFilter.birch"
  this->reduce();
}

#line 47 "src/filter/MoveParticleFilter.birch"
void birch::type::MoveParticleFilter::simulate(const libbirch::Shared<birch::type::Buffer>& input) {
  #line 47 "src/filter/MoveParticleFilter.birch"
  libbirch_function_("simulate", "src/filter/MoveParticleFilter.birch", 47);
  #line 48 "src/filter/MoveParticleFilter.birch"
  libbirch_line_(48);
  #line 48 "src/filter/MoveParticleFilter.birch"
  #pragma omp parallel
  {
    #line 48 "src/filter/MoveParticleFilter.birch"
    libbirch_function_("<parallel for>", "src/filter/MoveParticleFilter.birch", 48);
    #pragma omp for schedule(static)
    for (auto n = birch::type::Integer(1); n <= this->nparticles; ++n) {
      #line 49 "src/filter/MoveParticleFilter.birch"
      libbirch_line_(49);
      #line 49 "src/filter/MoveParticleFilter.birch"
      auto x = libbirch::cast<libbirch::Shared<birch::type::MoveParticle>>(this->x(n)).value();
      #line 50 "src/filter/MoveParticleFilter.birch"
      libbirch_line_(50);
      #line 50 "src/filter/MoveParticleFilter.birch"
      auto handler = birch::MoveHandler(this->delayed);
      #line 51 "src/filter/MoveParticleFilter.birch"
      libbirch_line_(51);
      #line 51 "src/filter/MoveParticleFilter.birch"
      {
        auto handler_ = birch::swap_handler((handler));
        #line 52 "src/filter/MoveParticleFilter.birch"
        libbirch_line_(52);
        #line 52 "src/filter/MoveParticleFilter.birch"
        x->m->read(input);
        #line 53 "src/filter/MoveParticleFilter.birch"
        libbirch_line_(53);
        #line 53 "src/filter/MoveParticleFilter.birch"
        x->m->simulate();
        #line 54 "src/filter/MoveParticleFilter.birch"
        libbirch_line_(54);
        #line 54 "src/filter/MoveParticleFilter.birch"
        this->w(n) = this->w(n) + handler->w;
        birch::set_handler(handler_);
      }
      #line 56 "src/filter/MoveParticleFilter.birch"
      libbirch_line_(56);
      #line 56 "src/filter/MoveParticleFilter.birch"
      this->w(n) = this->w(n) + x->augment(birch::type::Integer(0), handler->z);
      #line 57 "src/filter/MoveParticleFilter.birch"
      libbirch_line_(57);
      #line 57 "src/filter/MoveParticleFilter.birch"
      while (x->size() > this->nlags) {
        #line 58 "src/filter/MoveParticleFilter.birch"
        libbirch_line_(58);
        #line 58 "src/filter/MoveParticleFilter.birch"
        x->truncate();
      }
    }
  }
}

#line 63 "src/filter/MoveParticleFilter.birch"
void birch::type::MoveParticleFilter::simulate(const birch::type::Integer& t, const libbirch::Shared<birch::type::Buffer>& input) {
  #line 63 "src/filter/MoveParticleFilter.birch"
  libbirch_function_("simulate", "src/filter/MoveParticleFilter.birch", 63);
  #line 64 "src/filter/MoveParticleFilter.birch"
  libbirch_line_(64);
  #line 64 "src/filter/MoveParticleFilter.birch"
  #pragma omp parallel
  {
    #line 64 "src/filter/MoveParticleFilter.birch"
    libbirch_function_("<parallel for>", "src/filter/MoveParticleFilter.birch", 64);
    #pragma omp for schedule(static)
    for (auto n = birch::type::Integer(1); n <= this->nparticles; ++n) {
      #line 65 "src/filter/MoveParticleFilter.birch"
      libbirch_line_(65);
      #line 65 "src/filter/MoveParticleFilter.birch"
      auto x = libbirch::cast<libbirch::Shared<birch::type::MoveParticle>>(this->x(n)).value();
      #line 66 "src/filter/MoveParticleFilter.birch"
      libbirch_line_(66);
      #line 66 "src/filter/MoveParticleFilter.birch"
      auto handler = birch::MoveHandler(this->delayed);
      #line 67 "src/filter/MoveParticleFilter.birch"
      libbirch_line_(67);
      #line 67 "src/filter/MoveParticleFilter.birch"
      {
        auto handler_ = birch::swap_handler((handler));
        #line 68 "src/filter/MoveParticleFilter.birch"
        libbirch_line_(68);
        #line 68 "src/filter/MoveParticleFilter.birch"
        x->m->read(t, input);
        #line 69 "src/filter/MoveParticleFilter.birch"
        libbirch_line_(69);
        #line 69 "src/filter/MoveParticleFilter.birch"
        x->m->simulate(t);
        #line 70 "src/filter/MoveParticleFilter.birch"
        libbirch_line_(70);
        #line 70 "src/filter/MoveParticleFilter.birch"
        this->w(n) = this->w(n) + handler->w;
        birch::set_handler(handler_);
      }
      #line 72 "src/filter/MoveParticleFilter.birch"
      libbirch_line_(72);
      #line 72 "src/filter/MoveParticleFilter.birch"
      this->w(n) = this->w(n) + x->augment(t, handler->z);
      #line 73 "src/filter/MoveParticleFilter.birch"
      libbirch_line_(73);
      #line 73 "src/filter/MoveParticleFilter.birch"
      while (x->size() > this->nlags) {
        #line 74 "src/filter/MoveParticleFilter.birch"
        libbirch_line_(74);
        #line 74 "src/filter/MoveParticleFilter.birch"
        x->truncate();
      }
    }
  }
}

#line 79 "src/filter/MoveParticleFilter.birch"
void birch::type::MoveParticleFilter::move(const birch::type::Integer& t) {
  #line 79 "src/filter/MoveParticleFilter.birch"
  libbirch_function_("move", "src/filter/MoveParticleFilter.birch", 79);
  #line 80 "src/filter/MoveParticleFilter.birch"
  libbirch_line_(80);
  #line 80 "src/filter/MoveParticleFilter.birch"
  this->naccepts = birch::vector(birch::type::Integer(0), this->nparticles);
  #line 81 "src/filter/MoveParticleFilter.birch"
  libbirch_line_(81);
  #line 81 "src/filter/MoveParticleFilter.birch"
  if (this->ess <= this->trigger * this->nparticles && this->nlags > birch::type::Integer(0) && this->nmoves > birch::type::Integer(0)) {
    #line 82 "src/filter/MoveParticleFilter.birch"
    libbirch_line_(82);
    #line 82 "src/filter/MoveParticleFilter.birch"
    libbirch::Shared<birch::type::LangevinKernel> _u0954 = libbirch::make<libbirch::Shared<birch::type::LangevinKernel>>();
    #line 83 "src/filter/MoveParticleFilter.birch"
    libbirch_line_(83);
    #line 83 "src/filter/MoveParticleFilter.birch"
    _u0954->scale = this->scale / birch::pow(birch::min(t, this->nlags), birch::type::Integer(3));
    #line 84 "src/filter/MoveParticleFilter.birch"
    libbirch_line_(84);
    #line 84 "src/filter/MoveParticleFilter.birch"
    #pragma omp parallel
    {
      #line 84 "src/filter/MoveParticleFilter.birch"
      libbirch_function_("<parallel for>", "src/filter/MoveParticleFilter.birch", 84);
      #pragma omp for schedule(static)
      for (auto n = birch::type::Integer(1); n <= this->nparticles; ++n) {
        #line 85 "src/filter/MoveParticleFilter.birch"
        libbirch_line_(85);
        #line 85 "src/filter/MoveParticleFilter.birch"
        auto x = libbirch::cast<libbirch::Shared<birch::type::MoveParticle>>(birch::copy(this->x(n))).value();
        #line 86 "src/filter/MoveParticleFilter.birch"
        libbirch_line_(86);
        #line 86 "src/filter/MoveParticleFilter.birch"
        x->grad(t - this->nlags);
        #line 87 "src/filter/MoveParticleFilter.birch"
        libbirch_line_(87);
        #line 87 "src/filter/MoveParticleFilter.birch"
        for (auto m = birch::type::Integer(1); m <= this->nmoves; ++m) {
          #line 88 "src/filter/MoveParticleFilter.birch"
          libbirch_line_(88);
          #line 88 "src/filter/MoveParticleFilter.birch"
          auto x_prime_ = birch::copy(x);
          #line 89 "src/filter/MoveParticleFilter.birch"
          libbirch_line_(89);
          #line 89 "src/filter/MoveParticleFilter.birch"
          x_prime_->move(t - this->nlags, _u0954);
          #line 90 "src/filter/MoveParticleFilter.birch"
          libbirch_line_(90);
          #line 90 "src/filter/MoveParticleFilter.birch"
          x_prime_->grad(t - this->nlags);
          #line 91 "src/filter/MoveParticleFilter.birch"
          libbirch_line_(91);
          #line 91 "src/filter/MoveParticleFilter.birch"
          auto _u0945 = x_prime_->_u0960 - x->_u0960 + x_prime_->compare(t - this->nlags, x, _u0954);
          #line 92 "src/filter/MoveParticleFilter.birch"
          libbirch_line_(92);
          #line 92 "src/filter/MoveParticleFilter.birch"
          if (birch::log(birch::simulate_uniform(0.0, 1.0)) <= _u0945) {
            #line 93 "src/filter/MoveParticleFilter.birch"
            libbirch_line_(93);
            #line 93 "src/filter/MoveParticleFilter.birch"
            x = x_prime_;
            #line 94 "src/filter/MoveParticleFilter.birch"
            libbirch_line_(94);
            #line 94 "src/filter/MoveParticleFilter.birch"
            this->naccepts(n) = this->naccepts(n) + birch::type::Integer(1);
          }
        }
        #line 97 "src/filter/MoveParticleFilter.birch"
        libbirch_line_(97);
        #line 97 "src/filter/MoveParticleFilter.birch"
        this->x(n) = x;
      }
    }
    #line 99 "src/filter/MoveParticleFilter.birch"
    libbirch_line_(99);
    #line 99 "src/filter/MoveParticleFilter.birch"
    birch::collect();
  }
}

#line 103 "src/filter/MoveParticleFilter.birch"
void birch::type::MoveParticleFilter::reduce() {
  #line 103 "src/filter/MoveParticleFilter.birch"
  libbirch_function_("reduce", "src/filter/MoveParticleFilter.birch", 103);
  #line 104 "src/filter/MoveParticleFilter.birch"
  libbirch_line_(104);
  #line 104 "src/filter/MoveParticleFilter.birch"
  this->base_type_::reduce();
  #line 105 "src/filter/MoveParticleFilter.birch"
  libbirch_line_(105);
  #line 105 "src/filter/MoveParticleFilter.birch"
  this->raccepts = birch::Real(birch::sum(this->naccepts)) / (this->nparticles * this->nmoves);
}

#line 108 "src/filter/MoveParticleFilter.birch"
void birch::type::MoveParticleFilter::read(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 108 "src/filter/MoveParticleFilter.birch"
  libbirch_function_("read", "src/filter/MoveParticleFilter.birch", 108);
  #line 109 "src/filter/MoveParticleFilter.birch"
  libbirch_line_(109);
  #line 109 "src/filter/MoveParticleFilter.birch"
  this->base_type_::read(buffer);
  #line 110 "src/filter/MoveParticleFilter.birch"
  libbirch_line_(110);
  #line 110 "src/filter/MoveParticleFilter.birch"
    libbirch::optional_assign(this->scale, buffer->get<birch::type::Real>(birch::type::String("scale")));
;
  #line 111 "src/filter/MoveParticleFilter.birch"
  libbirch_line_(111);
  #line 111 "src/filter/MoveParticleFilter.birch"
    libbirch::optional_assign(this->nmoves, buffer->get<birch::type::Integer>(birch::type::String("nmoves")));
;
  #line 112 "src/filter/MoveParticleFilter.birch"
  libbirch_line_(112);
  #line 112 "src/filter/MoveParticleFilter.birch"
    libbirch::optional_assign(this->nlags, buffer->get<birch::type::Integer>(birch::type::String("nlags")));
;
}

#line 1 "src/filter/MoveParticleFilter.birch"
birch::type::MoveParticleFilter* birch::type::make_MoveParticleFilter_() {
  #line 1 "src/filter/MoveParticleFilter.birch"
  return new birch::type::MoveParticleFilter();
  #line 1 "src/filter/MoveParticleFilter.birch"
}

#line 1 "src/filter/ParticleFilter.birch"
birch::type::ParticleFilter::ParticleFilter() :
    #line 1 "src/filter/ParticleFilter.birch"
    base_type_(),
    #line 19 "src/filter/ParticleFilter.birch"
    x(libbirch::make<libbirch::DefaultArray<libbirch::Shared<birch::type::Particle>,1>>()),
    #line 24 "src/filter/ParticleFilter.birch"
    w(libbirch::make<libbirch::DefaultArray<birch::type::Real,1>>()),
    #line 29 "src/filter/ParticleFilter.birch"
    a(libbirch::make<libbirch::DefaultArray<birch::type::Integer,1>>()),
    #line 37 "src/filter/ParticleFilter.birch"
    b(birch::type::Integer(0)),
    #line 42 "src/filter/ParticleFilter.birch"
    lsum(0.0),
    #line 47 "src/filter/ParticleFilter.birch"
    ess(0.0),
    #line 52 "src/filter/ParticleFilter.birch"
    lnormalize(0.0),
    #line 60 "src/filter/ParticleFilter.birch"
    npropagations(birch::type::Integer(0)),
    #line 65 "src/filter/ParticleFilter.birch"
    raccepts(0.0),
    #line 70 "src/filter/ParticleFilter.birch"
    nparticles(birch::type::Integer(1)),
    #line 77 "src/filter/ParticleFilter.birch"
    trigger(0.7),
    #line 82 "src/filter/ParticleFilter.birch"
    delayed(true) {
  //
}

#line 87 "src/filter/ParticleFilter.birch"
libbirch::Shared<birch::type::Particle> birch::type::ParticleFilter::particle(const libbirch::Shared<birch::type::Model>& model) {
  #line 87 "src/filter/ParticleFilter.birch"
  libbirch_function_("particle", "src/filter/ParticleFilter.birch", 87);
  #line 88 "src/filter/ParticleFilter.birch"
  libbirch_line_(88);
  #line 88 "src/filter/ParticleFilter.birch"
  return birch::Particle(model);
}

#line 97 "src/filter/ParticleFilter.birch"
void birch::type::ParticleFilter::filter(const libbirch::Shared<birch::type::Model>& model, const libbirch::Shared<birch::type::Buffer>& input) {
  #line 97 "src/filter/ParticleFilter.birch"
  libbirch_function_("filter", "src/filter/ParticleFilter.birch", 97);
  #line 98 "src/filter/ParticleFilter.birch"
  libbirch_line_(98);
  #line 98 "src/filter/ParticleFilter.birch"
  this->x = birch::copy(this->particle(model), this->nparticles);
  #line 99 "src/filter/ParticleFilter.birch"
  libbirch_line_(99);
  #line 99 "src/filter/ParticleFilter.birch"
  this->w = birch::vector(0.0, this->nparticles);
  #line 100 "src/filter/ParticleFilter.birch"
  libbirch_line_(100);
  #line 100 "src/filter/ParticleFilter.birch"
  this->a = birch::iota(birch::type::Integer(1), this->nparticles);
  #line 101 "src/filter/ParticleFilter.birch"
  libbirch_line_(101);
  #line 101 "src/filter/ParticleFilter.birch"
  this->b = birch::type::Integer(1);
  #line 102 "src/filter/ParticleFilter.birch"
  libbirch_line_(102);
  #line 102 "src/filter/ParticleFilter.birch"
  this->ess = this->nparticles;
  #line 103 "src/filter/ParticleFilter.birch"
  libbirch_line_(103);
  #line 103 "src/filter/ParticleFilter.birch"
  this->lsum = 0.0;
  #line 104 "src/filter/ParticleFilter.birch"
  libbirch_line_(104);
  #line 104 "src/filter/ParticleFilter.birch"
  this->lnormalize = 0.0;
  #line 105 "src/filter/ParticleFilter.birch"
  libbirch_line_(105);
  #line 105 "src/filter/ParticleFilter.birch"
  this->npropagations = this->nparticles;
  #line 106 "src/filter/ParticleFilter.birch"
  libbirch_line_(106);
  #line 106 "src/filter/ParticleFilter.birch"
  this->simulate(input);
  #line 107 "src/filter/ParticleFilter.birch"
  libbirch_line_(107);
  #line 107 "src/filter/ParticleFilter.birch"
  this->reduce();
}

#line 116 "src/filter/ParticleFilter.birch"
void birch::type::ParticleFilter::filter(const birch::type::Integer& t, const libbirch::Shared<birch::type::Buffer>& input) {
  #line 116 "src/filter/ParticleFilter.birch"
  libbirch_function_("filter", "src/filter/ParticleFilter.birch", 116);
  #line 117 "src/filter/ParticleFilter.birch"
  libbirch_line_(117);
  #line 117 "src/filter/ParticleFilter.birch"
  this->resample();
  #line 118 "src/filter/ParticleFilter.birch"
  libbirch_line_(118);
  #line 118 "src/filter/ParticleFilter.birch"
  this->simulate(t, input);
  #line 119 "src/filter/ParticleFilter.birch"
  libbirch_line_(119);
  #line 119 "src/filter/ParticleFilter.birch"
  this->reduce();
}

#line 125 "src/filter/ParticleFilter.birch"
void birch::type::ParticleFilter::simulate(const libbirch::Shared<birch::type::Buffer>& input) {
  #line 125 "src/filter/ParticleFilter.birch"
  libbirch_function_("simulate", "src/filter/ParticleFilter.birch", 125);
  #line 126 "src/filter/ParticleFilter.birch"
  libbirch_line_(126);
  #line 126 "src/filter/ParticleFilter.birch"
  #pragma omp parallel
  {
    #line 126 "src/filter/ParticleFilter.birch"
    libbirch_function_("<parallel for>", "src/filter/ParticleFilter.birch", 126);
    #pragma omp for schedule(static)
    for (auto n = birch::type::Integer(1); n <= this->nparticles; ++n) {
      #line 127 "src/filter/ParticleFilter.birch"
      libbirch_line_(127);
      #line 127 "src/filter/ParticleFilter.birch"
      auto handler = birch::PlayHandler(this->delayed);
      #line 128 "src/filter/ParticleFilter.birch"
      libbirch_line_(128);
      #line 128 "src/filter/ParticleFilter.birch"
      {
        auto handler_ = birch::swap_handler((handler));
        #line 129 "src/filter/ParticleFilter.birch"
        libbirch_line_(129);
        #line 129 "src/filter/ParticleFilter.birch"
        this->x(n)->m->read(input);
        #line 130 "src/filter/ParticleFilter.birch"
        libbirch_line_(130);
        #line 130 "src/filter/ParticleFilter.birch"
        this->x(n)->m->simulate();
        #line 131 "src/filter/ParticleFilter.birch"
        libbirch_line_(131);
        #line 131 "src/filter/ParticleFilter.birch"
        this->w(n) = this->w(n) + handler->w;
        birch::set_handler(handler_);
      }
    }
  }
}

#line 139 "src/filter/ParticleFilter.birch"
void birch::type::ParticleFilter::simulate(const birch::type::Integer& t, const libbirch::Shared<birch::type::Buffer>& input) {
  #line 139 "src/filter/ParticleFilter.birch"
  libbirch_function_("simulate", "src/filter/ParticleFilter.birch", 139);
  #line 140 "src/filter/ParticleFilter.birch"
  libbirch_line_(140);
  #line 140 "src/filter/ParticleFilter.birch"
  #pragma omp parallel
  {
    #line 140 "src/filter/ParticleFilter.birch"
    libbirch_function_("<parallel for>", "src/filter/ParticleFilter.birch", 140);
    #pragma omp for schedule(static)
    for (auto n = birch::type::Integer(1); n <= this->nparticles; ++n) {
      #line 141 "src/filter/ParticleFilter.birch"
      libbirch_line_(141);
      #line 141 "src/filter/ParticleFilter.birch"
      auto handler = birch::PlayHandler(this->delayed);
      #line 142 "src/filter/ParticleFilter.birch"
      libbirch_line_(142);
      #line 142 "src/filter/ParticleFilter.birch"
      {
        auto handler_ = birch::swap_handler((handler));
        #line 143 "src/filter/ParticleFilter.birch"
        libbirch_line_(143);
        #line 143 "src/filter/ParticleFilter.birch"
        this->x(n)->m->read(t, input);
        #line 144 "src/filter/ParticleFilter.birch"
        libbirch_line_(144);
        #line 144 "src/filter/ParticleFilter.birch"
        this->x(n)->m->simulate(t);
        #line 145 "src/filter/ParticleFilter.birch"
        libbirch_line_(145);
        #line 145 "src/filter/ParticleFilter.birch"
        this->w(n) = this->w(n) + handler->w;
        birch::set_handler(handler_);
      }
    }
  }
}

#line 154 "src/filter/ParticleFilter.birch"
void birch::type::ParticleFilter::reduce() {
  #line 154 "src/filter/ParticleFilter.birch"
  libbirch_function_("reduce", "src/filter/ParticleFilter.birch", 154);
  #line 155 "src/filter/ParticleFilter.birch"
  libbirch_line_(155);
  #line 155 "src/filter/ParticleFilter.birch"
  std::tie(this->ess, this->lsum) = birch::resample_reduce(this->w);
  #line 156 "src/filter/ParticleFilter.birch"
  libbirch_line_(156);
  #line 156 "src/filter/ParticleFilter.birch"
  this->lnormalize = this->lnormalize + this->lsum - birch::log(birch::Real(this->nparticles));
  #line 157 "src/filter/ParticleFilter.birch"
  libbirch_line_(157);
  #line 157 "src/filter/ParticleFilter.birch"
  this->b = birch::ancestor(this->w);
  #line 158 "src/filter/ParticleFilter.birch"
  libbirch_line_(158);
  #line 158 "src/filter/ParticleFilter.birch"
  if (this->b == birch::type::Integer(0)) {
    #line 159 "src/filter/ParticleFilter.birch"
    libbirch_line_(159);
    #line 159 "src/filter/ParticleFilter.birch"
    birch::error(birch::type::String("particle filter degenerated"));
  }
}

#line 166 "src/filter/ParticleFilter.birch"
void birch::type::ParticleFilter::resample() {
  #line 166 "src/filter/ParticleFilter.birch"
  libbirch_function_("resample", "src/filter/ParticleFilter.birch", 166);
  #line 167 "src/filter/ParticleFilter.birch"
  libbirch_line_(167);
  #line 167 "src/filter/ParticleFilter.birch"
  if (this->ess <= this->trigger * this->nparticles) {
    #line 168 "src/filter/ParticleFilter.birch"
    libbirch_line_(168);
    #line 168 "src/filter/ParticleFilter.birch"
    this->a = birch::resample_systematic(this->w);
    #line 169 "src/filter/ParticleFilter.birch"
    libbirch_line_(169);
    #line 169 "src/filter/ParticleFilter.birch"
    this->w = birch::vector(0.0, this->nparticles);
    #line 170 "src/filter/ParticleFilter.birch"
    libbirch_line_(170);
    #line 170 "src/filter/ParticleFilter.birch"
    this->copy();
    #line 171 "src/filter/ParticleFilter.birch"
    libbirch_line_(171);
    #line 171 "src/filter/ParticleFilter.birch"
    birch::collect();
  } else {
    #line 174 "src/filter/ParticleFilter.birch"
    libbirch_line_(174);
    #line 174 "src/filter/ParticleFilter.birch"
    this->a = birch::iota(birch::type::Integer(1), this->nparticles);
    #line 175 "src/filter/ParticleFilter.birch"
    libbirch_line_(175);
    #line 175 "src/filter/ParticleFilter.birch"
    this->w = this->w - birch::vector(this->lsum - birch::log(birch::Real(this->nparticles)), this->nparticles);
  }
}

#line 182 "src/filter/ParticleFilter.birch"
void birch::type::ParticleFilter::copy() {
  #line 182 "src/filter/ParticleFilter.birch"
  libbirch_function_("copy", "src/filter/ParticleFilter.birch", 182);
  #line 183 "src/filter/ParticleFilter.birch"
  libbirch_line_(183);
  #line 183 "src/filter/ParticleFilter.birch"
  auto i = birch::vector(false, this->nparticles);
  #line 184 "src/filter/ParticleFilter.birch"
  libbirch_line_(184);
  #line 184 "src/filter/ParticleFilter.birch"
  #pragma omp parallel
  {
    #line 184 "src/filter/ParticleFilter.birch"
    libbirch_function_("<parallel for>", "src/filter/ParticleFilter.birch", 184);
    #pragma omp for schedule(guided)
    for (auto n = birch::type::Integer(1); n <= this->nparticles; ++n) {
      #line 185 "src/filter/ParticleFilter.birch"
      libbirch_line_(185);
      #line 185 "src/filter/ParticleFilter.birch"
      auto m = this->a(n);
      #line 186 "src/filter/ParticleFilter.birch"
      libbirch_line_(186);
      #line 186 "src/filter/ParticleFilter.birch"
      if (m != n) {
        #line 187 "src/filter/ParticleFilter.birch"
        libbirch_line_(187);
        #line 187 "src/filter/ParticleFilter.birch"
        if (!(i(m))) {
          #line 188 "src/filter/ParticleFilter.birch"
          libbirch_line_(188);
          #line 188 "src/filter/ParticleFilter.birch"
          this->x(n) = birch::copy(this->x(m));
          #line 189 "src/filter/ParticleFilter.birch"
          libbirch_line_(189);
          #line 189 "src/filter/ParticleFilter.birch"
          i(m) = true;
        } else {
          #line 191 "src/filter/ParticleFilter.birch"
          libbirch_line_(191);
          #line 191 "src/filter/ParticleFilter.birch"
          this->x(n) = birch::copy2(this->x(m));
        }
      }
    }
  }
}

#line 197 "src/filter/ParticleFilter.birch"
void birch::type::ParticleFilter::read(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 197 "src/filter/ParticleFilter.birch"
  libbirch_function_("read", "src/filter/ParticleFilter.birch", 197);
  #line 198 "src/filter/ParticleFilter.birch"
  libbirch_line_(198);
  #line 198 "src/filter/ParticleFilter.birch"
    libbirch::optional_assign(this->nparticles, buffer->get<birch::type::Integer>(birch::type::String("nparticles")));
;
  #line 199 "src/filter/ParticleFilter.birch"
  libbirch_line_(199);
  #line 199 "src/filter/ParticleFilter.birch"
    libbirch::optional_assign(this->trigger, buffer->get<birch::type::Real>(birch::type::String("trigger")));
;
  #line 200 "src/filter/ParticleFilter.birch"
  libbirch_line_(200);
  #line 200 "src/filter/ParticleFilter.birch"
    libbirch::optional_assign(this->delayed, buffer->get<birch::type::Boolean>(birch::type::String("delayed")));
;
}

#line 1 "src/filter/ParticleFilter.birch"
birch::type::ParticleFilter* birch::type::make_ParticleFilter_() {
  #line 1 "src/filter/ParticleFilter.birch"
  return new birch::type::ParticleFilter();
  #line 1 "src/filter/ParticleFilter.birch"
}

