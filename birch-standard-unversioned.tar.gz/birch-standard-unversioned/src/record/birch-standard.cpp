#line 4 "src/record/FactorRecord.birch"
birch::type::FactorRecord::FactorRecord() :
    #line 4 "src/record/FactorRecord.birch"
    base_type_() {
  //
}

#line 4 "src/record/FactorRecord.birch"
birch::type::FactorRecord* birch::type::make_FactorRecord_() {
  #line 4 "src/record/FactorRecord.birch"
  return new birch::type::FactorRecord();
  #line 4 "src/record/FactorRecord.birch"
}

#line 11 "src/record/FactorRecord.birch"
libbirch::Shared<birch::type::FactorRecord> birch::FactorRecord() {
  #line 11 "src/record/FactorRecord.birch"
  libbirch_function_("FactorRecord", "src/record/FactorRecord.birch", 11);
  #line 12 "src/record/FactorRecord.birch"
  libbirch_line_(12);
  #line 12 "src/record/FactorRecord.birch"
  return birch::construct<libbirch::Shared<birch::type::FactorRecord>>();
}

#line 9 "src/record/Record.birch"
birch::type::Record::Record() :
    #line 9 "src/record/Record.birch"
    base_type_() {
  //
}

#line 17 "src/record/Record.birch"
birch::type::Real birch::type::Record::ratio(const libbirch::Shared<birch::type::Record>& record, const birch::type::Real& scale) {
  #line 17 "src/record/Record.birch"
  libbirch_function_("ratio", "src/record/Record.birch", 17);
  #line 18 "src/record/Record.birch"
  libbirch_line_(18);
  #line 18 "src/record/Record.birch"
  return 0.0;
}

