#line 20 "src/data/Buffer.birch"
birch::type::Buffer::Buffer() :
    #line 20 "src/data/Buffer.birch"
    base_type_(),
    #line 40 "src/data/Buffer.birch"
    keys(libbirch::make<std::optional<libbirch::DefaultArray<birch::type::String,1>>>()),
    #line 41 "src/data/Buffer.birch"
    values(libbirch::make<std::optional<libbirch::DefaultArray<libbirch::Shared<birch::type::Buffer>,1>>>()),
    #line 42 "src/data/Buffer.birch"
    scalarString(libbirch::make<std::optional<birch::type::String>>()),
    #line 43 "src/data/Buffer.birch"
    scalarReal(libbirch::make<std::optional<birch::type::Real>>()),
    #line 44 "src/data/Buffer.birch"
    scalarInteger(libbirch::make<std::optional<birch::type::Integer>>()),
    #line 45 "src/data/Buffer.birch"
    scalarBoolean(libbirch::make<std::optional<birch::type::Boolean>>()),
    #line 46 "src/data/Buffer.birch"
    vectorReal(libbirch::make<std::optional<libbirch::DefaultArray<birch::type::Real,1>>>()),
    #line 47 "src/data/Buffer.birch"
    vectorInteger(libbirch::make<std::optional<libbirch::DefaultArray<birch::type::Integer,1>>>()),
    #line 48 "src/data/Buffer.birch"
    vectorBoolean(libbirch::make<std::optional<libbirch::DefaultArray<birch::type::Boolean,1>>>()),
    #line 49 "src/data/Buffer.birch"
    matrixReal(libbirch::make<std::optional<libbirch::DefaultArray<birch::type::Real,2>>>()),
    #line 50 "src/data/Buffer.birch"
    matrixInteger(libbirch::make<std::optional<libbirch::DefaultArray<birch::type::Integer,2>>>()),
    #line 51 "src/data/Buffer.birch"
    matrixBoolean(libbirch::make<std::optional<libbirch::DefaultArray<birch::type::Boolean,2>>>()) {
  this->libbirch::Any::acyclic_();
}

#line 56 "src/data/Buffer.birch"
birch::type::Boolean birch::type::Buffer::isNil() {
  #line 56 "src/data/Buffer.birch"
  libbirch_function_("isNil", "src/data/Buffer.birch", 56);
  #line 57 "src/data/Buffer.birch"
  libbirch_line_(57);
  #line 57 "src/data/Buffer.birch"
  return !((this->keys.has_value() || this->values.has_value() || this->scalarString.has_value() || this->scalarReal.has_value() || this->scalarInteger.has_value() || this->scalarBoolean.has_value() || this->vectorReal.has_value() || this->vectorInteger.has_value() || this->vectorBoolean.has_value() || this->matrixReal.has_value() || this->matrixInteger.has_value() || this->matrixBoolean.has_value()));
}

#line 66 "src/data/Buffer.birch"
birch::type::Boolean birch::type::Buffer::isNil(const birch::type::String& key) {
  #line 66 "src/data/Buffer.birch"
  libbirch_function_("isNil", "src/data/Buffer.birch", 66);
  #line 67 "src/data/Buffer.birch"
  libbirch_line_(67);
  #line 67 "src/data/Buffer.birch"
  auto buffer = this->get(key);
  #line 68 "src/data/Buffer.birch"
  libbirch_line_(68);
  #line 68 "src/data/Buffer.birch"
  if (buffer.has_value()) {
    #line 69 "src/data/Buffer.birch"
    libbirch_line_(69);
    #line 69 "src/data/Buffer.birch"
    return buffer.value()->isNil();
  } else {
    #line 71 "src/data/Buffer.birch"
    libbirch_line_(71);
    #line 71 "src/data/Buffer.birch"
    return true;
  }
}

#line 78 "src/data/Buffer.birch"
void birch::type::Buffer::setNil() {
  #line 78 "src/data/Buffer.birch"
  libbirch_function_("setNil", "src/data/Buffer.birch", 78);
  #line 79 "src/data/Buffer.birch"
  libbirch_line_(79);
  #line 79 "src/data/Buffer.birch"
  this->keys = std::nullopt;
  #line 80 "src/data/Buffer.birch"
  libbirch_line_(80);
  #line 80 "src/data/Buffer.birch"
  this->values = std::nullopt;
  #line 81 "src/data/Buffer.birch"
  libbirch_line_(81);
  #line 81 "src/data/Buffer.birch"
  this->scalarString = std::nullopt;
  #line 82 "src/data/Buffer.birch"
  libbirch_line_(82);
  #line 82 "src/data/Buffer.birch"
  this->scalarReal = std::nullopt;
  #line 83 "src/data/Buffer.birch"
  libbirch_line_(83);
  #line 83 "src/data/Buffer.birch"
  this->scalarInteger = std::nullopt;
  #line 84 "src/data/Buffer.birch"
  libbirch_line_(84);
  #line 84 "src/data/Buffer.birch"
  this->scalarBoolean = std::nullopt;
  #line 85 "src/data/Buffer.birch"
  libbirch_line_(85);
  #line 85 "src/data/Buffer.birch"
  this->vectorReal = std::nullopt;
  #line 86 "src/data/Buffer.birch"
  libbirch_line_(86);
  #line 86 "src/data/Buffer.birch"
  this->vectorInteger = std::nullopt;
  #line 87 "src/data/Buffer.birch"
  libbirch_line_(87);
  #line 87 "src/data/Buffer.birch"
  this->vectorBoolean = std::nullopt;
  #line 88 "src/data/Buffer.birch"
  libbirch_line_(88);
  #line 88 "src/data/Buffer.birch"
  this->matrixReal = std::nullopt;
  #line 89 "src/data/Buffer.birch"
  libbirch_line_(89);
  #line 89 "src/data/Buffer.birch"
  this->matrixInteger = std::nullopt;
  #line 90 "src/data/Buffer.birch"
  libbirch_line_(90);
  #line 90 "src/data/Buffer.birch"
  this->matrixBoolean = std::nullopt;
}

#line 96 "src/data/Buffer.birch"
void birch::type::Buffer::setNil(const birch::type::String& key) {
  #line 96 "src/data/Buffer.birch"
  libbirch_function_("setNil", "src/data/Buffer.birch", 96);
  #line 97 "src/data/Buffer.birch"
  libbirch_line_(97);
  #line 97 "src/data/Buffer.birch"
  auto value = birch::Buffer();
  #line 98 "src/data/Buffer.birch"
  libbirch_line_(98);
  #line 98 "src/data/Buffer.birch"
  value->setNil();
  #line 99 "src/data/Buffer.birch"
  libbirch_line_(99);
  #line 99 "src/data/Buffer.birch"
  this->set(key, value);
}

#line 106 "src/data/Buffer.birch"
birch::type::Boolean birch::type::Buffer::isEmpty() {
  #line 106 "src/data/Buffer.birch"
  libbirch_function_("isEmpty", "src/data/Buffer.birch", 106);
  #line 107 "src/data/Buffer.birch"
  libbirch_line_(107);
  #line 107 "src/data/Buffer.birch"
  return this->isNil() || (this->values.has_value() && birch::length(this->values.value()) == birch::type::Integer(0));
}

#line 114 "src/data/Buffer.birch"
birch::type::Boolean birch::type::Buffer::isEmpty(const birch::type::String& key) {
  #line 114 "src/data/Buffer.birch"
  libbirch_function_("isEmpty", "src/data/Buffer.birch", 114);
  #line 115 "src/data/Buffer.birch"
  libbirch_line_(115);
  #line 115 "src/data/Buffer.birch"
  auto buffer = this->get(key);
  #line 116 "src/data/Buffer.birch"
  libbirch_line_(116);
  #line 116 "src/data/Buffer.birch"
  if (buffer.has_value()) {
    #line 117 "src/data/Buffer.birch"
    libbirch_line_(117);
    #line 117 "src/data/Buffer.birch"
    return buffer.value()->isEmpty();
  } else {
    #line 119 "src/data/Buffer.birch"
    libbirch_line_(119);
    #line 119 "src/data/Buffer.birch"
    return true;
  }
}

#line 126 "src/data/Buffer.birch"
void birch::type::Buffer::setEmptyObject() {
  #line 126 "src/data/Buffer.birch"
  libbirch_function_("setEmptyObject", "src/data/Buffer.birch", 126);
  #line 127 "src/data/Buffer.birch"
  libbirch_line_(127);
  #line 127 "src/data/Buffer.birch"
  this->setNil();
  #line 128 "src/data/Buffer.birch"
  libbirch_line_(128);
  #line 128 "src/data/Buffer.birch"
  libbirch::DefaultArray<birch::type::String,1> keys = libbirch::make<libbirch::DefaultArray<birch::type::String,1>>();
  #line 129 "src/data/Buffer.birch"
  libbirch_line_(129);
  #line 129 "src/data/Buffer.birch"
  libbirch::DefaultArray<libbirch::Shared<birch::type::Buffer>,1> values = libbirch::make<libbirch::DefaultArray<libbirch::Shared<birch::type::Buffer>,1>>();
  #line 130 "src/data/Buffer.birch"
  libbirch_line_(130);
  #line 130 "src/data/Buffer.birch"
  this->keys = keys;
  #line 131 "src/data/Buffer.birch"
  libbirch_line_(131);
  #line 131 "src/data/Buffer.birch"
  this->values = values;
}

#line 137 "src/data/Buffer.birch"
void birch::type::Buffer::setEmptyObject(const birch::type::String& key) {
  #line 137 "src/data/Buffer.birch"
  libbirch_function_("setEmptyObject", "src/data/Buffer.birch", 137);
  #line 138 "src/data/Buffer.birch"
  libbirch_line_(138);
  #line 138 "src/data/Buffer.birch"
  auto value = birch::Buffer();
  #line 139 "src/data/Buffer.birch"
  libbirch_line_(139);
  #line 139 "src/data/Buffer.birch"
  value->setEmptyObject();
  #line 140 "src/data/Buffer.birch"
  libbirch_line_(140);
  #line 140 "src/data/Buffer.birch"
  this->set(key, value);
}

#line 146 "src/data/Buffer.birch"
void birch::type::Buffer::setEmptyArray() {
  #line 146 "src/data/Buffer.birch"
  libbirch_function_("setEmptyArray", "src/data/Buffer.birch", 146);
  #line 147 "src/data/Buffer.birch"
  libbirch_line_(147);
  #line 147 "src/data/Buffer.birch"
  this->setNil();
  #line 148 "src/data/Buffer.birch"
  libbirch_line_(148);
  #line 148 "src/data/Buffer.birch"
  libbirch::DefaultArray<libbirch::Shared<birch::type::Buffer>,1> values = libbirch::make<libbirch::DefaultArray<libbirch::Shared<birch::type::Buffer>,1>>();
  #line 149 "src/data/Buffer.birch"
  libbirch_line_(149);
  #line 149 "src/data/Buffer.birch"
  this->values = values;
}

#line 155 "src/data/Buffer.birch"
void birch::type::Buffer::setEmptyArray(const birch::type::String& key) {
  #line 155 "src/data/Buffer.birch"
  libbirch_function_("setEmptyArray", "src/data/Buffer.birch", 155);
  #line 156 "src/data/Buffer.birch"
  libbirch_line_(156);
  #line 156 "src/data/Buffer.birch"
  auto value = birch::Buffer();
  #line 157 "src/data/Buffer.birch"
  libbirch_line_(157);
  #line 157 "src/data/Buffer.birch"
  value->setEmptyArray();
  #line 158 "src/data/Buffer.birch"
  libbirch_line_(158);
  #line 158 "src/data/Buffer.birch"
  this->set(key, value);
}

#line 165 "src/data/Buffer.birch"
libbirch::Shared<birch::type::Buffer> birch::type::Buffer::move() {
  #line 165 "src/data/Buffer.birch"
  libbirch_function_("move", "src/data/Buffer.birch", 165);
  #line 166 "src/data/Buffer.birch"
  libbirch_line_(166);
  #line 166 "src/data/Buffer.birch"
  auto buffer = birch::Buffer();
  #line 167 "src/data/Buffer.birch"
  libbirch_line_(167);
  #line 167 "src/data/Buffer.birch"
  buffer->keys = this->keys;
  #line 168 "src/data/Buffer.birch"
  libbirch_line_(168);
  #line 168 "src/data/Buffer.birch"
  buffer->values = this->values;
  #line 169 "src/data/Buffer.birch"
  libbirch_line_(169);
  #line 169 "src/data/Buffer.birch"
  buffer->scalarString = this->scalarString;
  #line 170 "src/data/Buffer.birch"
  libbirch_line_(170);
  #line 170 "src/data/Buffer.birch"
  buffer->scalarReal = this->scalarReal;
  #line 171 "src/data/Buffer.birch"
  libbirch_line_(171);
  #line 171 "src/data/Buffer.birch"
  buffer->scalarInteger = this->scalarInteger;
  #line 172 "src/data/Buffer.birch"
  libbirch_line_(172);
  #line 172 "src/data/Buffer.birch"
  buffer->scalarBoolean = this->scalarBoolean;
  #line 173 "src/data/Buffer.birch"
  libbirch_line_(173);
  #line 173 "src/data/Buffer.birch"
  buffer->vectorReal = this->vectorReal;
  #line 174 "src/data/Buffer.birch"
  libbirch_line_(174);
  #line 174 "src/data/Buffer.birch"
  buffer->vectorInteger = this->vectorInteger;
  #line 175 "src/data/Buffer.birch"
  libbirch_line_(175);
  #line 175 "src/data/Buffer.birch"
  buffer->vectorBoolean = this->vectorBoolean;
  #line 176 "src/data/Buffer.birch"
  libbirch_line_(176);
  #line 176 "src/data/Buffer.birch"
  buffer->matrixReal = this->matrixReal;
  #line 177 "src/data/Buffer.birch"
  libbirch_line_(177);
  #line 177 "src/data/Buffer.birch"
  buffer->matrixInteger = this->matrixInteger;
  #line 178 "src/data/Buffer.birch"
  libbirch_line_(178);
  #line 178 "src/data/Buffer.birch"
  buffer->matrixBoolean = this->matrixBoolean;
  #line 179 "src/data/Buffer.birch"
  libbirch_line_(179);
  #line 179 "src/data/Buffer.birch"
  this->setNil();
  #line 180 "src/data/Buffer.birch"
  libbirch_line_(180);
  #line 180 "src/data/Buffer.birch"
  return buffer;
}

#line 192 "src/data/Buffer.birch"
libbirch::Shared<birch::type::Buffer> birch::type::Buffer::move(const birch::type::String& key) {
  #line 192 "src/data/Buffer.birch"
  libbirch_function_("move", "src/data/Buffer.birch", 192);
  #line 193 "src/data/Buffer.birch"
  libbirch_line_(193);
  #line 193 "src/data/Buffer.birch"
  auto buffer = this->get(key);
  #line 194 "src/data/Buffer.birch"
  libbirch_line_(194);
  #line 194 "src/data/Buffer.birch"
  if (buffer.has_value()) {
    #line 195 "src/data/Buffer.birch"
    libbirch_line_(195);
    #line 195 "src/data/Buffer.birch"
    return buffer.value()->move();
  } else {
    #line 197 "src/data/Buffer.birch"
    libbirch_line_(197);
    #line 197 "src/data/Buffer.birch"
    return birch::Buffer();
  }
}

#line 208 "src/data/Buffer.birch"
birch::type::Integer birch::type::Buffer::size() {
  #line 208 "src/data/Buffer.birch"
  libbirch_function_("size", "src/data/Buffer.birch", 208);
  #line 209 "src/data/Buffer.birch"
  libbirch_line_(209);
  #line 209 "src/data/Buffer.birch"
  if (this->keys.has_value() || this->scalarString.has_value() || this->scalarReal.has_value() || this->scalarInteger.has_value() || this->scalarBoolean.has_value()) {
    #line 211 "src/data/Buffer.birch"
    libbirch_line_(211);
    #line 211 "src/data/Buffer.birch"
    return birch::type::Integer(1);
  } else {
    #line 212 "src/data/Buffer.birch"
    libbirch_line_(212);
    #line 212 "src/data/Buffer.birch"
    if (this->values.has_value()) {
      #line 213 "src/data/Buffer.birch"
      libbirch_line_(213);
      #line 213 "src/data/Buffer.birch"
      return birch::length(this->values.value());
    } else {
      #line 214 "src/data/Buffer.birch"
      libbirch_line_(214);
      #line 214 "src/data/Buffer.birch"
      if (this->vectorReal.has_value()) {
        #line 215 "src/data/Buffer.birch"
        libbirch_line_(215);
        #line 215 "src/data/Buffer.birch"
        return birch::length(this->vectorReal.value());
      } else {
        #line 216 "src/data/Buffer.birch"
        libbirch_line_(216);
        #line 216 "src/data/Buffer.birch"
        if (this->vectorInteger.has_value()) {
          #line 217 "src/data/Buffer.birch"
          libbirch_line_(217);
          #line 217 "src/data/Buffer.birch"
          return birch::length(this->vectorInteger.value());
        } else {
          #line 218 "src/data/Buffer.birch"
          libbirch_line_(218);
          #line 218 "src/data/Buffer.birch"
          if (this->vectorBoolean.has_value()) {
            #line 219 "src/data/Buffer.birch"
            libbirch_line_(219);
            #line 219 "src/data/Buffer.birch"
            return birch::length(this->vectorBoolean.value());
          } else {
            #line 220 "src/data/Buffer.birch"
            libbirch_line_(220);
            #line 220 "src/data/Buffer.birch"
            if (this->matrixReal.has_value()) {
              #line 221 "src/data/Buffer.birch"
              libbirch_line_(221);
              #line 221 "src/data/Buffer.birch"
              return birch::rows(this->matrixReal.value());
            } else {
              #line 222 "src/data/Buffer.birch"
              libbirch_line_(222);
              #line 222 "src/data/Buffer.birch"
              if (this->matrixInteger.has_value()) {
                #line 223 "src/data/Buffer.birch"
                libbirch_line_(223);
                #line 223 "src/data/Buffer.birch"
                return birch::rows(this->matrixInteger.value());
              } else {
                #line 224 "src/data/Buffer.birch"
                libbirch_line_(224);
                #line 224 "src/data/Buffer.birch"
                if (this->matrixBoolean.has_value()) {
                  #line 225 "src/data/Buffer.birch"
                  libbirch_line_(225);
                  #line 225 "src/data/Buffer.birch"
                  return birch::rows(this->matrixBoolean.value());
                } else {
                  #line 227 "src/data/Buffer.birch"
                  libbirch_line_(227);
                  #line 227 "src/data/Buffer.birch"
                  return birch::type::Integer(0);
                }
              }
            }
          }
        }
      }
    }
  }
}

#line 238 "src/data/Buffer.birch"
birch::type::Integer birch::type::Buffer::size(const birch::type::String& key) {
  #line 238 "src/data/Buffer.birch"
  libbirch_function_("size", "src/data/Buffer.birch", 238);
  #line 239 "src/data/Buffer.birch"
  libbirch_line_(239);
  #line 239 "src/data/Buffer.birch"
  auto buffer = this->get(key);
  #line 240 "src/data/Buffer.birch"
  libbirch_line_(240);
  #line 240 "src/data/Buffer.birch"
  if (buffer.has_value()) {
    #line 241 "src/data/Buffer.birch"
    libbirch_line_(241);
    #line 241 "src/data/Buffer.birch"
    return buffer.value()->size();
  } else {
    #line 243 "src/data/Buffer.birch"
    libbirch_line_(243);
    #line 243 "src/data/Buffer.birch"
    return birch::type::Integer(0);
  }
}

#line 320 "src/data/Buffer.birch"
std::optional<libbirch::Shared<birch::type::Buffer>> birch::type::Buffer::get(const birch::type::String& key) {
  #line 320 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 320);
  #line 321 "src/data/Buffer.birch"
  libbirch_line_(321);
  #line 321 "src/data/Buffer.birch"
  if (this->keys.has_value()) {
    #line 322 "src/data/Buffer.birch"
    libbirch_line_(322);
    #line 322 "src/data/Buffer.birch"
    for (auto i = birch::type::Integer(1); i <= birch::length(this->keys.value()); ++i) {
      #line 323 "src/data/Buffer.birch"
      libbirch_line_(323);
      #line 323 "src/data/Buffer.birch"
      if (this->keys.value()(i) == key) {
        #line 324 "src/data/Buffer.birch"
        libbirch_line_(324);
        #line 324 "src/data/Buffer.birch"
        return this->values.value()(i);
      }
    }
  }
  #line 328 "src/data/Buffer.birch"
  libbirch_line_(328);
  #line 328 "src/data/Buffer.birch"
  return std::nullopt;
}

#line 386 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& key, const libbirch::Shared<birch::type::Buffer>& x) {
  #line 386 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 386);
  #line 387 "src/data/Buffer.birch"
  libbirch_line_(387);
  #line 387 "src/data/Buffer.birch"
  if (!(this->keys.has_value())) {
    #line 388 "src/data/Buffer.birch"
    libbirch_line_(388);
    #line 388 "src/data/Buffer.birch"
    this->setNil();
    #line 389 "src/data/Buffer.birch"
    libbirch_line_(389);
    #line 389 "src/data/Buffer.birch"
    this->keys = libbirch::make_array_from_sequence({ key });
    #line 390 "src/data/Buffer.birch"
    libbirch_line_(390);
    #line 390 "src/data/Buffer.birch"
    this->values = libbirch::make_array_from_sequence({ x });
  } else {
    #line 392 "src/data/Buffer.birch"
    libbirch_line_(392);
    #line 392 "src/data/Buffer.birch"
    this->keys = birch::stack(this->keys.value(), key);
    #line 393 "src/data/Buffer.birch"
    libbirch_line_(393);
    #line 393 "src/data/Buffer.birch"
    this->values = birch::stack(this->values.value(), x);
  }
}

#line 404 "src/data/Buffer.birch"
libbirch::Shared<birch::type::Iterator<libbirch::Shared<birch::type::Buffer>>> birch::type::Buffer::walk() {
  #line 404 "src/data/Buffer.birch"
  libbirch_function_("walk", "src/data/Buffer.birch", 404);
  #line 405 "src/data/Buffer.birch"
  libbirch_line_(405);
  #line 405 "src/data/Buffer.birch"
  if (this->keys.has_value() || this->scalarString.has_value() || this->scalarReal.has_value() || this->scalarInteger.has_value() || this->scalarBoolean.has_value()) {
    #line 407 "src/data/Buffer.birch"
    libbirch_line_(407);
    #line 407 "src/data/Buffer.birch"
    return birch::SingletonIterator(this->shared_from_this_());
  } else {
    #line 408 "src/data/Buffer.birch"
    libbirch_line_(408);
    #line 408 "src/data/Buffer.birch"
    if (this->values.has_value()) {
      #line 409 "src/data/Buffer.birch"
      libbirch_line_(409);
      #line 409 "src/data/Buffer.birch"
      return birch::BufferIterator(this->shared_from_this_());
    } else {
      #line 410 "src/data/Buffer.birch"
      libbirch_line_(410);
      #line 410 "src/data/Buffer.birch"
      if (this->vectorReal.has_value()) {
        #line 411 "src/data/Buffer.birch"
        libbirch_line_(411);
        #line 411 "src/data/Buffer.birch"
        return birch::VectorBufferIterator(this->vectorReal.value());
      } else {
        #line 412 "src/data/Buffer.birch"
        libbirch_line_(412);
        #line 412 "src/data/Buffer.birch"
        if (this->vectorInteger.has_value()) {
          #line 413 "src/data/Buffer.birch"
          libbirch_line_(413);
          #line 413 "src/data/Buffer.birch"
          return birch::VectorBufferIterator(this->vectorInteger.value());
        } else {
          #line 414 "src/data/Buffer.birch"
          libbirch_line_(414);
          #line 414 "src/data/Buffer.birch"
          if (this->vectorBoolean.has_value()) {
            #line 415 "src/data/Buffer.birch"
            libbirch_line_(415);
            #line 415 "src/data/Buffer.birch"
            return birch::VectorBufferIterator(this->vectorBoolean.value());
          } else {
            #line 416 "src/data/Buffer.birch"
            libbirch_line_(416);
            #line 416 "src/data/Buffer.birch"
            if (this->matrixReal.has_value()) {
              #line 417 "src/data/Buffer.birch"
              libbirch_line_(417);
              #line 417 "src/data/Buffer.birch"
              return birch::MatrixBufferIterator(this->matrixReal.value());
            } else {
              #line 418 "src/data/Buffer.birch"
              libbirch_line_(418);
              #line 418 "src/data/Buffer.birch"
              if (this->matrixInteger.has_value()) {
                #line 419 "src/data/Buffer.birch"
                libbirch_line_(419);
                #line 419 "src/data/Buffer.birch"
                return birch::MatrixBufferIterator(this->matrixInteger.value());
              } else {
                #line 420 "src/data/Buffer.birch"
                libbirch_line_(420);
                #line 420 "src/data/Buffer.birch"
                if (this->matrixBoolean.has_value()) {
                  #line 421 "src/data/Buffer.birch"
                  libbirch_line_(421);
                  #line 421 "src/data/Buffer.birch"
                  return birch::MatrixBufferIterator(this->matrixBoolean.value());
                } else {
                  #line 423 "src/data/Buffer.birch"
                  libbirch_line_(423);
                  #line 423 "src/data/Buffer.birch"
                  return birch::EmptyIterator<libbirch::Shared<birch::type::Buffer>>();
                }
              }
            }
          }
        }
      }
    }
  }
}

#line 435 "src/data/Buffer.birch"
libbirch::Shared<birch::type::Iterator<libbirch::Shared<birch::type::Buffer>>> birch::type::Buffer::walk(const birch::type::String& key) {
  #line 435 "src/data/Buffer.birch"
  libbirch_function_("walk", "src/data/Buffer.birch", 435);
  #line 436 "src/data/Buffer.birch"
  libbirch_line_(436);
  #line 436 "src/data/Buffer.birch"
  auto buffer = this->get(key);
  #line 437 "src/data/Buffer.birch"
  libbirch_line_(437);
  #line 437 "src/data/Buffer.birch"
  if (buffer.has_value()) {
    #line 438 "src/data/Buffer.birch"
    libbirch_line_(438);
    #line 438 "src/data/Buffer.birch"
    return buffer.value()->walk();
  } else {
    #line 440 "src/data/Buffer.birch"
    libbirch_line_(440);
    #line 440 "src/data/Buffer.birch"
    return birch::EmptyIterator<libbirch::Shared<birch::type::Buffer>>();
  }
}

#line 473 "src/data/Buffer.birch"
void birch::type::Buffer::push(const libbirch::Shared<birch::type::Buffer>& x) {
  #line 473 "src/data/Buffer.birch"
  libbirch_function_("push", "src/data/Buffer.birch", 473);
  #line 474 "src/data/Buffer.birch"
  libbirch_line_(474);
  #line 474 "src/data/Buffer.birch"
  if (this->isEmpty()) {
    #line 475 "src/data/Buffer.birch"
    libbirch_line_(475);
    #line 475 "src/data/Buffer.birch"
    this->keys = std::nullopt;
    #line 476 "src/data/Buffer.birch"
    libbirch_line_(476);
    #line 476 "src/data/Buffer.birch"
    this->values = libbirch::make_array_from_sequence({ x });
  } else {
    #line 477 "src/data/Buffer.birch"
    libbirch_line_(477);
    #line 477 "src/data/Buffer.birch"
    if (!(this->keys.has_value()) && this->values.has_value()) {
      #line 478 "src/data/Buffer.birch"
      libbirch_line_(478);
      #line 478 "src/data/Buffer.birch"
      this->values = birch::stack(this->values.value(), x);
    } else {
      #line 480 "src/data/Buffer.birch"
      libbirch_line_(480);
      #line 480 "src/data/Buffer.birch"
      this->values = libbirch::make_array_from_sequence({ this->move(), x });
    }
  }
}

#line 524 "src/data/Buffer.birch"
void birch::type::Buffer::push(const birch::type::String& key, const libbirch::Shared<birch::type::Buffer>& x) {
  #line 524 "src/data/Buffer.birch"
  libbirch_function_("push", "src/data/Buffer.birch", 524);
  #line 525 "src/data/Buffer.birch"
  libbirch_line_(525);
  #line 525 "src/data/Buffer.birch"
  auto buffer = this->get(key);
  #line 526 "src/data/Buffer.birch"
  libbirch_line_(526);
  #line 526 "src/data/Buffer.birch"
  if (!(buffer.has_value())) {
    #line 527 "src/data/Buffer.birch"
    libbirch_line_(527);
    #line 527 "src/data/Buffer.birch"
    buffer = birch::Buffer();
    #line 528 "src/data/Buffer.birch"
    libbirch_line_(528);
    #line 528 "src/data/Buffer.birch"
    this->set(key, buffer.value());
  }
  #line 530 "src/data/Buffer.birch"
  libbirch_line_(530);
  #line 530 "src/data/Buffer.birch"
  buffer.value()->push(x);
}

#line 536 "src/data/Buffer.birch"
void birch::type::Buffer::pushNil() {
  #line 536 "src/data/Buffer.birch"
  libbirch_function_("pushNil", "src/data/Buffer.birch", 536);
  #line 537 "src/data/Buffer.birch"
  libbirch_line_(537);
  #line 537 "src/data/Buffer.birch"
  this->push(birch::Buffer());
}

#line 545 "src/data/Buffer.birch"
void birch::type::Buffer::pushNil(const birch::type::String& key) {
  #line 545 "src/data/Buffer.birch"
  libbirch_function_("pushNil", "src/data/Buffer.birch", 545);
  #line 546 "src/data/Buffer.birch"
  libbirch_line_(546);
  #line 546 "src/data/Buffer.birch"
  this->push(key, birch::Buffer());
}

#line 549 "src/data/Buffer.birch"
void birch::type::Buffer::accept(const libbirch::Shared<birch::type::Writer>& writer) {
  #line 549 "src/data/Buffer.birch"
  libbirch_function_("accept", "src/data/Buffer.birch", 549);
  #line 550 "src/data/Buffer.birch"
  libbirch_line_(550);
  #line 550 "src/data/Buffer.birch"
  if (this->keys.has_value()) {
    #line 551 "src/data/Buffer.birch"
    libbirch_line_(551);
    #line 551 "src/data/Buffer.birch"
    writer->visit(this->keys.value(), this->values.value());
  } else {
    #line 552 "src/data/Buffer.birch"
    libbirch_line_(552);
    #line 552 "src/data/Buffer.birch"
    if (this->values.has_value()) {
      #line 553 "src/data/Buffer.birch"
      libbirch_line_(553);
      #line 553 "src/data/Buffer.birch"
      writer->visit(this->values.value());
    } else {
      #line 554 "src/data/Buffer.birch"
      libbirch_line_(554);
      #line 554 "src/data/Buffer.birch"
      if (this->scalarString.has_value()) {
        #line 555 "src/data/Buffer.birch"
        libbirch_line_(555);
        #line 555 "src/data/Buffer.birch"
        writer->visit(this->scalarString.value());
      } else {
        #line 556 "src/data/Buffer.birch"
        libbirch_line_(556);
        #line 556 "src/data/Buffer.birch"
        if (this->scalarReal.has_value()) {
          #line 557 "src/data/Buffer.birch"
          libbirch_line_(557);
          #line 557 "src/data/Buffer.birch"
          writer->visit(this->scalarReal.value());
        } else {
          #line 558 "src/data/Buffer.birch"
          libbirch_line_(558);
          #line 558 "src/data/Buffer.birch"
          if (this->scalarInteger.has_value()) {
            #line 559 "src/data/Buffer.birch"
            libbirch_line_(559);
            #line 559 "src/data/Buffer.birch"
            writer->visit(this->scalarInteger.value());
          } else {
            #line 560 "src/data/Buffer.birch"
            libbirch_line_(560);
            #line 560 "src/data/Buffer.birch"
            if (this->scalarBoolean.has_value()) {
              #line 561 "src/data/Buffer.birch"
              libbirch_line_(561);
              #line 561 "src/data/Buffer.birch"
              writer->visit(this->scalarBoolean.value());
            } else {
              #line 562 "src/data/Buffer.birch"
              libbirch_line_(562);
              #line 562 "src/data/Buffer.birch"
              if (this->vectorReal.has_value()) {
                #line 563 "src/data/Buffer.birch"
                libbirch_line_(563);
                #line 563 "src/data/Buffer.birch"
                writer->visit(this->vectorReal.value());
              } else {
                #line 564 "src/data/Buffer.birch"
                libbirch_line_(564);
                #line 564 "src/data/Buffer.birch"
                if (this->vectorInteger.has_value()) {
                  #line 565 "src/data/Buffer.birch"
                  libbirch_line_(565);
                  #line 565 "src/data/Buffer.birch"
                  writer->visit(this->vectorInteger.value());
                } else {
                  #line 566 "src/data/Buffer.birch"
                  libbirch_line_(566);
                  #line 566 "src/data/Buffer.birch"
                  if (this->vectorBoolean.has_value()) {
                    #line 567 "src/data/Buffer.birch"
                    libbirch_line_(567);
                    #line 567 "src/data/Buffer.birch"
                    writer->visit(this->vectorBoolean.value());
                  } else {
                    #line 568 "src/data/Buffer.birch"
                    libbirch_line_(568);
                    #line 568 "src/data/Buffer.birch"
                    if (this->matrixReal.has_value()) {
                      #line 569 "src/data/Buffer.birch"
                      libbirch_line_(569);
                      #line 569 "src/data/Buffer.birch"
                      writer->visit(this->matrixReal.value());
                    } else {
                      #line 570 "src/data/Buffer.birch"
                      libbirch_line_(570);
                      #line 570 "src/data/Buffer.birch"
                      if (this->matrixInteger.has_value()) {
                        #line 571 "src/data/Buffer.birch"
                        libbirch_line_(571);
                        #line 571 "src/data/Buffer.birch"
                        writer->visit(this->matrixInteger.value());
                      } else {
                        #line 572 "src/data/Buffer.birch"
                        libbirch_line_(572);
                        #line 572 "src/data/Buffer.birch"
                        if (this->matrixBoolean.has_value()) {
                          #line 573 "src/data/Buffer.birch"
                          libbirch_line_(573);
                          #line 573 "src/data/Buffer.birch"
                          writer->visit(this->matrixBoolean.value());
                        } else {
                          #line 575 "src/data/Buffer.birch"
                          libbirch_line_(575);
                          #line 575 "src/data/Buffer.birch"
                          writer->visitNil();
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

#line 579 "src/data/Buffer.birch"
std::optional<birch::type::Boolean> birch::type::Buffer::doGet(const std::optional<birch::type::Boolean>& x) {
  #line 579 "src/data/Buffer.birch"
  libbirch_function_("doGet", "src/data/Buffer.birch", 579);
  #line 580 "src/data/Buffer.birch"
  libbirch_line_(580);
  #line 580 "src/data/Buffer.birch"
  if (this->scalarBoolean.has_value()) {
    #line 581 "src/data/Buffer.birch"
    libbirch_line_(581);
    #line 581 "src/data/Buffer.birch"
    return birch::Boolean(this->scalarBoolean.value());
  } else {
    #line 582 "src/data/Buffer.birch"
    libbirch_line_(582);
    #line 582 "src/data/Buffer.birch"
    if (this->scalarInteger.has_value()) {
      #line 583 "src/data/Buffer.birch"
      libbirch_line_(583);
      #line 583 "src/data/Buffer.birch"
      return birch::Boolean(this->scalarInteger.value());
    } else {
      #line 584 "src/data/Buffer.birch"
      libbirch_line_(584);
      #line 584 "src/data/Buffer.birch"
      if (this->scalarReal.has_value()) {
        #line 585 "src/data/Buffer.birch"
        libbirch_line_(585);
        #line 585 "src/data/Buffer.birch"
        return birch::Boolean(this->scalarReal.value());
      } else {
        #line 586 "src/data/Buffer.birch"
        libbirch_line_(586);
        #line 586 "src/data/Buffer.birch"
        if (this->scalarString.has_value()) {
          #line 587 "src/data/Buffer.birch"
          libbirch_line_(587);
          #line 587 "src/data/Buffer.birch"
          return birch::Boolean(this->scalarString.value());
        } else {
          #line 589 "src/data/Buffer.birch"
          libbirch_line_(589);
          #line 589 "src/data/Buffer.birch"
          return std::nullopt;
        }
      }
    }
  }
}

#line 593 "src/data/Buffer.birch"
std::optional<birch::type::Integer> birch::type::Buffer::doGet(const std::optional<birch::type::Integer>& x) {
  #line 593 "src/data/Buffer.birch"
  libbirch_function_("doGet", "src/data/Buffer.birch", 593);
  #line 594 "src/data/Buffer.birch"
  libbirch_line_(594);
  #line 594 "src/data/Buffer.birch"
  if (this->scalarBoolean.has_value()) {
    #line 595 "src/data/Buffer.birch"
    libbirch_line_(595);
    #line 595 "src/data/Buffer.birch"
    return birch::Integer(this->scalarBoolean.value());
  } else {
    #line 596 "src/data/Buffer.birch"
    libbirch_line_(596);
    #line 596 "src/data/Buffer.birch"
    if (this->scalarInteger.has_value()) {
      #line 597 "src/data/Buffer.birch"
      libbirch_line_(597);
      #line 597 "src/data/Buffer.birch"
      return birch::Integer(this->scalarInteger.value());
    } else {
      #line 598 "src/data/Buffer.birch"
      libbirch_line_(598);
      #line 598 "src/data/Buffer.birch"
      if (this->scalarReal.has_value()) {
        #line 599 "src/data/Buffer.birch"
        libbirch_line_(599);
        #line 599 "src/data/Buffer.birch"
        return birch::Integer(this->scalarReal.value());
      } else {
        #line 600 "src/data/Buffer.birch"
        libbirch_line_(600);
        #line 600 "src/data/Buffer.birch"
        if (this->scalarString.has_value()) {
          #line 601 "src/data/Buffer.birch"
          libbirch_line_(601);
          #line 601 "src/data/Buffer.birch"
          return birch::Integer(this->scalarString.value());
        } else {
          #line 603 "src/data/Buffer.birch"
          libbirch_line_(603);
          #line 603 "src/data/Buffer.birch"
          return std::nullopt;
        }
      }
    }
  }
}

#line 607 "src/data/Buffer.birch"
std::optional<birch::type::Real> birch::type::Buffer::doGet(const std::optional<birch::type::Real>& x) {
  #line 607 "src/data/Buffer.birch"
  libbirch_function_("doGet", "src/data/Buffer.birch", 607);
  #line 608 "src/data/Buffer.birch"
  libbirch_line_(608);
  #line 608 "src/data/Buffer.birch"
  if (this->scalarBoolean.has_value()) {
    #line 609 "src/data/Buffer.birch"
    libbirch_line_(609);
    #line 609 "src/data/Buffer.birch"
    return birch::Real(this->scalarBoolean.value());
  } else {
    #line 610 "src/data/Buffer.birch"
    libbirch_line_(610);
    #line 610 "src/data/Buffer.birch"
    if (this->scalarInteger.has_value()) {
      #line 611 "src/data/Buffer.birch"
      libbirch_line_(611);
      #line 611 "src/data/Buffer.birch"
      return birch::Real(this->scalarInteger.value());
    } else {
      #line 612 "src/data/Buffer.birch"
      libbirch_line_(612);
      #line 612 "src/data/Buffer.birch"
      if (this->scalarReal.has_value()) {
        #line 613 "src/data/Buffer.birch"
        libbirch_line_(613);
        #line 613 "src/data/Buffer.birch"
        return birch::Real(this->scalarReal.value());
      } else {
        #line 614 "src/data/Buffer.birch"
        libbirch_line_(614);
        #line 614 "src/data/Buffer.birch"
        if (this->scalarString.has_value()) {
          #line 615 "src/data/Buffer.birch"
          libbirch_line_(615);
          #line 615 "src/data/Buffer.birch"
          return birch::Real(this->scalarString.value());
        } else {
          #line 617 "src/data/Buffer.birch"
          libbirch_line_(617);
          #line 617 "src/data/Buffer.birch"
          return std::nullopt;
        }
      }
    }
  }
}

#line 621 "src/data/Buffer.birch"
std::optional<birch::type::String> birch::type::Buffer::doGet(const std::optional<birch::type::String>& x) {
  #line 621 "src/data/Buffer.birch"
  libbirch_function_("doGet", "src/data/Buffer.birch", 621);
  #line 622 "src/data/Buffer.birch"
  libbirch_line_(622);
  #line 622 "src/data/Buffer.birch"
  if (this->scalarBoolean.has_value()) {
    #line 623 "src/data/Buffer.birch"
    libbirch_line_(623);
    #line 623 "src/data/Buffer.birch"
    return birch::String(this->scalarBoolean.value());
  } else {
    #line 624 "src/data/Buffer.birch"
    libbirch_line_(624);
    #line 624 "src/data/Buffer.birch"
    if (this->scalarInteger.has_value()) {
      #line 625 "src/data/Buffer.birch"
      libbirch_line_(625);
      #line 625 "src/data/Buffer.birch"
      return birch::String(this->scalarInteger.value());
    } else {
      #line 626 "src/data/Buffer.birch"
      libbirch_line_(626);
      #line 626 "src/data/Buffer.birch"
      if (this->scalarReal.has_value()) {
        #line 627 "src/data/Buffer.birch"
        libbirch_line_(627);
        #line 627 "src/data/Buffer.birch"
        return birch::String(this->scalarReal.value());
      } else {
        #line 628 "src/data/Buffer.birch"
        libbirch_line_(628);
        #line 628 "src/data/Buffer.birch"
        if (this->scalarString.has_value()) {
          #line 629 "src/data/Buffer.birch"
          libbirch_line_(629);
          #line 629 "src/data/Buffer.birch"
          return birch::String(this->scalarString.value());
        } else {
          #line 631 "src/data/Buffer.birch"
          libbirch_line_(631);
          #line 631 "src/data/Buffer.birch"
          return std::nullopt;
        }
      }
    }
  }
}

#line 639 "src/data/Buffer.birch"
std::optional<libbirch::DefaultArray<birch::type::Boolean,1>> birch::type::Buffer::doGet(const std::optional<libbirch::DefaultArray<birch::type::Boolean,1>>& x) {
  #line 639 "src/data/Buffer.birch"
  libbirch_function_("doGet", "src/data/Buffer.birch", 639);
  #line 640 "src/data/Buffer.birch"
  libbirch_line_(640);
  #line 640 "src/data/Buffer.birch"
  if (this->vectorBoolean.has_value()) {
    #line 641 "src/data/Buffer.birch"
    libbirch_line_(641);
    #line 641 "src/data/Buffer.birch"
    return birch::Boolean(this->vectorBoolean.value());
  } else {
    #line 642 "src/data/Buffer.birch"
    libbirch_line_(642);
    #line 642 "src/data/Buffer.birch"
    if (this->vectorInteger.has_value()) {
      #line 643 "src/data/Buffer.birch"
      libbirch_line_(643);
      #line 643 "src/data/Buffer.birch"
      return birch::Boolean(this->vectorInteger.value());
    } else {
      #line 644 "src/data/Buffer.birch"
      libbirch_line_(644);
      #line 644 "src/data/Buffer.birch"
      if (this->vectorReal.has_value()) {
        #line 645 "src/data/Buffer.birch"
        libbirch_line_(645);
        #line 645 "src/data/Buffer.birch"
        return birch::Boolean(this->vectorReal.value());
      } else {
        #line 647 "src/data/Buffer.birch"
        libbirch_line_(647);
        #line 647 "src/data/Buffer.birch"
        return this->doGetVector<birch::type::Boolean>();
      }
    }
  }
}

#line 651 "src/data/Buffer.birch"
std::optional<libbirch::DefaultArray<birch::type::Integer,1>> birch::type::Buffer::doGet(const std::optional<libbirch::DefaultArray<birch::type::Integer,1>>& x) {
  #line 651 "src/data/Buffer.birch"
  libbirch_function_("doGet", "src/data/Buffer.birch", 651);
  #line 652 "src/data/Buffer.birch"
  libbirch_line_(652);
  #line 652 "src/data/Buffer.birch"
  if (this->vectorBoolean.has_value()) {
    #line 653 "src/data/Buffer.birch"
    libbirch_line_(653);
    #line 653 "src/data/Buffer.birch"
    return birch::Integer(this->vectorBoolean.value());
  } else {
    #line 654 "src/data/Buffer.birch"
    libbirch_line_(654);
    #line 654 "src/data/Buffer.birch"
    if (this->vectorInteger.has_value()) {
      #line 655 "src/data/Buffer.birch"
      libbirch_line_(655);
      #line 655 "src/data/Buffer.birch"
      return birch::Integer(this->vectorInteger.value());
    } else {
      #line 656 "src/data/Buffer.birch"
      libbirch_line_(656);
      #line 656 "src/data/Buffer.birch"
      if (this->vectorReal.has_value()) {
        #line 657 "src/data/Buffer.birch"
        libbirch_line_(657);
        #line 657 "src/data/Buffer.birch"
        return birch::Integer(this->vectorReal.value());
      } else {
        #line 659 "src/data/Buffer.birch"
        libbirch_line_(659);
        #line 659 "src/data/Buffer.birch"
        return this->doGetVector<birch::type::Integer>();
      }
    }
  }
}

#line 663 "src/data/Buffer.birch"
std::optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::Buffer::doGet(const std::optional<libbirch::DefaultArray<birch::type::Real,1>>& x) {
  #line 663 "src/data/Buffer.birch"
  libbirch_function_("doGet", "src/data/Buffer.birch", 663);
  #line 664 "src/data/Buffer.birch"
  libbirch_line_(664);
  #line 664 "src/data/Buffer.birch"
  if (this->vectorBoolean.has_value()) {
    #line 665 "src/data/Buffer.birch"
    libbirch_line_(665);
    #line 665 "src/data/Buffer.birch"
    return birch::Real(this->vectorBoolean.value());
  } else {
    #line 666 "src/data/Buffer.birch"
    libbirch_line_(666);
    #line 666 "src/data/Buffer.birch"
    if (this->vectorInteger.has_value()) {
      #line 667 "src/data/Buffer.birch"
      libbirch_line_(667);
      #line 667 "src/data/Buffer.birch"
      return birch::Real(this->vectorInteger.value());
    } else {
      #line 668 "src/data/Buffer.birch"
      libbirch_line_(668);
      #line 668 "src/data/Buffer.birch"
      if (this->vectorReal.has_value()) {
        #line 669 "src/data/Buffer.birch"
        libbirch_line_(669);
        #line 669 "src/data/Buffer.birch"
        return birch::Real(this->vectorReal.value());
      } else {
        #line 671 "src/data/Buffer.birch"
        libbirch_line_(671);
        #line 671 "src/data/Buffer.birch"
        return this->doGetVector<birch::type::Real>();
      }
    }
  }
}

#line 699 "src/data/Buffer.birch"
std::optional<libbirch::DefaultArray<birch::type::Boolean,2>> birch::type::Buffer::doGet(const std::optional<libbirch::DefaultArray<birch::type::Boolean,2>>& x) {
  #line 699 "src/data/Buffer.birch"
  libbirch_function_("doGet", "src/data/Buffer.birch", 699);
  #line 700 "src/data/Buffer.birch"
  libbirch_line_(700);
  #line 700 "src/data/Buffer.birch"
  if (this->matrixBoolean.has_value()) {
    #line 701 "src/data/Buffer.birch"
    libbirch_line_(701);
    #line 701 "src/data/Buffer.birch"
    return birch::Boolean(this->matrixBoolean.value());
  } else {
    #line 702 "src/data/Buffer.birch"
    libbirch_line_(702);
    #line 702 "src/data/Buffer.birch"
    if (this->matrixInteger.has_value()) {
      #line 703 "src/data/Buffer.birch"
      libbirch_line_(703);
      #line 703 "src/data/Buffer.birch"
      return birch::Boolean(this->matrixInteger.value());
    } else {
      #line 704 "src/data/Buffer.birch"
      libbirch_line_(704);
      #line 704 "src/data/Buffer.birch"
      if (this->matrixReal.has_value()) {
        #line 705 "src/data/Buffer.birch"
        libbirch_line_(705);
        #line 705 "src/data/Buffer.birch"
        return birch::Boolean(this->matrixReal.value());
      } else {
        #line 707 "src/data/Buffer.birch"
        libbirch_line_(707);
        #line 707 "src/data/Buffer.birch"
        return this->doGetMatrix<birch::type::Boolean>();
      }
    }
  }
}

#line 711 "src/data/Buffer.birch"
std::optional<libbirch::DefaultArray<birch::type::Integer,2>> birch::type::Buffer::doGet(const std::optional<libbirch::DefaultArray<birch::type::Integer,2>>& x) {
  #line 711 "src/data/Buffer.birch"
  libbirch_function_("doGet", "src/data/Buffer.birch", 711);
  #line 712 "src/data/Buffer.birch"
  libbirch_line_(712);
  #line 712 "src/data/Buffer.birch"
  if (this->matrixBoolean.has_value()) {
    #line 713 "src/data/Buffer.birch"
    libbirch_line_(713);
    #line 713 "src/data/Buffer.birch"
    return birch::Integer(this->matrixBoolean.value());
  } else {
    #line 714 "src/data/Buffer.birch"
    libbirch_line_(714);
    #line 714 "src/data/Buffer.birch"
    if (this->matrixInteger.has_value()) {
      #line 715 "src/data/Buffer.birch"
      libbirch_line_(715);
      #line 715 "src/data/Buffer.birch"
      return birch::Integer(this->matrixInteger.value());
    } else {
      #line 716 "src/data/Buffer.birch"
      libbirch_line_(716);
      #line 716 "src/data/Buffer.birch"
      if (this->matrixReal.has_value()) {
        #line 717 "src/data/Buffer.birch"
        libbirch_line_(717);
        #line 717 "src/data/Buffer.birch"
        return birch::Integer(this->matrixReal.value());
      } else {
        #line 719 "src/data/Buffer.birch"
        libbirch_line_(719);
        #line 719 "src/data/Buffer.birch"
        return this->doGetMatrix<birch::type::Integer>();
      }
    }
  }
}

#line 723 "src/data/Buffer.birch"
std::optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::Buffer::doGet(const std::optional<libbirch::DefaultArray<birch::type::Real,2>>& x) {
  #line 723 "src/data/Buffer.birch"
  libbirch_function_("doGet", "src/data/Buffer.birch", 723);
  #line 724 "src/data/Buffer.birch"
  libbirch_line_(724);
  #line 724 "src/data/Buffer.birch"
  if (this->matrixBoolean.has_value()) {
    #line 725 "src/data/Buffer.birch"
    libbirch_line_(725);
    #line 725 "src/data/Buffer.birch"
    return birch::Real(this->matrixBoolean.value());
  } else {
    #line 726 "src/data/Buffer.birch"
    libbirch_line_(726);
    #line 726 "src/data/Buffer.birch"
    if (this->matrixInteger.has_value()) {
      #line 727 "src/data/Buffer.birch"
      libbirch_line_(727);
      #line 727 "src/data/Buffer.birch"
      return birch::Real(this->matrixInteger.value());
    } else {
      #line 728 "src/data/Buffer.birch"
      libbirch_line_(728);
      #line 728 "src/data/Buffer.birch"
      if (this->matrixReal.has_value()) {
        #line 729 "src/data/Buffer.birch"
        libbirch_line_(729);
        #line 729 "src/data/Buffer.birch"
        return birch::Real(this->matrixReal.value());
      } else {
        #line 731 "src/data/Buffer.birch"
        libbirch_line_(731);
        #line 731 "src/data/Buffer.birch"
        return this->doGetMatrix<birch::type::Real>();
      }
    }
  }
}

#line 739 "src/data/Buffer.birch"
std::optional<birch::type::LLT> birch::type::Buffer::doGet(const std::optional<birch::type::LLT>& x) {
  #line 739 "src/data/Buffer.birch"
  libbirch_function_("doGet", "src/data/Buffer.birch", 739);
  #line 740 "src/data/Buffer.birch"
  libbirch_line_(740);
  #line 740 "src/data/Buffer.birch"
  auto y = this->doGetMatrix<birch::type::Real>();
  #line 741 "src/data/Buffer.birch"
  libbirch_line_(741);
  #line 741 "src/data/Buffer.birch"
  if (y.has_value()) {
    #line 742 "src/data/Buffer.birch"
    libbirch_line_(742);
    #line 742 "src/data/Buffer.birch"
    return birch::llt(y.value());
  } else {
    #line 744 "src/data/Buffer.birch"
    libbirch_line_(744);
    #line 744 "src/data/Buffer.birch"
    return std::nullopt;
  }
}

#line 777 "src/data/Buffer.birch"
void birch::type::Buffer::doSet(const birch::type::Boolean& x) {
  #line 777 "src/data/Buffer.birch"
  libbirch_function_("doSet", "src/data/Buffer.birch", 777);
  #line 778 "src/data/Buffer.birch"
  libbirch_line_(778);
  #line 778 "src/data/Buffer.birch"
  this->setNil();
  #line 779 "src/data/Buffer.birch"
  libbirch_line_(779);
  #line 779 "src/data/Buffer.birch"
  this->scalarBoolean = x;
}

#line 782 "src/data/Buffer.birch"
void birch::type::Buffer::doSet(const birch::type::Integer& x) {
  #line 782 "src/data/Buffer.birch"
  libbirch_function_("doSet", "src/data/Buffer.birch", 782);
  #line 783 "src/data/Buffer.birch"
  libbirch_line_(783);
  #line 783 "src/data/Buffer.birch"
  this->setNil();
  #line 784 "src/data/Buffer.birch"
  libbirch_line_(784);
  #line 784 "src/data/Buffer.birch"
  this->scalarInteger = x;
}

#line 787 "src/data/Buffer.birch"
void birch::type::Buffer::doSet(const birch::type::Real& x) {
  #line 787 "src/data/Buffer.birch"
  libbirch_function_("doSet", "src/data/Buffer.birch", 787);
  #line 788 "src/data/Buffer.birch"
  libbirch_line_(788);
  #line 788 "src/data/Buffer.birch"
  this->setNil();
  #line 789 "src/data/Buffer.birch"
  libbirch_line_(789);
  #line 789 "src/data/Buffer.birch"
  this->scalarReal = x;
}

#line 792 "src/data/Buffer.birch"
void birch::type::Buffer::doSet(const birch::type::String& x) {
  #line 792 "src/data/Buffer.birch"
  libbirch_function_("doSet", "src/data/Buffer.birch", 792);
  #line 793 "src/data/Buffer.birch"
  libbirch_line_(793);
  #line 793 "src/data/Buffer.birch"
  this->setNil();
  #line 794 "src/data/Buffer.birch"
  libbirch_line_(794);
  #line 794 "src/data/Buffer.birch"
  this->scalarString = x;
}

#line 807 "src/data/Buffer.birch"
void birch::type::Buffer::doSet(const libbirch::DefaultArray<birch::type::Boolean,1>& x) {
  #line 807 "src/data/Buffer.birch"
  libbirch_function_("doSet", "src/data/Buffer.birch", 807);
  #line 808 "src/data/Buffer.birch"
  libbirch_line_(808);
  #line 808 "src/data/Buffer.birch"
  this->setNil();
  #line 809 "src/data/Buffer.birch"
  libbirch_line_(809);
  #line 809 "src/data/Buffer.birch"
  this->vectorBoolean = x;
}

#line 812 "src/data/Buffer.birch"
void birch::type::Buffer::doSet(const libbirch::DefaultArray<birch::type::Integer,1>& x) {
  #line 812 "src/data/Buffer.birch"
  libbirch_function_("doSet", "src/data/Buffer.birch", 812);
  #line 813 "src/data/Buffer.birch"
  libbirch_line_(813);
  #line 813 "src/data/Buffer.birch"
  this->setNil();
  #line 814 "src/data/Buffer.birch"
  libbirch_line_(814);
  #line 814 "src/data/Buffer.birch"
  this->vectorInteger = x;
}

#line 817 "src/data/Buffer.birch"
void birch::type::Buffer::doSet(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 817 "src/data/Buffer.birch"
  libbirch_function_("doSet", "src/data/Buffer.birch", 817);
  #line 818 "src/data/Buffer.birch"
  libbirch_line_(818);
  #line 818 "src/data/Buffer.birch"
  this->setNil();
  #line 819 "src/data/Buffer.birch"
  libbirch_line_(819);
  #line 819 "src/data/Buffer.birch"
  this->vectorReal = x;
}

#line 836 "src/data/Buffer.birch"
void birch::type::Buffer::doSet(const libbirch::DefaultArray<birch::type::Boolean,2>& x) {
  #line 836 "src/data/Buffer.birch"
  libbirch_function_("doSet", "src/data/Buffer.birch", 836);
  #line 837 "src/data/Buffer.birch"
  libbirch_line_(837);
  #line 837 "src/data/Buffer.birch"
  this->setNil();
  #line 838 "src/data/Buffer.birch"
  libbirch_line_(838);
  #line 838 "src/data/Buffer.birch"
  this->matrixBoolean = x;
}

#line 841 "src/data/Buffer.birch"
void birch::type::Buffer::doSet(const libbirch::DefaultArray<birch::type::Integer,2>& x) {
  #line 841 "src/data/Buffer.birch"
  libbirch_function_("doSet", "src/data/Buffer.birch", 841);
  #line 842 "src/data/Buffer.birch"
  libbirch_line_(842);
  #line 842 "src/data/Buffer.birch"
  this->setNil();
  #line 843 "src/data/Buffer.birch"
  libbirch_line_(843);
  #line 843 "src/data/Buffer.birch"
  this->matrixInteger = x;
}

#line 846 "src/data/Buffer.birch"
void birch::type::Buffer::doSet(const libbirch::DefaultArray<birch::type::Real,2>& x) {
  #line 846 "src/data/Buffer.birch"
  libbirch_function_("doSet", "src/data/Buffer.birch", 846);
  #line 847 "src/data/Buffer.birch"
  libbirch_line_(847);
  #line 847 "src/data/Buffer.birch"
  this->setNil();
  #line 848 "src/data/Buffer.birch"
  libbirch_line_(848);
  #line 848 "src/data/Buffer.birch"
  this->matrixReal = x;
}

#line 851 "src/data/Buffer.birch"
void birch::type::Buffer::doSet(const birch::type::LLT& x) {
  #line 851 "src/data/Buffer.birch"
  libbirch_function_("doSet", "src/data/Buffer.birch", 851);
  #line 852 "src/data/Buffer.birch"
  libbirch_line_(852);
  #line 852 "src/data/Buffer.birch"
  this->setNil();
  #line 853 "src/data/Buffer.birch"
  libbirch_line_(853);
  #line 853 "src/data/Buffer.birch"
  this->matrixReal = birch::canonical(x);
}

#line 856 "src/data/Buffer.birch"
void birch::type::Buffer::doPush(const birch::type::Boolean& x) {
  #line 856 "src/data/Buffer.birch"
  libbirch_function_("doPush", "src/data/Buffer.birch", 856);
  #line 857 "src/data/Buffer.birch"
  libbirch_line_(857);
  #line 857 "src/data/Buffer.birch"
  if (this->isEmpty()) {
    #line 858 "src/data/Buffer.birch"
    libbirch_line_(858);
    #line 858 "src/data/Buffer.birch"
    this->set(x);
  } else {
    #line 859 "src/data/Buffer.birch"
    libbirch_line_(859);
    #line 859 "src/data/Buffer.birch"
    if (this->scalarBoolean.has_value()) {
      #line 860 "src/data/Buffer.birch"
      libbirch_line_(860);
      #line 860 "src/data/Buffer.birch"
      this->set(libbirch::make_array_from_sequence({ this->scalarBoolean.value(), x }));
    } else {
      #line 861 "src/data/Buffer.birch"
      libbirch_line_(861);
      #line 861 "src/data/Buffer.birch"
      if (this->scalarInteger.has_value()) {
        #line 862 "src/data/Buffer.birch"
        libbirch_line_(862);
        #line 862 "src/data/Buffer.birch"
        this->set(libbirch::make_array_from_sequence({ this->scalarInteger.value(), birch::Integer(x) }));
      } else {
        #line 863 "src/data/Buffer.birch"
        libbirch_line_(863);
        #line 863 "src/data/Buffer.birch"
        if (this->scalarReal.has_value()) {
          #line 864 "src/data/Buffer.birch"
          libbirch_line_(864);
          #line 864 "src/data/Buffer.birch"
          this->set(libbirch::make_array_from_sequence({ this->scalarReal.value(), birch::Real(x) }));
        } else {
          #line 865 "src/data/Buffer.birch"
          libbirch_line_(865);
          #line 865 "src/data/Buffer.birch"
          if (this->vectorBoolean.has_value()) {
            #line 866 "src/data/Buffer.birch"

      vectorBoolean.value().push(x);
                } else {
            #line 869 "src/data/Buffer.birch"
            libbirch_line_(869);
            #line 869 "src/data/Buffer.birch"
            if (this->vectorInteger.has_value()) {
              #line 870 "src/data/Buffer.birch"
              libbirch_line_(870);
              #line 870 "src/data/Buffer.birch"
              this->push(birch::Integer(x));
            } else {
              #line 871 "src/data/Buffer.birch"
              libbirch_line_(871);
              #line 871 "src/data/Buffer.birch"
              if (this->vectorReal.has_value()) {
                #line 872 "src/data/Buffer.birch"
                libbirch_line_(872);
                #line 872 "src/data/Buffer.birch"
                this->push(birch::Real(x));
              } else {
                #line 874 "src/data/Buffer.birch"
                libbirch_line_(874);
                #line 874 "src/data/Buffer.birch"
                this->push(birch::Buffer(x));
              }
            }
          }
        }
      }
    }
  }
}

#line 878 "src/data/Buffer.birch"
void birch::type::Buffer::doPush(const birch::type::Integer& x) {
  #line 878 "src/data/Buffer.birch"
  libbirch_function_("doPush", "src/data/Buffer.birch", 878);
  #line 879 "src/data/Buffer.birch"
  libbirch_line_(879);
  #line 879 "src/data/Buffer.birch"
  if (this->isEmpty()) {
    #line 880 "src/data/Buffer.birch"
    libbirch_line_(880);
    #line 880 "src/data/Buffer.birch"
    this->set(x);
  } else {
    #line 881 "src/data/Buffer.birch"
    libbirch_line_(881);
    #line 881 "src/data/Buffer.birch"
    if (this->scalarBoolean.has_value()) {
      #line 882 "src/data/Buffer.birch"
      libbirch_line_(882);
      #line 882 "src/data/Buffer.birch"
      this->set(libbirch::make_array_from_sequence({ birch::Integer(this->scalarBoolean.value()), x }));
    } else {
      #line 883 "src/data/Buffer.birch"
      libbirch_line_(883);
      #line 883 "src/data/Buffer.birch"
      if (this->scalarInteger.has_value()) {
        #line 884 "src/data/Buffer.birch"
        libbirch_line_(884);
        #line 884 "src/data/Buffer.birch"
        this->set(libbirch::make_array_from_sequence({ this->scalarInteger.value(), x }));
      } else {
        #line 885 "src/data/Buffer.birch"
        libbirch_line_(885);
        #line 885 "src/data/Buffer.birch"
        if (this->scalarReal.has_value()) {
          #line 886 "src/data/Buffer.birch"
          libbirch_line_(886);
          #line 886 "src/data/Buffer.birch"
          this->set(libbirch::make_array_from_sequence({ this->scalarReal.value(), birch::Real(x) }));
        } else {
          #line 887 "src/data/Buffer.birch"
          libbirch_line_(887);
          #line 887 "src/data/Buffer.birch"
          if (this->vectorBoolean.has_value()) {
            #line 888 "src/data/Buffer.birch"
            libbirch_line_(888);
            #line 888 "src/data/Buffer.birch"
            this->set(birch::stack(birch::Integer(this->vectorBoolean.value()), x));
          } else {
            #line 889 "src/data/Buffer.birch"
            libbirch_line_(889);
            #line 889 "src/data/Buffer.birch"
            if (this->vectorInteger.has_value()) {
              #line 890 "src/data/Buffer.birch"

      vectorInteger.value().push(x);
                  } else {
              #line 893 "src/data/Buffer.birch"
              libbirch_line_(893);
              #line 893 "src/data/Buffer.birch"
              if (this->vectorReal.has_value()) {
                #line 894 "src/data/Buffer.birch"
                libbirch_line_(894);
                #line 894 "src/data/Buffer.birch"
                this->push(birch::Real(x));
              } else {
                #line 896 "src/data/Buffer.birch"
                libbirch_line_(896);
                #line 896 "src/data/Buffer.birch"
                this->push(birch::Buffer(x));
              }
            }
          }
        }
      }
    }
  }
}

#line 900 "src/data/Buffer.birch"
void birch::type::Buffer::doPush(const birch::type::Real& x) {
  #line 900 "src/data/Buffer.birch"
  libbirch_function_("doPush", "src/data/Buffer.birch", 900);
  #line 901 "src/data/Buffer.birch"
  libbirch_line_(901);
  #line 901 "src/data/Buffer.birch"
  if (this->isEmpty()) {
    #line 902 "src/data/Buffer.birch"
    libbirch_line_(902);
    #line 902 "src/data/Buffer.birch"
    this->set(x);
  } else {
    #line 903 "src/data/Buffer.birch"
    libbirch_line_(903);
    #line 903 "src/data/Buffer.birch"
    if (this->scalarBoolean.has_value()) {
      #line 904 "src/data/Buffer.birch"
      libbirch_line_(904);
      #line 904 "src/data/Buffer.birch"
      this->set(libbirch::make_array_from_sequence({ birch::Real(this->scalarBoolean.value()), x }));
    } else {
      #line 905 "src/data/Buffer.birch"
      libbirch_line_(905);
      #line 905 "src/data/Buffer.birch"
      if (this->scalarInteger.has_value()) {
        #line 906 "src/data/Buffer.birch"
        libbirch_line_(906);
        #line 906 "src/data/Buffer.birch"
        this->set(libbirch::make_array_from_sequence({ birch::Real(this->scalarInteger.value()), x }));
      } else {
        #line 907 "src/data/Buffer.birch"
        libbirch_line_(907);
        #line 907 "src/data/Buffer.birch"
        if (this->scalarReal.has_value()) {
          #line 908 "src/data/Buffer.birch"
          libbirch_line_(908);
          #line 908 "src/data/Buffer.birch"
          this->set(libbirch::make_array_from_sequence({ this->scalarReal.value(), x }));
        } else {
          #line 909 "src/data/Buffer.birch"
          libbirch_line_(909);
          #line 909 "src/data/Buffer.birch"
          if (this->vectorBoolean.has_value()) {
            #line 910 "src/data/Buffer.birch"
            libbirch_line_(910);
            #line 910 "src/data/Buffer.birch"
            this->set(birch::stack(birch::Real(this->vectorBoolean.value()), x));
          } else {
            #line 911 "src/data/Buffer.birch"
            libbirch_line_(911);
            #line 911 "src/data/Buffer.birch"
            if (this->vectorInteger.has_value()) {
              #line 912 "src/data/Buffer.birch"
              libbirch_line_(912);
              #line 912 "src/data/Buffer.birch"
              this->set(birch::stack(birch::Real(this->vectorInteger.value()), x));
            } else {
              #line 913 "src/data/Buffer.birch"
              libbirch_line_(913);
              #line 913 "src/data/Buffer.birch"
              if (this->vectorReal.has_value()) {
                #line 914 "src/data/Buffer.birch"

      vectorReal.value().push(x);
                    } else {
                #line 918 "src/data/Buffer.birch"
                libbirch_line_(918);
                #line 918 "src/data/Buffer.birch"
                this->push(birch::Buffer(x));
              }
            }
          }
        }
      }
    }
  }
}

#line 922 "src/data/Buffer.birch"
void birch::type::Buffer::doPush(const birch::type::String& x) {
  #line 922 "src/data/Buffer.birch"
  libbirch_function_("doPush", "src/data/Buffer.birch", 922);
  #line 923 "src/data/Buffer.birch"
  libbirch_line_(923);
  #line 923 "src/data/Buffer.birch"
  this->push(birch::Buffer(x));
}

#line 934 "src/data/Buffer.birch"
void birch::type::Buffer::doPush(const libbirch::DefaultArray<birch::type::Boolean,1>& x) {
  #line 934 "src/data/Buffer.birch"
  libbirch_function_("doPush", "src/data/Buffer.birch", 934);
  #line 935 "src/data/Buffer.birch"
  libbirch_line_(935);
  #line 935 "src/data/Buffer.birch"
  if (this->isEmpty()) {
    #line 936 "src/data/Buffer.birch"
    libbirch_line_(936);
    #line 936 "src/data/Buffer.birch"
    this->set(birch::row(x));
  } else {
    #line 937 "src/data/Buffer.birch"
    libbirch_line_(937);
    #line 937 "src/data/Buffer.birch"
    if (this->vectorBoolean.has_value()) {
      #line 938 "src/data/Buffer.birch"
      libbirch_line_(938);
      #line 938 "src/data/Buffer.birch"
      this->set(birch::stack(birch::row(this->vectorBoolean.value()), birch::row(x)));
    } else {
      #line 939 "src/data/Buffer.birch"
      libbirch_line_(939);
      #line 939 "src/data/Buffer.birch"
      if (this->matrixBoolean.has_value()) {
        #line 940 "src/data/Buffer.birch"
        libbirch_line_(940);
        #line 940 "src/data/Buffer.birch"
        this->set(birch::stack(this->matrixBoolean.value(), birch::row(x)));
      } else {
        #line 941 "src/data/Buffer.birch"
        libbirch_line_(941);
        #line 941 "src/data/Buffer.birch"
        if (this->vectorInteger.has_value() || this->matrixInteger.has_value()) {
          #line 942 "src/data/Buffer.birch"
          libbirch_line_(942);
          #line 942 "src/data/Buffer.birch"
          this->push(birch::Integer(x));
        } else {
          #line 943 "src/data/Buffer.birch"
          libbirch_line_(943);
          #line 943 "src/data/Buffer.birch"
          if (this->vectorReal.has_value() || this->matrixReal.has_value()) {
            #line 944 "src/data/Buffer.birch"
            libbirch_line_(944);
            #line 944 "src/data/Buffer.birch"
            this->push(birch::Real(x));
          } else {
            #line 946 "src/data/Buffer.birch"
            libbirch_line_(946);
            #line 946 "src/data/Buffer.birch"
            this->push(birch::Buffer(x));
          }
        }
      }
    }
  }
}

#line 950 "src/data/Buffer.birch"
void birch::type::Buffer::doPush(const libbirch::DefaultArray<birch::type::Integer,1>& x) {
  #line 950 "src/data/Buffer.birch"
  libbirch_function_("doPush", "src/data/Buffer.birch", 950);
  #line 951 "src/data/Buffer.birch"
  libbirch_line_(951);
  #line 951 "src/data/Buffer.birch"
  if (this->isEmpty()) {
    #line 952 "src/data/Buffer.birch"
    libbirch_line_(952);
    #line 952 "src/data/Buffer.birch"
    this->set(birch::row(x));
  } else {
    #line 953 "src/data/Buffer.birch"
    libbirch_line_(953);
    #line 953 "src/data/Buffer.birch"
    if (this->vectorBoolean.has_value()) {
      #line 954 "src/data/Buffer.birch"
      libbirch_line_(954);
      #line 954 "src/data/Buffer.birch"
      this->set(birch::stack(birch::Integer(birch::row(this->vectorBoolean.value())), birch::row(x)));
    } else {
      #line 955 "src/data/Buffer.birch"
      libbirch_line_(955);
      #line 955 "src/data/Buffer.birch"
      if (this->matrixBoolean.has_value()) {
        #line 956 "src/data/Buffer.birch"
        libbirch_line_(956);
        #line 956 "src/data/Buffer.birch"
        this->set(birch::stack(birch::Integer(this->matrixBoolean.value()), birch::row(x)));
      } else {
        #line 957 "src/data/Buffer.birch"
        libbirch_line_(957);
        #line 957 "src/data/Buffer.birch"
        if (this->vectorInteger.has_value()) {
          #line 958 "src/data/Buffer.birch"
          libbirch_line_(958);
          #line 958 "src/data/Buffer.birch"
          this->set(birch::stack(birch::row(this->vectorInteger.value()), birch::row(x)));
        } else {
          #line 959 "src/data/Buffer.birch"
          libbirch_line_(959);
          #line 959 "src/data/Buffer.birch"
          if (this->matrixInteger.has_value()) {
            #line 960 "src/data/Buffer.birch"
            libbirch_line_(960);
            #line 960 "src/data/Buffer.birch"
            this->set(birch::stack(this->matrixInteger.value(), birch::row(x)));
          } else {
            #line 961 "src/data/Buffer.birch"
            libbirch_line_(961);
            #line 961 "src/data/Buffer.birch"
            if (this->vectorReal.has_value() || this->matrixReal.has_value()) {
              #line 962 "src/data/Buffer.birch"
              libbirch_line_(962);
              #line 962 "src/data/Buffer.birch"
              this->push(birch::Real(x));
            } else {
              #line 964 "src/data/Buffer.birch"
              libbirch_line_(964);
              #line 964 "src/data/Buffer.birch"
              this->push(birch::Buffer(x));
            }
          }
        }
      }
    }
  }
}

#line 968 "src/data/Buffer.birch"
void birch::type::Buffer::doPush(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 968 "src/data/Buffer.birch"
  libbirch_function_("doPush", "src/data/Buffer.birch", 968);
  #line 969 "src/data/Buffer.birch"
  libbirch_line_(969);
  #line 969 "src/data/Buffer.birch"
  if (this->isEmpty()) {
    #line 970 "src/data/Buffer.birch"
    libbirch_line_(970);
    #line 970 "src/data/Buffer.birch"
    this->set(birch::row(x));
  } else {
    #line 971 "src/data/Buffer.birch"
    libbirch_line_(971);
    #line 971 "src/data/Buffer.birch"
    if (this->vectorBoolean.has_value()) {
      #line 972 "src/data/Buffer.birch"
      libbirch_line_(972);
      #line 972 "src/data/Buffer.birch"
      this->set(birch::stack(birch::Real(birch::row(this->vectorBoolean.value())), birch::row(x)));
    } else {
      #line 973 "src/data/Buffer.birch"
      libbirch_line_(973);
      #line 973 "src/data/Buffer.birch"
      if (this->matrixBoolean.has_value()) {
        #line 974 "src/data/Buffer.birch"
        libbirch_line_(974);
        #line 974 "src/data/Buffer.birch"
        this->set(birch::stack(birch::Real(this->matrixBoolean.value()), birch::row(x)));
      } else {
        #line 975 "src/data/Buffer.birch"
        libbirch_line_(975);
        #line 975 "src/data/Buffer.birch"
        if (this->vectorInteger.has_value()) {
          #line 976 "src/data/Buffer.birch"
          libbirch_line_(976);
          #line 976 "src/data/Buffer.birch"
          this->set(birch::stack(birch::Real(birch::row(this->vectorInteger.value())), birch::row(x)));
        } else {
          #line 977 "src/data/Buffer.birch"
          libbirch_line_(977);
          #line 977 "src/data/Buffer.birch"
          if (this->matrixInteger.has_value()) {
            #line 978 "src/data/Buffer.birch"
            libbirch_line_(978);
            #line 978 "src/data/Buffer.birch"
            this->set(birch::stack(birch::Real(this->matrixInteger.value()), birch::row(x)));
          } else {
            #line 979 "src/data/Buffer.birch"
            libbirch_line_(979);
            #line 979 "src/data/Buffer.birch"
            if (this->vectorReal.has_value()) {
              #line 980 "src/data/Buffer.birch"
              libbirch_line_(980);
              #line 980 "src/data/Buffer.birch"
              this->set(birch::stack(birch::row(this->vectorReal.value()), birch::row(x)));
            } else {
              #line 981 "src/data/Buffer.birch"
              libbirch_line_(981);
              #line 981 "src/data/Buffer.birch"
              if (this->matrixReal.has_value()) {
                #line 982 "src/data/Buffer.birch"
                libbirch_line_(982);
                #line 982 "src/data/Buffer.birch"
                this->set(birch::stack(this->matrixReal.value(), birch::row(x)));
              } else {
                #line 984 "src/data/Buffer.birch"
                libbirch_line_(984);
                #line 984 "src/data/Buffer.birch"
                this->push(birch::Buffer(x));
              }
            }
          }
        }
      }
    }
  }
}

#line 20 "src/data/Buffer.birch"
birch::type::Buffer* birch::type::make_Buffer_() {
  #line 20 "src/data/Buffer.birch"
  return new birch::type::Buffer();
  #line 20 "src/data/Buffer.birch"
}

#line 992 "src/data/Buffer.birch"
libbirch::Shared<birch::type::Buffer> birch::Buffer() {
  #line 992 "src/data/Buffer.birch"
  libbirch_function_("Buffer", "src/data/Buffer.birch", 992);
  #line 993 "src/data/Buffer.birch"
  libbirch_line_(993);
  #line 993 "src/data/Buffer.birch"
  return birch::construct<libbirch::Shared<birch::type::Buffer>>();
}

