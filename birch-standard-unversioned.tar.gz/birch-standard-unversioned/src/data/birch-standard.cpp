#line 4 "src/data/ArrayValue.birch"
birch::type::ArrayValue::ArrayValue(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/data/ArrayValue.birch"
    super_type_(),
    #line 9 "src/data/ArrayValue.birch"
    elements() {
  //
}

#line 11 "src/data/ArrayValue.birch"
void birch::type::ArrayValue::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Writer>>& writer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/data/ArrayValue.birch"
  libbirch_function_("accept", "src/data/ArrayValue.birch", 11);
  #line 12 "src/data/ArrayValue.birch"
  libbirch_line_(12);
  #line 12 "src/data/ArrayValue.birch"
  writer->visit(shared_from_this_(), handler_);
}

#line 15 "src/data/ArrayValue.birch"
birch::type::Integer birch::type::ArrayValue::size(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/data/ArrayValue.birch"
  libbirch_function_("size", "src/data/ArrayValue.birch", 15);
  #line 16 "src/data/ArrayValue.birch"
  libbirch_line_(16);
  #line 16 "src/data/ArrayValue.birch"
  return this_()->elements->size(handler_);
}

#line 19 "src/data/ArrayValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Iterator<libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>>>> birch::type::ArrayValue::walk(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/data/ArrayValue.birch"
  libbirch_function_("walk", "src/data/ArrayValue.birch", 19);
  #line 20 "src/data/ArrayValue.birch"
  libbirch_line_(20);
  #line 20 "src/data/ArrayValue.birch"
  return this_()->elements->walk(handler_);
}

#line 23 "src/data/ArrayValue.birch"
void birch::type::ArrayValue::insert(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "src/data/ArrayValue.birch"
  libbirch_function_("insert", "src/data/ArrayValue.birch", 23);
  #line 24 "src/data/ArrayValue.birch"
  libbirch_line_(24);
  #line 24 "src/data/ArrayValue.birch"
  this_()->elements->pushBack(value, handler_);
}

#line 27 "src/data/ArrayValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::ArrayValue::pushNil(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/data/ArrayValue.birch"
  libbirch_function_("pushNil", "src/data/ArrayValue.birch", 27);
  #line 28 "src/data/ArrayValue.birch"
  libbirch_line_(28);
  #line 28 "src/data/ArrayValue.birch"
  auto buffer = birch::Buffer(handler_);
  #line 29 "src/data/ArrayValue.birch"
  libbirch_line_(29);
  #line 29 "src/data/ArrayValue.birch"
  buffer->setNil(handler_);
  #line 30 "src/data/ArrayValue.birch"
  libbirch_line_(30);
  #line 30 "src/data/ArrayValue.birch"
  this_()->insert(buffer, handler_);
  #line 31 "src/data/ArrayValue.birch"
  libbirch_line_(31);
  #line 31 "src/data/ArrayValue.birch"
  return shared_from_this_();
}

#line 34 "src/data/ArrayValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::ArrayValue::push(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/data/ArrayValue.birch"
  libbirch_function_("push", "src/data/ArrayValue.birch", 34);
  #line 35 "src/data/ArrayValue.birch"
  libbirch_line_(35);
  #line 35 "src/data/ArrayValue.birch"
  this_()->insert(birch::Buffer(x, handler_), handler_);
  #line 36 "src/data/ArrayValue.birch"
  libbirch_line_(36);
  #line 36 "src/data/ArrayValue.birch"
  return shared_from_this_();
}

#line 39 "src/data/ArrayValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::ArrayValue::push(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/data/ArrayValue.birch"
  libbirch_function_("push", "src/data/ArrayValue.birch", 39);
  #line 40 "src/data/ArrayValue.birch"
  libbirch_line_(40);
  #line 40 "src/data/ArrayValue.birch"
  this_()->insert(birch::Buffer(x, handler_), handler_);
  #line 41 "src/data/ArrayValue.birch"
  libbirch_line_(41);
  #line 41 "src/data/ArrayValue.birch"
  return shared_from_this_();
}

#line 44 "src/data/ArrayValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::ArrayValue::push(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/data/ArrayValue.birch"
  libbirch_function_("push", "src/data/ArrayValue.birch", 44);
  #line 45 "src/data/ArrayValue.birch"
  libbirch_line_(45);
  #line 45 "src/data/ArrayValue.birch"
  this_()->insert(birch::Buffer(x, handler_), handler_);
  #line 46 "src/data/ArrayValue.birch"
  libbirch_line_(46);
  #line 46 "src/data/ArrayValue.birch"
  return shared_from_this_();
}

#line 49 "src/data/ArrayValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::ArrayValue::push(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/data/ArrayValue.birch"
  libbirch_function_("push", "src/data/ArrayValue.birch", 49);
  #line 50 "src/data/ArrayValue.birch"
  libbirch_line_(50);
  #line 50 "src/data/ArrayValue.birch"
  this_()->insert(birch::Buffer(x, handler_), handler_);
  #line 51 "src/data/ArrayValue.birch"
  libbirch_line_(51);
  #line 51 "src/data/ArrayValue.birch"
  return shared_from_this_();
}

#line 54 "src/data/ArrayValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::ArrayValue::push(const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "src/data/ArrayValue.birch"
  libbirch_function_("push", "src/data/ArrayValue.birch", 54);
  #line 55 "src/data/ArrayValue.birch"
  libbirch_line_(55);
  #line 55 "src/data/ArrayValue.birch"
  this_()->insert(birch::Buffer(x, handler_), handler_);
  #line 56 "src/data/ArrayValue.birch"
  libbirch_line_(56);
  #line 56 "src/data/ArrayValue.birch"
  return shared_from_this_();
}

#line 59 "src/data/ArrayValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::ArrayValue::push(const libbirch::DefaultArray<birch::type::Boolean,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/data/ArrayValue.birch"
  libbirch_function_("push", "src/data/ArrayValue.birch", 59);
  #line 60 "src/data/ArrayValue.birch"
  libbirch_line_(60);
  #line 60 "src/data/ArrayValue.birch"
  this_()->insert(birch::Buffer(x, handler_), handler_);
  #line 61 "src/data/ArrayValue.birch"
  libbirch_line_(61);
  #line 61 "src/data/ArrayValue.birch"
  return shared_from_this_();
}

#line 64 "src/data/ArrayValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::ArrayValue::push(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "src/data/ArrayValue.birch"
  libbirch_function_("push", "src/data/ArrayValue.birch", 64);
  #line 65 "src/data/ArrayValue.birch"
  libbirch_line_(65);
  #line 65 "src/data/ArrayValue.birch"
  this_()->insert(birch::Buffer(x, handler_), handler_);
  #line 66 "src/data/ArrayValue.birch"
  libbirch_line_(66);
  #line 66 "src/data/ArrayValue.birch"
  return shared_from_this_();
}

#line 69 "src/data/ArrayValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::ArrayValue::push(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "src/data/ArrayValue.birch"
  libbirch_function_("push", "src/data/ArrayValue.birch", 69);
  #line 70 "src/data/ArrayValue.birch"
  libbirch_line_(70);
  #line 70 "src/data/ArrayValue.birch"
  this_()->insert(birch::Buffer(x, handler_), handler_);
  #line 71 "src/data/ArrayValue.birch"
  libbirch_line_(71);
  #line 71 "src/data/ArrayValue.birch"
  return shared_from_this_();
}

#line 74 "src/data/ArrayValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,2>> birch::type::ArrayValue::getBooleanMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 74 "src/data/ArrayValue.birch"
  libbirch_function_("getBooleanMatrix", "src/data/ArrayValue.birch", 74);
  #line 75 "src/data/ArrayValue.birch"
  libbirch_line_(75);
  #line 75 "src/data/ArrayValue.birch"
  auto nrows = this_()->size(handler_);
  #line 76 "src/data/ArrayValue.birch"
  libbirch_line_(76);
  #line 76 "src/data/ArrayValue.birch"
  auto rows = this_()->walk(handler_);
  #line 77 "src/data/ArrayValue.birch"
  libbirch_line_(77);
  #line 77 "src/data/ArrayValue.birch"
  if (rows->hasNext(handler_)) {
    #line 79 "src/data/ArrayValue.birch"
    libbirch_line_(79);
    #line 79 "src/data/ArrayValue.birch"
    auto row = rows->next(handler_);
    #line 80 "src/data/ArrayValue.birch"
    libbirch_line_(80);
    #line 80 "src/data/ArrayValue.birch"
    auto ncols = row->size(handler_);
    #line 81 "src/data/ArrayValue.birch"
    libbirch_line_(81);
    #line 81 "src/data/ArrayValue.birch"
    libbirch::DefaultArray<birch::type::Boolean,2> X(libbirch::make_shape(nrows, ncols));
    #line 83 "src/data/ArrayValue.birch"
    libbirch_line_(83);
    #line 83 "src/data/ArrayValue.birch"
    auto x = row->getBooleanVector(handler_);
    #line 84 "src/data/ArrayValue.birch"
    libbirch_line_(84);
    #line 84 "src/data/ArrayValue.birch"
    if (x.query()) {
      #line 85 "src/data/ArrayValue.birch"
      libbirch_line_(85);
      #line 85 "src/data/ArrayValue.birch"
      X.set(libbirch::make_slice(birch::type::Integer(1) - 1, libbirch::make_range(birch::type::Integer(1) - 1, ncols - 1)), x.get());
    } else {
      #line 87 "src/data/ArrayValue.birch"
      libbirch_line_(87);
      #line 87 "src/data/ArrayValue.birch"
      return libbirch::nil;
    }
    #line 92 "src/data/ArrayValue.birch"
    libbirch_line_(92);
    #line 92 "src/data/ArrayValue.birch"
    auto i = birch::type::Integer(1);
    #line 93 "src/data/ArrayValue.birch"
    libbirch_line_(93);
    #line 93 "src/data/ArrayValue.birch"
    while (rows->hasNext(handler_)) {
      #line 94 "src/data/ArrayValue.birch"
      libbirch_line_(94);
      #line 94 "src/data/ArrayValue.birch"
      row = rows->next(handler_);
      #line 95 "src/data/ArrayValue.birch"
      libbirch_line_(95);
      #line 95 "src/data/ArrayValue.birch"
      ncols = row->size(handler_);
      #line 96 "src/data/ArrayValue.birch"
      libbirch_line_(96);
      #line 96 "src/data/ArrayValue.birch"
      if (ncols == birch::columns(X, handler_)) {
        #line 97 "src/data/ArrayValue.birch"
        libbirch_line_(97);
        #line 97 "src/data/ArrayValue.birch"
        x = row->getBooleanVector(handler_);
        #line 98 "src/data/ArrayValue.birch"
        libbirch_line_(98);
        #line 98 "src/data/ArrayValue.birch"
        if (x.query()) {
          #line 99 "src/data/ArrayValue.birch"
          libbirch_line_(99);
          #line 99 "src/data/ArrayValue.birch"
          i = i + birch::type::Integer(1);
          #line 100 "src/data/ArrayValue.birch"
          libbirch_line_(100);
          #line 100 "src/data/ArrayValue.birch"
          X.set(libbirch::make_slice(i - 1, libbirch::make_range(birch::type::Integer(1) - 1, ncols - 1)), x.get());
        } else {
          #line 102 "src/data/ArrayValue.birch"
          libbirch_line_(102);
          #line 102 "src/data/ArrayValue.birch"
          return libbirch::nil;
        }
      } else {
        #line 105 "src/data/ArrayValue.birch"
        libbirch_line_(105);
        #line 105 "src/data/ArrayValue.birch"
        return libbirch::nil;
      }
    }
    #line 108 "src/data/ArrayValue.birch"
    libbirch_line_(108);
    #line 108 "src/data/ArrayValue.birch"
    libbirch_assert_(i == nrows);
    #line 109 "src/data/ArrayValue.birch"
    libbirch_line_(109);
    #line 109 "src/data/ArrayValue.birch"
    return X;
  }
  #line 111 "src/data/ArrayValue.birch"
  libbirch_line_(111);
  #line 111 "src/data/ArrayValue.birch"
  return libbirch::nil;
}

#line 114 "src/data/ArrayValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,2>> birch::type::ArrayValue::getIntegerMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 114 "src/data/ArrayValue.birch"
  libbirch_function_("getIntegerMatrix", "src/data/ArrayValue.birch", 114);
  #line 115 "src/data/ArrayValue.birch"
  libbirch_line_(115);
  #line 115 "src/data/ArrayValue.birch"
  auto nrows = this_()->size(handler_);
  #line 116 "src/data/ArrayValue.birch"
  libbirch_line_(116);
  #line 116 "src/data/ArrayValue.birch"
  auto rows = this_()->walk(handler_);
  #line 117 "src/data/ArrayValue.birch"
  libbirch_line_(117);
  #line 117 "src/data/ArrayValue.birch"
  if (rows->hasNext(handler_)) {
    #line 119 "src/data/ArrayValue.birch"
    libbirch_line_(119);
    #line 119 "src/data/ArrayValue.birch"
    auto row = rows->next(handler_);
    #line 120 "src/data/ArrayValue.birch"
    libbirch_line_(120);
    #line 120 "src/data/ArrayValue.birch"
    auto ncols = row->size(handler_);
    #line 121 "src/data/ArrayValue.birch"
    libbirch_line_(121);
    #line 121 "src/data/ArrayValue.birch"
    libbirch::DefaultArray<birch::type::Integer,2> X(libbirch::make_shape(nrows, ncols));
    #line 123 "src/data/ArrayValue.birch"
    libbirch_line_(123);
    #line 123 "src/data/ArrayValue.birch"
    auto x = row->getIntegerVector(handler_);
    #line 124 "src/data/ArrayValue.birch"
    libbirch_line_(124);
    #line 124 "src/data/ArrayValue.birch"
    if (x.query()) {
      #line 125 "src/data/ArrayValue.birch"
      libbirch_line_(125);
      #line 125 "src/data/ArrayValue.birch"
      X.set(libbirch::make_slice(birch::type::Integer(1) - 1, libbirch::make_range(birch::type::Integer(1) - 1, ncols - 1)), x.get());
    } else {
      #line 127 "src/data/ArrayValue.birch"
      libbirch_line_(127);
      #line 127 "src/data/ArrayValue.birch"
      return libbirch::nil;
    }
    #line 132 "src/data/ArrayValue.birch"
    libbirch_line_(132);
    #line 132 "src/data/ArrayValue.birch"
    auto i = birch::type::Integer(1);
    #line 133 "src/data/ArrayValue.birch"
    libbirch_line_(133);
    #line 133 "src/data/ArrayValue.birch"
    while (rows->hasNext(handler_)) {
      #line 134 "src/data/ArrayValue.birch"
      libbirch_line_(134);
      #line 134 "src/data/ArrayValue.birch"
      row = rows->next(handler_);
      #line 135 "src/data/ArrayValue.birch"
      libbirch_line_(135);
      #line 135 "src/data/ArrayValue.birch"
      ncols = row->size(handler_);
      #line 136 "src/data/ArrayValue.birch"
      libbirch_line_(136);
      #line 136 "src/data/ArrayValue.birch"
      if (ncols == birch::columns(X, handler_)) {
        #line 137 "src/data/ArrayValue.birch"
        libbirch_line_(137);
        #line 137 "src/data/ArrayValue.birch"
        x = row->getIntegerVector(handler_);
        #line 138 "src/data/ArrayValue.birch"
        libbirch_line_(138);
        #line 138 "src/data/ArrayValue.birch"
        if (x.query()) {
          #line 139 "src/data/ArrayValue.birch"
          libbirch_line_(139);
          #line 139 "src/data/ArrayValue.birch"
          i = i + birch::type::Integer(1);
          #line 140 "src/data/ArrayValue.birch"
          libbirch_line_(140);
          #line 140 "src/data/ArrayValue.birch"
          X.set(libbirch::make_slice(i - 1, libbirch::make_range(birch::type::Integer(1) - 1, ncols - 1)), x.get());
        } else {
          #line 142 "src/data/ArrayValue.birch"
          libbirch_line_(142);
          #line 142 "src/data/ArrayValue.birch"
          return libbirch::nil;
        }
      } else {
        #line 145 "src/data/ArrayValue.birch"
        libbirch_line_(145);
        #line 145 "src/data/ArrayValue.birch"
        return libbirch::nil;
      }
    }
    #line 148 "src/data/ArrayValue.birch"
    libbirch_line_(148);
    #line 148 "src/data/ArrayValue.birch"
    libbirch_assert_(i == nrows);
    #line 149 "src/data/ArrayValue.birch"
    libbirch_line_(149);
    #line 149 "src/data/ArrayValue.birch"
    return X;
  }
  #line 151 "src/data/ArrayValue.birch"
  libbirch_line_(151);
  #line 151 "src/data/ArrayValue.birch"
  return libbirch::nil;
}

#line 154 "src/data/ArrayValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::ArrayValue::getRealMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 154 "src/data/ArrayValue.birch"
  libbirch_function_("getRealMatrix", "src/data/ArrayValue.birch", 154);
  #line 155 "src/data/ArrayValue.birch"
  libbirch_line_(155);
  #line 155 "src/data/ArrayValue.birch"
  auto nrows = this_()->size(handler_);
  #line 156 "src/data/ArrayValue.birch"
  libbirch_line_(156);
  #line 156 "src/data/ArrayValue.birch"
  auto rows = this_()->walk(handler_);
  #line 157 "src/data/ArrayValue.birch"
  libbirch_line_(157);
  #line 157 "src/data/ArrayValue.birch"
  if (rows->hasNext(handler_)) {
    #line 159 "src/data/ArrayValue.birch"
    libbirch_line_(159);
    #line 159 "src/data/ArrayValue.birch"
    auto row = rows->next(handler_);
    #line 160 "src/data/ArrayValue.birch"
    libbirch_line_(160);
    #line 160 "src/data/ArrayValue.birch"
    auto ncols = row->size(handler_);
    #line 161 "src/data/ArrayValue.birch"
    libbirch_line_(161);
    #line 161 "src/data/ArrayValue.birch"
    libbirch::DefaultArray<birch::type::Real,2> X(libbirch::make_shape(nrows, ncols));
    #line 163 "src/data/ArrayValue.birch"
    libbirch_line_(163);
    #line 163 "src/data/ArrayValue.birch"
    auto x = row->getRealVector(handler_);
    #line 164 "src/data/ArrayValue.birch"
    libbirch_line_(164);
    #line 164 "src/data/ArrayValue.birch"
    if (x.query()) {
      #line 165 "src/data/ArrayValue.birch"
      libbirch_line_(165);
      #line 165 "src/data/ArrayValue.birch"
      X.set(libbirch::make_slice(birch::type::Integer(1) - 1, libbirch::make_range(birch::type::Integer(1) - 1, ncols - 1)), x.get());
    } else {
      #line 167 "src/data/ArrayValue.birch"
      libbirch_line_(167);
      #line 167 "src/data/ArrayValue.birch"
      return libbirch::nil;
    }
    #line 172 "src/data/ArrayValue.birch"
    libbirch_line_(172);
    #line 172 "src/data/ArrayValue.birch"
    auto i = birch::type::Integer(1);
    #line 173 "src/data/ArrayValue.birch"
    libbirch_line_(173);
    #line 173 "src/data/ArrayValue.birch"
    while (rows->hasNext(handler_)) {
      #line 174 "src/data/ArrayValue.birch"
      libbirch_line_(174);
      #line 174 "src/data/ArrayValue.birch"
      row = rows->next(handler_);
      #line 175 "src/data/ArrayValue.birch"
      libbirch_line_(175);
      #line 175 "src/data/ArrayValue.birch"
      ncols = row->size(handler_);
      #line 176 "src/data/ArrayValue.birch"
      libbirch_line_(176);
      #line 176 "src/data/ArrayValue.birch"
      if (ncols == birch::columns(X, handler_)) {
        #line 177 "src/data/ArrayValue.birch"
        libbirch_line_(177);
        #line 177 "src/data/ArrayValue.birch"
        x = row->getRealVector(handler_);
        #line 178 "src/data/ArrayValue.birch"
        libbirch_line_(178);
        #line 178 "src/data/ArrayValue.birch"
        if (x.query()) {
          #line 179 "src/data/ArrayValue.birch"
          libbirch_line_(179);
          #line 179 "src/data/ArrayValue.birch"
          i = i + birch::type::Integer(1);
          #line 180 "src/data/ArrayValue.birch"
          libbirch_line_(180);
          #line 180 "src/data/ArrayValue.birch"
          X.set(libbirch::make_slice(i - 1, libbirch::make_range(birch::type::Integer(1) - 1, ncols - 1)), x.get());
        } else {
          #line 182 "src/data/ArrayValue.birch"
          libbirch_line_(182);
          #line 182 "src/data/ArrayValue.birch"
          return libbirch::nil;
        }
      } else {
        #line 185 "src/data/ArrayValue.birch"
        libbirch_line_(185);
        #line 185 "src/data/ArrayValue.birch"
        return libbirch::nil;
      }
    }
    #line 188 "src/data/ArrayValue.birch"
    libbirch_line_(188);
    #line 188 "src/data/ArrayValue.birch"
    libbirch_assert_(i == nrows);
    #line 189 "src/data/ArrayValue.birch"
    libbirch_line_(189);
    #line 189 "src/data/ArrayValue.birch"
    return X;
  }
  #line 191 "src/data/ArrayValue.birch"
  libbirch_line_(191);
  #line 191 "src/data/ArrayValue.birch"
  return libbirch::nil;
}

#line 4 "src/data/ArrayValue.birch"
birch::type::ArrayValue* birch::type::make_ArrayValue_() {
  #line 4 "src/data/ArrayValue.birch"
  return new birch::type::ArrayValue();
  #line 4 "src/data/ArrayValue.birch"
}

#line 198 "src/data/ArrayValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ArrayValue>> birch::ArrayValue(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 198 "src/data/ArrayValue.birch"
  libbirch_function_("ArrayValue", "src/data/ArrayValue.birch", 198);
  #line 199 "src/data/ArrayValue.birch"
  libbirch_line_(199);
  #line 199 "src/data/ArrayValue.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::ArrayValue>>>(handler_);
}

#line 4 "src/data/BooleanValue.birch"
birch::type::BooleanValue::BooleanValue(const birch::type::Boolean& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/data/BooleanValue.birch"
    super_type_(),
    #line 8 "src/data/BooleanValue.birch"
    value(value) {
  //
}

#line 10 "src/data/BooleanValue.birch"
void birch::type::BooleanValue::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Writer>>& writer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/data/BooleanValue.birch"
  libbirch_function_("accept", "src/data/BooleanValue.birch", 10);
  #line 11 "src/data/BooleanValue.birch"
  libbirch_line_(11);
  #line 11 "src/data/BooleanValue.birch"
  writer->visit(shared_from_this_(), handler_);
}

#line 14 "src/data/BooleanValue.birch"
libbirch::Optional<birch::type::Boolean> birch::type::BooleanValue::getBoolean(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/data/BooleanValue.birch"
  libbirch_function_("getBoolean", "src/data/BooleanValue.birch", 14);
  #line 15 "src/data/BooleanValue.birch"
  libbirch_line_(15);
  #line 15 "src/data/BooleanValue.birch"
  return this_()->value;
}

#line 18 "src/data/BooleanValue.birch"
libbirch::Optional<birch::type::Integer> birch::type::BooleanValue::getInteger(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/data/BooleanValue.birch"
  libbirch_function_("getInteger", "src/data/BooleanValue.birch", 18);
  #line 19 "src/data/BooleanValue.birch"
  libbirch_line_(19);
  #line 19 "src/data/BooleanValue.birch"
  return birch::Integer(this_()->value, handler_);
}

#line 22 "src/data/BooleanValue.birch"
libbirch::Optional<birch::type::Real> birch::type::BooleanValue::getReal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/data/BooleanValue.birch"
  libbirch_function_("getReal", "src/data/BooleanValue.birch", 22);
  #line 23 "src/data/BooleanValue.birch"
  libbirch_line_(23);
  #line 23 "src/data/BooleanValue.birch"
  return birch::Real(this_()->value, handler_);
}

#line 26 "src/data/BooleanValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,1>> birch::type::BooleanValue::getBooleanVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/data/BooleanValue.birch"
  libbirch_function_("getBooleanVector", "src/data/BooleanValue.birch", 26);
  #line 27 "src/data/BooleanValue.birch"
  libbirch_line_(27);
  #line 27 "src/data/BooleanValue.birch"
  return birch::vector(this_()->value, birch::type::Integer(1), handler_);
}

#line 30 "src/data/BooleanValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,1>> birch::type::BooleanValue::getIntegerVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/data/BooleanValue.birch"
  libbirch_function_("getIntegerVector", "src/data/BooleanValue.birch", 30);
  #line 31 "src/data/BooleanValue.birch"
  libbirch_line_(31);
  #line 31 "src/data/BooleanValue.birch"
  return birch::vector(birch::Integer(this_()->value, handler_), birch::type::Integer(1), handler_);
}

#line 34 "src/data/BooleanValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::BooleanValue::getRealVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/data/BooleanValue.birch"
  libbirch_function_("getRealVector", "src/data/BooleanValue.birch", 34);
  #line 35 "src/data/BooleanValue.birch"
  libbirch_line_(35);
  #line 35 "src/data/BooleanValue.birch"
  return birch::vector(birch::Real(this_()->value, handler_), birch::type::Integer(1), handler_);
}

#line 38 "src/data/BooleanValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,2>> birch::type::BooleanValue::getBooleanMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "src/data/BooleanValue.birch"
  libbirch_function_("getBooleanMatrix", "src/data/BooleanValue.birch", 38);
  #line 39 "src/data/BooleanValue.birch"
  libbirch_line_(39);
  #line 39 "src/data/BooleanValue.birch"
  return birch::matrix(this_()->value, birch::type::Integer(1), birch::type::Integer(1), handler_);
}

#line 42 "src/data/BooleanValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,2>> birch::type::BooleanValue::getIntegerMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/data/BooleanValue.birch"
  libbirch_function_("getIntegerMatrix", "src/data/BooleanValue.birch", 42);
  #line 43 "src/data/BooleanValue.birch"
  libbirch_line_(43);
  #line 43 "src/data/BooleanValue.birch"
  return birch::matrix(birch::Integer(this_()->value, handler_), birch::type::Integer(1), birch::type::Integer(1), handler_);
}

#line 46 "src/data/BooleanValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::BooleanValue::getRealMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/data/BooleanValue.birch"
  libbirch_function_("getRealMatrix", "src/data/BooleanValue.birch", 46);
  #line 47 "src/data/BooleanValue.birch"
  libbirch_line_(47);
  #line 47 "src/data/BooleanValue.birch"
  return birch::matrix(birch::Real(this_()->value, handler_), birch::type::Integer(1), birch::type::Integer(1), handler_);
}

#line 50 "src/data/BooleanValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::BooleanValue::pushNil(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "src/data/BooleanValue.birch"
  libbirch_function_("pushNil", "src/data/BooleanValue.birch", 50);
  #line 51 "src/data/BooleanValue.birch"
  libbirch_line_(51);
  #line 51 "src/data/BooleanValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 52 "src/data/BooleanValue.birch"
  libbirch_line_(52);
  #line 52 "src/data/BooleanValue.birch"
  o->push(this_()->value, handler_);
  #line 53 "src/data/BooleanValue.birch"
  libbirch_line_(53);
  #line 53 "src/data/BooleanValue.birch"
  o->pushNil(handler_);
  #line 54 "src/data/BooleanValue.birch"
  libbirch_line_(54);
  #line 54 "src/data/BooleanValue.birch"
  return o;
}

#line 57 "src/data/BooleanValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::BooleanValue::push(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 57 "src/data/BooleanValue.birch"
  libbirch_function_("push", "src/data/BooleanValue.birch", 57);
  #line 58 "src/data/BooleanValue.birch"
  libbirch_line_(58);
  #line 58 "src/data/BooleanValue.birch"
  return birch::BooleanVectorValue(libbirch::make_array({ this_()->value, x }), handler_);
}

#line 61 "src/data/BooleanValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::BooleanValue::push(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "src/data/BooleanValue.birch"
  libbirch_function_("push", "src/data/BooleanValue.birch", 61);
  #line 62 "src/data/BooleanValue.birch"
  libbirch_line_(62);
  #line 62 "src/data/BooleanValue.birch"
  return birch::IntegerVectorValue(libbirch::make_array({ birch::Integer(this_()->value, handler_), x }), handler_);
}

#line 65 "src/data/BooleanValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::BooleanValue::push(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "src/data/BooleanValue.birch"
  libbirch_function_("push", "src/data/BooleanValue.birch", 65);
  #line 66 "src/data/BooleanValue.birch"
  libbirch_line_(66);
  #line 66 "src/data/BooleanValue.birch"
  return birch::RealVectorValue(libbirch::make_array({ birch::Real(this_()->value, handler_), x }), handler_);
}

#line 69 "src/data/BooleanValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::BooleanValue::push(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "src/data/BooleanValue.birch"
  libbirch_function_("push", "src/data/BooleanValue.birch", 69);
  #line 70 "src/data/BooleanValue.birch"
  libbirch_line_(70);
  #line 70 "src/data/BooleanValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 71 "src/data/BooleanValue.birch"
  libbirch_line_(71);
  #line 71 "src/data/BooleanValue.birch"
  o->push(this_()->value, handler_);
  #line 72 "src/data/BooleanValue.birch"
  libbirch_line_(72);
  #line 72 "src/data/BooleanValue.birch"
  o->push(x, handler_);
  #line 73 "src/data/BooleanValue.birch"
  libbirch_line_(73);
  #line 73 "src/data/BooleanValue.birch"
  return o;
}

#line 76 "src/data/BooleanValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::BooleanValue::push(const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "src/data/BooleanValue.birch"
  libbirch_function_("push", "src/data/BooleanValue.birch", 76);
  #line 77 "src/data/BooleanValue.birch"
  libbirch_line_(77);
  #line 77 "src/data/BooleanValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 78 "src/data/BooleanValue.birch"
  libbirch_line_(78);
  #line 78 "src/data/BooleanValue.birch"
  o->push(this_()->value, handler_);
  #line 79 "src/data/BooleanValue.birch"
  libbirch_line_(79);
  #line 79 "src/data/BooleanValue.birch"
  o->push(x, handler_);
  #line 80 "src/data/BooleanValue.birch"
  libbirch_line_(80);
  #line 80 "src/data/BooleanValue.birch"
  return o;
}

#line 83 "src/data/BooleanValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::BooleanValue::push(const libbirch::DefaultArray<birch::type::Boolean,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 83 "src/data/BooleanValue.birch"
  libbirch_function_("push", "src/data/BooleanValue.birch", 83);
  #line 84 "src/data/BooleanValue.birch"
  libbirch_line_(84);
  #line 84 "src/data/BooleanValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 85 "src/data/BooleanValue.birch"
  libbirch_line_(85);
  #line 85 "src/data/BooleanValue.birch"
  o->push(this_()->value, handler_);
  #line 86 "src/data/BooleanValue.birch"
  libbirch_line_(86);
  #line 86 "src/data/BooleanValue.birch"
  o->push(x, handler_);
  #line 87 "src/data/BooleanValue.birch"
  libbirch_line_(87);
  #line 87 "src/data/BooleanValue.birch"
  return o;
}

#line 90 "src/data/BooleanValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::BooleanValue::push(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 90 "src/data/BooleanValue.birch"
  libbirch_function_("push", "src/data/BooleanValue.birch", 90);
  #line 91 "src/data/BooleanValue.birch"
  libbirch_line_(91);
  #line 91 "src/data/BooleanValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 92 "src/data/BooleanValue.birch"
  libbirch_line_(92);
  #line 92 "src/data/BooleanValue.birch"
  o->push(this_()->value, handler_);
  #line 93 "src/data/BooleanValue.birch"
  libbirch_line_(93);
  #line 93 "src/data/BooleanValue.birch"
  o->push(x, handler_);
  #line 94 "src/data/BooleanValue.birch"
  libbirch_line_(94);
  #line 94 "src/data/BooleanValue.birch"
  return o;
}

#line 97 "src/data/BooleanValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::BooleanValue::push(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 97 "src/data/BooleanValue.birch"
  libbirch_function_("push", "src/data/BooleanValue.birch", 97);
  #line 98 "src/data/BooleanValue.birch"
  libbirch_line_(98);
  #line 98 "src/data/BooleanValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 99 "src/data/BooleanValue.birch"
  libbirch_line_(99);
  #line 99 "src/data/BooleanValue.birch"
  o->push(this_()->value, handler_);
  #line 100 "src/data/BooleanValue.birch"
  libbirch_line_(100);
  #line 100 "src/data/BooleanValue.birch"
  o->push(x, handler_);
  #line 101 "src/data/BooleanValue.birch"
  libbirch_line_(101);
  #line 101 "src/data/BooleanValue.birch"
  return o;
}

#line 108 "src/data/BooleanValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::BooleanValue>> birch::BooleanValue(const birch::type::Boolean& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 108 "src/data/BooleanValue.birch"
  libbirch_function_("BooleanValue", "src/data/BooleanValue.birch", 108);
  #line 109 "src/data/BooleanValue.birch"
  libbirch_line_(109);
  #line 109 "src/data/BooleanValue.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::BooleanValue>>>(value, handler_);
}

#line 4 "src/data/BooleanVectorValue.birch"
birch::type::BooleanVectorValue::BooleanVectorValue(const libbirch::DefaultArray<birch::type::Boolean,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/data/BooleanVectorValue.birch"
    super_type_(),
    #line 8 "src/data/BooleanVectorValue.birch"
    value(value) {
  //
}

#line 10 "src/data/BooleanVectorValue.birch"
void birch::type::BooleanVectorValue::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Writer>>& writer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/data/BooleanVectorValue.birch"
  libbirch_function_("accept", "src/data/BooleanVectorValue.birch", 10);
  #line 11 "src/data/BooleanVectorValue.birch"
  libbirch_line_(11);
  #line 11 "src/data/BooleanVectorValue.birch"
  writer->visit(shared_from_this_(), handler_);
}

#line 14 "src/data/BooleanVectorValue.birch"
birch::type::Integer birch::type::BooleanVectorValue::size(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/data/BooleanVectorValue.birch"
  libbirch_function_("size", "src/data/BooleanVectorValue.birch", 14);
  #line 15 "src/data/BooleanVectorValue.birch"
  libbirch_line_(15);
  #line 15 "src/data/BooleanVectorValue.birch"
  return birch::length(this_()->value, handler_);
}

#line 18 "src/data/BooleanVectorValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,1>> birch::type::BooleanVectorValue::getBooleanVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/data/BooleanVectorValue.birch"
  libbirch_function_("getBooleanVector", "src/data/BooleanVectorValue.birch", 18);
  #line 19 "src/data/BooleanVectorValue.birch"
  libbirch_line_(19);
  #line 19 "src/data/BooleanVectorValue.birch"
  return this_()->value;
}

#line 22 "src/data/BooleanVectorValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,1>> birch::type::BooleanVectorValue::getIntegerVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/data/BooleanVectorValue.birch"
  libbirch_function_("getIntegerVector", "src/data/BooleanVectorValue.birch", 22);
  #line 23 "src/data/BooleanVectorValue.birch"
  libbirch_line_(23);
  #line 23 "src/data/BooleanVectorValue.birch"
  return birch::Integer(this_()->value, handler_);
}

#line 26 "src/data/BooleanVectorValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::BooleanVectorValue::getRealVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/data/BooleanVectorValue.birch"
  libbirch_function_("getRealVector", "src/data/BooleanVectorValue.birch", 26);
  #line 27 "src/data/BooleanVectorValue.birch"
  libbirch_line_(27);
  #line 27 "src/data/BooleanVectorValue.birch"
  return birch::Real(this_()->value, handler_);
}

#line 30 "src/data/BooleanVectorValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,2>> birch::type::BooleanVectorValue::getBooleanMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/data/BooleanVectorValue.birch"
  libbirch_function_("getBooleanMatrix", "src/data/BooleanVectorValue.birch", 30);
  #line 31 "src/data/BooleanVectorValue.birch"
  libbirch_line_(31);
  #line 31 "src/data/BooleanVectorValue.birch"
  return birch::column(this_()->value, handler_);
}

#line 34 "src/data/BooleanVectorValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,2>> birch::type::BooleanVectorValue::getIntegerMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/data/BooleanVectorValue.birch"
  libbirch_function_("getIntegerMatrix", "src/data/BooleanVectorValue.birch", 34);
  #line 35 "src/data/BooleanVectorValue.birch"
  libbirch_line_(35);
  #line 35 "src/data/BooleanVectorValue.birch"
  return birch::column(birch::Integer(this_()->value, handler_), handler_);
}

#line 38 "src/data/BooleanVectorValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::BooleanVectorValue::getRealMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "src/data/BooleanVectorValue.birch"
  libbirch_function_("getRealMatrix", "src/data/BooleanVectorValue.birch", 38);
  #line 39 "src/data/BooleanVectorValue.birch"
  libbirch_line_(39);
  #line 39 "src/data/BooleanVectorValue.birch"
  return birch::column(birch::Real(this_()->value, handler_), handler_);
}

#line 42 "src/data/BooleanVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::BooleanVectorValue::pushNil(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/data/BooleanVectorValue.birch"
  libbirch_function_("pushNil", "src/data/BooleanVectorValue.birch", 42);
  #line 43 "src/data/BooleanVectorValue.birch"
  libbirch_line_(43);
  #line 43 "src/data/BooleanVectorValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 44 "src/data/BooleanVectorValue.birch"
  libbirch_line_(44);
  #line 44 "src/data/BooleanVectorValue.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(this_()->value, handler_); ++i) {
    #line 45 "src/data/BooleanVectorValue.birch"
    libbirch_line_(45);
    #line 45 "src/data/BooleanVectorValue.birch"
    o->push(this_()->value.get(libbirch::make_slice(i - 1)), handler_);
  }
  #line 47 "src/data/BooleanVectorValue.birch"
  libbirch_line_(47);
  #line 47 "src/data/BooleanVectorValue.birch"
  o->pushNil(handler_);
  #line 48 "src/data/BooleanVectorValue.birch"
  libbirch_line_(48);
  #line 48 "src/data/BooleanVectorValue.birch"
  return o;
}

#line 51 "src/data/BooleanVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::BooleanVectorValue::push(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 51 "src/data/BooleanVectorValue.birch"
  libbirch_function_("push", "src/data/BooleanVectorValue.birch", 51);
  #line 52 "src/data/BooleanVectorValue.birch"

    value.insert(value.size(), x);
      #line 55 "src/data/BooleanVectorValue.birch"
  libbirch_line_(55);
  #line 55 "src/data/BooleanVectorValue.birch"
  return shared_from_this_();
}

#line 58 "src/data/BooleanVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::BooleanVectorValue::push(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "src/data/BooleanVectorValue.birch"
  libbirch_function_("push", "src/data/BooleanVectorValue.birch", 58);
  #line 59 "src/data/BooleanVectorValue.birch"
  libbirch_line_(59);
  #line 59 "src/data/BooleanVectorValue.birch"
  auto n = birch::length(this_()->value, handler_);
  #line 60 "src/data/BooleanVectorValue.birch"
  libbirch_line_(60);
  #line 60 "src/data/BooleanVectorValue.birch"
  return birch::IntegerVectorValue(birch::vector(std::function<birch::type::Integer(birch::type::Integer,const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_
)>([=](const birch::type::Integer& i, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr) {
    #line 61 "src/data/BooleanVectorValue.birch"
    libbirch_line_(61);
    #line 61 "src/data/BooleanVectorValue.birch"
    if (i == n + birch::type::Integer(1)) {
      #line 62 "src/data/BooleanVectorValue.birch"
      libbirch_line_(62);
      #line 62 "src/data/BooleanVectorValue.birch"
      return x;
    } else {
      #line 64 "src/data/BooleanVectorValue.birch"
      libbirch_line_(64);
      #line 64 "src/data/BooleanVectorValue.birch"
      return birch::Integer(this_()->value.get(libbirch::make_slice(i - 1)), handler_);
    }
  }), n + birch::type::Integer(1), handler_), handler_);
}

#line 69 "src/data/BooleanVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::BooleanVectorValue::push(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "src/data/BooleanVectorValue.birch"
  libbirch_function_("push", "src/data/BooleanVectorValue.birch", 69);
  #line 70 "src/data/BooleanVectorValue.birch"
  libbirch_line_(70);
  #line 70 "src/data/BooleanVectorValue.birch"
  auto n = birch::length(this_()->value, handler_);
  #line 71 "src/data/BooleanVectorValue.birch"
  libbirch_line_(71);
  #line 71 "src/data/BooleanVectorValue.birch"
  return birch::RealVectorValue(birch::vector(std::function<birch::type::Integer(birch::type::Integer,const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_
)>([=](const birch::type::Integer& i, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr) {
    #line 72 "src/data/BooleanVectorValue.birch"
    libbirch_line_(72);
    #line 72 "src/data/BooleanVectorValue.birch"
    if (i == n + birch::type::Integer(1)) {
      #line 73 "src/data/BooleanVectorValue.birch"
      libbirch_line_(73);
      #line 73 "src/data/BooleanVectorValue.birch"
      return x;
    } else {
      #line 75 "src/data/BooleanVectorValue.birch"
      libbirch_line_(75);
      #line 75 "src/data/BooleanVectorValue.birch"
      return birch::Real(this_()->value.get(libbirch::make_slice(i - 1)), handler_);
    }
  }), n + birch::type::Integer(1), handler_), handler_);
}

#line 80 "src/data/BooleanVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::BooleanVectorValue::push(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 80 "src/data/BooleanVectorValue.birch"
  libbirch_function_("push", "src/data/BooleanVectorValue.birch", 80);
  #line 81 "src/data/BooleanVectorValue.birch"
  libbirch_line_(81);
  #line 81 "src/data/BooleanVectorValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 82 "src/data/BooleanVectorValue.birch"
  libbirch_line_(82);
  #line 82 "src/data/BooleanVectorValue.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(this_()->value, handler_); ++i) {
    #line 83 "src/data/BooleanVectorValue.birch"
    libbirch_line_(83);
    #line 83 "src/data/BooleanVectorValue.birch"
    o->push(this_()->value.get(libbirch::make_slice(i - 1)), handler_);
  }
  #line 85 "src/data/BooleanVectorValue.birch"
  libbirch_line_(85);
  #line 85 "src/data/BooleanVectorValue.birch"
  o->push(x, handler_);
  #line 86 "src/data/BooleanVectorValue.birch"
  libbirch_line_(86);
  #line 86 "src/data/BooleanVectorValue.birch"
  return o;
}

#line 89 "src/data/BooleanVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::BooleanVectorValue::push(const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 89 "src/data/BooleanVectorValue.birch"
  libbirch_function_("push", "src/data/BooleanVectorValue.birch", 89);
  #line 90 "src/data/BooleanVectorValue.birch"
  libbirch_line_(90);
  #line 90 "src/data/BooleanVectorValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 91 "src/data/BooleanVectorValue.birch"
  libbirch_line_(91);
  #line 91 "src/data/BooleanVectorValue.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(this_()->value, handler_); ++i) {
    #line 92 "src/data/BooleanVectorValue.birch"
    libbirch_line_(92);
    #line 92 "src/data/BooleanVectorValue.birch"
    o->push(this_()->value.get(libbirch::make_slice(i - 1)), handler_);
  }
  #line 94 "src/data/BooleanVectorValue.birch"
  libbirch_line_(94);
  #line 94 "src/data/BooleanVectorValue.birch"
  o->push(x, handler_);
  #line 95 "src/data/BooleanVectorValue.birch"
  libbirch_line_(95);
  #line 95 "src/data/BooleanVectorValue.birch"
  return o;
}

#line 98 "src/data/BooleanVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::BooleanVectorValue::push(const libbirch::DefaultArray<birch::type::Boolean,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 98 "src/data/BooleanVectorValue.birch"
  libbirch_function_("push", "src/data/BooleanVectorValue.birch", 98);
  #line 99 "src/data/BooleanVectorValue.birch"
  libbirch_line_(99);
  #line 99 "src/data/BooleanVectorValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 100 "src/data/BooleanVectorValue.birch"
  libbirch_line_(100);
  #line 100 "src/data/BooleanVectorValue.birch"
  o->push(this_()->value, handler_);
  #line 101 "src/data/BooleanVectorValue.birch"
  libbirch_line_(101);
  #line 101 "src/data/BooleanVectorValue.birch"
  o->push(x, handler_);
  #line 102 "src/data/BooleanVectorValue.birch"
  libbirch_line_(102);
  #line 102 "src/data/BooleanVectorValue.birch"
  return o;
}

#line 105 "src/data/BooleanVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::BooleanVectorValue::push(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 105 "src/data/BooleanVectorValue.birch"
  libbirch_function_("push", "src/data/BooleanVectorValue.birch", 105);
  #line 106 "src/data/BooleanVectorValue.birch"
  libbirch_line_(106);
  #line 106 "src/data/BooleanVectorValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 107 "src/data/BooleanVectorValue.birch"
  libbirch_line_(107);
  #line 107 "src/data/BooleanVectorValue.birch"
  o->push(this_()->value, handler_);
  #line 108 "src/data/BooleanVectorValue.birch"
  libbirch_line_(108);
  #line 108 "src/data/BooleanVectorValue.birch"
  o->push(x, handler_);
  #line 109 "src/data/BooleanVectorValue.birch"
  libbirch_line_(109);
  #line 109 "src/data/BooleanVectorValue.birch"
  return o;
}

#line 112 "src/data/BooleanVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::BooleanVectorValue::push(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 112 "src/data/BooleanVectorValue.birch"
  libbirch_function_("push", "src/data/BooleanVectorValue.birch", 112);
  #line 113 "src/data/BooleanVectorValue.birch"
  libbirch_line_(113);
  #line 113 "src/data/BooleanVectorValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 114 "src/data/BooleanVectorValue.birch"
  libbirch_line_(114);
  #line 114 "src/data/BooleanVectorValue.birch"
  o->push(this_()->value, handler_);
  #line 115 "src/data/BooleanVectorValue.birch"
  libbirch_line_(115);
  #line 115 "src/data/BooleanVectorValue.birch"
  o->push(x, handler_);
  #line 116 "src/data/BooleanVectorValue.birch"
  libbirch_line_(116);
  #line 116 "src/data/BooleanVectorValue.birch"
  return o;
}

#line 123 "src/data/BooleanVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::BooleanVectorValue>> birch::BooleanVectorValue(const libbirch::DefaultArray<birch::type::Boolean,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 123 "src/data/BooleanVectorValue.birch"
  libbirch_function_("BooleanVectorValue", "src/data/BooleanVectorValue.birch", 123);
  #line 124 "src/data/BooleanVectorValue.birch"
  libbirch_line_(124);
  #line 124 "src/data/BooleanVectorValue.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::BooleanVectorValue>>>(value, handler_);
}

#line 23 "src/data/Buffer.birch"
birch::type::Buffer::Buffer(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 23 "src/data/Buffer.birch"
    super_type_(),
    #line 27 "src/data/Buffer.birch"
    content() {
  //
}

#line 32 "src/data/Buffer.birch"
void birch::type::Buffer::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Writer>>& writer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/data/Buffer.birch"
  libbirch_function_("accept", "src/data/Buffer.birch", 32);
  #line 33 "src/data/Buffer.birch"
  libbirch_line_(33);
  #line 33 "src/data/Buffer.birch"
  if (!this_()->content.query()) {
    #line 34 "src/data/Buffer.birch"
    libbirch_line_(34);
    #line 34 "src/data/Buffer.birch"
    this_()->content = birch::NilValue(handler_);
  }
  #line 36 "src/data/Buffer.birch"
  libbirch_line_(36);
  #line 36 "src/data/Buffer.birch"
  this_()->content.get()->accept(writer, handler_);
}

#line 42 "src/data/Buffer.birch"
void birch::type::Buffer::clear(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/data/Buffer.birch"
  libbirch_function_("clear", "src/data/Buffer.birch", 42);
  #line 43 "src/data/Buffer.birch"
  libbirch_line_(43);
  #line 43 "src/data/Buffer.birch"
  this_()->content = libbirch::nil;
}

#line 49 "src/data/Buffer.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>> birch::type::Buffer::find(const birch::type::String& key, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/data/Buffer.birch"
  libbirch_function_("find", "src/data/Buffer.birch", 49);
  #line 50 "src/data/Buffer.birch"
  libbirch_line_(50);
  #line 50 "src/data/Buffer.birch"
  if (this_()->content.query()) {
    #line 51 "src/data/Buffer.birch"
    libbirch_line_(51);
    #line 51 "src/data/Buffer.birch"
    return this_()->content.get()->find(key, handler_);
  } else {
    #line 53 "src/data/Buffer.birch"
    libbirch_line_(53);
    #line 53 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 60 "src/data/Buffer.birch"
void birch::type::Buffer::insert(const birch::type::String& key, const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "src/data/Buffer.birch"
  libbirch_function_("insert", "src/data/Buffer.birch", 60);
  #line 61 "src/data/Buffer.birch"
  libbirch_line_(61);
  #line 61 "src/data/Buffer.birch"
  if (!this_()->content.query()) {
    #line 62 "src/data/Buffer.birch"
    libbirch_line_(62);
    #line 62 "src/data/Buffer.birch"
    this_()->content = birch::ObjectValue(handler_);
  }
  #line 64 "src/data/Buffer.birch"
  libbirch_line_(64);
  #line 64 "src/data/Buffer.birch"
  this_()->content.get()->insert(key, value, handler_);
}

#line 70 "src/data/Buffer.birch"
void birch::type::Buffer::insert(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "src/data/Buffer.birch"
  libbirch_function_("insert", "src/data/Buffer.birch", 70);
  #line 71 "src/data/Buffer.birch"
  libbirch_line_(71);
  #line 71 "src/data/Buffer.birch"
  if (!this_()->content.query()) {
    #line 72 "src/data/Buffer.birch"
    libbirch_line_(72);
    #line 72 "src/data/Buffer.birch"
    this_()->content = birch::ArrayValue(handler_);
  }
  #line 74 "src/data/Buffer.birch"
  libbirch_line_(74);
  #line 74 "src/data/Buffer.birch"
  this_()->content.get()->insert(value, handler_);
}

#line 82 "src/data/Buffer.birch"
libbirch::Optional<birch::type::Boolean> birch::type::Buffer::getBoolean(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 82 "src/data/Buffer.birch"
  libbirch_function_("getBoolean", "src/data/Buffer.birch", 82);
  #line 83 "src/data/Buffer.birch"
  libbirch_line_(83);
  #line 83 "src/data/Buffer.birch"
  if (this_()->content.query()) {
    #line 84 "src/data/Buffer.birch"
    libbirch_line_(84);
    #line 84 "src/data/Buffer.birch"
    return this_()->content.get()->getBoolean(handler_);
  } else {
    #line 86 "src/data/Buffer.birch"
    libbirch_line_(86);
    #line 86 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 95 "src/data/Buffer.birch"
libbirch::Optional<birch::type::Integer> birch::type::Buffer::getInteger(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "src/data/Buffer.birch"
  libbirch_function_("getInteger", "src/data/Buffer.birch", 95);
  #line 96 "src/data/Buffer.birch"
  libbirch_line_(96);
  #line 96 "src/data/Buffer.birch"
  if (this_()->content.query()) {
    #line 97 "src/data/Buffer.birch"
    libbirch_line_(97);
    #line 97 "src/data/Buffer.birch"
    return this_()->content.get()->getInteger(handler_);
  } else {
    #line 99 "src/data/Buffer.birch"
    libbirch_line_(99);
    #line 99 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 108 "src/data/Buffer.birch"
libbirch::Optional<birch::type::Real> birch::type::Buffer::getReal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 108 "src/data/Buffer.birch"
  libbirch_function_("getReal", "src/data/Buffer.birch", 108);
  #line 109 "src/data/Buffer.birch"
  libbirch_line_(109);
  #line 109 "src/data/Buffer.birch"
  if (this_()->content.query()) {
    #line 110 "src/data/Buffer.birch"
    libbirch_line_(110);
    #line 110 "src/data/Buffer.birch"
    return this_()->content.get()->getReal(handler_);
  } else {
    #line 112 "src/data/Buffer.birch"
    libbirch_line_(112);
    #line 112 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 121 "src/data/Buffer.birch"
libbirch::Optional<birch::type::String> birch::type::Buffer::getString(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 121 "src/data/Buffer.birch"
  libbirch_function_("getString", "src/data/Buffer.birch", 121);
  #line 122 "src/data/Buffer.birch"
  libbirch_line_(122);
  #line 122 "src/data/Buffer.birch"
  if (this_()->content.query()) {
    #line 123 "src/data/Buffer.birch"
    libbirch_line_(123);
    #line 123 "src/data/Buffer.birch"
    return this_()->content.get()->getString(handler_);
  } else {
    #line 125 "src/data/Buffer.birch"
    libbirch_line_(125);
    #line 125 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 135 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,1>> birch::type::Buffer::getBooleanVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 135 "src/data/Buffer.birch"
  libbirch_function_("getBooleanVector", "src/data/Buffer.birch", 135);
  #line 136 "src/data/Buffer.birch"
  libbirch_line_(136);
  #line 136 "src/data/Buffer.birch"
  if (this_()->content.query()) {
    #line 137 "src/data/Buffer.birch"
    libbirch_line_(137);
    #line 137 "src/data/Buffer.birch"
    return this_()->content.get()->getBooleanVector(handler_);
  } else {
    #line 139 "src/data/Buffer.birch"
    libbirch_line_(139);
    #line 139 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 149 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,1>> birch::type::Buffer::getIntegerVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 149 "src/data/Buffer.birch"
  libbirch_function_("getIntegerVector", "src/data/Buffer.birch", 149);
  #line 150 "src/data/Buffer.birch"
  libbirch_line_(150);
  #line 150 "src/data/Buffer.birch"
  if (this_()->content.query()) {
    #line 151 "src/data/Buffer.birch"
    libbirch_line_(151);
    #line 151 "src/data/Buffer.birch"
    return this_()->content.get()->getIntegerVector(handler_);
  } else {
    #line 153 "src/data/Buffer.birch"
    libbirch_line_(153);
    #line 153 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 163 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::Buffer::getRealVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 163 "src/data/Buffer.birch"
  libbirch_function_("getRealVector", "src/data/Buffer.birch", 163);
  #line 164 "src/data/Buffer.birch"
  libbirch_line_(164);
  #line 164 "src/data/Buffer.birch"
  if (this_()->content.query()) {
    #line 165 "src/data/Buffer.birch"
    libbirch_line_(165);
    #line 165 "src/data/Buffer.birch"
    return this_()->content.get()->getRealVector(handler_);
  } else {
    #line 167 "src/data/Buffer.birch"
    libbirch_line_(167);
    #line 167 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 177 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,2>> birch::type::Buffer::getBooleanMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 177 "src/data/Buffer.birch"
  libbirch_function_("getBooleanMatrix", "src/data/Buffer.birch", 177);
  #line 178 "src/data/Buffer.birch"
  libbirch_line_(178);
  #line 178 "src/data/Buffer.birch"
  if (this_()->content.query()) {
    #line 179 "src/data/Buffer.birch"
    libbirch_line_(179);
    #line 179 "src/data/Buffer.birch"
    return this_()->content.get()->getBooleanMatrix(handler_);
  } else {
    #line 181 "src/data/Buffer.birch"
    libbirch_line_(181);
    #line 181 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 191 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,2>> birch::type::Buffer::getIntegerMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 191 "src/data/Buffer.birch"
  libbirch_function_("getIntegerMatrix", "src/data/Buffer.birch", 191);
  #line 192 "src/data/Buffer.birch"
  libbirch_line_(192);
  #line 192 "src/data/Buffer.birch"
  if (this_()->content.query()) {
    #line 193 "src/data/Buffer.birch"
    libbirch_line_(193);
    #line 193 "src/data/Buffer.birch"
    return this_()->content.get()->getIntegerMatrix(handler_);
  } else {
    #line 195 "src/data/Buffer.birch"
    libbirch_line_(195);
    #line 195 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 205 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::Buffer::getRealMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 205 "src/data/Buffer.birch"
  libbirch_function_("getRealMatrix", "src/data/Buffer.birch", 205);
  #line 206 "src/data/Buffer.birch"
  libbirch_line_(206);
  #line 206 "src/data/Buffer.birch"
  if (this_()->content.query()) {
    #line 207 "src/data/Buffer.birch"
    libbirch_line_(207);
    #line 207 "src/data/Buffer.birch"
    return this_()->content.get()->getRealMatrix(handler_);
  } else {
    #line 209 "src/data/Buffer.birch"
    libbirch_line_(209);
    #line 209 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 219 "src/data/Buffer.birch"
libbirch::Optional<birch::type::LLT> birch::type::Buffer::getLLT(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 219 "src/data/Buffer.birch"
  libbirch_function_("getLLT", "src/data/Buffer.birch", 219);
  #line 220 "src/data/Buffer.birch"
  libbirch_line_(220);
  #line 220 "src/data/Buffer.birch"
  if (this_()->content.query()) {
    #line 221 "src/data/Buffer.birch"
    libbirch_line_(221);
    #line 221 "src/data/Buffer.birch"
    auto X = this_()->content.get()->getRealMatrix(handler_);
    #line 222 "src/data/Buffer.birch"
    libbirch_line_(222);
    #line 222 "src/data/Buffer.birch"
    if (X.query()) {
      #line 223 "src/data/Buffer.birch"
      libbirch_line_(223);
      #line 223 "src/data/Buffer.birch"
      return birch::llt(X.get(), handler_);
    }
  }
  #line 226 "src/data/Buffer.birch"
  libbirch_line_(226);
  #line 226 "src/data/Buffer.birch"
  return libbirch::nil;
}

#line 236 "src/data/Buffer.birch"
libbirch::Optional<birch::type::Boolean> birch::type::Buffer::get(const libbirch::Optional<birch::type::Boolean>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 236 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 236);
  #line 237 "src/data/Buffer.birch"
  libbirch_line_(237);
  #line 237 "src/data/Buffer.birch"
  return this_()->getBoolean(handler_);
}

#line 247 "src/data/Buffer.birch"
libbirch::Optional<birch::type::Integer> birch::type::Buffer::get(const libbirch::Optional<birch::type::Integer>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 247 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 247);
  #line 248 "src/data/Buffer.birch"
  libbirch_line_(248);
  #line 248 "src/data/Buffer.birch"
  return this_()->getInteger(handler_);
}

#line 258 "src/data/Buffer.birch"
libbirch::Optional<birch::type::Real> birch::type::Buffer::get(const libbirch::Optional<birch::type::Real>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 258 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 258);
  #line 259 "src/data/Buffer.birch"
  libbirch_line_(259);
  #line 259 "src/data/Buffer.birch"
  return this_()->getReal(handler_);
}

#line 269 "src/data/Buffer.birch"
libbirch::Optional<birch::type::String> birch::type::Buffer::get(const libbirch::Optional<birch::type::String>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 269 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 269);
  #line 270 "src/data/Buffer.birch"
  libbirch_line_(270);
  #line 270 "src/data/Buffer.birch"
  return this_()->getString(handler_);
}

#line 280 "src/data/Buffer.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Object>>> birch::type::Buffer::get(const libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Object>>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 280 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 280);
  #line 281 "src/data/Buffer.birch"
  libbirch_line_(281);
  #line 281 "src/data/Buffer.birch"
  if (value.query()) {
    #line 282 "src/data/Buffer.birch"
    libbirch_line_(282);
    #line 282 "src/data/Buffer.birch"
    value.get()->read(shared_from_this_(), handler_);
  }
  #line 284 "src/data/Buffer.birch"
  libbirch_line_(284);
  #line 284 "src/data/Buffer.birch"
  return value;
}

#line 295 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,1>> birch::type::Buffer::get(const libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,1>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 295 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 295);
  #line 296 "src/data/Buffer.birch"
  libbirch_line_(296);
  #line 296 "src/data/Buffer.birch"
  return this_()->getBooleanVector(handler_);
}

#line 307 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,1>> birch::type::Buffer::get(const libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,1>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 307 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 307);
  #line 308 "src/data/Buffer.birch"
  libbirch_line_(308);
  #line 308 "src/data/Buffer.birch"
  return this_()->getIntegerVector(handler_);
}

#line 319 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::Buffer::get(const libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 319 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 319);
  #line 320 "src/data/Buffer.birch"
  libbirch_line_(320);
  #line 320 "src/data/Buffer.birch"
  return this_()->getRealVector(handler_);
}

#line 331 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,2>> birch::type::Buffer::get(const libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,2>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 331 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 331);
  #line 332 "src/data/Buffer.birch"
  libbirch_line_(332);
  #line 332 "src/data/Buffer.birch"
  return this_()->getBooleanMatrix(handler_);
}

#line 343 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,2>> birch::type::Buffer::get(const libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,2>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 343 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 343);
  #line 344 "src/data/Buffer.birch"
  libbirch_line_(344);
  #line 344 "src/data/Buffer.birch"
  return this_()->getIntegerMatrix(handler_);
}

#line 355 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::Buffer::get(const libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 355 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 355);
  #line 356 "src/data/Buffer.birch"
  libbirch_line_(356);
  #line 356 "src/data/Buffer.birch"
  return this_()->getRealMatrix(handler_);
}

#line 367 "src/data/Buffer.birch"
libbirch::Optional<birch::type::LLT> birch::type::Buffer::get(const libbirch::Optional<birch::type::LLT>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 367 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 367);
  #line 368 "src/data/Buffer.birch"
  libbirch_line_(368);
  #line 368 "src/data/Buffer.birch"
  return this_()->getLLT(handler_);
}

#line 374 "src/data/Buffer.birch"
void birch::type::Buffer::setNil(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 374 "src/data/Buffer.birch"
  libbirch_function_("setNil", "src/data/Buffer.birch", 374);
  #line 375 "src/data/Buffer.birch"
  libbirch_line_(375);
  #line 375 "src/data/Buffer.birch"
  this_()->content = birch::NilValue(handler_);
}

#line 381 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::Boolean& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 381 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 381);
  #line 382 "src/data/Buffer.birch"
  libbirch_line_(382);
  #line 382 "src/data/Buffer.birch"
  this_()->content = birch::BooleanValue(value, handler_);
}

#line 388 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::Integer& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 388 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 388);
  #line 389 "src/data/Buffer.birch"
  libbirch_line_(389);
  #line 389 "src/data/Buffer.birch"
  this_()->content = birch::IntegerValue(value, handler_);
}

#line 395 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::Real& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 395 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 395);
  #line 396 "src/data/Buffer.birch"
  libbirch_line_(396);
  #line 396 "src/data/Buffer.birch"
  this_()->content = birch::RealValue(value, handler_);
}

#line 402 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 402 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 402);
  #line 403 "src/data/Buffer.birch"
  libbirch_line_(403);
  #line 403 "src/data/Buffer.birch"
  this_()->content = birch::StringValue(value, handler_);
}

#line 409 "src/data/Buffer.birch"
void birch::type::Buffer::set(const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 409 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 409);
  #line 410 "src/data/Buffer.birch"
  libbirch_line_(410);
  #line 410 "src/data/Buffer.birch"
  value->write(shared_from_this_(), handler_);
}

#line 416 "src/data/Buffer.birch"
void birch::type::Buffer::set(const libbirch::DefaultArray<birch::type::Boolean,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 416 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 416);
  #line 417 "src/data/Buffer.birch"
  libbirch_line_(417);
  #line 417 "src/data/Buffer.birch"
  this_()->content = birch::BooleanVectorValue(value, handler_);
}

#line 423 "src/data/Buffer.birch"
void birch::type::Buffer::set(const libbirch::DefaultArray<birch::type::Integer,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 423 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 423);
  #line 424 "src/data/Buffer.birch"
  libbirch_line_(424);
  #line 424 "src/data/Buffer.birch"
  this_()->content = birch::IntegerVectorValue(value, handler_);
}

#line 430 "src/data/Buffer.birch"
void birch::type::Buffer::set(const libbirch::DefaultArray<birch::type::Real,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 430 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 430);
  #line 431 "src/data/Buffer.birch"
  libbirch_line_(431);
  #line 431 "src/data/Buffer.birch"
  this_()->content = birch::RealVectorValue(value, handler_);
}

#line 437 "src/data/Buffer.birch"
void birch::type::Buffer::set(const libbirch::DefaultArray<birch::type::String,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 437 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 437);
  #line 438 "src/data/Buffer.birch"
  libbirch_line_(438);
  #line 438 "src/data/Buffer.birch"
  this_()->content = birch::ArrayValue(handler_);
  #line 439 "src/data/Buffer.birch"
  libbirch_line_(439);
  #line 439 "src/data/Buffer.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(value, handler_); ++i) {
    #line 440 "src/data/Buffer.birch"
    libbirch_line_(440);
    #line 440 "src/data/Buffer.birch"
    this_()->push(value.get(libbirch::make_slice(i - 1)), handler_);
  }
}

#line 447 "src/data/Buffer.birch"
void birch::type::Buffer::set(const libbirch::DefaultArray<libbirch::Lazy<libbirch::Shared<birch::type::Object>>,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 447 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 447);
  #line 448 "src/data/Buffer.birch"
  libbirch_line_(448);
  #line 448 "src/data/Buffer.birch"
  this_()->content = birch::ArrayValue(handler_);
  #line 449 "src/data/Buffer.birch"
  libbirch_line_(449);
  #line 449 "src/data/Buffer.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(value, handler_); ++i) {
    #line 450 "src/data/Buffer.birch"
    libbirch_line_(450);
    #line 450 "src/data/Buffer.birch"
    this_()->push(value.get(libbirch::make_slice(i - 1)), handler_);
  }
}

#line 457 "src/data/Buffer.birch"
void birch::type::Buffer::set(const libbirch::DefaultArray<birch::type::Boolean,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 457 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 457);
  #line 458 "src/data/Buffer.birch"
  libbirch_line_(458);
  #line 458 "src/data/Buffer.birch"
  this_()->content = birch::ArrayValue(handler_);
  #line 459 "src/data/Buffer.birch"
  libbirch_line_(459);
  #line 459 "src/data/Buffer.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(value, handler_); ++i) {
    #line 460 "src/data/Buffer.birch"
    libbirch_line_(460);
    #line 460 "src/data/Buffer.birch"
    this_()->push(birch::row(value, i, handler_), handler_);
  }
}

#line 467 "src/data/Buffer.birch"
void birch::type::Buffer::set(const libbirch::DefaultArray<birch::type::Integer,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 467 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 467);
  #line 468 "src/data/Buffer.birch"
  libbirch_line_(468);
  #line 468 "src/data/Buffer.birch"
  this_()->content = birch::ArrayValue(handler_);
  #line 469 "src/data/Buffer.birch"
  libbirch_line_(469);
  #line 469 "src/data/Buffer.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(value, handler_); ++i) {
    #line 470 "src/data/Buffer.birch"
    libbirch_line_(470);
    #line 470 "src/data/Buffer.birch"
    this_()->push(birch::row(value, i, handler_), handler_);
  }
}

#line 477 "src/data/Buffer.birch"
void birch::type::Buffer::set(const libbirch::DefaultArray<birch::type::Real,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 477 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 477);
  #line 478 "src/data/Buffer.birch"
  libbirch_line_(478);
  #line 478 "src/data/Buffer.birch"
  this_()->content = birch::ArrayValue(handler_);
  #line 479 "src/data/Buffer.birch"
  libbirch_line_(479);
  #line 479 "src/data/Buffer.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(value, handler_); ++i) {
    #line 480 "src/data/Buffer.birch"
    libbirch_line_(480);
    #line 480 "src/data/Buffer.birch"
    this_()->push(birch::row(value, i, handler_), handler_);
  }
}

#line 487 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::LLT& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 487 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 487);
  #line 488 "src/data/Buffer.birch"
  libbirch_line_(488);
  #line 488 "src/data/Buffer.birch"
  this_()->set(birch::canonical(value, handler_), handler_);
}

#line 499 "src/data/Buffer.birch"
libbirch::Optional<birch::type::Boolean> birch::type::Buffer::getBoolean(const birch::type::String& key, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 499 "src/data/Buffer.birch"
  libbirch_function_("getBoolean", "src/data/Buffer.birch", 499);
  #line 500 "src/data/Buffer.birch"
  libbirch_line_(500);
  #line 500 "src/data/Buffer.birch"
  auto buffer = this_()->find(key, handler_);
  #line 501 "src/data/Buffer.birch"
  libbirch_line_(501);
  #line 501 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 502 "src/data/Buffer.birch"
    libbirch_line_(502);
    #line 502 "src/data/Buffer.birch"
    return buffer.get()->getBoolean(handler_);
  } else {
    #line 504 "src/data/Buffer.birch"
    libbirch_line_(504);
    #line 504 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 516 "src/data/Buffer.birch"
libbirch::Optional<birch::type::Integer> birch::type::Buffer::getInteger(const birch::type::String& key, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 516 "src/data/Buffer.birch"
  libbirch_function_("getInteger", "src/data/Buffer.birch", 516);
  #line 517 "src/data/Buffer.birch"
  libbirch_line_(517);
  #line 517 "src/data/Buffer.birch"
  auto buffer = this_()->find(key, handler_);
  #line 518 "src/data/Buffer.birch"
  libbirch_line_(518);
  #line 518 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 519 "src/data/Buffer.birch"
    libbirch_line_(519);
    #line 519 "src/data/Buffer.birch"
    return buffer.get()->getInteger(handler_);
  } else {
    #line 521 "src/data/Buffer.birch"
    libbirch_line_(521);
    #line 521 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 533 "src/data/Buffer.birch"
libbirch::Optional<birch::type::Real> birch::type::Buffer::getReal(const birch::type::String& key, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 533 "src/data/Buffer.birch"
  libbirch_function_("getReal", "src/data/Buffer.birch", 533);
  #line 534 "src/data/Buffer.birch"
  libbirch_line_(534);
  #line 534 "src/data/Buffer.birch"
  auto buffer = this_()->find(key, handler_);
  #line 535 "src/data/Buffer.birch"
  libbirch_line_(535);
  #line 535 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 536 "src/data/Buffer.birch"
    libbirch_line_(536);
    #line 536 "src/data/Buffer.birch"
    return buffer.get()->getReal(handler_);
  } else {
    #line 538 "src/data/Buffer.birch"
    libbirch_line_(538);
    #line 538 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 550 "src/data/Buffer.birch"
libbirch::Optional<birch::type::String> birch::type::Buffer::getString(const birch::type::String& key, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 550 "src/data/Buffer.birch"
  libbirch_function_("getString", "src/data/Buffer.birch", 550);
  #line 551 "src/data/Buffer.birch"
  libbirch_line_(551);
  #line 551 "src/data/Buffer.birch"
  auto buffer = this_()->find(key, handler_);
  #line 552 "src/data/Buffer.birch"
  libbirch_line_(552);
  #line 552 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 553 "src/data/Buffer.birch"
    libbirch_line_(553);
    #line 553 "src/data/Buffer.birch"
    return buffer.get()->getString(handler_);
  } else {
    #line 555 "src/data/Buffer.birch"
    libbirch_line_(555);
    #line 555 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 567 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,1>> birch::type::Buffer::getBooleanVector(const birch::type::String& key, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 567 "src/data/Buffer.birch"
  libbirch_function_("getBooleanVector", "src/data/Buffer.birch", 567);
  #line 568 "src/data/Buffer.birch"
  libbirch_line_(568);
  #line 568 "src/data/Buffer.birch"
  auto buffer = this_()->find(key, handler_);
  #line 569 "src/data/Buffer.birch"
  libbirch_line_(569);
  #line 569 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 570 "src/data/Buffer.birch"
    libbirch_line_(570);
    #line 570 "src/data/Buffer.birch"
    return buffer.get()->getBooleanVector(handler_);
  } else {
    #line 572 "src/data/Buffer.birch"
    libbirch_line_(572);
    #line 572 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 584 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,1>> birch::type::Buffer::getIntegerVector(const birch::type::String& key, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 584 "src/data/Buffer.birch"
  libbirch_function_("getIntegerVector", "src/data/Buffer.birch", 584);
  #line 585 "src/data/Buffer.birch"
  libbirch_line_(585);
  #line 585 "src/data/Buffer.birch"
  auto buffer = this_()->find(key, handler_);
  #line 586 "src/data/Buffer.birch"
  libbirch_line_(586);
  #line 586 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 587 "src/data/Buffer.birch"
    libbirch_line_(587);
    #line 587 "src/data/Buffer.birch"
    return buffer.get()->getIntegerVector(handler_);
  } else {
    #line 589 "src/data/Buffer.birch"
    libbirch_line_(589);
    #line 589 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 601 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::Buffer::getRealVector(const birch::type::String& key, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 601 "src/data/Buffer.birch"
  libbirch_function_("getRealVector", "src/data/Buffer.birch", 601);
  #line 602 "src/data/Buffer.birch"
  libbirch_line_(602);
  #line 602 "src/data/Buffer.birch"
  auto buffer = this_()->find(key, handler_);
  #line 603 "src/data/Buffer.birch"
  libbirch_line_(603);
  #line 603 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 604 "src/data/Buffer.birch"
    libbirch_line_(604);
    #line 604 "src/data/Buffer.birch"
    return buffer.get()->getRealVector(handler_);
  } else {
    #line 606 "src/data/Buffer.birch"
    libbirch_line_(606);
    #line 606 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 618 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,2>> birch::type::Buffer::getBooleanMatrix(const birch::type::String& key, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 618 "src/data/Buffer.birch"
  libbirch_function_("getBooleanMatrix", "src/data/Buffer.birch", 618);
  #line 619 "src/data/Buffer.birch"
  libbirch_line_(619);
  #line 619 "src/data/Buffer.birch"
  auto buffer = this_()->find(key, handler_);
  #line 620 "src/data/Buffer.birch"
  libbirch_line_(620);
  #line 620 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 621 "src/data/Buffer.birch"
    libbirch_line_(621);
    #line 621 "src/data/Buffer.birch"
    return buffer.get()->getBooleanMatrix(handler_);
  } else {
    #line 623 "src/data/Buffer.birch"
    libbirch_line_(623);
    #line 623 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 635 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,2>> birch::type::Buffer::getIntegerMatrix(const birch::type::String& key, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 635 "src/data/Buffer.birch"
  libbirch_function_("getIntegerMatrix", "src/data/Buffer.birch", 635);
  #line 636 "src/data/Buffer.birch"
  libbirch_line_(636);
  #line 636 "src/data/Buffer.birch"
  auto buffer = this_()->find(key, handler_);
  #line 637 "src/data/Buffer.birch"
  libbirch_line_(637);
  #line 637 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 638 "src/data/Buffer.birch"
    libbirch_line_(638);
    #line 638 "src/data/Buffer.birch"
    return buffer.get()->getIntegerMatrix(handler_);
  } else {
    #line 640 "src/data/Buffer.birch"
    libbirch_line_(640);
    #line 640 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 652 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::Buffer::getRealMatrix(const birch::type::String& key, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 652 "src/data/Buffer.birch"
  libbirch_function_("getRealMatrix", "src/data/Buffer.birch", 652);
  #line 653 "src/data/Buffer.birch"
  libbirch_line_(653);
  #line 653 "src/data/Buffer.birch"
  auto buffer = this_()->find(key, handler_);
  #line 654 "src/data/Buffer.birch"
  libbirch_line_(654);
  #line 654 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 655 "src/data/Buffer.birch"
    libbirch_line_(655);
    #line 655 "src/data/Buffer.birch"
    return buffer.get()->getRealMatrix(handler_);
  } else {
    #line 657 "src/data/Buffer.birch"
    libbirch_line_(657);
    #line 657 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 669 "src/data/Buffer.birch"
libbirch::Optional<birch::type::LLT> birch::type::Buffer::getLLT(const birch::type::String& key, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 669 "src/data/Buffer.birch"
  libbirch_function_("getLLT", "src/data/Buffer.birch", 669);
  #line 670 "src/data/Buffer.birch"
  libbirch_line_(670);
  #line 670 "src/data/Buffer.birch"
  auto buffer = this_()->find(key, handler_);
  #line 671 "src/data/Buffer.birch"
  libbirch_line_(671);
  #line 671 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 672 "src/data/Buffer.birch"
    libbirch_line_(672);
    #line 672 "src/data/Buffer.birch"
    return buffer.get()->getLLT(handler_);
  } else {
    #line 674 "src/data/Buffer.birch"
    libbirch_line_(674);
    #line 674 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 687 "src/data/Buffer.birch"
libbirch::Optional<birch::type::Boolean> birch::type::Buffer::get(const birch::type::String& key, const libbirch::Optional<birch::type::Boolean>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 687 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 687);
  #line 688 "src/data/Buffer.birch"
  libbirch_line_(688);
  #line 688 "src/data/Buffer.birch"
  return this_()->getBoolean(key, handler_);
}

#line 700 "src/data/Buffer.birch"
libbirch::Optional<birch::type::Integer> birch::type::Buffer::get(const birch::type::String& key, const libbirch::Optional<birch::type::Integer>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 700 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 700);
  #line 701 "src/data/Buffer.birch"
  libbirch_line_(701);
  #line 701 "src/data/Buffer.birch"
  return this_()->getInteger(key, handler_);
}

#line 713 "src/data/Buffer.birch"
libbirch::Optional<birch::type::Real> birch::type::Buffer::get(const birch::type::String& key, const libbirch::Optional<birch::type::Real>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 713 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 713);
  #line 714 "src/data/Buffer.birch"
  libbirch_line_(714);
  #line 714 "src/data/Buffer.birch"
  return this_()->getReal(key, handler_);
}

#line 726 "src/data/Buffer.birch"
libbirch::Optional<birch::type::String> birch::type::Buffer::get(const birch::type::String& key, const libbirch::Optional<birch::type::String>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 726 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 726);
  #line 727 "src/data/Buffer.birch"
  libbirch_line_(727);
  #line 727 "src/data/Buffer.birch"
  return this_()->getString(key, handler_);
}

#line 738 "src/data/Buffer.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Object>>> birch::type::Buffer::get(const birch::type::String& key, const libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Object>>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 738 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 738);
  #line 739 "src/data/Buffer.birch"
  libbirch_line_(739);
  #line 739 "src/data/Buffer.birch"
  auto buffer = this_()->find(key, handler_);
  #line 740 "src/data/Buffer.birch"
  libbirch_line_(740);
  #line 740 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 741 "src/data/Buffer.birch"
    libbirch_line_(741);
    #line 741 "src/data/Buffer.birch"
    return buffer.get()->get(value, handler_);
  } else {
    #line 743 "src/data/Buffer.birch"
    libbirch_line_(743);
    #line 743 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 756 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,1>> birch::type::Buffer::get(const birch::type::String& key, const libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,1>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 756 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 756);
  #line 757 "src/data/Buffer.birch"
  libbirch_line_(757);
  #line 757 "src/data/Buffer.birch"
  return this_()->getBooleanVector(key, handler_);
}

#line 769 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,1>> birch::type::Buffer::get(const birch::type::String& key, const libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,1>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 769 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 769);
  #line 770 "src/data/Buffer.birch"
  libbirch_line_(770);
  #line 770 "src/data/Buffer.birch"
  return this_()->getIntegerVector(key, handler_);
}

#line 782 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::Buffer::get(const birch::type::String& key, const libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 782 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 782);
  #line 783 "src/data/Buffer.birch"
  libbirch_line_(783);
  #line 783 "src/data/Buffer.birch"
  return this_()->getRealVector(key, handler_);
}

#line 795 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,2>> birch::type::Buffer::get(const birch::type::String& key, const libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,2>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 795 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 795);
  #line 796 "src/data/Buffer.birch"
  libbirch_line_(796);
  #line 796 "src/data/Buffer.birch"
  return this_()->getBooleanMatrix(key, handler_);
}

#line 808 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,2>> birch::type::Buffer::get(const birch::type::String& key, const libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,2>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 808 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 808);
  #line 809 "src/data/Buffer.birch"
  libbirch_line_(809);
  #line 809 "src/data/Buffer.birch"
  return this_()->getIntegerMatrix(key, handler_);
}

#line 821 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::Buffer::get(const birch::type::String& key, const libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 821 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 821);
  #line 822 "src/data/Buffer.birch"
  libbirch_line_(822);
  #line 822 "src/data/Buffer.birch"
  return this_()->getRealMatrix(key, handler_);
}

#line 834 "src/data/Buffer.birch"
libbirch::Optional<birch::type::LLT> birch::type::Buffer::get(const birch::type::String& key, const libbirch::Optional<birch::type::LLT>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 834 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 834);
  #line 835 "src/data/Buffer.birch"
  libbirch_line_(835);
  #line 835 "src/data/Buffer.birch"
  return this_()->getLLT(key, handler_);
}

#line 843 "src/data/Buffer.birch"
void birch::type::Buffer::setNil(const birch::type::String& key, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 843 "src/data/Buffer.birch"
  libbirch_function_("setNil", "src/data/Buffer.birch", 843);
  #line 844 "src/data/Buffer.birch"
  libbirch_line_(844);
  #line 844 "src/data/Buffer.birch"
  this_()->insert(key, birch::Buffer(handler_), handler_);
}

#line 853 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& key, const birch::type::Boolean& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 853 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 853);
  #line 854 "src/data/Buffer.birch"
  libbirch_line_(854);
  #line 854 "src/data/Buffer.birch"
  this_()->insert(key, birch::Buffer(value, handler_), handler_);
}

#line 863 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& key, const birch::type::Integer& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 863 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 863);
  #line 864 "src/data/Buffer.birch"
  libbirch_line_(864);
  #line 864 "src/data/Buffer.birch"
  this_()->insert(key, birch::Buffer(value, handler_), handler_);
}

#line 873 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& key, const birch::type::Real& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 873 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 873);
  #line 874 "src/data/Buffer.birch"
  libbirch_line_(874);
  #line 874 "src/data/Buffer.birch"
  this_()->insert(key, birch::Buffer(value, handler_), handler_);
}

#line 883 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& key, const birch::type::String& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 883 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 883);
  #line 884 "src/data/Buffer.birch"
  libbirch_line_(884);
  #line 884 "src/data/Buffer.birch"
  this_()->insert(key, birch::Buffer(value, handler_), handler_);
}

#line 893 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& key, const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 893 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 893);
  #line 894 "src/data/Buffer.birch"
  libbirch_line_(894);
  #line 894 "src/data/Buffer.birch"
  auto buffer = birch::Buffer(handler_);
  #line 895 "src/data/Buffer.birch"
  libbirch_line_(895);
  #line 895 "src/data/Buffer.birch"
  value->write(buffer, handler_);
  #line 896 "src/data/Buffer.birch"
  libbirch_line_(896);
  #line 896 "src/data/Buffer.birch"
  this_()->insert(key, buffer, handler_);
}

#line 905 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& key, const libbirch::DefaultArray<birch::type::Boolean,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 905 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 905);
  #line 906 "src/data/Buffer.birch"
  libbirch_line_(906);
  #line 906 "src/data/Buffer.birch"
  this_()->insert(key, birch::Buffer(value, handler_), handler_);
}

#line 915 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& key, const libbirch::DefaultArray<birch::type::Integer,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 915 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 915);
  #line 916 "src/data/Buffer.birch"
  libbirch_line_(916);
  #line 916 "src/data/Buffer.birch"
  this_()->insert(key, birch::Buffer(value, handler_), handler_);
}

#line 925 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& key, const libbirch::DefaultArray<birch::type::Real,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 925 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 925);
  #line 926 "src/data/Buffer.birch"
  libbirch_line_(926);
  #line 926 "src/data/Buffer.birch"
  this_()->insert(key, birch::Buffer(value, handler_), handler_);
}

#line 935 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& key, const libbirch::DefaultArray<birch::type::String,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 935 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 935);
  #line 936 "src/data/Buffer.birch"
  libbirch_line_(936);
  #line 936 "src/data/Buffer.birch"
  this_()->insert(key, birch::Buffer(value, handler_), handler_);
}

#line 945 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& key, const libbirch::DefaultArray<libbirch::Lazy<libbirch::Shared<birch::type::Object>>,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 945 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 945);
  #line 946 "src/data/Buffer.birch"
  libbirch_line_(946);
  #line 946 "src/data/Buffer.birch"
  this_()->insert(key, birch::Buffer(value, handler_), handler_);
}

#line 955 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& key, const libbirch::DefaultArray<birch::type::Boolean,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 955 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 955);
  #line 956 "src/data/Buffer.birch"
  libbirch_line_(956);
  #line 956 "src/data/Buffer.birch"
  this_()->insert(key, birch::Buffer(value, handler_), handler_);
}

#line 965 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& key, const libbirch::DefaultArray<birch::type::Integer,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 965 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 965);
  #line 966 "src/data/Buffer.birch"
  libbirch_line_(966);
  #line 966 "src/data/Buffer.birch"
  this_()->insert(key, birch::Buffer(value, handler_), handler_);
}

#line 975 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& key, const libbirch::DefaultArray<birch::type::Real,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 975 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 975);
  #line 976 "src/data/Buffer.birch"
  libbirch_line_(976);
  #line 976 "src/data/Buffer.birch"
  this_()->insert(key, birch::Buffer(value, handler_), handler_);
}

#line 985 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& key, const birch::type::LLT& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 985 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 985);
  #line 986 "src/data/Buffer.birch"
  libbirch_line_(986);
  #line 986 "src/data/Buffer.birch"
  this_()->insert(key, birch::Buffer(birch::canonical(value, handler_), handler_), handler_);
}

#line 993 "src/data/Buffer.birch"
birch::type::Integer birch::type::Buffer::size(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 993 "src/data/Buffer.birch"
  libbirch_function_("size", "src/data/Buffer.birch", 993);
  #line 994 "src/data/Buffer.birch"
  libbirch_line_(994);
  #line 994 "src/data/Buffer.birch"
  if (this_()->content.query()) {
    #line 995 "src/data/Buffer.birch"
    libbirch_line_(995);
    #line 995 "src/data/Buffer.birch"
    return this_()->content.get()->size(handler_);
  } else {
    #line 997 "src/data/Buffer.birch"
    libbirch_line_(997);
    #line 997 "src/data/Buffer.birch"
    return birch::type::Integer(0);
  }
}

#line 1007 "src/data/Buffer.birch"
birch::type::Integer birch::type::Buffer::size(const birch::type::String& key, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1007 "src/data/Buffer.birch"
  libbirch_function_("size", "src/data/Buffer.birch", 1007);
  #line 1008 "src/data/Buffer.birch"
  libbirch_line_(1008);
  #line 1008 "src/data/Buffer.birch"
  auto buffer = this_()->find(key, handler_);
  #line 1009 "src/data/Buffer.birch"
  libbirch_line_(1009);
  #line 1009 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 1010 "src/data/Buffer.birch"
    libbirch_line_(1010);
    #line 1010 "src/data/Buffer.birch"
    return buffer.get()->size(handler_);
  } else {
    #line 1012 "src/data/Buffer.birch"
    libbirch_line_(1012);
    #line 1012 "src/data/Buffer.birch"
    return birch::type::Integer(0);
  }
}

#line 1019 "src/data/Buffer.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Iterator<libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>>>> birch::type::Buffer::walk(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1019 "src/data/Buffer.birch"
  libbirch_function_("walk", "src/data/Buffer.birch", 1019);
  #line 1020 "src/data/Buffer.birch"
  libbirch_line_(1020);
  #line 1020 "src/data/Buffer.birch"
  if (this_()->content.query()) {
    #line 1021 "src/data/Buffer.birch"
    libbirch_line_(1021);
    #line 1021 "src/data/Buffer.birch"
    return this_()->content.get()->walk(handler_);
  } else {
    #line 1023 "src/data/Buffer.birch"
    libbirch_line_(1023);
    #line 1023 "src/data/Buffer.birch"
    return birch::EmptyIterator<libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>>(handler_);
  }
}

#line 1032 "src/data/Buffer.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Iterator<libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>>>> birch::type::Buffer::walk(const birch::type::String& key, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1032 "src/data/Buffer.birch"
  libbirch_function_("walk", "src/data/Buffer.birch", 1032);
  #line 1033 "src/data/Buffer.birch"
  libbirch_line_(1033);
  #line 1033 "src/data/Buffer.birch"
  auto buffer = this_()->find(key, handler_);
  #line 1034 "src/data/Buffer.birch"
  libbirch_line_(1034);
  #line 1034 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 1035 "src/data/Buffer.birch"
    libbirch_line_(1035);
    #line 1035 "src/data/Buffer.birch"
    return buffer.get()->walk(handler_);
  } else {
    #line 1037 "src/data/Buffer.birch"
    libbirch_line_(1037);
    #line 1037 "src/data/Buffer.birch"
    return birch::EmptyIterator<libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>>(handler_);
  }
}

#line 1044 "src/data/Buffer.birch"
void birch::type::Buffer::pushNil(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1044 "src/data/Buffer.birch"
  libbirch_function_("pushNil", "src/data/Buffer.birch", 1044);
  #line 1045 "src/data/Buffer.birch"
  libbirch_line_(1045);
  #line 1045 "src/data/Buffer.birch"
  if (this_()->content.query()) {
    #line 1046 "src/data/Buffer.birch"
    libbirch_line_(1046);
    #line 1046 "src/data/Buffer.birch"
    this_()->content = this_()->content.get()->pushNil(handler_);
  } else {
    #line 1048 "src/data/Buffer.birch"
    libbirch_line_(1048);
    #line 1048 "src/data/Buffer.birch"
    this_()->content = birch::ArrayValue(handler_);
    #line 1049 "src/data/Buffer.birch"
    libbirch_line_(1049);
    #line 1049 "src/data/Buffer.birch"
    this_()->content.get()->pushNil(handler_);
  }
}

#line 1056 "src/data/Buffer.birch"
void birch::type::Buffer::push(const birch::type::Boolean& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1056 "src/data/Buffer.birch"
  libbirch_function_("push", "src/data/Buffer.birch", 1056);
  #line 1057 "src/data/Buffer.birch"
  libbirch_line_(1057);
  #line 1057 "src/data/Buffer.birch"
  if (this_()->content.query()) {
    #line 1058 "src/data/Buffer.birch"
    libbirch_line_(1058);
    #line 1058 "src/data/Buffer.birch"
    this_()->content = this_()->content.get()->push(value, handler_);
  } else {
    #line 1060 "src/data/Buffer.birch"
    libbirch_line_(1060);
    #line 1060 "src/data/Buffer.birch"
    this_()->set(libbirch::make_array({ value }), handler_);
  }
}

#line 1067 "src/data/Buffer.birch"
void birch::type::Buffer::push(const birch::type::Integer& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1067 "src/data/Buffer.birch"
  libbirch_function_("push", "src/data/Buffer.birch", 1067);
  #line 1068 "src/data/Buffer.birch"
  libbirch_line_(1068);
  #line 1068 "src/data/Buffer.birch"
  if (this_()->content.query()) {
    #line 1069 "src/data/Buffer.birch"
    libbirch_line_(1069);
    #line 1069 "src/data/Buffer.birch"
    this_()->content = this_()->content.get()->push(value, handler_);
  } else {
    #line 1071 "src/data/Buffer.birch"
    libbirch_line_(1071);
    #line 1071 "src/data/Buffer.birch"
    this_()->set(libbirch::make_array({ value }), handler_);
  }
}

#line 1078 "src/data/Buffer.birch"
void birch::type::Buffer::push(const birch::type::Real& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1078 "src/data/Buffer.birch"
  libbirch_function_("push", "src/data/Buffer.birch", 1078);
  #line 1079 "src/data/Buffer.birch"
  libbirch_line_(1079);
  #line 1079 "src/data/Buffer.birch"
  if (this_()->content.query()) {
    #line 1080 "src/data/Buffer.birch"
    libbirch_line_(1080);
    #line 1080 "src/data/Buffer.birch"
    this_()->content = this_()->content.get()->push(value, handler_);
  } else {
    #line 1082 "src/data/Buffer.birch"
    libbirch_line_(1082);
    #line 1082 "src/data/Buffer.birch"
    this_()->set(libbirch::make_array({ value }), handler_);
  }
}

#line 1089 "src/data/Buffer.birch"
void birch::type::Buffer::push(const birch::type::String& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1089 "src/data/Buffer.birch"
  libbirch_function_("push", "src/data/Buffer.birch", 1089);
  #line 1090 "src/data/Buffer.birch"
  libbirch_line_(1090);
  #line 1090 "src/data/Buffer.birch"
  if (this_()->content.query()) {
    #line 1091 "src/data/Buffer.birch"
    libbirch_line_(1091);
    #line 1091 "src/data/Buffer.birch"
    this_()->content = this_()->content.get()->push(value, handler_);
  } else {
    #line 1093 "src/data/Buffer.birch"
    libbirch_line_(1093);
    #line 1093 "src/data/Buffer.birch"
    this_()->set(libbirch::make_array({ value }), handler_);
  }
}

#line 1100 "src/data/Buffer.birch"
void birch::type::Buffer::push(const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1100 "src/data/Buffer.birch"
  libbirch_function_("push", "src/data/Buffer.birch", 1100);
  #line 1101 "src/data/Buffer.birch"
  libbirch_line_(1101);
  #line 1101 "src/data/Buffer.birch"
  if (this_()->content.query()) {
    #line 1102 "src/data/Buffer.birch"
    libbirch_line_(1102);
    #line 1102 "src/data/Buffer.birch"
    this_()->content = this_()->content.get()->push(value, handler_);
  } else {
    #line 1104 "src/data/Buffer.birch"
    libbirch_line_(1104);
    #line 1104 "src/data/Buffer.birch"
    this_()->set(libbirch::make_array({ value }), handler_);
  }
}

#line 1111 "src/data/Buffer.birch"
void birch::type::Buffer::push(const libbirch::DefaultArray<birch::type::Boolean,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1111 "src/data/Buffer.birch"
  libbirch_function_("push", "src/data/Buffer.birch", 1111);
  #line 1112 "src/data/Buffer.birch"
  libbirch_line_(1112);
  #line 1112 "src/data/Buffer.birch"
  if (this_()->content.query()) {
    #line 1113 "src/data/Buffer.birch"
    libbirch_line_(1113);
    #line 1113 "src/data/Buffer.birch"
    this_()->content = this_()->content.get()->push(value, handler_);
  } else {
    #line 1115 "src/data/Buffer.birch"
    libbirch_line_(1115);
    #line 1115 "src/data/Buffer.birch"
    this_()->content = birch::ArrayValue(handler_);
    #line 1116 "src/data/Buffer.birch"
    libbirch_line_(1116);
    #line 1116 "src/data/Buffer.birch"
    this_()->content.get()->push(value, handler_);
  }
}

#line 1123 "src/data/Buffer.birch"
void birch::type::Buffer::push(const libbirch::DefaultArray<birch::type::Integer,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1123 "src/data/Buffer.birch"
  libbirch_function_("push", "src/data/Buffer.birch", 1123);
  #line 1124 "src/data/Buffer.birch"
  libbirch_line_(1124);
  #line 1124 "src/data/Buffer.birch"
  if (this_()->content.query()) {
    #line 1125 "src/data/Buffer.birch"
    libbirch_line_(1125);
    #line 1125 "src/data/Buffer.birch"
    this_()->content = this_()->content.get()->push(value, handler_);
  } else {
    #line 1127 "src/data/Buffer.birch"
    libbirch_line_(1127);
    #line 1127 "src/data/Buffer.birch"
    this_()->content = birch::ArrayValue(handler_);
    #line 1128 "src/data/Buffer.birch"
    libbirch_line_(1128);
    #line 1128 "src/data/Buffer.birch"
    this_()->content.get()->push(value, handler_);
  }
}

#line 1135 "src/data/Buffer.birch"
void birch::type::Buffer::push(const libbirch::DefaultArray<birch::type::Real,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1135 "src/data/Buffer.birch"
  libbirch_function_("push", "src/data/Buffer.birch", 1135);
  #line 1136 "src/data/Buffer.birch"
  libbirch_line_(1136);
  #line 1136 "src/data/Buffer.birch"
  if (this_()->content.query()) {
    #line 1137 "src/data/Buffer.birch"
    libbirch_line_(1137);
    #line 1137 "src/data/Buffer.birch"
    this_()->content = this_()->content.get()->push(value, handler_);
  } else {
    #line 1139 "src/data/Buffer.birch"
    libbirch_line_(1139);
    #line 1139 "src/data/Buffer.birch"
    this_()->content = birch::ArrayValue(handler_);
    #line 1140 "src/data/Buffer.birch"
    libbirch_line_(1140);
    #line 1140 "src/data/Buffer.birch"
    this_()->content.get()->push(value, handler_);
  }
}

#line 23 "src/data/Buffer.birch"
birch::type::Buffer* birch::type::make_Buffer_() {
  #line 23 "src/data/Buffer.birch"
  return new birch::type::Buffer();
  #line 23 "src/data/Buffer.birch"
}

#line 1159 "src/data/Buffer.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> birch::Buffer(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1159 "src/data/Buffer.birch"
  libbirch_function_("Buffer", "src/data/Buffer.birch", 1159);
  #line 1160 "src/data/Buffer.birch"
  libbirch_line_(1160);
  #line 1160 "src/data/Buffer.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>>(handler_);
}

#line 4 "src/data/Entry.birch"
birch::type::Entry::Entry(const birch::type::String& key, const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/data/Entry.birch"
    super_type_(),
    #line 8 "src/data/Entry.birch"
    key(key),
    #line 13 "src/data/Entry.birch"
    value(value) {
  //
}

#line 19 "src/data/Entry.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Entry>> birch::Entry(const birch::type::String& key, const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/data/Entry.birch"
  libbirch_function_("Entry", "src/data/Entry.birch", 19);
  #line 20 "src/data/Entry.birch"
  libbirch_line_(20);
  #line 20 "src/data/Entry.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Entry>>>(key, value, handler_);
}

#line 4 "src/data/IntegerValue.birch"
birch::type::IntegerValue::IntegerValue(const birch::type::Integer& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/data/IntegerValue.birch"
    super_type_(),
    #line 8 "src/data/IntegerValue.birch"
    value(value) {
  //
}

#line 10 "src/data/IntegerValue.birch"
void birch::type::IntegerValue::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Writer>>& writer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/data/IntegerValue.birch"
  libbirch_function_("accept", "src/data/IntegerValue.birch", 10);
  #line 11 "src/data/IntegerValue.birch"
  libbirch_line_(11);
  #line 11 "src/data/IntegerValue.birch"
  writer->visit(shared_from_this_(), handler_);
}

#line 14 "src/data/IntegerValue.birch"
libbirch::Optional<birch::type::Integer> birch::type::IntegerValue::getInteger(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/data/IntegerValue.birch"
  libbirch_function_("getInteger", "src/data/IntegerValue.birch", 14);
  #line 15 "src/data/IntegerValue.birch"
  libbirch_line_(15);
  #line 15 "src/data/IntegerValue.birch"
  return this_()->value;
}

#line 18 "src/data/IntegerValue.birch"
libbirch::Optional<birch::type::Real> birch::type::IntegerValue::getReal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/data/IntegerValue.birch"
  libbirch_function_("getReal", "src/data/IntegerValue.birch", 18);
  #line 19 "src/data/IntegerValue.birch"
  libbirch_line_(19);
  #line 19 "src/data/IntegerValue.birch"
  return birch::Real(this_()->value, handler_);
}

#line 22 "src/data/IntegerValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,1>> birch::type::IntegerValue::getIntegerVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/data/IntegerValue.birch"
  libbirch_function_("getIntegerVector", "src/data/IntegerValue.birch", 22);
  #line 23 "src/data/IntegerValue.birch"
  libbirch_line_(23);
  #line 23 "src/data/IntegerValue.birch"
  return birch::vector(this_()->value, birch::type::Integer(1), handler_);
}

#line 26 "src/data/IntegerValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::IntegerValue::getRealVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/data/IntegerValue.birch"
  libbirch_function_("getRealVector", "src/data/IntegerValue.birch", 26);
  #line 27 "src/data/IntegerValue.birch"
  libbirch_line_(27);
  #line 27 "src/data/IntegerValue.birch"
  return birch::vector(birch::Real(this_()->value, handler_), birch::type::Integer(1), handler_);
}

#line 30 "src/data/IntegerValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,2>> birch::type::IntegerValue::getIntegerMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/data/IntegerValue.birch"
  libbirch_function_("getIntegerMatrix", "src/data/IntegerValue.birch", 30);
  #line 31 "src/data/IntegerValue.birch"
  libbirch_line_(31);
  #line 31 "src/data/IntegerValue.birch"
  return birch::matrix(this_()->value, birch::type::Integer(1), birch::type::Integer(1), handler_);
}

#line 34 "src/data/IntegerValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::IntegerValue::getRealMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/data/IntegerValue.birch"
  libbirch_function_("getRealMatrix", "src/data/IntegerValue.birch", 34);
  #line 35 "src/data/IntegerValue.birch"
  libbirch_line_(35);
  #line 35 "src/data/IntegerValue.birch"
  return birch::matrix(birch::Real(this_()->value, handler_), birch::type::Integer(1), birch::type::Integer(1), handler_);
}

#line 38 "src/data/IntegerValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::IntegerValue::pushNil(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "src/data/IntegerValue.birch"
  libbirch_function_("pushNil", "src/data/IntegerValue.birch", 38);
  #line 39 "src/data/IntegerValue.birch"
  libbirch_line_(39);
  #line 39 "src/data/IntegerValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 40 "src/data/IntegerValue.birch"
  libbirch_line_(40);
  #line 40 "src/data/IntegerValue.birch"
  o->push(this_()->value, handler_);
  #line 41 "src/data/IntegerValue.birch"
  libbirch_line_(41);
  #line 41 "src/data/IntegerValue.birch"
  o->pushNil(handler_);
  #line 42 "src/data/IntegerValue.birch"
  libbirch_line_(42);
  #line 42 "src/data/IntegerValue.birch"
  return o;
}

#line 45 "src/data/IntegerValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::IntegerValue::push(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "src/data/IntegerValue.birch"
  libbirch_function_("push", "src/data/IntegerValue.birch", 45);
  #line 46 "src/data/IntegerValue.birch"
  libbirch_line_(46);
  #line 46 "src/data/IntegerValue.birch"
  return birch::IntegerVectorValue(libbirch::make_array({ this_()->value, birch::Integer(x, handler_) }), handler_);
}

#line 49 "src/data/IntegerValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::IntegerValue::push(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/data/IntegerValue.birch"
  libbirch_function_("push", "src/data/IntegerValue.birch", 49);
  #line 50 "src/data/IntegerValue.birch"
  libbirch_line_(50);
  #line 50 "src/data/IntegerValue.birch"
  return birch::IntegerVectorValue(libbirch::make_array({ this_()->value, x }), handler_);
}

#line 53 "src/data/IntegerValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::IntegerValue::push(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "src/data/IntegerValue.birch"
  libbirch_function_("push", "src/data/IntegerValue.birch", 53);
  #line 54 "src/data/IntegerValue.birch"
  libbirch_line_(54);
  #line 54 "src/data/IntegerValue.birch"
  return birch::RealVectorValue(libbirch::make_array({ birch::Real(this_()->value, handler_), x }), handler_);
}

#line 57 "src/data/IntegerValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::IntegerValue::push(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 57 "src/data/IntegerValue.birch"
  libbirch_function_("push", "src/data/IntegerValue.birch", 57);
  #line 58 "src/data/IntegerValue.birch"
  libbirch_line_(58);
  #line 58 "src/data/IntegerValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 59 "src/data/IntegerValue.birch"
  libbirch_line_(59);
  #line 59 "src/data/IntegerValue.birch"
  o->push(this_()->value, handler_);
  #line 60 "src/data/IntegerValue.birch"
  libbirch_line_(60);
  #line 60 "src/data/IntegerValue.birch"
  o->push(x, handler_);
  #line 61 "src/data/IntegerValue.birch"
  libbirch_line_(61);
  #line 61 "src/data/IntegerValue.birch"
  return o;
}

#line 64 "src/data/IntegerValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::IntegerValue::push(const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "src/data/IntegerValue.birch"
  libbirch_function_("push", "src/data/IntegerValue.birch", 64);
  #line 65 "src/data/IntegerValue.birch"
  libbirch_line_(65);
  #line 65 "src/data/IntegerValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 66 "src/data/IntegerValue.birch"
  libbirch_line_(66);
  #line 66 "src/data/IntegerValue.birch"
  o->push(this_()->value, handler_);
  #line 67 "src/data/IntegerValue.birch"
  libbirch_line_(67);
  #line 67 "src/data/IntegerValue.birch"
  o->push(x, handler_);
  #line 68 "src/data/IntegerValue.birch"
  libbirch_line_(68);
  #line 68 "src/data/IntegerValue.birch"
  return o;
}

#line 71 "src/data/IntegerValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::IntegerValue::push(const libbirch::DefaultArray<birch::type::Boolean,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 71 "src/data/IntegerValue.birch"
  libbirch_function_("push", "src/data/IntegerValue.birch", 71);
  #line 72 "src/data/IntegerValue.birch"
  libbirch_line_(72);
  #line 72 "src/data/IntegerValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 73 "src/data/IntegerValue.birch"
  libbirch_line_(73);
  #line 73 "src/data/IntegerValue.birch"
  o->push(this_()->value, handler_);
  #line 74 "src/data/IntegerValue.birch"
  libbirch_line_(74);
  #line 74 "src/data/IntegerValue.birch"
  o->push(x, handler_);
  #line 75 "src/data/IntegerValue.birch"
  libbirch_line_(75);
  #line 75 "src/data/IntegerValue.birch"
  return o;
}

#line 78 "src/data/IntegerValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::IntegerValue::push(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 78 "src/data/IntegerValue.birch"
  libbirch_function_("push", "src/data/IntegerValue.birch", 78);
  #line 79 "src/data/IntegerValue.birch"
  libbirch_line_(79);
  #line 79 "src/data/IntegerValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 80 "src/data/IntegerValue.birch"
  libbirch_line_(80);
  #line 80 "src/data/IntegerValue.birch"
  o->push(this_()->value, handler_);
  #line 81 "src/data/IntegerValue.birch"
  libbirch_line_(81);
  #line 81 "src/data/IntegerValue.birch"
  o->push(x, handler_);
  #line 82 "src/data/IntegerValue.birch"
  libbirch_line_(82);
  #line 82 "src/data/IntegerValue.birch"
  return o;
}

#line 85 "src/data/IntegerValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::IntegerValue::push(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 85 "src/data/IntegerValue.birch"
  libbirch_function_("push", "src/data/IntegerValue.birch", 85);
  #line 86 "src/data/IntegerValue.birch"
  libbirch_line_(86);
  #line 86 "src/data/IntegerValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 87 "src/data/IntegerValue.birch"
  libbirch_line_(87);
  #line 87 "src/data/IntegerValue.birch"
  o->push(this_()->value, handler_);
  #line 88 "src/data/IntegerValue.birch"
  libbirch_line_(88);
  #line 88 "src/data/IntegerValue.birch"
  o->push(x, handler_);
  #line 89 "src/data/IntegerValue.birch"
  libbirch_line_(89);
  #line 89 "src/data/IntegerValue.birch"
  return o;
}

#line 96 "src/data/IntegerValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IntegerValue>> birch::IntegerValue(const birch::type::Integer& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 96 "src/data/IntegerValue.birch"
  libbirch_function_("IntegerValue", "src/data/IntegerValue.birch", 96);
  #line 97 "src/data/IntegerValue.birch"
  libbirch_line_(97);
  #line 97 "src/data/IntegerValue.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::IntegerValue>>>(value, handler_);
}

#line 4 "src/data/IntegerVectorValue.birch"
birch::type::IntegerVectorValue::IntegerVectorValue(const libbirch::DefaultArray<birch::type::Integer,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/data/IntegerVectorValue.birch"
    super_type_(),
    #line 8 "src/data/IntegerVectorValue.birch"
    value(value) {
  //
}

#line 10 "src/data/IntegerVectorValue.birch"
void birch::type::IntegerVectorValue::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Writer>>& writer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/data/IntegerVectorValue.birch"
  libbirch_function_("accept", "src/data/IntegerVectorValue.birch", 10);
  #line 11 "src/data/IntegerVectorValue.birch"
  libbirch_line_(11);
  #line 11 "src/data/IntegerVectorValue.birch"
  writer->visit(shared_from_this_(), handler_);
}

#line 14 "src/data/IntegerVectorValue.birch"
birch::type::Integer birch::type::IntegerVectorValue::size(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/data/IntegerVectorValue.birch"
  libbirch_function_("size", "src/data/IntegerVectorValue.birch", 14);
  #line 15 "src/data/IntegerVectorValue.birch"
  libbirch_line_(15);
  #line 15 "src/data/IntegerVectorValue.birch"
  return birch::length(this_()->value, handler_);
}

#line 18 "src/data/IntegerVectorValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,1>> birch::type::IntegerVectorValue::getIntegerVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/data/IntegerVectorValue.birch"
  libbirch_function_("getIntegerVector", "src/data/IntegerVectorValue.birch", 18);
  #line 19 "src/data/IntegerVectorValue.birch"
  libbirch_line_(19);
  #line 19 "src/data/IntegerVectorValue.birch"
  return this_()->value;
}

#line 22 "src/data/IntegerVectorValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,2>> birch::type::IntegerVectorValue::getIntegerMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/data/IntegerVectorValue.birch"
  libbirch_function_("getIntegerMatrix", "src/data/IntegerVectorValue.birch", 22);
  #line 23 "src/data/IntegerVectorValue.birch"
  libbirch_line_(23);
  #line 23 "src/data/IntegerVectorValue.birch"
  return birch::column(this_()->value, handler_);
}

#line 26 "src/data/IntegerVectorValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::IntegerVectorValue::getRealVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/data/IntegerVectorValue.birch"
  libbirch_function_("getRealVector", "src/data/IntegerVectorValue.birch", 26);
  #line 27 "src/data/IntegerVectorValue.birch"
  libbirch_line_(27);
  #line 27 "src/data/IntegerVectorValue.birch"
  return birch::Real(this_()->value, handler_);
}

#line 30 "src/data/IntegerVectorValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::IntegerVectorValue::getRealMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/data/IntegerVectorValue.birch"
  libbirch_function_("getRealMatrix", "src/data/IntegerVectorValue.birch", 30);
  #line 31 "src/data/IntegerVectorValue.birch"
  libbirch_line_(31);
  #line 31 "src/data/IntegerVectorValue.birch"
  return birch::column(birch::Real(this_()->value, handler_), handler_);
}

#line 34 "src/data/IntegerVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::IntegerVectorValue::pushNil(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/data/IntegerVectorValue.birch"
  libbirch_function_("pushNil", "src/data/IntegerVectorValue.birch", 34);
  #line 35 "src/data/IntegerVectorValue.birch"
  libbirch_line_(35);
  #line 35 "src/data/IntegerVectorValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 36 "src/data/IntegerVectorValue.birch"
  libbirch_line_(36);
  #line 36 "src/data/IntegerVectorValue.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(this_()->value, handler_); ++i) {
    #line 37 "src/data/IntegerVectorValue.birch"
    libbirch_line_(37);
    #line 37 "src/data/IntegerVectorValue.birch"
    o->push(this_()->value.get(libbirch::make_slice(i - 1)), handler_);
  }
  #line 39 "src/data/IntegerVectorValue.birch"
  libbirch_line_(39);
  #line 39 "src/data/IntegerVectorValue.birch"
  o->pushNil(handler_);
  #line 40 "src/data/IntegerVectorValue.birch"
  libbirch_line_(40);
  #line 40 "src/data/IntegerVectorValue.birch"
  return o;
}

#line 43 "src/data/IntegerVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::IntegerVectorValue::push(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "src/data/IntegerVectorValue.birch"
  libbirch_function_("push", "src/data/IntegerVectorValue.birch", 43);
  #line 44 "src/data/IntegerVectorValue.birch"
  libbirch_line_(44);
  #line 44 "src/data/IntegerVectorValue.birch"
  return this_()->push(birch::Integer(x, handler_), handler_);
}

#line 47 "src/data/IntegerVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::IntegerVectorValue::push(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "src/data/IntegerVectorValue.birch"
  libbirch_function_("push", "src/data/IntegerVectorValue.birch", 47);
  #line 48 "src/data/IntegerVectorValue.birch"

    value.insert(value.size(), x);
      #line 51 "src/data/IntegerVectorValue.birch"
  libbirch_line_(51);
  #line 51 "src/data/IntegerVectorValue.birch"
  return shared_from_this_();
}

#line 54 "src/data/IntegerVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::IntegerVectorValue::push(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "src/data/IntegerVectorValue.birch"
  libbirch_function_("push", "src/data/IntegerVectorValue.birch", 54);
  #line 55 "src/data/IntegerVectorValue.birch"
  libbirch_line_(55);
  #line 55 "src/data/IntegerVectorValue.birch"
  auto n = birch::length(this_()->value, handler_);
  #line 56 "src/data/IntegerVectorValue.birch"
  libbirch_line_(56);
  #line 56 "src/data/IntegerVectorValue.birch"
  return birch::RealVectorValue(birch::vector(std::function<birch::type::Integer(birch::type::Integer,const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_
)>([=](const birch::type::Integer& i, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr) {
    #line 57 "src/data/IntegerVectorValue.birch"
    libbirch_line_(57);
    #line 57 "src/data/IntegerVectorValue.birch"
    if (i == n + birch::type::Integer(1)) {
      #line 58 "src/data/IntegerVectorValue.birch"
      libbirch_line_(58);
      #line 58 "src/data/IntegerVectorValue.birch"
      return x;
    } else {
      #line 60 "src/data/IntegerVectorValue.birch"
      libbirch_line_(60);
      #line 60 "src/data/IntegerVectorValue.birch"
      return birch::Real(this_()->value.get(libbirch::make_slice(i - 1)), handler_);
    }
  }), n + birch::type::Integer(1), handler_), handler_);
}

#line 65 "src/data/IntegerVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::IntegerVectorValue::push(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "src/data/IntegerVectorValue.birch"
  libbirch_function_("push", "src/data/IntegerVectorValue.birch", 65);
  #line 66 "src/data/IntegerVectorValue.birch"
  libbirch_line_(66);
  #line 66 "src/data/IntegerVectorValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 67 "src/data/IntegerVectorValue.birch"
  libbirch_line_(67);
  #line 67 "src/data/IntegerVectorValue.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(this_()->value, handler_); ++i) {
    #line 68 "src/data/IntegerVectorValue.birch"
    libbirch_line_(68);
    #line 68 "src/data/IntegerVectorValue.birch"
    o->push(this_()->value.get(libbirch::make_slice(i - 1)), handler_);
  }
  #line 70 "src/data/IntegerVectorValue.birch"
  libbirch_line_(70);
  #line 70 "src/data/IntegerVectorValue.birch"
  o->push(x, handler_);
  #line 71 "src/data/IntegerVectorValue.birch"
  libbirch_line_(71);
  #line 71 "src/data/IntegerVectorValue.birch"
  return o;
}

#line 74 "src/data/IntegerVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::IntegerVectorValue::push(const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 74 "src/data/IntegerVectorValue.birch"
  libbirch_function_("push", "src/data/IntegerVectorValue.birch", 74);
  #line 75 "src/data/IntegerVectorValue.birch"
  libbirch_line_(75);
  #line 75 "src/data/IntegerVectorValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 76 "src/data/IntegerVectorValue.birch"
  libbirch_line_(76);
  #line 76 "src/data/IntegerVectorValue.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(this_()->value, handler_); ++i) {
    #line 77 "src/data/IntegerVectorValue.birch"
    libbirch_line_(77);
    #line 77 "src/data/IntegerVectorValue.birch"
    o->push(this_()->value.get(libbirch::make_slice(i - 1)), handler_);
  }
  #line 79 "src/data/IntegerVectorValue.birch"
  libbirch_line_(79);
  #line 79 "src/data/IntegerVectorValue.birch"
  o->push(x, handler_);
  #line 80 "src/data/IntegerVectorValue.birch"
  libbirch_line_(80);
  #line 80 "src/data/IntegerVectorValue.birch"
  return o;
}

#line 83 "src/data/IntegerVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::IntegerVectorValue::push(const libbirch::DefaultArray<birch::type::Boolean,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 83 "src/data/IntegerVectorValue.birch"
  libbirch_function_("push", "src/data/IntegerVectorValue.birch", 83);
  #line 84 "src/data/IntegerVectorValue.birch"
  libbirch_line_(84);
  #line 84 "src/data/IntegerVectorValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 85 "src/data/IntegerVectorValue.birch"
  libbirch_line_(85);
  #line 85 "src/data/IntegerVectorValue.birch"
  o->push(this_()->value, handler_);
  #line 86 "src/data/IntegerVectorValue.birch"
  libbirch_line_(86);
  #line 86 "src/data/IntegerVectorValue.birch"
  o->push(x, handler_);
  #line 87 "src/data/IntegerVectorValue.birch"
  libbirch_line_(87);
  #line 87 "src/data/IntegerVectorValue.birch"
  return o;
}

#line 90 "src/data/IntegerVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::IntegerVectorValue::push(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 90 "src/data/IntegerVectorValue.birch"
  libbirch_function_("push", "src/data/IntegerVectorValue.birch", 90);
  #line 91 "src/data/IntegerVectorValue.birch"
  libbirch_line_(91);
  #line 91 "src/data/IntegerVectorValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 92 "src/data/IntegerVectorValue.birch"
  libbirch_line_(92);
  #line 92 "src/data/IntegerVectorValue.birch"
  o->push(this_()->value, handler_);
  #line 93 "src/data/IntegerVectorValue.birch"
  libbirch_line_(93);
  #line 93 "src/data/IntegerVectorValue.birch"
  o->push(x, handler_);
  #line 94 "src/data/IntegerVectorValue.birch"
  libbirch_line_(94);
  #line 94 "src/data/IntegerVectorValue.birch"
  return o;
}

#line 97 "src/data/IntegerVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::IntegerVectorValue::push(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 97 "src/data/IntegerVectorValue.birch"
  libbirch_function_("push", "src/data/IntegerVectorValue.birch", 97);
  #line 98 "src/data/IntegerVectorValue.birch"
  libbirch_line_(98);
  #line 98 "src/data/IntegerVectorValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 99 "src/data/IntegerVectorValue.birch"
  libbirch_line_(99);
  #line 99 "src/data/IntegerVectorValue.birch"
  o->push(this_()->value, handler_);
  #line 100 "src/data/IntegerVectorValue.birch"
  libbirch_line_(100);
  #line 100 "src/data/IntegerVectorValue.birch"
  o->push(x, handler_);
  #line 101 "src/data/IntegerVectorValue.birch"
  libbirch_line_(101);
  #line 101 "src/data/IntegerVectorValue.birch"
  return o;
}

#line 108 "src/data/IntegerVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IntegerVectorValue>> birch::IntegerVectorValue(const libbirch::DefaultArray<birch::type::Integer,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 108 "src/data/IntegerVectorValue.birch"
  libbirch_function_("IntegerVectorValue", "src/data/IntegerVectorValue.birch", 108);
  #line 109 "src/data/IntegerVectorValue.birch"
  libbirch_line_(109);
  #line 109 "src/data/IntegerVectorValue.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::IntegerVectorValue>>>(value, handler_);
}

#line 4 "src/data/NilValue.birch"
birch::type::NilValue::NilValue(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/data/NilValue.birch"
    super_type_() {
  //
}

#line 5 "src/data/NilValue.birch"
void birch::type::NilValue::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Writer>>& writer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 5 "src/data/NilValue.birch"
  libbirch_function_("accept", "src/data/NilValue.birch", 5);
  #line 6 "src/data/NilValue.birch"
  libbirch_line_(6);
  #line 6 "src/data/NilValue.birch"
  writer->visit(shared_from_this_(), handler_);
}

#line 9 "src/data/NilValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::NilValue::pushNil(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/data/NilValue.birch"
  libbirch_function_("pushNil", "src/data/NilValue.birch", 9);
  #line 10 "src/data/NilValue.birch"
  libbirch_line_(10);
  #line 10 "src/data/NilValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 11 "src/data/NilValue.birch"
  libbirch_line_(11);
  #line 11 "src/data/NilValue.birch"
  o->pushNil(handler_);
  #line 12 "src/data/NilValue.birch"
  libbirch_line_(12);
  #line 12 "src/data/NilValue.birch"
  o->pushNil(handler_);
  #line 13 "src/data/NilValue.birch"
  libbirch_line_(13);
  #line 13 "src/data/NilValue.birch"
  return o;
}

#line 16 "src/data/NilValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::NilValue::push(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/data/NilValue.birch"
  libbirch_function_("push", "src/data/NilValue.birch", 16);
  #line 17 "src/data/NilValue.birch"
  libbirch_line_(17);
  #line 17 "src/data/NilValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 18 "src/data/NilValue.birch"
  libbirch_line_(18);
  #line 18 "src/data/NilValue.birch"
  o->pushNil(handler_);
  #line 19 "src/data/NilValue.birch"
  libbirch_line_(19);
  #line 19 "src/data/NilValue.birch"
  o->push(x, handler_);
  #line 20 "src/data/NilValue.birch"
  libbirch_line_(20);
  #line 20 "src/data/NilValue.birch"
  return o;
}

#line 23 "src/data/NilValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::NilValue::push(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "src/data/NilValue.birch"
  libbirch_function_("push", "src/data/NilValue.birch", 23);
  #line 24 "src/data/NilValue.birch"
  libbirch_line_(24);
  #line 24 "src/data/NilValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 25 "src/data/NilValue.birch"
  libbirch_line_(25);
  #line 25 "src/data/NilValue.birch"
  o->pushNil(handler_);
  #line 26 "src/data/NilValue.birch"
  libbirch_line_(26);
  #line 26 "src/data/NilValue.birch"
  o->push(x, handler_);
  #line 27 "src/data/NilValue.birch"
  libbirch_line_(27);
  #line 27 "src/data/NilValue.birch"
  return o;
}

#line 30 "src/data/NilValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::NilValue::push(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/data/NilValue.birch"
  libbirch_function_("push", "src/data/NilValue.birch", 30);
  #line 31 "src/data/NilValue.birch"
  libbirch_line_(31);
  #line 31 "src/data/NilValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 32 "src/data/NilValue.birch"
  libbirch_line_(32);
  #line 32 "src/data/NilValue.birch"
  o->pushNil(handler_);
  #line 33 "src/data/NilValue.birch"
  libbirch_line_(33);
  #line 33 "src/data/NilValue.birch"
  o->push(x, handler_);
  #line 34 "src/data/NilValue.birch"
  libbirch_line_(34);
  #line 34 "src/data/NilValue.birch"
  return o;
}

#line 37 "src/data/NilValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::NilValue::push(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/data/NilValue.birch"
  libbirch_function_("push", "src/data/NilValue.birch", 37);
  #line 38 "src/data/NilValue.birch"
  libbirch_line_(38);
  #line 38 "src/data/NilValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 39 "src/data/NilValue.birch"
  libbirch_line_(39);
  #line 39 "src/data/NilValue.birch"
  o->pushNil(handler_);
  #line 40 "src/data/NilValue.birch"
  libbirch_line_(40);
  #line 40 "src/data/NilValue.birch"
  o->push(x, handler_);
  #line 41 "src/data/NilValue.birch"
  libbirch_line_(41);
  #line 41 "src/data/NilValue.birch"
  return o;
}

#line 44 "src/data/NilValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::NilValue::push(const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/data/NilValue.birch"
  libbirch_function_("push", "src/data/NilValue.birch", 44);
  #line 45 "src/data/NilValue.birch"
  libbirch_line_(45);
  #line 45 "src/data/NilValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 46 "src/data/NilValue.birch"
  libbirch_line_(46);
  #line 46 "src/data/NilValue.birch"
  o->pushNil(handler_);
  #line 47 "src/data/NilValue.birch"
  libbirch_line_(47);
  #line 47 "src/data/NilValue.birch"
  o->push(x, handler_);
  #line 48 "src/data/NilValue.birch"
  libbirch_line_(48);
  #line 48 "src/data/NilValue.birch"
  return o;
}

#line 51 "src/data/NilValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::NilValue::push(const libbirch::DefaultArray<birch::type::Boolean,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 51 "src/data/NilValue.birch"
  libbirch_function_("push", "src/data/NilValue.birch", 51);
  #line 52 "src/data/NilValue.birch"
  libbirch_line_(52);
  #line 52 "src/data/NilValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 53 "src/data/NilValue.birch"
  libbirch_line_(53);
  #line 53 "src/data/NilValue.birch"
  o->pushNil(handler_);
  #line 54 "src/data/NilValue.birch"
  libbirch_line_(54);
  #line 54 "src/data/NilValue.birch"
  o->push(x, handler_);
  #line 55 "src/data/NilValue.birch"
  libbirch_line_(55);
  #line 55 "src/data/NilValue.birch"
  return o;
}

#line 58 "src/data/NilValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::NilValue::push(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "src/data/NilValue.birch"
  libbirch_function_("push", "src/data/NilValue.birch", 58);
  #line 59 "src/data/NilValue.birch"
  libbirch_line_(59);
  #line 59 "src/data/NilValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 60 "src/data/NilValue.birch"
  libbirch_line_(60);
  #line 60 "src/data/NilValue.birch"
  o->pushNil(handler_);
  #line 61 "src/data/NilValue.birch"
  libbirch_line_(61);
  #line 61 "src/data/NilValue.birch"
  o->push(x, handler_);
  #line 62 "src/data/NilValue.birch"
  libbirch_line_(62);
  #line 62 "src/data/NilValue.birch"
  return o;
}

#line 65 "src/data/NilValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::NilValue::push(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "src/data/NilValue.birch"
  libbirch_function_("push", "src/data/NilValue.birch", 65);
  #line 66 "src/data/NilValue.birch"
  libbirch_line_(66);
  #line 66 "src/data/NilValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 67 "src/data/NilValue.birch"
  libbirch_line_(67);
  #line 67 "src/data/NilValue.birch"
  o->pushNil(handler_);
  #line 68 "src/data/NilValue.birch"
  libbirch_line_(68);
  #line 68 "src/data/NilValue.birch"
  o->push(x, handler_);
  #line 69 "src/data/NilValue.birch"
  libbirch_line_(69);
  #line 69 "src/data/NilValue.birch"
  return o;
}

#line 4 "src/data/NilValue.birch"
birch::type::NilValue* birch::type::make_NilValue_() {
  #line 4 "src/data/NilValue.birch"
  return new birch::type::NilValue();
  #line 4 "src/data/NilValue.birch"
}

#line 76 "src/data/NilValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::NilValue>> birch::NilValue(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "src/data/NilValue.birch"
  libbirch_function_("NilValue", "src/data/NilValue.birch", 76);
  #line 77 "src/data/NilValue.birch"
  libbirch_line_(77);
  #line 77 "src/data/NilValue.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::NilValue>>>(handler_);
}

#line 4 "src/data/ObjectValue.birch"
birch::type::ObjectValue::ObjectValue(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/data/ObjectValue.birch"
    super_type_(),
    #line 10 "src/data/ObjectValue.birch"
    entries() {
  //
}

#line 12 "src/data/ObjectValue.birch"
void birch::type::ObjectValue::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Writer>>& writer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 12 "src/data/ObjectValue.birch"
  libbirch_function_("accept", "src/data/ObjectValue.birch", 12);
  #line 13 "src/data/ObjectValue.birch"
  libbirch_line_(13);
  #line 13 "src/data/ObjectValue.birch"
  writer->visit(shared_from_this_(), handler_);
}

#line 16 "src/data/ObjectValue.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>> birch::type::ObjectValue::find(const birch::type::String& key, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/data/ObjectValue.birch"
  libbirch_function_("find", "src/data/ObjectValue.birch", 16);
  #line 17 "src/data/ObjectValue.birch"
  libbirch_line_(17);
  #line 17 "src/data/ObjectValue.birch"
  auto iter = this_()->entries->walk(handler_);
  #line 18 "src/data/ObjectValue.birch"
  libbirch_line_(18);
  #line 18 "src/data/ObjectValue.birch"
  while (iter->hasNext(handler_)) {
    #line 19 "src/data/ObjectValue.birch"
    libbirch_line_(19);
    #line 19 "src/data/ObjectValue.birch"
    auto entry = iter->next(handler_);
    #line 20 "src/data/ObjectValue.birch"
    libbirch_line_(20);
    #line 20 "src/data/ObjectValue.birch"
    if (entry->key == key) {
      #line 21 "src/data/ObjectValue.birch"
      libbirch_line_(21);
      #line 21 "src/data/ObjectValue.birch"
      return entry->value;
    }
  }
  #line 24 "src/data/ObjectValue.birch"
  libbirch_line_(24);
  #line 24 "src/data/ObjectValue.birch"
  return libbirch::nil;
}

#line 27 "src/data/ObjectValue.birch"
void birch::type::ObjectValue::insert(const birch::type::String& key, const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/data/ObjectValue.birch"
  libbirch_function_("insert", "src/data/ObjectValue.birch", 27);
  #line 28 "src/data/ObjectValue.birch"
  libbirch_line_(28);
  #line 28 "src/data/ObjectValue.birch"
  this_()->entries->pushBack(birch::Entry(key, value, handler_), handler_);
}

#line 31 "src/data/ObjectValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::ObjectValue::pushNil(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "src/data/ObjectValue.birch"
  libbirch_function_("pushNil", "src/data/ObjectValue.birch", 31);
  #line 32 "src/data/ObjectValue.birch"
  libbirch_line_(32);
  #line 32 "src/data/ObjectValue.birch"
  auto b = birch::Buffer(handler_);
  #line 33 "src/data/ObjectValue.birch"
  libbirch_line_(33);
  #line 33 "src/data/ObjectValue.birch"
  b->content = shared_from_this_();
  #line 34 "src/data/ObjectValue.birch"
  libbirch_line_(34);
  #line 34 "src/data/ObjectValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 35 "src/data/ObjectValue.birch"
  libbirch_line_(35);
  #line 35 "src/data/ObjectValue.birch"
  o->push(b, handler_);
  #line 36 "src/data/ObjectValue.birch"
  libbirch_line_(36);
  #line 36 "src/data/ObjectValue.birch"
  o->pushNil(handler_);
  #line 37 "src/data/ObjectValue.birch"
  libbirch_line_(37);
  #line 37 "src/data/ObjectValue.birch"
  return o;
}

#line 40 "src/data/ObjectValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::ObjectValue::push(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "src/data/ObjectValue.birch"
  libbirch_function_("push", "src/data/ObjectValue.birch", 40);
  #line 41 "src/data/ObjectValue.birch"
  libbirch_line_(41);
  #line 41 "src/data/ObjectValue.birch"
  auto b = birch::Buffer(handler_);
  #line 42 "src/data/ObjectValue.birch"
  libbirch_line_(42);
  #line 42 "src/data/ObjectValue.birch"
  b->content = shared_from_this_();
  #line 43 "src/data/ObjectValue.birch"
  libbirch_line_(43);
  #line 43 "src/data/ObjectValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 44 "src/data/ObjectValue.birch"
  libbirch_line_(44);
  #line 44 "src/data/ObjectValue.birch"
  o->push(b, handler_);
  #line 45 "src/data/ObjectValue.birch"
  libbirch_line_(45);
  #line 45 "src/data/ObjectValue.birch"
  o->push(x, handler_);
  #line 46 "src/data/ObjectValue.birch"
  libbirch_line_(46);
  #line 46 "src/data/ObjectValue.birch"
  return o;
}

#line 49 "src/data/ObjectValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::ObjectValue::push(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/data/ObjectValue.birch"
  libbirch_function_("push", "src/data/ObjectValue.birch", 49);
  #line 50 "src/data/ObjectValue.birch"
  libbirch_line_(50);
  #line 50 "src/data/ObjectValue.birch"
  auto b = birch::Buffer(handler_);
  #line 51 "src/data/ObjectValue.birch"
  libbirch_line_(51);
  #line 51 "src/data/ObjectValue.birch"
  b->content = shared_from_this_();
  #line 52 "src/data/ObjectValue.birch"
  libbirch_line_(52);
  #line 52 "src/data/ObjectValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 53 "src/data/ObjectValue.birch"
  libbirch_line_(53);
  #line 53 "src/data/ObjectValue.birch"
  o->push(b, handler_);
  #line 54 "src/data/ObjectValue.birch"
  libbirch_line_(54);
  #line 54 "src/data/ObjectValue.birch"
  o->push(x, handler_);
  #line 55 "src/data/ObjectValue.birch"
  libbirch_line_(55);
  #line 55 "src/data/ObjectValue.birch"
  return o;
}

#line 58 "src/data/ObjectValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::ObjectValue::push(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "src/data/ObjectValue.birch"
  libbirch_function_("push", "src/data/ObjectValue.birch", 58);
  #line 59 "src/data/ObjectValue.birch"
  libbirch_line_(59);
  #line 59 "src/data/ObjectValue.birch"
  auto b = birch::Buffer(handler_);
  #line 60 "src/data/ObjectValue.birch"
  libbirch_line_(60);
  #line 60 "src/data/ObjectValue.birch"
  b->content = shared_from_this_();
  #line 61 "src/data/ObjectValue.birch"
  libbirch_line_(61);
  #line 61 "src/data/ObjectValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 62 "src/data/ObjectValue.birch"
  libbirch_line_(62);
  #line 62 "src/data/ObjectValue.birch"
  o->push(b, handler_);
  #line 63 "src/data/ObjectValue.birch"
  libbirch_line_(63);
  #line 63 "src/data/ObjectValue.birch"
  o->push(x, handler_);
  #line 64 "src/data/ObjectValue.birch"
  libbirch_line_(64);
  #line 64 "src/data/ObjectValue.birch"
  return o;
}

#line 67 "src/data/ObjectValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::ObjectValue::push(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 67 "src/data/ObjectValue.birch"
  libbirch_function_("push", "src/data/ObjectValue.birch", 67);
  #line 68 "src/data/ObjectValue.birch"
  libbirch_line_(68);
  #line 68 "src/data/ObjectValue.birch"
  auto b = birch::Buffer(handler_);
  #line 69 "src/data/ObjectValue.birch"
  libbirch_line_(69);
  #line 69 "src/data/ObjectValue.birch"
  b->content = shared_from_this_();
  #line 70 "src/data/ObjectValue.birch"
  libbirch_line_(70);
  #line 70 "src/data/ObjectValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 71 "src/data/ObjectValue.birch"
  libbirch_line_(71);
  #line 71 "src/data/ObjectValue.birch"
  o->push(b, handler_);
  #line 72 "src/data/ObjectValue.birch"
  libbirch_line_(72);
  #line 72 "src/data/ObjectValue.birch"
  o->push(x, handler_);
  #line 73 "src/data/ObjectValue.birch"
  libbirch_line_(73);
  #line 73 "src/data/ObjectValue.birch"
  return o;
}

#line 76 "src/data/ObjectValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::ObjectValue::push(const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "src/data/ObjectValue.birch"
  libbirch_function_("push", "src/data/ObjectValue.birch", 76);
  #line 77 "src/data/ObjectValue.birch"
  libbirch_line_(77);
  #line 77 "src/data/ObjectValue.birch"
  auto b = birch::Buffer(handler_);
  #line 78 "src/data/ObjectValue.birch"
  libbirch_line_(78);
  #line 78 "src/data/ObjectValue.birch"
  b->content = shared_from_this_();
  #line 79 "src/data/ObjectValue.birch"
  libbirch_line_(79);
  #line 79 "src/data/ObjectValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 80 "src/data/ObjectValue.birch"
  libbirch_line_(80);
  #line 80 "src/data/ObjectValue.birch"
  o->push(b, handler_);
  #line 81 "src/data/ObjectValue.birch"
  libbirch_line_(81);
  #line 81 "src/data/ObjectValue.birch"
  o->push(x, handler_);
  #line 82 "src/data/ObjectValue.birch"
  libbirch_line_(82);
  #line 82 "src/data/ObjectValue.birch"
  return o;
}

#line 85 "src/data/ObjectValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::ObjectValue::push(const libbirch::DefaultArray<birch::type::Boolean,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 85 "src/data/ObjectValue.birch"
  libbirch_function_("push", "src/data/ObjectValue.birch", 85);
  #line 86 "src/data/ObjectValue.birch"
  libbirch_line_(86);
  #line 86 "src/data/ObjectValue.birch"
  auto b = birch::Buffer(handler_);
  #line 87 "src/data/ObjectValue.birch"
  libbirch_line_(87);
  #line 87 "src/data/ObjectValue.birch"
  b->content = shared_from_this_();
  #line 88 "src/data/ObjectValue.birch"
  libbirch_line_(88);
  #line 88 "src/data/ObjectValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 89 "src/data/ObjectValue.birch"
  libbirch_line_(89);
  #line 89 "src/data/ObjectValue.birch"
  o->push(b, handler_);
  #line 90 "src/data/ObjectValue.birch"
  libbirch_line_(90);
  #line 90 "src/data/ObjectValue.birch"
  o->push(x, handler_);
  #line 91 "src/data/ObjectValue.birch"
  libbirch_line_(91);
  #line 91 "src/data/ObjectValue.birch"
  return o;
}

#line 94 "src/data/ObjectValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::ObjectValue::push(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 94 "src/data/ObjectValue.birch"
  libbirch_function_("push", "src/data/ObjectValue.birch", 94);
  #line 95 "src/data/ObjectValue.birch"
  libbirch_line_(95);
  #line 95 "src/data/ObjectValue.birch"
  auto b = birch::Buffer(handler_);
  #line 96 "src/data/ObjectValue.birch"
  libbirch_line_(96);
  #line 96 "src/data/ObjectValue.birch"
  b->content = shared_from_this_();
  #line 97 "src/data/ObjectValue.birch"
  libbirch_line_(97);
  #line 97 "src/data/ObjectValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 98 "src/data/ObjectValue.birch"
  libbirch_line_(98);
  #line 98 "src/data/ObjectValue.birch"
  o->push(b, handler_);
  #line 99 "src/data/ObjectValue.birch"
  libbirch_line_(99);
  #line 99 "src/data/ObjectValue.birch"
  o->push(x, handler_);
  #line 100 "src/data/ObjectValue.birch"
  libbirch_line_(100);
  #line 100 "src/data/ObjectValue.birch"
  return o;
}

#line 103 "src/data/ObjectValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::ObjectValue::push(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 103 "src/data/ObjectValue.birch"
  libbirch_function_("push", "src/data/ObjectValue.birch", 103);
  #line 104 "src/data/ObjectValue.birch"
  libbirch_line_(104);
  #line 104 "src/data/ObjectValue.birch"
  auto b = birch::Buffer(handler_);
  #line 105 "src/data/ObjectValue.birch"
  libbirch_line_(105);
  #line 105 "src/data/ObjectValue.birch"
  b->content = shared_from_this_();
  #line 106 "src/data/ObjectValue.birch"
  libbirch_line_(106);
  #line 106 "src/data/ObjectValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 107 "src/data/ObjectValue.birch"
  libbirch_line_(107);
  #line 107 "src/data/ObjectValue.birch"
  o->push(b, handler_);
  #line 108 "src/data/ObjectValue.birch"
  libbirch_line_(108);
  #line 108 "src/data/ObjectValue.birch"
  o->push(x, handler_);
  #line 109 "src/data/ObjectValue.birch"
  libbirch_line_(109);
  #line 109 "src/data/ObjectValue.birch"
  return o;
}

#line 4 "src/data/ObjectValue.birch"
birch::type::ObjectValue* birch::type::make_ObjectValue_() {
  #line 4 "src/data/ObjectValue.birch"
  return new birch::type::ObjectValue();
  #line 4 "src/data/ObjectValue.birch"
}

#line 116 "src/data/ObjectValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ObjectValue>> birch::ObjectValue(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 116 "src/data/ObjectValue.birch"
  libbirch_function_("ObjectValue", "src/data/ObjectValue.birch", 116);
  #line 117 "src/data/ObjectValue.birch"
  libbirch_line_(117);
  #line 117 "src/data/ObjectValue.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::ObjectValue>>>(handler_);
}

#line 4 "src/data/RealValue.birch"
birch::type::RealValue::RealValue(const birch::type::Real& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/data/RealValue.birch"
    super_type_(),
    #line 8 "src/data/RealValue.birch"
    value(value) {
  //
}

#line 10 "src/data/RealValue.birch"
void birch::type::RealValue::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Writer>>& writer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/data/RealValue.birch"
  libbirch_function_("accept", "src/data/RealValue.birch", 10);
  #line 11 "src/data/RealValue.birch"
  libbirch_line_(11);
  #line 11 "src/data/RealValue.birch"
  writer->visit(shared_from_this_(), handler_);
}

#line 14 "src/data/RealValue.birch"
libbirch::Optional<birch::type::Real> birch::type::RealValue::getReal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/data/RealValue.birch"
  libbirch_function_("getReal", "src/data/RealValue.birch", 14);
  #line 15 "src/data/RealValue.birch"
  libbirch_line_(15);
  #line 15 "src/data/RealValue.birch"
  return this_()->value;
}

#line 18 "src/data/RealValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::RealValue::getRealVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/data/RealValue.birch"
  libbirch_function_("getRealVector", "src/data/RealValue.birch", 18);
  #line 19 "src/data/RealValue.birch"
  libbirch_line_(19);
  #line 19 "src/data/RealValue.birch"
  return birch::vector(this_()->value, birch::type::Integer(1), handler_);
}

#line 22 "src/data/RealValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::RealValue::getRealMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/data/RealValue.birch"
  libbirch_function_("getRealMatrix", "src/data/RealValue.birch", 22);
  #line 23 "src/data/RealValue.birch"
  libbirch_line_(23);
  #line 23 "src/data/RealValue.birch"
  return birch::matrix(this_()->value, birch::type::Integer(1), birch::type::Integer(1), handler_);
}

#line 26 "src/data/RealValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::RealValue::pushNil(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/data/RealValue.birch"
  libbirch_function_("pushNil", "src/data/RealValue.birch", 26);
  #line 27 "src/data/RealValue.birch"
  libbirch_line_(27);
  #line 27 "src/data/RealValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 28 "src/data/RealValue.birch"
  libbirch_line_(28);
  #line 28 "src/data/RealValue.birch"
  o->push(this_()->value, handler_);
  #line 29 "src/data/RealValue.birch"
  libbirch_line_(29);
  #line 29 "src/data/RealValue.birch"
  o->pushNil(handler_);
  #line 30 "src/data/RealValue.birch"
  libbirch_line_(30);
  #line 30 "src/data/RealValue.birch"
  return o;
}

#line 33 "src/data/RealValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::RealValue::push(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/data/RealValue.birch"
  libbirch_function_("push", "src/data/RealValue.birch", 33);
  #line 34 "src/data/RealValue.birch"
  libbirch_line_(34);
  #line 34 "src/data/RealValue.birch"
  return birch::RealVectorValue(libbirch::make_array({ this_()->value, birch::Real(x, handler_) }), handler_);
}

#line 37 "src/data/RealValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::RealValue::push(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/data/RealValue.birch"
  libbirch_function_("push", "src/data/RealValue.birch", 37);
  #line 38 "src/data/RealValue.birch"
  libbirch_line_(38);
  #line 38 "src/data/RealValue.birch"
  return birch::RealVectorValue(libbirch::make_array({ this_()->value, birch::Real(x, handler_) }), handler_);
}

#line 41 "src/data/RealValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::RealValue::push(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "src/data/RealValue.birch"
  libbirch_function_("push", "src/data/RealValue.birch", 41);
  #line 42 "src/data/RealValue.birch"
  libbirch_line_(42);
  #line 42 "src/data/RealValue.birch"
  return birch::RealVectorValue(libbirch::make_array({ this_()->value, x }), handler_);
}

#line 45 "src/data/RealValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::RealValue::push(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "src/data/RealValue.birch"
  libbirch_function_("push", "src/data/RealValue.birch", 45);
  #line 46 "src/data/RealValue.birch"
  libbirch_line_(46);
  #line 46 "src/data/RealValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 47 "src/data/RealValue.birch"
  libbirch_line_(47);
  #line 47 "src/data/RealValue.birch"
  o->push(this_()->value, handler_);
  #line 48 "src/data/RealValue.birch"
  libbirch_line_(48);
  #line 48 "src/data/RealValue.birch"
  o->push(x, handler_);
  #line 49 "src/data/RealValue.birch"
  libbirch_line_(49);
  #line 49 "src/data/RealValue.birch"
  return o;
}

#line 52 "src/data/RealValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::RealValue::push(const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "src/data/RealValue.birch"
  libbirch_function_("push", "src/data/RealValue.birch", 52);
  #line 53 "src/data/RealValue.birch"
  libbirch_line_(53);
  #line 53 "src/data/RealValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 54 "src/data/RealValue.birch"
  libbirch_line_(54);
  #line 54 "src/data/RealValue.birch"
  o->push(this_()->value, handler_);
  #line 55 "src/data/RealValue.birch"
  libbirch_line_(55);
  #line 55 "src/data/RealValue.birch"
  o->push(x, handler_);
  #line 56 "src/data/RealValue.birch"
  libbirch_line_(56);
  #line 56 "src/data/RealValue.birch"
  return o;
}

#line 59 "src/data/RealValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::RealValue::push(const libbirch::DefaultArray<birch::type::Boolean,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/data/RealValue.birch"
  libbirch_function_("push", "src/data/RealValue.birch", 59);
  #line 60 "src/data/RealValue.birch"
  libbirch_line_(60);
  #line 60 "src/data/RealValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 61 "src/data/RealValue.birch"
  libbirch_line_(61);
  #line 61 "src/data/RealValue.birch"
  o->push(this_()->value, handler_);
  #line 62 "src/data/RealValue.birch"
  libbirch_line_(62);
  #line 62 "src/data/RealValue.birch"
  o->push(x, handler_);
  #line 63 "src/data/RealValue.birch"
  libbirch_line_(63);
  #line 63 "src/data/RealValue.birch"
  return o;
}

#line 66 "src/data/RealValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::RealValue::push(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "src/data/RealValue.birch"
  libbirch_function_("push", "src/data/RealValue.birch", 66);
  #line 67 "src/data/RealValue.birch"
  libbirch_line_(67);
  #line 67 "src/data/RealValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 68 "src/data/RealValue.birch"
  libbirch_line_(68);
  #line 68 "src/data/RealValue.birch"
  o->push(this_()->value, handler_);
  #line 69 "src/data/RealValue.birch"
  libbirch_line_(69);
  #line 69 "src/data/RealValue.birch"
  o->push(x, handler_);
  #line 70 "src/data/RealValue.birch"
  libbirch_line_(70);
  #line 70 "src/data/RealValue.birch"
  return o;
}

#line 73 "src/data/RealValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::RealValue::push(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 73 "src/data/RealValue.birch"
  libbirch_function_("push", "src/data/RealValue.birch", 73);
  #line 74 "src/data/RealValue.birch"
  libbirch_line_(74);
  #line 74 "src/data/RealValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 75 "src/data/RealValue.birch"
  libbirch_line_(75);
  #line 75 "src/data/RealValue.birch"
  o->push(this_()->value, handler_);
  #line 76 "src/data/RealValue.birch"
  libbirch_line_(76);
  #line 76 "src/data/RealValue.birch"
  o->push(x, handler_);
  #line 77 "src/data/RealValue.birch"
  libbirch_line_(77);
  #line 77 "src/data/RealValue.birch"
  return o;
}

#line 84 "src/data/RealValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::RealValue>> birch::RealValue(const birch::type::Real& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 84 "src/data/RealValue.birch"
  libbirch_function_("RealValue", "src/data/RealValue.birch", 84);
  #line 85 "src/data/RealValue.birch"
  libbirch_line_(85);
  #line 85 "src/data/RealValue.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::RealValue>>>(value, handler_);
}

#line 4 "src/data/RealVectorValue.birch"
birch::type::RealVectorValue::RealVectorValue(const libbirch::DefaultArray<birch::type::Real,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/data/RealVectorValue.birch"
    super_type_(),
    #line 8 "src/data/RealVectorValue.birch"
    value(value) {
  //
}

#line 10 "src/data/RealVectorValue.birch"
void birch::type::RealVectorValue::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Writer>>& writer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/data/RealVectorValue.birch"
  libbirch_function_("accept", "src/data/RealVectorValue.birch", 10);
  #line 11 "src/data/RealVectorValue.birch"
  libbirch_line_(11);
  #line 11 "src/data/RealVectorValue.birch"
  writer->visit(shared_from_this_(), handler_);
}

#line 14 "src/data/RealVectorValue.birch"
birch::type::Integer birch::type::RealVectorValue::size(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/data/RealVectorValue.birch"
  libbirch_function_("size", "src/data/RealVectorValue.birch", 14);
  #line 15 "src/data/RealVectorValue.birch"
  libbirch_line_(15);
  #line 15 "src/data/RealVectorValue.birch"
  return birch::length(this_()->value, handler_);
}

#line 18 "src/data/RealVectorValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::RealVectorValue::getRealVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/data/RealVectorValue.birch"
  libbirch_function_("getRealVector", "src/data/RealVectorValue.birch", 18);
  #line 19 "src/data/RealVectorValue.birch"
  libbirch_line_(19);
  #line 19 "src/data/RealVectorValue.birch"
  return this_()->value;
}

#line 22 "src/data/RealVectorValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::RealVectorValue::getRealMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/data/RealVectorValue.birch"
  libbirch_function_("getRealMatrix", "src/data/RealVectorValue.birch", 22);
  #line 23 "src/data/RealVectorValue.birch"
  libbirch_line_(23);
  #line 23 "src/data/RealVectorValue.birch"
  return birch::column(this_()->value, handler_);
}

#line 26 "src/data/RealVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::RealVectorValue::pushNil(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/data/RealVectorValue.birch"
  libbirch_function_("pushNil", "src/data/RealVectorValue.birch", 26);
  #line 27 "src/data/RealVectorValue.birch"
  libbirch_line_(27);
  #line 27 "src/data/RealVectorValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 28 "src/data/RealVectorValue.birch"
  libbirch_line_(28);
  #line 28 "src/data/RealVectorValue.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(this_()->value, handler_); ++i) {
    #line 29 "src/data/RealVectorValue.birch"
    libbirch_line_(29);
    #line 29 "src/data/RealVectorValue.birch"
    o->push(this_()->value.get(libbirch::make_slice(i - 1)), handler_);
  }
  #line 31 "src/data/RealVectorValue.birch"
  libbirch_line_(31);
  #line 31 "src/data/RealVectorValue.birch"
  o->pushNil(handler_);
  #line 32 "src/data/RealVectorValue.birch"
  libbirch_line_(32);
  #line 32 "src/data/RealVectorValue.birch"
  return o;
}

#line 35 "src/data/RealVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::RealVectorValue::push(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "src/data/RealVectorValue.birch"
  libbirch_function_("push", "src/data/RealVectorValue.birch", 35);
  #line 36 "src/data/RealVectorValue.birch"
  libbirch_line_(36);
  #line 36 "src/data/RealVectorValue.birch"
  return this_()->push(birch::Real(x, handler_), handler_);
}

#line 39 "src/data/RealVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::RealVectorValue::push(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/data/RealVectorValue.birch"
  libbirch_function_("push", "src/data/RealVectorValue.birch", 39);
  #line 40 "src/data/RealVectorValue.birch"
  libbirch_line_(40);
  #line 40 "src/data/RealVectorValue.birch"
  return this_()->push(birch::Real(x, handler_), handler_);
}

#line 43 "src/data/RealVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::RealVectorValue::push(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "src/data/RealVectorValue.birch"
  libbirch_function_("push", "src/data/RealVectorValue.birch", 43);
  #line 44 "src/data/RealVectorValue.birch"

    value.insert(value.size(), x);
      #line 47 "src/data/RealVectorValue.birch"
  libbirch_line_(47);
  #line 47 "src/data/RealVectorValue.birch"
  return shared_from_this_();
}

#line 50 "src/data/RealVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::RealVectorValue::push(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "src/data/RealVectorValue.birch"
  libbirch_function_("push", "src/data/RealVectorValue.birch", 50);
  #line 51 "src/data/RealVectorValue.birch"
  libbirch_line_(51);
  #line 51 "src/data/RealVectorValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 52 "src/data/RealVectorValue.birch"
  libbirch_line_(52);
  #line 52 "src/data/RealVectorValue.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(this_()->value, handler_); ++i) {
    #line 53 "src/data/RealVectorValue.birch"
    libbirch_line_(53);
    #line 53 "src/data/RealVectorValue.birch"
    o->push(this_()->value.get(libbirch::make_slice(i - 1)), handler_);
  }
  #line 55 "src/data/RealVectorValue.birch"
  libbirch_line_(55);
  #line 55 "src/data/RealVectorValue.birch"
  o->push(x, handler_);
  #line 56 "src/data/RealVectorValue.birch"
  libbirch_line_(56);
  #line 56 "src/data/RealVectorValue.birch"
  return o;
}

#line 59 "src/data/RealVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::RealVectorValue::push(const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/data/RealVectorValue.birch"
  libbirch_function_("push", "src/data/RealVectorValue.birch", 59);
  #line 60 "src/data/RealVectorValue.birch"
  libbirch_line_(60);
  #line 60 "src/data/RealVectorValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 61 "src/data/RealVectorValue.birch"
  libbirch_line_(61);
  #line 61 "src/data/RealVectorValue.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(this_()->value, handler_); ++i) {
    #line 62 "src/data/RealVectorValue.birch"
    libbirch_line_(62);
    #line 62 "src/data/RealVectorValue.birch"
    o->push(this_()->value.get(libbirch::make_slice(i - 1)), handler_);
  }
  #line 64 "src/data/RealVectorValue.birch"
  libbirch_line_(64);
  #line 64 "src/data/RealVectorValue.birch"
  o->push(x, handler_);
  #line 65 "src/data/RealVectorValue.birch"
  libbirch_line_(65);
  #line 65 "src/data/RealVectorValue.birch"
  return o;
}

#line 68 "src/data/RealVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::RealVectorValue::push(const libbirch::DefaultArray<birch::type::Boolean,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 68 "src/data/RealVectorValue.birch"
  libbirch_function_("push", "src/data/RealVectorValue.birch", 68);
  #line 69 "src/data/RealVectorValue.birch"
  libbirch_line_(69);
  #line 69 "src/data/RealVectorValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 70 "src/data/RealVectorValue.birch"
  libbirch_line_(70);
  #line 70 "src/data/RealVectorValue.birch"
  o->push(this_()->value, handler_);
  #line 71 "src/data/RealVectorValue.birch"
  libbirch_line_(71);
  #line 71 "src/data/RealVectorValue.birch"
  o->push(x, handler_);
  #line 72 "src/data/RealVectorValue.birch"
  libbirch_line_(72);
  #line 72 "src/data/RealVectorValue.birch"
  return o;
}

#line 75 "src/data/RealVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::RealVectorValue::push(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 75 "src/data/RealVectorValue.birch"
  libbirch_function_("push", "src/data/RealVectorValue.birch", 75);
  #line 76 "src/data/RealVectorValue.birch"
  libbirch_line_(76);
  #line 76 "src/data/RealVectorValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 77 "src/data/RealVectorValue.birch"
  libbirch_line_(77);
  #line 77 "src/data/RealVectorValue.birch"
  o->push(this_()->value, handler_);
  #line 78 "src/data/RealVectorValue.birch"
  libbirch_line_(78);
  #line 78 "src/data/RealVectorValue.birch"
  o->push(x, handler_);
  #line 79 "src/data/RealVectorValue.birch"
  libbirch_line_(79);
  #line 79 "src/data/RealVectorValue.birch"
  return o;
}

#line 82 "src/data/RealVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::RealVectorValue::push(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 82 "src/data/RealVectorValue.birch"
  libbirch_function_("push", "src/data/RealVectorValue.birch", 82);
  #line 83 "src/data/RealVectorValue.birch"
  libbirch_line_(83);
  #line 83 "src/data/RealVectorValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 84 "src/data/RealVectorValue.birch"
  libbirch_line_(84);
  #line 84 "src/data/RealVectorValue.birch"
  o->push(this_()->value, handler_);
  #line 85 "src/data/RealVectorValue.birch"
  libbirch_line_(85);
  #line 85 "src/data/RealVectorValue.birch"
  o->push(x, handler_);
  #line 86 "src/data/RealVectorValue.birch"
  libbirch_line_(86);
  #line 86 "src/data/RealVectorValue.birch"
  return o;
}

#line 93 "src/data/RealVectorValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::RealVectorValue>> birch::RealVectorValue(const libbirch::DefaultArray<birch::type::Real,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 93 "src/data/RealVectorValue.birch"
  libbirch_function_("RealVectorValue", "src/data/RealVectorValue.birch", 93);
  #line 94 "src/data/RealVectorValue.birch"
  libbirch_line_(94);
  #line 94 "src/data/RealVectorValue.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::RealVectorValue>>>(value, handler_);
}

#line 4 "src/data/StringValue.birch"
birch::type::StringValue::StringValue(const birch::type::String& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/data/StringValue.birch"
    super_type_(),
    #line 8 "src/data/StringValue.birch"
    value(value) {
  //
}

#line 10 "src/data/StringValue.birch"
void birch::type::StringValue::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Writer>>& writer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/data/StringValue.birch"
  libbirch_function_("accept", "src/data/StringValue.birch", 10);
  #line 11 "src/data/StringValue.birch"
  libbirch_line_(11);
  #line 11 "src/data/StringValue.birch"
  writer->visit(shared_from_this_(), handler_);
}

#line 14 "src/data/StringValue.birch"
libbirch::Optional<birch::type::String> birch::type::StringValue::getString(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/data/StringValue.birch"
  libbirch_function_("getString", "src/data/StringValue.birch", 14);
  #line 15 "src/data/StringValue.birch"
  libbirch_line_(15);
  #line 15 "src/data/StringValue.birch"
  return this_()->value;
}

#line 18 "src/data/StringValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::StringValue::pushNil(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/data/StringValue.birch"
  libbirch_function_("pushNil", "src/data/StringValue.birch", 18);
  #line 19 "src/data/StringValue.birch"
  libbirch_line_(19);
  #line 19 "src/data/StringValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 20 "src/data/StringValue.birch"
  libbirch_line_(20);
  #line 20 "src/data/StringValue.birch"
  o->push(this_()->value, handler_);
  #line 21 "src/data/StringValue.birch"
  libbirch_line_(21);
  #line 21 "src/data/StringValue.birch"
  o->pushNil(handler_);
  #line 22 "src/data/StringValue.birch"
  libbirch_line_(22);
  #line 22 "src/data/StringValue.birch"
  return o;
}

#line 25 "src/data/StringValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::StringValue::push(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/data/StringValue.birch"
  libbirch_function_("push", "src/data/StringValue.birch", 25);
  #line 26 "src/data/StringValue.birch"
  libbirch_line_(26);
  #line 26 "src/data/StringValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 27 "src/data/StringValue.birch"
  libbirch_line_(27);
  #line 27 "src/data/StringValue.birch"
  o->push(this_()->value, handler_);
  #line 28 "src/data/StringValue.birch"
  libbirch_line_(28);
  #line 28 "src/data/StringValue.birch"
  o->push(x, handler_);
  #line 29 "src/data/StringValue.birch"
  libbirch_line_(29);
  #line 29 "src/data/StringValue.birch"
  return o;
}

#line 32 "src/data/StringValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::StringValue::push(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/data/StringValue.birch"
  libbirch_function_("push", "src/data/StringValue.birch", 32);
  #line 33 "src/data/StringValue.birch"
  libbirch_line_(33);
  #line 33 "src/data/StringValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 34 "src/data/StringValue.birch"
  libbirch_line_(34);
  #line 34 "src/data/StringValue.birch"
  o->push(this_()->value, handler_);
  #line 35 "src/data/StringValue.birch"
  libbirch_line_(35);
  #line 35 "src/data/StringValue.birch"
  o->push(x, handler_);
  #line 36 "src/data/StringValue.birch"
  libbirch_line_(36);
  #line 36 "src/data/StringValue.birch"
  return o;
}

#line 39 "src/data/StringValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::StringValue::push(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/data/StringValue.birch"
  libbirch_function_("push", "src/data/StringValue.birch", 39);
  #line 40 "src/data/StringValue.birch"
  libbirch_line_(40);
  #line 40 "src/data/StringValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 41 "src/data/StringValue.birch"
  libbirch_line_(41);
  #line 41 "src/data/StringValue.birch"
  o->push(this_()->value, handler_);
  #line 42 "src/data/StringValue.birch"
  libbirch_line_(42);
  #line 42 "src/data/StringValue.birch"
  o->push(x, handler_);
  #line 43 "src/data/StringValue.birch"
  libbirch_line_(43);
  #line 43 "src/data/StringValue.birch"
  return o;
}

#line 46 "src/data/StringValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::StringValue::push(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/data/StringValue.birch"
  libbirch_function_("push", "src/data/StringValue.birch", 46);
  #line 47 "src/data/StringValue.birch"
  libbirch_line_(47);
  #line 47 "src/data/StringValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 48 "src/data/StringValue.birch"
  libbirch_line_(48);
  #line 48 "src/data/StringValue.birch"
  o->push(this_()->value, handler_);
  #line 49 "src/data/StringValue.birch"
  libbirch_line_(49);
  #line 49 "src/data/StringValue.birch"
  o->push(x, handler_);
  #line 50 "src/data/StringValue.birch"
  libbirch_line_(50);
  #line 50 "src/data/StringValue.birch"
  return o;
}

#line 53 "src/data/StringValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::StringValue::push(const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "src/data/StringValue.birch"
  libbirch_function_("push", "src/data/StringValue.birch", 53);
  #line 54 "src/data/StringValue.birch"
  libbirch_line_(54);
  #line 54 "src/data/StringValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 55 "src/data/StringValue.birch"
  libbirch_line_(55);
  #line 55 "src/data/StringValue.birch"
  o->push(this_()->value, handler_);
  #line 56 "src/data/StringValue.birch"
  libbirch_line_(56);
  #line 56 "src/data/StringValue.birch"
  o->push(x, handler_);
  #line 57 "src/data/StringValue.birch"
  libbirch_line_(57);
  #line 57 "src/data/StringValue.birch"
  return o;
}

#line 60 "src/data/StringValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::StringValue::push(const libbirch::DefaultArray<birch::type::Boolean,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "src/data/StringValue.birch"
  libbirch_function_("push", "src/data/StringValue.birch", 60);
  #line 61 "src/data/StringValue.birch"
  libbirch_line_(61);
  #line 61 "src/data/StringValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 62 "src/data/StringValue.birch"
  libbirch_line_(62);
  #line 62 "src/data/StringValue.birch"
  o->push(this_()->value, handler_);
  #line 63 "src/data/StringValue.birch"
  libbirch_line_(63);
  #line 63 "src/data/StringValue.birch"
  o->push(x, handler_);
  #line 64 "src/data/StringValue.birch"
  libbirch_line_(64);
  #line 64 "src/data/StringValue.birch"
  return o;
}

#line 67 "src/data/StringValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::StringValue::push(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 67 "src/data/StringValue.birch"
  libbirch_function_("push", "src/data/StringValue.birch", 67);
  #line 68 "src/data/StringValue.birch"
  libbirch_line_(68);
  #line 68 "src/data/StringValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 69 "src/data/StringValue.birch"
  libbirch_line_(69);
  #line 69 "src/data/StringValue.birch"
  o->push(this_()->value, handler_);
  #line 70 "src/data/StringValue.birch"
  libbirch_line_(70);
  #line 70 "src/data/StringValue.birch"
  o->push(x, handler_);
  #line 71 "src/data/StringValue.birch"
  libbirch_line_(71);
  #line 71 "src/data/StringValue.birch"
  return o;
}

#line 74 "src/data/StringValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Value>> birch::type::StringValue::push(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 74 "src/data/StringValue.birch"
  libbirch_function_("push", "src/data/StringValue.birch", 74);
  #line 75 "src/data/StringValue.birch"
  libbirch_line_(75);
  #line 75 "src/data/StringValue.birch"
  auto o = birch::ArrayValue(handler_);
  #line 76 "src/data/StringValue.birch"
  libbirch_line_(76);
  #line 76 "src/data/StringValue.birch"
  o->push(this_()->value, handler_);
  #line 77 "src/data/StringValue.birch"
  libbirch_line_(77);
  #line 77 "src/data/StringValue.birch"
  o->push(x, handler_);
  #line 78 "src/data/StringValue.birch"
  libbirch_line_(78);
  #line 78 "src/data/StringValue.birch"
  return o;
}

#line 85 "src/data/StringValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::StringValue>> birch::StringValue(const birch::type::String& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 85 "src/data/StringValue.birch"
  libbirch_function_("StringValue", "src/data/StringValue.birch", 85);
  #line 86 "src/data/StringValue.birch"
  libbirch_line_(86);
  #line 86 "src/data/StringValue.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::StringValue>>>(value, handler_);
}

#line 4 "src/data/Value.birch"
birch::type::Value::Value(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/data/Value.birch"
    super_type_() {
  //
}

#line 13 "src/data/Value.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>> birch::type::Value::find(const birch::type::String& key, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 13 "src/data/Value.birch"
  libbirch_function_("find", "src/data/Value.birch", 13);
  #line 14 "src/data/Value.birch"
  libbirch_line_(14);
  #line 14 "src/data/Value.birch"
  return libbirch::nil;
}

#line 20 "src/data/Value.birch"
void birch::type::Value::insert(const birch::type::String& key, const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/data/Value.birch"
  libbirch_function_("insert", "src/data/Value.birch", 20);
  #line 21 "src/data/Value.birch"
  libbirch_line_(21);
  #line 21 "src/data/Value.birch"
  birch::error(birch::type::String("not an object"), handler_);
}

#line 27 "src/data/Value.birch"
void birch::type::Value::insert(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/data/Value.birch"
  libbirch_function_("insert", "src/data/Value.birch", 27);
  #line 28 "src/data/Value.birch"
  libbirch_line_(28);
  #line 28 "src/data/Value.birch"
  birch::error(birch::type::String("not an array"), handler_);
}

#line 34 "src/data/Value.birch"
birch::type::Integer birch::type::Value::size(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/data/Value.birch"
  libbirch_function_("size", "src/data/Value.birch", 34);
  #line 35 "src/data/Value.birch"
  libbirch_line_(35);
  #line 35 "src/data/Value.birch"
  return birch::type::Integer(1);
}

#line 41 "src/data/Value.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Iterator<libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>>>> birch::type::Value::walk(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "src/data/Value.birch"
  libbirch_function_("walk", "src/data/Value.birch", 41);
  #line 42 "src/data/Value.birch"
  libbirch_line_(42);
  #line 42 "src/data/Value.birch"
  return birch::EmptyIterator<libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>>(handler_);
}

#line 138 "src/data/Value.birch"
libbirch::Optional<birch::type::Boolean> birch::type::Value::getBoolean(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 138 "src/data/Value.birch"
  libbirch_function_("getBoolean", "src/data/Value.birch", 138);
  #line 139 "src/data/Value.birch"
  libbirch_line_(139);
  #line 139 "src/data/Value.birch"
  return libbirch::nil;
}

#line 147 "src/data/Value.birch"
libbirch::Optional<birch::type::Integer> birch::type::Value::getInteger(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 147 "src/data/Value.birch"
  libbirch_function_("getInteger", "src/data/Value.birch", 147);
  #line 148 "src/data/Value.birch"
  libbirch_line_(148);
  #line 148 "src/data/Value.birch"
  return libbirch::nil;
}

#line 156 "src/data/Value.birch"
libbirch::Optional<birch::type::Real> birch::type::Value::getReal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 156 "src/data/Value.birch"
  libbirch_function_("getReal", "src/data/Value.birch", 156);
  #line 157 "src/data/Value.birch"
  libbirch_line_(157);
  #line 157 "src/data/Value.birch"
  return libbirch::nil;
}

#line 165 "src/data/Value.birch"
libbirch::Optional<birch::type::String> birch::type::Value::getString(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 165 "src/data/Value.birch"
  libbirch_function_("getString", "src/data/Value.birch", 165);
  #line 166 "src/data/Value.birch"
  libbirch_line_(166);
  #line 166 "src/data/Value.birch"
  return libbirch::nil;
}

#line 175 "src/data/Value.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,1>> birch::type::Value::getBooleanVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 175 "src/data/Value.birch"
  libbirch_function_("getBooleanVector", "src/data/Value.birch", 175);
  #line 176 "src/data/Value.birch"
  libbirch_line_(176);
  #line 176 "src/data/Value.birch"
  return libbirch::nil;
}

#line 185 "src/data/Value.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,1>> birch::type::Value::getIntegerVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 185 "src/data/Value.birch"
  libbirch_function_("getIntegerVector", "src/data/Value.birch", 185);
  #line 186 "src/data/Value.birch"
  libbirch_line_(186);
  #line 186 "src/data/Value.birch"
  return libbirch::nil;
}

#line 195 "src/data/Value.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::Value::getRealVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 195 "src/data/Value.birch"
  libbirch_function_("getRealVector", "src/data/Value.birch", 195);
  #line 196 "src/data/Value.birch"
  libbirch_line_(196);
  #line 196 "src/data/Value.birch"
  return libbirch::nil;
}

#line 205 "src/data/Value.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,2>> birch::type::Value::getBooleanMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 205 "src/data/Value.birch"
  libbirch_function_("getBooleanMatrix", "src/data/Value.birch", 205);
  #line 206 "src/data/Value.birch"
  libbirch_line_(206);
  #line 206 "src/data/Value.birch"
  return libbirch::nil;
}

#line 215 "src/data/Value.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,2>> birch::type::Value::getIntegerMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 215 "src/data/Value.birch"
  libbirch_function_("getIntegerMatrix", "src/data/Value.birch", 215);
  #line 216 "src/data/Value.birch"
  libbirch_line_(216);
  #line 216 "src/data/Value.birch"
  return libbirch::nil;
}

#line 225 "src/data/Value.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::Value::getRealMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 225 "src/data/Value.birch"
  libbirch_function_("getRealMatrix", "src/data/Value.birch", 225);
  #line 226 "src/data/Value.birch"
  libbirch_line_(226);
  #line 226 "src/data/Value.birch"
  return libbirch::nil;
}

