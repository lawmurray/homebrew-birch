#line 1 "src/data/ArrayValue.birch"
birch::type::ArrayValue::ArrayValue(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/data/ArrayValue.birch"
    super_type_(),
    #line 9 "src/data/ArrayValue.birch"
    buffers() {
  //
}

#line 11 "src/data/ArrayValue.birch"
void birch::type::ArrayValue::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Writer>>& writer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/data/ArrayValue.birch"
  libbirch_function_("accept", "src/data/ArrayValue.birch", 11);
  #line 12 "src/data/ArrayValue.birch"
  libbirch_line_(12);
  #line 12 "src/data/ArrayValue.birch"
  writer->visit(shared_from_this_(), handler_);
}

#line 15 "src/data/ArrayValue.birch"
birch::type::Boolean birch::type::ArrayValue::isArray(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/data/ArrayValue.birch"
  libbirch_function_("isArray", "src/data/ArrayValue.birch", 15);
  #line 16 "src/data/ArrayValue.birch"
  libbirch_line_(16);
  #line 16 "src/data/ArrayValue.birch"
  return true;
}

#line 19 "src/data/ArrayValue.birch"
birch::type::Integer birch::type::ArrayValue::size(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/data/ArrayValue.birch"
  libbirch_function_("size", "src/data/ArrayValue.birch", 19);
  #line 20 "src/data/ArrayValue.birch"
  libbirch_line_(20);
  #line 20 "src/data/ArrayValue.birch"
  return this_()->buffers->size(handler_);
}

#line 23 "src/data/ArrayValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Iterator<libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>>>> birch::type::ArrayValue::walk(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "src/data/ArrayValue.birch"
  libbirch_function_("walk", "src/data/ArrayValue.birch", 23);
  #line 24 "src/data/ArrayValue.birch"
  libbirch_line_(24);
  #line 24 "src/data/ArrayValue.birch"
  return this_()->buffers->walk(handler_);
}

#line 27 "src/data/ArrayValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> birch::type::ArrayValue::push(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/data/ArrayValue.birch"
  libbirch_function_("push", "src/data/ArrayValue.birch", 27);
  #line 28 "src/data/ArrayValue.birch"
  libbirch_line_(28);
  #line 28 "src/data/ArrayValue.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> buffer;
  #line 29 "src/data/ArrayValue.birch"
  libbirch_line_(29);
  #line 29 "src/data/ArrayValue.birch"
  this_()->buffers->pushBack(buffer, handler_);
  #line 30 "src/data/ArrayValue.birch"
  libbirch_line_(30);
  #line 30 "src/data/ArrayValue.birch"
  return buffer;
}

#line 33 "src/data/ArrayValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,1>> birch::type::ArrayValue::getBooleanVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/data/ArrayValue.birch"
  libbirch_function_("getBooleanVector", "src/data/ArrayValue.birch", 33);
  #line 34 "src/data/ArrayValue.birch"
  libbirch_line_(34);
  #line 34 "src/data/ArrayValue.birch"
  libbirch::DefaultArray<birch::type::Boolean,1> result(libbirch::make_shape(this_()->buffers->size(handler_)));
  #line 35 "src/data/ArrayValue.birch"
  libbirch_line_(35);
  #line 35 "src/data/ArrayValue.birch"
  auto f = this_()->buffers->walk(handler_);
  #line 36 "src/data/ArrayValue.birch"
  libbirch_line_(36);
  #line 36 "src/data/ArrayValue.birch"
  auto i = birch::type::Integer(1);
  #line 37 "src/data/ArrayValue.birch"
  libbirch_line_(37);
  #line 37 "src/data/ArrayValue.birch"
  while (f->hasNext(handler_)) {
    #line 38 "src/data/ArrayValue.birch"
    libbirch_line_(38);
    #line 38 "src/data/ArrayValue.birch"
    auto value = f->next(handler_)->getBoolean(handler_);
    #line 39 "src/data/ArrayValue.birch"
    libbirch_line_(39);
    #line 39 "src/data/ArrayValue.birch"
    if (value.query()) {
      #line 40 "src/data/ArrayValue.birch"
      libbirch_line_(40);
      #line 40 "src/data/ArrayValue.birch"
      result.set(libbirch::make_slice(i - 1), value.get());
      #line 41 "src/data/ArrayValue.birch"
      libbirch_line_(41);
      #line 41 "src/data/ArrayValue.birch"
      i = i + birch::type::Integer(1);
    } else {
      #line 43 "src/data/ArrayValue.birch"
      libbirch_line_(43);
      #line 43 "src/data/ArrayValue.birch"
      return libbirch::nil;
    }
  }
  #line 46 "src/data/ArrayValue.birch"
  libbirch_line_(46);
  #line 46 "src/data/ArrayValue.birch"
  return result;
}

#line 49 "src/data/ArrayValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,1>> birch::type::ArrayValue::getIntegerVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/data/ArrayValue.birch"
  libbirch_function_("getIntegerVector", "src/data/ArrayValue.birch", 49);
  #line 50 "src/data/ArrayValue.birch"
  libbirch_line_(50);
  #line 50 "src/data/ArrayValue.birch"
  libbirch::DefaultArray<birch::type::Integer,1> result(libbirch::make_shape(this_()->buffers->size(handler_)));
  #line 51 "src/data/ArrayValue.birch"
  libbirch_line_(51);
  #line 51 "src/data/ArrayValue.birch"
  auto f = this_()->buffers->walk(handler_);
  #line 52 "src/data/ArrayValue.birch"
  libbirch_line_(52);
  #line 52 "src/data/ArrayValue.birch"
  auto i = birch::type::Integer(1);
  #line 53 "src/data/ArrayValue.birch"
  libbirch_line_(53);
  #line 53 "src/data/ArrayValue.birch"
  while (f->hasNext(handler_)) {
    #line 54 "src/data/ArrayValue.birch"
    libbirch_line_(54);
    #line 54 "src/data/ArrayValue.birch"
    auto value = f->next(handler_)->getInteger(handler_);
    #line 55 "src/data/ArrayValue.birch"
    libbirch_line_(55);
    #line 55 "src/data/ArrayValue.birch"
    if (value.query()) {
      #line 56 "src/data/ArrayValue.birch"
      libbirch_line_(56);
      #line 56 "src/data/ArrayValue.birch"
      result.set(libbirch::make_slice(i - 1), value.get());
      #line 57 "src/data/ArrayValue.birch"
      libbirch_line_(57);
      #line 57 "src/data/ArrayValue.birch"
      i = i + birch::type::Integer(1);
    } else {
      #line 59 "src/data/ArrayValue.birch"
      libbirch_line_(59);
      #line 59 "src/data/ArrayValue.birch"
      return libbirch::nil;
    }
  }
  #line 62 "src/data/ArrayValue.birch"
  libbirch_line_(62);
  #line 62 "src/data/ArrayValue.birch"
  return result;
}

#line 65 "src/data/ArrayValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::ArrayValue::getRealVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "src/data/ArrayValue.birch"
  libbirch_function_("getRealVector", "src/data/ArrayValue.birch", 65);
  #line 66 "src/data/ArrayValue.birch"
  libbirch_line_(66);
  #line 66 "src/data/ArrayValue.birch"
  libbirch::DefaultArray<birch::type::Real,1> result(libbirch::make_shape(this_()->buffers->size(handler_)));
  #line 67 "src/data/ArrayValue.birch"
  libbirch_line_(67);
  #line 67 "src/data/ArrayValue.birch"
  auto f = this_()->buffers->walk(handler_);
  #line 68 "src/data/ArrayValue.birch"
  libbirch_line_(68);
  #line 68 "src/data/ArrayValue.birch"
  auto i = birch::type::Integer(1);
  #line 69 "src/data/ArrayValue.birch"
  libbirch_line_(69);
  #line 69 "src/data/ArrayValue.birch"
  while (f->hasNext(handler_)) {
    #line 70 "src/data/ArrayValue.birch"
    libbirch_line_(70);
    #line 70 "src/data/ArrayValue.birch"
    auto buffer = f->next(handler_);
    #line 71 "src/data/ArrayValue.birch"
    libbirch_line_(71);
    #line 71 "src/data/ArrayValue.birch"
    auto value = buffer->getReal(handler_);
    #line 72 "src/data/ArrayValue.birch"
    libbirch_line_(72);
    #line 72 "src/data/ArrayValue.birch"
    if (!value.query()) {
      #line 73 "src/data/ArrayValue.birch"
      libbirch_line_(73);
      #line 73 "src/data/ArrayValue.birch"
      value = libbirch::cast<birch::type::Real>(buffer->getInteger(handler_));
    }
    #line 75 "src/data/ArrayValue.birch"
    libbirch_line_(75);
    #line 75 "src/data/ArrayValue.birch"
    if (value.query()) {
      #line 76 "src/data/ArrayValue.birch"
      libbirch_line_(76);
      #line 76 "src/data/ArrayValue.birch"
      result.set(libbirch::make_slice(i - 1), value.get());
      #line 77 "src/data/ArrayValue.birch"
      libbirch_line_(77);
      #line 77 "src/data/ArrayValue.birch"
      i = i + birch::type::Integer(1);
    } else {
      #line 79 "src/data/ArrayValue.birch"
      libbirch_line_(79);
      #line 79 "src/data/ArrayValue.birch"
      return libbirch::nil;
    }
  }
  #line 82 "src/data/ArrayValue.birch"
  libbirch_line_(82);
  #line 82 "src/data/ArrayValue.birch"
  return result;
}

#line 85 "src/data/ArrayValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,2>> birch::type::ArrayValue::getBooleanMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 85 "src/data/ArrayValue.birch"
  libbirch_function_("getBooleanMatrix", "src/data/ArrayValue.birch", 85);
  #line 86 "src/data/ArrayValue.birch"
  libbirch_line_(86);
  #line 86 "src/data/ArrayValue.birch"
  auto nrows = this_()->size(handler_);
  #line 87 "src/data/ArrayValue.birch"
  libbirch_line_(87);
  #line 87 "src/data/ArrayValue.birch"
  auto rows = this_()->walk(handler_);
  #line 88 "src/data/ArrayValue.birch"
  libbirch_line_(88);
  #line 88 "src/data/ArrayValue.birch"
  if (rows->hasNext(handler_)) {
    #line 90 "src/data/ArrayValue.birch"
    libbirch_line_(90);
    #line 90 "src/data/ArrayValue.birch"
    auto row = rows->next(handler_);
    #line 91 "src/data/ArrayValue.birch"
    libbirch_line_(91);
    #line 91 "src/data/ArrayValue.birch"
    auto ncols = row->size(handler_);
    #line 92 "src/data/ArrayValue.birch"
    libbirch_line_(92);
    #line 92 "src/data/ArrayValue.birch"
    auto X = birch::matrix(false, nrows, ncols, handler_);
    #line 93 "src/data/ArrayValue.birch"
    libbirch_line_(93);
    #line 93 "src/data/ArrayValue.birch"
    auto x = row->getBooleanVector(handler_);
    #line 94 "src/data/ArrayValue.birch"
    libbirch_line_(94);
    #line 94 "src/data/ArrayValue.birch"
    if (x.query()) {
      #line 95 "src/data/ArrayValue.birch"
      libbirch_line_(95);
      #line 95 "src/data/ArrayValue.birch"
      X.set(libbirch::make_slice(birch::type::Integer(1) - 1, libbirch::make_range(birch::type::Integer(1) - 1, ncols - 1)), x.get());
    } else {
      #line 97 "src/data/ArrayValue.birch"
      libbirch_line_(97);
      #line 97 "src/data/ArrayValue.birch"
      return libbirch::nil;
    }
    #line 102 "src/data/ArrayValue.birch"
    libbirch_line_(102);
    #line 102 "src/data/ArrayValue.birch"
    auto i = birch::type::Integer(1);
    #line 103 "src/data/ArrayValue.birch"
    libbirch_line_(103);
    #line 103 "src/data/ArrayValue.birch"
    while (rows->hasNext(handler_)) {
      #line 104 "src/data/ArrayValue.birch"
      libbirch_line_(104);
      #line 104 "src/data/ArrayValue.birch"
      row = rows->next(handler_);
      #line 105 "src/data/ArrayValue.birch"
      libbirch_line_(105);
      #line 105 "src/data/ArrayValue.birch"
      ncols = row->size(handler_);
      #line 106 "src/data/ArrayValue.birch"
      libbirch_line_(106);
      #line 106 "src/data/ArrayValue.birch"
      if (ncols == birch::columns(X, handler_)) {
        #line 107 "src/data/ArrayValue.birch"
        libbirch_line_(107);
        #line 107 "src/data/ArrayValue.birch"
        x = row->getBooleanVector(handler_);
        #line 108 "src/data/ArrayValue.birch"
        libbirch_line_(108);
        #line 108 "src/data/ArrayValue.birch"
        if (x.query()) {
          #line 109 "src/data/ArrayValue.birch"
          libbirch_line_(109);
          #line 109 "src/data/ArrayValue.birch"
          i = i + birch::type::Integer(1);
          #line 110 "src/data/ArrayValue.birch"
          libbirch_line_(110);
          #line 110 "src/data/ArrayValue.birch"
          X.set(libbirch::make_slice(i - 1, libbirch::make_range(birch::type::Integer(1) - 1, ncols - 1)), x.get());
        } else {
          #line 112 "src/data/ArrayValue.birch"
          libbirch_line_(112);
          #line 112 "src/data/ArrayValue.birch"
          return libbirch::nil;
        }
      } else {
        #line 115 "src/data/ArrayValue.birch"
        libbirch_line_(115);
        #line 115 "src/data/ArrayValue.birch"
        return libbirch::nil;
      }
    }
    #line 118 "src/data/ArrayValue.birch"
    libbirch_line_(118);
    #line 118 "src/data/ArrayValue.birch"
    libbirch_assert_(i == nrows);
    #line 119 "src/data/ArrayValue.birch"
    libbirch_line_(119);
    #line 119 "src/data/ArrayValue.birch"
    return X;
  }
  #line 121 "src/data/ArrayValue.birch"
  libbirch_line_(121);
  #line 121 "src/data/ArrayValue.birch"
  return libbirch::nil;
}

#line 124 "src/data/ArrayValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,2>> birch::type::ArrayValue::getIntegerMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 124 "src/data/ArrayValue.birch"
  libbirch_function_("getIntegerMatrix", "src/data/ArrayValue.birch", 124);
  #line 125 "src/data/ArrayValue.birch"
  libbirch_line_(125);
  #line 125 "src/data/ArrayValue.birch"
  auto nrows = this_()->size(handler_);
  #line 126 "src/data/ArrayValue.birch"
  libbirch_line_(126);
  #line 126 "src/data/ArrayValue.birch"
  auto rows = this_()->walk(handler_);
  #line 127 "src/data/ArrayValue.birch"
  libbirch_line_(127);
  #line 127 "src/data/ArrayValue.birch"
  if (rows->hasNext(handler_)) {
    #line 129 "src/data/ArrayValue.birch"
    libbirch_line_(129);
    #line 129 "src/data/ArrayValue.birch"
    auto row = rows->next(handler_);
    #line 130 "src/data/ArrayValue.birch"
    libbirch_line_(130);
    #line 130 "src/data/ArrayValue.birch"
    auto ncols = row->size(handler_);
    #line 131 "src/data/ArrayValue.birch"
    libbirch_line_(131);
    #line 131 "src/data/ArrayValue.birch"
    auto X = birch::matrix(birch::type::Integer(0), nrows, ncols, handler_);
    #line 132 "src/data/ArrayValue.birch"
    libbirch_line_(132);
    #line 132 "src/data/ArrayValue.birch"
    auto x = row->getIntegerVector(handler_);
    #line 133 "src/data/ArrayValue.birch"
    libbirch_line_(133);
    #line 133 "src/data/ArrayValue.birch"
    if (x.query()) {
      #line 134 "src/data/ArrayValue.birch"
      libbirch_line_(134);
      #line 134 "src/data/ArrayValue.birch"
      X.set(libbirch::make_slice(birch::type::Integer(1) - 1, libbirch::make_range(birch::type::Integer(1) - 1, ncols - 1)), x.get());
    } else {
      #line 136 "src/data/ArrayValue.birch"
      libbirch_line_(136);
      #line 136 "src/data/ArrayValue.birch"
      return libbirch::nil;
    }
    #line 141 "src/data/ArrayValue.birch"
    libbirch_line_(141);
    #line 141 "src/data/ArrayValue.birch"
    auto i = birch::type::Integer(1);
    #line 142 "src/data/ArrayValue.birch"
    libbirch_line_(142);
    #line 142 "src/data/ArrayValue.birch"
    while (rows->hasNext(handler_)) {
      #line 143 "src/data/ArrayValue.birch"
      libbirch_line_(143);
      #line 143 "src/data/ArrayValue.birch"
      row = rows->next(handler_);
      #line 144 "src/data/ArrayValue.birch"
      libbirch_line_(144);
      #line 144 "src/data/ArrayValue.birch"
      ncols = row->size(handler_);
      #line 145 "src/data/ArrayValue.birch"
      libbirch_line_(145);
      #line 145 "src/data/ArrayValue.birch"
      if (ncols == birch::columns(X, handler_)) {
        #line 146 "src/data/ArrayValue.birch"
        libbirch_line_(146);
        #line 146 "src/data/ArrayValue.birch"
        x = row->getIntegerVector(handler_);
        #line 147 "src/data/ArrayValue.birch"
        libbirch_line_(147);
        #line 147 "src/data/ArrayValue.birch"
        if (x.query()) {
          #line 148 "src/data/ArrayValue.birch"
          libbirch_line_(148);
          #line 148 "src/data/ArrayValue.birch"
          i = i + birch::type::Integer(1);
          #line 149 "src/data/ArrayValue.birch"
          libbirch_line_(149);
          #line 149 "src/data/ArrayValue.birch"
          X.set(libbirch::make_slice(i - 1, libbirch::make_range(birch::type::Integer(1) - 1, ncols - 1)), x.get());
        } else {
          #line 151 "src/data/ArrayValue.birch"
          libbirch_line_(151);
          #line 151 "src/data/ArrayValue.birch"
          return libbirch::nil;
        }
      } else {
        #line 154 "src/data/ArrayValue.birch"
        libbirch_line_(154);
        #line 154 "src/data/ArrayValue.birch"
        return libbirch::nil;
      }
    }
    #line 157 "src/data/ArrayValue.birch"
    libbirch_line_(157);
    #line 157 "src/data/ArrayValue.birch"
    libbirch_assert_(i == nrows);
    #line 158 "src/data/ArrayValue.birch"
    libbirch_line_(158);
    #line 158 "src/data/ArrayValue.birch"
    return X;
  }
  #line 160 "src/data/ArrayValue.birch"
  libbirch_line_(160);
  #line 160 "src/data/ArrayValue.birch"
  return libbirch::nil;
}

#line 163 "src/data/ArrayValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::ArrayValue::getRealMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 163 "src/data/ArrayValue.birch"
  libbirch_function_("getRealMatrix", "src/data/ArrayValue.birch", 163);
  #line 164 "src/data/ArrayValue.birch"
  libbirch_line_(164);
  #line 164 "src/data/ArrayValue.birch"
  auto nrows = this_()->size(handler_);
  #line 165 "src/data/ArrayValue.birch"
  libbirch_line_(165);
  #line 165 "src/data/ArrayValue.birch"
  auto rows = this_()->walk(handler_);
  #line 166 "src/data/ArrayValue.birch"
  libbirch_line_(166);
  #line 166 "src/data/ArrayValue.birch"
  if (rows->hasNext(handler_)) {
    #line 168 "src/data/ArrayValue.birch"
    libbirch_line_(168);
    #line 168 "src/data/ArrayValue.birch"
    auto row = rows->next(handler_);
    #line 169 "src/data/ArrayValue.birch"
    libbirch_line_(169);
    #line 169 "src/data/ArrayValue.birch"
    auto ncols = row->size(handler_);
    #line 170 "src/data/ArrayValue.birch"
    libbirch_line_(170);
    #line 170 "src/data/ArrayValue.birch"
    auto X = birch::matrix(0.0, nrows, ncols, handler_);
    #line 171 "src/data/ArrayValue.birch"
    libbirch_line_(171);
    #line 171 "src/data/ArrayValue.birch"
    auto x = row->getRealVector(handler_);
    #line 172 "src/data/ArrayValue.birch"
    libbirch_line_(172);
    #line 172 "src/data/ArrayValue.birch"
    if (x.query()) {
      #line 173 "src/data/ArrayValue.birch"
      libbirch_line_(173);
      #line 173 "src/data/ArrayValue.birch"
      X.set(libbirch::make_slice(birch::type::Integer(1) - 1, libbirch::make_range(birch::type::Integer(1) - 1, ncols - 1)), x.get());
    } else {
      #line 175 "src/data/ArrayValue.birch"
      libbirch_line_(175);
      #line 175 "src/data/ArrayValue.birch"
      return libbirch::nil;
    }
    #line 180 "src/data/ArrayValue.birch"
    libbirch_line_(180);
    #line 180 "src/data/ArrayValue.birch"
    auto i = birch::type::Integer(1);
    #line 181 "src/data/ArrayValue.birch"
    libbirch_line_(181);
    #line 181 "src/data/ArrayValue.birch"
    while (rows->hasNext(handler_)) {
      #line 182 "src/data/ArrayValue.birch"
      libbirch_line_(182);
      #line 182 "src/data/ArrayValue.birch"
      row = rows->next(handler_);
      #line 183 "src/data/ArrayValue.birch"
      libbirch_line_(183);
      #line 183 "src/data/ArrayValue.birch"
      ncols = row->size(handler_);
      #line 184 "src/data/ArrayValue.birch"
      libbirch_line_(184);
      #line 184 "src/data/ArrayValue.birch"
      if (ncols == birch::columns(X, handler_)) {
        #line 185 "src/data/ArrayValue.birch"
        libbirch_line_(185);
        #line 185 "src/data/ArrayValue.birch"
        x = row->getRealVector(handler_);
        #line 186 "src/data/ArrayValue.birch"
        libbirch_line_(186);
        #line 186 "src/data/ArrayValue.birch"
        if (x.query()) {
          #line 187 "src/data/ArrayValue.birch"
          libbirch_line_(187);
          #line 187 "src/data/ArrayValue.birch"
          i = i + birch::type::Integer(1);
          #line 188 "src/data/ArrayValue.birch"
          libbirch_line_(188);
          #line 188 "src/data/ArrayValue.birch"
          X.set(libbirch::make_slice(i - 1, libbirch::make_range(birch::type::Integer(1) - 1, ncols - 1)), x.get());
        } else {
          #line 190 "src/data/ArrayValue.birch"
          libbirch_line_(190);
          #line 190 "src/data/ArrayValue.birch"
          return libbirch::nil;
        }
      } else {
        #line 193 "src/data/ArrayValue.birch"
        libbirch_line_(193);
        #line 193 "src/data/ArrayValue.birch"
        return libbirch::nil;
      }
    }
    #line 196 "src/data/ArrayValue.birch"
    libbirch_line_(196);
    #line 196 "src/data/ArrayValue.birch"
    libbirch_assert_(i == nrows);
    #line 197 "src/data/ArrayValue.birch"
    libbirch_line_(197);
    #line 197 "src/data/ArrayValue.birch"
    return X;
  }
  #line 199 "src/data/ArrayValue.birch"
  libbirch_line_(199);
  #line 199 "src/data/ArrayValue.birch"
  return libbirch::nil;
}

#line 1 "src/data/ArrayValue.birch"
birch::type::ArrayValue* birch::type::make_ArrayValue_() {
  #line 1 "src/data/ArrayValue.birch"
  return new birch::type::ArrayValue();
  #line 1 "src/data/ArrayValue.birch"
}

#line 1 "src/data/BooleanValue.birch"
birch::type::BooleanValue::BooleanValue(const birch::type::Boolean& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/data/BooleanValue.birch"
    super_type_(),
    #line 8 "src/data/BooleanValue.birch"
    value(value) {
  //
}

#line 10 "src/data/BooleanValue.birch"
void birch::type::BooleanValue::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Writer>>& writer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/data/BooleanValue.birch"
  libbirch_function_("accept", "src/data/BooleanValue.birch", 10);
  #line 11 "src/data/BooleanValue.birch"
  libbirch_line_(11);
  #line 11 "src/data/BooleanValue.birch"
  writer->visit(shared_from_this_(), handler_);
}

#line 14 "src/data/BooleanValue.birch"
birch::type::Boolean birch::type::BooleanValue::isScalar(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/data/BooleanValue.birch"
  libbirch_function_("isScalar", "src/data/BooleanValue.birch", 14);
  #line 15 "src/data/BooleanValue.birch"
  libbirch_line_(15);
  #line 15 "src/data/BooleanValue.birch"
  return true;
}

#line 18 "src/data/BooleanValue.birch"
libbirch::Optional<birch::type::Boolean> birch::type::BooleanValue::getBoolean(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/data/BooleanValue.birch"
  libbirch_function_("getBoolean", "src/data/BooleanValue.birch", 18);
  #line 19 "src/data/BooleanValue.birch"
  libbirch_line_(19);
  #line 19 "src/data/BooleanValue.birch"
  return this_()->value;
}

#line 22 "src/data/BooleanValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,1>> birch::type::BooleanValue::getBooleanVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/data/BooleanValue.birch"
  libbirch_function_("getBooleanVector", "src/data/BooleanValue.birch", 22);
  #line 23 "src/data/BooleanValue.birch"
  libbirch_line_(23);
  #line 23 "src/data/BooleanValue.birch"
  return birch::vector(this_()->value, birch::type::Integer(1), handler_);
}

#line 26 "src/data/BooleanValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,2>> birch::type::BooleanValue::getBooleanMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/data/BooleanValue.birch"
  libbirch_function_("getBooleanMatrix", "src/data/BooleanValue.birch", 26);
  #line 27 "src/data/BooleanValue.birch"
  libbirch_line_(27);
  #line 27 "src/data/BooleanValue.birch"
  return birch::matrix(this_()->value, birch::type::Integer(1), birch::type::Integer(1), handler_);
}

#line 1 "src/data/BooleanMatrixValue.birch"
birch::type::BooleanMatrixValue::BooleanMatrixValue(const libbirch::DefaultArray<birch::type::Boolean,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/data/BooleanMatrixValue.birch"
    super_type_(),
    #line 8 "src/data/BooleanMatrixValue.birch"
    value(value) {
  //
}

#line 10 "src/data/BooleanMatrixValue.birch"
void birch::type::BooleanMatrixValue::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Writer>>& writer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/data/BooleanMatrixValue.birch"
  libbirch_function_("accept", "src/data/BooleanMatrixValue.birch", 10);
  #line 11 "src/data/BooleanMatrixValue.birch"
  libbirch_line_(11);
  #line 11 "src/data/BooleanMatrixValue.birch"
  writer->visit(shared_from_this_(), handler_);
}

#line 14 "src/data/BooleanMatrixValue.birch"
birch::type::Boolean birch::type::BooleanMatrixValue::isArray(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/data/BooleanMatrixValue.birch"
  libbirch_function_("isArray", "src/data/BooleanMatrixValue.birch", 14);
  #line 15 "src/data/BooleanMatrixValue.birch"
  libbirch_line_(15);
  #line 15 "src/data/BooleanMatrixValue.birch"
  return true;
}

#line 18 "src/data/BooleanMatrixValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,2>> birch::type::BooleanMatrixValue::getBooleanMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/data/BooleanMatrixValue.birch"
  libbirch_function_("getBooleanMatrix", "src/data/BooleanMatrixValue.birch", 18);
  #line 19 "src/data/BooleanMatrixValue.birch"
  libbirch_line_(19);
  #line 19 "src/data/BooleanMatrixValue.birch"
  return this_()->value;
}

#line 1 "src/data/BooleanVectorValue.birch"
birch::type::BooleanVectorValue::BooleanVectorValue(const libbirch::DefaultArray<birch::type::Boolean,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/data/BooleanVectorValue.birch"
    super_type_(),
    #line 8 "src/data/BooleanVectorValue.birch"
    value(value) {
  //
}

#line 10 "src/data/BooleanVectorValue.birch"
void birch::type::BooleanVectorValue::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Writer>>& writer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/data/BooleanVectorValue.birch"
  libbirch_function_("accept", "src/data/BooleanVectorValue.birch", 10);
  #line 11 "src/data/BooleanVectorValue.birch"
  libbirch_line_(11);
  #line 11 "src/data/BooleanVectorValue.birch"
  writer->visit(shared_from_this_(), handler_);
}

#line 14 "src/data/BooleanVectorValue.birch"
birch::type::Boolean birch::type::BooleanVectorValue::isArray(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/data/BooleanVectorValue.birch"
  libbirch_function_("isArray", "src/data/BooleanVectorValue.birch", 14);
  #line 15 "src/data/BooleanVectorValue.birch"
  libbirch_line_(15);
  #line 15 "src/data/BooleanVectorValue.birch"
  return true;
}

#line 18 "src/data/BooleanVectorValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,1>> birch::type::BooleanVectorValue::getBooleanVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/data/BooleanVectorValue.birch"
  libbirch_function_("getBooleanVector", "src/data/BooleanVectorValue.birch", 18);
  #line 19 "src/data/BooleanVectorValue.birch"
  libbirch_line_(19);
  #line 19 "src/data/BooleanVectorValue.birch"
  return this_()->value;
}

#line 22 "src/data/BooleanVectorValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,2>> birch::type::BooleanVectorValue::getBooleanMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/data/BooleanVectorValue.birch"
  libbirch_function_("getBooleanMatrix", "src/data/BooleanVectorValue.birch", 22);
  #line 23 "src/data/BooleanVectorValue.birch"
  libbirch_line_(23);
  #line 23 "src/data/BooleanVectorValue.birch"
  return birch::column(this_()->value, handler_);
}

#line 4 "src/data/Buffer.birch"
birch::type::Buffer::Buffer(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/data/Buffer.birch"
    super_type_(),
    #line 8 "src/data/Buffer.birch"
    value(birch::ObjectValue(handler_)) {
  //
}

#line 13 "src/data/Buffer.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>> birch::type::Buffer::getChild(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 13 "src/data/Buffer.birch"
  libbirch_function_("getChild", "src/data/Buffer.birch", 13);
  #line 14 "src/data/Buffer.birch"
  libbirch_line_(14);
  #line 14 "src/data/Buffer.birch"
  return this_()->value->getChild(name, handler_);
}

#line 20 "src/data/Buffer.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> birch::type::Buffer::setChild(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/data/Buffer.birch"
  libbirch_function_("setChild", "src/data/Buffer.birch", 20);
  #line 21 "src/data/Buffer.birch"
  libbirch_line_(21);
  #line 21 "src/data/Buffer.birch"
  return this_()->value->setChild(name, handler_);
}

#line 27 "src/data/Buffer.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> birch::type::Buffer::push(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/data/Buffer.birch"
  libbirch_function_("push", "src/data/Buffer.birch", 27);
  #line 28 "src/data/Buffer.birch"
  libbirch_line_(28);
  #line 28 "src/data/Buffer.birch"
  return this_()->value->push(handler_);
}

#line 34 "src/data/Buffer.birch"
birch::type::Integer birch::type::Buffer::size(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/data/Buffer.birch"
  libbirch_function_("size", "src/data/Buffer.birch", 34);
  #line 35 "src/data/Buffer.birch"
  libbirch_line_(35);
  #line 35 "src/data/Buffer.birch"
  return this_()->value->size(handler_);
}

#line 41 "src/data/Buffer.birch"
void birch::type::Buffer::clear(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "src/data/Buffer.birch"
  libbirch_function_("clear", "src/data/Buffer.birch", 41);
  #line 42 "src/data/Buffer.birch"
  libbirch_line_(42);
  #line 42 "src/data/Buffer.birch"
  this_()->value = birch::ObjectValue(handler_);
}

#line 48 "src/data/Buffer.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Iterator<libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>>>> birch::type::Buffer::walk(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "src/data/Buffer.birch"
  libbirch_function_("walk", "src/data/Buffer.birch", 48);
  #line 49 "src/data/Buffer.birch"
  libbirch_line_(49);
  #line 49 "src/data/Buffer.birch"
  return this_()->value->walk(handler_);
}

#line 57 "src/data/Buffer.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Iterator<libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>>>> birch::type::Buffer::walk(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 57 "src/data/Buffer.birch"
  libbirch_function_("walk", "src/data/Buffer.birch", 57);
  #line 58 "src/data/Buffer.birch"
  libbirch_line_(58);
  #line 58 "src/data/Buffer.birch"
  return this_()->getArray(name, handler_).get()->walk(handler_);
}

#line 66 "src/data/Buffer.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>> birch::type::Buffer::getObject(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "src/data/Buffer.birch"
  libbirch_function_("getObject", "src/data/Buffer.birch", 66);
  #line 67 "src/data/Buffer.birch"
  libbirch_line_(67);
  #line 67 "src/data/Buffer.birch"
  return shared_from_this_();
}

#line 73 "src/data/Buffer.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>> birch::type::Buffer::getArray(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 73 "src/data/Buffer.birch"
  libbirch_function_("getArray", "src/data/Buffer.birch", 73);
  #line 74 "src/data/Buffer.birch"
  libbirch_line_(74);
  #line 74 "src/data/Buffer.birch"
  if (this_()->value->isArray(handler_)) {
    #line 75 "src/data/Buffer.birch"
    libbirch_line_(75);
    #line 75 "src/data/Buffer.birch"
    return shared_from_this_();
  } else {
    #line 77 "src/data/Buffer.birch"
    libbirch_line_(77);
    #line 77 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 86 "src/data/Buffer.birch"
libbirch::Optional<birch::type::Boolean> birch::type::Buffer::getBoolean(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 86 "src/data/Buffer.birch"
  libbirch_function_("getBoolean", "src/data/Buffer.birch", 86);
  #line 87 "src/data/Buffer.birch"
  libbirch_line_(87);
  #line 87 "src/data/Buffer.birch"
  return this_()->value->getBoolean(handler_);
}

#line 95 "src/data/Buffer.birch"
libbirch::Optional<birch::type::Integer> birch::type::Buffer::getInteger(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "src/data/Buffer.birch"
  libbirch_function_("getInteger", "src/data/Buffer.birch", 95);
  #line 96 "src/data/Buffer.birch"
  libbirch_line_(96);
  #line 96 "src/data/Buffer.birch"
  return this_()->value->getInteger(handler_);
}

#line 104 "src/data/Buffer.birch"
libbirch::Optional<birch::type::Real> birch::type::Buffer::getReal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 104 "src/data/Buffer.birch"
  libbirch_function_("getReal", "src/data/Buffer.birch", 104);
  #line 105 "src/data/Buffer.birch"
  libbirch_line_(105);
  #line 105 "src/data/Buffer.birch"
  return this_()->value->getReal(handler_);
}

#line 113 "src/data/Buffer.birch"
libbirch::Optional<birch::type::String> birch::type::Buffer::getString(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 113 "src/data/Buffer.birch"
  libbirch_function_("getString", "src/data/Buffer.birch", 113);
  #line 114 "src/data/Buffer.birch"
  libbirch_line_(114);
  #line 114 "src/data/Buffer.birch"
  return this_()->value->getString(handler_);
}

#line 123 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,1>> birch::type::Buffer::getBooleanVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 123 "src/data/Buffer.birch"
  libbirch_function_("getBooleanVector", "src/data/Buffer.birch", 123);
  #line 124 "src/data/Buffer.birch"
  libbirch_line_(124);
  #line 124 "src/data/Buffer.birch"
  return this_()->value->getBooleanVector(handler_);
}

#line 133 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,1>> birch::type::Buffer::getIntegerVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 133 "src/data/Buffer.birch"
  libbirch_function_("getIntegerVector", "src/data/Buffer.birch", 133);
  #line 134 "src/data/Buffer.birch"
  libbirch_line_(134);
  #line 134 "src/data/Buffer.birch"
  return this_()->value->getIntegerVector(handler_);
}

#line 143 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::Buffer::getRealVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 143 "src/data/Buffer.birch"
  libbirch_function_("getRealVector", "src/data/Buffer.birch", 143);
  #line 144 "src/data/Buffer.birch"
  libbirch_line_(144);
  #line 144 "src/data/Buffer.birch"
  return this_()->value->getRealVector(handler_);
}

#line 153 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,2>> birch::type::Buffer::getBooleanMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 153 "src/data/Buffer.birch"
  libbirch_function_("getBooleanMatrix", "src/data/Buffer.birch", 153);
  #line 154 "src/data/Buffer.birch"
  libbirch_line_(154);
  #line 154 "src/data/Buffer.birch"
  return this_()->value->getBooleanMatrix(handler_);
}

#line 163 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,2>> birch::type::Buffer::getIntegerMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 163 "src/data/Buffer.birch"
  libbirch_function_("getIntegerMatrix", "src/data/Buffer.birch", 163);
  #line 164 "src/data/Buffer.birch"
  libbirch_line_(164);
  #line 164 "src/data/Buffer.birch"
  return this_()->value->getIntegerMatrix(handler_);
}

#line 173 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::Buffer::getRealMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 173 "src/data/Buffer.birch"
  libbirch_function_("getRealMatrix", "src/data/Buffer.birch", 173);
  #line 174 "src/data/Buffer.birch"
  libbirch_line_(174);
  #line 174 "src/data/Buffer.birch"
  return this_()->value->getRealMatrix(handler_);
}

#line 183 "src/data/Buffer.birch"
libbirch::Optional<birch::type::LLT> birch::type::Buffer::getLLT(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 183 "src/data/Buffer.birch"
  libbirch_function_("getLLT", "src/data/Buffer.birch", 183);
  #line 184 "src/data/Buffer.birch"
  libbirch_line_(184);
  #line 184 "src/data/Buffer.birch"
  auto x = this_()->getRealMatrix(handler_);
  #line 185 "src/data/Buffer.birch"
  libbirch_line_(185);
  #line 185 "src/data/Buffer.birch"
  if (x.query()) {
    #line 186 "src/data/Buffer.birch"
    libbirch_line_(186);
    #line 186 "src/data/Buffer.birch"
    return birch::llt(x.get(), handler_);
  } else {
    #line 188 "src/data/Buffer.birch"
    libbirch_line_(188);
    #line 188 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 195 "src/data/Buffer.birch"
birch::type::Integer birch::type::Buffer::size(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 195 "src/data/Buffer.birch"
  libbirch_function_("size", "src/data/Buffer.birch", 195);
  #line 196 "src/data/Buffer.birch"
  libbirch_line_(196);
  #line 196 "src/data/Buffer.birch"
  auto array = this_()->getArray(name, handler_);
  #line 197 "src/data/Buffer.birch"
  libbirch_line_(197);
  #line 197 "src/data/Buffer.birch"
  if (array.query()) {
    #line 198 "src/data/Buffer.birch"
    libbirch_line_(198);
    #line 198 "src/data/Buffer.birch"
    return array.get()->size(handler_);
  } else {
    #line 200 "src/data/Buffer.birch"
    libbirch_line_(200);
    #line 200 "src/data/Buffer.birch"
    return birch::type::Integer(0);
  }
}

#line 212 "src/data/Buffer.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>> birch::type::Buffer::getObject(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 212 "src/data/Buffer.birch"
  libbirch_function_("getObject", "src/data/Buffer.birch", 212);
  #line 213 "src/data/Buffer.birch"
  libbirch_line_(213);
  #line 213 "src/data/Buffer.birch"
  auto buffer = this_()->getChild(name, handler_);
  #line 214 "src/data/Buffer.birch"
  libbirch_line_(214);
  #line 214 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 215 "src/data/Buffer.birch"
    libbirch_line_(215);
    #line 215 "src/data/Buffer.birch"
    return buffer.get()->getObject(handler_);
  } else {
    #line 217 "src/data/Buffer.birch"
    libbirch_line_(217);
    #line 217 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 229 "src/data/Buffer.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>> birch::type::Buffer::getArray(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 229 "src/data/Buffer.birch"
  libbirch_function_("getArray", "src/data/Buffer.birch", 229);
  #line 230 "src/data/Buffer.birch"
  libbirch_line_(230);
  #line 230 "src/data/Buffer.birch"
  auto buffer = this_()->getChild(name, handler_);
  #line 231 "src/data/Buffer.birch"
  libbirch_line_(231);
  #line 231 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 232 "src/data/Buffer.birch"
    libbirch_line_(232);
    #line 232 "src/data/Buffer.birch"
    return buffer.get()->getArray(handler_);
  } else {
    #line 234 "src/data/Buffer.birch"
    libbirch_line_(234);
    #line 234 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 246 "src/data/Buffer.birch"
libbirch::Optional<birch::type::Boolean> birch::type::Buffer::getBoolean(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 246 "src/data/Buffer.birch"
  libbirch_function_("getBoolean", "src/data/Buffer.birch", 246);
  #line 247 "src/data/Buffer.birch"
  libbirch_line_(247);
  #line 247 "src/data/Buffer.birch"
  auto buffer = this_()->getChild(name, handler_);
  #line 248 "src/data/Buffer.birch"
  libbirch_line_(248);
  #line 248 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 249 "src/data/Buffer.birch"
    libbirch_line_(249);
    #line 249 "src/data/Buffer.birch"
    return buffer.get()->getBoolean(handler_);
  } else {
    #line 251 "src/data/Buffer.birch"
    libbirch_line_(251);
    #line 251 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 263 "src/data/Buffer.birch"
libbirch::Optional<birch::type::Integer> birch::type::Buffer::getInteger(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 263 "src/data/Buffer.birch"
  libbirch_function_("getInteger", "src/data/Buffer.birch", 263);
  #line 264 "src/data/Buffer.birch"
  libbirch_line_(264);
  #line 264 "src/data/Buffer.birch"
  auto buffer = this_()->getChild(name, handler_);
  #line 265 "src/data/Buffer.birch"
  libbirch_line_(265);
  #line 265 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 266 "src/data/Buffer.birch"
    libbirch_line_(266);
    #line 266 "src/data/Buffer.birch"
    return buffer.get()->getInteger(handler_);
  } else {
    #line 268 "src/data/Buffer.birch"
    libbirch_line_(268);
    #line 268 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 280 "src/data/Buffer.birch"
libbirch::Optional<birch::type::Real> birch::type::Buffer::getReal(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 280 "src/data/Buffer.birch"
  libbirch_function_("getReal", "src/data/Buffer.birch", 280);
  #line 281 "src/data/Buffer.birch"
  libbirch_line_(281);
  #line 281 "src/data/Buffer.birch"
  auto buffer = this_()->getChild(name, handler_);
  #line 282 "src/data/Buffer.birch"
  libbirch_line_(282);
  #line 282 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 283 "src/data/Buffer.birch"
    libbirch_line_(283);
    #line 283 "src/data/Buffer.birch"
    return buffer.get()->getReal(handler_);
  } else {
    #line 285 "src/data/Buffer.birch"
    libbirch_line_(285);
    #line 285 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 297 "src/data/Buffer.birch"
libbirch::Optional<birch::type::String> birch::type::Buffer::getString(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 297 "src/data/Buffer.birch"
  libbirch_function_("getString", "src/data/Buffer.birch", 297);
  #line 298 "src/data/Buffer.birch"
  libbirch_line_(298);
  #line 298 "src/data/Buffer.birch"
  auto buffer = this_()->getChild(name, handler_);
  #line 299 "src/data/Buffer.birch"
  libbirch_line_(299);
  #line 299 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 300 "src/data/Buffer.birch"
    libbirch_line_(300);
    #line 300 "src/data/Buffer.birch"
    return buffer.get()->getString(handler_);
  } else {
    #line 302 "src/data/Buffer.birch"
    libbirch_line_(302);
    #line 302 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 314 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,1>> birch::type::Buffer::getBooleanVector(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 314 "src/data/Buffer.birch"
  libbirch_function_("getBooleanVector", "src/data/Buffer.birch", 314);
  #line 315 "src/data/Buffer.birch"
  libbirch_line_(315);
  #line 315 "src/data/Buffer.birch"
  auto buffer = this_()->getChild(name, handler_);
  #line 316 "src/data/Buffer.birch"
  libbirch_line_(316);
  #line 316 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 317 "src/data/Buffer.birch"
    libbirch_line_(317);
    #line 317 "src/data/Buffer.birch"
    return buffer.get()->getBooleanVector(handler_);
  } else {
    #line 319 "src/data/Buffer.birch"
    libbirch_line_(319);
    #line 319 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 331 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,1>> birch::type::Buffer::getIntegerVector(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 331 "src/data/Buffer.birch"
  libbirch_function_("getIntegerVector", "src/data/Buffer.birch", 331);
  #line 332 "src/data/Buffer.birch"
  libbirch_line_(332);
  #line 332 "src/data/Buffer.birch"
  auto buffer = this_()->getChild(name, handler_);
  #line 333 "src/data/Buffer.birch"
  libbirch_line_(333);
  #line 333 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 334 "src/data/Buffer.birch"
    libbirch_line_(334);
    #line 334 "src/data/Buffer.birch"
    return buffer.get()->getIntegerVector(handler_);
  } else {
    #line 336 "src/data/Buffer.birch"
    libbirch_line_(336);
    #line 336 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 348 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::Buffer::getRealVector(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 348 "src/data/Buffer.birch"
  libbirch_function_("getRealVector", "src/data/Buffer.birch", 348);
  #line 349 "src/data/Buffer.birch"
  libbirch_line_(349);
  #line 349 "src/data/Buffer.birch"
  auto buffer = this_()->getChild(name, handler_);
  #line 350 "src/data/Buffer.birch"
  libbirch_line_(350);
  #line 350 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 351 "src/data/Buffer.birch"
    libbirch_line_(351);
    #line 351 "src/data/Buffer.birch"
    return buffer.get()->getRealVector(handler_);
  } else {
    #line 353 "src/data/Buffer.birch"
    libbirch_line_(353);
    #line 353 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 365 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,2>> birch::type::Buffer::getBooleanMatrix(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 365 "src/data/Buffer.birch"
  libbirch_function_("getBooleanMatrix", "src/data/Buffer.birch", 365);
  #line 366 "src/data/Buffer.birch"
  libbirch_line_(366);
  #line 366 "src/data/Buffer.birch"
  auto buffer = this_()->getChild(name, handler_);
  #line 367 "src/data/Buffer.birch"
  libbirch_line_(367);
  #line 367 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 368 "src/data/Buffer.birch"
    libbirch_line_(368);
    #line 368 "src/data/Buffer.birch"
    return buffer.get()->getBooleanMatrix(handler_);
  } else {
    #line 370 "src/data/Buffer.birch"
    libbirch_line_(370);
    #line 370 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 382 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,2>> birch::type::Buffer::getIntegerMatrix(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 382 "src/data/Buffer.birch"
  libbirch_function_("getIntegerMatrix", "src/data/Buffer.birch", 382);
  #line 383 "src/data/Buffer.birch"
  libbirch_line_(383);
  #line 383 "src/data/Buffer.birch"
  auto buffer = this_()->getChild(name, handler_);
  #line 384 "src/data/Buffer.birch"
  libbirch_line_(384);
  #line 384 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 385 "src/data/Buffer.birch"
    libbirch_line_(385);
    #line 385 "src/data/Buffer.birch"
    return buffer.get()->getIntegerMatrix(handler_);
  } else {
    #line 387 "src/data/Buffer.birch"
    libbirch_line_(387);
    #line 387 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 399 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::Buffer::getRealMatrix(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 399 "src/data/Buffer.birch"
  libbirch_function_("getRealMatrix", "src/data/Buffer.birch", 399);
  #line 400 "src/data/Buffer.birch"
  libbirch_line_(400);
  #line 400 "src/data/Buffer.birch"
  auto buffer = this_()->getChild(name, handler_);
  #line 401 "src/data/Buffer.birch"
  libbirch_line_(401);
  #line 401 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 402 "src/data/Buffer.birch"
    libbirch_line_(402);
    #line 402 "src/data/Buffer.birch"
    return buffer.get()->getRealMatrix(handler_);
  } else {
    #line 404 "src/data/Buffer.birch"
    libbirch_line_(404);
    #line 404 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 416 "src/data/Buffer.birch"
libbirch::Optional<birch::type::LLT> birch::type::Buffer::getLLT(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 416 "src/data/Buffer.birch"
  libbirch_function_("getLLT", "src/data/Buffer.birch", 416);
  #line 417 "src/data/Buffer.birch"
  libbirch_line_(417);
  #line 417 "src/data/Buffer.birch"
  auto buffer = this_()->getChild(name, handler_);
  #line 418 "src/data/Buffer.birch"
  libbirch_line_(418);
  #line 418 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 419 "src/data/Buffer.birch"
    libbirch_line_(419);
    #line 419 "src/data/Buffer.birch"
    return buffer.get()->getLLT(handler_);
  } else {
    #line 421 "src/data/Buffer.birch"
    libbirch_line_(421);
    #line 421 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 432 "src/data/Buffer.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Object>>> birch::type::Buffer::get(const libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Object>>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 432 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 432);
  #line 433 "src/data/Buffer.birch"
  libbirch_line_(433);
  #line 433 "src/data/Buffer.birch"
  if (value.query()) {
    #line 434 "src/data/Buffer.birch"
    libbirch_line_(434);
    #line 434 "src/data/Buffer.birch"
    value.get()->read(shared_from_this_(), handler_);
  }
  #line 436 "src/data/Buffer.birch"
  libbirch_line_(436);
  #line 436 "src/data/Buffer.birch"
  return value;
}

#line 446 "src/data/Buffer.birch"
libbirch::Optional<birch::type::Boolean> birch::type::Buffer::get(const libbirch::Optional<birch::type::Boolean>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 446 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 446);
  #line 447 "src/data/Buffer.birch"
  libbirch_line_(447);
  #line 447 "src/data/Buffer.birch"
  return this_()->getBoolean(handler_);
}

#line 457 "src/data/Buffer.birch"
libbirch::Optional<birch::type::Integer> birch::type::Buffer::get(const libbirch::Optional<birch::type::Integer>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 457 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 457);
  #line 458 "src/data/Buffer.birch"
  libbirch_line_(458);
  #line 458 "src/data/Buffer.birch"
  return this_()->getInteger(handler_);
}

#line 468 "src/data/Buffer.birch"
libbirch::Optional<birch::type::Real> birch::type::Buffer::get(const libbirch::Optional<birch::type::Real>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 468 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 468);
  #line 469 "src/data/Buffer.birch"
  libbirch_line_(469);
  #line 469 "src/data/Buffer.birch"
  return this_()->getReal(handler_);
}

#line 479 "src/data/Buffer.birch"
libbirch::Optional<birch::type::String> birch::type::Buffer::get(const libbirch::Optional<birch::type::String>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 479 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 479);
  #line 480 "src/data/Buffer.birch"
  libbirch_line_(480);
  #line 480 "src/data/Buffer.birch"
  return this_()->getString(handler_);
}

#line 491 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,1>> birch::type::Buffer::get(const libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,1>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 491 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 491);
  #line 492 "src/data/Buffer.birch"
  libbirch_line_(492);
  #line 492 "src/data/Buffer.birch"
  return this_()->getBooleanVector(handler_);
}

#line 503 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,1>> birch::type::Buffer::get(const libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,1>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 503 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 503);
  #line 504 "src/data/Buffer.birch"
  libbirch_line_(504);
  #line 504 "src/data/Buffer.birch"
  return this_()->getIntegerVector(handler_);
}

#line 515 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::Buffer::get(const libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 515 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 515);
  #line 516 "src/data/Buffer.birch"
  libbirch_line_(516);
  #line 516 "src/data/Buffer.birch"
  return this_()->getRealVector(handler_);
}

#line 527 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,2>> birch::type::Buffer::get(const libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,2>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 527 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 527);
  #line 528 "src/data/Buffer.birch"
  libbirch_line_(528);
  #line 528 "src/data/Buffer.birch"
  return this_()->getBooleanMatrix(handler_);
}

#line 539 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,2>> birch::type::Buffer::get(const libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,2>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 539 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 539);
  #line 540 "src/data/Buffer.birch"
  libbirch_line_(540);
  #line 540 "src/data/Buffer.birch"
  return this_()->getIntegerMatrix(handler_);
}

#line 551 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::Buffer::get(const libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 551 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 551);
  #line 552 "src/data/Buffer.birch"
  libbirch_line_(552);
  #line 552 "src/data/Buffer.birch"
  return this_()->getRealMatrix(handler_);
}

#line 563 "src/data/Buffer.birch"
libbirch::Optional<birch::type::LLT> birch::type::Buffer::get(const libbirch::Optional<birch::type::LLT>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 563 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 563);
  #line 564 "src/data/Buffer.birch"
  libbirch_line_(564);
  #line 564 "src/data/Buffer.birch"
  return this_()->getLLT(handler_);
}

#line 575 "src/data/Buffer.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Object>>> birch::type::Buffer::get(const birch::type::String& name, const libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Object>>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 575 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 575);
  #line 576 "src/data/Buffer.birch"
  libbirch_line_(576);
  #line 576 "src/data/Buffer.birch"
  auto buffer = this_()->getObject(name, handler_);
  #line 577 "src/data/Buffer.birch"
  libbirch_line_(577);
  #line 577 "src/data/Buffer.birch"
  if (buffer.query()) {
    #line 578 "src/data/Buffer.birch"
    libbirch_line_(578);
    #line 578 "src/data/Buffer.birch"
    return buffer.get()->get(value, handler_);
  } else {
    #line 580 "src/data/Buffer.birch"
    libbirch_line_(580);
    #line 580 "src/data/Buffer.birch"
    return libbirch::nil;
  }
}

#line 593 "src/data/Buffer.birch"
libbirch::Optional<birch::type::Boolean> birch::type::Buffer::get(const birch::type::String& name, const libbirch::Optional<birch::type::Boolean>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 593 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 593);
  #line 594 "src/data/Buffer.birch"
  libbirch_line_(594);
  #line 594 "src/data/Buffer.birch"
  return this_()->getBoolean(name, handler_);
}

#line 606 "src/data/Buffer.birch"
libbirch::Optional<birch::type::Integer> birch::type::Buffer::get(const birch::type::String& name, const libbirch::Optional<birch::type::Integer>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 606 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 606);
  #line 607 "src/data/Buffer.birch"
  libbirch_line_(607);
  #line 607 "src/data/Buffer.birch"
  return this_()->getInteger(name, handler_);
}

#line 619 "src/data/Buffer.birch"
libbirch::Optional<birch::type::Real> birch::type::Buffer::get(const birch::type::String& name, const libbirch::Optional<birch::type::Real>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 619 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 619);
  #line 620 "src/data/Buffer.birch"
  libbirch_line_(620);
  #line 620 "src/data/Buffer.birch"
  return this_()->getReal(name, handler_);
}

#line 632 "src/data/Buffer.birch"
libbirch::Optional<birch::type::String> birch::type::Buffer::get(const birch::type::String& name, const libbirch::Optional<birch::type::String>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 632 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 632);
  #line 633 "src/data/Buffer.birch"
  libbirch_line_(633);
  #line 633 "src/data/Buffer.birch"
  return this_()->getString(name, handler_);
}

#line 645 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,1>> birch::type::Buffer::get(const birch::type::String& name, const libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,1>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 645 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 645);
  #line 646 "src/data/Buffer.birch"
  libbirch_line_(646);
  #line 646 "src/data/Buffer.birch"
  return this_()->getBooleanVector(name, handler_);
}

#line 658 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,1>> birch::type::Buffer::get(const birch::type::String& name, const libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,1>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 658 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 658);
  #line 659 "src/data/Buffer.birch"
  libbirch_line_(659);
  #line 659 "src/data/Buffer.birch"
  return this_()->getIntegerVector(name, handler_);
}

#line 671 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::Buffer::get(const birch::type::String& name, const libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 671 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 671);
  #line 672 "src/data/Buffer.birch"
  libbirch_line_(672);
  #line 672 "src/data/Buffer.birch"
  return this_()->getRealVector(name, handler_);
}

#line 684 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,2>> birch::type::Buffer::get(const birch::type::String& name, const libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,2>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 684 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 684);
  #line 685 "src/data/Buffer.birch"
  libbirch_line_(685);
  #line 685 "src/data/Buffer.birch"
  return this_()->getBooleanMatrix(name, handler_);
}

#line 697 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,2>> birch::type::Buffer::get(const birch::type::String& name, const libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,2>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 697 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 697);
  #line 698 "src/data/Buffer.birch"
  libbirch_line_(698);
  #line 698 "src/data/Buffer.birch"
  return this_()->getIntegerMatrix(name, handler_);
}

#line 710 "src/data/Buffer.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::Buffer::get(const birch::type::String& name, const libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 710 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 710);
  #line 711 "src/data/Buffer.birch"
  libbirch_line_(711);
  #line 711 "src/data/Buffer.birch"
  return this_()->getRealMatrix(name, handler_);
}

#line 723 "src/data/Buffer.birch"
libbirch::Optional<birch::type::LLT> birch::type::Buffer::get(const birch::type::String& name, const libbirch::Optional<birch::type::LLT>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 723 "src/data/Buffer.birch"
  libbirch_function_("get", "src/data/Buffer.birch", 723);
  #line 724 "src/data/Buffer.birch"
  libbirch_line_(724);
  #line 724 "src/data/Buffer.birch"
  return this_()->getLLT(name, handler_);
}

#line 730 "src/data/Buffer.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> birch::type::Buffer::setObject(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 730 "src/data/Buffer.birch"
  libbirch_function_("setObject", "src/data/Buffer.birch", 730);
  #line 731 "src/data/Buffer.birch"
  libbirch_line_(731);
  #line 731 "src/data/Buffer.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::ObjectValue>> v;
  #line 732 "src/data/Buffer.birch"
  libbirch_line_(732);
  #line 732 "src/data/Buffer.birch"
  this_()->value = v;
  #line 733 "src/data/Buffer.birch"
  libbirch_line_(733);
  #line 733 "src/data/Buffer.birch"
  return shared_from_this_();
}

#line 739 "src/data/Buffer.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> birch::type::Buffer::setArray(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 739 "src/data/Buffer.birch"
  libbirch_function_("setArray", "src/data/Buffer.birch", 739);
  #line 740 "src/data/Buffer.birch"
  libbirch_line_(740);
  #line 740 "src/data/Buffer.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::ArrayValue>> v;
  #line 741 "src/data/Buffer.birch"
  libbirch_line_(741);
  #line 741 "src/data/Buffer.birch"
  this_()->value = v;
  #line 742 "src/data/Buffer.birch"
  libbirch_line_(742);
  #line 742 "src/data/Buffer.birch"
  return shared_from_this_();
}

#line 748 "src/data/Buffer.birch"
void birch::type::Buffer::setNil(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 748 "src/data/Buffer.birch"
  libbirch_function_("setNil", "src/data/Buffer.birch", 748);
  #line 749 "src/data/Buffer.birch"
  libbirch_line_(749);
  #line 749 "src/data/Buffer.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::NilValue>> v;
  #line 750 "src/data/Buffer.birch"
  libbirch_line_(750);
  #line 750 "src/data/Buffer.birch"
  this_()->value = v;
}

#line 758 "src/data/Buffer.birch"
void birch::type::Buffer::setBoolean(const birch::type::Boolean& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 758 "src/data/Buffer.birch"
  libbirch_function_("setBoolean", "src/data/Buffer.birch", 758);
  #line 759 "src/data/Buffer.birch"
  libbirch_line_(759);
  #line 759 "src/data/Buffer.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::BooleanValue>> v(value);
  #line 760 "src/data/Buffer.birch"
  libbirch_line_(760);
  #line 760 "src/data/Buffer.birch"
  this_()->value = v;
}

#line 768 "src/data/Buffer.birch"
void birch::type::Buffer::setInteger(const birch::type::Integer& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 768 "src/data/Buffer.birch"
  libbirch_function_("setInteger", "src/data/Buffer.birch", 768);
  #line 769 "src/data/Buffer.birch"
  libbirch_line_(769);
  #line 769 "src/data/Buffer.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::IntegerValue>> v(value);
  #line 770 "src/data/Buffer.birch"
  libbirch_line_(770);
  #line 770 "src/data/Buffer.birch"
  this_()->value = v;
}

#line 778 "src/data/Buffer.birch"
void birch::type::Buffer::setReal(const birch::type::Real& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 778 "src/data/Buffer.birch"
  libbirch_function_("setReal", "src/data/Buffer.birch", 778);
  #line 779 "src/data/Buffer.birch"
  libbirch_line_(779);
  #line 779 "src/data/Buffer.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::RealValue>> v(value);
  #line 780 "src/data/Buffer.birch"
  libbirch_line_(780);
  #line 780 "src/data/Buffer.birch"
  this_()->value = v;
}

#line 788 "src/data/Buffer.birch"
void birch::type::Buffer::setString(const birch::type::String& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 788 "src/data/Buffer.birch"
  libbirch_function_("setString", "src/data/Buffer.birch", 788);
  #line 789 "src/data/Buffer.birch"
  libbirch_line_(789);
  #line 789 "src/data/Buffer.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::StringValue>> v(value);
  #line 790 "src/data/Buffer.birch"
  libbirch_line_(790);
  #line 790 "src/data/Buffer.birch"
  this_()->value = v;
}

#line 798 "src/data/Buffer.birch"
void birch::type::Buffer::setBooleanVector(const libbirch::DefaultArray<birch::type::Boolean,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 798 "src/data/Buffer.birch"
  libbirch_function_("setBooleanVector", "src/data/Buffer.birch", 798);
  #line 799 "src/data/Buffer.birch"
  libbirch_line_(799);
  #line 799 "src/data/Buffer.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::BooleanVectorValue>> v(value);
  #line 800 "src/data/Buffer.birch"
  libbirch_line_(800);
  #line 800 "src/data/Buffer.birch"
  this_()->value = v;
}

#line 808 "src/data/Buffer.birch"
void birch::type::Buffer::setIntegerVector(const libbirch::DefaultArray<birch::type::Integer,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 808 "src/data/Buffer.birch"
  libbirch_function_("setIntegerVector", "src/data/Buffer.birch", 808);
  #line 809 "src/data/Buffer.birch"
  libbirch_line_(809);
  #line 809 "src/data/Buffer.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::IntegerVectorValue>> v(value);
  #line 810 "src/data/Buffer.birch"
  libbirch_line_(810);
  #line 810 "src/data/Buffer.birch"
  this_()->value = v;
}

#line 818 "src/data/Buffer.birch"
void birch::type::Buffer::setRealVector(const libbirch::DefaultArray<birch::type::Real,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 818 "src/data/Buffer.birch"
  libbirch_function_("setRealVector", "src/data/Buffer.birch", 818);
  #line 819 "src/data/Buffer.birch"
  libbirch_line_(819);
  #line 819 "src/data/Buffer.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::RealVectorValue>> v(value);
  #line 820 "src/data/Buffer.birch"
  libbirch_line_(820);
  #line 820 "src/data/Buffer.birch"
  this_()->value = v;
}

#line 828 "src/data/Buffer.birch"
void birch::type::Buffer::setObjectVector(const libbirch::DefaultArray<libbirch::Lazy<libbirch::Shared<birch::type::Object>>,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 828 "src/data/Buffer.birch"
  libbirch_function_("setObjectVector", "src/data/Buffer.birch", 828);
  #line 829 "src/data/Buffer.birch"
  libbirch_line_(829);
  #line 829 "src/data/Buffer.birch"
  this_()->setArray(handler_);
  #line 830 "src/data/Buffer.birch"
  libbirch_line_(830);
  #line 830 "src/data/Buffer.birch"
  for (auto n = birch::type::Integer(1); n <= birch::length(value, handler_); ++n) {
    #line 831 "src/data/Buffer.birch"
    libbirch_line_(831);
    #line 831 "src/data/Buffer.birch"
    this_()->push(handler_)->set(value.get(libbirch::make_slice(n - 1)), handler_);
  }
}

#line 840 "src/data/Buffer.birch"
void birch::type::Buffer::setBooleanMatrix(const libbirch::DefaultArray<birch::type::Boolean,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 840 "src/data/Buffer.birch"
  libbirch_function_("setBooleanMatrix", "src/data/Buffer.birch", 840);
  #line 841 "src/data/Buffer.birch"
  libbirch_line_(841);
  #line 841 "src/data/Buffer.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::BooleanMatrixValue>> v(value);
  #line 842 "src/data/Buffer.birch"
  libbirch_line_(842);
  #line 842 "src/data/Buffer.birch"
  this_()->value = v;
}

#line 850 "src/data/Buffer.birch"
void birch::type::Buffer::setIntegerMatrix(const libbirch::DefaultArray<birch::type::Integer,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 850 "src/data/Buffer.birch"
  libbirch_function_("setIntegerMatrix", "src/data/Buffer.birch", 850);
  #line 851 "src/data/Buffer.birch"
  libbirch_line_(851);
  #line 851 "src/data/Buffer.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::IntegerMatrixValue>> v(value);
  #line 852 "src/data/Buffer.birch"
  libbirch_line_(852);
  #line 852 "src/data/Buffer.birch"
  this_()->value = v;
}

#line 860 "src/data/Buffer.birch"
void birch::type::Buffer::setRealMatrix(const libbirch::DefaultArray<birch::type::Real,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 860 "src/data/Buffer.birch"
  libbirch_function_("setRealMatrix", "src/data/Buffer.birch", 860);
  #line 861 "src/data/Buffer.birch"
  libbirch_line_(861);
  #line 861 "src/data/Buffer.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::RealMatrixValue>> v(value);
  #line 862 "src/data/Buffer.birch"
  libbirch_line_(862);
  #line 862 "src/data/Buffer.birch"
  this_()->value = v;
}

#line 870 "src/data/Buffer.birch"
void birch::type::Buffer::setLLT(const birch::type::LLT& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 870 "src/data/Buffer.birch"
  libbirch_function_("setLLT", "src/data/Buffer.birch", 870);
  #line 871 "src/data/Buffer.birch"
  libbirch_line_(871);
  #line 871 "src/data/Buffer.birch"
  this_()->setRealMatrix(birch::canonical(value, handler_), handler_);
}

#line 879 "src/data/Buffer.birch"
void birch::type::Buffer::setObjectMatrix(const libbirch::DefaultArray<libbirch::Lazy<libbirch::Shared<birch::type::Object>>,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 879 "src/data/Buffer.birch"
  libbirch_function_("setObjectMatrix", "src/data/Buffer.birch", 879);
  #line 880 "src/data/Buffer.birch"
  libbirch_line_(880);
  #line 880 "src/data/Buffer.birch"
  this_()->setArray(handler_);
  #line 881 "src/data/Buffer.birch"
  libbirch_line_(881);
  #line 881 "src/data/Buffer.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(value, handler_); ++i) {
    #line 882 "src/data/Buffer.birch"
    libbirch_line_(882);
    #line 882 "src/data/Buffer.birch"
    auto buffer = this_()->push(handler_)->setArray(handler_);
    #line 883 "src/data/Buffer.birch"
    libbirch_line_(883);
    #line 883 "src/data/Buffer.birch"
    for (auto j = birch::type::Integer(1); j <= birch::columns(value, handler_); ++j) {
      #line 884 "src/data/Buffer.birch"
      libbirch_line_(884);
      #line 884 "src/data/Buffer.birch"
      buffer->push(handler_)->set(value.get(libbirch::make_slice(i - 1, j - 1)), handler_);
    }
  }
}

#line 894 "src/data/Buffer.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> birch::type::Buffer::setObject(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 894 "src/data/Buffer.birch"
  libbirch_function_("setObject", "src/data/Buffer.birch", 894);
  #line 895 "src/data/Buffer.birch"
  libbirch_line_(895);
  #line 895 "src/data/Buffer.birch"
  return this_()->setChild(name, handler_)->setObject(handler_);
}

#line 903 "src/data/Buffer.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> birch::type::Buffer::setArray(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 903 "src/data/Buffer.birch"
  libbirch_function_("setArray", "src/data/Buffer.birch", 903);
  #line 904 "src/data/Buffer.birch"
  libbirch_line_(904);
  #line 904 "src/data/Buffer.birch"
  return this_()->setChild(name, handler_)->setArray(handler_);
}

#line 912 "src/data/Buffer.birch"
void birch::type::Buffer::setNil(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 912 "src/data/Buffer.birch"
  libbirch_function_("setNil", "src/data/Buffer.birch", 912);
  #line 913 "src/data/Buffer.birch"
  libbirch_line_(913);
  #line 913 "src/data/Buffer.birch"
  this_()->setChild(name, handler_)->setNil(handler_);
}

#line 922 "src/data/Buffer.birch"
void birch::type::Buffer::setBoolean(const birch::type::String& name, const birch::type::Boolean& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 922 "src/data/Buffer.birch"
  libbirch_function_("setBoolean", "src/data/Buffer.birch", 922);
  #line 923 "src/data/Buffer.birch"
  libbirch_line_(923);
  #line 923 "src/data/Buffer.birch"
  this_()->setChild(name, handler_)->setBoolean(value, handler_);
}

#line 932 "src/data/Buffer.birch"
void birch::type::Buffer::setInteger(const birch::type::String& name, const birch::type::Integer& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 932 "src/data/Buffer.birch"
  libbirch_function_("setInteger", "src/data/Buffer.birch", 932);
  #line 933 "src/data/Buffer.birch"
  libbirch_line_(933);
  #line 933 "src/data/Buffer.birch"
  this_()->setChild(name, handler_)->setInteger(value, handler_);
}

#line 942 "src/data/Buffer.birch"
void birch::type::Buffer::setReal(const birch::type::String& name, const birch::type::Real& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 942 "src/data/Buffer.birch"
  libbirch_function_("setReal", "src/data/Buffer.birch", 942);
  #line 943 "src/data/Buffer.birch"
  libbirch_line_(943);
  #line 943 "src/data/Buffer.birch"
  this_()->setChild(name, handler_)->setReal(value, handler_);
}

#line 952 "src/data/Buffer.birch"
void birch::type::Buffer::setString(const birch::type::String& name, const birch::type::String& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 952 "src/data/Buffer.birch"
  libbirch_function_("setString", "src/data/Buffer.birch", 952);
  #line 953 "src/data/Buffer.birch"
  libbirch_line_(953);
  #line 953 "src/data/Buffer.birch"
  this_()->setChild(name, handler_)->setString(value, handler_);
}

#line 962 "src/data/Buffer.birch"
void birch::type::Buffer::setBooleanVector(const birch::type::String& name, const libbirch::DefaultArray<birch::type::Boolean,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 962 "src/data/Buffer.birch"
  libbirch_function_("setBooleanVector", "src/data/Buffer.birch", 962);
  #line 963 "src/data/Buffer.birch"
  libbirch_line_(963);
  #line 963 "src/data/Buffer.birch"
  this_()->setChild(name, handler_)->setBooleanVector(value, handler_);
}

#line 972 "src/data/Buffer.birch"
void birch::type::Buffer::setIntegerVector(const birch::type::String& name, const libbirch::DefaultArray<birch::type::Integer,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 972 "src/data/Buffer.birch"
  libbirch_function_("setIntegerVector", "src/data/Buffer.birch", 972);
  #line 973 "src/data/Buffer.birch"
  libbirch_line_(973);
  #line 973 "src/data/Buffer.birch"
  this_()->setChild(name, handler_)->setIntegerVector(value, handler_);
}

#line 982 "src/data/Buffer.birch"
void birch::type::Buffer::setRealVector(const birch::type::String& name, const libbirch::DefaultArray<birch::type::Real,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 982 "src/data/Buffer.birch"
  libbirch_function_("setRealVector", "src/data/Buffer.birch", 982);
  #line 983 "src/data/Buffer.birch"
  libbirch_line_(983);
  #line 983 "src/data/Buffer.birch"
  this_()->setChild(name, handler_)->setRealVector(value, handler_);
}

#line 992 "src/data/Buffer.birch"
void birch::type::Buffer::setObjectVector(const birch::type::String& name, const libbirch::DefaultArray<libbirch::Lazy<libbirch::Shared<birch::type::Object>>,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 992 "src/data/Buffer.birch"
  libbirch_function_("setObjectVector", "src/data/Buffer.birch", 992);
  #line 993 "src/data/Buffer.birch"
  libbirch_line_(993);
  #line 993 "src/data/Buffer.birch"
  this_()->setChild(name, handler_)->setObjectVector(value, handler_);
}

#line 1002 "src/data/Buffer.birch"
void birch::type::Buffer::setBooleanMatrix(const birch::type::String& name, const libbirch::DefaultArray<birch::type::Boolean,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1002 "src/data/Buffer.birch"
  libbirch_function_("setBooleanMatrix", "src/data/Buffer.birch", 1002);
  #line 1003 "src/data/Buffer.birch"
  libbirch_line_(1003);
  #line 1003 "src/data/Buffer.birch"
  this_()->setChild(name, handler_)->setBooleanMatrix(value, handler_);
}

#line 1012 "src/data/Buffer.birch"
void birch::type::Buffer::setIntegerMatrix(const birch::type::String& name, const libbirch::DefaultArray<birch::type::Integer,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1012 "src/data/Buffer.birch"
  libbirch_function_("setIntegerMatrix", "src/data/Buffer.birch", 1012);
  #line 1013 "src/data/Buffer.birch"
  libbirch_line_(1013);
  #line 1013 "src/data/Buffer.birch"
  this_()->setChild(name, handler_)->setIntegerMatrix(value, handler_);
}

#line 1022 "src/data/Buffer.birch"
void birch::type::Buffer::setRealMatrix(const birch::type::String& name, const libbirch::DefaultArray<birch::type::Real,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1022 "src/data/Buffer.birch"
  libbirch_function_("setRealMatrix", "src/data/Buffer.birch", 1022);
  #line 1023 "src/data/Buffer.birch"
  libbirch_line_(1023);
  #line 1023 "src/data/Buffer.birch"
  this_()->setChild(name, handler_)->setRealMatrix(value, handler_);
}

#line 1032 "src/data/Buffer.birch"
void birch::type::Buffer::setLLT(const birch::type::String& name, const birch::type::LLT& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1032 "src/data/Buffer.birch"
  libbirch_function_("setLLT", "src/data/Buffer.birch", 1032);
  #line 1033 "src/data/Buffer.birch"
  libbirch_line_(1033);
  #line 1033 "src/data/Buffer.birch"
  this_()->setChild(name, handler_)->setLLT(value, handler_);
}

#line 1042 "src/data/Buffer.birch"
void birch::type::Buffer::setObjectMatrix(const birch::type::String& name, const libbirch::DefaultArray<libbirch::Lazy<libbirch::Shared<birch::type::Object>>,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1042 "src/data/Buffer.birch"
  libbirch_function_("setObjectMatrix", "src/data/Buffer.birch", 1042);
  #line 1043 "src/data/Buffer.birch"
  libbirch_line_(1043);
  #line 1043 "src/data/Buffer.birch"
  this_()->setChild(name, handler_)->setObjectMatrix(value, handler_);
}

#line 1051 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::Boolean& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1051 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1051);
  #line 1052 "src/data/Buffer.birch"
  libbirch_line_(1052);
  #line 1052 "src/data/Buffer.birch"
  this_()->setBoolean(value, handler_);
}

#line 1060 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::Integer& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1060 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1060);
  #line 1061 "src/data/Buffer.birch"
  libbirch_line_(1061);
  #line 1061 "src/data/Buffer.birch"
  this_()->setInteger(value, handler_);
}

#line 1069 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::Real& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1069 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1069);
  #line 1070 "src/data/Buffer.birch"
  libbirch_line_(1070);
  #line 1070 "src/data/Buffer.birch"
  this_()->setReal(value, handler_);
}

#line 1078 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1078 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1078);
  #line 1079 "src/data/Buffer.birch"
  libbirch_line_(1079);
  #line 1079 "src/data/Buffer.birch"
  this_()->setString(value, handler_);
}

#line 1087 "src/data/Buffer.birch"
void birch::type::Buffer::set(const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1087 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1087);
  #line 1088 "src/data/Buffer.birch"
  libbirch_line_(1088);
  #line 1088 "src/data/Buffer.birch"
  this_()->setObject(handler_);
  #line 1089 "src/data/Buffer.birch"
  libbirch_line_(1089);
  #line 1089 "src/data/Buffer.birch"
  value->write(shared_from_this_(), handler_);
}

#line 1097 "src/data/Buffer.birch"
void birch::type::Buffer::set(const libbirch::DefaultArray<birch::type::Boolean,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1097 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1097);
  #line 1098 "src/data/Buffer.birch"
  libbirch_line_(1098);
  #line 1098 "src/data/Buffer.birch"
  this_()->setBooleanVector(value, handler_);
}

#line 1106 "src/data/Buffer.birch"
void birch::type::Buffer::set(const libbirch::DefaultArray<birch::type::Integer,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1106 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1106);
  #line 1107 "src/data/Buffer.birch"
  libbirch_line_(1107);
  #line 1107 "src/data/Buffer.birch"
  this_()->setIntegerVector(value, handler_);
}

#line 1115 "src/data/Buffer.birch"
void birch::type::Buffer::set(const libbirch::DefaultArray<birch::type::Real,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1115 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1115);
  #line 1116 "src/data/Buffer.birch"
  libbirch_line_(1116);
  #line 1116 "src/data/Buffer.birch"
  this_()->setRealVector(value, handler_);
}

#line 1124 "src/data/Buffer.birch"
void birch::type::Buffer::set(const libbirch::DefaultArray<libbirch::Lazy<libbirch::Shared<birch::type::Object>>,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1124 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1124);
  #line 1125 "src/data/Buffer.birch"
  libbirch_line_(1125);
  #line 1125 "src/data/Buffer.birch"
  this_()->setObjectVector(value, handler_);
}

#line 1133 "src/data/Buffer.birch"
void birch::type::Buffer::set(const libbirch::DefaultArray<birch::type::Boolean,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1133 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1133);
  #line 1134 "src/data/Buffer.birch"
  libbirch_line_(1134);
  #line 1134 "src/data/Buffer.birch"
  this_()->setBooleanMatrix(value, handler_);
}

#line 1142 "src/data/Buffer.birch"
void birch::type::Buffer::set(const libbirch::DefaultArray<birch::type::Integer,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1142 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1142);
  #line 1143 "src/data/Buffer.birch"
  libbirch_line_(1143);
  #line 1143 "src/data/Buffer.birch"
  this_()->setIntegerMatrix(value, handler_);
}

#line 1151 "src/data/Buffer.birch"
void birch::type::Buffer::set(const libbirch::DefaultArray<birch::type::Real,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1151 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1151);
  #line 1152 "src/data/Buffer.birch"
  libbirch_line_(1152);
  #line 1152 "src/data/Buffer.birch"
  this_()->setRealMatrix(value, handler_);
}

#line 1160 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::LLT& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1160 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1160);
  #line 1161 "src/data/Buffer.birch"
  libbirch_line_(1161);
  #line 1161 "src/data/Buffer.birch"
  this_()->setLLT(value, handler_);
}

#line 1169 "src/data/Buffer.birch"
void birch::type::Buffer::set(const libbirch::DefaultArray<libbirch::Lazy<libbirch::Shared<birch::type::Object>>,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1169 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1169);
  #line 1170 "src/data/Buffer.birch"
  libbirch_line_(1170);
  #line 1170 "src/data/Buffer.birch"
  this_()->setObjectMatrix(value, handler_);
}

#line 1179 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& name, const birch::type::Boolean& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1179 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1179);
  #line 1180 "src/data/Buffer.birch"
  libbirch_line_(1180);
  #line 1180 "src/data/Buffer.birch"
  this_()->setBoolean(name, value, handler_);
}

#line 1189 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& name, const birch::type::Integer& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1189 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1189);
  #line 1190 "src/data/Buffer.birch"
  libbirch_line_(1190);
  #line 1190 "src/data/Buffer.birch"
  this_()->setInteger(name, value, handler_);
}

#line 1199 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& name, const birch::type::Real& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1199 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1199);
  #line 1200 "src/data/Buffer.birch"
  libbirch_line_(1200);
  #line 1200 "src/data/Buffer.birch"
  this_()->setReal(name, value, handler_);
}

#line 1209 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& name, const birch::type::String& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1209 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1209);
  #line 1210 "src/data/Buffer.birch"
  libbirch_line_(1210);
  #line 1210 "src/data/Buffer.birch"
  this_()->setString(name, value, handler_);
}

#line 1219 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1219 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1219);
  #line 1220 "src/data/Buffer.birch"
  libbirch_line_(1220);
  #line 1220 "src/data/Buffer.birch"
  this_()->setChild(name, handler_)->set(value, handler_);
}

#line 1229 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& name, const libbirch::DefaultArray<birch::type::Boolean,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1229 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1229);
  #line 1230 "src/data/Buffer.birch"
  libbirch_line_(1230);
  #line 1230 "src/data/Buffer.birch"
  this_()->setBooleanVector(name, value, handler_);
}

#line 1239 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& name, const libbirch::DefaultArray<birch::type::Integer,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1239 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1239);
  #line 1240 "src/data/Buffer.birch"
  libbirch_line_(1240);
  #line 1240 "src/data/Buffer.birch"
  this_()->setIntegerVector(name, value, handler_);
}

#line 1249 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& name, const libbirch::DefaultArray<birch::type::Real,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1249 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1249);
  #line 1250 "src/data/Buffer.birch"
  libbirch_line_(1250);
  #line 1250 "src/data/Buffer.birch"
  this_()->setRealVector(name, value, handler_);
}

#line 1259 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& name, const libbirch::DefaultArray<libbirch::Lazy<libbirch::Shared<birch::type::Object>>,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1259 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1259);
  #line 1260 "src/data/Buffer.birch"
  libbirch_line_(1260);
  #line 1260 "src/data/Buffer.birch"
  this_()->setObjectVector(name, value, handler_);
}

#line 1269 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& name, const libbirch::DefaultArray<birch::type::Boolean,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1269 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1269);
  #line 1270 "src/data/Buffer.birch"
  libbirch_line_(1270);
  #line 1270 "src/data/Buffer.birch"
  this_()->setBooleanMatrix(name, value, handler_);
}

#line 1279 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& name, const libbirch::DefaultArray<birch::type::Integer,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1279 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1279);
  #line 1280 "src/data/Buffer.birch"
  libbirch_line_(1280);
  #line 1280 "src/data/Buffer.birch"
  this_()->setIntegerMatrix(name, value, handler_);
}

#line 1289 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& name, const libbirch::DefaultArray<birch::type::Real,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1289 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1289);
  #line 1290 "src/data/Buffer.birch"
  libbirch_line_(1290);
  #line 1290 "src/data/Buffer.birch"
  this_()->setRealMatrix(name, value, handler_);
}

#line 1299 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& name, const birch::type::LLT& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1299 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1299);
  #line 1300 "src/data/Buffer.birch"
  libbirch_line_(1300);
  #line 1300 "src/data/Buffer.birch"
  this_()->setLLT(name, value, handler_);
}

#line 1309 "src/data/Buffer.birch"
void birch::type::Buffer::set(const birch::type::String& name, const libbirch::DefaultArray<libbirch::Lazy<libbirch::Shared<birch::type::Object>>,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1309 "src/data/Buffer.birch"
  libbirch_function_("set", "src/data/Buffer.birch", 1309);
  #line 1310 "src/data/Buffer.birch"
  libbirch_line_(1310);
  #line 1310 "src/data/Buffer.birch"
  this_()->setObjectMatrix(name, value, handler_);
}

#line 4 "src/data/Buffer.birch"
birch::type::Buffer* birch::type::make_Buffer_() {
  #line 4 "src/data/Buffer.birch"
  return new birch::type::Buffer();
  #line 4 "src/data/Buffer.birch"
}

#line 1319 "src/data/Buffer.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> birch::Buffer(const libbirch::Lazy<libbirch::Shared<birch::type::Value>>& root, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1319 "src/data/Buffer.birch"
  libbirch_function_("Buffer", "src/data/Buffer.birch", 1319);
  #line 1320 "src/data/Buffer.birch"
  libbirch_line_(1320);
  #line 1320 "src/data/Buffer.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> o;
  #line 1321 "src/data/Buffer.birch"
  libbirch_line_(1321);
  #line 1321 "src/data/Buffer.birch"
  o->value = root;
  #line 1322 "src/data/Buffer.birch"
  libbirch_line_(1322);
  #line 1322 "src/data/Buffer.birch"
  return o;
}

#line 1328 "src/data/Buffer.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> birch::Buffer(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1328 "src/data/Buffer.birch"
  libbirch_function_("Buffer", "src/data/Buffer.birch", 1328);
  #line 1329 "src/data/Buffer.birch"
  libbirch_line_(1329);
  #line 1329 "src/data/Buffer.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> o;
  #line 1330 "src/data/Buffer.birch"
  libbirch_line_(1330);
  #line 1330 "src/data/Buffer.birch"
  return o;
}

#line 1 "src/data/Entry.birch"
birch::type::Entry::Entry(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/data/Entry.birch"
    super_type_(),
    #line 8 "src/data/Entry.birch"
    name(),
    #line 13 "src/data/Entry.birch"
    buffer() {
  //
}

#line 1 "src/data/Entry.birch"
birch::type::Entry* birch::type::make_Entry_() {
  #line 1 "src/data/Entry.birch"
  return new birch::type::Entry();
  #line 1 "src/data/Entry.birch"
}

#line 1 "src/data/IntegerValue.birch"
birch::type::IntegerValue::IntegerValue(const birch::type::Integer& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/data/IntegerValue.birch"
    super_type_(),
    #line 8 "src/data/IntegerValue.birch"
    value(value) {
  //
}

#line 10 "src/data/IntegerValue.birch"
void birch::type::IntegerValue::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Writer>>& writer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/data/IntegerValue.birch"
  libbirch_function_("accept", "src/data/IntegerValue.birch", 10);
  #line 11 "src/data/IntegerValue.birch"
  libbirch_line_(11);
  #line 11 "src/data/IntegerValue.birch"
  writer->visit(shared_from_this_(), handler_);
}

#line 14 "src/data/IntegerValue.birch"
birch::type::Boolean birch::type::IntegerValue::isScalar(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/data/IntegerValue.birch"
  libbirch_function_("isScalar", "src/data/IntegerValue.birch", 14);
  #line 15 "src/data/IntegerValue.birch"
  libbirch_line_(15);
  #line 15 "src/data/IntegerValue.birch"
  return true;
}

#line 18 "src/data/IntegerValue.birch"
libbirch::Optional<birch::type::Integer> birch::type::IntegerValue::getInteger(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/data/IntegerValue.birch"
  libbirch_function_("getInteger", "src/data/IntegerValue.birch", 18);
  #line 19 "src/data/IntegerValue.birch"
  libbirch_line_(19);
  #line 19 "src/data/IntegerValue.birch"
  return this_()->value;
}

#line 22 "src/data/IntegerValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,1>> birch::type::IntegerValue::getIntegerVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/data/IntegerValue.birch"
  libbirch_function_("getIntegerVector", "src/data/IntegerValue.birch", 22);
  #line 23 "src/data/IntegerValue.birch"
  libbirch_line_(23);
  #line 23 "src/data/IntegerValue.birch"
  return birch::vector(this_()->value, birch::type::Integer(1), handler_);
}

#line 26 "src/data/IntegerValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,2>> birch::type::IntegerValue::getIntegerMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/data/IntegerValue.birch"
  libbirch_function_("getIntegerMatrix", "src/data/IntegerValue.birch", 26);
  #line 27 "src/data/IntegerValue.birch"
  libbirch_line_(27);
  #line 27 "src/data/IntegerValue.birch"
  return birch::matrix(this_()->value, birch::type::Integer(1), birch::type::Integer(1), handler_);
}

#line 30 "src/data/IntegerValue.birch"
libbirch::Optional<birch::type::Real> birch::type::IntegerValue::getReal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/data/IntegerValue.birch"
  libbirch_function_("getReal", "src/data/IntegerValue.birch", 30);
  #line 31 "src/data/IntegerValue.birch"
  libbirch_line_(31);
  #line 31 "src/data/IntegerValue.birch"
  return birch::Real(this_()->value, handler_);
}

#line 34 "src/data/IntegerValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::IntegerValue::getRealVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/data/IntegerValue.birch"
  libbirch_function_("getRealVector", "src/data/IntegerValue.birch", 34);
  #line 35 "src/data/IntegerValue.birch"
  libbirch_line_(35);
  #line 35 "src/data/IntegerValue.birch"
  return birch::vector(birch::Real(this_()->value, handler_), birch::type::Integer(1), handler_);
}

#line 38 "src/data/IntegerValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::IntegerValue::getRealMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "src/data/IntegerValue.birch"
  libbirch_function_("getRealMatrix", "src/data/IntegerValue.birch", 38);
  #line 39 "src/data/IntegerValue.birch"
  libbirch_line_(39);
  #line 39 "src/data/IntegerValue.birch"
  return birch::matrix(birch::Real(this_()->value, handler_), birch::type::Integer(1), birch::type::Integer(1), handler_);
}

#line 1 "src/data/IntegerMatrixValue.birch"
birch::type::IntegerMatrixValue::IntegerMatrixValue(const libbirch::DefaultArray<birch::type::Integer,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/data/IntegerMatrixValue.birch"
    super_type_(),
    #line 8 "src/data/IntegerMatrixValue.birch"
    value(value) {
  //
}

#line 10 "src/data/IntegerMatrixValue.birch"
void birch::type::IntegerMatrixValue::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Writer>>& writer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/data/IntegerMatrixValue.birch"
  libbirch_function_("accept", "src/data/IntegerMatrixValue.birch", 10);
  #line 11 "src/data/IntegerMatrixValue.birch"
  libbirch_line_(11);
  #line 11 "src/data/IntegerMatrixValue.birch"
  writer->visit(shared_from_this_(), handler_);
}

#line 14 "src/data/IntegerMatrixValue.birch"
birch::type::Boolean birch::type::IntegerMatrixValue::isArray(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/data/IntegerMatrixValue.birch"
  libbirch_function_("isArray", "src/data/IntegerMatrixValue.birch", 14);
  #line 15 "src/data/IntegerMatrixValue.birch"
  libbirch_line_(15);
  #line 15 "src/data/IntegerMatrixValue.birch"
  return true;
}

#line 18 "src/data/IntegerMatrixValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,2>> birch::type::IntegerMatrixValue::getIntegerMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/data/IntegerMatrixValue.birch"
  libbirch_function_("getIntegerMatrix", "src/data/IntegerMatrixValue.birch", 18);
  #line 19 "src/data/IntegerMatrixValue.birch"
  libbirch_line_(19);
  #line 19 "src/data/IntegerMatrixValue.birch"
  return this_()->value;
}

#line 22 "src/data/IntegerMatrixValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::IntegerMatrixValue::getRealMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/data/IntegerMatrixValue.birch"
  libbirch_function_("getRealMatrix", "src/data/IntegerMatrixValue.birch", 22);
  #line 23 "src/data/IntegerMatrixValue.birch"
  libbirch_line_(23);
  #line 23 "src/data/IntegerMatrixValue.birch"
  libbirch::DefaultArray<birch::type::Real,2> value = this_()->value;
  #line 24 "src/data/IntegerMatrixValue.birch"
  libbirch_line_(24);
  #line 24 "src/data/IntegerMatrixValue.birch"
  return value;
}

#line 1 "src/data/IntegerVectorValue.birch"
birch::type::IntegerVectorValue::IntegerVectorValue(const libbirch::DefaultArray<birch::type::Integer,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/data/IntegerVectorValue.birch"
    super_type_(),
    #line 8 "src/data/IntegerVectorValue.birch"
    value(value) {
  //
}

#line 10 "src/data/IntegerVectorValue.birch"
void birch::type::IntegerVectorValue::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Writer>>& writer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/data/IntegerVectorValue.birch"
  libbirch_function_("accept", "src/data/IntegerVectorValue.birch", 10);
  #line 11 "src/data/IntegerVectorValue.birch"
  libbirch_line_(11);
  #line 11 "src/data/IntegerVectorValue.birch"
  writer->visit(shared_from_this_(), handler_);
}

#line 14 "src/data/IntegerVectorValue.birch"
birch::type::Boolean birch::type::IntegerVectorValue::isArray(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/data/IntegerVectorValue.birch"
  libbirch_function_("isArray", "src/data/IntegerVectorValue.birch", 14);
  #line 15 "src/data/IntegerVectorValue.birch"
  libbirch_line_(15);
  #line 15 "src/data/IntegerVectorValue.birch"
  return true;
}

#line 18 "src/data/IntegerVectorValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,1>> birch::type::IntegerVectorValue::getIntegerVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/data/IntegerVectorValue.birch"
  libbirch_function_("getIntegerVector", "src/data/IntegerVectorValue.birch", 18);
  #line 19 "src/data/IntegerVectorValue.birch"
  libbirch_line_(19);
  #line 19 "src/data/IntegerVectorValue.birch"
  return this_()->value;
}

#line 22 "src/data/IntegerVectorValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,2>> birch::type::IntegerVectorValue::getIntegerMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/data/IntegerVectorValue.birch"
  libbirch_function_("getIntegerMatrix", "src/data/IntegerVectorValue.birch", 22);
  #line 23 "src/data/IntegerVectorValue.birch"
  libbirch_line_(23);
  #line 23 "src/data/IntegerVectorValue.birch"
  return birch::column(this_()->value, handler_);
}

#line 26 "src/data/IntegerVectorValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::IntegerVectorValue::getRealVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/data/IntegerVectorValue.birch"
  libbirch_function_("getRealVector", "src/data/IntegerVectorValue.birch", 26);
  #line 27 "src/data/IntegerVectorValue.birch"
  libbirch_line_(27);
  #line 27 "src/data/IntegerVectorValue.birch"
  libbirch::DefaultArray<birch::type::Real,1> value = this_()->value;
  #line 28 "src/data/IntegerVectorValue.birch"
  libbirch_line_(28);
  #line 28 "src/data/IntegerVectorValue.birch"
  return value;
}

#line 31 "src/data/IntegerVectorValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::IntegerVectorValue::getRealMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "src/data/IntegerVectorValue.birch"
  libbirch_function_("getRealMatrix", "src/data/IntegerVectorValue.birch", 31);
  #line 32 "src/data/IntegerVectorValue.birch"
  libbirch_line_(32);
  #line 32 "src/data/IntegerVectorValue.birch"
  libbirch::DefaultArray<birch::type::Real,1> value = this_()->value;
  #line 33 "src/data/IntegerVectorValue.birch"
  libbirch_line_(33);
  #line 33 "src/data/IntegerVectorValue.birch"
  return birch::column(value, handler_);
}

#line 1 "src/data/NilValue.birch"
birch::type::NilValue::NilValue(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/data/NilValue.birch"
    super_type_() {
  //
}

#line 5 "src/data/NilValue.birch"
void birch::type::NilValue::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Writer>>& writer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 5 "src/data/NilValue.birch"
  libbirch_function_("accept", "src/data/NilValue.birch", 5);
  #line 6 "src/data/NilValue.birch"
  libbirch_line_(6);
  #line 6 "src/data/NilValue.birch"
  writer->visit(shared_from_this_(), handler_);
}

#line 9 "src/data/NilValue.birch"
birch::type::Boolean birch::type::NilValue::isScalar(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/data/NilValue.birch"
  libbirch_function_("isScalar", "src/data/NilValue.birch", 9);
  #line 10 "src/data/NilValue.birch"
  libbirch_line_(10);
  #line 10 "src/data/NilValue.birch"
  return true;
}

#line 1 "src/data/NilValue.birch"
birch::type::NilValue* birch::type::make_NilValue_() {
  #line 1 "src/data/NilValue.birch"
  return new birch::type::NilValue();
  #line 1 "src/data/NilValue.birch"
}

#line 1 "src/data/ObjectValue.birch"
birch::type::ObjectValue::ObjectValue(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/data/ObjectValue.birch"
    super_type_(),
    #line 10 "src/data/ObjectValue.birch"
    entries() {
  //
}

#line 12 "src/data/ObjectValue.birch"
void birch::type::ObjectValue::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Writer>>& writer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 12 "src/data/ObjectValue.birch"
  libbirch_function_("accept", "src/data/ObjectValue.birch", 12);
  #line 13 "src/data/ObjectValue.birch"
  libbirch_line_(13);
  #line 13 "src/data/ObjectValue.birch"
  writer->visit(shared_from_this_(), handler_);
}

#line 16 "src/data/ObjectValue.birch"
birch::type::Boolean birch::type::ObjectValue::isObject(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/data/ObjectValue.birch"
  libbirch_function_("isObject", "src/data/ObjectValue.birch", 16);
  #line 17 "src/data/ObjectValue.birch"
  libbirch_line_(17);
  #line 17 "src/data/ObjectValue.birch"
  return true;
}

#line 20 "src/data/ObjectValue.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>> birch::type::ObjectValue::getChild(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/data/ObjectValue.birch"
  libbirch_function_("getChild", "src/data/ObjectValue.birch", 20);
  #line 21 "src/data/ObjectValue.birch"
  libbirch_line_(21);
  #line 21 "src/data/ObjectValue.birch"
  auto iter = this_()->entries->walk(handler_);
  #line 22 "src/data/ObjectValue.birch"
  libbirch_line_(22);
  #line 22 "src/data/ObjectValue.birch"
  while (iter->hasNext(handler_)) {
    #line 23 "src/data/ObjectValue.birch"
    libbirch_line_(23);
    #line 23 "src/data/ObjectValue.birch"
    auto entry = iter->next(handler_);
    #line 24 "src/data/ObjectValue.birch"
    libbirch_line_(24);
    #line 24 "src/data/ObjectValue.birch"
    if (entry->name == name) {
      #line 25 "src/data/ObjectValue.birch"
      libbirch_line_(25);
      #line 25 "src/data/ObjectValue.birch"
      return entry->buffer;
    }
  }
  #line 28 "src/data/ObjectValue.birch"
  libbirch_line_(28);
  #line 28 "src/data/ObjectValue.birch"
  return libbirch::nil;
}

#line 31 "src/data/ObjectValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> birch::type::ObjectValue::setChild(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "src/data/ObjectValue.birch"
  libbirch_function_("setChild", "src/data/ObjectValue.birch", 31);
  #line 32 "src/data/ObjectValue.birch"
  libbirch_line_(32);
  #line 32 "src/data/ObjectValue.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> buffer;
  #line 33 "src/data/ObjectValue.birch"
  libbirch_line_(33);
  #line 33 "src/data/ObjectValue.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Entry>> entry;
  #line 34 "src/data/ObjectValue.birch"
  libbirch_line_(34);
  #line 34 "src/data/ObjectValue.birch"
  entry->name = name;
  #line 35 "src/data/ObjectValue.birch"
  libbirch_line_(35);
  #line 35 "src/data/ObjectValue.birch"
  entry->buffer = buffer;
  #line 36 "src/data/ObjectValue.birch"
  libbirch_line_(36);
  #line 36 "src/data/ObjectValue.birch"
  this_()->entries->pushBack(entry, handler_);
  #line 37 "src/data/ObjectValue.birch"
  libbirch_line_(37);
  #line 37 "src/data/ObjectValue.birch"
  return buffer;
}

#line 1 "src/data/ObjectValue.birch"
birch::type::ObjectValue* birch::type::make_ObjectValue_() {
  #line 1 "src/data/ObjectValue.birch"
  return new birch::type::ObjectValue();
  #line 1 "src/data/ObjectValue.birch"
}

#line 41 "src/data/ObjectValue.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ObjectValue>> birch::ObjectValue(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "src/data/ObjectValue.birch"
  libbirch_function_("ObjectValue", "src/data/ObjectValue.birch", 41);
  #line 42 "src/data/ObjectValue.birch"
  libbirch_line_(42);
  #line 42 "src/data/ObjectValue.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::ObjectValue>>>(handler_);
}

#line 1 "src/data/RealValue.birch"
birch::type::RealValue::RealValue(const birch::type::Real& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/data/RealValue.birch"
    super_type_(),
    #line 8 "src/data/RealValue.birch"
    value(value) {
  //
}

#line 10 "src/data/RealValue.birch"
void birch::type::RealValue::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Writer>>& writer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/data/RealValue.birch"
  libbirch_function_("accept", "src/data/RealValue.birch", 10);
  #line 11 "src/data/RealValue.birch"
  libbirch_line_(11);
  #line 11 "src/data/RealValue.birch"
  writer->visit(shared_from_this_(), handler_);
}

#line 14 "src/data/RealValue.birch"
birch::type::Boolean birch::type::RealValue::isScalar(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/data/RealValue.birch"
  libbirch_function_("isScalar", "src/data/RealValue.birch", 14);
  #line 15 "src/data/RealValue.birch"
  libbirch_line_(15);
  #line 15 "src/data/RealValue.birch"
  return true;
}

#line 18 "src/data/RealValue.birch"
libbirch::Optional<birch::type::Real> birch::type::RealValue::getReal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/data/RealValue.birch"
  libbirch_function_("getReal", "src/data/RealValue.birch", 18);
  #line 19 "src/data/RealValue.birch"
  libbirch_line_(19);
  #line 19 "src/data/RealValue.birch"
  return this_()->value;
}

#line 22 "src/data/RealValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::RealValue::getRealVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/data/RealValue.birch"
  libbirch_function_("getRealVector", "src/data/RealValue.birch", 22);
  #line 23 "src/data/RealValue.birch"
  libbirch_line_(23);
  #line 23 "src/data/RealValue.birch"
  return birch::vector(this_()->value, birch::type::Integer(1), handler_);
}

#line 26 "src/data/RealValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::RealValue::getRealMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/data/RealValue.birch"
  libbirch_function_("getRealMatrix", "src/data/RealValue.birch", 26);
  #line 27 "src/data/RealValue.birch"
  libbirch_line_(27);
  #line 27 "src/data/RealValue.birch"
  return birch::matrix(this_()->value, birch::type::Integer(1), birch::type::Integer(1), handler_);
}

#line 1 "src/data/RealMatrixValue.birch"
birch::type::RealMatrixValue::RealMatrixValue(const libbirch::DefaultArray<birch::type::Real,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/data/RealMatrixValue.birch"
    super_type_(),
    #line 8 "src/data/RealMatrixValue.birch"
    value(value) {
  //
}

#line 10 "src/data/RealMatrixValue.birch"
void birch::type::RealMatrixValue::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Writer>>& writer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/data/RealMatrixValue.birch"
  libbirch_function_("accept", "src/data/RealMatrixValue.birch", 10);
  #line 11 "src/data/RealMatrixValue.birch"
  libbirch_line_(11);
  #line 11 "src/data/RealMatrixValue.birch"
  writer->visit(shared_from_this_(), handler_);
}

#line 14 "src/data/RealMatrixValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::RealMatrixValue::getRealMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/data/RealMatrixValue.birch"
  libbirch_function_("getRealMatrix", "src/data/RealMatrixValue.birch", 14);
  #line 15 "src/data/RealMatrixValue.birch"
  libbirch_line_(15);
  #line 15 "src/data/RealMatrixValue.birch"
  return this_()->value;
}

#line 18 "src/data/RealMatrixValue.birch"
birch::type::Boolean birch::type::RealMatrixValue::isArray(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/data/RealMatrixValue.birch"
  libbirch_function_("isArray", "src/data/RealMatrixValue.birch", 18);
  #line 19 "src/data/RealMatrixValue.birch"
  libbirch_line_(19);
  #line 19 "src/data/RealMatrixValue.birch"
  return true;
}

#line 1 "src/data/RealVectorValue.birch"
birch::type::RealVectorValue::RealVectorValue(const libbirch::DefaultArray<birch::type::Real,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/data/RealVectorValue.birch"
    super_type_(),
    #line 8 "src/data/RealVectorValue.birch"
    value(value) {
  //
}

#line 10 "src/data/RealVectorValue.birch"
void birch::type::RealVectorValue::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Writer>>& writer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/data/RealVectorValue.birch"
  libbirch_function_("accept", "src/data/RealVectorValue.birch", 10);
  #line 11 "src/data/RealVectorValue.birch"
  libbirch_line_(11);
  #line 11 "src/data/RealVectorValue.birch"
  writer->visit(shared_from_this_(), handler_);
}

#line 14 "src/data/RealVectorValue.birch"
birch::type::Boolean birch::type::RealVectorValue::isArray(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/data/RealVectorValue.birch"
  libbirch_function_("isArray", "src/data/RealVectorValue.birch", 14);
  #line 15 "src/data/RealVectorValue.birch"
  libbirch_line_(15);
  #line 15 "src/data/RealVectorValue.birch"
  return true;
}

#line 18 "src/data/RealVectorValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::RealVectorValue::getRealVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/data/RealVectorValue.birch"
  libbirch_function_("getRealVector", "src/data/RealVectorValue.birch", 18);
  #line 19 "src/data/RealVectorValue.birch"
  libbirch_line_(19);
  #line 19 "src/data/RealVectorValue.birch"
  return this_()->value;
}

#line 22 "src/data/RealVectorValue.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::RealVectorValue::getRealMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/data/RealVectorValue.birch"
  libbirch_function_("getRealMatrix", "src/data/RealVectorValue.birch", 22);
  #line 23 "src/data/RealVectorValue.birch"
  libbirch_line_(23);
  #line 23 "src/data/RealVectorValue.birch"
  return birch::column(this_()->value, handler_);
}

#line 1 "src/data/StringValue.birch"
birch::type::StringValue::StringValue(const birch::type::String& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/data/StringValue.birch"
    super_type_(),
    #line 8 "src/data/StringValue.birch"
    value(value) {
  //
}

#line 10 "src/data/StringValue.birch"
void birch::type::StringValue::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Writer>>& writer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/data/StringValue.birch"
  libbirch_function_("accept", "src/data/StringValue.birch", 10);
  #line 11 "src/data/StringValue.birch"
  libbirch_line_(11);
  #line 11 "src/data/StringValue.birch"
  writer->visit(shared_from_this_(), handler_);
}

#line 14 "src/data/StringValue.birch"
birch::type::Boolean birch::type::StringValue::isScalar(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/data/StringValue.birch"
  libbirch_function_("isScalar", "src/data/StringValue.birch", 14);
  #line 15 "src/data/StringValue.birch"
  libbirch_line_(15);
  #line 15 "src/data/StringValue.birch"
  return true;
}

#line 18 "src/data/StringValue.birch"
libbirch::Optional<birch::type::String> birch::type::StringValue::getString(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/data/StringValue.birch"
  libbirch_function_("getString", "src/data/StringValue.birch", 18);
  #line 19 "src/data/StringValue.birch"
  libbirch_line_(19);
  #line 19 "src/data/StringValue.birch"
  return this_()->value;
}

#line 4 "src/data/Value.birch"
birch::type::Value::Value(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/data/Value.birch"
    super_type_() {
  //
}

#line 13 "src/data/Value.birch"
birch::type::Boolean birch::type::Value::isObject(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 13 "src/data/Value.birch"
  libbirch_function_("isObject", "src/data/Value.birch", 13);
  #line 14 "src/data/Value.birch"
  libbirch_line_(14);
  #line 14 "src/data/Value.birch"
  return false;
}

#line 20 "src/data/Value.birch"
birch::type::Boolean birch::type::Value::isArray(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/data/Value.birch"
  libbirch_function_("isArray", "src/data/Value.birch", 20);
  #line 21 "src/data/Value.birch"
  libbirch_line_(21);
  #line 21 "src/data/Value.birch"
  return false;
}

#line 27 "src/data/Value.birch"
birch::type::Boolean birch::type::Value::isScalar(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/data/Value.birch"
  libbirch_function_("isScalar", "src/data/Value.birch", 27);
  #line 28 "src/data/Value.birch"
  libbirch_line_(28);
  #line 28 "src/data/Value.birch"
  return false;
}

#line 34 "src/data/Value.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>> birch::type::Value::getChild(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/data/Value.birch"
  libbirch_function_("getChild", "src/data/Value.birch", 34);
  #line 35 "src/data/Value.birch"
  libbirch_line_(35);
  #line 35 "src/data/Value.birch"
  return libbirch::nil;
}

#line 41 "src/data/Value.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> birch::type::Value::setChild(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "src/data/Value.birch"
  libbirch_function_("setChild", "src/data/Value.birch", 41);
  #line 42 "src/data/Value.birch"
  libbirch_line_(42);
  #line 42 "src/data/Value.birch"
  birch::error(birch::type::String("not an object"), handler_);
  #line 43 "src/data/Value.birch"
  libbirch_line_(43);
  #line 43 "src/data/Value.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> buf;
  #line 44 "src/data/Value.birch"
  libbirch_line_(44);
  #line 44 "src/data/Value.birch"
  return buf;
}

#line 52 "src/data/Value.birch"
birch::type::Integer birch::type::Value::size(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "src/data/Value.birch"
  libbirch_function_("size", "src/data/Value.birch", 52);
  #line 53 "src/data/Value.birch"
  libbirch_line_(53);
  #line 53 "src/data/Value.birch"
  return birch::type::Integer(1);
}

#line 59 "src/data/Value.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Iterator<libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>>>> birch::type::Value::walk(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/data/Value.birch"
  libbirch_function_("walk", "src/data/Value.birch", 59);
  #line 60 "src/data/Value.birch"
  libbirch_line_(60);
  #line 60 "src/data/Value.birch"
  birch::error(birch::type::String("not an array"), handler_);
  #line 61 "src/data/Value.birch"
  libbirch_line_(61);
  #line 61 "src/data/Value.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Array<libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>>>> o;
  #line 62 "src/data/Value.birch"
  libbirch_line_(62);
  #line 62 "src/data/Value.birch"
  return o->walk(handler_);
}

#line 68 "src/data/Value.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> birch::type::Value::push(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 68 "src/data/Value.birch"
  libbirch_function_("push", "src/data/Value.birch", 68);
  #line 69 "src/data/Value.birch"
  libbirch_line_(69);
  #line 69 "src/data/Value.birch"
  birch::error(birch::type::String("not an array"), handler_);
  #line 70 "src/data/Value.birch"
  libbirch_line_(70);
  #line 70 "src/data/Value.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> o;
  #line 71 "src/data/Value.birch"
  libbirch_line_(71);
  #line 71 "src/data/Value.birch"
  return o;
}

#line 77 "src/data/Value.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::ObjectValue>>> birch::type::Value::getObject(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 77 "src/data/Value.birch"
  libbirch_function_("getObject", "src/data/Value.birch", 77);
  #line 78 "src/data/Value.birch"
  libbirch_line_(78);
  #line 78 "src/data/Value.birch"
  return libbirch::nil;
}

#line 84 "src/data/Value.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::ArrayValue>>> birch::type::Value::getArray(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 84 "src/data/Value.birch"
  libbirch_function_("getArray", "src/data/Value.birch", 84);
  #line 85 "src/data/Value.birch"
  libbirch_line_(85);
  #line 85 "src/data/Value.birch"
  return libbirch::nil;
}

#line 93 "src/data/Value.birch"
libbirch::Optional<birch::type::Boolean> birch::type::Value::getBoolean(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 93 "src/data/Value.birch"
  libbirch_function_("getBoolean", "src/data/Value.birch", 93);
  #line 94 "src/data/Value.birch"
  libbirch_line_(94);
  #line 94 "src/data/Value.birch"
  return libbirch::nil;
}

#line 102 "src/data/Value.birch"
libbirch::Optional<birch::type::Integer> birch::type::Value::getInteger(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 102 "src/data/Value.birch"
  libbirch_function_("getInteger", "src/data/Value.birch", 102);
  #line 103 "src/data/Value.birch"
  libbirch_line_(103);
  #line 103 "src/data/Value.birch"
  return libbirch::nil;
}

#line 111 "src/data/Value.birch"
libbirch::Optional<birch::type::Real> birch::type::Value::getReal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 111 "src/data/Value.birch"
  libbirch_function_("getReal", "src/data/Value.birch", 111);
  #line 112 "src/data/Value.birch"
  libbirch_line_(112);
  #line 112 "src/data/Value.birch"
  return libbirch::nil;
}

#line 120 "src/data/Value.birch"
libbirch::Optional<birch::type::String> birch::type::Value::getString(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 120 "src/data/Value.birch"
  libbirch_function_("getString", "src/data/Value.birch", 120);
  #line 121 "src/data/Value.birch"
  libbirch_line_(121);
  #line 121 "src/data/Value.birch"
  return libbirch::nil;
}

#line 130 "src/data/Value.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,1>> birch::type::Value::getBooleanVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 130 "src/data/Value.birch"
  libbirch_function_("getBooleanVector", "src/data/Value.birch", 130);
  #line 131 "src/data/Value.birch"
  libbirch_line_(131);
  #line 131 "src/data/Value.birch"
  return libbirch::nil;
}

#line 140 "src/data/Value.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,1>> birch::type::Value::getIntegerVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 140 "src/data/Value.birch"
  libbirch_function_("getIntegerVector", "src/data/Value.birch", 140);
  #line 141 "src/data/Value.birch"
  libbirch_line_(141);
  #line 141 "src/data/Value.birch"
  return libbirch::nil;
}

#line 150 "src/data/Value.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::Value::getRealVector(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 150 "src/data/Value.birch"
  libbirch_function_("getRealVector", "src/data/Value.birch", 150);
  #line 151 "src/data/Value.birch"
  libbirch_line_(151);
  #line 151 "src/data/Value.birch"
  return libbirch::nil;
}

#line 160 "src/data/Value.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Boolean,2>> birch::type::Value::getBooleanMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 160 "src/data/Value.birch"
  libbirch_function_("getBooleanMatrix", "src/data/Value.birch", 160);
  #line 161 "src/data/Value.birch"
  libbirch_line_(161);
  #line 161 "src/data/Value.birch"
  return libbirch::nil;
}

#line 170 "src/data/Value.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Integer,2>> birch::type::Value::getIntegerMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 170 "src/data/Value.birch"
  libbirch_function_("getIntegerMatrix", "src/data/Value.birch", 170);
  #line 171 "src/data/Value.birch"
  libbirch_line_(171);
  #line 171 "src/data/Value.birch"
  return libbirch::nil;
}

#line 180 "src/data/Value.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::Value::getRealMatrix(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 180 "src/data/Value.birch"
  libbirch_function_("getRealMatrix", "src/data/Value.birch", 180);
  #line 181 "src/data/Value.birch"
  libbirch_line_(181);
  #line 181 "src/data/Value.birch"
  return libbirch::nil;
}

