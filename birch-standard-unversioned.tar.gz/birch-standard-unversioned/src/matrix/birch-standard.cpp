#line 10 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::operator*(const birch::type::Real& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 10 "src/matrix/eigen.birch"
  libbirch_function_("*", "src/matrix/eigen.birch", 10);
  #line 11 "src/matrix/eigen.birch"

  return x*y.toEigen();
  }

#line 16 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::operator*(const libbirch::DefaultArray<birch::type::Real,1>& x, const birch::type::Real& y) {
  #line 16 "src/matrix/eigen.birch"
  libbirch_function_("*", "src/matrix/eigen.birch", 16);
  #line 17 "src/matrix/eigen.birch"

  return x.toEigen()*y;
  }

#line 22 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator*(const birch::type::Real& x, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 22 "src/matrix/eigen.birch"
  libbirch_function_("*", "src/matrix/eigen.birch", 22);
  #line 23 "src/matrix/eigen.birch"

  return x*Y.toEigen();
  }

#line 28 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator*(const libbirch::DefaultArray<birch::type::Real,2>& X, const birch::type::Real& y) {
  #line 28 "src/matrix/eigen.birch"
  libbirch_function_("*", "src/matrix/eigen.birch", 28);
  #line 29 "src/matrix/eigen.birch"

  return X.toEigen()*y;
  }

#line 34 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::operator/(const libbirch::DefaultArray<birch::type::Real,1>& x, const birch::type::Real& y) {
  #line 34 "src/matrix/eigen.birch"
  libbirch_function_("/", "src/matrix/eigen.birch", 34);
  #line 35 "src/matrix/eigen.birch"

  return x.toEigen()/y;
  }

#line 40 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator/(const libbirch::DefaultArray<birch::type::Real,2>& X, const birch::type::Real& y) {
  #line 40 "src/matrix/eigen.birch"
  libbirch_function_("/", "src/matrix/eigen.birch", 40);
  #line 41 "src/matrix/eigen.birch"

  return X.toEigen()/y;
  }

#line 46 "src/matrix/eigen.birch"
birch::type::Boolean birch::operator==(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 46 "src/matrix/eigen.birch"
  libbirch_function_("==", "src/matrix/eigen.birch", 46);
  #line 47 "src/matrix/eigen.birch"

  return x.toEigen() == y.toEigen();
  }

#line 52 "src/matrix/eigen.birch"
birch::type::Boolean birch::operator!=(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 52 "src/matrix/eigen.birch"
  libbirch_function_("!=", "src/matrix/eigen.birch", 52);
  #line 53 "src/matrix/eigen.birch"

  return x.toEigen() != y.toEigen();
  }

#line 58 "src/matrix/eigen.birch"
birch::type::Boolean birch::operator==(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 58 "src/matrix/eigen.birch"
  libbirch_function_("==", "src/matrix/eigen.birch", 58);
  #line 59 "src/matrix/eigen.birch"

  return X.toEigen() == Y.toEigen();
  }

#line 64 "src/matrix/eigen.birch"
birch::type::Boolean birch::operator!=(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 64 "src/matrix/eigen.birch"
  libbirch_function_("!=", "src/matrix/eigen.birch", 64);
  #line 65 "src/matrix/eigen.birch"

  return X.toEigen() != Y.toEigen();
  }

#line 70 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::operator-(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 70 "src/matrix/eigen.birch"
  libbirch_function_("-", "src/matrix/eigen.birch", 70);
  #line 71 "src/matrix/eigen.birch"

  return -x.toEigen();
  }

#line 76 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::operator+(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 76 "src/matrix/eigen.birch"
  libbirch_function_("+", "src/matrix/eigen.birch", 76);
  #line 77 "src/matrix/eigen.birch"
  libbirch_line_(77);
  #line 77 "src/matrix/eigen.birch"
  return x;
}

#line 80 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator-(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 80 "src/matrix/eigen.birch"
  libbirch_function_("-", "src/matrix/eigen.birch", 80);
  #line 81 "src/matrix/eigen.birch"

  return -X.toEigen();
  }

#line 86 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator+(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 86 "src/matrix/eigen.birch"
  libbirch_function_("+", "src/matrix/eigen.birch", 86);
  #line 87 "src/matrix/eigen.birch"
  libbirch_line_(87);
  #line 87 "src/matrix/eigen.birch"
  return X;
}

#line 90 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::operator+(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 90 "src/matrix/eigen.birch"
  libbirch_function_("+", "src/matrix/eigen.birch", 90);
  #line 91 "src/matrix/eigen.birch"

  return x.toEigen() + y.toEigen();
  }

#line 96 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::operator-(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 96 "src/matrix/eigen.birch"
  libbirch_function_("-", "src/matrix/eigen.birch", 96);
  #line 97 "src/matrix/eigen.birch"

  return x.toEigen() - y.toEigen();
  }

#line 102 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator+(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 102 "src/matrix/eigen.birch"
  libbirch_function_("+", "src/matrix/eigen.birch", 102);
  #line 103 "src/matrix/eigen.birch"

  return X.toEigen() + Y.toEigen();
  }

#line 108 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator-(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 108 "src/matrix/eigen.birch"
  libbirch_function_("-", "src/matrix/eigen.birch", 108);
  #line 109 "src/matrix/eigen.birch"

  return X.toEigen() - Y.toEigen();
  }

#line 114 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::operator*(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 114 "src/matrix/eigen.birch"
  libbirch_function_("*", "src/matrix/eigen.birch", 114);
  #line 115 "src/matrix/eigen.birch"

  return X.toEigen()*y.toEigen();
  }

#line 120 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator*(const libbirch::DefaultArray<birch::type::Real,1>& X, const libbirch::DefaultArray<birch::type::Real,2>& y) {
  #line 120 "src/matrix/eigen.birch"
  libbirch_function_("*", "src/matrix/eigen.birch", 120);
  #line 121 "src/matrix/eigen.birch"

  return X.toEigen()*y.toEigen();
  }

#line 126 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator*(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 126 "src/matrix/eigen.birch"
  libbirch_function_("*", "src/matrix/eigen.birch", 126);
  #line 127 "src/matrix/eigen.birch"

  return X.toEigen()*Y.toEigen();
  }

#line 132 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::operator*(const birch::type::Integer& x, const libbirch::DefaultArray<birch::type::Integer,1>& y) {
  #line 132 "src/matrix/eigen.birch"
  libbirch_function_("*", "src/matrix/eigen.birch", 132);
  #line 133 "src/matrix/eigen.birch"

  return x*y.toEigen();
  }

#line 138 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::operator*(const libbirch::DefaultArray<birch::type::Integer,1>& x, const birch::type::Integer& y) {
  #line 138 "src/matrix/eigen.birch"
  libbirch_function_("*", "src/matrix/eigen.birch", 138);
  #line 139 "src/matrix/eigen.birch"

  return x.toEigen()*y;
  }

#line 144 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator*(const birch::type::Integer& x, const libbirch::DefaultArray<birch::type::Integer,2>& Y) {
  #line 144 "src/matrix/eigen.birch"
  libbirch_function_("*", "src/matrix/eigen.birch", 144);
  #line 145 "src/matrix/eigen.birch"

  return x*Y.toEigen();
  }

#line 150 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator*(const libbirch::DefaultArray<birch::type::Integer,2>& X, const birch::type::Integer& y) {
  #line 150 "src/matrix/eigen.birch"
  libbirch_function_("*", "src/matrix/eigen.birch", 150);
  #line 151 "src/matrix/eigen.birch"

  return X.toEigen()*y;
  }

#line 156 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::operator/(const libbirch::DefaultArray<birch::type::Integer,1>& x, const birch::type::Integer& y) {
  #line 156 "src/matrix/eigen.birch"
  libbirch_function_("/", "src/matrix/eigen.birch", 156);
  #line 157 "src/matrix/eigen.birch"

  return x.toEigen()/y;
  }

#line 162 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator/(const libbirch::DefaultArray<birch::type::Integer,2>& X, const birch::type::Integer& y) {
  #line 162 "src/matrix/eigen.birch"
  libbirch_function_("/", "src/matrix/eigen.birch", 162);
  #line 163 "src/matrix/eigen.birch"

  return X.toEigen()/y;
  }

#line 168 "src/matrix/eigen.birch"
birch::type::Boolean birch::operator==(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::DefaultArray<birch::type::Integer,1>& y) {
  #line 168 "src/matrix/eigen.birch"
  libbirch_function_("==", "src/matrix/eigen.birch", 168);
  #line 169 "src/matrix/eigen.birch"

  return x.toEigen() == y.toEigen();
  }

#line 174 "src/matrix/eigen.birch"
birch::type::Boolean birch::operator!=(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::DefaultArray<birch::type::Integer,1>& y) {
  #line 174 "src/matrix/eigen.birch"
  libbirch_function_("!=", "src/matrix/eigen.birch", 174);
  #line 175 "src/matrix/eigen.birch"

  return x.toEigen() != y.toEigen();
  }

#line 180 "src/matrix/eigen.birch"
birch::type::Boolean birch::operator==(const libbirch::DefaultArray<birch::type::Integer,2>& X, const libbirch::DefaultArray<birch::type::Integer,2>& Y) {
  #line 180 "src/matrix/eigen.birch"
  libbirch_function_("==", "src/matrix/eigen.birch", 180);
  #line 181 "src/matrix/eigen.birch"

  return X.toEigen() == Y.toEigen();
  }

#line 186 "src/matrix/eigen.birch"
birch::type::Boolean birch::operator!=(const libbirch::DefaultArray<birch::type::Integer,2>& X, const libbirch::DefaultArray<birch::type::Integer,2>& Y) {
  #line 186 "src/matrix/eigen.birch"
  libbirch_function_("!=", "src/matrix/eigen.birch", 186);
  #line 187 "src/matrix/eigen.birch"

  return X.toEigen() != Y.toEigen();
  }

#line 192 "src/matrix/eigen.birch"
birch::type::Boolean birch::operator==(const birch::type::LLT& X, const birch::type::LLT& Y) {
  #line 192 "src/matrix/eigen.birch"
  libbirch_function_("==", "src/matrix/eigen.birch", 192);
  #line 193 "src/matrix/eigen.birch"

  return X.reconstructedMatrix() == Y.reconstructedMatrix();
  }

#line 198 "src/matrix/eigen.birch"
birch::type::Boolean birch::operator!=(const birch::type::LLT& X, const birch::type::LLT& Y) {
  #line 198 "src/matrix/eigen.birch"
  libbirch_function_("!=", "src/matrix/eigen.birch", 198);
  #line 199 "src/matrix/eigen.birch"

  return X.reconstructedMatrix() != Y.reconstructedMatrix();
  }

#line 204 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::operator-(const libbirch::DefaultArray<birch::type::Integer,1>& x) {
  #line 204 "src/matrix/eigen.birch"
  libbirch_function_("-", "src/matrix/eigen.birch", 204);
  #line 205 "src/matrix/eigen.birch"

  return -x.toEigen();
  }

#line 210 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::operator+(const libbirch::DefaultArray<birch::type::Integer,1>& x) {
  #line 210 "src/matrix/eigen.birch"
  libbirch_function_("+", "src/matrix/eigen.birch", 210);
  #line 211 "src/matrix/eigen.birch"
  libbirch_line_(211);
  #line 211 "src/matrix/eigen.birch"
  return x;
}

#line 214 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator-(const libbirch::DefaultArray<birch::type::Integer,2>& X) {
  #line 214 "src/matrix/eigen.birch"
  libbirch_function_("-", "src/matrix/eigen.birch", 214);
  #line 215 "src/matrix/eigen.birch"

  return -X.toEigen();
  }

#line 220 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator+(const libbirch::DefaultArray<birch::type::Integer,2>& X) {
  #line 220 "src/matrix/eigen.birch"
  libbirch_function_("+", "src/matrix/eigen.birch", 220);
  #line 221 "src/matrix/eigen.birch"
  libbirch_line_(221);
  #line 221 "src/matrix/eigen.birch"
  return X;
}

#line 224 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::operator+(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::DefaultArray<birch::type::Integer,1>& y) {
  #line 224 "src/matrix/eigen.birch"
  libbirch_function_("+", "src/matrix/eigen.birch", 224);
  #line 225 "src/matrix/eigen.birch"

  return x.toEigen() + y.toEigen();
  }

#line 230 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::operator-(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::DefaultArray<birch::type::Integer,1>& y) {
  #line 230 "src/matrix/eigen.birch"
  libbirch_function_("-", "src/matrix/eigen.birch", 230);
  #line 231 "src/matrix/eigen.birch"

  return x.toEigen() - y.toEigen();
  }

#line 236 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator+(const libbirch::DefaultArray<birch::type::Integer,2>& X, const libbirch::DefaultArray<birch::type::Integer,2>& Y) {
  #line 236 "src/matrix/eigen.birch"
  libbirch_function_("+", "src/matrix/eigen.birch", 236);
  #line 237 "src/matrix/eigen.birch"

  return X.toEigen() + Y.toEigen();
  }

#line 242 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator-(const libbirch::DefaultArray<birch::type::Integer,2>& X, const libbirch::DefaultArray<birch::type::Integer,2>& Y) {
  #line 242 "src/matrix/eigen.birch"
  libbirch_function_("-", "src/matrix/eigen.birch", 242);
  #line 243 "src/matrix/eigen.birch"

  return X.toEigen() - Y.toEigen();
  }

#line 248 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::operator*(const libbirch::DefaultArray<birch::type::Integer,2>& X, const libbirch::DefaultArray<birch::type::Integer,1>& y) {
  #line 248 "src/matrix/eigen.birch"
  libbirch_function_("*", "src/matrix/eigen.birch", 248);
  #line 249 "src/matrix/eigen.birch"

  return X.toEigen()*y.toEigen();
  }

#line 254 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator*(const libbirch::DefaultArray<birch::type::Integer,1>& X, const libbirch::DefaultArray<birch::type::Integer,2>& y) {
  #line 254 "src/matrix/eigen.birch"
  libbirch_function_("*", "src/matrix/eigen.birch", 254);
  #line 255 "src/matrix/eigen.birch"

  return X.toEigen()*y.toEigen();
  }

#line 260 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator*(const libbirch::DefaultArray<birch::type::Integer,2>& X, const libbirch::DefaultArray<birch::type::Integer,2>& Y) {
  #line 260 "src/matrix/eigen.birch"
  libbirch_function_("*", "src/matrix/eigen.birch", 260);
  #line 261 "src/matrix/eigen.birch"

  return X.toEigen()*Y.toEigen();
  }

#line 269 "src/matrix/eigen.birch"
birch::type::Real birch::dot(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 269 "src/matrix/eigen.birch"
  libbirch_function_("dot", "src/matrix/eigen.birch", 269);
  #line 270 "src/matrix/eigen.birch"

  return x.toEigen().squaredNorm();
  }

#line 278 "src/matrix/eigen.birch"
birch::type::Real birch::dot(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 278 "src/matrix/eigen.birch"
  libbirch_function_("dot", "src/matrix/eigen.birch", 278);
  #line 279 "src/matrix/eigen.birch"

  return x.toEigen().dot(y.toEigen());
  }

#line 288 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::dot(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 288 "src/matrix/eigen.birch"
  libbirch_function_("dot", "src/matrix/eigen.birch", 288);
  #line 289 "src/matrix/eigen.birch"

  return Y.toEigen().transpose()*x.toEigen();
  }

#line 297 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::outer(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 297 "src/matrix/eigen.birch"
  libbirch_function_("outer", "src/matrix/eigen.birch", 297);
  #line 298 "src/matrix/eigen.birch"

  auto y = x.toEigen();
  return y*y.transpose();
  }

#line 307 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::outer(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 307 "src/matrix/eigen.birch"
  libbirch_function_("outer", "src/matrix/eigen.birch", 307);
  #line 308 "src/matrix/eigen.birch"

  return x.toEigen()*y.toEigen().transpose();
  }

#line 316 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::outer(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 316 "src/matrix/eigen.birch"
  libbirch_function_("outer", "src/matrix/eigen.birch", 316);
  #line 317 "src/matrix/eigen.birch"

  auto Y = X.toEigen();
  return Y*Y.transpose();
  }

#line 326 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::outer(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 326 "src/matrix/eigen.birch"
  libbirch_function_("outer", "src/matrix/eigen.birch", 326);
  #line 327 "src/matrix/eigen.birch"

  return X.toEigen()*Y.toEigen().transpose();
  }

#line 335 "src/matrix/eigen.birch"
birch::type::Real birch::norm(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 335 "src/matrix/eigen.birch"
  libbirch_function_("norm", "src/matrix/eigen.birch", 335);
  #line 336 "src/matrix/eigen.birch"

  return x.toEigen().norm();
  }

#line 344 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::sqrt(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 344 "src/matrix/eigen.birch"
  libbirch_function_("sqrt", "src/matrix/eigen.birch", 344);
  #line 345 "src/matrix/eigen.birch"

  return x.toEigen().array().sqrt().matrix();
  }

#line 353 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::transpose(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 353 "src/matrix/eigen.birch"
  libbirch_function_("transpose", "src/matrix/eigen.birch", 353);
  #line 354 "src/matrix/eigen.birch"

  return X.toEigen().transpose();
  }

#line 362 "src/matrix/eigen.birch"
birch::type::LLT birch::transpose(const birch::type::LLT& S) {
  #line 362 "src/matrix/eigen.birch"
  libbirch_function_("transpose", "src/matrix/eigen.birch", 362);
  #line 363 "src/matrix/eigen.birch"
  libbirch_line_(363);
  #line 363 "src/matrix/eigen.birch"
  return S;
}

#line 369 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::transpose(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 369 "src/matrix/eigen.birch"
  libbirch_function_("transpose", "src/matrix/eigen.birch", 369);
  #line 370 "src/matrix/eigen.birch"

  return x.toEigen().transpose();
  }

#line 378 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::diagonal(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 378 "src/matrix/eigen.birch"
  libbirch_function_("diagonal", "src/matrix/eigen.birch", 378);
  #line 379 "src/matrix/eigen.birch"

  return x.toEigen().asDiagonal();
  }

#line 387 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::diagonal(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 387 "src/matrix/eigen.birch"
  libbirch_function_("diagonal", "src/matrix/eigen.birch", 387);
  #line 388 "src/matrix/eigen.birch"

  return X.toEigen().diagonal();
  }

#line 396 "src/matrix/eigen.birch"
birch::type::Real birch::trace(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 396 "src/matrix/eigen.birch"
  libbirch_function_("trace", "src/matrix/eigen.birch", 396);
  #line 397 "src/matrix/eigen.birch"

  return X.toEigen().trace();
  }

#line 405 "src/matrix/eigen.birch"
birch::type::Real birch::trace(const birch::type::LLT& S) {
  #line 405 "src/matrix/eigen.birch"
  libbirch_function_("trace", "src/matrix/eigen.birch", 405);
  #line 406 "src/matrix/eigen.birch"

  return S.reconstructedMatrix().trace();
  }

#line 414 "src/matrix/eigen.birch"
birch::type::Real birch::det(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 414 "src/matrix/eigen.birch"
  libbirch_function_("det", "src/matrix/eigen.birch", 414);
  #line 415 "src/matrix/eigen.birch"

  return X.toEigen().determinant();
  }

#line 423 "src/matrix/eigen.birch"
birch::type::Real birch::ldet(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 423 "src/matrix/eigen.birch"
  libbirch_function_("ldet", "src/matrix/eigen.birch", 423);
  #line 424 "src/matrix/eigen.birch"

  return X.toEigen().householderQr().logAbsDeterminant();
  }

#line 432 "src/matrix/eigen.birch"
birch::type::Real birch::det(const birch::type::LLT& S) {
  #line 432 "src/matrix/eigen.birch"
  libbirch_function_("det", "src/matrix/eigen.birch", 432);
  #line 433 "src/matrix/eigen.birch"

  auto d = S.matrixL().determinant();
  return d*d;
  }

#line 442 "src/matrix/eigen.birch"
birch::type::Real birch::ldet(const birch::type::LLT& S) {
  #line 442 "src/matrix/eigen.birch"
  libbirch_function_("ldet", "src/matrix/eigen.birch", 442);
  #line 443 "src/matrix/eigen.birch"

  return 2.0*S.matrixL().nestedExpression().diagonal().array().log().sum();
  }

#line 451 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::inv(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 451 "src/matrix/eigen.birch"
  libbirch_function_("inv", "src/matrix/eigen.birch", 451);
  #line 452 "src/matrix/eigen.birch"

  return X.toEigen().inverse();
  }

#line 460 "src/matrix/eigen.birch"
birch::type::LLT birch::inv(const birch::type::LLT& S) {
  #line 460 "src/matrix/eigen.birch"
  libbirch_function_("inv", "src/matrix/eigen.birch", 460);
  #line 461 "src/matrix/eigen.birch"

  return S.solve(libbirch::EigenMatrix<birch::type::Real>::Identity(
      S.rows(), S.cols())).llt();
  }

#line 470 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::solve(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 470 "src/matrix/eigen.birch"
  libbirch_function_("solve", "src/matrix/eigen.birch", 470);
  #line 471 "src/matrix/eigen.birch"

  return X.toEigen().householderQr().solve(y.toEigen()).eval();
  }

#line 479 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::solve(const birch::type::LLT& S, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 479 "src/matrix/eigen.birch"
  libbirch_function_("solve", "src/matrix/eigen.birch", 479);
  #line 480 "src/matrix/eigen.birch"

  return S.solve(y.toEigen()).eval();
  }

#line 488 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::solve(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 488 "src/matrix/eigen.birch"
  libbirch_function_("solve", "src/matrix/eigen.birch", 488);
  #line 489 "src/matrix/eigen.birch"

  return X.toEigen().householderQr().solve(Y.toEigen()).eval();
  }

#line 497 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::solve(const birch::type::LLT& S, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 497 "src/matrix/eigen.birch"
  libbirch_function_("solve", "src/matrix/eigen.birch", 497);
  #line 498 "src/matrix/eigen.birch"

  return S.solve(Y.toEigen()).eval();
  }

#line 508 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::cholesky(const birch::type::LLT& S) {
  #line 508 "src/matrix/eigen.birch"
  libbirch_function_("cholesky", "src/matrix/eigen.birch", 508);
  #line 509 "src/matrix/eigen.birch"

  return S.matrixL();
  }

#line 517 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::hadamard(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 517 "src/matrix/eigen.birch"
  libbirch_function_("hadamard", "src/matrix/eigen.birch", 517);
  #line 518 "src/matrix/eigen.birch"

  return x.toEigen().cwiseProduct(y.toEigen());
  }

#line 526 "src/matrix/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::hadamard(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 526 "src/matrix/eigen.birch"
  libbirch_function_("hadamard", "src/matrix/eigen.birch", 526);
  #line 527 "src/matrix/eigen.birch"

  return X.toEigen().cwiseProduct(Y.toEigen());
  }

#line 144 "src/matrix/matrix.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::diagonal(const birch::type::Real& x, const birch::type::Integer& length) {
  #line 144 "src/matrix/matrix.birch"
  libbirch_function_("diagonal", "src/matrix/matrix.birch", 144);
  #line 145 "src/matrix/matrix.birch"
  libbirch_line_(145);
  #line 145 "src/matrix/matrix.birch"
  return birch::matrix(std::function<birch::type::Real(birch::type::Integer,birch::type::Integer)>([=](const birch::type::Integer& i, const birch::type::Integer& j) {
    #line 146 "src/matrix/matrix.birch"
    libbirch_line_(146);
    #line 146 "src/matrix/matrix.birch"
    if (i == j) {
      #line 147 "src/matrix/matrix.birch"
      libbirch_line_(147);
      #line 147 "src/matrix/matrix.birch"
      return x;
    } else {
      #line 149 "src/matrix/matrix.birch"
      libbirch_line_(149);
      #line 149 "src/matrix/matrix.birch"
      return 0.0;
    }
  }), length, length);
}

#line 160 "src/matrix/matrix.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::diagonal(const birch::type::Integer& x, const birch::type::Integer& length) {
  #line 160 "src/matrix/matrix.birch"
  libbirch_function_("diagonal", "src/matrix/matrix.birch", 160);
  #line 161 "src/matrix/matrix.birch"
  libbirch_line_(161);
  #line 161 "src/matrix/matrix.birch"
  return birch::matrix(std::function<birch::type::Integer(birch::type::Integer,birch::type::Integer)>([=](const birch::type::Integer& i, const birch::type::Integer& j) {
    #line 162 "src/matrix/matrix.birch"
    libbirch_line_(162);
    #line 162 "src/matrix/matrix.birch"
    if (i == j) {
      #line 163 "src/matrix/matrix.birch"
      libbirch_line_(163);
      #line 163 "src/matrix/matrix.birch"
      return x;
    } else {
      #line 165 "src/matrix/matrix.birch"
      libbirch_line_(165);
      #line 165 "src/matrix/matrix.birch"
      return birch::type::Integer(0);
    }
  }), length, length);
}

#line 176 "src/matrix/matrix.birch"
libbirch::DefaultArray<birch::type::Boolean,2> birch::diagonal(const birch::type::Boolean& x, const birch::type::Integer& length) {
  #line 176 "src/matrix/matrix.birch"
  libbirch_function_("diagonal", "src/matrix/matrix.birch", 176);
  #line 177 "src/matrix/matrix.birch"
  libbirch_line_(177);
  #line 177 "src/matrix/matrix.birch"
  return birch::matrix(std::function<birch::type::Boolean(birch::type::Integer,birch::type::Integer)>([=](const birch::type::Integer& i, const birch::type::Integer& j) {
    #line 178 "src/matrix/matrix.birch"
    libbirch_line_(178);
    #line 178 "src/matrix/matrix.birch"
    if (i == j) {
      #line 179 "src/matrix/matrix.birch"
      libbirch_line_(179);
      #line 179 "src/matrix/matrix.birch"
      return x;
    } else {
      #line 181 "src/matrix/matrix.birch"
      libbirch_line_(181);
      #line 181 "src/matrix/matrix.birch"
      return false;
    }
  }), length, length);
}

#line 192 "src/matrix/matrix.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::identity(const birch::type::Integer& length) {
  #line 192 "src/matrix/matrix.birch"
  libbirch_function_("identity", "src/matrix/matrix.birch", 192);
  #line 193 "src/matrix/matrix.birch"
  libbirch_line_(193);
  #line 193 "src/matrix/matrix.birch"
  return birch::diagonal(1.0, length);
}

#line 263 "src/matrix/matrix.birch"
birch::type::String birch::String(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 263 "src/matrix/matrix.birch"
  libbirch_function_("String", "src/matrix/matrix.birch", 263);
  #line 264 "src/matrix/matrix.birch"
  libbirch_line_(264);
  #line 264 "src/matrix/matrix.birch"
  birch::type::String result = libbirch::make<birch::type::String>();
  #line 265 "src/matrix/matrix.birch"

  std::stringstream buf;
    #line 268 "src/matrix/matrix.birch"
  libbirch_line_(268);
  #line 268 "src/matrix/matrix.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(X); ++i) {
    #line 269 "src/matrix/matrix.birch"

    if (i > 1) {
      buf << '\n';
    }
        #line 274 "src/matrix/matrix.birch"
    libbirch_line_(274);
    #line 274 "src/matrix/matrix.birch"
    for (auto j = birch::type::Integer(1); j <= birch::columns(X); ++j) {
      #line 275 "src/matrix/matrix.birch"
      libbirch_line_(275);
      #line 275 "src/matrix/matrix.birch"
      auto value = X(i, j);
      #line 276 "src/matrix/matrix.birch"

      if (j > 1) {
        buf << ' ';
      }
      if (value == floor(value)) {
        buf << (int64_t)value << ".0";
      } else {
        buf << std::scientific << std::setprecision(14) << value;
      }
          }
  }
  #line 288 "src/matrix/matrix.birch"

  result = buf.str();
    #line 291 "src/matrix/matrix.birch"
  libbirch_line_(291);
  #line 291 "src/matrix/matrix.birch"
  return result;
}

#line 297 "src/matrix/matrix.birch"
birch::type::String birch::String(const libbirch::DefaultArray<birch::type::Integer,2>& X) {
  #line 297 "src/matrix/matrix.birch"
  libbirch_function_("String", "src/matrix/matrix.birch", 297);
  #line 298 "src/matrix/matrix.birch"
  libbirch_line_(298);
  #line 298 "src/matrix/matrix.birch"
  birch::type::String result = libbirch::make<birch::type::String>();
  #line 299 "src/matrix/matrix.birch"

  std::stringstream buf;
    #line 302 "src/matrix/matrix.birch"
  libbirch_line_(302);
  #line 302 "src/matrix/matrix.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(X); ++i) {
    #line 303 "src/matrix/matrix.birch"

    if (i > 1) {
      buf << '\n';
    }
        #line 308 "src/matrix/matrix.birch"
    libbirch_line_(308);
    #line 308 "src/matrix/matrix.birch"
    for (auto j = birch::type::Integer(1); j <= birch::columns(X); ++j) {
      #line 309 "src/matrix/matrix.birch"
      libbirch_line_(309);
      #line 309 "src/matrix/matrix.birch"
      auto value = X(i, j);
      #line 310 "src/matrix/matrix.birch"

      if (j > 1) {
        buf << ' ';
      }
      buf << value;
          }
  }
  #line 318 "src/matrix/matrix.birch"

  result = buf.str();
    #line 321 "src/matrix/matrix.birch"
  libbirch_line_(321);
  #line 321 "src/matrix/matrix.birch"
  return result;
}

#line 327 "src/matrix/matrix.birch"
birch::type::String birch::String(const libbirch::DefaultArray<birch::type::Boolean,2>& X) {
  #line 327 "src/matrix/matrix.birch"
  libbirch_function_("String", "src/matrix/matrix.birch", 327);
  #line 328 "src/matrix/matrix.birch"
  libbirch_line_(328);
  #line 328 "src/matrix/matrix.birch"
  birch::type::String result = libbirch::make<birch::type::String>();
  #line 329 "src/matrix/matrix.birch"

  std::stringstream buf;
    #line 332 "src/matrix/matrix.birch"
  libbirch_line_(332);
  #line 332 "src/matrix/matrix.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(X); ++i) {
    #line 333 "src/matrix/matrix.birch"

    if (i > 1) {
      buf << '\n';
    }
        #line 338 "src/matrix/matrix.birch"
    libbirch_line_(338);
    #line 338 "src/matrix/matrix.birch"
    for (auto j = birch::type::Integer(1); j <= birch::columns(X); ++j) {
      #line 339 "src/matrix/matrix.birch"
      libbirch_line_(339);
      #line 339 "src/matrix/matrix.birch"
      auto value = X(i, j);
      #line 340 "src/matrix/matrix.birch"

      if (j > 1) {
        buf << ' ';
      }
      if (value) {
        buf << "true";
      } else {
        buf << "false";
      }
          }
  }
  #line 352 "src/matrix/matrix.birch"

  result = buf.str();
    #line 355 "src/matrix/matrix.birch"
  libbirch_line_(355);
  #line 355 "src/matrix/matrix.birch"
  return result;
}

#line 361 "src/matrix/matrix.birch"
birch::type::String birch::String(const birch::type::LLT& X) {
  #line 361 "src/matrix/matrix.birch"
  libbirch_function_("String", "src/matrix/matrix.birch", 361);
  #line 362 "src/matrix/matrix.birch"
  libbirch_line_(362);
  #line 362 "src/matrix/matrix.birch"
  return birch::String(birch::canonical(X));
}

#line 4 "src/matrix/scalar.birch"
birch::type::Integer birch::length(const birch::type::Real& x) {
  #line 4 "src/matrix/scalar.birch"
  libbirch_function_("length", "src/matrix/scalar.birch", 4);
  #line 5 "src/matrix/scalar.birch"
  libbirch_line_(5);
  #line 5 "src/matrix/scalar.birch"
  return birch::type::Integer(1);
}

#line 11 "src/matrix/scalar.birch"
birch::type::Integer birch::length(const birch::type::Integer& x) {
  #line 11 "src/matrix/scalar.birch"
  libbirch_function_("length", "src/matrix/scalar.birch", 11);
  #line 12 "src/matrix/scalar.birch"
  libbirch_line_(12);
  #line 12 "src/matrix/scalar.birch"
  return birch::type::Integer(1);
}

#line 18 "src/matrix/scalar.birch"
birch::type::Integer birch::length(const birch::type::Boolean& x) {
  #line 18 "src/matrix/scalar.birch"
  libbirch_function_("length", "src/matrix/scalar.birch", 18);
  #line 19 "src/matrix/scalar.birch"
  libbirch_line_(19);
  #line 19 "src/matrix/scalar.birch"
  return birch::type::Integer(1);
}

#line 25 "src/matrix/scalar.birch"
birch::type::Integer birch::rows(const birch::type::Real& x) {
  #line 25 "src/matrix/scalar.birch"
  libbirch_function_("rows", "src/matrix/scalar.birch", 25);
  #line 26 "src/matrix/scalar.birch"
  libbirch_line_(26);
  #line 26 "src/matrix/scalar.birch"
  return birch::type::Integer(1);
}

#line 32 "src/matrix/scalar.birch"
birch::type::Integer birch::rows(const birch::type::Integer& x) {
  #line 32 "src/matrix/scalar.birch"
  libbirch_function_("rows", "src/matrix/scalar.birch", 32);
  #line 33 "src/matrix/scalar.birch"
  libbirch_line_(33);
  #line 33 "src/matrix/scalar.birch"
  return birch::type::Integer(1);
}

#line 39 "src/matrix/scalar.birch"
birch::type::Integer birch::rows(const birch::type::Boolean& x) {
  #line 39 "src/matrix/scalar.birch"
  libbirch_function_("rows", "src/matrix/scalar.birch", 39);
  #line 40 "src/matrix/scalar.birch"
  libbirch_line_(40);
  #line 40 "src/matrix/scalar.birch"
  return birch::type::Integer(1);
}

#line 46 "src/matrix/scalar.birch"
birch::type::Integer birch::columns(const birch::type::Real& x) {
  #line 46 "src/matrix/scalar.birch"
  libbirch_function_("columns", "src/matrix/scalar.birch", 46);
  #line 47 "src/matrix/scalar.birch"
  libbirch_line_(47);
  #line 47 "src/matrix/scalar.birch"
  return birch::type::Integer(1);
}

#line 53 "src/matrix/scalar.birch"
birch::type::Integer birch::columns(const birch::type::Integer& x) {
  #line 53 "src/matrix/scalar.birch"
  libbirch_function_("columns", "src/matrix/scalar.birch", 53);
  #line 54 "src/matrix/scalar.birch"
  libbirch_line_(54);
  #line 54 "src/matrix/scalar.birch"
  return birch::type::Integer(1);
}

#line 60 "src/matrix/scalar.birch"
birch::type::Integer birch::columns(const birch::type::Boolean& x) {
  #line 60 "src/matrix/scalar.birch"
  libbirch_function_("columns", "src/matrix/scalar.birch", 60);
  #line 61 "src/matrix/scalar.birch"
  libbirch_line_(61);
  #line 61 "src/matrix/scalar.birch"
  return birch::type::Integer(1);
}

#line 67 "src/matrix/scalar.birch"
birch::type::Real birch::transpose(const birch::type::Real& x) {
  #line 67 "src/matrix/scalar.birch"
  libbirch_function_("transpose", "src/matrix/scalar.birch", 67);
  #line 68 "src/matrix/scalar.birch"
  libbirch_line_(68);
  #line 68 "src/matrix/scalar.birch"
  return x;
}

#line 74 "src/matrix/scalar.birch"
birch::type::Integer birch::transpose(const birch::type::Integer& x) {
  #line 74 "src/matrix/scalar.birch"
  libbirch_function_("transpose", "src/matrix/scalar.birch", 74);
  #line 75 "src/matrix/scalar.birch"
  libbirch_line_(75);
  #line 75 "src/matrix/scalar.birch"
  return x;
}

#line 81 "src/matrix/scalar.birch"
birch::type::Boolean birch::transpose(const birch::type::Boolean& x) {
  #line 81 "src/matrix/scalar.birch"
  libbirch_function_("transpose", "src/matrix/scalar.birch", 81);
  #line 82 "src/matrix/scalar.birch"
  libbirch_line_(82);
  #line 82 "src/matrix/scalar.birch"
  return x;
}

#line 224 "src/matrix/vector.birch"
birch::type::String birch::String(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 224 "src/matrix/vector.birch"
  libbirch_function_("String", "src/matrix/vector.birch", 224);
  #line 225 "src/matrix/vector.birch"
  libbirch_line_(225);
  #line 225 "src/matrix/vector.birch"
  birch::type::String result = libbirch::make<birch::type::String>();
  #line 226 "src/matrix/vector.birch"

  std::stringstream buf;
    #line 229 "src/matrix/vector.birch"
  libbirch_line_(229);
  #line 229 "src/matrix/vector.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(x); ++i) {
    #line 230 "src/matrix/vector.birch"
    libbirch_line_(230);
    #line 230 "src/matrix/vector.birch"
    auto value = x(i);
    #line 231 "src/matrix/vector.birch"

    if (i > 1) {
      buf << ' ';
    }
    if (value == floor(value)) {
      buf << (int64_t)value << ".0";
    } else {
      buf << std::scientific << std::setprecision(6) << value;
    }
      }
  #line 242 "src/matrix/vector.birch"

  result = buf.str();
    #line 245 "src/matrix/vector.birch"
  libbirch_line_(245);
  #line 245 "src/matrix/vector.birch"
  return result;
}

#line 251 "src/matrix/vector.birch"
birch::type::String birch::String(const libbirch::DefaultArray<birch::type::Integer,1>& x) {
  #line 251 "src/matrix/vector.birch"
  libbirch_function_("String", "src/matrix/vector.birch", 251);
  #line 252 "src/matrix/vector.birch"
  libbirch_line_(252);
  #line 252 "src/matrix/vector.birch"
  birch::type::String result = libbirch::make<birch::type::String>();
  #line 253 "src/matrix/vector.birch"

  std::stringstream buf;
    #line 256 "src/matrix/vector.birch"
  libbirch_line_(256);
  #line 256 "src/matrix/vector.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(x); ++i) {
    #line 257 "src/matrix/vector.birch"
    libbirch_line_(257);
    #line 257 "src/matrix/vector.birch"
    auto value = x(i);
    #line 258 "src/matrix/vector.birch"

    if (i > 1) {
      buf << ' ';
    }
    buf << value;
      }
  #line 265 "src/matrix/vector.birch"

  result = buf.str();
    #line 268 "src/matrix/vector.birch"
  libbirch_line_(268);
  #line 268 "src/matrix/vector.birch"
  return result;
}

#line 274 "src/matrix/vector.birch"
birch::type::String birch::String(const libbirch::DefaultArray<birch::type::Boolean,1>& x) {
  #line 274 "src/matrix/vector.birch"
  libbirch_function_("String", "src/matrix/vector.birch", 274);
  #line 275 "src/matrix/vector.birch"
  libbirch_line_(275);
  #line 275 "src/matrix/vector.birch"
  birch::type::String result = libbirch::make<birch::type::String>();
  #line 276 "src/matrix/vector.birch"

  std::stringstream buf;
    #line 279 "src/matrix/vector.birch"
  libbirch_line_(279);
  #line 279 "src/matrix/vector.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(x); ++i) {
    #line 280 "src/matrix/vector.birch"
    libbirch_line_(280);
    #line 280 "src/matrix/vector.birch"
    auto value = x(i);
    #line 281 "src/matrix/vector.birch"

    if (i > 1) {
      buf << ' ';
    }
    if (value) {
      buf << "true";
    } else {
      buf << "false";
    }
      }
  #line 292 "src/matrix/vector.birch"

  result = buf.str();
    #line 295 "src/matrix/vector.birch"
  libbirch_line_(295);
  #line 295 "src/matrix/vector.birch"
  return result;
}

