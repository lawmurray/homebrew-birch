#line 1 "src/kernel/LangevinKernel.birch"
birch::type::LangevinKernel::LangevinKernel(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/kernel/LangevinKernel.birch"
    super_type_(),
    #line 15 "src/kernel/LangevinKernel.birch"
    scale(1.0) {
  //
}

#line 17 "src/kernel/LangevinKernel.birch"
birch::type::Real birch::type::LangevinKernel::move(const libbirch::Lazy<libbirch::Shared<birch::type::Random<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 17 "src/kernel/LangevinKernel.birch"
  libbirch_function_("move", "src/kernel/LangevinKernel.birch", 17);
  #line 18 "src/kernel/LangevinKernel.birch"
  libbirch_line_(18);
  #line 18 "src/kernel/LangevinKernel.birch"
  return birch::simulate_gaussian(x->x.get() + this_()->scale * x->d.get(), 2.0 * this_()->scale, handler_);
}

#line 21 "src/kernel/LangevinKernel.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::LangevinKernel::move(const libbirch::Lazy<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "src/kernel/LangevinKernel.birch"
  libbirch_function_("move", "src/kernel/LangevinKernel.birch", 21);
  #line 22 "src/kernel/LangevinKernel.birch"
  libbirch_line_(22);
  #line 22 "src/kernel/LangevinKernel.birch"
  return birch::simulate_multivariate_gaussian(x->x.get() + this_()->scale * x->d.get(), 2.0 * this_()->scale, handler_);
}

#line 25 "src/kernel/LangevinKernel.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::LangevinKernel::move(const libbirch::Lazy<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,2>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/kernel/LangevinKernel.birch"
  libbirch_function_("move", "src/kernel/LangevinKernel.birch", 25);
  #line 26 "src/kernel/LangevinKernel.birch"
  libbirch_line_(26);
  #line 26 "src/kernel/LangevinKernel.birch"
  return birch::simulate_matrix_gaussian(x->x.get() + this_()->scale * x->d.get(), 2.0 * this_()->scale, handler_);
}

#line 29 "src/kernel/LangevinKernel.birch"
birch::type::Real birch::type::LangevinKernel::logpdf(const libbirch::Lazy<libbirch::Shared<birch::type::Random<birch::type::Real>>>& x_prime_, const libbirch::Lazy<libbirch::Shared<birch::type::Random<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "src/kernel/LangevinKernel.birch"
  libbirch_function_("logpdf", "src/kernel/LangevinKernel.birch", 29);
  #line 30 "src/kernel/LangevinKernel.birch"
  libbirch_line_(30);
  #line 30 "src/kernel/LangevinKernel.birch"
  return birch::logpdf_gaussian(x_prime_->x.get(), x->x.get() + this_()->scale * x->d.get(), 2.0 * this_()->scale, handler_);
}

#line 33 "src/kernel/LangevinKernel.birch"
birch::type::Real birch::type::LangevinKernel::logpdf(const libbirch::Lazy<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,1>>>>& x_prime_, const libbirch::Lazy<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/kernel/LangevinKernel.birch"
  libbirch_function_("logpdf", "src/kernel/LangevinKernel.birch", 33);
  #line 34 "src/kernel/LangevinKernel.birch"
  libbirch_line_(34);
  #line 34 "src/kernel/LangevinKernel.birch"
  return birch::logpdf_multivariate_gaussian(x_prime_->x.get(), x->x.get() + this_()->scale * x->d.get(), 2.0 * this_()->scale, handler_);
}

#line 37 "src/kernel/LangevinKernel.birch"
birch::type::Real birch::type::LangevinKernel::logpdf(const libbirch::Lazy<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,2>>>>& x_prime_, const libbirch::Lazy<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,2>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/kernel/LangevinKernel.birch"
  libbirch_function_("logpdf", "src/kernel/LangevinKernel.birch", 37);
  #line 38 "src/kernel/LangevinKernel.birch"
  libbirch_line_(38);
  #line 38 "src/kernel/LangevinKernel.birch"
  return birch::logpdf_matrix_gaussian(x_prime_->x.get(), x->x.get() + this_()->scale * x->d.get(), 2.0 * this_()->scale, handler_);
}

#line 41 "src/kernel/LangevinKernel.birch"
void birch::type::LangevinKernel::read(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "src/kernel/LangevinKernel.birch"
  libbirch_function_("read", "src/kernel/LangevinKernel.birch", 41);
  #line 42 "src/kernel/LangevinKernel.birch"
  libbirch_line_(42);
  #line 42 "src/kernel/LangevinKernel.birch"
  this_()->super_type_::read(buffer, handler_);
  #line 43 "src/kernel/LangevinKernel.birch"
  libbirch_line_(43);
  #line 43 "src/kernel/LangevinKernel.birch"
  libbirch::optional_assign(this_()->scale, buffer->getReal(birch::type::String("scale"), handler_));
}

#line 46 "src/kernel/LangevinKernel.birch"
void birch::type::LangevinKernel::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/kernel/LangevinKernel.birch"
  libbirch_function_("write", "src/kernel/LangevinKernel.birch", 46);
  #line 47 "src/kernel/LangevinKernel.birch"
  libbirch_line_(47);
  #line 47 "src/kernel/LangevinKernel.birch"
  this_()->super_type_::write(buffer, handler_);
  #line 48 "src/kernel/LangevinKernel.birch"
  libbirch_line_(48);
  #line 48 "src/kernel/LangevinKernel.birch"
  buffer->setReal(birch::type::String("scale"), this_()->scale, handler_);
}

#line 1 "src/kernel/LangevinKernel.birch"
birch::type::LangevinKernel* birch::type::make_LangevinKernel_() {
  #line 1 "src/kernel/LangevinKernel.birch"
  return new birch::type::LangevinKernel();
  #line 1 "src/kernel/LangevinKernel.birch"
}

#line 1 "src/kernel/Kernel.birch"
birch::type::Kernel::Kernel(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/kernel/Kernel.birch"
    super_type_() {
  //
}

#line 55 "src/kernel/Kernel.birch"
birch::type::Real birch::type::Kernel::move(const libbirch::Lazy<libbirch::Shared<birch::type::Random<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 55 "src/kernel/Kernel.birch"
  libbirch_function_("move", "src/kernel/Kernel.birch", 55);
  #line 56 "src/kernel/Kernel.birch"
  libbirch_line_(56);
  #line 56 "src/kernel/Kernel.birch"
  return x->x.get();
}

#line 66 "src/kernel/Kernel.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::Kernel::move(const libbirch::Lazy<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "src/kernel/Kernel.birch"
  libbirch_function_("move", "src/kernel/Kernel.birch", 66);
  #line 67 "src/kernel/Kernel.birch"
  libbirch_line_(67);
  #line 67 "src/kernel/Kernel.birch"
  return x->x.get();
}

#line 77 "src/kernel/Kernel.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::Kernel::move(const libbirch::Lazy<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,2>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 77 "src/kernel/Kernel.birch"
  libbirch_function_("move", "src/kernel/Kernel.birch", 77);
  #line 78 "src/kernel/Kernel.birch"
  libbirch_line_(78);
  #line 78 "src/kernel/Kernel.birch"
  return x->x.get();
}

#line 88 "src/kernel/Kernel.birch"
birch::type::LLT birch::type::Kernel::move(const libbirch::Lazy<libbirch::Shared<birch::type::Random<birch::type::LLT>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 88 "src/kernel/Kernel.birch"
  libbirch_function_("move", "src/kernel/Kernel.birch", 88);
  #line 89 "src/kernel/Kernel.birch"
  libbirch_line_(89);
  #line 89 "src/kernel/Kernel.birch"
  return x->x.get();
}

#line 99 "src/kernel/Kernel.birch"
birch::type::Integer birch::type::Kernel::move(const libbirch::Lazy<libbirch::Shared<birch::type::Random<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 99 "src/kernel/Kernel.birch"
  libbirch_function_("move", "src/kernel/Kernel.birch", 99);
  #line 100 "src/kernel/Kernel.birch"
  libbirch_line_(100);
  #line 100 "src/kernel/Kernel.birch"
  return x->x.get();
}

#line 110 "src/kernel/Kernel.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::type::Kernel::move(const libbirch::Lazy<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Integer,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 110 "src/kernel/Kernel.birch"
  libbirch_function_("move", "src/kernel/Kernel.birch", 110);
  #line 111 "src/kernel/Kernel.birch"
  libbirch_line_(111);
  #line 111 "src/kernel/Kernel.birch"
  return x->x.get();
}

#line 121 "src/kernel/Kernel.birch"
birch::type::Boolean birch::type::Kernel::move(const libbirch::Lazy<libbirch::Shared<birch::type::Random<birch::type::Boolean>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 121 "src/kernel/Kernel.birch"
  libbirch_function_("move", "src/kernel/Kernel.birch", 121);
  #line 122 "src/kernel/Kernel.birch"
  libbirch_line_(122);
  #line 122 "src/kernel/Kernel.birch"
  return x->x.get();
}

#line 133 "src/kernel/Kernel.birch"
birch::type::Real birch::type::Kernel::logpdf(const libbirch::Lazy<libbirch::Shared<birch::type::Random<birch::type::Real>>>& x_prime_, const libbirch::Lazy<libbirch::Shared<birch::type::Random<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 133 "src/kernel/Kernel.birch"
  libbirch_function_("logpdf", "src/kernel/Kernel.birch", 133);
  #line 134 "src/kernel/Kernel.birch"
  libbirch_line_(134);
  #line 134 "src/kernel/Kernel.birch"
  return 0.0;
}

#line 145 "src/kernel/Kernel.birch"
birch::type::Real birch::type::Kernel::logpdf(const libbirch::Lazy<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,1>>>>& x_prime_, const libbirch::Lazy<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 145 "src/kernel/Kernel.birch"
  libbirch_function_("logpdf", "src/kernel/Kernel.birch", 145);
  #line 146 "src/kernel/Kernel.birch"
  libbirch_line_(146);
  #line 146 "src/kernel/Kernel.birch"
  return 0.0;
}

#line 157 "src/kernel/Kernel.birch"
birch::type::Real birch::type::Kernel::logpdf(const libbirch::Lazy<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,2>>>>& x_prime_, const libbirch::Lazy<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,2>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 157 "src/kernel/Kernel.birch"
  libbirch_function_("logpdf", "src/kernel/Kernel.birch", 157);
  #line 158 "src/kernel/Kernel.birch"
  libbirch_line_(158);
  #line 158 "src/kernel/Kernel.birch"
  return 0.0;
}

#line 169 "src/kernel/Kernel.birch"
birch::type::Real birch::type::Kernel::logpdf(const libbirch::Lazy<libbirch::Shared<birch::type::Random<birch::type::LLT>>>& x_prime_, const libbirch::Lazy<libbirch::Shared<birch::type::Random<birch::type::LLT>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 169 "src/kernel/Kernel.birch"
  libbirch_function_("logpdf", "src/kernel/Kernel.birch", 169);
  #line 170 "src/kernel/Kernel.birch"
  libbirch_line_(170);
  #line 170 "src/kernel/Kernel.birch"
  return 0.0;
}

#line 181 "src/kernel/Kernel.birch"
birch::type::Real birch::type::Kernel::logpdf(const libbirch::Lazy<libbirch::Shared<birch::type::Random<birch::type::Integer>>>& x_prime_, const libbirch::Lazy<libbirch::Shared<birch::type::Random<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 181 "src/kernel/Kernel.birch"
  libbirch_function_("logpdf", "src/kernel/Kernel.birch", 181);
  #line 182 "src/kernel/Kernel.birch"
  libbirch_line_(182);
  #line 182 "src/kernel/Kernel.birch"
  return 0.0;
}

#line 193 "src/kernel/Kernel.birch"
birch::type::Real birch::type::Kernel::logpdf(const libbirch::Lazy<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Integer,1>>>>& x_prime_, const libbirch::Lazy<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Integer,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 193 "src/kernel/Kernel.birch"
  libbirch_function_("logpdf", "src/kernel/Kernel.birch", 193);
  #line 194 "src/kernel/Kernel.birch"
  libbirch_line_(194);
  #line 194 "src/kernel/Kernel.birch"
  return 0.0;
}

#line 205 "src/kernel/Kernel.birch"
birch::type::Real birch::type::Kernel::logpdf(const libbirch::Lazy<libbirch::Shared<birch::type::Random<birch::type::Boolean>>>& x_prime_, const libbirch::Lazy<libbirch::Shared<birch::type::Random<birch::type::Boolean>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 205 "src/kernel/Kernel.birch"
  libbirch_function_("logpdf", "src/kernel/Kernel.birch", 205);
  #line 206 "src/kernel/Kernel.birch"
  libbirch_line_(206);
  #line 206 "src/kernel/Kernel.birch"
  return 0.0;
}

#line 1 "src/kernel/Kernel.birch"
birch::type::Kernel* birch::type::make_Kernel_() {
  #line 1 "src/kernel/Kernel.birch"
  return new birch::type::Kernel();
  #line 1 "src/kernel/Kernel.birch"
}

