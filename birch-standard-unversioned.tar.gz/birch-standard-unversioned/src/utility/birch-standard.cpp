#line 1 "src/utility/chrono.birch"
#include <chrono>

thread_local static std::chrono::time_point<std::chrono::steady_clock> savedTimePoint = std::chrono::steady_clock::now();
#line 10 "src/utility/chrono.birch"
void birch::tic(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/utility/chrono.birch"
  libbirch_function_("tic", "src/utility/chrono.birch", 10);
  #line 11 "src/utility/chrono.birch"
savedTimePoint = std::chrono::steady_clock::now();
  }

#line 19 "src/utility/chrono.birch"
birch::type::Real birch::toc(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/utility/chrono.birch"
  libbirch_function_("toc", "src/utility/chrono.birch", 19);
  #line 20 "src/utility/chrono.birch"
  libbirch_line_(20);
  #line 20 "src/utility/chrono.birch"
  birch::type::Real elapsed;
  #line 21 "src/utility/chrono.birch"
std::chrono::duration<double> e = std::chrono::steady_clock::now() - savedTimePoint;
  elapsed = e.count();
    #line 25 "src/utility/chrono.birch"
  libbirch_line_(25);
  #line 25 "src/utility/chrono.birch"
  return elapsed;
}

#line 4 "src/utility/collect.birch"
void birch::collect(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 4 "src/utility/collect.birch"
  libbirch_function_("collect", "src/utility/collect.birch", 4);
  #line 5 "src/utility/collect.birch"
libbirch::collect();
  }

#line 4 "src/utility/error.birch"
void birch::error(const birch::type::String& msg, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 4 "src/utility/error.birch"
  libbirch_function_("error", "src/utility/error.birch", 4);
  #line 5 "src/utility/error.birch"
libbirch::abort(msg, 1);
  }

#line 13 "src/utility/error.birch"
void birch::warn(const birch::type::String& msg, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 13 "src/utility/error.birch"
  libbirch_function_("warn", "src/utility/error.birch", 13);
  #line 14 "src/utility/error.birch"
  libbirch_line_(14);
  #line 14 "src/utility/error.birch"
  birch::stderr()->print(birch::type::String("warning: ") + msg + birch::type::String("\n"), handler_);
}

#line 28 "src/utility/make.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Object>>> birch::make(const birch::type::String& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/utility/make.birch"
  libbirch_function_("make", "src/utility/make.birch", 28);
  #line 29 "src/utility/make.birch"
  libbirch_line_(29);
  #line 29 "src/utility/make.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Object>>> result;
  #line 30 "src/utility/make.birch"
  libbirch_line_(30);
  #line 30 "src/utility/make.birch"
  birch::type::String symbol = birch::type::String("make_") + name + birch::type::String("_");
  #line 31 "src/utility/make.birch"
using make_t = birch::type::Object*();
  void* addr = dlsym(RTLD_DEFAULT, symbol.c_str());
  if (addr) {
    result = libbirch::Lazy<libbirch::Shared<birch::type::Object>>(reinterpret_cast<make_t*>(addr)());
  }
    #line 38 "src/utility/make.birch"
  libbirch_line_(38);
  #line 38 "src/utility/make.birch"
  if (!result.query()) {
    #line 39 "src/utility/make.birch"
    libbirch_line_(39);
    #line 39 "src/utility/make.birch"
    birch::warn(birch::type::String("could not make object of type ") + name + birch::type::String("; class may not exist or may require initialization arguments."), handler_);
  }
  #line 42 "src/utility/make.birch"
  libbirch_line_(42);
  #line 42 "src/utility/make.birch"
  return result;
}

#line 53 "src/utility/make.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Object>>> birch::make(const libbirch::Optional<birch::type::String>& name, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "src/utility/make.birch"
  libbirch_function_("make", "src/utility/make.birch", 53);
  #line 54 "src/utility/make.birch"
  libbirch_line_(54);
  #line 54 "src/utility/make.birch"
  if (name.query()) {
    #line 55 "src/utility/make.birch"
    libbirch_line_(55);
    #line 55 "src/utility/make.birch"
    return birch::make(name.get(), handler_);
  } else {
    #line 57 "src/utility/make.birch"
    libbirch_line_(57);
    #line 57 "src/utility/make.birch"
    return libbirch::nil;
  }
}

#line 75 "src/utility/make.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Object>>> birch::make(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 75 "src/utility/make.birch"
  libbirch_function_("make", "src/utility/make.birch", 75);
  #line 76 "src/utility/make.birch"
  libbirch_line_(76);
  #line 76 "src/utility/make.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Object>>> result;
  #line 77 "src/utility/make.birch"
  libbirch_line_(77);
  #line 77 "src/utility/make.birch"
  auto className = buffer->getString(birch::type::String("class"), handler_);
  #line 78 "src/utility/make.birch"
  libbirch_line_(78);
  #line 78 "src/utility/make.birch"
  if (className.query()) {
    #line 79 "src/utility/make.birch"
    libbirch_line_(79);
    #line 79 "src/utility/make.birch"
    result = birch::make(className.get(), handler_);
  }
  #line 81 "src/utility/make.birch"
  libbirch_line_(81);
  #line 81 "src/utility/make.birch"
  if (result.query()) {
    #line 82 "src/utility/make.birch"
    libbirch_line_(82);
    #line 82 "src/utility/make.birch"
    result.get()->read(buffer, handler_);
  }
  #line 84 "src/utility/make.birch"
  libbirch_line_(84);
  #line 84 "src/utility/make.birch"
  return result;
}

#line 95 "src/utility/make.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Object>>> birch::make(const libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "src/utility/make.birch"
  libbirch_function_("make", "src/utility/make.birch", 95);
  #line 96 "src/utility/make.birch"
  libbirch_line_(96);
  #line 96 "src/utility/make.birch"
  if (buffer.query()) {
    #line 97 "src/utility/make.birch"
    libbirch_line_(97);
    #line 97 "src/utility/make.birch"
    return birch::make(buffer.get(), handler_);
  } else {
    #line 99 "src/utility/make.birch"
    libbirch_line_(99);
    #line 99 "src/utility/make.birch"
    return libbirch::nil;
  }
}

#line 1 "src/utility/ProgressBar.birch"
birch::type::ProgressBar::ProgressBar(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/utility/ProgressBar.birch"
    super_type_(),
    #line 8 "src/utility/ProgressBar.birch"
    out(birch::stderr()),
    #line 13 "src/utility/ProgressBar.birch"
    current(-birch::type::Integer(1)),
    #line 18 "src/utility/ProgressBar.birch"
    maximum(birch::type::Integer(80)) {
  //
}

#line 30 "src/utility/ProgressBar.birch"
void birch::type::ProgressBar::update(const birch::type::Real& progress, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/utility/ProgressBar.birch"
  libbirch_function_("update", "src/utility/ProgressBar.birch", 30);
  #line 31 "src/utility/ProgressBar.birch"
  libbirch_line_(31);
  #line 31 "src/utility/ProgressBar.birch"
  libbirch_assert_(0.0 <= progress && progress <= 1.0);  // GCOV_EXCL_LINE
  #line 32 "src/utility/ProgressBar.birch"
  libbirch_line_(32);
  #line 32 "src/utility/ProgressBar.birch"
  auto old = this_()->current;
  #line 33 "src/utility/ProgressBar.birch"
  libbirch_line_(33);
  #line 33 "src/utility/ProgressBar.birch"
  this_()->current = birch::Integer(progress * this_()->maximum, handler_);
  #line 34 "src/utility/ProgressBar.birch"
  libbirch_line_(34);
  #line 34 "src/utility/ProgressBar.birch"
  if (this_()->current != old) {
    #line 36 "src/utility/ProgressBar.birch"
    libbirch_line_(36);
    #line 36 "src/utility/ProgressBar.birch"
    this_()->out->flush(handler_);
    #line 37 "src/utility/ProgressBar.birch"
    libbirch_line_(37);
    #line 37 "src/utility/ProgressBar.birch"
    if (old >= birch::type::Integer(0)) {
      #line 39 "src/utility/ProgressBar.birch"
      libbirch_line_(39);
      #line 39 "src/utility/ProgressBar.birch"
      this_()->out->print(birch::type::String("\033[1A\r"), handler_);
    }
    #line 41 "src/utility/ProgressBar.birch"
    libbirch_line_(41);
    #line 41 "src/utility/ProgressBar.birch"
    for (auto i = birch::type::Integer(1); i <= this_()->current; ++i) {
      #line 42 "src/utility/ProgressBar.birch"
      libbirch_line_(42);
      #line 42 "src/utility/ProgressBar.birch"
      this_()->out->print(birch::type::String("\u25a0"), handler_);
    }
    #line 44 "src/utility/ProgressBar.birch"
    libbirch_line_(44);
    #line 44 "src/utility/ProgressBar.birch"
    for (auto i = (this_()->current + birch::type::Integer(1)); i <= this_()->maximum; ++i) {
      #line 45 "src/utility/ProgressBar.birch"
      libbirch_line_(45);
      #line 45 "src/utility/ProgressBar.birch"
      this_()->out->print(birch::type::String("\u25a1"), handler_);
    }
    #line 47 "src/utility/ProgressBar.birch"
    libbirch_line_(47);
    #line 47 "src/utility/ProgressBar.birch"
    this_()->out->print(birch::type::String("\n"), handler_);
    #line 48 "src/utility/ProgressBar.birch"
    libbirch_line_(48);
    #line 48 "src/utility/ProgressBar.birch"
    this_()->out->flush(handler_);
  }
}

#line 1 "src/utility/ProgressBar.birch"
birch::type::ProgressBar* birch::type::make_ProgressBar_() {
  #line 1 "src/utility/ProgressBar.birch"
  return new birch::type::ProgressBar();
  #line 1 "src/utility/ProgressBar.birch"
}

