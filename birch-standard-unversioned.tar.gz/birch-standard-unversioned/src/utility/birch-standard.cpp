#line 1 "src/utility/ProgressBar.birch"
birch::type::ProgressBar::ProgressBar() :
    #line 1 "src/utility/ProgressBar.birch"
    base_type_(),
    #line 8 "src/utility/ProgressBar.birch"
    out(birch::stderr()),
    #line 13 "src/utility/ProgressBar.birch"
    current(-(birch::type::Integer(1))),
    #line 18 "src/utility/ProgressBar.birch"
    maximum(birch::type::Integer(80)) {
  //
}

#line 30 "src/utility/ProgressBar.birch"
void birch::type::ProgressBar::update(const birch::type::Real& progress) {
  #line 30 "src/utility/ProgressBar.birch"
  libbirch_function_("update", "src/utility/ProgressBar.birch", 30);
  #line 31 "src/utility/ProgressBar.birch"
  libbirch_line_(31);
  #line 31 "src/utility/ProgressBar.birch"
  libbirch_assert_(0.0 <= progress && progress <= 1.0);
  #line 32 "src/utility/ProgressBar.birch"
  libbirch_line_(32);
  #line 32 "src/utility/ProgressBar.birch"
  auto old = this->current;
  #line 33 "src/utility/ProgressBar.birch"
  libbirch_line_(33);
  #line 33 "src/utility/ProgressBar.birch"
  this->current = birch::Integer(progress * this->maximum);
  #line 34 "src/utility/ProgressBar.birch"
  libbirch_line_(34);
  #line 34 "src/utility/ProgressBar.birch"
  if (this->current != old) {
    #line 36 "src/utility/ProgressBar.birch"
    libbirch_line_(36);
    #line 36 "src/utility/ProgressBar.birch"
    this->out->flush();
    #line 37 "src/utility/ProgressBar.birch"
    libbirch_line_(37);
    #line 37 "src/utility/ProgressBar.birch"
    if (old >= birch::type::Integer(0)) {
      #line 39 "src/utility/ProgressBar.birch"
      libbirch_line_(39);
      #line 39 "src/utility/ProgressBar.birch"
      this->out->print(birch::type::String("\033[1A\r"));
    }
    #line 41 "src/utility/ProgressBar.birch"
    libbirch_line_(41);
    #line 41 "src/utility/ProgressBar.birch"
    for (auto i = birch::type::Integer(1); i <= this->current; ++i) {
      #line 42 "src/utility/ProgressBar.birch"
      libbirch_line_(42);
      #line 42 "src/utility/ProgressBar.birch"
      this->out->print(birch::type::String("\u25a0"));
    }
    #line 44 "src/utility/ProgressBar.birch"
    libbirch_line_(44);
    #line 44 "src/utility/ProgressBar.birch"
    for (auto i = (this->current + birch::type::Integer(1)); i <= this->maximum; ++i) {
      #line 45 "src/utility/ProgressBar.birch"
      libbirch_line_(45);
      #line 45 "src/utility/ProgressBar.birch"
      this->out->print(birch::type::String("\u25a1"));
    }
    #line 47 "src/utility/ProgressBar.birch"
    libbirch_line_(47);
    #line 47 "src/utility/ProgressBar.birch"
    this->out->print(birch::type::String("\n"));
    #line 48 "src/utility/ProgressBar.birch"
    libbirch_line_(48);
    #line 48 "src/utility/ProgressBar.birch"
    this->out->flush();
  }
}

#line 1 "src/utility/ProgressBar.birch"
birch::type::ProgressBar* birch::type::make_ProgressBar_() {
  #line 1 "src/utility/ProgressBar.birch"
  return new birch::type::ProgressBar();
  #line 1 "src/utility/ProgressBar.birch"
}

#line 1 "src/utility/chrono.birch"

#include <chrono>

thread_local static std::chrono::time_point<std::chrono::steady_clock> savedTimePoint = std::chrono::steady_clock::now();
#line 10 "src/utility/chrono.birch"
void birch::tic() {
  #line 10 "src/utility/chrono.birch"
  libbirch_function_("tic", "src/utility/chrono.birch", 10);
  #line 11 "src/utility/chrono.birch"

  savedTimePoint = std::chrono::steady_clock::now();
  }

#line 19 "src/utility/chrono.birch"
birch::type::Real birch::toc() {
  #line 19 "src/utility/chrono.birch"
  libbirch_function_("toc", "src/utility/chrono.birch", 19);
  #line 20 "src/utility/chrono.birch"
  libbirch_line_(20);
  #line 20 "src/utility/chrono.birch"
  birch::type::Real elapsed = libbirch::make<birch::type::Real>();
  #line 21 "src/utility/chrono.birch"

  std::chrono::duration<double> e = std::chrono::steady_clock::now() - savedTimePoint;
  elapsed = e.count();
    #line 25 "src/utility/chrono.birch"
  libbirch_line_(25);
  #line 25 "src/utility/chrono.birch"
  return elapsed;
}

#line 4 "src/utility/collect.birch"
void birch::collect() {
  #line 4 "src/utility/collect.birch"
  libbirch_function_("collect", "src/utility/collect.birch", 4);
  #line 5 "src/utility/collect.birch"

  libbirch::collect();
  }

#line 4 "src/utility/error.birch"
void birch::error(const birch::type::String& msg) {
  #line 4 "src/utility/error.birch"
  libbirch_function_("error", "src/utility/error.birch", 4);
  #line 5 "src/utility/error.birch"

  libbirch::abort(msg, 1);
  }

#line 13 "src/utility/error.birch"
void birch::warn(const birch::type::String& msg) {
  #line 13 "src/utility/error.birch"
  libbirch_function_("warn", "src/utility/error.birch", 13);
  #line 14 "src/utility/error.birch"
  libbirch_line_(14);
  #line 14 "src/utility/error.birch"
  birch::stderr()->print(birch::type::String("warning: ") + msg + birch::type::String("\n"));
}

#line 28 "src/utility/make.birch"
std::optional<libbirch::Shared<birch::type::Object>> birch::make(const birch::type::String& name) {
  #line 28 "src/utility/make.birch"
  libbirch_function_("make", "src/utility/make.birch", 28);
  #line 29 "src/utility/make.birch"
  libbirch_line_(29);
  #line 29 "src/utility/make.birch"
  std::optional<libbirch::Shared<birch::type::Object>> result = libbirch::make<std::optional<libbirch::Shared<birch::type::Object>>>();
  #line 30 "src/utility/make.birch"
  libbirch_line_(30);
  #line 30 "src/utility/make.birch"
  birch::type::String symbol = birch::type::String("make_") + name + birch::type::String("_");
  #line 31 "src/utility/make.birch"

  using make_t = birch::type::Object*();
  void* addr = dlsym(RTLD_DEFAULT, symbol.c_str());
  if (addr) {
    result = libbirch::Shared<birch::type::Object>(reinterpret_cast<make_t*>(addr)());
  }
    #line 38 "src/utility/make.birch"
  libbirch_line_(38);
  #line 38 "src/utility/make.birch"
  if (!(result.has_value())) {
    #line 39 "src/utility/make.birch"
    libbirch_line_(39);
    #line 39 "src/utility/make.birch"
    birch::warn(birch::type::String("could not make object of type ") + name + birch::type::String("; class may not exist or may require initialization arguments."));
  }
  #line 42 "src/utility/make.birch"
  libbirch_line_(42);
  #line 42 "src/utility/make.birch"
  return result;
}

#line 59 "src/utility/make.birch"
std::optional<libbirch::Shared<birch::type::Object>> birch::make(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 59 "src/utility/make.birch"
  libbirch_function_("make", "src/utility/make.birch", 59);
  #line 60 "src/utility/make.birch"
  libbirch_line_(60);
  #line 60 "src/utility/make.birch"
  std::optional<libbirch::Shared<birch::type::Object>> result = libbirch::make<std::optional<libbirch::Shared<birch::type::Object>>>();
  #line 61 "src/utility/make.birch"
  libbirch_line_(61);
  #line 61 "src/utility/make.birch"
  auto className = buffer->get<birch::type::String>(birch::type::String("class"));
  #line 62 "src/utility/make.birch"
  libbirch_line_(62);
  #line 62 "src/utility/make.birch"
  if (className.has_value()) {
    #line 63 "src/utility/make.birch"
    libbirch_line_(63);
    #line 63 "src/utility/make.birch"
    result = birch::make(className.value());
  }
  #line 65 "src/utility/make.birch"
  libbirch_line_(65);
  #line 65 "src/utility/make.birch"
  if (result.has_value()) {
    #line 66 "src/utility/make.birch"
    libbirch_line_(66);
    #line 66 "src/utility/make.birch"
    result.value()->read(buffer);
  }
  #line 68 "src/utility/make.birch"
  libbirch_line_(68);
  #line 68 "src/utility/make.birch"
  return result;
}

#line 1 "src/utility/probability.birch"

static auto make_handlers() {
  std::vector<libbirch::Shared<birch::type::Handler>> handlers(
        libbirch::get_max_threads(), nullptr);
  #pragma omp parallel num_threads(libbirch::get_max_threads())
  {
    handlers[libbirch::get_thread_num()] = birch::PlayHandler(true);
  }
  return handlers;
}

static auto& get_handler() {
  static auto handlers = make_handlers();
  return handlers[libbirch::get_thread_num()];
}
#line 21 "src/utility/probability.birch"
libbirch::Shared<birch::type::Handler> birch::get_handler() {
  #line 21 "src/utility/probability.birch"
  libbirch_function_("get_handler", "src/utility/probability.birch", 21);
  #line 22 "src/utility/probability.birch"

  return ::get_handler();
  }

#line 35 "src/utility/probability.birch"
void birch::set_handler(const libbirch::Shared<birch::type::Handler>& handler) {
  #line 35 "src/utility/probability.birch"
  libbirch_function_("set_handler", "src/utility/probability.birch", 35);
  #line 36 "src/utility/probability.birch"

  ::get_handler() = handler;
  }

#line 53 "src/utility/probability.birch"
libbirch::Shared<birch::type::Handler> birch::swap_handler(const libbirch::Shared<birch::type::Handler>& handler) {
  #line 53 "src/utility/probability.birch"
  libbirch_function_("swap_handler", "src/utility/probability.birch", 53);
  #line 54 "src/utility/probability.birch"

  auto& current = ::get_handler();
  auto previous = handler;
  std::swap(current, previous);
  return previous;
  }

#line 145 "src/utility/probability.birch"
void birch::handle_factor(const birch::type::Real& w) {
  #line 145 "src/utility/probability.birch"
  libbirch_function_("handle_factor", "src/utility/probability.birch", 145);
  #line 146 "src/utility/probability.birch"
  libbirch_line_(146);
  #line 146 "src/utility/probability.birch"
  birch::get_handler()->handle(birch::FactorEvent(w));
}

