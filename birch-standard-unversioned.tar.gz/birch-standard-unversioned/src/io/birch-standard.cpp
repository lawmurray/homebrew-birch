#line 1 "src/io/InputStream.birch"
birch::type::InputStream::InputStream(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/io/InputStream.birch"
    super_type_(),
    #line 8 "src/io/InputStream.birch"
    file() {
  //
}

#line 16 "src/io/InputStream.birch"
void birch::type::InputStream::open(const birch::type::String& path, const birch::type::Integer& mode, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/io/InputStream.birch"
  libbirch_function_("open", "src/io/InputStream.birch", 16);
  #line 17 "src/io/InputStream.birch"
  libbirch_line_(17);
  #line 17 "src/io/InputStream.birch"
  libbirch_assert_(!(this_()->file.query()));
  #line 18 "src/io/InputStream.birch"
  libbirch_line_(18);
  #line 18 "src/io/InputStream.birch"
  this_()->file = birch::fopen(path, mode, handler_);
}

#line 26 "src/io/InputStream.birch"
void birch::type::InputStream::open(const birch::type::String& path, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/io/InputStream.birch"
  libbirch_function_("open", "src/io/InputStream.birch", 26);
  #line 27 "src/io/InputStream.birch"
  libbirch_line_(27);
  #line 27 "src/io/InputStream.birch"
  this_()->open(path, birch::READ(), handler_);
}

#line 33 "src/io/InputStream.birch"
void birch::type::InputStream::close(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/io/InputStream.birch"
  libbirch_function_("close", "src/io/InputStream.birch", 33);
  #line 34 "src/io/InputStream.birch"
  libbirch_line_(34);
  #line 34 "src/io/InputStream.birch"
  libbirch_assert_(this_()->file.query());
  #line 35 "src/io/InputStream.birch"
  libbirch_line_(35);
  #line 35 "src/io/InputStream.birch"
  birch::fclose(this_()->file.get(), handler_);
  #line 36 "src/io/InputStream.birch"
  libbirch_line_(36);
  #line 36 "src/io/InputStream.birch"
  this_()->file = libbirch::nil;
}

#line 42 "src/io/InputStream.birch"
birch::type::Boolean birch::type::InputStream::eof(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/io/InputStream.birch"
  libbirch_function_("eof", "src/io/InputStream.birch", 42);
  #line 43 "src/io/InputStream.birch"
  libbirch_line_(43);
  #line 43 "src/io/InputStream.birch"
  libbirch_assert_(this_()->file.query());
  #line 44 "src/io/InputStream.birch"
return ::feof(this->file.get());
    }

#line 52 "src/io/InputStream.birch"
libbirch::Optional<birch::type::Integer> birch::type::InputStream::scanInteger(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "src/io/InputStream.birch"
  libbirch_function_("scanInteger", "src/io/InputStream.birch", 52);
  #line 53 "src/io/InputStream.birch"
  libbirch_line_(53);
  #line 53 "src/io/InputStream.birch"
  libbirch_assert_(this_()->file.query());
  #line 54 "src/io/InputStream.birch"
  libbirch_line_(54);
  #line 54 "src/io/InputStream.birch"
  libbirch::Optional<birch::type::Integer> x;
  #line 55 "src/io/InputStream.birch"
long long int y;  // ensure fscanf gets exactly the type it expects
    auto res = ::fscanf(this->file.get(), "%lld", &y);
    if (res == 1) {
      x = (birch::type::Integer)y;
    } 
      #line 62 "src/io/InputStream.birch"
  libbirch_line_(62);
  #line 62 "src/io/InputStream.birch"
  return x;
}

#line 68 "src/io/InputStream.birch"
libbirch::Optional<birch::type::Real> birch::type::InputStream::scanReal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 68 "src/io/InputStream.birch"
  libbirch_function_("scanReal", "src/io/InputStream.birch", 68);
  #line 69 "src/io/InputStream.birch"
  libbirch_line_(69);
  #line 69 "src/io/InputStream.birch"
  libbirch_assert_(this_()->file.query());
  #line 70 "src/io/InputStream.birch"
  libbirch_line_(70);
  #line 70 "src/io/InputStream.birch"
  libbirch::Optional<birch::type::Real> x;
  #line 71 "src/io/InputStream.birch"
double y;  // ensure fscanf gets exactly the type it expects
    auto res = ::fscanf(this->file.get(), "%lf", &y);
    if (res == 1) {
      x = y;
    } 
      #line 78 "src/io/InputStream.birch"
  libbirch_line_(78);
  #line 78 "src/io/InputStream.birch"
  return x;
}

#line 1 "src/io/InputStream.birch"
birch::type::InputStream* birch::type::make_InputStream_() {
  #line 1 "src/io/InputStream.birch"
  return new birch::type::InputStream();
  #line 1 "src/io/InputStream.birch"
}

#line 85 "src/io/InputStream.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InputStream>> birch::InputStream(const birch::type::File& file, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 85 "src/io/InputStream.birch"
  libbirch_function_("InputStream", "src/io/InputStream.birch", 85);
  #line 86 "src/io/InputStream.birch"
  libbirch_line_(86);
  #line 86 "src/io/InputStream.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::InputStream>> o;
  #line 87 "src/io/InputStream.birch"
  libbirch_line_(87);
  #line 87 "src/io/InputStream.birch"
  o->file = file;
  #line 88 "src/io/InputStream.birch"
  libbirch_line_(88);
  #line 88 "src/io/InputStream.birch"
  return o;
}

#line 1 "src/io/JSONWriter.birch"
birch::type::JSONWriter::JSONWriter(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/io/JSONWriter.birch"
    super_type_() {
  //
}

#line 14 "src/io/JSONWriter.birch"
void birch::type::JSONWriter::startMapping(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/io/JSONWriter.birch"
  libbirch_function_("startMapping", "src/io/JSONWriter.birch", 14);
  #line 15 "src/io/JSONWriter.birch"
yaml_mapping_start_event_initialize(&this->event, NULL, NULL, 1,
        YAML_FLOW_MAPPING_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 22 "src/io/JSONWriter.birch"
void birch::type::JSONWriter::startSequence(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/io/JSONWriter.birch"
  libbirch_function_("startSequence", "src/io/JSONWriter.birch", 22);
  #line 23 "src/io/JSONWriter.birch"
yaml_sequence_start_event_initialize(&this->event, NULL, NULL, 1,
        YAML_FLOW_SEQUENCE_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 30 "src/io/JSONWriter.birch"
void birch::type::JSONWriter::scalar(const birch::type::String& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/io/JSONWriter.birch"
  libbirch_function_("scalar", "src/io/JSONWriter.birch", 30);
  #line 31 "src/io/JSONWriter.birch"
yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)value.c_str(), value.length(), 1, 1,
        YAML_DOUBLE_QUOTED_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 1 "src/io/JSONWriter.birch"
birch::type::JSONWriter* birch::type::make_JSONWriter_() {
  #line 1 "src/io/JSONWriter.birch"
  return new birch::type::JSONWriter();
  #line 1 "src/io/JSONWriter.birch"
}

#line 1 "src/io/OutputStream.birch"
birch::type::OutputStream::OutputStream(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/io/OutputStream.birch"
    super_type_(),
    #line 8 "src/io/OutputStream.birch"
    file() {
  //
}

#line 16 "src/io/OutputStream.birch"
void birch::type::OutputStream::open(const birch::type::String& path, const birch::type::Integer& mode, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/io/OutputStream.birch"
  libbirch_function_("open", "src/io/OutputStream.birch", 16);
  #line 17 "src/io/OutputStream.birch"
  libbirch_line_(17);
  #line 17 "src/io/OutputStream.birch"
  this_()->file = birch::fopen(path, mode, handler_);
}

#line 25 "src/io/OutputStream.birch"
void birch::type::OutputStream::open(const birch::type::String& path, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/io/OutputStream.birch"
  libbirch_function_("open", "src/io/OutputStream.birch", 25);
  #line 26 "src/io/OutputStream.birch"
  libbirch_line_(26);
  #line 26 "src/io/OutputStream.birch"
  this_()->open(path, birch::WRITE(), handler_);
}

#line 32 "src/io/OutputStream.birch"
void birch::type::OutputStream::close(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/io/OutputStream.birch"
  libbirch_function_("close", "src/io/OutputStream.birch", 32);
  #line 33 "src/io/OutputStream.birch"
  libbirch_line_(33);
  #line 33 "src/io/OutputStream.birch"
  libbirch_assert_(this_()->file.query());
  #line 34 "src/io/OutputStream.birch"
  libbirch_line_(34);
  #line 34 "src/io/OutputStream.birch"
  birch::fclose(this_()->file.get(), handler_);
  #line 35 "src/io/OutputStream.birch"
  libbirch_line_(35);
  #line 35 "src/io/OutputStream.birch"
  this_()->file = libbirch::nil;
}

#line 41 "src/io/OutputStream.birch"
void birch::type::OutputStream::flush(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "src/io/OutputStream.birch"
  libbirch_function_("flush", "src/io/OutputStream.birch", 41);
  #line 42 "src/io/OutputStream.birch"
  libbirch_line_(42);
  #line 42 "src/io/OutputStream.birch"
  libbirch_assert_(this_()->file.query());
  #line 43 "src/io/OutputStream.birch"
  libbirch_line_(43);
  #line 43 "src/io/OutputStream.birch"
  birch::fflush(this_()->file.get(), handler_);
}

#line 49 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const birch::type::String& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 49);
  #line 50 "src/io/OutputStream.birch"
  libbirch_line_(50);
  #line 50 "src/io/OutputStream.birch"
  libbirch_assert_(this_()->file.query());
  #line 51 "src/io/OutputStream.birch"
::fprintf(this->file.get(), "%s", value.c_str());
    }

#line 59 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const birch::type::Boolean& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 59);
  #line 60 "src/io/OutputStream.birch"
  libbirch_line_(60);
  #line 60 "src/io/OutputStream.birch"
  this_()->print(birch::String(value, handler_), handler_);
}

#line 66 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const birch::type::Integer& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 66);
  #line 67 "src/io/OutputStream.birch"
  libbirch_line_(67);
  #line 67 "src/io/OutputStream.birch"
  this_()->print(birch::String(value, handler_), handler_);
}

#line 73 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const birch::type::Real& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 73 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 73);
  #line 74 "src/io/OutputStream.birch"
  libbirch_line_(74);
  #line 74 "src/io/OutputStream.birch"
  this_()->print(birch::String(value, handler_), handler_);
}

#line 80 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const libbirch::DefaultArray<birch::type::Boolean,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 80 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 80);
  #line 81 "src/io/OutputStream.birch"
  libbirch_line_(81);
  #line 81 "src/io/OutputStream.birch"
  this_()->print(birch::String(value, handler_), handler_);
}

#line 87 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const libbirch::DefaultArray<birch::type::Integer,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 87 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 87);
  #line 88 "src/io/OutputStream.birch"
  libbirch_line_(88);
  #line 88 "src/io/OutputStream.birch"
  this_()->print(birch::String(value, handler_), handler_);
}

#line 94 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const libbirch::DefaultArray<birch::type::Real,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 94 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 94);
  #line 95 "src/io/OutputStream.birch"
  libbirch_line_(95);
  #line 95 "src/io/OutputStream.birch"
  this_()->print(birch::String(value, handler_), handler_);
}

#line 101 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const libbirch::DefaultArray<birch::type::Boolean,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 101 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 101);
  #line 102 "src/io/OutputStream.birch"
  libbirch_line_(102);
  #line 102 "src/io/OutputStream.birch"
  this_()->print(birch::String(value, handler_), handler_);
}

#line 108 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const libbirch::DefaultArray<birch::type::Integer,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 108 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 108);
  #line 109 "src/io/OutputStream.birch"
  libbirch_line_(109);
  #line 109 "src/io/OutputStream.birch"
  this_()->print(birch::String(value, handler_), handler_);
}

#line 115 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const libbirch::DefaultArray<birch::type::Real,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 115 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 115);
  #line 116 "src/io/OutputStream.birch"
  libbirch_line_(116);
  #line 116 "src/io/OutputStream.birch"
  this_()->print(birch::String(value, handler_), handler_);
}

#line 122 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const birch::type::LLT& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 122 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 122);
  #line 123 "src/io/OutputStream.birch"
  libbirch_line_(123);
  #line 123 "src/io/OutputStream.birch"
  this_()->print(birch::String(value, handler_), handler_);
}

#line 1 "src/io/OutputStream.birch"
birch::type::OutputStream* birch::type::make_OutputStream_() {
  #line 1 "src/io/OutputStream.birch"
  return new birch::type::OutputStream();
  #line 1 "src/io/OutputStream.birch"
}

#line 130 "src/io/OutputStream.birch"
libbirch::Lazy<libbirch::Shared<birch::type::OutputStream>> birch::OutputStream(const birch::type::File& file, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 130 "src/io/OutputStream.birch"
  libbirch_function_("OutputStream", "src/io/OutputStream.birch", 130);
  #line 131 "src/io/OutputStream.birch"
  libbirch_line_(131);
  #line 131 "src/io/OutputStream.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::OutputStream>> o;
  #line 132 "src/io/OutputStream.birch"
  libbirch_line_(132);
  #line 132 "src/io/OutputStream.birch"
  o->file = file;
  #line 133 "src/io/OutputStream.birch"
  libbirch_line_(133);
  #line 133 "src/io/OutputStream.birch"
  return o;
}

#line 38 "src/io/Reader.birch"
birch::type::Reader::Reader(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 38 "src/io/Reader.birch"
    super_type_() {
  //
}

#line 69 "src/io/Reader.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Reader>> birch::Reader(const birch::type::String& path, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "src/io/Reader.birch"
  libbirch_function_("Reader", "src/io/Reader.birch", 69);
  #line 70 "src/io/Reader.birch"
  libbirch_line_(70);
  #line 70 "src/io/Reader.birch"
  auto ext = birch::extension(path, handler_);
  #line 71 "src/io/Reader.birch"
  libbirch_line_(71);
  #line 71 "src/io/Reader.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Reader>>> result;
  #line 72 "src/io/Reader.birch"
  libbirch_line_(72);
  #line 72 "src/io/Reader.birch"
  if (ext == birch::type::String(".json")) {
    #line 73 "src/io/Reader.birch"
    libbirch_line_(73);
    #line 73 "src/io/Reader.birch"
    libbirch::Lazy<libbirch::Shared<birch::type::JSONReader>> reader;
    #line 74 "src/io/Reader.birch"
    libbirch_line_(74);
    #line 74 "src/io/Reader.birch"
    reader->open(path, handler_);
    #line 75 "src/io/Reader.birch"
    libbirch_line_(75);
    #line 75 "src/io/Reader.birch"
    result = reader;
  } else {
    #line 76 "src/io/Reader.birch"
    libbirch_line_(76);
    #line 76 "src/io/Reader.birch"
    if (ext == birch::type::String(".yml") || ext == birch::type::String(".yaml")) {
      #line 77 "src/io/Reader.birch"
      libbirch_line_(77);
      #line 77 "src/io/Reader.birch"
      libbirch::Lazy<libbirch::Shared<birch::type::YAMLReader>> reader;
      #line 78 "src/io/Reader.birch"
      libbirch_line_(78);
      #line 78 "src/io/Reader.birch"
      reader->open(path, handler_);
      #line 79 "src/io/Reader.birch"
      libbirch_line_(79);
      #line 79 "src/io/Reader.birch"
      result = reader;
    }
  }
  #line 81 "src/io/Reader.birch"
  libbirch_line_(81);
  #line 81 "src/io/Reader.birch"
  if (!result.query()) {
    #line 82 "src/io/Reader.birch"
    libbirch_line_(82);
    #line 82 "src/io/Reader.birch"
    birch::error(birch::type::String("unrecognized file extension '") + ext + birch::type::String("' in path '") + path + birch::type::String("'; supported extensions are '.json', '.yml' and '.yaml'."), handler_);
  }
  #line 85 "src/io/Reader.birch"
  libbirch_line_(85);
  #line 85 "src/io/Reader.birch"
  return result.get();
}

#line 37 "src/io/Writer.birch"
birch::type::Writer::Writer(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 37 "src/io/Writer.birch"
    super_type_() {
  //
}

#line 93 "src/io/Writer.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Writer>> birch::Writer(const birch::type::String& path, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 93 "src/io/Writer.birch"
  libbirch_function_("Writer", "src/io/Writer.birch", 93);
  #line 94 "src/io/Writer.birch"
  libbirch_line_(94);
  #line 94 "src/io/Writer.birch"
  auto ext = birch::extension(path, handler_);
  #line 95 "src/io/Writer.birch"
  libbirch_line_(95);
  #line 95 "src/io/Writer.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Writer>>> result;
  #line 96 "src/io/Writer.birch"
  libbirch_line_(96);
  #line 96 "src/io/Writer.birch"
  if (ext == birch::type::String(".json")) {
    #line 97 "src/io/Writer.birch"
    libbirch_line_(97);
    #line 97 "src/io/Writer.birch"
    libbirch::Lazy<libbirch::Shared<birch::type::JSONWriter>> writer;
    #line 98 "src/io/Writer.birch"
    libbirch_line_(98);
    #line 98 "src/io/Writer.birch"
    writer->open(path, handler_);
    #line 99 "src/io/Writer.birch"
    libbirch_line_(99);
    #line 99 "src/io/Writer.birch"
    result = writer;
  } else {
    #line 100 "src/io/Writer.birch"
    libbirch_line_(100);
    #line 100 "src/io/Writer.birch"
    if (ext == birch::type::String(".yml")) {
      #line 101 "src/io/Writer.birch"
      libbirch_line_(101);
      #line 101 "src/io/Writer.birch"
      libbirch::Lazy<libbirch::Shared<birch::type::YAMLWriter>> writer;
      #line 102 "src/io/Writer.birch"
      libbirch_line_(102);
      #line 102 "src/io/Writer.birch"
      writer->open(path, handler_);
      #line 103 "src/io/Writer.birch"
      libbirch_line_(103);
      #line 103 "src/io/Writer.birch"
      result = writer;
    }
  }
  #line 105 "src/io/Writer.birch"
  libbirch_line_(105);
  #line 105 "src/io/Writer.birch"
  if (!result.query()) {
    #line 106 "src/io/Writer.birch"
    libbirch_line_(106);
    #line 106 "src/io/Writer.birch"
    birch::error(birch::type::String("unrecognized file extension '") + ext + birch::type::String("' in path '") + path + birch::type::String("'; supported extensions are '.json' and '.yml'."), handler_);
  }
  #line 109 "src/io/Writer.birch"
  libbirch_line_(109);
  #line 109 "src/io/Writer.birch"
  return result.get();
}

#line 3 "src/io/YAMLReader.birch"
birch::type::YAMLReader::YAMLReader(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 3 "src/io/YAMLReader.birch"
    super_type_(),
    #line 28 "src/io/YAMLReader.birch"
    file() {
  //
}

#line 35 "src/io/YAMLReader.birch"
void birch::type::YAMLReader::open(const birch::type::String& path, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "src/io/YAMLReader.birch"
  libbirch_function_("open", "src/io/YAMLReader.birch", 35);
  #line 36 "src/io/YAMLReader.birch"
  libbirch_line_(36);
  #line 36 "src/io/YAMLReader.birch"
  this_()->file = birch::fopen(path, birch::READ(), handler_);
  #line 37 "src/io/YAMLReader.birch"
yaml_parser_initialize(&this->parser);
    yaml_parser_set_input_file(&this->parser, this->file);
    }

#line 43 "src/io/YAMLReader.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> birch::type::YAMLReader::slurp(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "src/io/YAMLReader.birch"
  libbirch_function_("slurp", "src/io/YAMLReader.birch", 43);
  #line 44 "src/io/YAMLReader.birch"
  libbirch_line_(44);
  #line 44 "src/io/YAMLReader.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> buffer;
  #line 45 "src/io/YAMLReader.birch"
int done = 0;
    while (!done) {
      if (!yaml_parser_parse(&this->parser, &this->event)) {
        error("parse error");
      }
      if (this->event.type == YAML_SEQUENCE_START_EVENT) {
        this->parseSequence(buffer);
      } else if (this->event.type == YAML_MAPPING_START_EVENT) {
        this->parseMapping(buffer);
      } else {
        done = this->event.type == YAML_STREAM_END_EVENT;
        yaml_event_delete(&this->event);
      }
    }
    yaml_parser_delete(&this->parser);
      #line 62 "src/io/YAMLReader.birch"
  libbirch_line_(62);
  #line 62 "src/io/YAMLReader.birch"
  return buffer;
}

#line 65 "src/io/YAMLReader.birch"
birch::type::Boolean birch::type::YAMLReader::hasNext(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "src/io/YAMLReader.birch"
  libbirch_function_("hasNext", "src/io/YAMLReader.birch", 65);
  #line 66 "src/io/YAMLReader.birch"
bool repeat = false, eof = false;
    do {
      if (!yaml_parser_parse(&this->parser, &this->event)) {
        error("parse error");
      }
      switch (this->event.type) {
        case YAML_SCALAR_EVENT:
        case YAML_SEQUENCE_START_EVENT:
        case YAML_MAPPING_START_EVENT:
          break;
        case YAML_STREAM_END_EVENT:
          eof = true;
          break;
        default:
          yaml_event_delete(&this->event);
          repeat = true;
          break;
      }
    } while (repeat);
    return !eof;
    }

#line 90 "src/io/YAMLReader.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> birch::type::YAMLReader::next(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 90 "src/io/YAMLReader.birch"
  libbirch_function_("next", "src/io/YAMLReader.birch", 90);
  #line 91 "src/io/YAMLReader.birch"
  libbirch_line_(91);
  #line 91 "src/io/YAMLReader.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> buffer;
  #line 92 "src/io/YAMLReader.birch"
switch (this->event.type) {
      case YAML_SCALAR_EVENT:
        this->parseValue(buffer);
        break;
      case YAML_SEQUENCE_START_EVENT:
        this->parseSequence(buffer);
        break;
      case YAML_MAPPING_START_EVENT:
        this->parseMapping(buffer);
        break;
      default:
        /* hasNext() should have dealt with all other events */
        assert(false);
    }
      #line 108 "src/io/YAMLReader.birch"
  libbirch_line_(108);
  #line 108 "src/io/YAMLReader.birch"
  return buffer;
}

#line 111 "src/io/YAMLReader.birch"
void birch::type::YAMLReader::close(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 111 "src/io/YAMLReader.birch"
  libbirch_function_("close", "src/io/YAMLReader.birch", 111);
  #line 112 "src/io/YAMLReader.birch"
  libbirch_line_(112);
  #line 112 "src/io/YAMLReader.birch"
  birch::fclose(this_()->file, handler_);
}

#line 115 "src/io/YAMLReader.birch"
void birch::type::YAMLReader::parseMapping(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 115 "src/io/YAMLReader.birch"
  libbirch_function_("parseMapping", "src/io/YAMLReader.birch", 115);
  #line 116 "src/io/YAMLReader.birch"
yaml_event_delete(&this->event);
    int done = 0;
    while (!done) {
      /* read one name/value pair on each iteration */
      if (!yaml_parser_parse(&this->parser, &this->event)) {
        error("parse error");
      }
      if (this->event.type == YAML_SCALAR_EVENT) {
        /* key */
        char* data = (char*)this->event.data.scalar.value;
        size_t length = this->event.data.scalar.length;
        std::string key(data, length);
        yaml_event_delete(&this->event);
        
        /* value */
        if (!yaml_parser_parse(&this->parser, &this->event)) {
          error("parse error");
        }
        auto value = birch::Buffer();
        buffer->insert(key, value);
        if (this->event.type == YAML_SCALAR_EVENT) {
          this->parseValue(value);
        } else if (this->event.type == YAML_SEQUENCE_START_EVENT) {
          this->parseSequence(value);
        } else if (this->event.type == YAML_MAPPING_START_EVENT) {
          this->parseMapping(value);
        } else {
          yaml_event_delete(&this->event);
        }
      } else {
        done = this->event.type == YAML_MAPPING_END_EVENT;
        yaml_event_delete(&this->event);
      }
    }
    }

#line 154 "src/io/YAMLReader.birch"
void birch::type::YAMLReader::parseSequence(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 154 "src/io/YAMLReader.birch"
  libbirch_function_("parseSequence", "src/io/YAMLReader.birch", 154);
  #line 155 "src/io/YAMLReader.birch"
yaml_event_delete(&this->event);
    int done = 0;
    while (!done) {
      if (!yaml_parser_parse(&this->parser, &this->event)) {
        error("parse error");
      }
      if (this->event.type == YAML_SCALAR_EVENT) {
        this->parseElement(buffer);
      } else if (this->event.type == YAML_SEQUENCE_START_EVENT) {
        auto element = birch::Buffer();
        buffer->insert(element);
        this->parseSequence(element);
      } else if (this->event.type == YAML_MAPPING_START_EVENT) {
        auto element = birch::Buffer();
        buffer->insert(element);
        this->parseMapping(element);
      } else {
        done = this->event.type == YAML_SEQUENCE_END_EVENT;
        yaml_event_delete(&this->event);
      }
    }
    }

#line 180 "src/io/YAMLReader.birch"
void birch::type::YAMLReader::parseValue(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 180 "src/io/YAMLReader.birch"
  libbirch_function_("parseValue", "src/io/YAMLReader.birch", 180);
  #line 181 "src/io/YAMLReader.birch"
auto data = (char*)this->event.data.scalar.value;
    auto length = this->event.data.scalar.length;
    auto endptr = data;
    auto intValue = int64_t(std::strtoll(data, &endptr, 10));
    if (endptr == data + length) {
      buffer->set(intValue);
    } else {
      auto realValue = std::strtod(data, &endptr);
      if (endptr == data + length) {
        buffer->set(realValue);
      } else if (std::strcmp(data, "true") == 0) {
        buffer->set(true);
      } else if (std::strcmp(data, "false") == 0) {
        buffer->set(false);
      } else if (std::strcmp(data, "null") == 0) {
        buffer->setNil();
      } else if (std::strcmp(data, "Infinity") == 0) {
        buffer->set(std::numeric_limits<Real>::infinity());
      } else if (std::strcmp(data, "-Infinity") == 0) {
        buffer->set(-std::numeric_limits<Real>::infinity());
      } else if (std::strcmp(data, "NaN") == 0) {
        buffer->set(std::numeric_limits<Real>::quiet_NaN());
      } else {
        buffer->set(std::string(data, length));
      }
    }
    yaml_event_delete(&this->event);
    }

#line 212 "src/io/YAMLReader.birch"
void birch::type::YAMLReader::parseElement(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 212 "src/io/YAMLReader.birch"
  libbirch_function_("parseElement", "src/io/YAMLReader.birch", 212);
  #line 213 "src/io/YAMLReader.birch"
auto data = (char*)this->event.data.scalar.value;
    auto length = this->event.data.scalar.length;
    auto endptr = data;
    auto intValue = int64_t(std::strtoll(data, &endptr, 10));
    if (endptr == data + length) {
      buffer->push(intValue);
    } else {
      auto realValue = std::strtod(data, &endptr);
      if (endptr == data + length) {
        buffer->push(realValue);
      } else if (std::strcmp(data, "true") == 0) {
        buffer->push(true);
      } else if (std::strcmp(data, "false") == 0) {
        buffer->push(false);
      } else if (std::strcmp(data, "null") == 0) {
        buffer->pushNil();
      } else if (std::strcmp(data, "Infinity") == 0) {
        buffer->push(std::numeric_limits<Real>::infinity());
      } else if (std::strcmp(data, "-Infinity") == 0) {
        buffer->push(-std::numeric_limits<Real>::infinity());
      } else if (std::strcmp(data, "NaN") == 0) {
        buffer->push(std::numeric_limits<Real>::quiet_NaN());
      } else {
        buffer->push(std::string(data, length));
      }
    }
    yaml_event_delete(&this->event);
    }

#line 3 "src/io/YAMLReader.birch"
birch::type::YAMLReader* birch::type::make_YAMLReader_() {
  #line 3 "src/io/YAMLReader.birch"
  return new birch::type::YAMLReader();
  #line 3 "src/io/YAMLReader.birch"
}

#line 3 "src/io/YAMLWriter.birch"
birch::type::YAMLWriter::YAMLWriter(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 3 "src/io/YAMLWriter.birch"
    super_type_(),
    #line 21 "src/io/YAMLWriter.birch"
    file(),
    #line 26 "src/io/YAMLWriter.birch"
    sequential(false) {
  //
}

#line 33 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::open(const birch::type::String& path, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/io/YAMLWriter.birch"
  libbirch_function_("open", "src/io/YAMLWriter.birch", 33);
  #line 34 "src/io/YAMLWriter.birch"
  libbirch_line_(34);
  #line 34 "src/io/YAMLWriter.birch"
  this_()->file = birch::fopen(path, birch::WRITE(), handler_);
  #line 35 "src/io/YAMLWriter.birch"
yaml_emitter_initialize(&this->emitter);
    yaml_emitter_set_unicode(&this->emitter, 1);
    yaml_emitter_set_output_file(&this->emitter, this->file);
    yaml_stream_start_event_initialize(&this->event, YAML_UTF8_ENCODING);
    yaml_emitter_emit(&this->emitter, &this->event);
    yaml_document_start_event_initialize(&this->event, NULL, NULL, NULL, 1);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 46 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::dump(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/io/YAMLWriter.birch"
  libbirch_function_("dump", "src/io/YAMLWriter.birch", 46);
  #line 47 "src/io/YAMLWriter.birch"
  libbirch_line_(47);
  #line 47 "src/io/YAMLWriter.birch"
  buffer->accept(shared_from_this_(), handler_);
}

#line 50 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::push(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "src/io/YAMLWriter.birch"
  libbirch_function_("push", "src/io/YAMLWriter.birch", 50);
  #line 51 "src/io/YAMLWriter.birch"
  libbirch_line_(51);
  #line 51 "src/io/YAMLWriter.birch"
  if (!this_()->sequential) {
    #line 52 "src/io/YAMLWriter.birch"
    libbirch_line_(52);
    #line 52 "src/io/YAMLWriter.birch"
    this_()->startSequence(handler_);
    #line 53 "src/io/YAMLWriter.birch"
    libbirch_line_(53);
    #line 53 "src/io/YAMLWriter.birch"
    this_()->sequential = true;
  }
  #line 55 "src/io/YAMLWriter.birch"
  libbirch_line_(55);
  #line 55 "src/io/YAMLWriter.birch"
  buffer->accept(shared_from_this_(), handler_);
}

#line 58 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::flush(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "src/io/YAMLWriter.birch"
  libbirch_function_("flush", "src/io/YAMLWriter.birch", 58);
  #line 59 "src/io/YAMLWriter.birch"
yaml_emitter_flush(&this->emitter);
      #line 62 "src/io/YAMLWriter.birch"
  libbirch_line_(62);
  #line 62 "src/io/YAMLWriter.birch"
  birch::fflush(this_()->file, handler_);
}

#line 65 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::close(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "src/io/YAMLWriter.birch"
  libbirch_function_("close", "src/io/YAMLWriter.birch", 65);
  #line 66 "src/io/YAMLWriter.birch"
  libbirch_line_(66);
  #line 66 "src/io/YAMLWriter.birch"
  if (this_()->sequential) {
    #line 67 "src/io/YAMLWriter.birch"
    libbirch_line_(67);
    #line 67 "src/io/YAMLWriter.birch"
    this_()->endSequence(handler_);
  }
  #line 69 "src/io/YAMLWriter.birch"
yaml_document_end_event_initialize(&this->event, 1);
    yaml_emitter_emit(&this->emitter, &this->event);
    yaml_stream_end_event_initialize(&this->event);
    yaml_emitter_emit(&this->emitter, &this->event);
    yaml_emitter_delete(&this->emitter);
      #line 76 "src/io/YAMLWriter.birch"
  libbirch_line_(76);
  #line 76 "src/io/YAMLWriter.birch"
  birch::fclose(this_()->file, handler_);
}

#line 79 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::Lazy<libbirch::Shared<birch::type::ObjectValue>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 79 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 79);
  #line 80 "src/io/YAMLWriter.birch"
  libbirch_line_(80);
  #line 80 "src/io/YAMLWriter.birch"
  this_()->startMapping(handler_);
  #line 81 "src/io/YAMLWriter.birch"
  libbirch_line_(81);
  #line 81 "src/io/YAMLWriter.birch"
  auto iter = value->entries->walk(handler_);
  #line 82 "src/io/YAMLWriter.birch"
  libbirch_line_(82);
  #line 82 "src/io/YAMLWriter.birch"
  while (iter->hasNext(handler_)) {
    #line 83 "src/io/YAMLWriter.birch"
    libbirch_line_(83);
    #line 83 "src/io/YAMLWriter.birch"
    auto entry = iter->next(handler_);
    #line 84 "src/io/YAMLWriter.birch"
    libbirch_line_(84);
    #line 84 "src/io/YAMLWriter.birch"
    this_()->scalar(entry->key, handler_);
    #line 85 "src/io/YAMLWriter.birch"
    libbirch_line_(85);
    #line 85 "src/io/YAMLWriter.birch"
    entry->value->accept(shared_from_this_(), handler_);
  }
  #line 87 "src/io/YAMLWriter.birch"
  libbirch_line_(87);
  #line 87 "src/io/YAMLWriter.birch"
  this_()->endMapping(handler_);
}

#line 90 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::Lazy<libbirch::Shared<birch::type::ArrayValue>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 90 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 90);
  #line 91 "src/io/YAMLWriter.birch"
  libbirch_line_(91);
  #line 91 "src/io/YAMLWriter.birch"
  this_()->startSequence(handler_);
  #line 92 "src/io/YAMLWriter.birch"
  libbirch_line_(92);
  #line 92 "src/io/YAMLWriter.birch"
  auto iter = value->walk(handler_);
  #line 93 "src/io/YAMLWriter.birch"
  libbirch_line_(93);
  #line 93 "src/io/YAMLWriter.birch"
  while (iter->hasNext(handler_)) {
    #line 94 "src/io/YAMLWriter.birch"
    libbirch_line_(94);
    #line 94 "src/io/YAMLWriter.birch"
    iter->next(handler_)->accept(shared_from_this_(), handler_);
  }
  #line 96 "src/io/YAMLWriter.birch"
  libbirch_line_(96);
  #line 96 "src/io/YAMLWriter.birch"
  this_()->endSequence(handler_);
}

#line 99 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::Lazy<libbirch::Shared<birch::type::StringValue>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 99 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 99);
  #line 100 "src/io/YAMLWriter.birch"
  libbirch_line_(100);
  #line 100 "src/io/YAMLWriter.birch"
  this_()->scalar(value->value, handler_);
}

#line 103 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::Lazy<libbirch::Shared<birch::type::RealValue>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 103 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 103);
  #line 104 "src/io/YAMLWriter.birch"
  libbirch_line_(104);
  #line 104 "src/io/YAMLWriter.birch"
  this_()->scalar(value->value, handler_);
}

#line 107 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::Lazy<libbirch::Shared<birch::type::IntegerValue>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 107 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 107);
  #line 108 "src/io/YAMLWriter.birch"
  libbirch_line_(108);
  #line 108 "src/io/YAMLWriter.birch"
  this_()->scalar(value->value, handler_);
}

#line 111 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::Lazy<libbirch::Shared<birch::type::BooleanValue>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 111 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 111);
  #line 112 "src/io/YAMLWriter.birch"
  libbirch_line_(112);
  #line 112 "src/io/YAMLWriter.birch"
  this_()->scalar(value->value, handler_);
}

#line 115 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::Lazy<libbirch::Shared<birch::type::NilValue>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 115 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 115);
  #line 116 "src/io/YAMLWriter.birch"
  libbirch_line_(116);
  #line 116 "src/io/YAMLWriter.birch"
  this_()->null(handler_);
}

#line 119 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::Lazy<libbirch::Shared<birch::type::BooleanVectorValue>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 119 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 119);
  #line 120 "src/io/YAMLWriter.birch"
  libbirch_line_(120);
  #line 120 "src/io/YAMLWriter.birch"
  this_()->startSequence(handler_);
  #line 121 "src/io/YAMLWriter.birch"
  libbirch_line_(121);
  #line 121 "src/io/YAMLWriter.birch"
  auto v = value->value;
  #line 122 "src/io/YAMLWriter.birch"
  libbirch_line_(122);
  #line 122 "src/io/YAMLWriter.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(v, handler_); ++i) {
    #line 123 "src/io/YAMLWriter.birch"
    libbirch_line_(123);
    #line 123 "src/io/YAMLWriter.birch"
    this_()->scalar(v.get(libbirch::make_slice(i - 1)), handler_);
  }
  #line 125 "src/io/YAMLWriter.birch"
  libbirch_line_(125);
  #line 125 "src/io/YAMLWriter.birch"
  this_()->endSequence(handler_);
}

#line 128 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::Lazy<libbirch::Shared<birch::type::IntegerVectorValue>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 128 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 128);
  #line 129 "src/io/YAMLWriter.birch"
  libbirch_line_(129);
  #line 129 "src/io/YAMLWriter.birch"
  this_()->startSequence(handler_);
  #line 130 "src/io/YAMLWriter.birch"
  libbirch_line_(130);
  #line 130 "src/io/YAMLWriter.birch"
  auto v = value->value;
  #line 131 "src/io/YAMLWriter.birch"
  libbirch_line_(131);
  #line 131 "src/io/YAMLWriter.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(v, handler_); ++i) {
    #line 132 "src/io/YAMLWriter.birch"
    libbirch_line_(132);
    #line 132 "src/io/YAMLWriter.birch"
    this_()->scalar(v.get(libbirch::make_slice(i - 1)), handler_);
  }
  #line 134 "src/io/YAMLWriter.birch"
  libbirch_line_(134);
  #line 134 "src/io/YAMLWriter.birch"
  this_()->endSequence(handler_);
}

#line 137 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::Lazy<libbirch::Shared<birch::type::RealVectorValue>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 137 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 137);
  #line 138 "src/io/YAMLWriter.birch"
  libbirch_line_(138);
  #line 138 "src/io/YAMLWriter.birch"
  this_()->startSequence(handler_);
  #line 139 "src/io/YAMLWriter.birch"
  libbirch_line_(139);
  #line 139 "src/io/YAMLWriter.birch"
  auto v = value->value;
  #line 140 "src/io/YAMLWriter.birch"
  libbirch_line_(140);
  #line 140 "src/io/YAMLWriter.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(v, handler_); ++i) {
    #line 141 "src/io/YAMLWriter.birch"
    libbirch_line_(141);
    #line 141 "src/io/YAMLWriter.birch"
    this_()->scalar(v.get(libbirch::make_slice(i - 1)), handler_);
  }
  #line 143 "src/io/YAMLWriter.birch"
  libbirch_line_(143);
  #line 143 "src/io/YAMLWriter.birch"
  this_()->endSequence(handler_);
}

#line 146 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::startMapping(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 146 "src/io/YAMLWriter.birch"
  libbirch_function_("startMapping", "src/io/YAMLWriter.birch", 146);
  #line 147 "src/io/YAMLWriter.birch"
yaml_mapping_start_event_initialize(&this->event, NULL, NULL, 1,
        YAML_ANY_MAPPING_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 154 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::endMapping(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 154 "src/io/YAMLWriter.birch"
  libbirch_function_("endMapping", "src/io/YAMLWriter.birch", 154);
  #line 155 "src/io/YAMLWriter.birch"
yaml_mapping_end_event_initialize(&this->event);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 161 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::startSequence(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 161 "src/io/YAMLWriter.birch"
  libbirch_function_("startSequence", "src/io/YAMLWriter.birch", 161);
  #line 162 "src/io/YAMLWriter.birch"
yaml_sequence_start_event_initialize(&this->event, NULL, NULL, 1,
        YAML_ANY_SEQUENCE_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 169 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::endSequence(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 169 "src/io/YAMLWriter.birch"
  libbirch_function_("endSequence", "src/io/YAMLWriter.birch", 169);
  #line 170 "src/io/YAMLWriter.birch"
yaml_sequence_end_event_initialize(&this->event);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 176 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::scalar(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 176 "src/io/YAMLWriter.birch"
  libbirch_function_("scalar", "src/io/YAMLWriter.birch", 176);
  #line 177 "src/io/YAMLWriter.birch"
  libbirch_line_(177);
  #line 177 "src/io/YAMLWriter.birch"
  auto value = birch::String(x, handler_);
  #line 178 "src/io/YAMLWriter.birch"
yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)value.c_str(), value.length(), 1, 1,
        YAML_ANY_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 186 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::scalar(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 186 "src/io/YAMLWriter.birch"
  libbirch_function_("scalar", "src/io/YAMLWriter.birch", 186);
  #line 187 "src/io/YAMLWriter.birch"
  libbirch_line_(187);
  #line 187 "src/io/YAMLWriter.birch"
  auto value = birch::String(x, handler_);
  #line 188 "src/io/YAMLWriter.birch"
yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)value.c_str(), value.length(), 1, 1,
        YAML_ANY_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 196 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::scalar(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 196 "src/io/YAMLWriter.birch"
  libbirch_function_("scalar", "src/io/YAMLWriter.birch", 196);
  #line 200 "src/io/YAMLWriter.birch"
  libbirch_line_(200);
  #line 200 "src/io/YAMLWriter.birch"
  birch::type::String value;
  #line 201 "src/io/YAMLWriter.birch"
  libbirch_line_(201);
  #line 201 "src/io/YAMLWriter.birch"
  if (x == birch::inf()) {
    #line 202 "src/io/YAMLWriter.birch"
    libbirch_line_(202);
    #line 202 "src/io/YAMLWriter.birch"
    value = birch::type::String("Infinity");
  } else {
    #line 203 "src/io/YAMLWriter.birch"
    libbirch_line_(203);
    #line 203 "src/io/YAMLWriter.birch"
    if (x == -birch::inf()) {
      #line 204 "src/io/YAMLWriter.birch"
      libbirch_line_(204);
      #line 204 "src/io/YAMLWriter.birch"
      value = birch::type::String("-Infinity");
    } else {
      #line 205 "src/io/YAMLWriter.birch"
      libbirch_line_(205);
      #line 205 "src/io/YAMLWriter.birch"
      if (birch::isnan(x, handler_)) {
        #line 206 "src/io/YAMLWriter.birch"
        libbirch_line_(206);
        #line 206 "src/io/YAMLWriter.birch"
        value = birch::type::String("NaN");
      } else {
        #line 208 "src/io/YAMLWriter.birch"
        libbirch_line_(208);
        #line 208 "src/io/YAMLWriter.birch"
        value = birch::String(x, handler_);
      }
    }
  }
  #line 210 "src/io/YAMLWriter.birch"
yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)value.c_str(), value.length(), 1, 1,
        YAML_PLAIN_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 218 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::scalar(const birch::type::String& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 218 "src/io/YAMLWriter.birch"
  libbirch_function_("scalar", "src/io/YAMLWriter.birch", 218);
  #line 219 "src/io/YAMLWriter.birch"
yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)value.c_str(), value.length(), 1, 1,
        YAML_ANY_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 227 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::null(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 227 "src/io/YAMLWriter.birch"
  libbirch_function_("null", "src/io/YAMLWriter.birch", 227);
  #line 228 "src/io/YAMLWriter.birch"
yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)"null", 4, 1, 1,
        YAML_ANY_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 3 "src/io/YAMLWriter.birch"
birch::type::YAMLWriter* birch::type::make_YAMLWriter_() {
  #line 3 "src/io/YAMLWriter.birch"
  return new birch::type::YAMLWriter();
  #line 3 "src/io/YAMLWriter.birch"
}

