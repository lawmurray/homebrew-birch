#line 1 "src/io/InputStream.birch"
birch::type::InputStream::InputStream() :
    #line 1 "src/io/InputStream.birch"
    base_type_(),
    #line 8 "src/io/InputStream.birch"
    file(libbirch::make<std::optional<birch::type::File>>()) {
  //
}

#line 16 "src/io/InputStream.birch"
void birch::type::InputStream::open(const birch::type::String& path, const birch::type::Integer& mode) {
  #line 16 "src/io/InputStream.birch"
  libbirch_function_("open", "src/io/InputStream.birch", 16);
  #line 17 "src/io/InputStream.birch"
  libbirch_line_(17);
  #line 17 "src/io/InputStream.birch"
  libbirch_assert_(!((this->file.has_value())));
  #line 18 "src/io/InputStream.birch"
  libbirch_line_(18);
  #line 18 "src/io/InputStream.birch"
  this->file = birch::fopen(path, mode);
}

#line 26 "src/io/InputStream.birch"
void birch::type::InputStream::open(const birch::type::String& path) {
  #line 26 "src/io/InputStream.birch"
  libbirch_function_("open", "src/io/InputStream.birch", 26);
  #line 27 "src/io/InputStream.birch"
  libbirch_line_(27);
  #line 27 "src/io/InputStream.birch"
  this->open(path, birch::READ());
}

#line 33 "src/io/InputStream.birch"
void birch::type::InputStream::close() {
  #line 33 "src/io/InputStream.birch"
  libbirch_function_("close", "src/io/InputStream.birch", 33);
  #line 34 "src/io/InputStream.birch"
  libbirch_line_(34);
  #line 34 "src/io/InputStream.birch"
  libbirch_assert_(this->file.has_value());
  #line 35 "src/io/InputStream.birch"
  libbirch_line_(35);
  #line 35 "src/io/InputStream.birch"
  birch::fclose(this->file.value());
  #line 36 "src/io/InputStream.birch"
  libbirch_line_(36);
  #line 36 "src/io/InputStream.birch"
  this->file = std::nullopt;
}

#line 42 "src/io/InputStream.birch"
birch::type::Boolean birch::type::InputStream::eof() {
  #line 42 "src/io/InputStream.birch"
  libbirch_function_("eof", "src/io/InputStream.birch", 42);
  #line 43 "src/io/InputStream.birch"
  libbirch_line_(43);
  #line 43 "src/io/InputStream.birch"
  libbirch_assert_(this->file.has_value());
  #line 44 "src/io/InputStream.birch"
  libbirch_line_(44);
  #line 44 "src/io/InputStream.birch"
  return birch::feof(this->file.value());
}

#line 50 "src/io/InputStream.birch"
std::optional<birch::type::Integer> birch::type::InputStream::scanInteger() {
  #line 50 "src/io/InputStream.birch"
  libbirch_function_("scanInteger", "src/io/InputStream.birch", 50);
  #line 51 "src/io/InputStream.birch"
  libbirch_line_(51);
  #line 51 "src/io/InputStream.birch"
  libbirch_assert_(this->file.has_value());
  #line 52 "src/io/InputStream.birch"
  libbirch_line_(52);
  #line 52 "src/io/InputStream.birch"
  std::optional<birch::type::Integer> x = libbirch::make<std::optional<birch::type::Integer>>();
  #line 53 "src/io/InputStream.birch"

    long long int y;  // ensure fscanf gets exactly the type it expects
    auto res = ::fscanf(this->file.value(), "%lld", &y);
    if (res == 1) {
      x = (birch::type::Integer)y;
    } 
      #line 60 "src/io/InputStream.birch"
  libbirch_line_(60);
  #line 60 "src/io/InputStream.birch"
  return x;
}

#line 66 "src/io/InputStream.birch"
std::optional<birch::type::Real> birch::type::InputStream::scanReal() {
  #line 66 "src/io/InputStream.birch"
  libbirch_function_("scanReal", "src/io/InputStream.birch", 66);
  #line 67 "src/io/InputStream.birch"
  libbirch_line_(67);
  #line 67 "src/io/InputStream.birch"
  libbirch_assert_(this->file.has_value());
  #line 68 "src/io/InputStream.birch"
  libbirch_line_(68);
  #line 68 "src/io/InputStream.birch"
  std::optional<birch::type::Real> x = libbirch::make<std::optional<birch::type::Real>>();
  #line 69 "src/io/InputStream.birch"

    double y;  // ensure fscanf gets exactly the type it expects
    auto res = ::fscanf(this->file.value(), "%lf", &y);
    if (res == 1) {
      x = y;
    } 
      #line 76 "src/io/InputStream.birch"
  libbirch_line_(76);
  #line 76 "src/io/InputStream.birch"
  return x;
}

#line 1 "src/io/InputStream.birch"
birch::type::InputStream* birch::type::make_InputStream_() {
  #line 1 "src/io/InputStream.birch"
  return new birch::type::InputStream();
  #line 1 "src/io/InputStream.birch"
}

#line 83 "src/io/InputStream.birch"
libbirch::Shared<birch::type::InputStream> birch::InputStream(const birch::type::File& file) {
  #line 83 "src/io/InputStream.birch"
  libbirch_function_("InputStream", "src/io/InputStream.birch", 83);
  #line 84 "src/io/InputStream.birch"
  libbirch_line_(84);
  #line 84 "src/io/InputStream.birch"
  libbirch::Shared<birch::type::InputStream> o = libbirch::make<libbirch::Shared<birch::type::InputStream>>();
  #line 85 "src/io/InputStream.birch"
  libbirch_line_(85);
  #line 85 "src/io/InputStream.birch"
  o->file = file;
  #line 86 "src/io/InputStream.birch"
  libbirch_line_(86);
  #line 86 "src/io/InputStream.birch"
  return o;
}

#line 1 "src/io/JSONWriter.birch"
birch::type::JSONWriter::JSONWriter() :
    #line 1 "src/io/JSONWriter.birch"
    base_type_() {
  //
}

#line 14 "src/io/JSONWriter.birch"
void birch::type::JSONWriter::visit(const birch::type::String& value) {
  #line 14 "src/io/JSONWriter.birch"
  libbirch_function_("visit", "src/io/JSONWriter.birch", 14);
  #line 15 "src/io/JSONWriter.birch"

    yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)value.c_str(), value.length(), 1, 1,
        YAML_DOUBLE_QUOTED_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 23 "src/io/JSONWriter.birch"
void birch::type::JSONWriter::startMapping() {
  #line 23 "src/io/JSONWriter.birch"
  libbirch_function_("startMapping", "src/io/JSONWriter.birch", 23);
  #line 24 "src/io/JSONWriter.birch"

    yaml_mapping_start_event_initialize(&this->event, NULL, NULL, 1,
        YAML_FLOW_MAPPING_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 31 "src/io/JSONWriter.birch"
void birch::type::JSONWriter::startSequence() {
  #line 31 "src/io/JSONWriter.birch"
  libbirch_function_("startSequence", "src/io/JSONWriter.birch", 31);
  #line 32 "src/io/JSONWriter.birch"

    yaml_sequence_start_event_initialize(&this->event, NULL, NULL, 1,
        YAML_FLOW_SEQUENCE_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 1 "src/io/JSONWriter.birch"
birch::type::JSONWriter* birch::type::make_JSONWriter_() {
  #line 1 "src/io/JSONWriter.birch"
  return new birch::type::JSONWriter();
  #line 1 "src/io/JSONWriter.birch"
}

#line 1 "src/io/OutputStream.birch"
birch::type::OutputStream::OutputStream() :
    #line 1 "src/io/OutputStream.birch"
    base_type_(),
    #line 8 "src/io/OutputStream.birch"
    file(libbirch::make<std::optional<birch::type::File>>()) {
  //
}

#line 16 "src/io/OutputStream.birch"
void birch::type::OutputStream::open(const birch::type::String& path, const birch::type::Integer& mode) {
  #line 16 "src/io/OutputStream.birch"
  libbirch_function_("open", "src/io/OutputStream.birch", 16);
  #line 17 "src/io/OutputStream.birch"
  libbirch_line_(17);
  #line 17 "src/io/OutputStream.birch"
  this->file = birch::fopen(path, mode);
}

#line 25 "src/io/OutputStream.birch"
void birch::type::OutputStream::open(const birch::type::String& path) {
  #line 25 "src/io/OutputStream.birch"
  libbirch_function_("open", "src/io/OutputStream.birch", 25);
  #line 26 "src/io/OutputStream.birch"
  libbirch_line_(26);
  #line 26 "src/io/OutputStream.birch"
  this->open(path, birch::WRITE());
}

#line 32 "src/io/OutputStream.birch"
void birch::type::OutputStream::close() {
  #line 32 "src/io/OutputStream.birch"
  libbirch_function_("close", "src/io/OutputStream.birch", 32);
  #line 33 "src/io/OutputStream.birch"
  libbirch_line_(33);
  #line 33 "src/io/OutputStream.birch"
  libbirch_assert_(this->file.has_value());
  #line 34 "src/io/OutputStream.birch"
  libbirch_line_(34);
  #line 34 "src/io/OutputStream.birch"
  birch::fclose(this->file.value());
  #line 35 "src/io/OutputStream.birch"
  libbirch_line_(35);
  #line 35 "src/io/OutputStream.birch"
  this->file = std::nullopt;
}

#line 41 "src/io/OutputStream.birch"
void birch::type::OutputStream::flush() {
  #line 41 "src/io/OutputStream.birch"
  libbirch_function_("flush", "src/io/OutputStream.birch", 41);
  #line 42 "src/io/OutputStream.birch"
  libbirch_line_(42);
  #line 42 "src/io/OutputStream.birch"
  libbirch_assert_(this->file.has_value());
  #line 43 "src/io/OutputStream.birch"
  libbirch_line_(43);
  #line 43 "src/io/OutputStream.birch"
  birch::fflush(this->file.value());
}

#line 49 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const birch::type::String& value) {
  #line 49 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 49);
  #line 50 "src/io/OutputStream.birch"
  libbirch_line_(50);
  #line 50 "src/io/OutputStream.birch"
  libbirch_assert_(this->file.has_value());
  #line 51 "src/io/OutputStream.birch"

    ::fprintf(this->file.value(), "%s", value.c_str());
    }

#line 59 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const birch::type::Boolean& value) {
  #line 59 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 59);
  #line 60 "src/io/OutputStream.birch"
  libbirch_line_(60);
  #line 60 "src/io/OutputStream.birch"
  this->print(birch::String(value));
}

#line 66 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const birch::type::Integer& value) {
  #line 66 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 66);
  #line 67 "src/io/OutputStream.birch"
  libbirch_line_(67);
  #line 67 "src/io/OutputStream.birch"
  this->print(birch::String(value));
}

#line 73 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const birch::type::Real& value) {
  #line 73 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 73);
  #line 74 "src/io/OutputStream.birch"
  libbirch_line_(74);
  #line 74 "src/io/OutputStream.birch"
  this->print(birch::String(value));
}

#line 80 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const libbirch::DefaultArray<birch::type::Boolean,1>& value) {
  #line 80 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 80);
  #line 81 "src/io/OutputStream.birch"
  libbirch_line_(81);
  #line 81 "src/io/OutputStream.birch"
  this->print(birch::String(value));
}

#line 87 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const libbirch::DefaultArray<birch::type::Integer,1>& value) {
  #line 87 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 87);
  #line 88 "src/io/OutputStream.birch"
  libbirch_line_(88);
  #line 88 "src/io/OutputStream.birch"
  this->print(birch::String(value));
}

#line 94 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const libbirch::DefaultArray<birch::type::Real,1>& value) {
  #line 94 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 94);
  #line 95 "src/io/OutputStream.birch"
  libbirch_line_(95);
  #line 95 "src/io/OutputStream.birch"
  this->print(birch::String(value));
}

#line 101 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const libbirch::DefaultArray<birch::type::Boolean,2>& value) {
  #line 101 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 101);
  #line 102 "src/io/OutputStream.birch"
  libbirch_line_(102);
  #line 102 "src/io/OutputStream.birch"
  this->print(birch::String(value));
}

#line 108 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const libbirch::DefaultArray<birch::type::Integer,2>& value) {
  #line 108 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 108);
  #line 109 "src/io/OutputStream.birch"
  libbirch_line_(109);
  #line 109 "src/io/OutputStream.birch"
  this->print(birch::String(value));
}

#line 115 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const libbirch::DefaultArray<birch::type::Real,2>& value) {
  #line 115 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 115);
  #line 116 "src/io/OutputStream.birch"
  libbirch_line_(116);
  #line 116 "src/io/OutputStream.birch"
  this->print(birch::String(value));
}

#line 122 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const birch::type::LLT& value) {
  #line 122 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 122);
  #line 123 "src/io/OutputStream.birch"
  libbirch_line_(123);
  #line 123 "src/io/OutputStream.birch"
  this->print(birch::String(value));
}

#line 1 "src/io/OutputStream.birch"
birch::type::OutputStream* birch::type::make_OutputStream_() {
  #line 1 "src/io/OutputStream.birch"
  return new birch::type::OutputStream();
  #line 1 "src/io/OutputStream.birch"
}

#line 130 "src/io/OutputStream.birch"
libbirch::Shared<birch::type::OutputStream> birch::OutputStream(const birch::type::File& file) {
  #line 130 "src/io/OutputStream.birch"
  libbirch_function_("OutputStream", "src/io/OutputStream.birch", 130);
  #line 131 "src/io/OutputStream.birch"
  libbirch_line_(131);
  #line 131 "src/io/OutputStream.birch"
  libbirch::Shared<birch::type::OutputStream> o = libbirch::make<libbirch::Shared<birch::type::OutputStream>>();
  #line 132 "src/io/OutputStream.birch"
  libbirch_line_(132);
  #line 132 "src/io/OutputStream.birch"
  o->file = file;
  #line 133 "src/io/OutputStream.birch"
  libbirch_line_(133);
  #line 133 "src/io/OutputStream.birch"
  return o;
}

#line 38 "src/io/Reader.birch"
birch::type::Reader::Reader() :
    #line 38 "src/io/Reader.birch"
    base_type_() {
  //
}

#line 69 "src/io/Reader.birch"
libbirch::Shared<birch::type::Reader> birch::Reader(const birch::type::String& path) {
  #line 69 "src/io/Reader.birch"
  libbirch_function_("Reader", "src/io/Reader.birch", 69);
  #line 70 "src/io/Reader.birch"
  libbirch_line_(70);
  #line 70 "src/io/Reader.birch"
  auto ext = birch::extension(path);
  #line 71 "src/io/Reader.birch"
  libbirch_line_(71);
  #line 71 "src/io/Reader.birch"
  std::optional<libbirch::Shared<birch::type::Reader>> result = libbirch::make<std::optional<libbirch::Shared<birch::type::Reader>>>();
  #line 72 "src/io/Reader.birch"
  libbirch_line_(72);
  #line 72 "src/io/Reader.birch"
  if (ext == birch::type::String(".json")) {
    #line 73 "src/io/Reader.birch"
    libbirch_line_(73);
    #line 73 "src/io/Reader.birch"
    libbirch::Shared<birch::type::JSONReader> reader = libbirch::make<libbirch::Shared<birch::type::JSONReader>>();
    #line 74 "src/io/Reader.birch"
    libbirch_line_(74);
    #line 74 "src/io/Reader.birch"
    reader->open(path);
    #line 75 "src/io/Reader.birch"
    libbirch_line_(75);
    #line 75 "src/io/Reader.birch"
    result = reader;
  } else {
    #line 76 "src/io/Reader.birch"
    libbirch_line_(76);
    #line 76 "src/io/Reader.birch"
    if (ext == birch::type::String(".yml") || ext == birch::type::String(".yaml")) {
      #line 77 "src/io/Reader.birch"
      libbirch_line_(77);
      #line 77 "src/io/Reader.birch"
      libbirch::Shared<birch::type::YAMLReader> reader = libbirch::make<libbirch::Shared<birch::type::YAMLReader>>();
      #line 78 "src/io/Reader.birch"
      libbirch_line_(78);
      #line 78 "src/io/Reader.birch"
      reader->open(path);
      #line 79 "src/io/Reader.birch"
      libbirch_line_(79);
      #line 79 "src/io/Reader.birch"
      result = reader;
    }
  }
  #line 81 "src/io/Reader.birch"
  libbirch_line_(81);
  #line 81 "src/io/Reader.birch"
  if (!(result.has_value())) {
    #line 82 "src/io/Reader.birch"
    libbirch_line_(82);
    #line 82 "src/io/Reader.birch"
    birch::error(birch::type::String("unrecognized file extension '") + ext + birch::type::String("' in path '") + path + birch::type::String("'; supported extensions are '.json', '.yml' and '.yaml'."));
  }
  #line 85 "src/io/Reader.birch"
  libbirch_line_(85);
  #line 85 "src/io/Reader.birch"
  return result.value();
}

#line 95 "src/io/Reader.birch"
libbirch::Shared<birch::type::Buffer> birch::slurp(const birch::type::String& path) {
  #line 95 "src/io/Reader.birch"
  libbirch_function_("slurp", "src/io/Reader.birch", 95);
  #line 96 "src/io/Reader.birch"
  libbirch_line_(96);
  #line 96 "src/io/Reader.birch"
  auto reader = birch::Reader(path);
  #line 97 "src/io/Reader.birch"
  libbirch_line_(97);
  #line 97 "src/io/Reader.birch"
  auto buffer = reader->slurp();
  #line 98 "src/io/Reader.birch"
  libbirch_line_(98);
  #line 98 "src/io/Reader.birch"
  reader->close();
  #line 99 "src/io/Reader.birch"
  libbirch_line_(99);
  #line 99 "src/io/Reader.birch"
  return buffer;
}

#line 37 "src/io/Writer.birch"
birch::type::Writer::Writer() :
    #line 37 "src/io/Writer.birch"
    base_type_() {
  //
}

#line 98 "src/io/Writer.birch"
libbirch::Shared<birch::type::Writer> birch::Writer(const birch::type::String& path) {
  #line 98 "src/io/Writer.birch"
  libbirch_function_("Writer", "src/io/Writer.birch", 98);
  #line 99 "src/io/Writer.birch"
  libbirch_line_(99);
  #line 99 "src/io/Writer.birch"
  auto ext = birch::extension(path);
  #line 100 "src/io/Writer.birch"
  libbirch_line_(100);
  #line 100 "src/io/Writer.birch"
  std::optional<libbirch::Shared<birch::type::Writer>> result = libbirch::make<std::optional<libbirch::Shared<birch::type::Writer>>>();
  #line 101 "src/io/Writer.birch"
  libbirch_line_(101);
  #line 101 "src/io/Writer.birch"
  if (ext == birch::type::String(".json")) {
    #line 102 "src/io/Writer.birch"
    libbirch_line_(102);
    #line 102 "src/io/Writer.birch"
    libbirch::Shared<birch::type::JSONWriter> writer = libbirch::make<libbirch::Shared<birch::type::JSONWriter>>();
    #line 103 "src/io/Writer.birch"
    libbirch_line_(103);
    #line 103 "src/io/Writer.birch"
    writer->open(path);
    #line 104 "src/io/Writer.birch"
    libbirch_line_(104);
    #line 104 "src/io/Writer.birch"
    result = writer;
  } else {
    #line 105 "src/io/Writer.birch"
    libbirch_line_(105);
    #line 105 "src/io/Writer.birch"
    if (ext == birch::type::String(".yml")) {
      #line 106 "src/io/Writer.birch"
      libbirch_line_(106);
      #line 106 "src/io/Writer.birch"
      libbirch::Shared<birch::type::YAMLWriter> writer = libbirch::make<libbirch::Shared<birch::type::YAMLWriter>>();
      #line 107 "src/io/Writer.birch"
      libbirch_line_(107);
      #line 107 "src/io/Writer.birch"
      writer->open(path);
      #line 108 "src/io/Writer.birch"
      libbirch_line_(108);
      #line 108 "src/io/Writer.birch"
      result = writer;
    }
  }
  #line 110 "src/io/Writer.birch"
  libbirch_line_(110);
  #line 110 "src/io/Writer.birch"
  if (!(result.has_value())) {
    #line 111 "src/io/Writer.birch"
    libbirch_line_(111);
    #line 111 "src/io/Writer.birch"
    birch::error(birch::type::String("unrecognized file extension '") + ext + birch::type::String("' in path '") + path + birch::type::String("'; supported extensions are '.json' and '.yml'."));
  }
  #line 114 "src/io/Writer.birch"
  libbirch_line_(114);
  #line 114 "src/io/Writer.birch"
  return result.value();
}

#line 123 "src/io/Writer.birch"
void birch::dump(const birch::type::String& path, const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 123 "src/io/Writer.birch"
  libbirch_function_("dump", "src/io/Writer.birch", 123);
  #line 124 "src/io/Writer.birch"
  libbirch_line_(124);
  #line 124 "src/io/Writer.birch"
  auto writer = birch::Writer(path);
  #line 125 "src/io/Writer.birch"
  libbirch_line_(125);
  #line 125 "src/io/Writer.birch"
  writer->dump(buffer);
  #line 126 "src/io/Writer.birch"
  libbirch_line_(126);
  #line 126 "src/io/Writer.birch"
  writer->close();
}

#line 3 "src/io/YAMLReader.birch"
birch::type::YAMLReader::YAMLReader() :
    #line 3 "src/io/YAMLReader.birch"
    base_type_(),
    #line 28 "src/io/YAMLReader.birch"
    file(libbirch::make<birch::type::File>()),
    #line 33 "src/io/YAMLReader.birch"
    sequential(false) {
  //
}

#line 40 "src/io/YAMLReader.birch"
void birch::type::YAMLReader::open(const birch::type::String& path) {
  #line 40 "src/io/YAMLReader.birch"
  libbirch_function_("open", "src/io/YAMLReader.birch", 40);
  #line 41 "src/io/YAMLReader.birch"
  libbirch_line_(41);
  #line 41 "src/io/YAMLReader.birch"
  this->file = birch::fopen(path, birch::READ());
  #line 42 "src/io/YAMLReader.birch"

    yaml_parser_initialize(&parser);
    yaml_parser_set_input_file(&parser, file);
    if (!yaml_parser_parse(&parser, &event)) {
      error("parse error");
    }
    }

#line 51 "src/io/YAMLReader.birch"
void birch::type::YAMLReader::close() {
  #line 51 "src/io/YAMLReader.birch"
  libbirch_function_("close", "src/io/YAMLReader.birch", 51);
  #line 52 "src/io/YAMLReader.birch"

    yaml_event_delete(&event);
    yaml_parser_delete(&parser);
      #line 56 "src/io/YAMLReader.birch"
  libbirch_line_(56);
  #line 56 "src/io/YAMLReader.birch"
  birch::fclose(this->file);
}

#line 59 "src/io/YAMLReader.birch"
libbirch::Shared<birch::type::Buffer> birch::type::YAMLReader::slurp() {
  #line 59 "src/io/YAMLReader.birch"
  libbirch_function_("slurp", "src/io/YAMLReader.birch", 59);
  #line 60 "src/io/YAMLReader.birch"
  libbirch_line_(60);
  #line 60 "src/io/YAMLReader.birch"
  libbirch_assert_(!(this->sequential));
  #line 61 "src/io/YAMLReader.birch"
  libbirch_line_(61);
  #line 61 "src/io/YAMLReader.birch"
  libbirch::Shared<birch::type::Buffer> buffer = libbirch::make<libbirch::Shared<birch::type::Buffer>>();
  #line 62 "src/io/YAMLReader.birch"

    while (event.type != YAML_STREAM_END_EVENT) {
      if (event.type == YAML_SEQUENCE_START_EVENT) {
        parseSequence(buffer);
      } else if (event.type == YAML_MAPPING_START_EVENT) {
        parseMapping(buffer);
      } else if (event.type == YAML_SCALAR_EVENT) {
        parseValue(buffer);
      }
      nextEvent();
    }
      #line 74 "src/io/YAMLReader.birch"
  libbirch_line_(74);
  #line 74 "src/io/YAMLReader.birch"
  return buffer;
}

#line 77 "src/io/YAMLReader.birch"
birch::type::Boolean birch::type::YAMLReader::hasNext() {
  #line 77 "src/io/YAMLReader.birch"
  libbirch_function_("hasNext", "src/io/YAMLReader.birch", 77);
  #line 78 "src/io/YAMLReader.birch"

    while (event.type != YAML_MAPPING_START_EVENT &&
        event.type != YAML_SEQUENCE_START_EVENT &&
        event.type != YAML_SCALAR_EVENT &&
        event.type != YAML_STREAM_END_EVENT) {
      nextEvent();
    }
    if (!sequential && event.type == YAML_SEQUENCE_START_EVENT) {
      /* root is a sequence to iterate through, go one level deeper to find
       * its first element, if any */
      nextEvent();
      while (event.type != YAML_MAPPING_START_EVENT &&
          event.type != YAML_SEQUENCE_START_EVENT &&
          event.type != YAML_SCALAR_EVENT &&
          event.type != YAML_STREAM_END_EVENT) {
        nextEvent();
      }
    }
    sequential = true;
    return event.type != YAML_STREAM_END_EVENT;
      #line 99 "src/io/YAMLReader.birch"
  libbirch_line_(99);
  #line 99 "src/io/YAMLReader.birch"
  return false;
}

#line 102 "src/io/YAMLReader.birch"
libbirch::Shared<birch::type::Buffer> birch::type::YAMLReader::next() {
  #line 102 "src/io/YAMLReader.birch"
  libbirch_function_("next", "src/io/YAMLReader.birch", 102);
  #line 103 "src/io/YAMLReader.birch"
  libbirch_line_(103);
  #line 103 "src/io/YAMLReader.birch"
  if (!(this->sequential)) {
    #line 104 "src/io/YAMLReader.birch"
    libbirch_line_(104);
    #line 104 "src/io/YAMLReader.birch"
    this->hasNext();
  }
  #line 106 "src/io/YAMLReader.birch"
  libbirch_line_(106);
  #line 106 "src/io/YAMLReader.birch"
  libbirch::Shared<birch::type::Buffer> buffer = libbirch::make<libbirch::Shared<birch::type::Buffer>>();
  #line 107 "src/io/YAMLReader.birch"

    if (event.type == YAML_SCALAR_EVENT) {
      parseValue(buffer);
    } else if (event.type == YAML_SEQUENCE_START_EVENT) {
      parseSequence(buffer);
    } else if (event.type == YAML_MAPPING_START_EVENT) {
      parseMapping(buffer);
    } else {
      /* shouldn't get here if hasNext() was called before next() */
      assert(false);
    }
    nextEvent();
      #line 120 "src/io/YAMLReader.birch"
  libbirch_line_(120);
  #line 120 "src/io/YAMLReader.birch"
  return buffer;
}

#line 126 "src/io/YAMLReader.birch"
void birch::type::YAMLReader::parseMapping(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 126 "src/io/YAMLReader.birch"
  libbirch_function_("parseMapping", "src/io/YAMLReader.birch", 126);
  #line 127 "src/io/YAMLReader.birch"
  libbirch_line_(127);
  #line 127 "src/io/YAMLReader.birch"
  buffer->setEmptyObject();
  #line 128 "src/io/YAMLReader.birch"

    nextEvent();
    while (event.type != YAML_MAPPING_END_EVENT) {
      if (event.type == YAML_SCALAR_EVENT) {
        /* key */
        char* data = (char*)event.data.scalar.value;
        size_t length = event.data.scalar.length;
        std::string key(data, length);
      
        /* value */
        nextEvent();
        auto value = birch::Buffer();
        if (event.type == YAML_SCALAR_EVENT) {
          parseValue(value);
        } else if (event.type == YAML_SEQUENCE_START_EVENT) {
          parseSequence(value);
        } else if (event.type == YAML_MAPPING_START_EVENT) {
          parseMapping(value);
        }

        /* set key/value entry */
        buffer->set(key, value);
      }
      nextEvent();
    }
    }

#line 159 "src/io/YAMLReader.birch"
void birch::type::YAMLReader::parseSequence(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 159 "src/io/YAMLReader.birch"
  libbirch_function_("parseSequence", "src/io/YAMLReader.birch", 159);
  #line 160 "src/io/YAMLReader.birch"
  libbirch_line_(160);
  #line 160 "src/io/YAMLReader.birch"
  buffer->setEmptyArray();
  #line 161 "src/io/YAMLReader.birch"

    nextEvent();
    while (event.type != YAML_SEQUENCE_END_EVENT) {
      if (event.type == YAML_SCALAR_EVENT) {
        parseElement(buffer);
      } else if (event.type == YAML_SEQUENCE_START_EVENT) {
        auto element = birch::Buffer();
        parseSequence(element);

        /* attempt to merge sequences into numerical matrices */
        if (element->vectorReal.has_value()) {
          buffer->push(element->vectorReal.value());
        } else if (element->vectorInteger.has_value()) {
          buffer->push(element->vectorInteger.value());
        } else if (element->vectorBoolean.has_value()) {
          buffer->push(element->vectorBoolean.value());
        } else {
          buffer->push(element);
        }
      } else if (event.type == YAML_MAPPING_START_EVENT) {
        auto element = birch::Buffer();
        parseMapping(element);
        buffer->push(element);
      }
      nextEvent();
    }
    }

#line 193 "src/io/YAMLReader.birch"
void birch::type::YAMLReader::parseValue(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 193 "src/io/YAMLReader.birch"
  libbirch_function_("parseValue", "src/io/YAMLReader.birch", 193);
  #line 194 "src/io/YAMLReader.birch"

    auto data = (char*)event.data.scalar.value;
    auto length = event.data.scalar.length;
    auto endptr = data;
    auto intValue = int64_t(std::strtoll(data, &endptr, 10));
    if (endptr == data + length) {
      buffer->set(intValue);
    } else {
      auto realValue = std::strtod(data, &endptr);
      if (endptr == data + length) {
        buffer->set(realValue);
      } else if (std::strcmp(data, "true") == 0) {
        buffer->set(true);
      } else if (std::strcmp(data, "false") == 0) {
        buffer->set(false);
      } else if (std::strcmp(data, "null") == 0) {
        buffer->setNil();
      } else if (std::strcmp(data, "Infinity") == 0) {
        buffer->set(std::numeric_limits<Real>::infinity());
      } else if (std::strcmp(data, "-Infinity") == 0) {
        buffer->set(-std::numeric_limits<Real>::infinity());
      } else if (std::strcmp(data, "NaN") == 0) {
        buffer->set(std::numeric_limits<Real>::quiet_NaN());
      } else {
        buffer->set(std::string(data, length));
      }
    }
    }

#line 227 "src/io/YAMLReader.birch"
void birch::type::YAMLReader::parseElement(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 227 "src/io/YAMLReader.birch"
  libbirch_function_("parseElement", "src/io/YAMLReader.birch", 227);
  #line 228 "src/io/YAMLReader.birch"

    auto data = (char*)event.data.scalar.value;
    auto length = event.data.scalar.length;
    auto endptr = data;
    auto intValue = int64_t(std::strtoll(data, &endptr, 10));
    if (endptr == data + length) {
      buffer->push(intValue);
    } else {
      auto realValue = std::strtod(data, &endptr);
      if (endptr == data + length) {
        buffer->push(realValue);
      } else if (std::strcmp(data, "true") == 0) {
        buffer->push(true);
      } else if (std::strcmp(data, "false") == 0) {
        buffer->push(false);
      } else if (std::strcmp(data, "null") == 0) {
        buffer->pushNil();
      } else if (std::strcmp(data, "Infinity") == 0) {
        buffer->push(std::numeric_limits<Real>::infinity());
      } else if (std::strcmp(data, "-Infinity") == 0) {
        buffer->push(-std::numeric_limits<Real>::infinity());
      } else if (std::strcmp(data, "NaN") == 0) {
        buffer->push(std::numeric_limits<Real>::quiet_NaN());
      } else {
        buffer->push(std::string(data, length));
      }
    }
    }

#line 261 "src/io/YAMLReader.birch"
void birch::type::YAMLReader::nextEvent() {
  #line 261 "src/io/YAMLReader.birch"
  libbirch_function_("nextEvent", "src/io/YAMLReader.birch", 261);
  #line 262 "src/io/YAMLReader.birch"

    yaml_event_delete(&event);
    if (!yaml_parser_parse(&parser, &event)) {
      error("parse error");
    }
    }

#line 3 "src/io/YAMLReader.birch"
birch::type::YAMLReader* birch::type::make_YAMLReader_() {
  #line 3 "src/io/YAMLReader.birch"
  return new birch::type::YAMLReader();
  #line 3 "src/io/YAMLReader.birch"
}

#line 3 "src/io/YAMLWriter.birch"
birch::type::YAMLWriter::YAMLWriter() :
    #line 3 "src/io/YAMLWriter.birch"
    base_type_(),
    #line 21 "src/io/YAMLWriter.birch"
    file(libbirch::make<birch::type::File>()),
    #line 26 "src/io/YAMLWriter.birch"
    sequential(false) {
  //
}

#line 33 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::open(const birch::type::String& path) {
  #line 33 "src/io/YAMLWriter.birch"
  libbirch_function_("open", "src/io/YAMLWriter.birch", 33);
  #line 34 "src/io/YAMLWriter.birch"
  libbirch_line_(34);
  #line 34 "src/io/YAMLWriter.birch"
  this->file = birch::fopen(path, birch::WRITE());
  #line 35 "src/io/YAMLWriter.birch"

    yaml_emitter_initialize(&this->emitter);
    yaml_emitter_set_unicode(&this->emitter, 1);
    yaml_emitter_set_output_file(&this->emitter, this->file);
    yaml_stream_start_event_initialize(&this->event, YAML_UTF8_ENCODING);
    yaml_emitter_emit(&this->emitter, &this->event);
    yaml_document_start_event_initialize(&this->event, NULL, NULL, NULL, 1);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 46 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::dump(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 46 "src/io/YAMLWriter.birch"
  libbirch_function_("dump", "src/io/YAMLWriter.birch", 46);
  #line 47 "src/io/YAMLWriter.birch"
  libbirch_line_(47);
  #line 47 "src/io/YAMLWriter.birch"
  buffer->accept(this->shared_from_this_());
}

#line 50 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::push(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 50 "src/io/YAMLWriter.birch"
  libbirch_function_("push", "src/io/YAMLWriter.birch", 50);
  #line 51 "src/io/YAMLWriter.birch"
  libbirch_line_(51);
  #line 51 "src/io/YAMLWriter.birch"
  if (!(this->sequential)) {
    #line 52 "src/io/YAMLWriter.birch"
    libbirch_line_(52);
    #line 52 "src/io/YAMLWriter.birch"
    this->startSequence();
    #line 53 "src/io/YAMLWriter.birch"
    libbirch_line_(53);
    #line 53 "src/io/YAMLWriter.birch"
    this->sequential = true;
  }
  #line 55 "src/io/YAMLWriter.birch"
  libbirch_line_(55);
  #line 55 "src/io/YAMLWriter.birch"
  buffer->accept(this->shared_from_this_());
}

#line 58 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::flush() {
  #line 58 "src/io/YAMLWriter.birch"
  libbirch_function_("flush", "src/io/YAMLWriter.birch", 58);
  #line 59 "src/io/YAMLWriter.birch"

    yaml_emitter_flush(&this->emitter);
      #line 62 "src/io/YAMLWriter.birch"
  libbirch_line_(62);
  #line 62 "src/io/YAMLWriter.birch"
  birch::fflush(this->file);
}

#line 65 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::close() {
  #line 65 "src/io/YAMLWriter.birch"
  libbirch_function_("close", "src/io/YAMLWriter.birch", 65);
  #line 66 "src/io/YAMLWriter.birch"
  libbirch_line_(66);
  #line 66 "src/io/YAMLWriter.birch"
  if (this->sequential) {
    #line 67 "src/io/YAMLWriter.birch"
    libbirch_line_(67);
    #line 67 "src/io/YAMLWriter.birch"
    this->endSequence();
  }
  #line 69 "src/io/YAMLWriter.birch"

    yaml_document_end_event_initialize(&this->event, 1);
    yaml_emitter_emit(&this->emitter, &this->event);
    yaml_stream_end_event_initialize(&this->event);
    yaml_emitter_emit(&this->emitter, &this->event);
    yaml_emitter_delete(&this->emitter);
      #line 76 "src/io/YAMLWriter.birch"
  libbirch_line_(76);
  #line 76 "src/io/YAMLWriter.birch"
  birch::fclose(this->file);
}

#line 79 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::DefaultArray<birch::type::String,1>& keys, const libbirch::DefaultArray<libbirch::Shared<birch::type::Buffer>,1>& values) {
  #line 79 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 79);
  #line 80 "src/io/YAMLWriter.birch"
  libbirch_line_(80);
  #line 80 "src/io/YAMLWriter.birch"
  libbirch_assert_(birch::length(keys) == birch::length(values));
  #line 81 "src/io/YAMLWriter.birch"
  libbirch_line_(81);
  #line 81 "src/io/YAMLWriter.birch"
  this->startMapping();
  #line 82 "src/io/YAMLWriter.birch"
  libbirch_line_(82);
  #line 82 "src/io/YAMLWriter.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(keys); ++i) {
    #line 83 "src/io/YAMLWriter.birch"
    libbirch_line_(83);
    #line 83 "src/io/YAMLWriter.birch"
    this->visit(keys(i));
    #line 84 "src/io/YAMLWriter.birch"
    libbirch_line_(84);
    #line 84 "src/io/YAMLWriter.birch"
    values(i)->accept(this->shared_from_this_());
  }
  #line 86 "src/io/YAMLWriter.birch"
  libbirch_line_(86);
  #line 86 "src/io/YAMLWriter.birch"
  this->endMapping();
}

#line 89 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::DefaultArray<libbirch::Shared<birch::type::Buffer>,1>& values) {
  #line 89 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 89);
  #line 90 "src/io/YAMLWriter.birch"
  libbirch_line_(90);
  #line 90 "src/io/YAMLWriter.birch"
  this->startSequence();
  #line 91 "src/io/YAMLWriter.birch"
  libbirch_line_(91);
  #line 91 "src/io/YAMLWriter.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(values); ++i) {
    #line 92 "src/io/YAMLWriter.birch"
    libbirch_line_(92);
    #line 92 "src/io/YAMLWriter.birch"
    values(i)->accept(this->shared_from_this_());
  }
  #line 94 "src/io/YAMLWriter.birch"
  libbirch_line_(94);
  #line 94 "src/io/YAMLWriter.birch"
  this->endSequence();
}

#line 97 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const birch::type::Boolean& value) {
  #line 97 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 97);
  #line 98 "src/io/YAMLWriter.birch"
  libbirch_line_(98);
  #line 98 "src/io/YAMLWriter.birch"
  auto str = birch::String(value);
  #line 99 "src/io/YAMLWriter.birch"

    yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)str.c_str(), str.length(), 1, 1,
        YAML_ANY_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 107 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const birch::type::Integer& value) {
  #line 107 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 107);
  #line 108 "src/io/YAMLWriter.birch"
  libbirch_line_(108);
  #line 108 "src/io/YAMLWriter.birch"
  auto str = birch::String(value);
  #line 109 "src/io/YAMLWriter.birch"

    yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)str.c_str(), str.length(), 1, 1,
        YAML_ANY_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 117 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const birch::type::Real& value) {
  #line 117 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 117);
  #line 121 "src/io/YAMLWriter.birch"
  libbirch_line_(121);
  #line 121 "src/io/YAMLWriter.birch"
  birch::type::String str = libbirch::make<birch::type::String>();
  #line 122 "src/io/YAMLWriter.birch"
  libbirch_line_(122);
  #line 122 "src/io/YAMLWriter.birch"
  if (value == birch::inf()) {
    #line 123 "src/io/YAMLWriter.birch"
    libbirch_line_(123);
    #line 123 "src/io/YAMLWriter.birch"
    str = birch::type::String("Infinity");
  } else {
    #line 124 "src/io/YAMLWriter.birch"
    libbirch_line_(124);
    #line 124 "src/io/YAMLWriter.birch"
    if (value == -(birch::inf())) {
      #line 125 "src/io/YAMLWriter.birch"
      libbirch_line_(125);
      #line 125 "src/io/YAMLWriter.birch"
      str = birch::type::String("-Infinity");
    } else {
      #line 126 "src/io/YAMLWriter.birch"
      libbirch_line_(126);
      #line 126 "src/io/YAMLWriter.birch"
      if (birch::isnan(value)) {
        #line 127 "src/io/YAMLWriter.birch"
        libbirch_line_(127);
        #line 127 "src/io/YAMLWriter.birch"
        str = birch::type::String("NaN");
      } else {
        #line 129 "src/io/YAMLWriter.birch"
        libbirch_line_(129);
        #line 129 "src/io/YAMLWriter.birch"
        str = birch::String(value);
      }
    }
  }
  #line 131 "src/io/YAMLWriter.birch"

    yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)str.c_str(), str.length(), 1, 1,
        YAML_PLAIN_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 139 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const birch::type::String& value) {
  #line 139 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 139);
  #line 140 "src/io/YAMLWriter.birch"

    yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)value.c_str(), value.length(), 1, 1,
        YAML_ANY_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 148 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::DefaultArray<birch::type::Boolean,1>& value) {
  #line 148 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 148);
  #line 149 "src/io/YAMLWriter.birch"
  libbirch_line_(149);
  #line 149 "src/io/YAMLWriter.birch"
  this->startSequence();
  #line 150 "src/io/YAMLWriter.birch"
  libbirch_line_(150);
  #line 150 "src/io/YAMLWriter.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(value); ++i) {
    #line 151 "src/io/YAMLWriter.birch"
    libbirch_line_(151);
    #line 151 "src/io/YAMLWriter.birch"
    this->visit(value(i));
  }
  #line 153 "src/io/YAMLWriter.birch"
  libbirch_line_(153);
  #line 153 "src/io/YAMLWriter.birch"
  this->endSequence();
}

#line 156 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::DefaultArray<birch::type::Integer,1>& value) {
  #line 156 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 156);
  #line 157 "src/io/YAMLWriter.birch"
  libbirch_line_(157);
  #line 157 "src/io/YAMLWriter.birch"
  this->startSequence();
  #line 158 "src/io/YAMLWriter.birch"
  libbirch_line_(158);
  #line 158 "src/io/YAMLWriter.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(value); ++i) {
    #line 159 "src/io/YAMLWriter.birch"
    libbirch_line_(159);
    #line 159 "src/io/YAMLWriter.birch"
    this->visit(value(i));
  }
  #line 161 "src/io/YAMLWriter.birch"
  libbirch_line_(161);
  #line 161 "src/io/YAMLWriter.birch"
  this->endSequence();
}

#line 164 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::DefaultArray<birch::type::Real,1>& value) {
  #line 164 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 164);
  #line 165 "src/io/YAMLWriter.birch"
  libbirch_line_(165);
  #line 165 "src/io/YAMLWriter.birch"
  this->startSequence();
  #line 166 "src/io/YAMLWriter.birch"
  libbirch_line_(166);
  #line 166 "src/io/YAMLWriter.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(value); ++i) {
    #line 167 "src/io/YAMLWriter.birch"
    libbirch_line_(167);
    #line 167 "src/io/YAMLWriter.birch"
    this->visit(value(i));
  }
  #line 169 "src/io/YAMLWriter.birch"
  libbirch_line_(169);
  #line 169 "src/io/YAMLWriter.birch"
  this->endSequence();
}

#line 172 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::DefaultArray<birch::type::String,1>& value) {
  #line 172 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 172);
  #line 173 "src/io/YAMLWriter.birch"
  libbirch_line_(173);
  #line 173 "src/io/YAMLWriter.birch"
  this->startSequence();
  #line 174 "src/io/YAMLWriter.birch"
  libbirch_line_(174);
  #line 174 "src/io/YAMLWriter.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(value); ++i) {
    #line 175 "src/io/YAMLWriter.birch"
    libbirch_line_(175);
    #line 175 "src/io/YAMLWriter.birch"
    this->visit(value(i));
  }
  #line 177 "src/io/YAMLWriter.birch"
  libbirch_line_(177);
  #line 177 "src/io/YAMLWriter.birch"
  this->endSequence();
}

#line 180 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::DefaultArray<birch::type::Boolean,2>& value) {
  #line 180 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 180);
  #line 181 "src/io/YAMLWriter.birch"
  libbirch_line_(181);
  #line 181 "src/io/YAMLWriter.birch"
  this->startSequence();
  #line 182 "src/io/YAMLWriter.birch"
  libbirch_line_(182);
  #line 182 "src/io/YAMLWriter.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(value); ++i) {
    #line 183 "src/io/YAMLWriter.birch"
    libbirch_line_(183);
    #line 183 "src/io/YAMLWriter.birch"
    this->visit(birch::row(value, i));
  }
  #line 185 "src/io/YAMLWriter.birch"
  libbirch_line_(185);
  #line 185 "src/io/YAMLWriter.birch"
  this->endSequence();
}

#line 188 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::DefaultArray<birch::type::Integer,2>& value) {
  #line 188 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 188);
  #line 189 "src/io/YAMLWriter.birch"
  libbirch_line_(189);
  #line 189 "src/io/YAMLWriter.birch"
  this->startSequence();
  #line 190 "src/io/YAMLWriter.birch"
  libbirch_line_(190);
  #line 190 "src/io/YAMLWriter.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(value); ++i) {
    #line 191 "src/io/YAMLWriter.birch"
    libbirch_line_(191);
    #line 191 "src/io/YAMLWriter.birch"
    this->visit(birch::row(value, i));
  }
  #line 193 "src/io/YAMLWriter.birch"
  libbirch_line_(193);
  #line 193 "src/io/YAMLWriter.birch"
  this->endSequence();
}

#line 196 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::DefaultArray<birch::type::Real,2>& value) {
  #line 196 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 196);
  #line 197 "src/io/YAMLWriter.birch"
  libbirch_line_(197);
  #line 197 "src/io/YAMLWriter.birch"
  this->startSequence();
  #line 198 "src/io/YAMLWriter.birch"
  libbirch_line_(198);
  #line 198 "src/io/YAMLWriter.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(value); ++i) {
    #line 199 "src/io/YAMLWriter.birch"
    libbirch_line_(199);
    #line 199 "src/io/YAMLWriter.birch"
    this->visit(birch::row(value, i));
  }
  #line 201 "src/io/YAMLWriter.birch"
  libbirch_line_(201);
  #line 201 "src/io/YAMLWriter.birch"
  this->endSequence();
}

#line 204 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::DefaultArray<birch::type::String,2>& value) {
  #line 204 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 204);
  #line 205 "src/io/YAMLWriter.birch"
  libbirch_line_(205);
  #line 205 "src/io/YAMLWriter.birch"
  this->startSequence();
  #line 206 "src/io/YAMLWriter.birch"
  libbirch_line_(206);
  #line 206 "src/io/YAMLWriter.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(value); ++i) {
    #line 207 "src/io/YAMLWriter.birch"
    libbirch_line_(207);
    #line 207 "src/io/YAMLWriter.birch"
    this->visit(birch::row(value, i));
  }
  #line 209 "src/io/YAMLWriter.birch"
  libbirch_line_(209);
  #line 209 "src/io/YAMLWriter.birch"
  this->endSequence();
}

#line 212 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visitNil() {
  #line 212 "src/io/YAMLWriter.birch"
  libbirch_function_("visitNil", "src/io/YAMLWriter.birch", 212);
  #line 213 "src/io/YAMLWriter.birch"

    yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)"null", 4, 1, 1,
        YAML_ANY_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 221 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::startMapping() {
  #line 221 "src/io/YAMLWriter.birch"
  libbirch_function_("startMapping", "src/io/YAMLWriter.birch", 221);
  #line 222 "src/io/YAMLWriter.birch"

    yaml_mapping_start_event_initialize(&this->event, NULL, NULL, 1,
        YAML_ANY_MAPPING_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 229 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::endMapping() {
  #line 229 "src/io/YAMLWriter.birch"
  libbirch_function_("endMapping", "src/io/YAMLWriter.birch", 229);
  #line 230 "src/io/YAMLWriter.birch"

    yaml_mapping_end_event_initialize(&this->event);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 236 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::startSequence() {
  #line 236 "src/io/YAMLWriter.birch"
  libbirch_function_("startSequence", "src/io/YAMLWriter.birch", 236);
  #line 237 "src/io/YAMLWriter.birch"

    yaml_sequence_start_event_initialize(&this->event, NULL, NULL, 1,
        YAML_ANY_SEQUENCE_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 244 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::endSequence() {
  #line 244 "src/io/YAMLWriter.birch"
  libbirch_function_("endSequence", "src/io/YAMLWriter.birch", 244);
  #line 245 "src/io/YAMLWriter.birch"

    yaml_sequence_end_event_initialize(&this->event);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 3 "src/io/YAMLWriter.birch"
birch::type::YAMLWriter* birch::type::make_YAMLWriter_() {
  #line 3 "src/io/YAMLWriter.birch"
  return new birch::type::YAMLWriter();
  #line 3 "src/io/YAMLWriter.birch"
}

