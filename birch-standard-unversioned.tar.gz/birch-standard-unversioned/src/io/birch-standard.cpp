#line 1 "src/io/InputStream.birch"
birch::type::InputStream::InputStream(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/io/InputStream.birch"
    super_type_(),
    #line 8 "src/io/InputStream.birch"
    file() {
  //
}

#line 16 "src/io/InputStream.birch"
void birch::type::InputStream::open(const birch::type::String& path, const birch::type::Integer& mode, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/io/InputStream.birch"
  libbirch_function_("open", "src/io/InputStream.birch", 16);
  #line 17 "src/io/InputStream.birch"
  libbirch_line_(17);
  #line 17 "src/io/InputStream.birch"
  libbirch_assert_(!(this_()->file.query()));  // GCOV_EXCL_LINE
  #line 18 "src/io/InputStream.birch"
  libbirch_line_(18);
  #line 18 "src/io/InputStream.birch"
  this_()->file = birch::fopen(path, mode, handler_);
}

#line 26 "src/io/InputStream.birch"
void birch::type::InputStream::open(const birch::type::String& path, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/io/InputStream.birch"
  libbirch_function_("open", "src/io/InputStream.birch", 26);
  #line 27 "src/io/InputStream.birch"
  libbirch_line_(27);
  #line 27 "src/io/InputStream.birch"
  this_()->open(path, birch::READ(), handler_);
}

#line 33 "src/io/InputStream.birch"
void birch::type::InputStream::close(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/io/InputStream.birch"
  libbirch_function_("close", "src/io/InputStream.birch", 33);
  #line 34 "src/io/InputStream.birch"
  libbirch_line_(34);
  #line 34 "src/io/InputStream.birch"
  libbirch_assert_(this_()->file.query());  // GCOV_EXCL_LINE
  #line 35 "src/io/InputStream.birch"
  libbirch_line_(35);
  #line 35 "src/io/InputStream.birch"
  birch::fclose(this_()->file.get(), handler_);
  #line 36 "src/io/InputStream.birch"
  libbirch_line_(36);
  #line 36 "src/io/InputStream.birch"
  this_()->file = libbirch::nil;
}

#line 42 "src/io/InputStream.birch"
birch::type::Boolean birch::type::InputStream::eof(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/io/InputStream.birch"
  libbirch_function_("eof", "src/io/InputStream.birch", 42);
  #line 43 "src/io/InputStream.birch"
  libbirch_line_(43);
  #line 43 "src/io/InputStream.birch"
  libbirch_assert_(this_()->file.query());  // GCOV_EXCL_LINE
  #line 44 "src/io/InputStream.birch"
return ::feof(this->file.get());
    }

#line 52 "src/io/InputStream.birch"
libbirch::Optional<birch::type::Integer> birch::type::InputStream::scanInteger(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "src/io/InputStream.birch"
  libbirch_function_("scanInteger", "src/io/InputStream.birch", 52);
  #line 53 "src/io/InputStream.birch"
  libbirch_line_(53);
  #line 53 "src/io/InputStream.birch"
  libbirch_assert_(this_()->file.query());  // GCOV_EXCL_LINE
  #line 54 "src/io/InputStream.birch"
  libbirch_line_(54);
  #line 54 "src/io/InputStream.birch"
  libbirch::Optional<birch::type::Integer> x;
  #line 55 "src/io/InputStream.birch"
long long int y;  // ensure fscanf gets exactly the type it expects
    auto res = ::fscanf(this->file.get(), "%lld", &y);
    if (res == 1) {
      x = (birch::type::Integer)y;
    } 
      #line 62 "src/io/InputStream.birch"
  libbirch_line_(62);
  #line 62 "src/io/InputStream.birch"
  return x;
}

#line 68 "src/io/InputStream.birch"
libbirch::Optional<birch::type::Real> birch::type::InputStream::scanReal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 68 "src/io/InputStream.birch"
  libbirch_function_("scanReal", "src/io/InputStream.birch", 68);
  #line 69 "src/io/InputStream.birch"
  libbirch_line_(69);
  #line 69 "src/io/InputStream.birch"
  libbirch_assert_(this_()->file.query());  // GCOV_EXCL_LINE
  #line 70 "src/io/InputStream.birch"
  libbirch_line_(70);
  #line 70 "src/io/InputStream.birch"
  libbirch::Optional<birch::type::Real> x;
  #line 71 "src/io/InputStream.birch"
double y;  // ensure fscanf gets exactly the type it expects
    auto res = ::fscanf(this->file.get(), "%lf", &y);
    if (res == 1) {
      x = y;
    } 
      #line 78 "src/io/InputStream.birch"
  libbirch_line_(78);
  #line 78 "src/io/InputStream.birch"
  return x;
}

#line 1 "src/io/InputStream.birch"
birch::type::InputStream* birch::type::make_InputStream_() {
  #line 1 "src/io/InputStream.birch"
  return new birch::type::InputStream();
  #line 1 "src/io/InputStream.birch"
}

#line 85 "src/io/InputStream.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InputStream>> birch::InputStream(const birch::type::File& file, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 85 "src/io/InputStream.birch"
  libbirch_function_("InputStream", "src/io/InputStream.birch", 85);
  #line 86 "src/io/InputStream.birch"
  libbirch_line_(86);
  #line 86 "src/io/InputStream.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::InputStream>> o;
  #line 87 "src/io/InputStream.birch"
  libbirch_line_(87);
  #line 87 "src/io/InputStream.birch"
  o->file = file;
  #line 88 "src/io/InputStream.birch"
  libbirch_line_(88);
  #line 88 "src/io/InputStream.birch"
  return o;
}

#line 3 "src/io/JSONWriter.birch"
birch::type::JSONWriter::JSONWriter(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 3 "src/io/JSONWriter.birch"
    super_type_() {
  //
}

#line 9 "src/io/JSONWriter.birch"
void birch::type::JSONWriter::startMapping(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/io/JSONWriter.birch"
  libbirch_function_("startMapping", "src/io/JSONWriter.birch", 9);
  #line 10 "src/io/JSONWriter.birch"
yaml_mapping_start_event_initialize(&this->event, NULL, NULL, 1,
        YAML_FLOW_MAPPING_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 17 "src/io/JSONWriter.birch"
void birch::type::JSONWriter::endMapping(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 17 "src/io/JSONWriter.birch"
  libbirch_function_("endMapping", "src/io/JSONWriter.birch", 17);
  #line 18 "src/io/JSONWriter.birch"
yaml_mapping_end_event_initialize(&this->event);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 24 "src/io/JSONWriter.birch"
void birch::type::JSONWriter::startSequence(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/io/JSONWriter.birch"
  libbirch_function_("startSequence", "src/io/JSONWriter.birch", 24);
  #line 25 "src/io/JSONWriter.birch"
yaml_sequence_start_event_initialize(&this->event, NULL, NULL, 1,
        YAML_FLOW_SEQUENCE_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 32 "src/io/JSONWriter.birch"
void birch::type::JSONWriter::endSequence(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/io/JSONWriter.birch"
  libbirch_function_("endSequence", "src/io/JSONWriter.birch", 32);
  #line 33 "src/io/JSONWriter.birch"
yaml_sequence_end_event_initialize(&this->event);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 39 "src/io/JSONWriter.birch"
void birch::type::JSONWriter::scalar(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/io/JSONWriter.birch"
  libbirch_function_("scalar", "src/io/JSONWriter.birch", 39);
  #line 40 "src/io/JSONWriter.birch"
  libbirch_line_(40);
  #line 40 "src/io/JSONWriter.birch"
  auto value = birch::String(x, handler_);
  #line 41 "src/io/JSONWriter.birch"
yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)value.c_str(), value.length(), 1, 1,
        YAML_PLAIN_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 49 "src/io/JSONWriter.birch"
void birch::type::JSONWriter::scalar(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/io/JSONWriter.birch"
  libbirch_function_("scalar", "src/io/JSONWriter.birch", 49);
  #line 50 "src/io/JSONWriter.birch"
  libbirch_line_(50);
  #line 50 "src/io/JSONWriter.birch"
  auto value = birch::String(x, handler_);
  #line 51 "src/io/JSONWriter.birch"
yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)value.c_str(), value.length(), 1, 1,
        YAML_PLAIN_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 59 "src/io/JSONWriter.birch"
void birch::type::JSONWriter::scalar(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/io/JSONWriter.birch"
  libbirch_function_("scalar", "src/io/JSONWriter.birch", 59);
  #line 63 "src/io/JSONWriter.birch"
  libbirch_line_(63);
  #line 63 "src/io/JSONWriter.birch"
  birch::type::String value;
  #line 64 "src/io/JSONWriter.birch"
  libbirch_line_(64);
  #line 64 "src/io/JSONWriter.birch"
  if (x == birch::inf()) {
    #line 65 "src/io/JSONWriter.birch"
    libbirch_line_(65);
    #line 65 "src/io/JSONWriter.birch"
    value = birch::type::String("Infinity");
  } else {
    #line 66 "src/io/JSONWriter.birch"
    libbirch_line_(66);
    #line 66 "src/io/JSONWriter.birch"
    if (x == -birch::inf()) {
      #line 67 "src/io/JSONWriter.birch"
      libbirch_line_(67);
      #line 67 "src/io/JSONWriter.birch"
      value = birch::type::String("-Infinity");
    } else {
      #line 68 "src/io/JSONWriter.birch"
      libbirch_line_(68);
      #line 68 "src/io/JSONWriter.birch"
      if (birch::isnan(x, handler_)) {
        #line 69 "src/io/JSONWriter.birch"
        libbirch_line_(69);
        #line 69 "src/io/JSONWriter.birch"
        value = birch::type::String("NaN");
      } else {
        #line 71 "src/io/JSONWriter.birch"
        libbirch_line_(71);
        #line 71 "src/io/JSONWriter.birch"
        value = birch::String(x, handler_);
      }
    }
  }
  #line 73 "src/io/JSONWriter.birch"
yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)value.c_str(), value.length(), 1, 1,
        YAML_PLAIN_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 81 "src/io/JSONWriter.birch"
void birch::type::JSONWriter::scalar(const birch::type::String& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "src/io/JSONWriter.birch"
  libbirch_function_("scalar", "src/io/JSONWriter.birch", 81);
  #line 82 "src/io/JSONWriter.birch"
yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)value.c_str(), value.length(), 1, 1,
        YAML_DOUBLE_QUOTED_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 90 "src/io/JSONWriter.birch"
void birch::type::JSONWriter::null(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 90 "src/io/JSONWriter.birch"
  libbirch_function_("null", "src/io/JSONWriter.birch", 90);
  #line 91 "src/io/JSONWriter.birch"
yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)"null", 4, 1, 1,
        YAML_PLAIN_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 3 "src/io/JSONWriter.birch"
birch::type::JSONWriter* birch::type::make_JSONWriter_() {
  #line 3 "src/io/JSONWriter.birch"
  return new birch::type::JSONWriter();
  #line 3 "src/io/JSONWriter.birch"
}

#line 1 "src/io/OutputStream.birch"
birch::type::OutputStream::OutputStream(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/io/OutputStream.birch"
    super_type_(),
    #line 8 "src/io/OutputStream.birch"
    file() {
  //
}

#line 16 "src/io/OutputStream.birch"
void birch::type::OutputStream::open(const birch::type::String& path, const birch::type::Integer& mode, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/io/OutputStream.birch"
  libbirch_function_("open", "src/io/OutputStream.birch", 16);
  #line 17 "src/io/OutputStream.birch"
  libbirch_line_(17);
  #line 17 "src/io/OutputStream.birch"
  this_()->file = birch::fopen(path, mode, handler_);
}

#line 25 "src/io/OutputStream.birch"
void birch::type::OutputStream::open(const birch::type::String& path, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/io/OutputStream.birch"
  libbirch_function_("open", "src/io/OutputStream.birch", 25);
  #line 26 "src/io/OutputStream.birch"
  libbirch_line_(26);
  #line 26 "src/io/OutputStream.birch"
  this_()->open(path, birch::WRITE(), handler_);
}

#line 32 "src/io/OutputStream.birch"
void birch::type::OutputStream::close(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/io/OutputStream.birch"
  libbirch_function_("close", "src/io/OutputStream.birch", 32);
  #line 33 "src/io/OutputStream.birch"
  libbirch_line_(33);
  #line 33 "src/io/OutputStream.birch"
  libbirch_assert_(this_()->file.query());  // GCOV_EXCL_LINE
  #line 34 "src/io/OutputStream.birch"
  libbirch_line_(34);
  #line 34 "src/io/OutputStream.birch"
  birch::fclose(this_()->file.get(), handler_);
  #line 35 "src/io/OutputStream.birch"
  libbirch_line_(35);
  #line 35 "src/io/OutputStream.birch"
  this_()->file = libbirch::nil;
}

#line 41 "src/io/OutputStream.birch"
void birch::type::OutputStream::flush(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "src/io/OutputStream.birch"
  libbirch_function_("flush", "src/io/OutputStream.birch", 41);
  #line 42 "src/io/OutputStream.birch"
  libbirch_line_(42);
  #line 42 "src/io/OutputStream.birch"
  libbirch_assert_(this_()->file.query());  // GCOV_EXCL_LINE
  #line 43 "src/io/OutputStream.birch"
  libbirch_line_(43);
  #line 43 "src/io/OutputStream.birch"
  birch::fflush(this_()->file.get(), handler_);
}

#line 49 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const birch::type::String& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 49);
  #line 50 "src/io/OutputStream.birch"
  libbirch_line_(50);
  #line 50 "src/io/OutputStream.birch"
  libbirch_assert_(this_()->file.query());  // GCOV_EXCL_LINE
  #line 51 "src/io/OutputStream.birch"
::fprintf(this->file.get(), "%s", value.c_str());
    }

#line 59 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const birch::type::Boolean& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 59);
  #line 60 "src/io/OutputStream.birch"
  libbirch_line_(60);
  #line 60 "src/io/OutputStream.birch"
  this_()->print(birch::String(value, handler_), handler_);
}

#line 66 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const birch::type::Integer& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 66);
  #line 67 "src/io/OutputStream.birch"
  libbirch_line_(67);
  #line 67 "src/io/OutputStream.birch"
  this_()->print(birch::String(value, handler_), handler_);
}

#line 73 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const birch::type::Real& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 73 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 73);
  #line 74 "src/io/OutputStream.birch"
  libbirch_line_(74);
  #line 74 "src/io/OutputStream.birch"
  this_()->print(birch::String(value, handler_), handler_);
}

#line 80 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const libbirch::DefaultArray<birch::type::Boolean,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 80 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 80);
  #line 81 "src/io/OutputStream.birch"
  libbirch_line_(81);
  #line 81 "src/io/OutputStream.birch"
  this_()->print(birch::String(value, handler_), handler_);
}

#line 87 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const libbirch::DefaultArray<birch::type::Integer,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 87 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 87);
  #line 88 "src/io/OutputStream.birch"
  libbirch_line_(88);
  #line 88 "src/io/OutputStream.birch"
  this_()->print(birch::String(value, handler_), handler_);
}

#line 94 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const libbirch::DefaultArray<birch::type::Real,1>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 94 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 94);
  #line 95 "src/io/OutputStream.birch"
  libbirch_line_(95);
  #line 95 "src/io/OutputStream.birch"
  this_()->print(birch::String(value, handler_), handler_);
}

#line 101 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const libbirch::DefaultArray<birch::type::Boolean,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 101 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 101);
  #line 102 "src/io/OutputStream.birch"
  libbirch_line_(102);
  #line 102 "src/io/OutputStream.birch"
  this_()->print(birch::String(value, handler_), handler_);
}

#line 108 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const libbirch::DefaultArray<birch::type::Integer,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 108 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 108);
  #line 109 "src/io/OutputStream.birch"
  libbirch_line_(109);
  #line 109 "src/io/OutputStream.birch"
  this_()->print(birch::String(value, handler_), handler_);
}

#line 115 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const libbirch::DefaultArray<birch::type::Real,2>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 115 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 115);
  #line 116 "src/io/OutputStream.birch"
  libbirch_line_(116);
  #line 116 "src/io/OutputStream.birch"
  this_()->print(birch::String(value, handler_), handler_);
}

#line 122 "src/io/OutputStream.birch"
void birch::type::OutputStream::print(const birch::type::LLT& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 122 "src/io/OutputStream.birch"
  libbirch_function_("print", "src/io/OutputStream.birch", 122);
  #line 123 "src/io/OutputStream.birch"
  libbirch_line_(123);
  #line 123 "src/io/OutputStream.birch"
  this_()->print(birch::String(value, handler_), handler_);
}

#line 1 "src/io/OutputStream.birch"
birch::type::OutputStream* birch::type::make_OutputStream_() {
  #line 1 "src/io/OutputStream.birch"
  return new birch::type::OutputStream();
  #line 1 "src/io/OutputStream.birch"
}

#line 130 "src/io/OutputStream.birch"
libbirch::Lazy<libbirch::Shared<birch::type::OutputStream>> birch::OutputStream(const birch::type::File& file, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 130 "src/io/OutputStream.birch"
  libbirch_function_("OutputStream", "src/io/OutputStream.birch", 130);
  #line 131 "src/io/OutputStream.birch"
  libbirch_line_(131);
  #line 131 "src/io/OutputStream.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::OutputStream>> o;
  #line 132 "src/io/OutputStream.birch"
  libbirch_line_(132);
  #line 132 "src/io/OutputStream.birch"
  o->file = file;
  #line 133 "src/io/OutputStream.birch"
  libbirch_line_(133);
  #line 133 "src/io/OutputStream.birch"
  return o;
}

#line 18 "src/io/Reader.birch"
birch::type::Reader::Reader(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 18 "src/io/Reader.birch"
    super_type_() {
  //
}

#line 79 "src/io/Reader.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Reader>> birch::Reader(const birch::type::String& path, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 79 "src/io/Reader.birch"
  libbirch_function_("Reader", "src/io/Reader.birch", 79);
  #line 80 "src/io/Reader.birch"
  libbirch_line_(80);
  #line 80 "src/io/Reader.birch"
  auto ext = birch::extension(path, handler_);
  #line 81 "src/io/Reader.birch"
  libbirch_line_(81);
  #line 81 "src/io/Reader.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Reader>>> result;
  #line 82 "src/io/Reader.birch"
  libbirch_line_(82);
  #line 82 "src/io/Reader.birch"
  if (ext == birch::type::String(".json")) {
    #line 83 "src/io/Reader.birch"
    libbirch_line_(83);
    #line 83 "src/io/Reader.birch"
    libbirch::Lazy<libbirch::Shared<birch::type::JSONReader>> reader;
    #line 84 "src/io/Reader.birch"
    libbirch_line_(84);
    #line 84 "src/io/Reader.birch"
    reader->open(path, handler_);
    #line 85 "src/io/Reader.birch"
    libbirch_line_(85);
    #line 85 "src/io/Reader.birch"
    result = reader;
  } else {
    #line 86 "src/io/Reader.birch"
    libbirch_line_(86);
    #line 86 "src/io/Reader.birch"
    if (ext == birch::type::String(".yml")) {
      #line 87 "src/io/Reader.birch"
      libbirch_line_(87);
      #line 87 "src/io/Reader.birch"
      libbirch::Lazy<libbirch::Shared<birch::type::YAMLReader>> reader;
      #line 88 "src/io/Reader.birch"
      libbirch_line_(88);
      #line 88 "src/io/Reader.birch"
      reader->open(path, handler_);
      #line 89 "src/io/Reader.birch"
      libbirch_line_(89);
      #line 89 "src/io/Reader.birch"
      result = reader;
    }
  }
  #line 91 "src/io/Reader.birch"
  libbirch_line_(91);
  #line 91 "src/io/Reader.birch"
  if (!result.query()) {
    #line 92 "src/io/Reader.birch"
    libbirch_line_(92);
    #line 92 "src/io/Reader.birch"
    birch::error(birch::type::String("unrecognized file extension '") + ext + birch::type::String("' in path '") + path + birch::type::String("'; supported extensions are '.json' and '.yml'."), handler_);
  }
  #line 95 "src/io/Reader.birch"
  libbirch_line_(95);
  #line 95 "src/io/Reader.birch"
  return result.get();
}

#line 32 "src/io/Writer.birch"
birch::type::Writer::Writer(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 32 "src/io/Writer.birch"
    super_type_() {
  //
}

#line 102 "src/io/Writer.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Writer>> birch::Writer(const birch::type::String& path, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 102 "src/io/Writer.birch"
  libbirch_function_("Writer", "src/io/Writer.birch", 102);
  #line 103 "src/io/Writer.birch"
  libbirch_line_(103);
  #line 103 "src/io/Writer.birch"
  auto ext = birch::extension(path, handler_);
  #line 104 "src/io/Writer.birch"
  libbirch_line_(104);
  #line 104 "src/io/Writer.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Writer>>> result;
  #line 105 "src/io/Writer.birch"
  libbirch_line_(105);
  #line 105 "src/io/Writer.birch"
  if (ext == birch::type::String(".json")) {
    #line 106 "src/io/Writer.birch"
    libbirch_line_(106);
    #line 106 "src/io/Writer.birch"
    libbirch::Lazy<libbirch::Shared<birch::type::JSONWriter>> writer;
    #line 107 "src/io/Writer.birch"
    libbirch_line_(107);
    #line 107 "src/io/Writer.birch"
    writer->open(path, handler_);
    #line 108 "src/io/Writer.birch"
    libbirch_line_(108);
    #line 108 "src/io/Writer.birch"
    result = writer;
  } else {
    #line 109 "src/io/Writer.birch"
    libbirch_line_(109);
    #line 109 "src/io/Writer.birch"
    if (ext == birch::type::String(".yml")) {
      #line 110 "src/io/Writer.birch"
      libbirch_line_(110);
      #line 110 "src/io/Writer.birch"
      libbirch::Lazy<libbirch::Shared<birch::type::YAMLWriter>> writer;
      #line 111 "src/io/Writer.birch"
      libbirch_line_(111);
      #line 111 "src/io/Writer.birch"
      writer->open(path, handler_);
      #line 112 "src/io/Writer.birch"
      libbirch_line_(112);
      #line 112 "src/io/Writer.birch"
      result = writer;
    }
  }
  #line 114 "src/io/Writer.birch"
  libbirch_line_(114);
  #line 114 "src/io/Writer.birch"
  if (!result.query()) {
    #line 115 "src/io/Writer.birch"
    libbirch_line_(115);
    #line 115 "src/io/Writer.birch"
    birch::error(birch::type::String("unrecognized file extension '") + ext + birch::type::String("' in path '") + path + birch::type::String("'; supported extensions are '.json' and '.yml'."), handler_);
  }
  #line 118 "src/io/Writer.birch"
  libbirch_line_(118);
  #line 118 "src/io/Writer.birch"
  return result.get();
}

#line 3 "src/io/YAMLWriter.birch"
birch::type::YAMLWriter::YAMLWriter(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 3 "src/io/YAMLWriter.birch"
    super_type_(),
    #line 12 "src/io/YAMLWriter.birch"
    file() {
  //
}

#line 19 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::open(const birch::type::String& path, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/io/YAMLWriter.birch"
  libbirch_function_("open", "src/io/YAMLWriter.birch", 19);
  #line 20 "src/io/YAMLWriter.birch"
  libbirch_line_(20);
  #line 20 "src/io/YAMLWriter.birch"
  this_()->file = birch::fopen(path, birch::WRITE(), handler_);
  #line 21 "src/io/YAMLWriter.birch"
yaml_emitter_initialize(&this->emitter);
    yaml_emitter_set_unicode(&this->emitter, 1);
    yaml_emitter_set_output_file(&this->emitter, this->file);
    yaml_stream_start_event_initialize(&this->event, YAML_UTF8_ENCODING);
    yaml_emitter_emit(&this->emitter, &this->event);
    yaml_document_start_event_initialize(&this->event, NULL, NULL, NULL, 1);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 32 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::print(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/io/YAMLWriter.birch"
  libbirch_function_("print", "src/io/YAMLWriter.birch", 32);
  #line 33 "src/io/YAMLWriter.birch"
  libbirch_line_(33);
  #line 33 "src/io/YAMLWriter.birch"
  buffer->value->accept(shared_from_this_(), handler_);
}

#line 36 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::flush(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/io/YAMLWriter.birch"
  libbirch_function_("flush", "src/io/YAMLWriter.birch", 36);
  #line 37 "src/io/YAMLWriter.birch"
yaml_emitter_flush(&this->emitter);
      #line 40 "src/io/YAMLWriter.birch"
  libbirch_line_(40);
  #line 40 "src/io/YAMLWriter.birch"
  birch::fflush(this_()->file, handler_);
}

#line 43 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::close(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "src/io/YAMLWriter.birch"
  libbirch_function_("close", "src/io/YAMLWriter.birch", 43);
  #line 44 "src/io/YAMLWriter.birch"
yaml_document_end_event_initialize(&this->event, 1);
    yaml_emitter_emit(&this->emitter, &this->event);
    yaml_stream_end_event_initialize(&this->event);
    yaml_emitter_emit(&this->emitter, &this->event);
    yaml_emitter_delete(&this->emitter);
      #line 51 "src/io/YAMLWriter.birch"
  libbirch_line_(51);
  #line 51 "src/io/YAMLWriter.birch"
  birch::fclose(this_()->file, handler_);
}

#line 54 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::Lazy<libbirch::Shared<birch::type::ObjectValue>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 54);
  #line 55 "src/io/YAMLWriter.birch"
  libbirch_line_(55);
  #line 55 "src/io/YAMLWriter.birch"
  this_()->startMapping(handler_);
  #line 56 "src/io/YAMLWriter.birch"
  libbirch_line_(56);
  #line 56 "src/io/YAMLWriter.birch"
  auto entry = value->entries->walk(handler_);
  #line 57 "src/io/YAMLWriter.birch"
  libbirch_line_(57);
  #line 57 "src/io/YAMLWriter.birch"
  while (entry->hasNext(handler_)) {
    #line 58 "src/io/YAMLWriter.birch"
    libbirch_line_(58);
    #line 58 "src/io/YAMLWriter.birch"
    auto e = entry->next(handler_);
    #line 59 "src/io/YAMLWriter.birch"
    libbirch_line_(59);
    #line 59 "src/io/YAMLWriter.birch"
    this_()->scalar(e->name, handler_);
    #line 60 "src/io/YAMLWriter.birch"
    libbirch_line_(60);
    #line 60 "src/io/YAMLWriter.birch"
    e->buffer->value->accept(shared_from_this_(), handler_);
  }
  #line 62 "src/io/YAMLWriter.birch"
  libbirch_line_(62);
  #line 62 "src/io/YAMLWriter.birch"
  this_()->endMapping(handler_);
}

#line 65 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::Lazy<libbirch::Shared<birch::type::ArrayValue>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 65);
  #line 66 "src/io/YAMLWriter.birch"
  libbirch_line_(66);
  #line 66 "src/io/YAMLWriter.birch"
  this_()->startSequence(handler_);
  #line 67 "src/io/YAMLWriter.birch"
  libbirch_line_(67);
  #line 67 "src/io/YAMLWriter.birch"
  auto element = value->buffers->walk(handler_);
  #line 68 "src/io/YAMLWriter.birch"
  libbirch_line_(68);
  #line 68 "src/io/YAMLWriter.birch"
  while (element->hasNext(handler_)) {
    #line 69 "src/io/YAMLWriter.birch"
    libbirch_line_(69);
    #line 69 "src/io/YAMLWriter.birch"
    element->next(handler_)->value->accept(shared_from_this_(), handler_);
  }
  #line 71 "src/io/YAMLWriter.birch"
  libbirch_line_(71);
  #line 71 "src/io/YAMLWriter.birch"
  this_()->endSequence(handler_);
}

#line 74 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::Lazy<libbirch::Shared<birch::type::StringValue>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 74 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 74);
  #line 75 "src/io/YAMLWriter.birch"
  libbirch_line_(75);
  #line 75 "src/io/YAMLWriter.birch"
  this_()->scalar(value->value, handler_);
}

#line 78 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::Lazy<libbirch::Shared<birch::type::RealValue>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 78 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 78);
  #line 79 "src/io/YAMLWriter.birch"
  libbirch_line_(79);
  #line 79 "src/io/YAMLWriter.birch"
  this_()->scalar(value->value, handler_);
}

#line 82 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::Lazy<libbirch::Shared<birch::type::IntegerValue>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 82 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 82);
  #line 83 "src/io/YAMLWriter.birch"
  libbirch_line_(83);
  #line 83 "src/io/YAMLWriter.birch"
  this_()->scalar(value->value, handler_);
}

#line 86 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::Lazy<libbirch::Shared<birch::type::BooleanValue>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 86 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 86);
  #line 87 "src/io/YAMLWriter.birch"
  libbirch_line_(87);
  #line 87 "src/io/YAMLWriter.birch"
  this_()->scalar(value->value, handler_);
}

#line 90 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::Lazy<libbirch::Shared<birch::type::NilValue>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 90 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 90);
  #line 91 "src/io/YAMLWriter.birch"
  libbirch_line_(91);
  #line 91 "src/io/YAMLWriter.birch"
  this_()->null(handler_);
}

#line 94 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::Lazy<libbirch::Shared<birch::type::BooleanVectorValue>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 94 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 94);
  #line 95 "src/io/YAMLWriter.birch"
  libbirch_line_(95);
  #line 95 "src/io/YAMLWriter.birch"
  this_()->startSequence(handler_);
  #line 96 "src/io/YAMLWriter.birch"
  libbirch_line_(96);
  #line 96 "src/io/YAMLWriter.birch"
  auto v = value->value;
  #line 97 "src/io/YAMLWriter.birch"
  libbirch_line_(97);
  #line 97 "src/io/YAMLWriter.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(v, handler_); ++i) {
    #line 98 "src/io/YAMLWriter.birch"
    libbirch_line_(98);
    #line 98 "src/io/YAMLWriter.birch"
    this_()->scalar(v.get(libbirch::make_slice(i - 1)), handler_);
  }
  #line 100 "src/io/YAMLWriter.birch"
  libbirch_line_(100);
  #line 100 "src/io/YAMLWriter.birch"
  this_()->endSequence(handler_);
}

#line 103 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::Lazy<libbirch::Shared<birch::type::IntegerVectorValue>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 103 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 103);
  #line 104 "src/io/YAMLWriter.birch"
  libbirch_line_(104);
  #line 104 "src/io/YAMLWriter.birch"
  this_()->startSequence(handler_);
  #line 105 "src/io/YAMLWriter.birch"
  libbirch_line_(105);
  #line 105 "src/io/YAMLWriter.birch"
  auto v = value->value;
  #line 106 "src/io/YAMLWriter.birch"
  libbirch_line_(106);
  #line 106 "src/io/YAMLWriter.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(v, handler_); ++i) {
    #line 107 "src/io/YAMLWriter.birch"
    libbirch_line_(107);
    #line 107 "src/io/YAMLWriter.birch"
    this_()->scalar(v.get(libbirch::make_slice(i - 1)), handler_);
  }
  #line 109 "src/io/YAMLWriter.birch"
  libbirch_line_(109);
  #line 109 "src/io/YAMLWriter.birch"
  this_()->endSequence(handler_);
}

#line 112 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::Lazy<libbirch::Shared<birch::type::RealVectorValue>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 112 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 112);
  #line 113 "src/io/YAMLWriter.birch"
  libbirch_line_(113);
  #line 113 "src/io/YAMLWriter.birch"
  this_()->startSequence(handler_);
  #line 114 "src/io/YAMLWriter.birch"
  libbirch_line_(114);
  #line 114 "src/io/YAMLWriter.birch"
  auto v = value->value;
  #line 115 "src/io/YAMLWriter.birch"
  libbirch_line_(115);
  #line 115 "src/io/YAMLWriter.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(v, handler_); ++i) {
    #line 116 "src/io/YAMLWriter.birch"
    libbirch_line_(116);
    #line 116 "src/io/YAMLWriter.birch"
    this_()->scalar(v.get(libbirch::make_slice(i - 1)), handler_);
  }
  #line 118 "src/io/YAMLWriter.birch"
  libbirch_line_(118);
  #line 118 "src/io/YAMLWriter.birch"
  this_()->endSequence(handler_);
}

#line 121 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::Lazy<libbirch::Shared<birch::type::BooleanMatrixValue>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 121 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 121);
  #line 122 "src/io/YAMLWriter.birch"
  libbirch_line_(122);
  #line 122 "src/io/YAMLWriter.birch"
  auto v = value->value;
  #line 123 "src/io/YAMLWriter.birch"
  libbirch_line_(123);
  #line 123 "src/io/YAMLWriter.birch"
  auto m = birch::rows(v, handler_);
  #line 124 "src/io/YAMLWriter.birch"
  libbirch_line_(124);
  #line 124 "src/io/YAMLWriter.birch"
  auto n = birch::columns(v, handler_);
  #line 125 "src/io/YAMLWriter.birch"
  libbirch_line_(125);
  #line 125 "src/io/YAMLWriter.birch"
  if (m > birch::type::Integer(0)) {
    #line 126 "src/io/YAMLWriter.birch"
    libbirch_line_(126);
    #line 126 "src/io/YAMLWriter.birch"
    this_()->startSequence(handler_);
    #line 127 "src/io/YAMLWriter.birch"
    libbirch_line_(127);
    #line 127 "src/io/YAMLWriter.birch"
    for (auto i = birch::type::Integer(1); i <= m; ++i) {
      #line 128 "src/io/YAMLWriter.birch"
      libbirch_line_(128);
      #line 128 "src/io/YAMLWriter.birch"
      if (n > birch::type::Integer(0)) {
        #line 129 "src/io/YAMLWriter.birch"
        libbirch_line_(129);
        #line 129 "src/io/YAMLWriter.birch"
        this_()->startSequence(handler_);
        #line 130 "src/io/YAMLWriter.birch"
        libbirch_line_(130);
        #line 130 "src/io/YAMLWriter.birch"
        for (auto j = birch::type::Integer(1); j <= n; ++j) {
          #line 131 "src/io/YAMLWriter.birch"
          libbirch_line_(131);
          #line 131 "src/io/YAMLWriter.birch"
          this_()->scalar(v.get(libbirch::make_slice(i - 1, j - 1)), handler_);
        }
        #line 133 "src/io/YAMLWriter.birch"
        libbirch_line_(133);
        #line 133 "src/io/YAMLWriter.birch"
        this_()->endSequence(handler_);
      }
    }
    #line 136 "src/io/YAMLWriter.birch"
    libbirch_line_(136);
    #line 136 "src/io/YAMLWriter.birch"
    this_()->endSequence(handler_);
  } else {
    #line 138 "src/io/YAMLWriter.birch"
    libbirch_line_(138);
    #line 138 "src/io/YAMLWriter.birch"
    this_()->null(handler_);
  }
}

#line 142 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::Lazy<libbirch::Shared<birch::type::IntegerMatrixValue>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 142 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 142);
  #line 143 "src/io/YAMLWriter.birch"
  libbirch_line_(143);
  #line 143 "src/io/YAMLWriter.birch"
  auto v = value->value;
  #line 144 "src/io/YAMLWriter.birch"
  libbirch_line_(144);
  #line 144 "src/io/YAMLWriter.birch"
  auto m = birch::rows(v, handler_);
  #line 145 "src/io/YAMLWriter.birch"
  libbirch_line_(145);
  #line 145 "src/io/YAMLWriter.birch"
  auto n = birch::columns(v, handler_);
  #line 146 "src/io/YAMLWriter.birch"
  libbirch_line_(146);
  #line 146 "src/io/YAMLWriter.birch"
  if (m > birch::type::Integer(0)) {
    #line 147 "src/io/YAMLWriter.birch"
    libbirch_line_(147);
    #line 147 "src/io/YAMLWriter.birch"
    this_()->startSequence(handler_);
    #line 148 "src/io/YAMLWriter.birch"
    libbirch_line_(148);
    #line 148 "src/io/YAMLWriter.birch"
    for (auto i = birch::type::Integer(1); i <= m; ++i) {
      #line 149 "src/io/YAMLWriter.birch"
      libbirch_line_(149);
      #line 149 "src/io/YAMLWriter.birch"
      if (n > birch::type::Integer(0)) {
        #line 150 "src/io/YAMLWriter.birch"
        libbirch_line_(150);
        #line 150 "src/io/YAMLWriter.birch"
        this_()->startSequence(handler_);
        #line 151 "src/io/YAMLWriter.birch"
        libbirch_line_(151);
        #line 151 "src/io/YAMLWriter.birch"
        for (auto j = birch::type::Integer(1); j <= n; ++j) {
          #line 152 "src/io/YAMLWriter.birch"
          libbirch_line_(152);
          #line 152 "src/io/YAMLWriter.birch"
          this_()->scalar(v.get(libbirch::make_slice(i - 1, j - 1)), handler_);
        }
        #line 154 "src/io/YAMLWriter.birch"
        libbirch_line_(154);
        #line 154 "src/io/YAMLWriter.birch"
        this_()->endSequence(handler_);
      }
    }
    #line 157 "src/io/YAMLWriter.birch"
    libbirch_line_(157);
    #line 157 "src/io/YAMLWriter.birch"
    this_()->endSequence(handler_);
  } else {
    #line 159 "src/io/YAMLWriter.birch"
    libbirch_line_(159);
    #line 159 "src/io/YAMLWriter.birch"
    this_()->null(handler_);
  }
}

#line 163 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::visit(const libbirch::Lazy<libbirch::Shared<birch::type::RealMatrixValue>>& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 163 "src/io/YAMLWriter.birch"
  libbirch_function_("visit", "src/io/YAMLWriter.birch", 163);
  #line 164 "src/io/YAMLWriter.birch"
  libbirch_line_(164);
  #line 164 "src/io/YAMLWriter.birch"
  auto v = value->value;
  #line 165 "src/io/YAMLWriter.birch"
  libbirch_line_(165);
  #line 165 "src/io/YAMLWriter.birch"
  auto m = birch::rows(v, handler_);
  #line 166 "src/io/YAMLWriter.birch"
  libbirch_line_(166);
  #line 166 "src/io/YAMLWriter.birch"
  auto n = birch::columns(v, handler_);
  #line 167 "src/io/YAMLWriter.birch"
  libbirch_line_(167);
  #line 167 "src/io/YAMLWriter.birch"
  if (m > birch::type::Integer(0)) {
    #line 168 "src/io/YAMLWriter.birch"
    libbirch_line_(168);
    #line 168 "src/io/YAMLWriter.birch"
    this_()->startSequence(handler_);
    #line 169 "src/io/YAMLWriter.birch"
    libbirch_line_(169);
    #line 169 "src/io/YAMLWriter.birch"
    for (auto i = birch::type::Integer(1); i <= m; ++i) {
      #line 170 "src/io/YAMLWriter.birch"
      libbirch_line_(170);
      #line 170 "src/io/YAMLWriter.birch"
      if (n > birch::type::Integer(0)) {
        #line 171 "src/io/YAMLWriter.birch"
        libbirch_line_(171);
        #line 171 "src/io/YAMLWriter.birch"
        this_()->startSequence(handler_);
        #line 172 "src/io/YAMLWriter.birch"
        libbirch_line_(172);
        #line 172 "src/io/YAMLWriter.birch"
        for (auto j = birch::type::Integer(1); j <= n; ++j) {
          #line 173 "src/io/YAMLWriter.birch"
          libbirch_line_(173);
          #line 173 "src/io/YAMLWriter.birch"
          this_()->scalar(v.get(libbirch::make_slice(i - 1, j - 1)), handler_);
        }
        #line 175 "src/io/YAMLWriter.birch"
        libbirch_line_(175);
        #line 175 "src/io/YAMLWriter.birch"
        this_()->endSequence(handler_);
      }
    }
    #line 178 "src/io/YAMLWriter.birch"
    libbirch_line_(178);
    #line 178 "src/io/YAMLWriter.birch"
    this_()->endSequence(handler_);
  } else {
    #line 180 "src/io/YAMLWriter.birch"
    libbirch_line_(180);
    #line 180 "src/io/YAMLWriter.birch"
    this_()->null(handler_);
  }
}

#line 184 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::startMapping(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 184 "src/io/YAMLWriter.birch"
  libbirch_function_("startMapping", "src/io/YAMLWriter.birch", 184);
  #line 185 "src/io/YAMLWriter.birch"
yaml_mapping_start_event_initialize(&this->event, NULL, NULL, 1,
        YAML_ANY_MAPPING_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 192 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::endMapping(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 192 "src/io/YAMLWriter.birch"
  libbirch_function_("endMapping", "src/io/YAMLWriter.birch", 192);
  #line 193 "src/io/YAMLWriter.birch"
yaml_mapping_end_event_initialize(&this->event);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 199 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::startSequence(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 199 "src/io/YAMLWriter.birch"
  libbirch_function_("startSequence", "src/io/YAMLWriter.birch", 199);
  #line 200 "src/io/YAMLWriter.birch"
yaml_sequence_start_event_initialize(&this->event, NULL, NULL, 1,
        YAML_ANY_SEQUENCE_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 207 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::endSequence(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 207 "src/io/YAMLWriter.birch"
  libbirch_function_("endSequence", "src/io/YAMLWriter.birch", 207);
  #line 208 "src/io/YAMLWriter.birch"
yaml_sequence_end_event_initialize(&this->event);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 214 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::scalar(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 214 "src/io/YAMLWriter.birch"
  libbirch_function_("scalar", "src/io/YAMLWriter.birch", 214);
  #line 215 "src/io/YAMLWriter.birch"
  libbirch_line_(215);
  #line 215 "src/io/YAMLWriter.birch"
  auto value = birch::String(x, handler_);
  #line 216 "src/io/YAMLWriter.birch"
yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)value.c_str(), value.length(), 1, 1,
        YAML_ANY_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 224 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::scalar(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 224 "src/io/YAMLWriter.birch"
  libbirch_function_("scalar", "src/io/YAMLWriter.birch", 224);
  #line 225 "src/io/YAMLWriter.birch"
  libbirch_line_(225);
  #line 225 "src/io/YAMLWriter.birch"
  auto value = birch::String(x, handler_);
  #line 226 "src/io/YAMLWriter.birch"
yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)value.c_str(), value.length(), 1, 1,
        YAML_ANY_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 234 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::scalar(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 234 "src/io/YAMLWriter.birch"
  libbirch_function_("scalar", "src/io/YAMLWriter.birch", 234);
  #line 235 "src/io/YAMLWriter.birch"
  libbirch_line_(235);
  #line 235 "src/io/YAMLWriter.birch"
  auto value = birch::String(x, handler_);
  #line 236 "src/io/YAMLWriter.birch"
yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)value.c_str(), value.length(), 1, 1,
        YAML_ANY_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 244 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::scalar(const birch::type::String& value, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 244 "src/io/YAMLWriter.birch"
  libbirch_function_("scalar", "src/io/YAMLWriter.birch", 244);
  #line 245 "src/io/YAMLWriter.birch"
yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)value.c_str(), value.length(), 1, 1,
        YAML_ANY_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 253 "src/io/YAMLWriter.birch"
void birch::type::YAMLWriter::null(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 253 "src/io/YAMLWriter.birch"
  libbirch_function_("null", "src/io/YAMLWriter.birch", 253);
  #line 254 "src/io/YAMLWriter.birch"
yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)"null", 4, 1, 1,
        YAML_ANY_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 3 "src/io/YAMLWriter.birch"
birch::type::YAMLWriter* birch::type::make_YAMLWriter_() {
  #line 3 "src/io/YAMLWriter.birch"
  return new birch::type::YAMLWriter();
  #line 3 "src/io/YAMLWriter.birch"
}

#line 3 "src/io/YAMLReader.birch"
birch::type::YAMLReader::YAMLReader(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 3 "src/io/YAMLReader.birch"
    super_type_(),
    #line 12 "src/io/YAMLReader.birch"
    file() {
  //
}

#line 19 "src/io/YAMLReader.birch"
void birch::type::YAMLReader::open(const birch::type::String& path, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/io/YAMLReader.birch"
  libbirch_function_("open", "src/io/YAMLReader.birch", 19);
  #line 20 "src/io/YAMLReader.birch"
  libbirch_line_(20);
  #line 20 "src/io/YAMLReader.birch"
  this_()->file = birch::fopen(path, birch::READ(), handler_);
}

#line 23 "src/io/YAMLReader.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> birch::type::YAMLReader::scan(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "src/io/YAMLReader.birch"
  libbirch_function_("scan", "src/io/YAMLReader.birch", 23);
  #line 24 "src/io/YAMLReader.birch"
  libbirch_line_(24);
  #line 24 "src/io/YAMLReader.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> buffer;
  #line 25 "src/io/YAMLReader.birch"
yaml_parser_initialize(&this->parser);
    yaml_parser_set_input_file(&this->parser, this->file);
    int done = 0;
    while (!done) {
      if (!yaml_parser_parse(&this->parser, &this->event)) {
        error("parse error");
      }
      if (this->event.type == YAML_SEQUENCE_START_EVENT) {
        this->parseSequence(buffer);
      } else if (this->event.type == YAML_MAPPING_START_EVENT) {
        this->parseMapping(buffer);
      } else {
        done = this->event.type == YAML_STREAM_END_EVENT;
        yaml_event_delete(&this->event);
      }
    }
    yaml_parser_delete(&this->parser);
      #line 44 "src/io/YAMLReader.birch"
  libbirch_line_(44);
  #line 44 "src/io/YAMLReader.birch"
  return buffer;
}

#line 47 "src/io/YAMLReader.birch"
void birch::type::YAMLReader::walk(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "src/io/YAMLReader.birch"
  libbirch_function_("walk", "src/io/YAMLReader.birch", 47);
  #line 48 "src/io/YAMLReader.birch"
bool done = false;
    yaml_parser_initialize(&this->parser);
    yaml_parser_set_input_file(&this->parser, this->file);
    }

#line 55 "src/io/YAMLReader.birch"
birch::type::Boolean birch::type::YAMLReader::hasNext(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 55 "src/io/YAMLReader.birch"
  libbirch_function_("hasNext", "src/io/YAMLReader.birch", 55);
  #line 56 "src/io/YAMLReader.birch"
bool repeat = false, eof = false;
    do {
      if (!yaml_parser_parse(&this->parser, &this->event)) {
        error("parse error");
      }
      switch (this->event.type) {
        case YAML_SCALAR_EVENT:
        case YAML_SEQUENCE_START_EVENT:
        case YAML_MAPPING_START_EVENT:
          break;
        case YAML_STREAM_END_EVENT:
          eof = true;
          break;
        default:
          yaml_event_delete(&this->event);
          repeat = true;
          break;
      }
    } while (repeat);
    return !eof;
    }

#line 80 "src/io/YAMLReader.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> birch::type::YAMLReader::next(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 80 "src/io/YAMLReader.birch"
  libbirch_function_("next", "src/io/YAMLReader.birch", 80);
  #line 81 "src/io/YAMLReader.birch"
  libbirch_line_(81);
  #line 81 "src/io/YAMLReader.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> buffer;
  #line 82 "src/io/YAMLReader.birch"
switch (this->event.type) {
      case YAML_SCALAR_EVENT:
        this->parseScalar(buffer);
        break;
      case YAML_SEQUENCE_START_EVENT:
        this->parseSequence(buffer);
        break;
      case YAML_MAPPING_START_EVENT:
        this->parseMapping(buffer);
        break;
      default:
        /* hasNext() should have dealt with all other events */
        assert(false);
    }
      #line 98 "src/io/YAMLReader.birch"
  libbirch_line_(98);
  #line 98 "src/io/YAMLReader.birch"
  return buffer;
}

#line 101 "src/io/YAMLReader.birch"
void birch::type::YAMLReader::close(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 101 "src/io/YAMLReader.birch"
  libbirch_function_("close", "src/io/YAMLReader.birch", 101);
  #line 102 "src/io/YAMLReader.birch"
  libbirch_line_(102);
  #line 102 "src/io/YAMLReader.birch"
  birch::fclose(this_()->file, handler_);
}

#line 105 "src/io/YAMLReader.birch"
void birch::type::YAMLReader::parseMapping(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 105 "src/io/YAMLReader.birch"
  libbirch_function_("parseMapping", "src/io/YAMLReader.birch", 105);
  #line 106 "src/io/YAMLReader.birch"
  libbirch_line_(106);
  #line 106 "src/io/YAMLReader.birch"
  buffer->setObject(handler_);
  #line 107 "src/io/YAMLReader.birch"
yaml_event_delete(&this->event);
    int done = 0;
    while (!done) {
      /* read one name/value pair on each iteration */
      if (!yaml_parser_parse(&this->parser, &this->event)) {
        error("parse error");
      }
      if (this->event.type == YAML_SCALAR_EVENT) {
        /* name */
        char* data = (char*)this->event.data.scalar.value;
        size_t length = this->event.data.scalar.length;
        std::string name(data, length);
        yaml_event_delete(&this->event);
        
        /* value */
        if (!yaml_parser_parse(&this->parser, &this->event)) {
          error("parse error");
        }
        if (this->event.type == YAML_SCALAR_EVENT) {
          this->parseScalar(buffer->setChild(name));
        } else if (this->event.type == YAML_SEQUENCE_START_EVENT) {
          this->parseSequence(buffer->setChild(name));
        } else if (this->event.type == YAML_MAPPING_START_EVENT) {
          this->parseMapping(buffer->setChild(name));
        } else {
          buffer->setChild(name);
          yaml_event_delete(&this->event);
        }
      } else {
        done = this->event.type == YAML_MAPPING_END_EVENT;
        yaml_event_delete(&this->event);
      }
    }
    }

#line 144 "src/io/YAMLReader.birch"
void birch::type::YAMLReader::parseSequence(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 144 "src/io/YAMLReader.birch"
  libbirch_function_("parseSequence", "src/io/YAMLReader.birch", 144);
  #line 145 "src/io/YAMLReader.birch"
  libbirch_line_(145);
  #line 145 "src/io/YAMLReader.birch"
  buffer->setArray(handler_);
  #line 146 "src/io/YAMLReader.birch"
yaml_event_delete(&this->event);
    int done = 0;
    while (!done) {
      if (!yaml_parser_parse(&this->parser, &this->event)) {
        error("parse error");
      }
      if (this->event.type == YAML_SCALAR_EVENT) {
        this->parseScalar(buffer->push());
      } else if (this->event.type == YAML_SEQUENCE_START_EVENT) {
        this->parseSequence(buffer->push());
      } else if (this->event.type == YAML_MAPPING_START_EVENT) {
        this->parseMapping(buffer->push());
      } else {
        done = this->event.type == YAML_SEQUENCE_END_EVENT;
        yaml_event_delete(&this->event);
      }
    }
    }

#line 167 "src/io/YAMLReader.birch"
void birch::type::YAMLReader::parseScalar(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 167 "src/io/YAMLReader.birch"
  libbirch_function_("parseScalar", "src/io/YAMLReader.birch", 167);
  #line 168 "src/io/YAMLReader.birch"
auto data = (char*)this->event.data.scalar.value;
    auto length = this->event.data.scalar.length;
    auto endptr = data;
    
    auto intValue = std::strtoll(data, &endptr, 10);
    if (endptr == data + length) {
      buffer->setInteger(intValue);
    } else {
      auto realValue = std::strtod(data, &endptr);
      if (endptr == data + length) {
        buffer->setReal(realValue);
      } else if (std::strcmp(data, "true") == 0) {
        buffer->setBoolean(true);
      } else if (std::strcmp(data, "false") == 0) {
        buffer->setBoolean(false);
      } else if (std::strcmp(data, "null") == 0) {
        buffer->setNil();
      } else if (std::strcmp(data, "Infinity") == 0) {
        buffer->setReal(std::numeric_limits<Real>::infinity());
      } else if (std::strcmp(data, "-Infinity") == 0) {
        buffer->setReal(-std::numeric_limits<Real>::infinity());
      } else if (std::strcmp(data, "NaN") == 0) {
        buffer->setReal(std::numeric_limits<Real>::quiet_NaN());
      } else {
        buffer->setString(std::string(data, length));
      }
    }
    yaml_event_delete(&this->event);
    }

#line 3 "src/io/YAMLReader.birch"
birch::type::YAMLReader* birch::type::make_YAMLReader_() {
  #line 3 "src/io/YAMLReader.birch"
  return new birch::type::YAMLReader();
  #line 3 "src/io/YAMLReader.birch"
}

