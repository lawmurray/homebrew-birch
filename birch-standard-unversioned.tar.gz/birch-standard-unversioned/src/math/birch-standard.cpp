#line 4 "src/math/canonical.birch"
birch::type::Real birch::canonical(const birch::type::Real& x) {
  #line 4 "src/math/canonical.birch"
  libbirch_function_("canonical", "src/math/canonical.birch", 4);
  #line 5 "src/math/canonical.birch"
  libbirch_line_(5);
  #line 5 "src/math/canonical.birch"
  return x;
}

#line 11 "src/math/canonical.birch"
birch::type::Integer birch::canonical(const birch::type::Integer& x) {
  #line 11 "src/math/canonical.birch"
  libbirch_function_("canonical", "src/math/canonical.birch", 11);
  #line 12 "src/math/canonical.birch"
  libbirch_line_(12);
  #line 12 "src/math/canonical.birch"
  return x;
}

#line 18 "src/math/canonical.birch"
birch::type::Boolean birch::canonical(const birch::type::Boolean& x) {
  #line 18 "src/math/canonical.birch"
  libbirch_function_("canonical", "src/math/canonical.birch", 18);
  #line 19 "src/math/canonical.birch"
  libbirch_line_(19);
  #line 19 "src/math/canonical.birch"
  return x;
}

#line 25 "src/math/canonical.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::canonical(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 25 "src/math/canonical.birch"
  libbirch_function_("canonical", "src/math/canonical.birch", 25);
  #line 26 "src/math/canonical.birch"
  libbirch_line_(26);
  #line 26 "src/math/canonical.birch"
  return x;
}

#line 32 "src/math/canonical.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::canonical(const libbirch::DefaultArray<birch::type::Integer,1>& x) {
  #line 32 "src/math/canonical.birch"
  libbirch_function_("canonical", "src/math/canonical.birch", 32);
  #line 33 "src/math/canonical.birch"
  libbirch_line_(33);
  #line 33 "src/math/canonical.birch"
  return x;
}

#line 38 "src/math/canonical.birch"
libbirch::DefaultArray<birch::type::Boolean,1> birch::canonical(const libbirch::DefaultArray<birch::type::Boolean,1>& x) {
  #line 38 "src/math/canonical.birch"
  libbirch_function_("canonical", "src/math/canonical.birch", 38);
  #line 39 "src/math/canonical.birch"
  libbirch_line_(39);
  #line 39 "src/math/canonical.birch"
  return x;
}

#line 45 "src/math/canonical.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::canonical(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 45 "src/math/canonical.birch"
  libbirch_function_("canonical", "src/math/canonical.birch", 45);
  #line 46 "src/math/canonical.birch"
  libbirch_line_(46);
  #line 46 "src/math/canonical.birch"
  return X;
}

#line 52 "src/math/canonical.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::canonical(const libbirch::DefaultArray<birch::type::Integer,2>& X) {
  #line 52 "src/math/canonical.birch"
  libbirch_function_("canonical", "src/math/canonical.birch", 52);
  #line 53 "src/math/canonical.birch"
  libbirch_line_(53);
  #line 53 "src/math/canonical.birch"
  return X;
}

#line 59 "src/math/canonical.birch"
libbirch::DefaultArray<birch::type::Boolean,2> birch::canonical(const libbirch::DefaultArray<birch::type::Boolean,2>& X) {
  #line 59 "src/math/canonical.birch"
  libbirch_function_("canonical", "src/math/canonical.birch", 59);
  #line 60 "src/math/canonical.birch"
  libbirch_line_(60);
  #line 60 "src/math/canonical.birch"
  return X;
}

#line 66 "src/math/canonical.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::canonical(const birch::type::LLT& X) {
  #line 66 "src/math/canonical.birch"
  libbirch_function_("canonical", "src/math/canonical.birch", 66);
  #line 67 "src/math/canonical.birch"

  return X.reconstructedMatrix();
  }

#line 1 "src/math/cdf.birch"

#include <boost/math/distributions.hpp>
#line 14 "src/math/cdf.birch"
birch::type::Real birch::cdf_binomial(const birch::type::Integer& x, const birch::type::Integer& n, const birch::type::Real& ρ) {
  #line 14 "src/math/cdf.birch"
  libbirch_function_("cdf_binomial", "src/math/cdf.birch", 14);
  #line 15 "src/math/cdf.birch"
  libbirch_line_(15);
  #line 15 "src/math/cdf.birch"
  libbirch_assert_(birch::type::Integer(0) <= n);
  #line 16 "src/math/cdf.birch"
  libbirch_line_(16);
  #line 16 "src/math/cdf.birch"
  libbirch_assert_(0.0 <= ρ && ρ <= 1.0);
  #line 18 "src/math/cdf.birch"
  libbirch_line_(18);
  #line 18 "src/math/cdf.birch"
  if (x < birch::type::Integer(0)) {
    #line 19 "src/math/cdf.birch"
    libbirch_line_(19);
    #line 19 "src/math/cdf.birch"
    return 0.0;
  } else {
    #line 20 "src/math/cdf.birch"
    libbirch_line_(20);
    #line 20 "src/math/cdf.birch"
    if (x > n) {
      #line 21 "src/math/cdf.birch"
      libbirch_line_(21);
      #line 21 "src/math/cdf.birch"
      return 1.0;
    } else {
      #line 23 "src/math/cdf.birch"
      libbirch_line_(23);
      #line 23 "src/math/cdf.birch"
      return birch::ibeta(n - x, x + 1.0, 1.0 - ρ);
    }
  }
}

#line 36 "src/math/cdf.birch"
birch::type::Real birch::cdf_negative_binomial(const birch::type::Integer& x, const birch::type::Integer& k, const birch::type::Real& ρ) {
  #line 36 "src/math/cdf.birch"
  libbirch_function_("cdf_negative_binomial", "src/math/cdf.birch", 36);
  #line 37 "src/math/cdf.birch"
  libbirch_line_(37);
  #line 37 "src/math/cdf.birch"
  libbirch_assert_(birch::type::Integer(0) < k);
  #line 38 "src/math/cdf.birch"
  libbirch_line_(38);
  #line 38 "src/math/cdf.birch"
  libbirch_assert_(0.0 <= ρ && ρ <= 1.0);
  #line 40 "src/math/cdf.birch"
  libbirch_line_(40);
  #line 40 "src/math/cdf.birch"
  if (x < birch::type::Integer(0)) {
    #line 41 "src/math/cdf.birch"
    libbirch_line_(41);
    #line 41 "src/math/cdf.birch"
    return 0.0;
  } else {
    #line 43 "src/math/cdf.birch"
    libbirch_line_(43);
    #line 43 "src/math/cdf.birch"
    return birch::ibeta(k, x + 1.0, ρ);
  }
}

#line 55 "src/math/cdf.birch"
birch::type::Real birch::cdf_poisson(const birch::type::Integer& x, const birch::type::Real& λ) {
  #line 55 "src/math/cdf.birch"
  libbirch_function_("cdf_poisson", "src/math/cdf.birch", 55);
  #line 56 "src/math/cdf.birch"
  libbirch_line_(56);
  #line 56 "src/math/cdf.birch"
  libbirch_assert_(0.0 <= λ);
  #line 58 "src/math/cdf.birch"
  libbirch_line_(58);
  #line 58 "src/math/cdf.birch"
  if (x < birch::type::Integer(0)) {
    #line 59 "src/math/cdf.birch"
    libbirch_line_(59);
    #line 59 "src/math/cdf.birch"
    return 0.0;
  } else {
    #line 61 "src/math/cdf.birch"
    libbirch_line_(61);
    #line 61 "src/math/cdf.birch"
    auto k = x + 1.0;
    #line 62 "src/math/cdf.birch"
    libbirch_line_(62);
    #line 62 "src/math/cdf.birch"
    return birch::upper_inc_gamma(k, λ);
  }
}

#line 75 "src/math/cdf.birch"
birch::type::Real birch::cdf_uniform_int(const birch::type::Integer& x, const birch::type::Integer& l, const birch::type::Integer& u) {
  #line 75 "src/math/cdf.birch"
  libbirch_function_("cdf_uniform_int", "src/math/cdf.birch", 75);
  #line 76 "src/math/cdf.birch"
  libbirch_line_(76);
  #line 76 "src/math/cdf.birch"
  if (x < l) {
    #line 77 "src/math/cdf.birch"
    libbirch_line_(77);
    #line 77 "src/math/cdf.birch"
    return 0.0;
  } else {
    #line 78 "src/math/cdf.birch"
    libbirch_line_(78);
    #line 78 "src/math/cdf.birch"
    if (x > u) {
      #line 79 "src/math/cdf.birch"
      libbirch_line_(79);
      #line 79 "src/math/cdf.birch"
      return 1.0;
    } else {
      #line 81 "src/math/cdf.birch"
      libbirch_line_(81);
      #line 81 "src/math/cdf.birch"
      return (x - l + birch::type::Integer(1)) / birch::Real(u - l + birch::type::Integer(1));
    }
  }
}

#line 93 "src/math/cdf.birch"
birch::type::Real birch::cdf_categorical(const birch::type::Integer& x, const libbirch::DefaultArray<birch::type::Real,1>& ρ) {
  #line 93 "src/math/cdf.birch"
  libbirch_function_("cdf_categorical", "src/math/cdf.birch", 93);
  #line 94 "src/math/cdf.birch"
  libbirch_line_(94);
  #line 94 "src/math/cdf.birch"
  if (birch::type::Integer(1) <= x && x <= birch::length(ρ)) {
    #line 95 "src/math/cdf.birch"
    libbirch_line_(95);
    #line 95 "src/math/cdf.birch"
    return birch::sum(ρ(libbirch::make_range(birch::type::Integer(1), x)));
  } else {
    #line 97 "src/math/cdf.birch"
    libbirch_line_(97);
    #line 97 "src/math/cdf.birch"
    return -(birch::inf());
  }
}

#line 110 "src/math/cdf.birch"
birch::type::Real birch::cdf_uniform(const birch::type::Real& x, const birch::type::Real& l, const birch::type::Real& u) {
  #line 110 "src/math/cdf.birch"
  libbirch_function_("cdf_uniform", "src/math/cdf.birch", 110);
  #line 111 "src/math/cdf.birch"
  libbirch_line_(111);
  #line 111 "src/math/cdf.birch"
  libbirch_assert_(l <= u);
  #line 113 "src/math/cdf.birch"
  libbirch_line_(113);
  #line 113 "src/math/cdf.birch"
  if (x <= l) {
    #line 114 "src/math/cdf.birch"
    libbirch_line_(114);
    #line 114 "src/math/cdf.birch"
    return 0.0;
  } else {
    #line 115 "src/math/cdf.birch"
    libbirch_line_(115);
    #line 115 "src/math/cdf.birch"
    if (x > u) {
      #line 116 "src/math/cdf.birch"
      libbirch_line_(116);
      #line 116 "src/math/cdf.birch"
      return 1.0;
    } else {
      #line 118 "src/math/cdf.birch"
      libbirch_line_(118);
      #line 118 "src/math/cdf.birch"
      return (x - l) / (u - l);
    }
  }
}

#line 132 "src/math/cdf.birch"
birch::type::Real birch::cdf_inverse_gamma_gamma(const birch::type::Real& x, const birch::type::Real& k, const birch::type::Real& α, const birch::type::Real& β) {
  #line 132 "src/math/cdf.birch"
  libbirch_function_("cdf_inverse_gamma_gamma", "src/math/cdf.birch", 132);
  #line 133 "src/math/cdf.birch"
  libbirch_line_(133);
  #line 133 "src/math/cdf.birch"
  if (x <= 0.0) {
    #line 134 "src/math/cdf.birch"
    libbirch_line_(134);
    #line 134 "src/math/cdf.birch"
    return 0.0;
  } else {
    #line 136 "src/math/cdf.birch"
    libbirch_line_(136);
    #line 136 "src/math/cdf.birch"
    return birch::ibeta(k, α, x / (β + x));
  }
}

#line 148 "src/math/cdf.birch"
birch::type::Real birch::cdf_exponential(const birch::type::Real& x, const birch::type::Real& λ) {
  #line 148 "src/math/cdf.birch"
  libbirch_function_("cdf_exponential", "src/math/cdf.birch", 148);
  #line 149 "src/math/cdf.birch"
  libbirch_line_(149);
  #line 149 "src/math/cdf.birch"
  libbirch_assert_(0.0 < λ);
  #line 151 "src/math/cdf.birch"
  libbirch_line_(151);
  #line 151 "src/math/cdf.birch"
  if (x <= 0.0) {
    #line 152 "src/math/cdf.birch"
    libbirch_line_(152);
    #line 152 "src/math/cdf.birch"
    return 0.0;
  } else {
    #line 154 "src/math/cdf.birch"
    libbirch_line_(154);
    #line 154 "src/math/cdf.birch"
    return -(birch::expm1(-(λ) * x));
  }
}

#line 167 "src/math/cdf.birch"
birch::type::Real birch::cdf_weibull(const birch::type::Real& x, const birch::type::Real& k, const birch::type::Real& λ) {
  #line 167 "src/math/cdf.birch"
  libbirch_function_("cdf_weibull", "src/math/cdf.birch", 167);
  #line 168 "src/math/cdf.birch"
  libbirch_line_(168);
  #line 168 "src/math/cdf.birch"
  libbirch_assert_(0.0 < k);
  #line 169 "src/math/cdf.birch"
  libbirch_line_(169);
  #line 169 "src/math/cdf.birch"
  libbirch_assert_(0.0 < λ);
  #line 170 "src/math/cdf.birch"
  libbirch_line_(170);
  #line 170 "src/math/cdf.birch"
  if (x >= birch::type::Integer(0)) {
    #line 171 "src/math/cdf.birch"
    libbirch_line_(171);
    #line 171 "src/math/cdf.birch"
    return -(birch::expm1(-(birch::pow(x / λ, k))));
  } else {
    #line 173 "src/math/cdf.birch"
    libbirch_line_(173);
    #line 173 "src/math/cdf.birch"
    return birch::type::Integer(0);
  }
}

#line 186 "src/math/cdf.birch"
birch::type::Real birch::cdf_gaussian(const birch::type::Real& x, const birch::type::Real& μ, const birch::type::Real& σ2) {
  #line 186 "src/math/cdf.birch"
  libbirch_function_("cdf_gaussian", "src/math/cdf.birch", 186);
  #line 187 "src/math/cdf.birch"
  libbirch_line_(187);
  #line 187 "src/math/cdf.birch"
  libbirch_assert_(0.0 < σ2);
  #line 188 "src/math/cdf.birch"
  libbirch_line_(188);
  #line 188 "src/math/cdf.birch"
  return 0.5 * (1.0 + birch::erf((x - μ) / birch::sqrt(σ2 * 2.0)));
}

#line 199 "src/math/cdf.birch"
birch::type::Real birch::cdf_student_t(const birch::type::Real& x, const birch::type::Real& ν) {
  #line 199 "src/math/cdf.birch"
  libbirch_function_("cdf_student_t", "src/math/cdf.birch", 199);
  #line 201 "src/math/cdf.birch"
  libbirch_line_(201);
  #line 201 "src/math/cdf.birch"
  libbirch_assert_(0.0 < ν);
  #line 202 "src/math/cdf.birch"
  libbirch_line_(202);
  #line 202 "src/math/cdf.birch"
  auto t = 0.5 * (x + birch::sqrt(x * x + ν)) / birch::sqrt(x * x + ν);
  #line 203 "src/math/cdf.birch"
  libbirch_line_(203);
  #line 203 "src/math/cdf.birch"
  auto prob = birch::ibeta(0.5 * ν, 0.5 * ν, t);
  #line 204 "src/math/cdf.birch"
  libbirch_line_(204);
  #line 204 "src/math/cdf.birch"
  return prob;
}

#line 217 "src/math/cdf.birch"
birch::type::Real birch::cdf_student_t(const birch::type::Real& x, const birch::type::Real& k, const birch::type::Real& μ, const birch::type::Real& σ2) {
  #line 217 "src/math/cdf.birch"
  libbirch_function_("cdf_student_t", "src/math/cdf.birch", 217);
  #line 218 "src/math/cdf.birch"
  libbirch_line_(218);
  #line 218 "src/math/cdf.birch"
  libbirch_assert_(0.0 < σ2);
  #line 219 "src/math/cdf.birch"
  libbirch_line_(219);
  #line 219 "src/math/cdf.birch"
  return birch::cdf_student_t((x - μ) / birch::sqrt(σ2 / k), k);
}

#line 231 "src/math/cdf.birch"
birch::type::Real birch::cdf_beta(const birch::type::Real& x, const birch::type::Real& α, const birch::type::Real& β) {
  #line 231 "src/math/cdf.birch"
  libbirch_function_("cdf_beta", "src/math/cdf.birch", 231);
  #line 232 "src/math/cdf.birch"
  libbirch_line_(232);
  #line 232 "src/math/cdf.birch"
  libbirch_assert_(0.0 < α);
  #line 233 "src/math/cdf.birch"
  libbirch_line_(233);
  #line 233 "src/math/cdf.birch"
  libbirch_assert_(0.0 < β);
  #line 235 "src/math/cdf.birch"
  libbirch_line_(235);
  #line 235 "src/math/cdf.birch"
  if (x < 0.0) {
    #line 236 "src/math/cdf.birch"
    libbirch_line_(236);
    #line 236 "src/math/cdf.birch"
    return 0.0;
  } else {
    #line 237 "src/math/cdf.birch"
    libbirch_line_(237);
    #line 237 "src/math/cdf.birch"
    if (x > 1.0) {
      #line 238 "src/math/cdf.birch"
      libbirch_line_(238);
      #line 238 "src/math/cdf.birch"
      return 1.0;
    } else {
      #line 240 "src/math/cdf.birch"
      libbirch_line_(240);
      #line 240 "src/math/cdf.birch"
      return birch::ibeta(α, β, x);
    }
  }
}

#line 252 "src/math/cdf.birch"
birch::type::Real birch::cdf_chi_squared(const birch::type::Real& x, const birch::type::Real& ν) {
  #line 252 "src/math/cdf.birch"
  libbirch_function_("cdf_chi_squared", "src/math/cdf.birch", 252);
  #line 253 "src/math/cdf.birch"
  libbirch_line_(253);
  #line 253 "src/math/cdf.birch"
  libbirch_assert_(0.0 < ν);
  #line 254 "src/math/cdf.birch"
  libbirch_line_(254);
  #line 254 "src/math/cdf.birch"
  return birch::lower_inc_gamma(0.5 * ν, 0.5 * x) / birch::gamma(0.5 * ν);
}

#line 266 "src/math/cdf.birch"
birch::type::Real birch::cdf_gamma(const birch::type::Real& x, const birch::type::Real& k, const birch::type::Real& θ) {
  #line 266 "src/math/cdf.birch"
  libbirch_function_("cdf_gamma", "src/math/cdf.birch", 266);
  #line 267 "src/math/cdf.birch"
  libbirch_line_(267);
  #line 267 "src/math/cdf.birch"
  libbirch_assert_(0.0 < k);
  #line 268 "src/math/cdf.birch"
  libbirch_line_(268);
  #line 268 "src/math/cdf.birch"
  libbirch_assert_(0.0 < θ);
  #line 270 "src/math/cdf.birch"
  libbirch_line_(270);
  #line 270 "src/math/cdf.birch"
  if (x <= 0.0) {
    #line 271 "src/math/cdf.birch"
    libbirch_line_(271);
    #line 271 "src/math/cdf.birch"
    return 0.0;
  } else {
    #line 273 "src/math/cdf.birch"
    libbirch_line_(273);
    #line 273 "src/math/cdf.birch"
    return birch::lower_inc_gamma(k, x / θ);
  }
}

#line 286 "src/math/cdf.birch"
birch::type::Real birch::cdf_inverse_gamma(const birch::type::Real& x, const birch::type::Real& α, const birch::type::Real& β) {
  #line 286 "src/math/cdf.birch"
  libbirch_function_("cdf_inverse_gamma", "src/math/cdf.birch", 286);
  #line 287 "src/math/cdf.birch"
  libbirch_line_(287);
  #line 287 "src/math/cdf.birch"
  libbirch_assert_(0.0 < α);
  #line 288 "src/math/cdf.birch"
  libbirch_line_(288);
  #line 288 "src/math/cdf.birch"
  libbirch_assert_(0.0 < β);
  #line 290 "src/math/cdf.birch"
  libbirch_line_(290);
  #line 290 "src/math/cdf.birch"
  if (x <= 0.0) {
    #line 291 "src/math/cdf.birch"
    libbirch_line_(291);
    #line 291 "src/math/cdf.birch"
    return 0.0;
  } else {
    #line 293 "src/math/cdf.birch"
    libbirch_line_(293);
    #line 293 "src/math/cdf.birch"
    return birch::upper_inc_gamma(α, β / x);
  }
}

#line 308 "src/math/cdf.birch"
birch::type::Real birch::cdf_normal_inverse_gamma(const birch::type::Real& x, const birch::type::Real& μ, const birch::type::Real& σ2, const birch::type::Real& α, const birch::type::Real& β) {
  #line 308 "src/math/cdf.birch"
  libbirch_function_("cdf_normal_inverse_gamma", "src/math/cdf.birch", 308);
  #line 310 "src/math/cdf.birch"
  libbirch_line_(310);
  #line 310 "src/math/cdf.birch"
  return birch::cdf_student_t(x, 2.0 * α, μ, σ2 * 2.0 * β);
}

#line 323 "src/math/cdf.birch"
birch::type::Real birch::cdf_beta_binomial(const birch::type::Integer& x, const birch::type::Integer& n, const birch::type::Real& α, const birch::type::Real& β) {
  #line 323 "src/math/cdf.birch"
  libbirch_function_("cdf_beta_binomial", "src/math/cdf.birch", 323);
  #line 324 "src/math/cdf.birch"
  libbirch_line_(324);
  #line 324 "src/math/cdf.birch"
  birch::type::Real P = 0.0;
  #line 325 "src/math/cdf.birch"
  libbirch_line_(325);
  #line 325 "src/math/cdf.birch"
  for (auto i = birch::type::Integer(0); i <= birch::min(n, x); ++i) {
    #line 326 "src/math/cdf.birch"
    libbirch_line_(326);
    #line 326 "src/math/cdf.birch"
    P = P + birch::exp(birch::logpdf_beta_binomial(i, n, α, β));
  }
  #line 328 "src/math/cdf.birch"
  libbirch_line_(328);
  #line 328 "src/math/cdf.birch"
  return P;
}

#line 340 "src/math/cdf.birch"
birch::type::Real birch::cdf_gamma_poisson(const birch::type::Integer& x, const birch::type::Real& k, const birch::type::Real& θ) {
  #line 340 "src/math/cdf.birch"
  libbirch_function_("cdf_gamma_poisson", "src/math/cdf.birch", 340);
  #line 341 "src/math/cdf.birch"
  libbirch_line_(341);
  #line 341 "src/math/cdf.birch"
  libbirch_assert_(0.0 < k);
  #line 342 "src/math/cdf.birch"
  libbirch_line_(342);
  #line 342 "src/math/cdf.birch"
  libbirch_assert_(0.0 < θ);
  #line 343 "src/math/cdf.birch"
  libbirch_line_(343);
  #line 343 "src/math/cdf.birch"
  libbirch_assert_(k == birch::floor(k));
  #line 345 "src/math/cdf.birch"
  libbirch_line_(345);
  #line 345 "src/math/cdf.birch"
  return birch::cdf_negative_binomial(x, birch::Integer(k), 1.0 / (θ + 1.0));
}

#line 357 "src/math/cdf.birch"
birch::type::Real birch::cdf_lomax(const birch::type::Real& x, const birch::type::Real& λ, const birch::type::Real& α) {
  #line 357 "src/math/cdf.birch"
  libbirch_function_("cdf_lomax", "src/math/cdf.birch", 357);
  #line 358 "src/math/cdf.birch"
  libbirch_line_(358);
  #line 358 "src/math/cdf.birch"
  libbirch_assert_(0.0 < λ);
  #line 359 "src/math/cdf.birch"
  libbirch_line_(359);
  #line 359 "src/math/cdf.birch"
  libbirch_assert_(0.0 < α);
  #line 361 "src/math/cdf.birch"
  libbirch_line_(361);
  #line 361 "src/math/cdf.birch"
  if (x <= 0.0) {
    #line 362 "src/math/cdf.birch"
    libbirch_line_(362);
    #line 362 "src/math/cdf.birch"
    return 0.0;
  } else {
    #line 364 "src/math/cdf.birch"
    libbirch_line_(364);
    #line 364 "src/math/cdf.birch"
    return 1.0 - birch::pow((1.0 + x / λ), -(α));
  }
}

#line 379 "src/math/cdf.birch"
birch::type::Real birch::cdf_normal_inverse_gamma_gaussian(const birch::type::Real& x, const birch::type::Real& μ, const birch::type::Real& a2, const birch::type::Real& α, const birch::type::Real& β) {
  #line 379 "src/math/cdf.birch"
  libbirch_function_("cdf_normal_inverse_gamma_gaussian", "src/math/cdf.birch", 379);
  #line 381 "src/math/cdf.birch"
  libbirch_line_(381);
  #line 381 "src/math/cdf.birch"
  return birch::cdf_student_t(x, 2.0 * α, μ, 2.0 * β * (1.0 + a2));
}

#line 398 "src/math/cdf.birch"
birch::type::Real birch::cdf_linear_normal_inverse_gamma_gaussian(const birch::type::Real& x, const birch::type::Real& a, const birch::type::Real& μ, const birch::type::Real& a2, const birch::type::Real& c, const birch::type::Real& α, const birch::type::Real& β) {
  #line 398 "src/math/cdf.birch"
  libbirch_function_("cdf_linear_normal_inverse_gamma_gaussian", "src/math/cdf.birch", 398);
  #line 400 "src/math/cdf.birch"
  libbirch_line_(400);
  #line 400 "src/math/cdf.birch"
  return birch::cdf_student_t(x, 2.0 * α, a * μ + c, 2.0 * β * (1.0 + a * a * a2));
}

#line 417 "src/math/cdf.birch"
birch::type::Real birch::cdf_linear_multivariate_normal_inverse_gamma_gaussian(const birch::type::Real& x, const libbirch::DefaultArray<birch::type::Real,1>& a, const libbirch::DefaultArray<birch::type::Real,1>& ν, const birch::type::LLT& Λ, const birch::type::Real& c, const birch::type::Real& α, const birch::type::Real& γ) {
  #line 417 "src/math/cdf.birch"
  libbirch_function_("cdf_linear_multivariate_normal_inverse_gamma_gaussian", "src/math/cdf.birch", 417);
  #line 419 "src/math/cdf.birch"
  libbirch_line_(419);
  #line 419 "src/math/cdf.birch"
  auto μ = birch::solve(Λ, ν);
  #line 420 "src/math/cdf.birch"
  libbirch_line_(420);
  #line 420 "src/math/cdf.birch"
  auto β = γ - 0.5 * birch::dot(μ, ν);
  #line 421 "src/math/cdf.birch"
  libbirch_line_(421);
  #line 421 "src/math/cdf.birch"
  return birch::cdf_student_t(x, 2.0 * α, birch::dot(a, μ) + c, 2.0 * β * (1.0 + birch::dot(a, birch::solve(Λ, a))));
}

#line 5 "src/math/constant.birch"
birch::type::Real64& birch::π() {
  #line 5 "src/math/constant.birch"
  static birch::type::Real64 result = 3.1415926535897932384626433832795;
  #line 5 "src/math/constant.birch"
  return result;
}

#line 10 "src/math/constant.birch"
birch::type::Real64& birch::inf() {
  #line 10 "src/math/constant.birch"
  static birch::type::Real64 result = 1.0 / 0.0;
  #line 10 "src/math/constant.birch"
  return result;
}

#line 15 "src/math/constant.birch"
birch::type::Real64& birch::nan() {
  #line 15 "src/math/constant.birch"
  static birch::type::Real64 result = 0.0 / 0.0;
  #line 15 "src/math/constant.birch"
  return result;
}

#line 19 "src/math/constant.birch"
birch::type::Real64& birch::MACHEP() {
  #line 19 "src/math/constant.birch"
  static birch::type::Real64 result = 1.11022302462515654042e-16;
  #line 19 "src/math/constant.birch"
  return result;
}

#line 23 "src/math/constant.birch"
libbirch::DefaultArray<birch::type::Real64,2>& birch::IGAM_ASYMPTOTIC_SERIES_D() {
  #line 23 "src/math/constant.birch"
  static libbirch::DefaultArray<birch::type::Real64,2> result = libbirch::make_array_from_sequence({ { -(3.3333333333333333e-1), 8.3333333333333333e-2, -(1.4814814814814815e-2), 1.1574074074074074e-3, 3.527336860670194e-4, -(1.7875514403292181e-4), 3.9192631785224378e-5, -(2.1854485106799922e-6), -(1.85406221071516e-6), 8.296711340953086e-7, -(1.7665952736826079e-7), 6.7078535434014986e-9, 1.0261809784240308e-8, -(4.3820360184533532e-9), 9.1476995822367902e-10, -(2.551419399494625e-11), -(5.8307721325504251e-11), 2.4361948020667416e-11, -(5.0276692801141756e-12), 1.1004392031956135e-13, 3.3717632624009854e-13, -(1.3923887224181621e-13), 2.8534893807047443e-14, -(5.1391118342425726e-16), -(1.9752288294349443e-15) }, { -(1.8518518518518519e-3), -(3.4722222222222222e-3), 2.6455026455026455e-3, -(9.9022633744855967e-4), 2.0576131687242798e-4, -(4.0187757201646091e-7), -(1.8098550334489978e-5), 7.6491609160811101e-6, -(1.6120900894563446e-6), 4.6471278028074343e-9, 1.378633446915721e-7, -(5.752545603517705e-8), 1.1951628599778147e-8, -(1.7543241719747648e-11), -(1.0091543710600413e-9), 4.1627929918425826e-10, -(8.5639070264929806e-11), 6.0672151016047586e-14, 7.1624989648114854e-12, -(2.9331866437714371e-12), 5.9966963656836887e-13, -(2.1671786527323314e-16), -(4.9783399723692616e-14), 2.0291628823713425e-14, -(4.13125571381061e-15) }, { 4.1335978835978836e-3, -(2.6813271604938272e-3), 7.7160493827160494e-4, 2.0093878600823045e-6, -(1.0736653226365161e-4), 5.2923448829120125e-5, -(1.2760635188618728e-5), 3.4235787340961381e-8, 1.3721957309062933e-6, -(6.298992138380055e-7), 1.4280614206064242e-7, -(2.0477098421990866e-10), -(1.4092529910867521e-8), 6.228974084922022e-9, -(1.3670488396617113e-9), 9.4283561590146782e-13, 1.2872252400089318e-10, -(5.5645956134363321e-11), 1.1975935546366981e-11, -(4.1689782251838635e-15), -(1.0940640427884594e-12), 4.6622399463901357e-13, -(9.905105763906906e-14), 1.8931876768373515e-17, 8.8592218725911273e-15 }, { 6.4943415637860082e-4, 2.2947209362139918e-4, -(4.6918949439525571e-4), 2.6772063206283885e-4, -(7.5618016718839764e-5), -(2.3965051138672967e-7), 1.1082654115347302e-5, -(5.6749528269915966e-6), 1.4230900732435884e-6, -(2.7861080291528142e-11), -(1.6958404091930277e-7), 8.0994649053880824e-8, -(1.9111168485973654e-8), 2.3928620439808118e-12, 2.0620131815488798e-9, -(9.4604966618551322e-10), 2.1541049775774908e-10, -(1.388823336813903e-14), -(2.1894761681963939e-11), 9.7909989511716851e-12, -(2.1782191880180962e-12), 6.2088195734079014e-17, 2.126978363279737e-13, -(9.3446887915174333e-14), 2.0453671226782849e-14 }, { -(8.618882909167117e-4), 7.8403922172006663e-4, -(2.9907248030319018e-4), -(1.4638452578843418e-6), 6.6414982154651222e-5, -(3.9683650471794347e-5), 1.1375726970678419e-5, 2.5074972262375328e-10, -(1.6954149536558306e-6), 8.9075075322053097e-7, -(2.2929348340008049e-7), 2.956794137544049e-11, 2.8865829742708784e-8, -(1.4189739437803219e-8), 3.4463580499464897e-9, -(2.3024517174528067e-13), -(3.9409233028046405e-10), 1.8602338968504502e-10, -(4.356323005056618e-11), 1.2786001016296231e-15, 4.6792750266579195e-12, -(2.1492464706134829e-12), 4.9088156148096522e-13, -(6.3385914848915603e-18), -(5.0453320690800944e-14) }, { -(3.3679855336635815e-4), -(6.9728137583658578e-5), 2.7727532449593921e-4, -(1.9932570516188848e-4), 6.7977804779372078e-5, 1.419062920643967e-7, -(1.3594048189768693e-5), 8.0184702563342015e-6, -(2.2914811765080952e-6), -(3.252473551298454e-10), 3.4652846491085265e-7, -(1.8447187191171343e-7), 4.8240967037894181e-8, -(1.7989466721743515e-14), -(6.3061945000135234e-9), 3.1624176287745679e-9, -(7.8409242536974293e-10), 5.1926791652540407e-15, 9.3589442423067836e-11, -(4.5134262161632782e-11), 1.0799129993116827e-11, -(3.661886712685252e-17), -(1.210902069055155e-12), 5.6807435849905643e-13, -(1.3249659916340829e-13) }, { 5.3130793646399222e-4, -(5.9216643735369388e-4), 2.7087820967180448e-4, 7.9023532326603279e-7, -(8.1539693675619688e-5), 5.6116827531062497e-5, -(1.8329116582843376e-5), -(3.0796134506033048e-9), 3.4651553688036091e-6, -(2.0291327396058604e-6), 5.7887928631490037e-7, 2.338630673826657e-13, -(8.8286007463304835e-8), 4.7435958880408128e-8, -(1.2545415020710382e-8), 8.6496488580102925e-14, 1.6846058979264063e-9, -(8.5754928235775947e-10), 2.1598224929232125e-10, -(7.6132305204761539e-16), -(2.6639822008536144e-11), 1.3065700536611057e-11, -(3.1799163902367977e-12), 4.7109761213674315e-18, 3.6902800842763467e-13 }, { 3.4436760689237767e-4, 5.1717909082605922e-5, -(3.3493161081142236e-4), 2.812695154763237e-4, -(1.0976582244684731e-4), -(1.2741009095484485e-7), 2.7744451511563644e-5, -(1.8263488805711333e-5), 5.7876949497350524e-6, 4.9387589339362704e-10, -(1.0595367014026043e-6), 6.1667143761104075e-7, -(1.7562973359060462e-7), -(1.2974473287015439e-12), 2.695423606288966e-8, -(1.4578352908731271e-8), 3.887645959386175e-9, -(3.8810022510194121e-17), -(5.3279941738772867e-10), 2.7437977643314845e-10, -(6.9957960920705679e-11), 2.5899863874868481e-17, 8.8566890996696381e-12, -(4.403168815871311e-12), 1.0865561947091654e-12 }, { -(6.5262391859530942e-4), 8.3949872067208728e-4, -(4.3829709854172101e-4), -(6.969091458420552e-7), 1.6644846642067548e-4, -(1.2783517679769219e-4), 4.6299532636913043e-5, 4.5579098679227077e-9, -(1.0595271125805195e-5), 6.7833429048651666e-6, -(2.1075476666258804e-6), -(1.7213731432817145e-11), 3.7735877416110979e-7, -(2.1867506700122867e-7), 6.2202288040189269e-8, 6.5977038267330006e-16, -(9.5903864974256858e-9), 5.2132144922808078e-9, -(1.3991589583935709e-9), 5.382058999060575e-16, 1.9484714275467745e-10, -(1.0127287556389682e-10), 2.6077347197254926e-11, -(5.0904186999932993e-18), -(3.3721464474854592e-12) }, { -(5.9676129019274625e-4), -(7.2048954160200106e-5), 6.7823088376673284e-4, -(6.4014752602627585e-4), 2.7750107634328704e-4, 1.8197008380465151e-7, -(8.4795071170685032e-5), 6.105192082501531e-5, -(2.1073920183404862e-5), -(8.8585890141255994e-10), 4.5284535953805377e-6, -(2.8427815022504408e-6), 8.7082341778646412e-7, 3.6886101871706965e-12, -(1.5344695190702061e-7), 8.862466778790695e-8, -(2.5184812301826817e-8), -(1.0225912098215092e-14), 3.8969470758154777e-9, -(2.1267304792235635e-9), 5.7370135528051385e-10, -(1.887749850169741e-19), -(8.0931538694657866e-11), 4.2382723283449199e-11, -(1.1002224534207726e-11) }, { 1.3324454494800656e-3, -(1.9144384985654775e-3), 1.1089369134596637e-3, 9.932404122642299e-7, -(5.0874501293093199e-4), 4.2735056665392884e-4, -(1.6858853767910799e-4), -(8.1301893922784998e-9), 4.5284402370562147e-5, -(3.127053674781734e-5), 1.044986828530338e-5, 4.8435226265680926e-11, -(2.1482565873456258e-6), 1.329369701097492e-6, -(4.0295693092101029e-7), -(1.7567877666323291e-13), 7.0145043163668257e-8, -(4.040787734999483e-8), 1.1474026743371963e-8, 3.9642746853563325e-18, -(1.7804938269892714e-9), 9.7480262548731646e-10, -(2.6405338676507616e-10), 5.794875163403742e-18, 3.7647749553543836e-11 }, { 1.579727660730835e-3, 1.6251626278391582e-4, -(2.0633421035543276e-3), 2.1389686185689098e-3, -(1.0108559391263003e-3), -(3.9912705529919201e-7), 3.6235025084764691e-4, -(2.8143901463712154e-4), 1.0449513336495887e-4, 2.1211418491830297e-9, -(2.5779417251947842e-5), 1.7281818956040463e-5, -(5.6413773872904282e-6), -(1.1024320105776174e-11), 1.1223224418895175e-6, -(6.8693396379526735e-7), 2.0653236975414887e-7, 4.6714772409838506e-14, -(3.5609886164949055e-8), 2.0470855345905963e-8, -(5.8091738633283358e-9), -(1.332821287582869e-16), 9.0354604391335133e-10, -(4.9598782517330834e-10), 1.3481607129399749e-10 }, { -(4.0725121195140166e-3), 6.4033628338080698e-3, -(4.0410161081676618e-3), -(2.183732802866233e-6), 2.1740441801254639e-3, -(1.9700440518418892e-3), 8.3595469747962458e-4, 1.9445447567109655e-8, -(2.5779387120421696e-4), 1.9009987368139304e-4, -(6.7696499937438965e-5), -(1.4440629666426572e-10), 1.5712512518742269e-5, -(1.0304008744776893e-5), 3.304517767401387e-6, 7.9829760242325709e-13, -(6.4097794149313004e-7), 3.8894624761300056e-7, -(1.1618347644948869e-7), -(2.816808630596451e-15), 1.9878012911297093e-8, -(1.1407719956357511e-8), 3.2355857064185555e-9, 4.1759468293455945e-20, -(5.0423112718105824e-10) }, { -(5.9475779383993003e-3), -(5.4016476789260452e-4), 8.7910413550767898e-3, -(9.8576315587856125e-3), 5.0134695031021538e-3, 1.2807521786221875e-6, -(2.0626019342754683e-3), 1.7109128573523058e-3, -(6.7695312714133799e-4), -(6.9011545676562133e-9), 1.8855128143995902e-4, -(1.3395215663491969e-4), 4.6263183033528039e-5, 4.0034230613321351e-11, -(1.0255652921494033e-5), 6.612086372797651e-6, -(2.0913022027253008e-6), -(2.0951775649603837e-13), 3.9756029041993247e-7, -(2.3956211978815887e-7), 7.1182883382145864e-8, 8.925574873053455e-16, -(1.2101547235064676e-8), 6.9350618248334386e-9, -(1.9661464453856102e-9) }, { 1.7402027787522711e-2, -(2.9527880945699121e-2), 2.0045875571402799e-2, 7.0289515966903407e-6, -(1.2375421071343148e-2), 1.1976293444235254e-2, -(5.4156038466518525e-3), -(6.3290893396418616e-8), 1.8855118129005065e-3, -(1.473473274825001e-3), 5.5515810097708387e-4, 5.2406834412550662e-10, -(1.4357913535784836e-4), 9.9181293224943297e-5, -(3.3460834749478311e-5), -(3.5755837291098993e-12), 7.1560851960630076e-6, -(4.5516802628155526e-6), 1.4236576649271475e-6, 1.8803149082089664e-14, -(2.6623403898929211e-7), 1.5950642189595716e-7, -(4.7187514673841102e-8), -(6.5107872958755177e-17), 7.9795091026746235e-9 }, { 3.0249124160905891e-2, 2.4817436002649977e-3, -(4.9939134373457022e-2), 5.9915643009307869e-2, -(3.2483207601623391e-2), -(5.7212968652103441e-6), 1.5085251778569354e-2, -(1.3261324005088445e-2), 5.5515262632426148e-3, 3.0263182257030016e-8, -(1.7229548406756723e-3), 1.2893570099929637e-3, -(4.6845138348319876e-4), -(1.830259937893045e-10), 1.1449739014822654e-4, -(7.7378565221244477e-5), 2.5625836246985201e-5, 1.0766165333192814e-12, -(5.3246809282422621e-6), 3.349634863064464e-6, -(1.0381253128684018e-6), -(5.608909920621128e-15), 1.9150821930676591e-7, -(1.1418365800203486e-7), 3.3654425209171788e-8 }, { -(9.9051020880159045e-2), 1.7954011706123486e-1, -(1.2989606383463778e-1), -(3.1478872752284357e-5), 9.0510635276848131e-2, -(9.2828824411184397e-2), 4.4412112839877808e-2, 2.7779236316835888e-7, -(1.7229543805449697e-2), 1.4182925050891573e-2, -(5.6214161633747336e-3), -(2.39598509186381e-9), 1.6029634366079908e-3, -(1.1606784674435773e-3), 4.1001337768153873e-4, 1.8365800754090661e-11, -(9.5844256563655903e-5), 6.3643062337764708e-5, -(2.076250624489065e-5), -(1.1806020912804483e-13), 4.2131808239120649e-6, -(2.6262241337012467e-6), 8.0770620494930662e-7, 6.0125912123632725e-16, -(1.4729737374018841e-7) }, { -(1.9994542198219728e-1), -(1.5056113040026424e-2), 3.6470239469348489e-1, -(4.6435192311733545e-1), 2.6640934719197893e-1, 3.4038266027147191e-5, -(1.3784338709329624e-1), 1.276467178337056e-1, -(5.6213828755200985e-2), -(1.753150885483011e-7), 1.9235592956768113e-2, -(1.5088821281095315e-2), 5.7401854451350123e-3, 1.0622382710310225e-9, -(1.5335082692563998e-3), 1.0819320643228214e-3, -(3.7372510193945659e-4), -(6.6170909729031985e-12), 8.4263617380909628e-5, -(5.5150706827483479e-5), 1.7769536448348069e-5, 3.8827923210205533e-14, -(3.53513697488768e-6), 2.1865832130045269e-6, -(6.6812849447625594e-7) }, { 7.2438608504029431e-1, -(1.3918010932653375), 1.0654143352413968, 1.876173868950258e-4, -(8.2705501176152696e-1), 8.9352433347828414e-1, -(4.4971003995291339e-1), -(1.6107401567546652e-6), 1.9235590165271091e-1, -(1.6597702160042609e-1), 6.8882222681814333e-2, 1.3910091724608687e-8, -(2.146911561508663e-2), 1.6228980898865892e-2, -(5.9796016172584256e-3), -(1.1287469112826745e-10), 1.5167451119784857e-3, -(1.0478634293553899e-3), 3.5539072889126421e-4, 8.1704322111801517e-13, -(7.7773013442452395e-5), 5.0291413897007722e-5, -(1.6035083867000518e-5), 1.2469354315487605e-14, 3.1369106244517615e-6 }, { 1.6668949727276811, 1.165462765994632e-1, -(3.3288393225018906), 4.4692325482864037, -(2.6977693045875807), -(2.600667859891061e-4), 1.5389017615694539, -(1.4937962361134612), 6.8881964633233148e-1, 1.3077482004552385e-6, -(2.5762963325596288e-1), 2.1097676102125449e-1, -(8.3714408359219882e-2), -(7.7920428881354753e-9), 2.4267923064833599e-2, -(1.7813678334552311e-2), 6.3970330388900056e-3, 4.9430807090480523e-11, -(1.5554602758465635e-3), 1.0561196919903214e-3, -(3.5277184460472902e-4), 9.3002334645022459e-14, 7.5285855026557172e-5, -(4.8186515569156351e-5), 1.5227271505597605e-5 }, { -(6.6188298861372935), 1.3397985455142589e+1, -(1.0789350606845146e+1), -(1.4352254537875018e-3), 9.2333694596189809, -(1.0456552819547769e+1), 5.5105526029033471, 1.2024439690716742e-5, -(2.5762961164755816), 2.3207442745387179, -(1.0045728797216284), -(1.0207833290021914e-7), 3.3975092171169466e-1, -(2.6720517450757468e-1), 1.0235252851562706e-1, 8.4329730484871625e-10, -(2.7998284958442595e-2), 2.0066274144976813e-2, -(7.0554368915086242e-3), 1.9402238183698188e-12, 1.6562888105449611e-3, -(1.1082898580743683e-3), 3.654545161310169e-4, -(5.1290032026971794e-11), -(7.6340103696869031e-5) }, { -(1.7112706061976095e+1), -(1.1208044642899116), 3.7131966511885444e+1, -(5.2298271025348962e+1), 3.3058589696624618e+1, 2.4791298976200222e-3, -(2.061089403411526e+1), 2.088672775145582e+1, -(1.0045703956517752e+1), -(1.2238783449063012e-5), 4.0770134274221141, -(3.473667358470195), 1.4329352617312006, 7.1359914411879712e-8, -(4.4797257159115612e-1), 3.4112666080644461e-1, -(1.2699786326594923e-1), -(2.8953677269081528e-10), 3.3125776278259863e-2, -(2.3274087021036101e-2), 8.0399993503648882e-3, -(1.177805216235265e-9), -(1.8321624891071668e-3), 1.2108282933588665e-3, -(3.9479941246822517e-4) }, { 7.389033153567425e+1, -(1.5680141270402273e+2), 1.322177542759164e+2, 1.3692876877324546e-2, -(1.2366496885920151e+2), 1.4620689391062729e+2, -(8.0365587724865346e+1), -(1.1259851148881298e-4), 4.0770132196179938e+1, -(3.8210340013273034e+1), 1.719522294277362e+1, 9.3519707955168356e-7, -(6.2716159907747034), 5.1168999071852637, -(2.0319658112299095), -(4.9507215582761543e-9), 5.9626397294332597e-1, -(4.4220765337238094e-1), 1.6079998700166273e-1, -(2.4733786203223402e-8), -(4.0307574759979762e-2), 2.7849050747097869e-2, -(9.4751858992054221e-3), 6.419922235909132e-6, 2.1250180774699461e-3 }, { 2.1216837098382522e+2, 1.3107863022633868e+1, -(4.9698285932871748e+2), 7.3121595266969204e+2, -(4.8213821720890847e+2), -(2.8817248692894889e-2), 3.2616720302947102e+2, -(3.4389340280087117e+2), 1.7195193870816232e+2, 1.4038077378096158e-4, -(7.52594195897599e+1), 6.651969984520934e+1, -(2.8447519748152462e+1), -(7.613702615875391e-7), 9.5402237105304373, -(7.5175301113311376), 2.8943997568871961, -(4.6612194999538201e-7), -(8.0615149598794088e-1), 5.8483006570631029e-1, -(2.0845408972964956e-1), 1.4765818959305817e-4, 5.1000433863753019e-2, -(3.3066252141883665e-2), 1.5109265210467774e-2 }, { -(9.8959643098322368e+2), 2.1925555360905233e+3, -(1.9283586782723356e+3), -(1.5925738122215253e-1), 1.9569985945919857e+3, -(2.4072514765081556e+3), 1.3756149959336496e+3, 1.2920735237496668e-3, -(7.525941715948055e+2), 7.3171668742208716e+2, -(3.4137023466220065e+2), -(9.9857390260608043e-6), 1.3356313181291573e+2, -(1.1276295161252794e+2), 4.6310396098204458e+1, -(7.9237387133614756e-6), -(1.4510726927018646e+1), 1.1111771248100563e+1, -(4.1690817945270892), 3.1008219800117808e-3, 1.1220095449981468, -(7.6052379926149916e-1), 3.6262236505085254e-1, 2.216867741940747e-1, 4.8683443692930507e-1 } });
  #line 23 "src/math/constant.birch"
  return result;
}

#line 49 "src/math/constant.birch"
libbirch::DefaultArray<birch::type::Real64,1>& birch::lanczos_sum_expg_scaled_num() {
  #line 49 "src/math/constant.birch"
  static libbirch::DefaultArray<birch::type::Real64,1> result = libbirch::make_array_from_sequence({ 0.006061842346248906525783753964555936883222, 0.5098416655656676188125178644804694509993, 19.51992788247617482847860966235652136208, 449.9445569063168119446858607650988409623, 6955.999602515376140356310115515198987526, 75999.29304014542649875303443598909137092, 601859.6171681098786670226533699352302507, 3481712.15498064590882071018964774556468, 14605578.08768506808414169982791359218571, 43338889.32467613834773723740590533316085, 86363131.28813859145546927288977868422342, 103794043.1163445451906271053616070238554, 56906521.91347156388090791033559122686859 });
  #line 49 "src/math/constant.birch"
  return result;
}

#line 65 "src/math/constant.birch"
libbirch::DefaultArray<birch::type::Real64,1>& birch::lanczos_sum_expg_scaled_denom() {
  #line 65 "src/math/constant.birch"
  static libbirch::DefaultArray<birch::type::Real64,1> result = libbirch::make_array_from_sequence({ birch::type::Integer(1), birch::type::Integer(66), birch::type::Integer(1925), birch::type::Integer(32670), birch::type::Integer(357423), birch::type::Integer(2637558), birch::type::Integer(13339535), birch::type::Integer(45995730), birch::type::Integer(105258076), birch::type::Integer(150917976), birch::type::Integer(120543840), birch::type::Integer(39916800), birch::type::Integer(0) });
  #line 65 "src/math/constant.birch"
  return result;
}

#line 10 "src/math/distance.birch"
birch::type::Real birch::wasserstein(const libbirch::DefaultArray<birch::type::Real,1>& x1, const libbirch::DefaultArray<birch::type::Real,1>& x2) {
  #line 10 "src/math/distance.birch"
  libbirch_function_("wasserstein", "src/math/distance.birch", 10);
  #line 11 "src/math/distance.birch"
  libbirch_line_(11);
  #line 11 "src/math/distance.birch"
  libbirch_assert_(birch::length(x1) == birch::length(x2));
  #line 12 "src/math/distance.birch"
  libbirch_line_(12);
  #line 12 "src/math/distance.birch"
  auto N = birch::length(x1);
  #line 13 "src/math/distance.birch"
  libbirch_line_(13);
  #line 13 "src/math/distance.birch"
  auto y1 = birch::sort<birch::type::Real>(x1);
  #line 14 "src/math/distance.birch"
  libbirch_line_(14);
  #line 14 "src/math/distance.birch"
  auto y2 = birch::sort<birch::type::Real>(x2);
  #line 15 "src/math/distance.birch"
  libbirch_line_(15);
  #line 15 "src/math/distance.birch"
  return birch::reduce<birch::type::Real>(y1 - y2, 0.0, std::function<birch::type::Real(birch::type::Real,birch::type::Real)>([=](const birch::type::Real& a, const birch::type::Real& b) {
    #line 16 "src/math/distance.birch"
    libbirch_line_(16);
    #line 16 "src/math/distance.birch"
    return birch::abs(a) + birch::abs(b);
  })) / N;
}

#line 10 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::operator*(const birch::type::Real& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 10 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 10);
  #line 11 "src/math/eigen.birch"

  return x*y.toEigen();
  }

#line 16 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::operator*(const libbirch::DefaultArray<birch::type::Real,1>& x, const birch::type::Real& y) {
  #line 16 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 16);
  #line 17 "src/math/eigen.birch"

  return x.toEigen()*y;
  }

#line 22 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator*(const birch::type::Real& x, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 22 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 22);
  #line 23 "src/math/eigen.birch"

  return x*Y.toEigen();
  }

#line 28 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator*(const libbirch::DefaultArray<birch::type::Real,2>& X, const birch::type::Real& y) {
  #line 28 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 28);
  #line 29 "src/math/eigen.birch"

  return X.toEigen()*y;
  }

#line 34 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::operator/(const libbirch::DefaultArray<birch::type::Real,1>& x, const birch::type::Real& y) {
  #line 34 "src/math/eigen.birch"
  libbirch_function_("/", "src/math/eigen.birch", 34);
  #line 35 "src/math/eigen.birch"

  return x.toEigen()/y;
  }

#line 40 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator/(const libbirch::DefaultArray<birch::type::Real,2>& X, const birch::type::Real& y) {
  #line 40 "src/math/eigen.birch"
  libbirch_function_("/", "src/math/eigen.birch", 40);
  #line 41 "src/math/eigen.birch"

  return X.toEigen()/y;
  }

#line 46 "src/math/eigen.birch"
birch::type::Boolean birch::operator==(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 46 "src/math/eigen.birch"
  libbirch_function_("==", "src/math/eigen.birch", 46);
  #line 47 "src/math/eigen.birch"

  return x.toEigen() == y.toEigen();
  }

#line 52 "src/math/eigen.birch"
birch::type::Boolean birch::operator!=(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 52 "src/math/eigen.birch"
  libbirch_function_("!=", "src/math/eigen.birch", 52);
  #line 53 "src/math/eigen.birch"

  return x.toEigen() != y.toEigen();
  }

#line 58 "src/math/eigen.birch"
birch::type::Boolean birch::operator==(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 58 "src/math/eigen.birch"
  libbirch_function_("==", "src/math/eigen.birch", 58);
  #line 59 "src/math/eigen.birch"

  return X.toEigen() == Y.toEigen();
  }

#line 64 "src/math/eigen.birch"
birch::type::Boolean birch::operator!=(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 64 "src/math/eigen.birch"
  libbirch_function_("!=", "src/math/eigen.birch", 64);
  #line 65 "src/math/eigen.birch"

  return X.toEigen() != Y.toEigen();
  }

#line 70 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::operator-(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 70 "src/math/eigen.birch"
  libbirch_function_("-", "src/math/eigen.birch", 70);
  #line 71 "src/math/eigen.birch"

  return -x.toEigen();
  }

#line 76 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::operator+(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 76 "src/math/eigen.birch"
  libbirch_function_("+", "src/math/eigen.birch", 76);
  #line 77 "src/math/eigen.birch"
  libbirch_line_(77);
  #line 77 "src/math/eigen.birch"
  return x;
}

#line 80 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator-(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 80 "src/math/eigen.birch"
  libbirch_function_("-", "src/math/eigen.birch", 80);
  #line 81 "src/math/eigen.birch"

  return -X.toEigen();
  }

#line 86 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator+(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 86 "src/math/eigen.birch"
  libbirch_function_("+", "src/math/eigen.birch", 86);
  #line 87 "src/math/eigen.birch"
  libbirch_line_(87);
  #line 87 "src/math/eigen.birch"
  return X;
}

#line 90 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::operator+(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 90 "src/math/eigen.birch"
  libbirch_function_("+", "src/math/eigen.birch", 90);
  #line 91 "src/math/eigen.birch"

  return x.toEigen() + y.toEigen();
  }

#line 96 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::operator-(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 96 "src/math/eigen.birch"
  libbirch_function_("-", "src/math/eigen.birch", 96);
  #line 97 "src/math/eigen.birch"

  return x.toEigen() - y.toEigen();
  }

#line 102 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator+(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 102 "src/math/eigen.birch"
  libbirch_function_("+", "src/math/eigen.birch", 102);
  #line 103 "src/math/eigen.birch"

  return X.toEigen() + Y.toEigen();
  }

#line 108 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator-(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 108 "src/math/eigen.birch"
  libbirch_function_("-", "src/math/eigen.birch", 108);
  #line 109 "src/math/eigen.birch"

  return X.toEigen() - Y.toEigen();
  }

#line 114 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::operator*(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 114 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 114);
  #line 115 "src/math/eigen.birch"

  return X.toEigen()*y.toEigen();
  }

#line 120 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator*(const libbirch::DefaultArray<birch::type::Real,1>& X, const libbirch::DefaultArray<birch::type::Real,2>& y) {
  #line 120 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 120);
  #line 121 "src/math/eigen.birch"

  return X.toEigen()*y.toEigen();
  }

#line 126 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator*(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 126 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 126);
  #line 127 "src/math/eigen.birch"

  return X.toEigen()*Y.toEigen();
  }

#line 132 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::operator*(const birch::type::Integer& x, const libbirch::DefaultArray<birch::type::Integer,1>& y) {
  #line 132 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 132);
  #line 133 "src/math/eigen.birch"

  return x*y.toEigen();
  }

#line 138 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::operator*(const libbirch::DefaultArray<birch::type::Integer,1>& x, const birch::type::Integer& y) {
  #line 138 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 138);
  #line 139 "src/math/eigen.birch"

  return x.toEigen()*y;
  }

#line 144 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator*(const birch::type::Integer& x, const libbirch::DefaultArray<birch::type::Integer,2>& Y) {
  #line 144 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 144);
  #line 145 "src/math/eigen.birch"

  return x*Y.toEigen();
  }

#line 150 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator*(const libbirch::DefaultArray<birch::type::Integer,2>& X, const birch::type::Integer& y) {
  #line 150 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 150);
  #line 151 "src/math/eigen.birch"

  return X.toEigen()*y;
  }

#line 156 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::operator/(const libbirch::DefaultArray<birch::type::Integer,1>& x, const birch::type::Integer& y) {
  #line 156 "src/math/eigen.birch"
  libbirch_function_("/", "src/math/eigen.birch", 156);
  #line 157 "src/math/eigen.birch"

  return x.toEigen()/y;
  }

#line 162 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator/(const libbirch::DefaultArray<birch::type::Integer,2>& X, const birch::type::Integer& y) {
  #line 162 "src/math/eigen.birch"
  libbirch_function_("/", "src/math/eigen.birch", 162);
  #line 163 "src/math/eigen.birch"

  return X.toEigen()/y;
  }

#line 168 "src/math/eigen.birch"
birch::type::Boolean birch::operator==(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::DefaultArray<birch::type::Integer,1>& y) {
  #line 168 "src/math/eigen.birch"
  libbirch_function_("==", "src/math/eigen.birch", 168);
  #line 169 "src/math/eigen.birch"

  return x.toEigen() == y.toEigen();
  }

#line 174 "src/math/eigen.birch"
birch::type::Boolean birch::operator!=(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::DefaultArray<birch::type::Integer,1>& y) {
  #line 174 "src/math/eigen.birch"
  libbirch_function_("!=", "src/math/eigen.birch", 174);
  #line 175 "src/math/eigen.birch"

  return x.toEigen() != y.toEigen();
  }

#line 180 "src/math/eigen.birch"
birch::type::Boolean birch::operator==(const libbirch::DefaultArray<birch::type::Integer,2>& X, const libbirch::DefaultArray<birch::type::Integer,2>& Y) {
  #line 180 "src/math/eigen.birch"
  libbirch_function_("==", "src/math/eigen.birch", 180);
  #line 181 "src/math/eigen.birch"

  return X.toEigen() == Y.toEigen();
  }

#line 186 "src/math/eigen.birch"
birch::type::Boolean birch::operator!=(const libbirch::DefaultArray<birch::type::Integer,2>& X, const libbirch::DefaultArray<birch::type::Integer,2>& Y) {
  #line 186 "src/math/eigen.birch"
  libbirch_function_("!=", "src/math/eigen.birch", 186);
  #line 187 "src/math/eigen.birch"

  return X.toEigen() != Y.toEigen();
  }

#line 192 "src/math/eigen.birch"
birch::type::Boolean birch::operator==(const birch::type::LLT& X, const birch::type::LLT& Y) {
  #line 192 "src/math/eigen.birch"
  libbirch_function_("==", "src/math/eigen.birch", 192);
  #line 193 "src/math/eigen.birch"

  return X.reconstructedMatrix() == Y.reconstructedMatrix();
  }

#line 198 "src/math/eigen.birch"
birch::type::Boolean birch::operator!=(const birch::type::LLT& X, const birch::type::LLT& Y) {
  #line 198 "src/math/eigen.birch"
  libbirch_function_("!=", "src/math/eigen.birch", 198);
  #line 199 "src/math/eigen.birch"

  return X.reconstructedMatrix() != Y.reconstructedMatrix();
  }

#line 204 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::operator-(const libbirch::DefaultArray<birch::type::Integer,1>& x) {
  #line 204 "src/math/eigen.birch"
  libbirch_function_("-", "src/math/eigen.birch", 204);
  #line 205 "src/math/eigen.birch"

  return -x.toEigen();
  }

#line 210 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::operator+(const libbirch::DefaultArray<birch::type::Integer,1>& x) {
  #line 210 "src/math/eigen.birch"
  libbirch_function_("+", "src/math/eigen.birch", 210);
  #line 211 "src/math/eigen.birch"
  libbirch_line_(211);
  #line 211 "src/math/eigen.birch"
  return x;
}

#line 214 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator-(const libbirch::DefaultArray<birch::type::Integer,2>& X) {
  #line 214 "src/math/eigen.birch"
  libbirch_function_("-", "src/math/eigen.birch", 214);
  #line 215 "src/math/eigen.birch"

  return -X.toEigen();
  }

#line 220 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator+(const libbirch::DefaultArray<birch::type::Integer,2>& X) {
  #line 220 "src/math/eigen.birch"
  libbirch_function_("+", "src/math/eigen.birch", 220);
  #line 221 "src/math/eigen.birch"
  libbirch_line_(221);
  #line 221 "src/math/eigen.birch"
  return X;
}

#line 224 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::operator+(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::DefaultArray<birch::type::Integer,1>& y) {
  #line 224 "src/math/eigen.birch"
  libbirch_function_("+", "src/math/eigen.birch", 224);
  #line 225 "src/math/eigen.birch"

  return x.toEigen() + y.toEigen();
  }

#line 230 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::operator-(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::DefaultArray<birch::type::Integer,1>& y) {
  #line 230 "src/math/eigen.birch"
  libbirch_function_("-", "src/math/eigen.birch", 230);
  #line 231 "src/math/eigen.birch"

  return x.toEigen() - y.toEigen();
  }

#line 236 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator+(const libbirch::DefaultArray<birch::type::Integer,2>& X, const libbirch::DefaultArray<birch::type::Integer,2>& Y) {
  #line 236 "src/math/eigen.birch"
  libbirch_function_("+", "src/math/eigen.birch", 236);
  #line 237 "src/math/eigen.birch"

  return X.toEigen() + Y.toEigen();
  }

#line 242 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator-(const libbirch::DefaultArray<birch::type::Integer,2>& X, const libbirch::DefaultArray<birch::type::Integer,2>& Y) {
  #line 242 "src/math/eigen.birch"
  libbirch_function_("-", "src/math/eigen.birch", 242);
  #line 243 "src/math/eigen.birch"

  return X.toEigen() - Y.toEigen();
  }

#line 248 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::operator*(const libbirch::DefaultArray<birch::type::Integer,2>& X, const libbirch::DefaultArray<birch::type::Integer,1>& y) {
  #line 248 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 248);
  #line 249 "src/math/eigen.birch"

  return X.toEigen()*y.toEigen();
  }

#line 254 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator*(const libbirch::DefaultArray<birch::type::Integer,1>& X, const libbirch::DefaultArray<birch::type::Integer,2>& y) {
  #line 254 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 254);
  #line 255 "src/math/eigen.birch"

  return X.toEigen()*y.toEigen();
  }

#line 260 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator*(const libbirch::DefaultArray<birch::type::Integer,2>& X, const libbirch::DefaultArray<birch::type::Integer,2>& Y) {
  #line 260 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 260);
  #line 261 "src/math/eigen.birch"

  return X.toEigen()*Y.toEigen();
  }

#line 269 "src/math/eigen.birch"
birch::type::Real birch::dot(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 269 "src/math/eigen.birch"
  libbirch_function_("dot", "src/math/eigen.birch", 269);
  #line 270 "src/math/eigen.birch"

  return x.toEigen().squaredNorm();
  }

#line 278 "src/math/eigen.birch"
birch::type::Real birch::dot(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 278 "src/math/eigen.birch"
  libbirch_function_("dot", "src/math/eigen.birch", 278);
  #line 279 "src/math/eigen.birch"

  return x.toEigen().dot(y.toEigen());
  }

#line 288 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::dot(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 288 "src/math/eigen.birch"
  libbirch_function_("dot", "src/math/eigen.birch", 288);
  #line 289 "src/math/eigen.birch"

  return Y.toEigen().transpose()*x.toEigen();
  }

#line 297 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::outer(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 297 "src/math/eigen.birch"
  libbirch_function_("outer", "src/math/eigen.birch", 297);
  #line 298 "src/math/eigen.birch"

  auto y = x.toEigen();
  return y*y.transpose();
  }

#line 307 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::outer(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 307 "src/math/eigen.birch"
  libbirch_function_("outer", "src/math/eigen.birch", 307);
  #line 308 "src/math/eigen.birch"

  return x.toEigen()*y.toEigen().transpose();
  }

#line 316 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::outer(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 316 "src/math/eigen.birch"
  libbirch_function_("outer", "src/math/eigen.birch", 316);
  #line 317 "src/math/eigen.birch"

  auto Y = X.toEigen();
  return Y*Y.transpose();
  }

#line 326 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::outer(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 326 "src/math/eigen.birch"
  libbirch_function_("outer", "src/math/eigen.birch", 326);
  #line 327 "src/math/eigen.birch"

  return X.toEigen()*Y.toEigen().transpose();
  }

#line 335 "src/math/eigen.birch"
birch::type::Real birch::norm(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 335 "src/math/eigen.birch"
  libbirch_function_("norm", "src/math/eigen.birch", 335);
  #line 336 "src/math/eigen.birch"

  return x.toEigen().norm();
  }

#line 344 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::sqrt(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 344 "src/math/eigen.birch"
  libbirch_function_("sqrt", "src/math/eigen.birch", 344);
  #line 345 "src/math/eigen.birch"

  return x.toEigen().array().sqrt().matrix();
  }

#line 353 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::transpose(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 353 "src/math/eigen.birch"
  libbirch_function_("transpose", "src/math/eigen.birch", 353);
  #line 354 "src/math/eigen.birch"

  return X.toEigen().transpose();
  }

#line 362 "src/math/eigen.birch"
birch::type::LLT birch::transpose(const birch::type::LLT& S) {
  #line 362 "src/math/eigen.birch"
  libbirch_function_("transpose", "src/math/eigen.birch", 362);
  #line 363 "src/math/eigen.birch"
  libbirch_line_(363);
  #line 363 "src/math/eigen.birch"
  return S;
}

#line 369 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::transpose(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 369 "src/math/eigen.birch"
  libbirch_function_("transpose", "src/math/eigen.birch", 369);
  #line 370 "src/math/eigen.birch"

  return x.toEigen().transpose();
  }

#line 378 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::diagonal(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 378 "src/math/eigen.birch"
  libbirch_function_("diagonal", "src/math/eigen.birch", 378);
  #line 379 "src/math/eigen.birch"

  return x.toEigen().asDiagonal();
  }

#line 387 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::diagonal(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 387 "src/math/eigen.birch"
  libbirch_function_("diagonal", "src/math/eigen.birch", 387);
  #line 388 "src/math/eigen.birch"

  return X.toEigen().diagonal();
  }

#line 396 "src/math/eigen.birch"
birch::type::Real birch::trace(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 396 "src/math/eigen.birch"
  libbirch_function_("trace", "src/math/eigen.birch", 396);
  #line 397 "src/math/eigen.birch"

  return X.toEigen().trace();
  }

#line 405 "src/math/eigen.birch"
birch::type::Real birch::trace(const birch::type::LLT& S) {
  #line 405 "src/math/eigen.birch"
  libbirch_function_("trace", "src/math/eigen.birch", 405);
  #line 406 "src/math/eigen.birch"

  return S.reconstructedMatrix().trace();
  }

#line 414 "src/math/eigen.birch"
birch::type::Real birch::det(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 414 "src/math/eigen.birch"
  libbirch_function_("det", "src/math/eigen.birch", 414);
  #line 415 "src/math/eigen.birch"

  return X.toEigen().determinant();
  }

#line 423 "src/math/eigen.birch"
birch::type::Real birch::ldet(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 423 "src/math/eigen.birch"
  libbirch_function_("ldet", "src/math/eigen.birch", 423);
  #line 424 "src/math/eigen.birch"

  return X.toEigen().householderQr().logAbsDeterminant();
  }

#line 432 "src/math/eigen.birch"
birch::type::Real birch::det(const birch::type::LLT& S) {
  #line 432 "src/math/eigen.birch"
  libbirch_function_("det", "src/math/eigen.birch", 432);
  #line 433 "src/math/eigen.birch"

  auto d = S.matrixL().determinant();
  return d*d;
  }

#line 442 "src/math/eigen.birch"
birch::type::Real birch::ldet(const birch::type::LLT& S) {
  #line 442 "src/math/eigen.birch"
  libbirch_function_("ldet", "src/math/eigen.birch", 442);
  #line 443 "src/math/eigen.birch"

  return 2.0*S.matrixL().nestedExpression().diagonal().array().log().sum();
  }

#line 451 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::inv(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 451 "src/math/eigen.birch"
  libbirch_function_("inv", "src/math/eigen.birch", 451);
  #line 452 "src/math/eigen.birch"

  return X.toEigen().inverse();
  }

#line 460 "src/math/eigen.birch"
birch::type::LLT birch::inv(const birch::type::LLT& S) {
  #line 460 "src/math/eigen.birch"
  libbirch_function_("inv", "src/math/eigen.birch", 460);
  #line 461 "src/math/eigen.birch"

  return S.solve(libbirch::EigenMatrix<birch::type::Real>::Identity(
      S.rows(), S.cols())).llt();
  }

#line 470 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::solve(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 470 "src/math/eigen.birch"
  libbirch_function_("solve", "src/math/eigen.birch", 470);
  #line 471 "src/math/eigen.birch"

  return X.toEigen().householderQr().solve(y.toEigen()).eval();
  }

#line 479 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::solve(const birch::type::LLT& S, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 479 "src/math/eigen.birch"
  libbirch_function_("solve", "src/math/eigen.birch", 479);
  #line 480 "src/math/eigen.birch"

  return S.solve(y.toEigen()).eval();
  }

#line 488 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::solve(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 488 "src/math/eigen.birch"
  libbirch_function_("solve", "src/math/eigen.birch", 488);
  #line 489 "src/math/eigen.birch"

  return X.toEigen().householderQr().solve(Y.toEigen()).eval();
  }

#line 497 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::solve(const birch::type::LLT& S, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 497 "src/math/eigen.birch"
  libbirch_function_("solve", "src/math/eigen.birch", 497);
  #line 498 "src/math/eigen.birch"

  return S.solve(Y.toEigen()).eval();
  }

#line 508 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::cholesky(const birch::type::LLT& S) {
  #line 508 "src/math/eigen.birch"
  libbirch_function_("cholesky", "src/math/eigen.birch", 508);
  #line 509 "src/math/eigen.birch"

  return S.matrixL();
  }

#line 517 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::hadamard(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 517 "src/math/eigen.birch"
  libbirch_function_("hadamard", "src/math/eigen.birch", 517);
  #line 518 "src/math/eigen.birch"

  return x.toEigen().cwiseProduct(y.toEigen());
  }

#line 526 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::hadamard(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 526 "src/math/eigen.birch"
  libbirch_function_("hadamard", "src/math/eigen.birch", 526);
  #line 527 "src/math/eigen.birch"

  return X.toEigen().cwiseProduct(Y.toEigen());
  }

#line 9 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_bernoulli(const birch::type::Boolean& x, const birch::type::Real& ρ) {
  #line 9 "src/math/logpdf.birch"
  libbirch_function_("logpdf_bernoulli", "src/math/logpdf.birch", 9);
  #line 10 "src/math/logpdf.birch"
  libbirch_line_(10);
  #line 10 "src/math/logpdf.birch"
  libbirch_assert_(0.0 <= ρ && ρ <= 1.0);
  #line 11 "src/math/logpdf.birch"
  libbirch_line_(11);
  #line 11 "src/math/logpdf.birch"
  if (x) {
    #line 12 "src/math/logpdf.birch"
    libbirch_line_(12);
    #line 12 "src/math/logpdf.birch"
    return birch::log(ρ);
  } else {
    #line 14 "src/math/logpdf.birch"
    libbirch_line_(14);
    #line 14 "src/math/logpdf.birch"
    return birch::log1p(-(ρ));
  }
}

#line 26 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_delta(const birch::type::Integer& x, const birch::type::Integer& μ) {
  #line 26 "src/math/logpdf.birch"
  libbirch_function_("logpdf_delta", "src/math/logpdf.birch", 26);
  #line 27 "src/math/logpdf.birch"
  libbirch_line_(27);
  #line 27 "src/math/logpdf.birch"
  if (x == μ) {
    #line 28 "src/math/logpdf.birch"
    libbirch_line_(28);
    #line 28 "src/math/logpdf.birch"
    return 0.0;
  } else {
    #line 30 "src/math/logpdf.birch"
    libbirch_line_(30);
    #line 30 "src/math/logpdf.birch"
    return -(birch::inf());
  }
}

#line 43 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_binomial(const birch::type::Integer& x, const birch::type::Integer& n, const birch::type::Real& ρ) {
  #line 43 "src/math/logpdf.birch"
  libbirch_function_("logpdf_binomial", "src/math/logpdf.birch", 43);
  #line 44 "src/math/logpdf.birch"
  libbirch_line_(44);
  #line 44 "src/math/logpdf.birch"
  libbirch_assert_(birch::type::Integer(0) <= n);
  #line 45 "src/math/logpdf.birch"
  libbirch_line_(45);
  #line 45 "src/math/logpdf.birch"
  libbirch_assert_(0.0 <= ρ && ρ <= 1.0);
  #line 47 "src/math/logpdf.birch"
  libbirch_line_(47);
  #line 47 "src/math/logpdf.birch"
  if (ρ == 0.0 || ρ == 1.0) {
    #line 48 "src/math/logpdf.birch"
    libbirch_line_(48);
    #line 48 "src/math/logpdf.birch"
    if (x == n * ρ) {
      #line 49 "src/math/logpdf.birch"
      libbirch_line_(49);
      #line 49 "src/math/logpdf.birch"
      return 0.0;
    } else {
      #line 51 "src/math/logpdf.birch"
      libbirch_line_(51);
      #line 51 "src/math/logpdf.birch"
      return -(birch::inf());
    }
  } else {
    #line 53 "src/math/logpdf.birch"
    libbirch_line_(53);
    #line 53 "src/math/logpdf.birch"
    if (birch::type::Integer(0) <= x && x <= n) {
      #line 54 "src/math/logpdf.birch"
      libbirch_line_(54);
      #line 54 "src/math/logpdf.birch"
      return x * birch::log(ρ) + (n - x) * birch::log1p(-(ρ)) + birch::lchoose(n, x);
    } else {
      #line 56 "src/math/logpdf.birch"
      libbirch_line_(56);
      #line 56 "src/math/logpdf.birch"
      return -(birch::inf());
    }
  }
}

#line 69 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_negative_binomial(const birch::type::Integer& x, const birch::type::Integer& k, const birch::type::Real& ρ) {
  #line 69 "src/math/logpdf.birch"
  libbirch_function_("logpdf_negative_binomial", "src/math/logpdf.birch", 69);
  #line 70 "src/math/logpdf.birch"
  libbirch_line_(70);
  #line 70 "src/math/logpdf.birch"
  libbirch_assert_(birch::type::Integer(0) < k);
  #line 71 "src/math/logpdf.birch"
  libbirch_line_(71);
  #line 71 "src/math/logpdf.birch"
  libbirch_assert_(0.0 <= ρ && ρ <= 1.0);
  #line 73 "src/math/logpdf.birch"
  libbirch_line_(73);
  #line 73 "src/math/logpdf.birch"
  if (x >= birch::type::Integer(0)) {
    #line 74 "src/math/logpdf.birch"
    libbirch_line_(74);
    #line 74 "src/math/logpdf.birch"
    return k * birch::log(ρ) + x * birch::log1p(-(ρ)) + birch::lchoose(x + k - birch::type::Integer(1), x);
  } else {
    #line 76 "src/math/logpdf.birch"
    libbirch_line_(76);
    #line 76 "src/math/logpdf.birch"
    return -(birch::inf());
  }
}

#line 88 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_poisson(const birch::type::Integer& x, const birch::type::Real& λ) {
  #line 88 "src/math/logpdf.birch"
  libbirch_function_("logpdf_poisson", "src/math/logpdf.birch", 88);
  #line 89 "src/math/logpdf.birch"
  libbirch_line_(89);
  #line 89 "src/math/logpdf.birch"
  libbirch_assert_(0.0 <= λ);
  #line 91 "src/math/logpdf.birch"
  libbirch_line_(91);
  #line 91 "src/math/logpdf.birch"
  if (λ > 0.0) {
    #line 92 "src/math/logpdf.birch"
    libbirch_line_(92);
    #line 92 "src/math/logpdf.birch"
    if (x >= birch::type::Integer(0)) {
      #line 93 "src/math/logpdf.birch"
      libbirch_line_(93);
      #line 93 "src/math/logpdf.birch"
      return x * birch::log(λ) - λ - birch::lgamma(x + 1.0);
    } else {
      #line 95 "src/math/logpdf.birch"
      libbirch_line_(95);
      #line 95 "src/math/logpdf.birch"
      return -(birch::inf());
    }
  } else {
    #line 98 "src/math/logpdf.birch"
    libbirch_line_(98);
    #line 98 "src/math/logpdf.birch"
    if (x == birch::type::Integer(0)) {
      #line 99 "src/math/logpdf.birch"
      libbirch_line_(99);
      #line 99 "src/math/logpdf.birch"
      return birch::inf();
    } else {
      #line 101 "src/math/logpdf.birch"
      libbirch_line_(101);
      #line 101 "src/math/logpdf.birch"
      return -(birch::inf());
    }
  }
}

#line 115 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_uniform_int(const birch::type::Integer& x, const birch::type::Integer& l, const birch::type::Integer& u) {
  #line 115 "src/math/logpdf.birch"
  libbirch_function_("logpdf_uniform_int", "src/math/logpdf.birch", 115);
  #line 116 "src/math/logpdf.birch"
  libbirch_line_(116);
  #line 116 "src/math/logpdf.birch"
  if (x >= l && x <= u) {
    #line 117 "src/math/logpdf.birch"
    libbirch_line_(117);
    #line 117 "src/math/logpdf.birch"
    return -(birch::log1p(birch::Real(u - l)));
  } else {
    #line 119 "src/math/logpdf.birch"
    libbirch_line_(119);
    #line 119 "src/math/logpdf.birch"
    return -(birch::inf());
  }
}

#line 131 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_categorical(const birch::type::Integer& x, const libbirch::DefaultArray<birch::type::Real,1>& ρ) {
  #line 131 "src/math/logpdf.birch"
  libbirch_function_("logpdf_categorical", "src/math/logpdf.birch", 131);
  #line 132 "src/math/logpdf.birch"
  libbirch_line_(132);
  #line 132 "src/math/logpdf.birch"
  if (birch::type::Integer(1) <= x && x <= birch::length(ρ)) {
    #line 133 "src/math/logpdf.birch"
    libbirch_line_(133);
    #line 133 "src/math/logpdf.birch"
    libbirch_assert_(ρ(x) >= 0.0);
    #line 134 "src/math/logpdf.birch"
    libbirch_line_(134);
    #line 134 "src/math/logpdf.birch"
    return birch::log(ρ(x));
  } else {
    #line 136 "src/math/logpdf.birch"
    libbirch_line_(136);
    #line 136 "src/math/logpdf.birch"
    return -(birch::inf());
  }
}

#line 149 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_multinomial(const libbirch::DefaultArray<birch::type::Integer,1>& x, const birch::type::Integer& n, const libbirch::DefaultArray<birch::type::Real,1>& ρ) {
  #line 149 "src/math/logpdf.birch"
  libbirch_function_("logpdf_multinomial", "src/math/logpdf.birch", 149);
  #line 150 "src/math/logpdf.birch"
  libbirch_line_(150);
  #line 150 "src/math/logpdf.birch"
  libbirch_assert_(birch::length(x) == birch::length(ρ));
  #line 152 "src/math/logpdf.birch"
  libbirch_line_(152);
  #line 152 "src/math/logpdf.birch"
  birch::type::Integer m = birch::type::Integer(0);
  #line 153 "src/math/logpdf.birch"
  libbirch_line_(153);
  #line 153 "src/math/logpdf.birch"
  birch::type::Real w = birch::lgamma(n + 1.0);
  #line 154 "src/math/logpdf.birch"
  libbirch_line_(154);
  #line 154 "src/math/logpdf.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(x); ++i) {
    #line 155 "src/math/logpdf.birch"
    libbirch_line_(155);
    #line 155 "src/math/logpdf.birch"
    libbirch_assert_(x(i) >= birch::type::Integer(0));
    #line 156 "src/math/logpdf.birch"
    libbirch_line_(156);
    #line 156 "src/math/logpdf.birch"
    libbirch_assert_(ρ(i) >= 0.0);
    #line 157 "src/math/logpdf.birch"
    libbirch_line_(157);
    #line 157 "src/math/logpdf.birch"
    m = m + x(i);
    #line 158 "src/math/logpdf.birch"
    libbirch_line_(158);
    #line 158 "src/math/logpdf.birch"
    w = w + x(i) * birch::log(ρ(i)) - birch::lgamma(x(i) + 1.0);
  }
  #line 160 "src/math/logpdf.birch"
  libbirch_line_(160);
  #line 160 "src/math/logpdf.birch"
  if (m == n) {
    #line 161 "src/math/logpdf.birch"
    libbirch_line_(161);
    #line 161 "src/math/logpdf.birch"
    return w;
  } else {
    #line 163 "src/math/logpdf.birch"
    libbirch_line_(163);
    #line 163 "src/math/logpdf.birch"
    return -(birch::inf());
  }
}

#line 175 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_dirichlet(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& α) {
  #line 175 "src/math/logpdf.birch"
  libbirch_function_("logpdf_dirichlet", "src/math/logpdf.birch", 175);
  #line 176 "src/math/logpdf.birch"
  libbirch_line_(176);
  #line 176 "src/math/logpdf.birch"
  libbirch_assert_(birch::length(x) == birch::length(α));
  #line 178 "src/math/logpdf.birch"
  libbirch_line_(178);
  #line 178 "src/math/logpdf.birch"
  birch::type::Integer D = birch::length(x);
  #line 179 "src/math/logpdf.birch"
  libbirch_line_(179);
  #line 179 "src/math/logpdf.birch"
  birch::type::Real w = 0.0;
  #line 180 "src/math/logpdf.birch"
  libbirch_line_(180);
  #line 180 "src/math/logpdf.birch"
  for (auto i = birch::type::Integer(1); i <= D; ++i) {
    #line 181 "src/math/logpdf.birch"
    libbirch_line_(181);
    #line 181 "src/math/logpdf.birch"
    if (x(i) < 0.0) {
      #line 182 "src/math/logpdf.birch"
      libbirch_line_(182);
      #line 182 "src/math/logpdf.birch"
      return -(birch::inf());
    }
    #line 184 "src/math/logpdf.birch"
    libbirch_line_(184);
    #line 184 "src/math/logpdf.birch"
    w = w + (α(i) - 1.0) * birch::log(x(i)) - birch::lgamma(α(i));
  }
  #line 186 "src/math/logpdf.birch"
  libbirch_line_(186);
  #line 186 "src/math/logpdf.birch"
  w = w + birch::lgamma(birch::sum(α));
  #line 187 "src/math/logpdf.birch"
  libbirch_line_(187);
  #line 187 "src/math/logpdf.birch"
  return w;
}

#line 199 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_uniform(const birch::type::Real& x, const birch::type::Real& l, const birch::type::Real& u) {
  #line 199 "src/math/logpdf.birch"
  libbirch_function_("logpdf_uniform", "src/math/logpdf.birch", 199);
  #line 200 "src/math/logpdf.birch"
  libbirch_line_(200);
  #line 200 "src/math/logpdf.birch"
  libbirch_assert_(l <= u);
  #line 202 "src/math/logpdf.birch"
  libbirch_line_(202);
  #line 202 "src/math/logpdf.birch"
  if (x >= l && x <= u) {
    #line 203 "src/math/logpdf.birch"
    libbirch_line_(203);
    #line 203 "src/math/logpdf.birch"
    return -(birch::log(u - l));
  } else {
    #line 205 "src/math/logpdf.birch"
    libbirch_line_(205);
    #line 205 "src/math/logpdf.birch"
    return -(birch::inf());
  }
}

#line 217 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_exponential(const birch::type::Real& x, const birch::type::Real& λ) {
  #line 217 "src/math/logpdf.birch"
  libbirch_function_("logpdf_exponential", "src/math/logpdf.birch", 217);
  #line 218 "src/math/logpdf.birch"
  libbirch_line_(218);
  #line 218 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < λ);
  #line 219 "src/math/logpdf.birch"
  libbirch_line_(219);
  #line 219 "src/math/logpdf.birch"
  return birch::if_then_else(x < 0.0, -(birch::inf()), birch::log(λ) - λ * x);
}

#line 231 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_weibull(const birch::type::Real& x, const birch::type::Real& k, const birch::type::Real& λ) {
  #line 231 "src/math/logpdf.birch"
  libbirch_function_("logpdf_weibull", "src/math/logpdf.birch", 231);
  #line 232 "src/math/logpdf.birch"
  libbirch_line_(232);
  #line 232 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < λ);
  #line 233 "src/math/logpdf.birch"
  libbirch_line_(233);
  #line 233 "src/math/logpdf.birch"
  return birch::if_then_else(x < 0.0, -(birch::inf()), birch::log(k) + (k - 1.0) * birch::log(x) - k * birch::log(λ) - birch::pow(x / λ, k));
}

#line 246 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_gaussian(const birch::type::Real& x, const birch::type::Real& μ, const birch::type::Real& σ2) {
  #line 246 "src/math/logpdf.birch"
  libbirch_function_("logpdf_gaussian", "src/math/logpdf.birch", 246);
  #line 247 "src/math/logpdf.birch"
  libbirch_line_(247);
  #line 247 "src/math/logpdf.birch"
  libbirch_assert_(0.0 <= σ2);
  #line 248 "src/math/logpdf.birch"
  libbirch_line_(248);
  #line 248 "src/math/logpdf.birch"
  return -(0.5) * (birch::pow(x - μ, 2.0) / σ2 + birch::log(2.0 * birch::π() * σ2));
}

#line 259 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_student_t(const birch::type::Real& x, const birch::type::Real& k) {
  #line 259 "src/math/logpdf.birch"
  libbirch_function_("logpdf_student_t", "src/math/logpdf.birch", 259);
  #line 260 "src/math/logpdf.birch"
  libbirch_line_(260);
  #line 260 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < k);
  #line 261 "src/math/logpdf.birch"
  libbirch_line_(261);
  #line 261 "src/math/logpdf.birch"
  auto a = 0.5 * (k + 1.0);
  #line 262 "src/math/logpdf.birch"
  libbirch_line_(262);
  #line 262 "src/math/logpdf.birch"
  auto b = 0.5 * k;
  #line 263 "src/math/logpdf.birch"
  libbirch_line_(263);
  #line 263 "src/math/logpdf.birch"
  return birch::lgamma(a) - birch::lgamma(b) - 0.5 * birch::log(birch::π() * k) - a * birch::log1p(x * x / k);
}

#line 276 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_student_t(const birch::type::Real& x, const birch::type::Real& k, const birch::type::Real& μ, const birch::type::Real& v) {
  #line 276 "src/math/logpdf.birch"
  libbirch_function_("logpdf_student_t", "src/math/logpdf.birch", 276);
  #line 277 "src/math/logpdf.birch"
  libbirch_line_(277);
  #line 277 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < k);
  #line 278 "src/math/logpdf.birch"
  libbirch_line_(278);
  #line 278 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < v);
  #line 279 "src/math/logpdf.birch"
  libbirch_line_(279);
  #line 279 "src/math/logpdf.birch"
  auto a = 0.5 * (k + 1.0);
  #line 280 "src/math/logpdf.birch"
  libbirch_line_(280);
  #line 280 "src/math/logpdf.birch"
  auto b = 0.5 * k;
  #line 281 "src/math/logpdf.birch"
  libbirch_line_(281);
  #line 281 "src/math/logpdf.birch"
  auto z = x - μ;
  #line 282 "src/math/logpdf.birch"
  libbirch_line_(282);
  #line 282 "src/math/logpdf.birch"
  return birch::lgamma(a) - birch::lgamma(b) - 0.5 * birch::log(birch::π() * v) - a * birch::log1p(z * z / v);
}

#line 294 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_beta(const birch::type::Real& x, const birch::type::Real& α, const birch::type::Real& β) {
  #line 294 "src/math/logpdf.birch"
  libbirch_function_("logpdf_beta", "src/math/logpdf.birch", 294);
  #line 295 "src/math/logpdf.birch"
  libbirch_line_(295);
  #line 295 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < α);
  #line 296 "src/math/logpdf.birch"
  libbirch_line_(296);
  #line 296 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < β);
  #line 298 "src/math/logpdf.birch"
  libbirch_line_(298);
  #line 298 "src/math/logpdf.birch"
  if (0.0 < x && x < 1.0) {
    #line 299 "src/math/logpdf.birch"
    libbirch_line_(299);
    #line 299 "src/math/logpdf.birch"
    return (α - 1.0) * birch::log(x) + (β - 1.0) * birch::log1p(-(x)) - birch::lbeta(α, β);
  } else {
    #line 301 "src/math/logpdf.birch"
    libbirch_line_(301);
    #line 301 "src/math/logpdf.birch"
    return -(birch::inf());
  }
}

#line 313 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_chi_squared(const birch::type::Real& x, const birch::type::Real& ν) {
  #line 313 "src/math/logpdf.birch"
  libbirch_function_("logpdf_chi_squared", "src/math/logpdf.birch", 313);
  #line 314 "src/math/logpdf.birch"
  libbirch_line_(314);
  #line 314 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < ν);
  #line 315 "src/math/logpdf.birch"
  libbirch_line_(315);
  #line 315 "src/math/logpdf.birch"
  if (x > 0.0 || (x >= 0.0 && ν > 1.0)) {
    #line 316 "src/math/logpdf.birch"
    libbirch_line_(316);
    #line 316 "src/math/logpdf.birch"
    auto k = 0.5 * ν;
    #line 317 "src/math/logpdf.birch"
    libbirch_line_(317);
    #line 317 "src/math/logpdf.birch"
    return (k - 1.0) * birch::log(x) - 0.5 * x - birch::lgamma(k) - k * birch::log(2.0);
  } else {
    #line 319 "src/math/logpdf.birch"
    libbirch_line_(319);
    #line 319 "src/math/logpdf.birch"
    return -(birch::inf());
  }
}

#line 332 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_gamma(const birch::type::Real& x, const birch::type::Real& k, const birch::type::Real& θ) {
  #line 332 "src/math/logpdf.birch"
  libbirch_function_("logpdf_gamma", "src/math/logpdf.birch", 332);
  #line 333 "src/math/logpdf.birch"
  libbirch_line_(333);
  #line 333 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < k);
  #line 334 "src/math/logpdf.birch"
  libbirch_line_(334);
  #line 334 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < θ);
  #line 335 "src/math/logpdf.birch"
  libbirch_line_(335);
  #line 335 "src/math/logpdf.birch"
  return birch::if_then_else(x < 0.0, -(birch::inf()), (k - 1.0) * birch::log(x) - x / θ - birch::lgamma(k) - k * birch::log(θ));
}

#line 348 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_wishart(const birch::type::LLT& X, const birch::type::LLT& Ψ, const birch::type::Real& ν) {
  #line 348 "src/math/logpdf.birch"
  libbirch_function_("logpdf_wishart", "src/math/logpdf.birch", 348);
  #line 349 "src/math/logpdf.birch"
  libbirch_line_(349);
  #line 349 "src/math/logpdf.birch"
  auto p = birch::columns(Ψ);
  #line 350 "src/math/logpdf.birch"
  libbirch_line_(350);
  #line 350 "src/math/logpdf.birch"
  libbirch_assert_(ν > p - birch::type::Integer(1));
  #line 351 "src/math/logpdf.birch"
  libbirch_line_(351);
  #line 351 "src/math/logpdf.birch"
  return 0.5 * (ν - p - 1.0) * birch::ldet(X) - 0.5 * birch::trace(birch::solve(Ψ, birch::canonical(X))) - 0.5 * ν * (p * birch::log(2.0) + birch::ldet(Ψ)) - birch::lgamma(0.5 * ν, p);
}

#line 364 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_inverse_gamma(const birch::type::Real& x, const birch::type::Real& α, const birch::type::Real& β) {
  #line 364 "src/math/logpdf.birch"
  libbirch_function_("logpdf_inverse_gamma", "src/math/logpdf.birch", 364);
  #line 365 "src/math/logpdf.birch"
  libbirch_line_(365);
  #line 365 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < α);
  #line 366 "src/math/logpdf.birch"
  libbirch_line_(366);
  #line 366 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < β);
  #line 367 "src/math/logpdf.birch"
  libbirch_line_(367);
  #line 367 "src/math/logpdf.birch"
  return birch::if_then_else(x < 0.0, -(birch::inf()), α * birch::log(β) - (α + 1.0) * birch::log(x) - β / x - birch::lgamma(α));
}

#line 380 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_inverse_wishart(const birch::type::LLT& X, const birch::type::LLT& Ψ, const birch::type::Real& ν) {
  #line 380 "src/math/logpdf.birch"
  libbirch_function_("logpdf_inverse_wishart", "src/math/logpdf.birch", 380);
  #line 381 "src/math/logpdf.birch"
  libbirch_line_(381);
  #line 381 "src/math/logpdf.birch"
  auto p = birch::rows(Ψ);
  #line 382 "src/math/logpdf.birch"
  libbirch_line_(382);
  #line 382 "src/math/logpdf.birch"
  libbirch_assert_(ν > p - birch::type::Integer(1));
  #line 383 "src/math/logpdf.birch"
  libbirch_line_(383);
  #line 383 "src/math/logpdf.birch"
  return -(0.5) * (ν + p - 1.0) * birch::ldet(X) - 0.5 * birch::trace(birch::solve(X, birch::canonical(Ψ))) - 0.5 * ν * (p * birch::log(2.0) - birch::ldet(Ψ)) - birch::lgamma(0.5 * ν, p);
}

#line 397 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_inverse_gamma_gamma(const birch::type::Real& x, const birch::type::Real& k, const birch::type::Real& α, const birch::type::Real& β) {
  #line 397 "src/math/logpdf.birch"
  libbirch_function_("logpdf_inverse_gamma_gamma", "src/math/logpdf.birch", 397);
  #line 398 "src/math/logpdf.birch"
  libbirch_line_(398);
  #line 398 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < k);
  #line 399 "src/math/logpdf.birch"
  libbirch_line_(399);
  #line 399 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < α);
  #line 400 "src/math/logpdf.birch"
  libbirch_line_(400);
  #line 400 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < β);
  #line 401 "src/math/logpdf.birch"
  libbirch_line_(401);
  #line 401 "src/math/logpdf.birch"
  return birch::if_then_else(x < 0.0, -(birch::inf()), (k - birch::type::Integer(1)) * birch::log(x) + α * birch::log(β) - (α + k) * birch::log(β + x) - birch::lbeta(α, k));
}

#line 416 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_normal_inverse_gamma(const birch::type::Real& x, const birch::type::Real& μ, const birch::type::Real& a2, const birch::type::Real& α, const birch::type::Real& β) {
  #line 416 "src/math/logpdf.birch"
  libbirch_function_("logpdf_normal_inverse_gamma", "src/math/logpdf.birch", 416);
  #line 418 "src/math/logpdf.birch"
  libbirch_line_(418);
  #line 418 "src/math/logpdf.birch"
  return birch::logpdf_student_t(x, 2.0 * α, μ, a2 * 2.0 * β);
}

#line 430 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_beta_bernoulli(const birch::type::Boolean& x, const birch::type::Real& α, const birch::type::Real& β) {
  #line 430 "src/math/logpdf.birch"
  libbirch_function_("logpdf_beta_bernoulli", "src/math/logpdf.birch", 430);
  #line 431 "src/math/logpdf.birch"
  libbirch_line_(431);
  #line 431 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < α);
  #line 432 "src/math/logpdf.birch"
  libbirch_line_(432);
  #line 432 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < β);
  #line 434 "src/math/logpdf.birch"
  libbirch_line_(434);
  #line 434 "src/math/logpdf.birch"
  if (x) {
    #line 435 "src/math/logpdf.birch"
    libbirch_line_(435);
    #line 435 "src/math/logpdf.birch"
    return birch::log(α) - birch::log(α + β);
  } else {
    #line 437 "src/math/logpdf.birch"
    libbirch_line_(437);
    #line 437 "src/math/logpdf.birch"
    return birch::log(β) - birch::log(α + β);
  }
}

#line 451 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_beta_binomial(const birch::type::Integer& x, const birch::type::Integer& n, const birch::type::Real& α, const birch::type::Real& β) {
  #line 451 "src/math/logpdf.birch"
  libbirch_function_("logpdf_beta_binomial", "src/math/logpdf.birch", 451);
  #line 452 "src/math/logpdf.birch"
  libbirch_line_(452);
  #line 452 "src/math/logpdf.birch"
  libbirch_assert_(birch::type::Integer(0) <= n);
  #line 453 "src/math/logpdf.birch"
  libbirch_line_(453);
  #line 453 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < α);
  #line 454 "src/math/logpdf.birch"
  libbirch_line_(454);
  #line 454 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < β);
  #line 456 "src/math/logpdf.birch"
  libbirch_line_(456);
  #line 456 "src/math/logpdf.birch"
  if (birch::type::Integer(0) <= x && x <= n) {
    #line 457 "src/math/logpdf.birch"
    libbirch_line_(457);
    #line 457 "src/math/logpdf.birch"
    return birch::lbeta(x + α, n - x + β) - birch::lbeta(α, β) + birch::lchoose(n, x);
  } else {
    #line 459 "src/math/logpdf.birch"
    libbirch_line_(459);
    #line 459 "src/math/logpdf.birch"
    return -(birch::inf());
  }
}

#line 473 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_beta_negative_binomial(const birch::type::Integer& x, const birch::type::Integer& k, const birch::type::Real& α, const birch::type::Real& β) {
  #line 473 "src/math/logpdf.birch"
  libbirch_function_("logpdf_beta_negative_binomial", "src/math/logpdf.birch", 473);
  #line 474 "src/math/logpdf.birch"
  libbirch_line_(474);
  #line 474 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < α);
  #line 475 "src/math/logpdf.birch"
  libbirch_line_(475);
  #line 475 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < β);
  #line 477 "src/math/logpdf.birch"
  libbirch_line_(477);
  #line 477 "src/math/logpdf.birch"
  if (x >= birch::type::Integer(0)) {
    #line 478 "src/math/logpdf.birch"
    libbirch_line_(478);
    #line 478 "src/math/logpdf.birch"
    return birch::lbeta(α + k, β + x) - birch::lbeta(α, β) + birch::lchoose(x + k - birch::type::Integer(1), x);
  } else {
    #line 480 "src/math/logpdf.birch"
    libbirch_line_(480);
    #line 480 "src/math/logpdf.birch"
    return -(birch::inf());
  }
}

#line 493 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_gamma_poisson(const birch::type::Integer& x, const birch::type::Real& k, const birch::type::Real& θ) {
  #line 493 "src/math/logpdf.birch"
  libbirch_function_("logpdf_gamma_poisson", "src/math/logpdf.birch", 493);
  #line 494 "src/math/logpdf.birch"
  libbirch_line_(494);
  #line 494 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < k);
  #line 495 "src/math/logpdf.birch"
  libbirch_line_(495);
  #line 495 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < θ);
  #line 496 "src/math/logpdf.birch"
  libbirch_line_(496);
  #line 496 "src/math/logpdf.birch"
  libbirch_assert_(k == birch::floor(k));
  #line 498 "src/math/logpdf.birch"
  libbirch_line_(498);
  #line 498 "src/math/logpdf.birch"
  return birch::logpdf_negative_binomial(x, birch::Integer(k), 1.0 / (θ + 1.0));
}

#line 510 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_lomax(const birch::type::Real& x, const birch::type::Real& λ, const birch::type::Real& α) {
  #line 510 "src/math/logpdf.birch"
  libbirch_function_("logpdf_lomax", "src/math/logpdf.birch", 510);
  #line 511 "src/math/logpdf.birch"
  libbirch_line_(511);
  #line 511 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < λ);
  #line 512 "src/math/logpdf.birch"
  libbirch_line_(512);
  #line 512 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < α);
  #line 513 "src/math/logpdf.birch"
  libbirch_line_(513);
  #line 513 "src/math/logpdf.birch"
  return birch::if_then_else(x < 0.0, -(birch::inf()), birch::log(α) - birch::log(λ) - (α + 1.0) * birch::log1p(x / λ));
}

#line 525 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_dirichlet_categorical(const birch::type::Integer& x, const libbirch::DefaultArray<birch::type::Real,1>& α) {
  #line 525 "src/math/logpdf.birch"
  libbirch_function_("logpdf_dirichlet_categorical", "src/math/logpdf.birch", 525);
  #line 526 "src/math/logpdf.birch"
  libbirch_line_(526);
  #line 526 "src/math/logpdf.birch"
  if (birch::type::Integer(1) <= x && x <= birch::length(α)) {
    #line 527 "src/math/logpdf.birch"
    libbirch_line_(527);
    #line 527 "src/math/logpdf.birch"
    birch::type::Real A = birch::sum(α);
    #line 528 "src/math/logpdf.birch"
    libbirch_line_(528);
    #line 528 "src/math/logpdf.birch"
    return birch::lgamma(1.0 + α(x)) - birch::lgamma(α(x)) + birch::lgamma(A) - birch::lgamma(1.0 + A);
  } else {
    #line 530 "src/math/logpdf.birch"
    libbirch_line_(530);
    #line 530 "src/math/logpdf.birch"
    return -(birch::inf());
  }
}

#line 543 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_dirichlet_multinomial(const libbirch::DefaultArray<birch::type::Integer,1>& x, const birch::type::Integer& n, const libbirch::DefaultArray<birch::type::Real,1>& α) {
  #line 543 "src/math/logpdf.birch"
  libbirch_function_("logpdf_dirichlet_multinomial", "src/math/logpdf.birch", 543);
  #line 544 "src/math/logpdf.birch"
  libbirch_line_(544);
  #line 544 "src/math/logpdf.birch"
  libbirch_assert_(birch::length(x) == birch::length(α));
  #line 546 "src/math/logpdf.birch"
  libbirch_line_(546);
  #line 546 "src/math/logpdf.birch"
  birch::type::Real A = birch::sum(α);
  #line 547 "src/math/logpdf.birch"
  libbirch_line_(547);
  #line 547 "src/math/logpdf.birch"
  birch::type::Integer m = birch::type::Integer(0);
  #line 548 "src/math/logpdf.birch"
  libbirch_line_(548);
  #line 548 "src/math/logpdf.birch"
  birch::type::Real w = birch::lgamma(n + 1.0) + birch::lgamma(A) - birch::lgamma(n + A);
  #line 549 "src/math/logpdf.birch"
  libbirch_line_(549);
  #line 549 "src/math/logpdf.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(α); ++i) {
    #line 550 "src/math/logpdf.birch"
    libbirch_line_(550);
    #line 550 "src/math/logpdf.birch"
    libbirch_assert_(x(i) >= birch::type::Integer(0));
    #line 551 "src/math/logpdf.birch"
    libbirch_line_(551);
    #line 551 "src/math/logpdf.birch"
    m = m + x(i);
    #line 552 "src/math/logpdf.birch"
    libbirch_line_(552);
    #line 552 "src/math/logpdf.birch"
    w = w + birch::lgamma(x(i) + α(i)) - birch::lgamma(x(i) + 1.0) - birch::lgamma(α(i));
  }
  #line 554 "src/math/logpdf.birch"
  libbirch_line_(554);
  #line 554 "src/math/logpdf.birch"
  if (m == n) {
    #line 555 "src/math/logpdf.birch"
    libbirch_line_(555);
    #line 555 "src/math/logpdf.birch"
    return w;
  } else {
    #line 557 "src/math/logpdf.birch"
    libbirch_line_(557);
    #line 557 "src/math/logpdf.birch"
    return -(birch::inf());
  }
}

#line 571 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_crp_categorical(const birch::type::Integer& k, const birch::type::Real& α, const birch::type::Real& θ, const libbirch::DefaultArray<birch::type::Integer,1>& n, const birch::type::Integer& N) {
  #line 571 "src/math/logpdf.birch"
  libbirch_function_("logpdf_crp_categorical", "src/math/logpdf.birch", 571);
  #line 573 "src/math/logpdf.birch"
  libbirch_line_(573);
  #line 573 "src/math/logpdf.birch"
  birch::type::Integer K = birch::length(n);
  #line 574 "src/math/logpdf.birch"
  libbirch_line_(574);
  #line 574 "src/math/logpdf.birch"
  if (k > K + birch::type::Integer(1)) {
    #line 575 "src/math/logpdf.birch"
    libbirch_line_(575);
    #line 575 "src/math/logpdf.birch"
    return -(birch::inf());
  } else {
    #line 576 "src/math/logpdf.birch"
    libbirch_line_(576);
    #line 576 "src/math/logpdf.birch"
    if (k == K + birch::type::Integer(1)) {
      #line 577 "src/math/logpdf.birch"
      libbirch_line_(577);
      #line 577 "src/math/logpdf.birch"
      return birch::log(K * α + θ) - birch::log(N + θ);
    } else {
      #line 579 "src/math/logpdf.birch"
      libbirch_line_(579);
      #line 579 "src/math/logpdf.birch"
      return birch::log(n(k) - α) - birch::log(N + θ);
    }
  }
}

#line 594 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_normal_inverse_gamma_gaussian(const birch::type::Real& x, const birch::type::Real& μ, const birch::type::Real& a2, const birch::type::Real& α, const birch::type::Real& β) {
  #line 594 "src/math/logpdf.birch"
  libbirch_function_("logpdf_normal_inverse_gamma_gaussian", "src/math/logpdf.birch", 594);
  #line 596 "src/math/logpdf.birch"
  libbirch_line_(596);
  #line 596 "src/math/logpdf.birch"
  return birch::logpdf_student_t(x, 2.0 * α, μ, 2.0 * β * (1.0 + a2));
}

#line 613 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_linear_normal_inverse_gamma_gaussian(const birch::type::Real& x, const birch::type::Real& a, const birch::type::Real& μ, const birch::type::Real& a2, const birch::type::Real& c, const birch::type::Real& α, const birch::type::Real& β) {
  #line 613 "src/math/logpdf.birch"
  libbirch_function_("logpdf_linear_normal_inverse_gamma_gaussian", "src/math/logpdf.birch", 613);
  #line 615 "src/math/logpdf.birch"
  libbirch_line_(615);
  #line 615 "src/math/logpdf.birch"
  return birch::logpdf_student_t(x, 2.0 * α, a * μ + c, 2.0 * β * (1.0 + a * a * a2));
}

#line 627 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& μ, const birch::type::LLT& Σ) {
  #line 627 "src/math/logpdf.birch"
  libbirch_function_("logpdf_multivariate_gaussian", "src/math/logpdf.birch", 627);
  #line 628 "src/math/logpdf.birch"
  libbirch_line_(628);
  #line 628 "src/math/logpdf.birch"
  auto n = birch::length(μ);
  #line 629 "src/math/logpdf.birch"
  libbirch_line_(629);
  #line 629 "src/math/logpdf.birch"
  return -(0.5) * (birch::dot(x - μ, birch::solve(Σ, x - μ)) + n * birch::log(2.0 * birch::π()) + birch::ldet(Σ));
}

#line 641 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& μ, const libbirch::DefaultArray<birch::type::Real,1>& σ2) {
  #line 641 "src/math/logpdf.birch"
  libbirch_function_("logpdf_multivariate_gaussian", "src/math/logpdf.birch", 641);
  #line 642 "src/math/logpdf.birch"
  libbirch_line_(642);
  #line 642 "src/math/logpdf.birch"
  auto n = birch::length(μ);
  #line 643 "src/math/logpdf.birch"
  libbirch_line_(643);
  #line 643 "src/math/logpdf.birch"
  auto w = 0.0;
  #line 644 "src/math/logpdf.birch"
  libbirch_line_(644);
  #line 644 "src/math/logpdf.birch"
  for (auto d = birch::type::Integer(1); d <= n; ++d) {
    #line 645 "src/math/logpdf.birch"
    libbirch_line_(645);
    #line 645 "src/math/logpdf.birch"
    w = w + birch::logpdf_gaussian(x(d), μ(d), σ2(d));
  }
  #line 647 "src/math/logpdf.birch"
  libbirch_line_(647);
  #line 647 "src/math/logpdf.birch"
  return w;
}

#line 660 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& μ, const birch::type::Real& σ2) {
  #line 660 "src/math/logpdf.birch"
  libbirch_function_("logpdf_multivariate_gaussian", "src/math/logpdf.birch", 660);
  #line 661 "src/math/logpdf.birch"
  libbirch_line_(661);
  #line 661 "src/math/logpdf.birch"
  auto n = birch::length(μ);
  #line 662 "src/math/logpdf.birch"
  libbirch_line_(662);
  #line 662 "src/math/logpdf.birch"
  return -(0.5) * (birch::dot(x - μ) / σ2 + n * birch::log(2.0 * birch::π() * σ2));
}

#line 676 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_multivariate_normal_inverse_gamma(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& ν, const birch::type::LLT& Λ, const birch::type::Real& α, const birch::type::Real& β) {
  #line 676 "src/math/logpdf.birch"
  libbirch_function_("logpdf_multivariate_normal_inverse_gamma", "src/math/logpdf.birch", 676);
  #line 678 "src/math/logpdf.birch"
  libbirch_line_(678);
  #line 678 "src/math/logpdf.birch"
  return birch::logpdf_multivariate_student_t(x, 2.0 * α, birch::solve(Λ, ν), birch::inv(Λ), 2.0 * β);
}

#line 693 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_multivariate_normal_inverse_gamma_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& ν, const birch::type::LLT& Λ, const birch::type::Real& α, const birch::type::Real& γ) {
  #line 693 "src/math/logpdf.birch"
  libbirch_function_("logpdf_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/math/logpdf.birch", 693);
  #line 695 "src/math/logpdf.birch"
  libbirch_line_(695);
  #line 695 "src/math/logpdf.birch"
  auto n = birch::length(ν);
  #line 696 "src/math/logpdf.birch"
  libbirch_line_(696);
  #line 696 "src/math/logpdf.birch"
  auto μ = birch::solve(Λ, ν);
  #line 697 "src/math/logpdf.birch"
  libbirch_line_(697);
  #line 697 "src/math/logpdf.birch"
  auto β = γ - 0.5 * birch::dot(μ, ν);
  #line 698 "src/math/logpdf.birch"
  libbirch_line_(698);
  #line 698 "src/math/logpdf.birch"
  return birch::logpdf_multivariate_student_t(x, 2.0 * α, μ, birch::llt(birch::identity(n) + birch::canonical(birch::inv(Λ))), 2.0 * β);
}

#line 716 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,2>& A, const libbirch::DefaultArray<birch::type::Real,1>& ν, const birch::type::LLT& Λ, const libbirch::DefaultArray<birch::type::Real,1>& c, const birch::type::Real& α, const birch::type::Real& γ) {
  #line 716 "src/math/logpdf.birch"
  libbirch_function_("logpdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/math/logpdf.birch", 716);
  #line 719 "src/math/logpdf.birch"
  libbirch_line_(719);
  #line 719 "src/math/logpdf.birch"
  auto n = birch::rows(A);
  #line 720 "src/math/logpdf.birch"
  libbirch_line_(720);
  #line 720 "src/math/logpdf.birch"
  auto μ = birch::solve(Λ, ν);
  #line 721 "src/math/logpdf.birch"
  libbirch_line_(721);
  #line 721 "src/math/logpdf.birch"
  auto β = γ - 0.5 * birch::dot(μ, ν);
  #line 722 "src/math/logpdf.birch"
  libbirch_line_(722);
  #line 722 "src/math/logpdf.birch"
  return birch::logpdf_multivariate_student_t(x, 2.0 * α, A * μ + c, birch::llt(birch::identity(n) + A * birch::solve(Λ, birch::transpose(A))), 2.0 * β);
}

#line 740 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_linear_multivariate_normal_inverse_gamma_gaussian(const birch::type::Real& x, const libbirch::DefaultArray<birch::type::Real,1>& a, const libbirch::DefaultArray<birch::type::Real,1>& ν, const birch::type::LLT& Λ, const birch::type::Real& c, const birch::type::Real& α, const birch::type::Real& γ) {
  #line 740 "src/math/logpdf.birch"
  libbirch_function_("logpdf_linear_multivariate_normal_inverse_gamma_gaussian", "src/math/logpdf.birch", 740);
  #line 742 "src/math/logpdf.birch"
  libbirch_line_(742);
  #line 742 "src/math/logpdf.birch"
  auto μ = birch::solve(Λ, ν);
  #line 743 "src/math/logpdf.birch"
  libbirch_line_(743);
  #line 743 "src/math/logpdf.birch"
  auto β = γ - 0.5 * birch::dot(μ, ν);
  #line 744 "src/math/logpdf.birch"
  libbirch_line_(744);
  #line 744 "src/math/logpdf.birch"
  return birch::logpdf_student_t(x, 2.0 * α, birch::dot(a, μ) + c, 2.0 * β * (1.0 + birch::dot(a, birch::solve(Λ, a))));
}

#line 758 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const birch::type::LLT& V) {
  #line 758 "src/math/logpdf.birch"
  libbirch_function_("logpdf_matrix_gaussian", "src/math/logpdf.birch", 758);
  #line 760 "src/math/logpdf.birch"
  libbirch_line_(760);
  #line 760 "src/math/logpdf.birch"
  auto n = birch::rows(M);
  #line 761 "src/math/logpdf.birch"
  libbirch_line_(761);
  #line 761 "src/math/logpdf.birch"
  auto p = birch::columns(M);
  #line 762 "src/math/logpdf.birch"
  libbirch_line_(762);
  #line 762 "src/math/logpdf.birch"
  return -(0.5) * (birch::trace(birch::solve(V, birch::transpose(X - M)) * birch::solve(U, X - M)) + n * p * birch::log(2.0 * birch::π()) + n * birch::ldet(V) + p * birch::ldet(U));
}

#line 776 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const libbirch::DefaultArray<birch::type::Real,1>& σ2) {
  #line 776 "src/math/logpdf.birch"
  libbirch_function_("logpdf_matrix_gaussian", "src/math/logpdf.birch", 776);
  #line 778 "src/math/logpdf.birch"
  libbirch_line_(778);
  #line 778 "src/math/logpdf.birch"
  auto n = birch::rows(M);
  #line 779 "src/math/logpdf.birch"
  libbirch_line_(779);
  #line 779 "src/math/logpdf.birch"
  auto p = birch::columns(M);
  #line 780 "src/math/logpdf.birch"
  libbirch_line_(780);
  #line 780 "src/math/logpdf.birch"
  return -(0.5) * (birch::trace(birch::solve(birch::diagonal(σ2), birch::transpose(X - M)) * birch::solve(U, X - M)) + n * p * birch::log(2.0 * birch::π()) + n * birch::ldet(birch::diagonal(σ2)) + p * birch::ldet(U));
}

#line 793 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& V) {
  #line 793 "src/math/logpdf.birch"
  libbirch_function_("logpdf_matrix_gaussian", "src/math/logpdf.birch", 793);
  #line 794 "src/math/logpdf.birch"
  libbirch_line_(794);
  #line 794 "src/math/logpdf.birch"
  auto n = birch::rows(M);
  #line 795 "src/math/logpdf.birch"
  libbirch_line_(795);
  #line 795 "src/math/logpdf.birch"
  auto p = birch::columns(M);
  #line 796 "src/math/logpdf.birch"
  libbirch_line_(796);
  #line 796 "src/math/logpdf.birch"
  return -(0.5) * (birch::trace(birch::solve(V, birch::transpose(X - M)) * (X - M)) + n * p * birch::log(2.0 * birch::π()) + n * birch::ldet(V));
}

#line 809 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::DefaultArray<birch::type::Real,1>& σ2) {
  #line 809 "src/math/logpdf.birch"
  libbirch_function_("logpdf_matrix_gaussian", "src/math/logpdf.birch", 809);
  #line 811 "src/math/logpdf.birch"
  libbirch_line_(811);
  #line 811 "src/math/logpdf.birch"
  auto n = birch::rows(M);
  #line 812 "src/math/logpdf.birch"
  libbirch_line_(812);
  #line 812 "src/math/logpdf.birch"
  auto p = birch::columns(M);
  #line 813 "src/math/logpdf.birch"
  libbirch_line_(813);
  #line 813 "src/math/logpdf.birch"
  return -(0.5) * (birch::trace(birch::solve(birch::diagonal(σ2), birch::outer(birch::transpose(X - M)))) + n * p * birch::log(2.0 * birch::π()) + n * birch::ldet(birch::diagonal(σ2)));
}

#line 827 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::Real& σ2) {
  #line 827 "src/math/logpdf.birch"
  libbirch_function_("logpdf_matrix_gaussian", "src/math/logpdf.birch", 827);
  #line 829 "src/math/logpdf.birch"
  libbirch_line_(829);
  #line 829 "src/math/logpdf.birch"
  auto n = birch::rows(M);
  #line 830 "src/math/logpdf.birch"
  libbirch_line_(830);
  #line 830 "src/math/logpdf.birch"
  auto p = birch::columns(M);
  #line 831 "src/math/logpdf.birch"
  libbirch_line_(831);
  #line 831 "src/math/logpdf.birch"
  return -(0.5) * (birch::trace(birch::outer(birch::transpose(X - M)) / σ2) + n * p * birch::log(2.0 * birch::π() * σ2));
}

#line 845 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_matrix_normal_inverse_wishart(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& Λ, const birch::type::LLT& Ψ, const birch::type::Real& k) {
  #line 845 "src/math/logpdf.birch"
  libbirch_function_("logpdf_matrix_normal_inverse_wishart", "src/math/logpdf.birch", 845);
  #line 847 "src/math/logpdf.birch"
  libbirch_line_(847);
  #line 847 "src/math/logpdf.birch"
  auto n = birch::rows(N);
  #line 848 "src/math/logpdf.birch"
  libbirch_line_(848);
  #line 848 "src/math/logpdf.birch"
  auto p = birch::columns(N);
  #line 849 "src/math/logpdf.birch"
  libbirch_line_(849);
  #line 849 "src/math/logpdf.birch"
  auto M = birch::solve(Λ, N);
  #line 850 "src/math/logpdf.birch"
  libbirch_line_(850);
  #line 850 "src/math/logpdf.birch"
  auto Σ = birch::inv(Λ);
  #line 851 "src/math/logpdf.birch"
  libbirch_line_(851);
  #line 851 "src/math/logpdf.birch"
  return birch::logpdf_matrix_student_t(X, k - p + 1.0, M, Σ, Ψ);
}

#line 865 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_matrix_normal_inverse_wishart_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& Λ, const birch::type::LLT& Ψ, const birch::type::Real& k) {
  #line 865 "src/math/logpdf.birch"
  libbirch_function_("logpdf_matrix_normal_inverse_wishart_matrix_gaussian", "src/math/logpdf.birch", 865);
  #line 867 "src/math/logpdf.birch"
  libbirch_line_(867);
  #line 867 "src/math/logpdf.birch"
  auto n = birch::rows(N);
  #line 868 "src/math/logpdf.birch"
  libbirch_line_(868);
  #line 868 "src/math/logpdf.birch"
  auto p = birch::columns(N);
  #line 869 "src/math/logpdf.birch"
  libbirch_line_(869);
  #line 869 "src/math/logpdf.birch"
  auto M = birch::solve(Λ, N);
  #line 870 "src/math/logpdf.birch"
  libbirch_line_(870);
  #line 870 "src/math/logpdf.birch"
  auto Σ = birch::llt(birch::identity(n) + birch::canonical(birch::inv(Λ)));
  #line 871 "src/math/logpdf.birch"
  libbirch_line_(871);
  #line 871 "src/math/logpdf.birch"
  return birch::logpdf_matrix_student_t(X, k - p + 1.0, M, Σ, Ψ);
}

#line 888 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_linear_matrix_normal_inverse_wishart_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& A, const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& Λ, const libbirch::DefaultArray<birch::type::Real,2>& C, const birch::type::LLT& Ψ, const birch::type::Real& k) {
  #line 888 "src/math/logpdf.birch"
  libbirch_function_("logpdf_linear_matrix_normal_inverse_wishart_matrix_gaussian", "src/math/logpdf.birch", 888);
  #line 891 "src/math/logpdf.birch"
  libbirch_line_(891);
  #line 891 "src/math/logpdf.birch"
  auto n = birch::rows(A);
  #line 892 "src/math/logpdf.birch"
  libbirch_line_(892);
  #line 892 "src/math/logpdf.birch"
  auto p = birch::columns(N);
  #line 893 "src/math/logpdf.birch"
  libbirch_line_(893);
  #line 893 "src/math/logpdf.birch"
  auto M = birch::solve(Λ, N);
  #line 894 "src/math/logpdf.birch"
  libbirch_line_(894);
  #line 894 "src/math/logpdf.birch"
  auto Σ = birch::llt(birch::identity(n) + A * birch::solve(Λ, birch::transpose(A)));
  #line 895 "src/math/logpdf.birch"
  libbirch_line_(895);
  #line 895 "src/math/logpdf.birch"
  return birch::logpdf_matrix_student_t(X, k - p + 1.0, A * M + C, Σ, Ψ);
}

#line 912 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& a, const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& Λ, const libbirch::DefaultArray<birch::type::Real,1>& c, const birch::type::LLT& Ψ, const birch::type::Real& k) {
  #line 912 "src/math/logpdf.birch"
  libbirch_function_("logpdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian", "src/math/logpdf.birch", 912);
  #line 915 "src/math/logpdf.birch"
  libbirch_line_(915);
  #line 915 "src/math/logpdf.birch"
  auto p = birch::columns(N);
  #line 916 "src/math/logpdf.birch"
  libbirch_line_(916);
  #line 916 "src/math/logpdf.birch"
  auto M = birch::solve(Λ, N);
  #line 917 "src/math/logpdf.birch"
  libbirch_line_(917);
  #line 917 "src/math/logpdf.birch"
  auto σ2 = 1.0 + birch::dot(a, birch::solve(Λ, a));
  #line 918 "src/math/logpdf.birch"
  libbirch_line_(918);
  #line 918 "src/math/logpdf.birch"
  return birch::logpdf_multivariate_student_t(x, k - p + 1.0, birch::dot(a, M) + c, σ2, Ψ);
}

#line 933 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_multivariate_student_t(const libbirch::DefaultArray<birch::type::Real,1>& x, const birch::type::Real& k, const libbirch::DefaultArray<birch::type::Real,1>& μ, const birch::type::LLT& U, const birch::type::Real& v) {
  #line 933 "src/math/logpdf.birch"
  libbirch_function_("logpdf_multivariate_student_t", "src/math/logpdf.birch", 933);
  #line 935 "src/math/logpdf.birch"
  libbirch_line_(935);
  #line 935 "src/math/logpdf.birch"
  return birch::logpdf_multivariate_student_t(x, k, μ, v, U);
}

#line 950 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_multivariate_student_t(const libbirch::DefaultArray<birch::type::Real,1>& x, const birch::type::Real& k, const libbirch::DefaultArray<birch::type::Real,1>& μ, const birch::type::Real& u, const birch::type::LLT& V) {
  #line 950 "src/math/logpdf.birch"
  libbirch_function_("logpdf_multivariate_student_t", "src/math/logpdf.birch", 950);
  #line 952 "src/math/logpdf.birch"
  libbirch_line_(952);
  #line 952 "src/math/logpdf.birch"
  auto p = birch::length(μ);
  #line 953 "src/math/logpdf.birch"
  libbirch_line_(953);
  #line 953 "src/math/logpdf.birch"
  auto a = 0.5 * (k + p);
  #line 954 "src/math/logpdf.birch"
  libbirch_line_(954);
  #line 954 "src/math/logpdf.birch"
  auto b = 0.5 * k;
  #line 955 "src/math/logpdf.birch"
  libbirch_line_(955);
  #line 955 "src/math/logpdf.birch"
  auto z = x - μ;
  #line 956 "src/math/logpdf.birch"
  libbirch_line_(956);
  #line 956 "src/math/logpdf.birch"
  return birch::lgamma(a) - 0.5 * p * birch::log(birch::π()) - birch::lgamma(b) - 0.5 * p * birch::log(u) - 0.5 * birch::ldet(V) - a * birch::log1p(birch::dot(z, birch::solve(V, z)) / u);
}

#line 972 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_matrix_student_t(const libbirch::DefaultArray<birch::type::Real,2>& X, const birch::type::Real& k, const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const birch::type::LLT& V) {
  #line 972 "src/math/logpdf.birch"
  libbirch_function_("logpdf_matrix_student_t", "src/math/logpdf.birch", 972);
  #line 974 "src/math/logpdf.birch"
  libbirch_line_(974);
  #line 974 "src/math/logpdf.birch"
  auto n = birch::rows(M);
  #line 975 "src/math/logpdf.birch"
  libbirch_line_(975);
  #line 975 "src/math/logpdf.birch"
  auto p = birch::columns(M);
  #line 976 "src/math/logpdf.birch"
  libbirch_line_(976);
  #line 976 "src/math/logpdf.birch"
  auto a = 0.5 * (k + p + n - 1.0);
  #line 977 "src/math/logpdf.birch"
  libbirch_line_(977);
  #line 977 "src/math/logpdf.birch"
  auto b = 0.5 * (k + n - 1.0);
  #line 978 "src/math/logpdf.birch"
  libbirch_line_(978);
  #line 978 "src/math/logpdf.birch"
  auto Z = X - M;
  #line 980 "src/math/logpdf.birch"
  libbirch_line_(980);
  #line 980 "src/math/logpdf.birch"
  return birch::lgamma(a, n) - 0.5 * p * n * birch::log(birch::π()) - birch::lgamma(b, n) - 0.5 * p * birch::ldet(U) - 0.5 * n * birch::ldet(V) - a * birch::ldet(birch::identity(n) + birch::solve(U, Z) * birch::solve(V, birch::transpose(Z)));
}

#line 993 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_independent_uniform(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& l, const libbirch::DefaultArray<birch::type::Real,1>& u) {
  #line 993 "src/math/logpdf.birch"
  libbirch_function_("logpdf_independent_uniform", "src/math/logpdf.birch", 993);
  #line 994 "src/math/logpdf.birch"
  libbirch_line_(994);
  #line 994 "src/math/logpdf.birch"
  libbirch_assert_(birch::length(x) > birch::type::Integer(0));
  #line 995 "src/math/logpdf.birch"
  libbirch_line_(995);
  #line 995 "src/math/logpdf.birch"
  libbirch_assert_(birch::length(l) == birch::length(x));
  #line 996 "src/math/logpdf.birch"
  libbirch_line_(996);
  #line 996 "src/math/logpdf.birch"
  libbirch_assert_(birch::length(u) == birch::length(x));
  #line 998 "src/math/logpdf.birch"
  libbirch_line_(998);
  #line 998 "src/math/logpdf.birch"
  birch::type::Integer D = birch::length(l);
  #line 999 "src/math/logpdf.birch"
  libbirch_line_(999);
  #line 999 "src/math/logpdf.birch"
  birch::type::Real w = 0.0;
  #line 1000 "src/math/logpdf.birch"
  libbirch_line_(1000);
  #line 1000 "src/math/logpdf.birch"
  for (auto d = birch::type::Integer(1); d <= D; ++d) {
    #line 1001 "src/math/logpdf.birch"
    libbirch_line_(1001);
    #line 1001 "src/math/logpdf.birch"
    w = w + birch::logpdf_uniform(x(d), l(d), u(d));
  }
  #line 1003 "src/math/logpdf.birch"
  libbirch_line_(1003);
  #line 1003 "src/math/logpdf.birch"
  return w;
}

#line 1015 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_independent_uniform_int(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::DefaultArray<birch::type::Integer,1>& l, const libbirch::DefaultArray<birch::type::Integer,1>& u) {
  #line 1015 "src/math/logpdf.birch"
  libbirch_function_("logpdf_independent_uniform_int", "src/math/logpdf.birch", 1015);
  #line 1016 "src/math/logpdf.birch"
  libbirch_line_(1016);
  #line 1016 "src/math/logpdf.birch"
  libbirch_assert_(birch::length(x) > birch::type::Integer(0));
  #line 1017 "src/math/logpdf.birch"
  libbirch_line_(1017);
  #line 1017 "src/math/logpdf.birch"
  libbirch_assert_(birch::length(l) == birch::length(x));
  #line 1018 "src/math/logpdf.birch"
  libbirch_line_(1018);
  #line 1018 "src/math/logpdf.birch"
  libbirch_assert_(birch::length(u) == birch::length(x));
  #line 1020 "src/math/logpdf.birch"
  libbirch_line_(1020);
  #line 1020 "src/math/logpdf.birch"
  birch::type::Integer D = birch::length(x);
  #line 1021 "src/math/logpdf.birch"
  libbirch_line_(1021);
  #line 1021 "src/math/logpdf.birch"
  birch::type::Real w = 0.0;
  #line 1022 "src/math/logpdf.birch"
  libbirch_line_(1022);
  #line 1022 "src/math/logpdf.birch"
  for (auto d = birch::type::Integer(1); d <= D; ++d) {
    #line 1023 "src/math/logpdf.birch"
    libbirch_line_(1023);
    #line 1023 "src/math/logpdf.birch"
    w = w + birch::logpdf_uniform_int(x(d), l(d), u(d));
  }
  #line 1025 "src/math/logpdf.birch"
  libbirch_line_(1025);
  #line 1025 "src/math/logpdf.birch"
  return w;
}

#line 9 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_bernoulli(const libbirch::Shared<birch::type::Expression<birch::type::Boolean>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& ρ) {
  #line 9 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_bernoulli", "src/math/logpdf_lazy.birch", 9);
  #line 10 "src/math/logpdf_lazy.birch"
  libbirch_line_(10);
  #line 10 "src/math/logpdf_lazy.birch"
  return birch::Real(x) * birch::log(ρ) + (1.0 - birch::Real(x)) * birch::log1p(-(ρ));
}

#line 22 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_binomial(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& n, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& ρ) {
  #line 22 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_binomial", "src/math/logpdf_lazy.birch", 22);
  #line 23 "src/math/logpdf_lazy.birch"
  libbirch_line_(23);
  #line 23 "src/math/logpdf_lazy.birch"
  return birch::Real(x) * birch::log(ρ) + birch::Real(n - x) * birch::log1p(-(ρ)) + birch::lchoose(n, x);
}

#line 35 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_negative_binomial(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& k, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& ρ) {
  #line 35 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_negative_binomial", "src/math/logpdf_lazy.birch", 35);
  #line 36 "src/math/logpdf_lazy.birch"
  libbirch_line_(36);
  #line 36 "src/math/logpdf_lazy.birch"
  return birch::Real(k) * birch::log(ρ) + birch::Real(x) * birch::log1p(-(ρ)) + birch::lchoose(x + k - birch::type::Integer(1), x);
}

#line 47 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_poisson(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& λ) {
  #line 47 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_poisson", "src/math/logpdf_lazy.birch", 47);
  #line 48 "src/math/logpdf_lazy.birch"
  libbirch_line_(48);
  #line 48 "src/math/logpdf_lazy.birch"
  return birch::Real(x) * birch::log(λ) - λ - birch::lgamma(birch::Real(x + birch::type::Integer(1)));
}

#line 122 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_exponential(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& λ) {
  #line 122 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_exponential", "src/math/logpdf_lazy.birch", 122);
  #line 123 "src/math/logpdf_lazy.birch"
  libbirch_line_(123);
  #line 123 "src/math/logpdf_lazy.birch"
  return birch::if_then_else(x < 0.0, -(birch::inf()), birch::log(λ) - λ * x);
}

#line 135 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_weibull(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& λ) {
  #line 135 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_weibull", "src/math/logpdf_lazy.birch", 135);
  #line 136 "src/math/logpdf_lazy.birch"
  libbirch_line_(136);
  #line 136 "src/math/logpdf_lazy.birch"
  return birch::if_then_else(x < 0.0, -(birch::inf()), birch::log(k) + (k - 1.0) * birch::log(x) - k * birch::log(λ) - birch::pow(x / λ, k));
}

#line 149 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_gaussian(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& μ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& σ2) {
  #line 149 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_gaussian", "src/math/logpdf_lazy.birch", 149);
  #line 150 "src/math/logpdf_lazy.birch"
  libbirch_line_(150);
  #line 150 "src/math/logpdf_lazy.birch"
  return -(0.5) * (birch::pow(x - μ, 2.0) / σ2 + birch::log(2.0 * birch::π() * σ2));
}

#line 161 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_student_t(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k) {
  #line 161 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_student_t", "src/math/logpdf_lazy.birch", 161);
  #line 162 "src/math/logpdf_lazy.birch"
  libbirch_line_(162);
  #line 162 "src/math/logpdf_lazy.birch"
  auto a = 0.5 * (k + 1.0);
  #line 163 "src/math/logpdf_lazy.birch"
  libbirch_line_(163);
  #line 163 "src/math/logpdf_lazy.birch"
  auto b = 0.5 * k;
  #line 164 "src/math/logpdf_lazy.birch"
  libbirch_line_(164);
  #line 164 "src/math/logpdf_lazy.birch"
  return birch::lgamma(a) - birch::lgamma(b) - 0.5 * birch::log(birch::π() * k) - a * birch::log1p(x * x / k);
}

#line 177 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_student_t(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& μ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& v) {
  #line 177 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_student_t", "src/math/logpdf_lazy.birch", 177);
  #line 178 "src/math/logpdf_lazy.birch"
  libbirch_line_(178);
  #line 178 "src/math/logpdf_lazy.birch"
  auto a = 0.5 * (k + 1.0);
  #line 179 "src/math/logpdf_lazy.birch"
  libbirch_line_(179);
  #line 179 "src/math/logpdf_lazy.birch"
  auto b = 0.5 * k;
  #line 180 "src/math/logpdf_lazy.birch"
  libbirch_line_(180);
  #line 180 "src/math/logpdf_lazy.birch"
  auto z = x - μ;
  #line 181 "src/math/logpdf_lazy.birch"
  libbirch_line_(181);
  #line 181 "src/math/logpdf_lazy.birch"
  return birch::lgamma(a) - birch::lgamma(b) - 0.5 * birch::log(birch::π() * v) - a * birch::log1p(z * z / v);
}

#line 193 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_beta(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& β) {
  #line 193 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_beta", "src/math/logpdf_lazy.birch", 193);
  #line 194 "src/math/logpdf_lazy.birch"
  libbirch_line_(194);
  #line 194 "src/math/logpdf_lazy.birch"
  return (α - 1.0) * birch::log(x) + (β - 1.0) * birch::log1p(-(x)) - birch::lbeta(α, β);
}

#line 205 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_chi_squared(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& ν) {
  #line 205 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_chi_squared", "src/math/logpdf_lazy.birch", 205);
  #line 206 "src/math/logpdf_lazy.birch"
  libbirch_line_(206);
  #line 206 "src/math/logpdf_lazy.birch"
  auto k = 0.5 * ν;
  #line 207 "src/math/logpdf_lazy.birch"
  libbirch_line_(207);
  #line 207 "src/math/logpdf_lazy.birch"
  return (k - 1.0) * birch::log(x) - 0.5 * x - birch::lgamma(k) - k * birch::log(2.0);
}

#line 219 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_gamma(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& θ) {
  #line 219 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_gamma", "src/math/logpdf_lazy.birch", 219);
  #line 220 "src/math/logpdf_lazy.birch"
  libbirch_line_(220);
  #line 220 "src/math/logpdf_lazy.birch"
  return birch::if_then_else(x < 0.0, -(birch::inf()), (k - 1.0) * birch::log(x) - x / θ - birch::lgamma(k) - k * birch::log(θ));
}

#line 233 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_wishart(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& X, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Ψ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& ν) {
  #line 233 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_wishart", "src/math/logpdf_lazy.birch", 233);
  #line 234 "src/math/logpdf_lazy.birch"
  libbirch_line_(234);
  #line 234 "src/math/logpdf_lazy.birch"
  auto p = birch::columns(Ψ);
  #line 235 "src/math/logpdf_lazy.birch"
  libbirch_line_(235);
  #line 235 "src/math/logpdf_lazy.birch"
  return 0.5 * (ν - p - 1.0) * birch::ldet(X) - 0.5 * birch::trace(birch::solve(Ψ, birch::canonical(X))) - 0.5 * ν * (p * birch::log(2.0) + birch::ldet(Ψ)) - birch::lgamma(0.5 * ν, p);
}

#line 248 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_inverse_gamma(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& β) {
  #line 248 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_inverse_gamma", "src/math/logpdf_lazy.birch", 248);
  #line 249 "src/math/logpdf_lazy.birch"
  libbirch_line_(249);
  #line 249 "src/math/logpdf_lazy.birch"
  return birch::if_then_else(x < 0.0, -(birch::inf()), α * birch::log(β) - (α + 1.0) * birch::log(x) - β / x - birch::lgamma(α));
}

#line 262 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_inverse_wishart(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& X, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Ψ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& ν) {
  #line 262 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_inverse_wishart", "src/math/logpdf_lazy.birch", 262);
  #line 263 "src/math/logpdf_lazy.birch"
  libbirch_line_(263);
  #line 263 "src/math/logpdf_lazy.birch"
  auto p = birch::rows(Ψ);
  #line 264 "src/math/logpdf_lazy.birch"
  libbirch_line_(264);
  #line 264 "src/math/logpdf_lazy.birch"
  return -(0.5) * (ν + p - 1.0) * birch::ldet(X) - 0.5 * birch::trace(birch::solve(X, birch::canonical(Ψ))) - 0.5 * ν * (p * birch::log(2.0) - birch::ldet(Ψ)) - birch::lgamma(0.5 * ν, p);
}

#line 278 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_inverse_gamma_gamma(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& β) {
  #line 278 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_inverse_gamma_gamma", "src/math/logpdf_lazy.birch", 278);
  #line 279 "src/math/logpdf_lazy.birch"
  libbirch_line_(279);
  #line 279 "src/math/logpdf_lazy.birch"
  return (k - birch::type::Integer(1)) * birch::log(x) + α * birch::log(β) - (α + k) * birch::log(β + x) - birch::lbeta(α, k);
}

#line 293 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_normal_inverse_gamma(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& μ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& a2, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& β) {
  #line 293 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_normal_inverse_gamma", "src/math/logpdf_lazy.birch", 293);
  #line 295 "src/math/logpdf_lazy.birch"
  libbirch_line_(295);
  #line 295 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_student_t(x, 2.0 * α, μ, a2 * 2.0 * β);
}

#line 307 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_beta_bernoulli(const libbirch::Shared<birch::type::Expression<birch::type::Boolean>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& β) {
  #line 307 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_beta_bernoulli", "src/math/logpdf_lazy.birch", 307);
  #line 308 "src/math/logpdf_lazy.birch"
  libbirch_line_(308);
  #line 308 "src/math/logpdf_lazy.birch"
  return birch::Real(x) * birch::log(α) + (1.0 - birch::Real(x)) * birch::log(β) - birch::log(α + β);
}

#line 321 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_beta_binomial(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& n, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& β) {
  #line 321 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_beta_binomial", "src/math/logpdf_lazy.birch", 321);
  #line 322 "src/math/logpdf_lazy.birch"
  libbirch_line_(322);
  #line 322 "src/math/logpdf_lazy.birch"
  return birch::lbeta(birch::Real(x) + α, birch::Real(n - x) + β) - birch::lbeta(α, β) + birch::lchoose(n, x);
}

#line 335 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_beta_negative_binomial(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& k, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& β) {
  #line 335 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_beta_negative_binomial", "src/math/logpdf_lazy.birch", 335);
  #line 336 "src/math/logpdf_lazy.birch"
  libbirch_line_(336);
  #line 336 "src/math/logpdf_lazy.birch"
  return birch::lbeta(α + birch::Real(k), β + birch::Real(x)) - birch::lbeta(α, β) + birch::lchoose(x + k - birch::type::Integer(1), x);
}

#line 348 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_gamma_poisson(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& θ) {
  #line 348 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_gamma_poisson", "src/math/logpdf_lazy.birch", 348);
  #line 349 "src/math/logpdf_lazy.birch"
  libbirch_line_(349);
  #line 349 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_negative_binomial(x, birch::Integer(k), 1.0 / (θ + 1.0));
}

#line 361 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_lomax(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& λ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α) {
  #line 361 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_lomax", "src/math/logpdf_lazy.birch", 361);
  #line 362 "src/math/logpdf_lazy.birch"
  libbirch_line_(362);
  #line 362 "src/math/logpdf_lazy.birch"
  return birch::if_then_else(x < 0.0, -(birch::inf()), birch::log(α) - birch::log(λ) - (α + 1.0) * birch::log1p(x / λ));
}

#line 416 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_normal_inverse_gamma_gaussian(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& μ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& a2, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& β) {
  #line 416 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_normal_inverse_gamma_gaussian", "src/math/logpdf_lazy.birch", 416);
  #line 418 "src/math/logpdf_lazy.birch"
  libbirch_line_(418);
  #line 418 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_student_t(x, 2.0 * α, μ, 2.0 * β * (1.0 + a2));
}

#line 435 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_linear_normal_inverse_gamma_gaussian(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& a, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& μ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& a2, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& c, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& β) {
  #line 435 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_linear_normal_inverse_gamma_gaussian", "src/math/logpdf_lazy.birch", 435);
  #line 437 "src/math/logpdf_lazy.birch"
  libbirch_line_(437);
  #line 437 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_student_t(x, 2.0 * α, a * μ + c, 2.0 * β * (1.0 + a * a * a2));
}

#line 449 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_multivariate_gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& μ, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Σ) {
  #line 449 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_multivariate_gaussian", "src/math/logpdf_lazy.birch", 449);
  #line 450 "src/math/logpdf_lazy.birch"
  libbirch_line_(450);
  #line 450 "src/math/logpdf_lazy.birch"
  auto n = birch::length(μ);
  #line 451 "src/math/logpdf_lazy.birch"
  libbirch_line_(451);
  #line 451 "src/math/logpdf_lazy.birch"
  return -(0.5) * (birch::dot(x - μ, birch::solve(Σ, x - μ)) + n * birch::log(2.0 * birch::π()) + birch::ldet(Σ));
}

#line 463 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_multivariate_gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& μ, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& σ2) {
  #line 463 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_multivariate_gaussian", "src/math/logpdf_lazy.birch", 463);
  #line 465 "src/math/logpdf_lazy.birch"
  libbirch_line_(465);
  #line 465 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_multivariate_gaussian(x, μ, birch::llt(birch::diagonal(σ2)));
}

#line 478 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_multivariate_gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& μ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& σ2) {
  #line 478 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_multivariate_gaussian", "src/math/logpdf_lazy.birch", 478);
  #line 479 "src/math/logpdf_lazy.birch"
  libbirch_line_(479);
  #line 479 "src/math/logpdf_lazy.birch"
  auto n = μ->length();
  #line 480 "src/math/logpdf_lazy.birch"
  libbirch_line_(480);
  #line 480 "src/math/logpdf_lazy.birch"
  return -(0.5) * (birch::dot(x - μ) / σ2 + n * birch::log(2.0 * birch::π() * σ2));
}

#line 494 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_multivariate_normal_inverse_gamma(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& ν, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Λ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& β) {
  #line 494 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_multivariate_normal_inverse_gamma", "src/math/logpdf_lazy.birch", 494);
  #line 496 "src/math/logpdf_lazy.birch"
  libbirch_line_(496);
  #line 496 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_multivariate_student_t(x, 2.0 * α, birch::solve(Λ, ν), birch::inv(Λ), 2.0 * β);
}

#line 511 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_multivariate_normal_inverse_gamma_multivariate_gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& ν, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Λ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& γ) {
  #line 511 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/math/logpdf_lazy.birch", 511);
  #line 513 "src/math/logpdf_lazy.birch"
  libbirch_line_(513);
  #line 513 "src/math/logpdf_lazy.birch"
  auto n = birch::length(ν);
  #line 514 "src/math/logpdf_lazy.birch"
  libbirch_line_(514);
  #line 514 "src/math/logpdf_lazy.birch"
  auto μ = birch::solve(Λ, ν);
  #line 515 "src/math/logpdf_lazy.birch"
  libbirch_line_(515);
  #line 515 "src/math/logpdf_lazy.birch"
  auto β = γ - 0.5 * birch::dot(μ, ν);
  #line 516 "src/math/logpdf_lazy.birch"
  libbirch_line_(516);
  #line 516 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_multivariate_student_t(x, 2.0 * α, μ, birch::llt(birch::identity(n) + birch::canonical(birch::inv(Λ))), 2.0 * β);
}

#line 534 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& A, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& ν, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Λ, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& c, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& γ) {
  #line 534 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_linear_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/math/logpdf_lazy.birch", 534);
  #line 537 "src/math/logpdf_lazy.birch"
  libbirch_line_(537);
  #line 537 "src/math/logpdf_lazy.birch"
  auto n = birch::rows(A);
  #line 538 "src/math/logpdf_lazy.birch"
  libbirch_line_(538);
  #line 538 "src/math/logpdf_lazy.birch"
  auto μ = birch::solve(Λ, ν);
  #line 539 "src/math/logpdf_lazy.birch"
  libbirch_line_(539);
  #line 539 "src/math/logpdf_lazy.birch"
  auto β = γ - 0.5 * birch::dot(μ, ν);
  #line 540 "src/math/logpdf_lazy.birch"
  libbirch_line_(540);
  #line 540 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_multivariate_student_t(x, 2.0 * α, A * μ + c, birch::llt(birch::identity(n) + A * birch::solve(Λ, birch::transpose(A))), 2.0 * β);
}

#line 558 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_linear_multivariate_normal_inverse_gamma_gaussian(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& a, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& ν, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Λ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& c, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& γ) {
  #line 558 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_linear_multivariate_normal_inverse_gamma_gaussian", "src/math/logpdf_lazy.birch", 558);
  #line 560 "src/math/logpdf_lazy.birch"
  libbirch_line_(560);
  #line 560 "src/math/logpdf_lazy.birch"
  auto μ = birch::solve(Λ, ν);
  #line 561 "src/math/logpdf_lazy.birch"
  libbirch_line_(561);
  #line 561 "src/math/logpdf_lazy.birch"
  auto β = γ - 0.5 * birch::dot(μ, ν);
  #line 562 "src/math/logpdf_lazy.birch"
  libbirch_line_(562);
  #line 562 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_student_t(x, 2.0 * α, birch::dot(a, μ) + c, 2.0 * β * (1.0 + birch::dot(a, birch::solve(Λ, a))));
}

#line 576 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_matrix_gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& X, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& U, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& V) {
  #line 576 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_matrix_gaussian", "src/math/logpdf_lazy.birch", 576);
  #line 578 "src/math/logpdf_lazy.birch"
  libbirch_line_(578);
  #line 578 "src/math/logpdf_lazy.birch"
  auto n = birch::rows(M);
  #line 579 "src/math/logpdf_lazy.birch"
  libbirch_line_(579);
  #line 579 "src/math/logpdf_lazy.birch"
  auto p = birch::columns(M);
  #line 580 "src/math/logpdf_lazy.birch"
  libbirch_line_(580);
  #line 580 "src/math/logpdf_lazy.birch"
  return -(0.5) * (birch::trace(birch::solve(V, birch::transpose(X - M)) * birch::solve(U, X - M)) + n * p * birch::log(2.0 * birch::π()) + n * birch::ldet(V) + p * birch::ldet(U));
}

#line 594 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_matrix_gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& X, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& U, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& σ2) {
  #line 594 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_matrix_gaussian", "src/math/logpdf_lazy.birch", 594);
  #line 597 "src/math/logpdf_lazy.birch"
  libbirch_line_(597);
  #line 597 "src/math/logpdf_lazy.birch"
  auto n = birch::rows(M);
  #line 598 "src/math/logpdf_lazy.birch"
  libbirch_line_(598);
  #line 598 "src/math/logpdf_lazy.birch"
  auto p = birch::columns(M);
  #line 599 "src/math/logpdf_lazy.birch"
  libbirch_line_(599);
  #line 599 "src/math/logpdf_lazy.birch"
  return -(0.5) * (birch::trace(birch::solve(birch::diagonal(σ2), birch::transpose(X - M)) * birch::solve(U, X - M)) + n * p * birch::log(2.0 * birch::π()) + n * birch::ldet(birch::diagonal(σ2)) + p * birch::ldet(U));
}

#line 612 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_matrix_gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& X, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& V) {
  #line 612 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_matrix_gaussian", "src/math/logpdf_lazy.birch", 612);
  #line 613 "src/math/logpdf_lazy.birch"
  libbirch_line_(613);
  #line 613 "src/math/logpdf_lazy.birch"
  auto n = birch::rows(M);
  #line 614 "src/math/logpdf_lazy.birch"
  libbirch_line_(614);
  #line 614 "src/math/logpdf_lazy.birch"
  auto p = birch::columns(M);
  #line 615 "src/math/logpdf_lazy.birch"
  libbirch_line_(615);
  #line 615 "src/math/logpdf_lazy.birch"
  return -(0.5) * (birch::trace(birch::solve(V, birch::transpose(X - M)) * (X - M)) + n * p * birch::log(2.0 * birch::π()) + n * birch::ldet(V));
}

#line 628 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_matrix_gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& X, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& σ2) {
  #line 628 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_matrix_gaussian", "src/math/logpdf_lazy.birch", 628);
  #line 630 "src/math/logpdf_lazy.birch"
  libbirch_line_(630);
  #line 630 "src/math/logpdf_lazy.birch"
  auto n = birch::rows(M);
  #line 631 "src/math/logpdf_lazy.birch"
  libbirch_line_(631);
  #line 631 "src/math/logpdf_lazy.birch"
  auto p = birch::columns(M);
  #line 632 "src/math/logpdf_lazy.birch"
  libbirch_line_(632);
  #line 632 "src/math/logpdf_lazy.birch"
  return -(0.5) * (birch::trace(birch::solve(birch::diagonal(σ2), birch::transpose(X - M) * (X - M))) + n * p * birch::log(2.0 * birch::π()) + n * birch::ldet(birch::diagonal(σ2)));
}

#line 646 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_matrix_gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& X, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& σ2) {
  #line 646 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_matrix_gaussian", "src/math/logpdf_lazy.birch", 646);
  #line 648 "src/math/logpdf_lazy.birch"
  libbirch_line_(648);
  #line 648 "src/math/logpdf_lazy.birch"
  auto n = birch::rows(M);
  #line 649 "src/math/logpdf_lazy.birch"
  libbirch_line_(649);
  #line 649 "src/math/logpdf_lazy.birch"
  auto p = birch::columns(M);
  #line 650 "src/math/logpdf_lazy.birch"
  libbirch_line_(650);
  #line 650 "src/math/logpdf_lazy.birch"
  return -(0.5) * (birch::trace(birch::transpose(X - M) * (X - M) / σ2) + n * p * birch::log(2.0 * birch::π() * σ2));
}

#line 664 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_matrix_normal_inverse_wishart(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& X, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& N, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Λ, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Ψ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k) {
  #line 664 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_matrix_normal_inverse_wishart", "src/math/logpdf_lazy.birch", 664);
  #line 666 "src/math/logpdf_lazy.birch"
  libbirch_line_(666);
  #line 666 "src/math/logpdf_lazy.birch"
  auto p = birch::columns(N);
  #line 667 "src/math/logpdf_lazy.birch"
  libbirch_line_(667);
  #line 667 "src/math/logpdf_lazy.birch"
  auto M = birch::solve(Λ, N);
  #line 668 "src/math/logpdf_lazy.birch"
  libbirch_line_(668);
  #line 668 "src/math/logpdf_lazy.birch"
  auto Σ = birch::inv(Λ);
  #line 669 "src/math/logpdf_lazy.birch"
  libbirch_line_(669);
  #line 669 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_matrix_student_t(X, k - p + 1.0, M, Σ, Ψ);
}

#line 683 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_matrix_normal_inverse_wishart_matrix_gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& X, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& N, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Λ, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Ψ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k) {
  #line 683 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_matrix_normal_inverse_wishart_matrix_gaussian", "src/math/logpdf_lazy.birch", 683);
  #line 685 "src/math/logpdf_lazy.birch"
  libbirch_line_(685);
  #line 685 "src/math/logpdf_lazy.birch"
  auto n = birch::rows(N);
  #line 686 "src/math/logpdf_lazy.birch"
  libbirch_line_(686);
  #line 686 "src/math/logpdf_lazy.birch"
  auto p = birch::columns(N);
  #line 687 "src/math/logpdf_lazy.birch"
  libbirch_line_(687);
  #line 687 "src/math/logpdf_lazy.birch"
  auto M = birch::solve(Λ, N);
  #line 688 "src/math/logpdf_lazy.birch"
  libbirch_line_(688);
  #line 688 "src/math/logpdf_lazy.birch"
  auto Σ = birch::llt(birch::identity(n) + birch::canonical(birch::inv(Λ)));
  #line 689 "src/math/logpdf_lazy.birch"
  libbirch_line_(689);
  #line 689 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_matrix_student_t(X, k - p + 1.0, M, Σ, Ψ);
}

#line 706 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_linear_matrix_normal_inverse_wishart_matrix_gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& X, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& A, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& N, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Λ, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& C, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Ψ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k) {
  #line 706 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_linear_matrix_normal_inverse_wishart_matrix_gaussian", "src/math/logpdf_lazy.birch", 706);
  #line 709 "src/math/logpdf_lazy.birch"
  libbirch_line_(709);
  #line 709 "src/math/logpdf_lazy.birch"
  auto n = birch::rows(A);
  #line 710 "src/math/logpdf_lazy.birch"
  libbirch_line_(710);
  #line 710 "src/math/logpdf_lazy.birch"
  auto p = birch::columns(N);
  #line 711 "src/math/logpdf_lazy.birch"
  libbirch_line_(711);
  #line 711 "src/math/logpdf_lazy.birch"
  auto M = birch::solve(Λ, N);
  #line 712 "src/math/logpdf_lazy.birch"
  libbirch_line_(712);
  #line 712 "src/math/logpdf_lazy.birch"
  auto Σ = birch::llt(birch::identity(n) + A * birch::solve(Λ, birch::transpose(A)));
  #line 713 "src/math/logpdf_lazy.birch"
  libbirch_line_(713);
  #line 713 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_matrix_student_t(X, k - p + 1.0, A * M + C, Σ, Ψ);
}

#line 730 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_linear_matrix_normal_inverse_wishart_multivariate_gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& a, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& N, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Λ, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& c, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Ψ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k) {
  #line 730 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_linear_matrix_normal_inverse_wishart_multivariate_gaussian", "src/math/logpdf_lazy.birch", 730);
  #line 734 "src/math/logpdf_lazy.birch"
  libbirch_line_(734);
  #line 734 "src/math/logpdf_lazy.birch"
  auto p = birch::columns(N);
  #line 735 "src/math/logpdf_lazy.birch"
  libbirch_line_(735);
  #line 735 "src/math/logpdf_lazy.birch"
  auto M = birch::solve(Λ, N);
  #line 736 "src/math/logpdf_lazy.birch"
  libbirch_line_(736);
  #line 736 "src/math/logpdf_lazy.birch"
  auto σ2 = 1.0 + birch::dot(a, birch::solve(Λ, a));
  #line 737 "src/math/logpdf_lazy.birch"
  libbirch_line_(737);
  #line 737 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_multivariate_student_t(x, k - p + 1.0, birch::dot(a, M) + c, σ2, Ψ);
}

#line 752 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_multivariate_student_t(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& μ, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& U, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& v) {
  #line 752 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_multivariate_student_t", "src/math/logpdf_lazy.birch", 752);
  #line 755 "src/math/logpdf_lazy.birch"
  libbirch_line_(755);
  #line 755 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_multivariate_student_t(x, k, μ, v, U);
}

#line 770 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_multivariate_student_t(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& μ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& u, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& V) {
  #line 770 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_multivariate_student_t", "src/math/logpdf_lazy.birch", 770);
  #line 773 "src/math/logpdf_lazy.birch"
  libbirch_line_(773);
  #line 773 "src/math/logpdf_lazy.birch"
  auto p = birch::length(μ);
  #line 774 "src/math/logpdf_lazy.birch"
  libbirch_line_(774);
  #line 774 "src/math/logpdf_lazy.birch"
  auto a = 0.5 * (k + p);
  #line 775 "src/math/logpdf_lazy.birch"
  libbirch_line_(775);
  #line 775 "src/math/logpdf_lazy.birch"
  auto b = 0.5 * k;
  #line 776 "src/math/logpdf_lazy.birch"
  libbirch_line_(776);
  #line 776 "src/math/logpdf_lazy.birch"
  auto z = x - μ;
  #line 777 "src/math/logpdf_lazy.birch"
  libbirch_line_(777);
  #line 777 "src/math/logpdf_lazy.birch"
  return birch::lgamma(a) - 0.5 * p * birch::log(birch::π()) - birch::lgamma(b) - 0.5 * p * birch::log(u) - 0.5 * birch::ldet(V) - a * birch::log1p(birch::dot(z, birch::solve(V, z)) / u);
}

#line 793 "src/math/logpdf_lazy.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::logpdf_lazy_matrix_student_t(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& X, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& U, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& V) {
  #line 793 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_matrix_student_t", "src/math/logpdf_lazy.birch", 793);
  #line 795 "src/math/logpdf_lazy.birch"
  libbirch_line_(795);
  #line 795 "src/math/logpdf_lazy.birch"
  auto n = birch::rows(M);
  #line 796 "src/math/logpdf_lazy.birch"
  libbirch_line_(796);
  #line 796 "src/math/logpdf_lazy.birch"
  auto p = birch::columns(M);
  #line 797 "src/math/logpdf_lazy.birch"
  libbirch_line_(797);
  #line 797 "src/math/logpdf_lazy.birch"
  auto a = 0.5 * (k + p + n - 1.0);
  #line 798 "src/math/logpdf_lazy.birch"
  libbirch_line_(798);
  #line 798 "src/math/logpdf_lazy.birch"
  auto b = 0.5 * (k + n - 1.0);
  #line 799 "src/math/logpdf_lazy.birch"
  libbirch_line_(799);
  #line 799 "src/math/logpdf_lazy.birch"
  auto Z = X - M;
  #line 801 "src/math/logpdf_lazy.birch"
  libbirch_line_(801);
  #line 801 "src/math/logpdf_lazy.birch"
  return birch::lgamma(a, n) - 0.5 * p * n * birch::log(birch::π()) - birch::lgamma(b, n) - 0.5 * p * birch::ldet(U) - 0.5 * n * birch::ldet(V) - a * birch::ldet(birch::identity(n) + birch::solve(U, Z) * birch::solve(V, birch::transpose(Z)));
}

#line 144 "src/math/matrix.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::diagonal(const birch::type::Real& x, const birch::type::Integer& length) {
  #line 144 "src/math/matrix.birch"
  libbirch_function_("diagonal", "src/math/matrix.birch", 144);
  #line 145 "src/math/matrix.birch"
  libbirch_line_(145);
  #line 145 "src/math/matrix.birch"
  return birch::matrix(std::function<birch::type::Real(birch::type::Integer,birch::type::Integer)>([=](const birch::type::Integer& i, const birch::type::Integer& j) {
    #line 146 "src/math/matrix.birch"
    libbirch_line_(146);
    #line 146 "src/math/matrix.birch"
    if (i == j) {
      #line 147 "src/math/matrix.birch"
      libbirch_line_(147);
      #line 147 "src/math/matrix.birch"
      return x;
    } else {
      #line 149 "src/math/matrix.birch"
      libbirch_line_(149);
      #line 149 "src/math/matrix.birch"
      return 0.0;
    }
  }), length, length);
}

#line 160 "src/math/matrix.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::diagonal(const birch::type::Integer& x, const birch::type::Integer& length) {
  #line 160 "src/math/matrix.birch"
  libbirch_function_("diagonal", "src/math/matrix.birch", 160);
  #line 161 "src/math/matrix.birch"
  libbirch_line_(161);
  #line 161 "src/math/matrix.birch"
  return birch::matrix(std::function<birch::type::Integer(birch::type::Integer,birch::type::Integer)>([=](const birch::type::Integer& i, const birch::type::Integer& j) {
    #line 162 "src/math/matrix.birch"
    libbirch_line_(162);
    #line 162 "src/math/matrix.birch"
    if (i == j) {
      #line 163 "src/math/matrix.birch"
      libbirch_line_(163);
      #line 163 "src/math/matrix.birch"
      return x;
    } else {
      #line 165 "src/math/matrix.birch"
      libbirch_line_(165);
      #line 165 "src/math/matrix.birch"
      return birch::type::Integer(0);
    }
  }), length, length);
}

#line 176 "src/math/matrix.birch"
libbirch::DefaultArray<birch::type::Boolean,2> birch::diagonal(const birch::type::Boolean& x, const birch::type::Integer& length) {
  #line 176 "src/math/matrix.birch"
  libbirch_function_("diagonal", "src/math/matrix.birch", 176);
  #line 177 "src/math/matrix.birch"
  libbirch_line_(177);
  #line 177 "src/math/matrix.birch"
  return birch::matrix(std::function<birch::type::Boolean(birch::type::Integer,birch::type::Integer)>([=](const birch::type::Integer& i, const birch::type::Integer& j) {
    #line 178 "src/math/matrix.birch"
    libbirch_line_(178);
    #line 178 "src/math/matrix.birch"
    if (i == j) {
      #line 179 "src/math/matrix.birch"
      libbirch_line_(179);
      #line 179 "src/math/matrix.birch"
      return x;
    } else {
      #line 181 "src/math/matrix.birch"
      libbirch_line_(181);
      #line 181 "src/math/matrix.birch"
      return false;
    }
  }), length, length);
}

#line 192 "src/math/matrix.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::identity(const birch::type::Integer& length) {
  #line 192 "src/math/matrix.birch"
  libbirch_function_("identity", "src/math/matrix.birch", 192);
  #line 193 "src/math/matrix.birch"
  libbirch_line_(193);
  #line 193 "src/math/matrix.birch"
  return birch::diagonal(1.0, length);
}

#line 263 "src/math/matrix.birch"
birch::type::String birch::String(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 263 "src/math/matrix.birch"
  libbirch_function_("String", "src/math/matrix.birch", 263);
  #line 264 "src/math/matrix.birch"
  libbirch_line_(264);
  #line 264 "src/math/matrix.birch"
  birch::type::String result = libbirch::make<birch::type::String>();
  #line 265 "src/math/matrix.birch"

  std::stringstream buf;
    #line 268 "src/math/matrix.birch"
  libbirch_line_(268);
  #line 268 "src/math/matrix.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(X); ++i) {
    #line 269 "src/math/matrix.birch"

    if (i > 1) {
      buf << '\n';
    }
        #line 274 "src/math/matrix.birch"
    libbirch_line_(274);
    #line 274 "src/math/matrix.birch"
    for (auto j = birch::type::Integer(1); j <= birch::columns(X); ++j) {
      #line 275 "src/math/matrix.birch"
      libbirch_line_(275);
      #line 275 "src/math/matrix.birch"
      auto value = X(i, j);
      #line 276 "src/math/matrix.birch"

      if (j > 1) {
        buf << ' ';
      }
      if (value == floor(value)) {
        buf << (int64_t)value << ".0";
      } else {
        buf << std::scientific << std::setprecision(14) << value;
      }
          }
  }
  #line 288 "src/math/matrix.birch"

  result = buf.str();
    #line 291 "src/math/matrix.birch"
  libbirch_line_(291);
  #line 291 "src/math/matrix.birch"
  return result;
}

#line 297 "src/math/matrix.birch"
birch::type::String birch::String(const libbirch::DefaultArray<birch::type::Integer,2>& X) {
  #line 297 "src/math/matrix.birch"
  libbirch_function_("String", "src/math/matrix.birch", 297);
  #line 298 "src/math/matrix.birch"
  libbirch_line_(298);
  #line 298 "src/math/matrix.birch"
  birch::type::String result = libbirch::make<birch::type::String>();
  #line 299 "src/math/matrix.birch"

  std::stringstream buf;
    #line 302 "src/math/matrix.birch"
  libbirch_line_(302);
  #line 302 "src/math/matrix.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(X); ++i) {
    #line 303 "src/math/matrix.birch"

    if (i > 1) {
      buf << '\n';
    }
        #line 308 "src/math/matrix.birch"
    libbirch_line_(308);
    #line 308 "src/math/matrix.birch"
    for (auto j = birch::type::Integer(1); j <= birch::columns(X); ++j) {
      #line 309 "src/math/matrix.birch"
      libbirch_line_(309);
      #line 309 "src/math/matrix.birch"
      auto value = X(i, j);
      #line 310 "src/math/matrix.birch"

      if (j > 1) {
        buf << ' ';
      }
      buf << value;
          }
  }
  #line 318 "src/math/matrix.birch"

  result = buf.str();
    #line 321 "src/math/matrix.birch"
  libbirch_line_(321);
  #line 321 "src/math/matrix.birch"
  return result;
}

#line 327 "src/math/matrix.birch"
birch::type::String birch::String(const libbirch::DefaultArray<birch::type::Boolean,2>& X) {
  #line 327 "src/math/matrix.birch"
  libbirch_function_("String", "src/math/matrix.birch", 327);
  #line 328 "src/math/matrix.birch"
  libbirch_line_(328);
  #line 328 "src/math/matrix.birch"
  birch::type::String result = libbirch::make<birch::type::String>();
  #line 329 "src/math/matrix.birch"

  std::stringstream buf;
    #line 332 "src/math/matrix.birch"
  libbirch_line_(332);
  #line 332 "src/math/matrix.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(X); ++i) {
    #line 333 "src/math/matrix.birch"

    if (i > 1) {
      buf << '\n';
    }
        #line 338 "src/math/matrix.birch"
    libbirch_line_(338);
    #line 338 "src/math/matrix.birch"
    for (auto j = birch::type::Integer(1); j <= birch::columns(X); ++j) {
      #line 339 "src/math/matrix.birch"
      libbirch_line_(339);
      #line 339 "src/math/matrix.birch"
      auto value = X(i, j);
      #line 340 "src/math/matrix.birch"

      if (j > 1) {
        buf << ' ';
      }
      if (value) {
        buf << "true";
      } else {
        buf << "false";
      }
          }
  }
  #line 352 "src/math/matrix.birch"

  result = buf.str();
    #line 355 "src/math/matrix.birch"
  libbirch_line_(355);
  #line 355 "src/math/matrix.birch"
  return result;
}

#line 361 "src/math/matrix.birch"
birch::type::String birch::String(const birch::type::LLT& X) {
  #line 361 "src/math/matrix.birch"
  libbirch_function_("String", "src/math/matrix.birch", 361);
  #line 362 "src/math/matrix.birch"
  libbirch_line_(362);
  #line 362 "src/math/matrix.birch"
  return birch::String(birch::canonical(X));
}

#line 1 "src/math/quantile.birch"

#include <boost/math/distributions.hpp>
#line 14 "src/math/quantile.birch"
birch::type::Integer birch::quantile_binomial(const birch::type::Real& P, const birch::type::Integer& n, const birch::type::Real& ρ) {
  #line 14 "src/math/quantile.birch"
  libbirch_function_("quantile_binomial", "src/math/quantile.birch", 14);
  #line 15 "src/math/quantile.birch"
  libbirch_line_(15);
  #line 15 "src/math/quantile.birch"
  libbirch_assert_(birch::type::Integer(0) <= n);
  #line 16 "src/math/quantile.birch"
  libbirch_line_(16);
  #line 16 "src/math/quantile.birch"
  libbirch_assert_(0.0 <= ρ && ρ <= 1.0);
  #line 17 "src/math/quantile.birch"

  return boost::math::quantile(boost::math::binomial_distribution<>(n, ρ), P);
  }

#line 31 "src/math/quantile.birch"
birch::type::Integer birch::quantile_negative_binomial(const birch::type::Real& P, const birch::type::Integer& k, const birch::type::Real& ρ) {
  #line 31 "src/math/quantile.birch"
  libbirch_function_("quantile_negative_binomial", "src/math/quantile.birch", 31);
  #line 32 "src/math/quantile.birch"
  libbirch_line_(32);
  #line 32 "src/math/quantile.birch"
  libbirch_assert_(birch::type::Integer(0) < k);
  #line 33 "src/math/quantile.birch"
  libbirch_line_(33);
  #line 33 "src/math/quantile.birch"
  libbirch_assert_(0.0 <= ρ && ρ <= 1.0);
  #line 34 "src/math/quantile.birch"

  return boost::math::quantile(boost::math::negative_binomial_distribution<>(k, ρ), P);
  }

#line 47 "src/math/quantile.birch"
birch::type::Integer birch::quantile_poisson(const birch::type::Real& P, const birch::type::Real& λ) {
  #line 47 "src/math/quantile.birch"
  libbirch_function_("quantile_poisson", "src/math/quantile.birch", 47);
  #line 48 "src/math/quantile.birch"
  libbirch_line_(48);
  #line 48 "src/math/quantile.birch"
  libbirch_assert_(0.0 <= λ);
  #line 49 "src/math/quantile.birch"

  return boost::math::quantile(boost::math::poisson_distribution<>(λ), P);
  }

#line 63 "src/math/quantile.birch"
birch::type::Integer birch::quantile_uniform_int(const birch::type::Real& P, const birch::type::Integer& l, const birch::type::Integer& u) {
  #line 63 "src/math/quantile.birch"
  libbirch_function_("quantile_uniform_int", "src/math/quantile.birch", 63);
  #line 64 "src/math/quantile.birch"
  libbirch_line_(64);
  #line 64 "src/math/quantile.birch"
  libbirch_assert_(l <= u);
  #line 65 "src/math/quantile.birch"
  libbirch_line_(65);
  #line 65 "src/math/quantile.birch"
  return l + birch::Integer(P * (u - l));
}

#line 76 "src/math/quantile.birch"
birch::type::Integer birch::quantile_categorical(const birch::type::Real& P, const libbirch::DefaultArray<birch::type::Real,1>& ρ) {
  #line 76 "src/math/quantile.birch"
  libbirch_function_("quantile_categorical", "src/math/quantile.birch", 76);
  #line 77 "src/math/quantile.birch"
  libbirch_line_(77);
  #line 77 "src/math/quantile.birch"
  auto i = birch::type::Integer(1);
  #line 78 "src/math/quantile.birch"
  libbirch_line_(78);
  #line 78 "src/math/quantile.birch"
  auto R = ρ(birch::type::Integer(1));
  #line 79 "src/math/quantile.birch"
  libbirch_line_(79);
  #line 79 "src/math/quantile.birch"
  while (R < P && i < birch::length(ρ)) {
    #line 80 "src/math/quantile.birch"
    libbirch_line_(80);
    #line 80 "src/math/quantile.birch"
    i = i + birch::type::Integer(1);
    #line 81 "src/math/quantile.birch"
    libbirch_line_(81);
    #line 81 "src/math/quantile.birch"
    R = R + ρ(i);
  }
  #line 83 "src/math/quantile.birch"
  libbirch_line_(83);
  #line 83 "src/math/quantile.birch"
  return i;
}

#line 95 "src/math/quantile.birch"
birch::type::Real birch::quantile_uniform(const birch::type::Real& P, const birch::type::Real& l, const birch::type::Real& u) {
  #line 95 "src/math/quantile.birch"
  libbirch_function_("quantile_uniform", "src/math/quantile.birch", 95);
  #line 96 "src/math/quantile.birch"
  libbirch_line_(96);
  #line 96 "src/math/quantile.birch"
  libbirch_assert_(l <= u);
  #line 97 "src/math/quantile.birch"
  libbirch_line_(97);
  #line 97 "src/math/quantile.birch"
  return l + P * (u - l);
}

#line 108 "src/math/quantile.birch"
birch::type::Real birch::quantile_exponential(const birch::type::Real& P, const birch::type::Real& λ) {
  #line 108 "src/math/quantile.birch"
  libbirch_function_("quantile_exponential", "src/math/quantile.birch", 108);
  #line 109 "src/math/quantile.birch"
  libbirch_line_(109);
  #line 109 "src/math/quantile.birch"
  libbirch_assert_(0.0 < λ);
  #line 110 "src/math/quantile.birch"

  return boost::math::quantile(boost::math::exponential_distribution<>(λ), P);
  }

#line 124 "src/math/quantile.birch"
birch::type::Real birch::quantile_weibull(const birch::type::Real& P, const birch::type::Real& k, const birch::type::Real& λ) {
  #line 124 "src/math/quantile.birch"
  libbirch_function_("quantile_weibull", "src/math/quantile.birch", 124);
  #line 125 "src/math/quantile.birch"
  libbirch_line_(125);
  #line 125 "src/math/quantile.birch"
  libbirch_assert_(0.0 < k);
  #line 126 "src/math/quantile.birch"
  libbirch_line_(126);
  #line 126 "src/math/quantile.birch"
  libbirch_assert_(0.0 < λ);
  #line 127 "src/math/quantile.birch"

  return boost::math::quantile(boost::math::weibull_distribution<>(k, λ), P);
  }

#line 141 "src/math/quantile.birch"
birch::type::Real birch::quantile_gaussian(const birch::type::Real& P, const birch::type::Real& μ, const birch::type::Real& σ2) {
  #line 141 "src/math/quantile.birch"
  libbirch_function_("quantile_gaussian", "src/math/quantile.birch", 141);
  #line 142 "src/math/quantile.birch"
  libbirch_line_(142);
  #line 142 "src/math/quantile.birch"
  libbirch_assert_(0.0 < σ2);
  #line 143 "src/math/quantile.birch"

  return boost::math::quantile(boost::math::normal_distribution<>(μ, ::sqrt(σ2)), P);
  }

#line 156 "src/math/quantile.birch"
birch::type::Real birch::quantile_student_t(const birch::type::Real& P, const birch::type::Real& ν) {
  #line 156 "src/math/quantile.birch"
  libbirch_function_("quantile_student_t", "src/math/quantile.birch", 156);
  #line 157 "src/math/quantile.birch"
  libbirch_line_(157);
  #line 157 "src/math/quantile.birch"
  libbirch_assert_(0.0 < ν);
  #line 158 "src/math/quantile.birch"

  return boost::math::quantile(boost::math::students_t_distribution<>(ν), P);
  }

#line 173 "src/math/quantile.birch"
birch::type::Real birch::quantile_student_t(const birch::type::Real& P, const birch::type::Real& ν, const birch::type::Real& μ, const birch::type::Real& σ2) {
  #line 173 "src/math/quantile.birch"
  libbirch_function_("quantile_student_t", "src/math/quantile.birch", 173);
  #line 174 "src/math/quantile.birch"
  libbirch_line_(174);
  #line 174 "src/math/quantile.birch"
  libbirch_assert_(0.0 < σ2);
  #line 175 "src/math/quantile.birch"
  libbirch_line_(175);
  #line 175 "src/math/quantile.birch"
  return birch::quantile_student_t(P, ν) * birch::sqrt(σ2) + μ;
}

#line 187 "src/math/quantile.birch"
birch::type::Real birch::quantile_beta(const birch::type::Real& P, const birch::type::Real& α, const birch::type::Real& β) {
  #line 187 "src/math/quantile.birch"
  libbirch_function_("quantile_beta", "src/math/quantile.birch", 187);
  #line 188 "src/math/quantile.birch"
  libbirch_line_(188);
  #line 188 "src/math/quantile.birch"
  libbirch_assert_(0.0 < α);
  #line 189 "src/math/quantile.birch"
  libbirch_line_(189);
  #line 189 "src/math/quantile.birch"
  libbirch_assert_(0.0 < β);
  #line 190 "src/math/quantile.birch"

  return boost::math::quantile(boost::math::beta_distribution<>(α, β), P);
  }

#line 203 "src/math/quantile.birch"
birch::type::Real birch::quantile_chi_squared(const birch::type::Real& P, const birch::type::Real& ν) {
  #line 203 "src/math/quantile.birch"
  libbirch_function_("quantile_chi_squared", "src/math/quantile.birch", 203);
  #line 204 "src/math/quantile.birch"
  libbirch_line_(204);
  #line 204 "src/math/quantile.birch"
  libbirch_assert_(0.0 < ν);
  #line 205 "src/math/quantile.birch"

  return boost::math::quantile(boost::math::chi_squared_distribution<>(ν), P);
  }

#line 219 "src/math/quantile.birch"
birch::type::Real birch::quantile_gamma(const birch::type::Real& P, const birch::type::Real& k, const birch::type::Real& θ) {
  #line 219 "src/math/quantile.birch"
  libbirch_function_("quantile_gamma", "src/math/quantile.birch", 219);
  #line 220 "src/math/quantile.birch"
  libbirch_line_(220);
  #line 220 "src/math/quantile.birch"
  libbirch_assert_(0.0 < k);
  #line 221 "src/math/quantile.birch"
  libbirch_line_(221);
  #line 221 "src/math/quantile.birch"
  libbirch_assert_(0.0 < θ);
  #line 222 "src/math/quantile.birch"

  return boost::math::quantile(boost::math::gamma_distribution<>(k, θ), P);
  }

#line 236 "src/math/quantile.birch"
birch::type::Real birch::quantile_inverse_gamma(const birch::type::Real& P, const birch::type::Real& α, const birch::type::Real& β) {
  #line 236 "src/math/quantile.birch"
  libbirch_function_("quantile_inverse_gamma", "src/math/quantile.birch", 236);
  #line 237 "src/math/quantile.birch"
  libbirch_line_(237);
  #line 237 "src/math/quantile.birch"
  libbirch_assert_(0.0 < α);
  #line 238 "src/math/quantile.birch"
  libbirch_line_(238);
  #line 238 "src/math/quantile.birch"
  libbirch_assert_(0.0 < β);
  #line 239 "src/math/quantile.birch"
  libbirch_line_(239);
  #line 239 "src/math/quantile.birch"
  if (P == 0.0) {
    #line 240 "src/math/quantile.birch"
    libbirch_line_(240);
    #line 240 "src/math/quantile.birch"
    return 0.0;
  } else {
    #line 242 "src/math/quantile.birch"

    return boost::math::quantile(boost::math::inverse_gamma_distribution<>(α, β), P);
      }
}

#line 259 "src/math/quantile.birch"
birch::type::Real birch::quantile_normal_inverse_gamma(const birch::type::Real& P, const birch::type::Real& μ, const birch::type::Real& a2, const birch::type::Real& α, const birch::type::Real& β) {
  #line 259 "src/math/quantile.birch"
  libbirch_function_("quantile_normal_inverse_gamma", "src/math/quantile.birch", 259);
  #line 261 "src/math/quantile.birch"
  libbirch_line_(261);
  #line 261 "src/math/quantile.birch"
  return birch::quantile_student_t(P, 2.0 * α, μ, a2 * β / α);
}

#line 273 "src/math/quantile.birch"
birch::type::Integer birch::quantile_gamma_poisson(const birch::type::Real& P, const birch::type::Real& k, const birch::type::Real& θ) {
  #line 273 "src/math/quantile.birch"
  libbirch_function_("quantile_gamma_poisson", "src/math/quantile.birch", 273);
  #line 274 "src/math/quantile.birch"
  libbirch_line_(274);
  #line 274 "src/math/quantile.birch"
  libbirch_assert_(0.0 < k);
  #line 275 "src/math/quantile.birch"
  libbirch_line_(275);
  #line 275 "src/math/quantile.birch"
  libbirch_assert_(0.0 < θ);
  #line 276 "src/math/quantile.birch"
  libbirch_line_(276);
  #line 276 "src/math/quantile.birch"
  libbirch_assert_(k == birch::floor(k));
  #line 277 "src/math/quantile.birch"
  libbirch_line_(277);
  #line 277 "src/math/quantile.birch"
  return birch::quantile_negative_binomial(P, birch::Integer(k), 1.0 / (θ + 1.0));
}

#line 289 "src/math/quantile.birch"
birch::type::Real birch::quantile_lomax(const birch::type::Real& P, const birch::type::Real& λ, const birch::type::Real& α) {
  #line 289 "src/math/quantile.birch"
  libbirch_function_("quantile_lomax", "src/math/quantile.birch", 289);
  #line 290 "src/math/quantile.birch"
  libbirch_line_(290);
  #line 290 "src/math/quantile.birch"
  libbirch_assert_(0.0 < λ);
  #line 291 "src/math/quantile.birch"
  libbirch_line_(291);
  #line 291 "src/math/quantile.birch"
  libbirch_assert_(0.0 < α);
  #line 292 "src/math/quantile.birch"

  return boost::math::quantile(boost::math::pareto_distribution<>(λ, α), P) - λ;
  }

#line 308 "src/math/quantile.birch"
birch::type::Real birch::quantile_normal_inverse_gamma_gaussian(const birch::type::Real& P, const birch::type::Real& μ, const birch::type::Real& a2, const birch::type::Real& α, const birch::type::Real& β) {
  #line 308 "src/math/quantile.birch"
  libbirch_function_("quantile_normal_inverse_gamma_gaussian", "src/math/quantile.birch", 308);
  #line 310 "src/math/quantile.birch"
  libbirch_line_(310);
  #line 310 "src/math/quantile.birch"
  return birch::quantile_student_t(P, 2.0 * α, μ, (β / α) * (1.0 + a2));
}

#line 327 "src/math/quantile.birch"
birch::type::Real birch::quantile_linear_normal_inverse_gamma_gaussian(const birch::type::Real& P, const birch::type::Real& a, const birch::type::Real& μ, const birch::type::Real& a2, const birch::type::Real& c, const birch::type::Real& α, const birch::type::Real& β) {
  #line 327 "src/math/quantile.birch"
  libbirch_function_("quantile_linear_normal_inverse_gamma_gaussian", "src/math/quantile.birch", 327);
  #line 329 "src/math/quantile.birch"
  libbirch_line_(329);
  #line 329 "src/math/quantile.birch"
  return birch::quantile_student_t(P, 2.0 * α, a * μ + c, (β / α) * (1.0 + a * a * a2));
}

#line 346 "src/math/quantile.birch"
birch::type::Real birch::quantile_linear_multivariate_normal_inverse_gamma_gaussian(const birch::type::Real& P, const libbirch::DefaultArray<birch::type::Real,1>& a, const libbirch::DefaultArray<birch::type::Real,1>& ν, const birch::type::LLT& Λ, const birch::type::Real& c, const birch::type::Real& α, const birch::type::Real& γ) {
  #line 346 "src/math/quantile.birch"
  libbirch_function_("quantile_linear_multivariate_normal_inverse_gamma_gaussian", "src/math/quantile.birch", 346);
  #line 348 "src/math/quantile.birch"
  libbirch_line_(348);
  #line 348 "src/math/quantile.birch"
  auto μ = birch::solve(Λ, ν);
  #line 349 "src/math/quantile.birch"
  libbirch_line_(349);
  #line 349 "src/math/quantile.birch"
  auto β = γ - 0.5 * birch::dot(μ, ν);
  #line 350 "src/math/quantile.birch"
  libbirch_line_(350);
  #line 350 "src/math/quantile.birch"
  return birch::quantile_student_t(P, 2.0 * α, birch::dot(a, μ) + c, (β / α) * (1.0 + birch::dot(a, birch::solve(Λ, a))));
}

#line 8 "src/math/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::resample_systematic(const libbirch::DefaultArray<birch::type::Real,1>& w) {
  #line 8 "src/math/resample.birch"
  libbirch_function_("resample_systematic", "src/math/resample.birch", 8);
  #line 9 "src/math/resample.birch"
  libbirch_line_(9);
  #line 9 "src/math/resample.birch"
  return birch::cumulative_offspring_to_ancestors_permute(birch::systematic_cumulative_offspring(birch::cumulative_weights(w)));
}

#line 20 "src/math/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::resample_multinomial(const libbirch::DefaultArray<birch::type::Real,1>& w) {
  #line 20 "src/math/resample.birch"
  libbirch_function_("resample_multinomial", "src/math/resample.birch", 20);
  #line 21 "src/math/resample.birch"
  libbirch_line_(21);
  #line 21 "src/math/resample.birch"
  return birch::offspring_to_ancestors_permute(birch::simulate_multinomial(birch::length(w), birch::norm_exp(w)));
}

#line 34 "src/math/resample.birch"
std::tuple<libbirch::DefaultArray<birch::type::Integer,1>, birch::type::Integer> birch::conditional_resample_multinomial(const libbirch::DefaultArray<birch::type::Real,1>& w, const birch::type::Integer& b) {
  #line 34 "src/math/resample.birch"
  libbirch_function_("conditional_resample_multinomial", "src/math/resample.birch", 34);
  #line 36 "src/math/resample.birch"
  libbirch_line_(36);
  #line 36 "src/math/resample.birch"
  auto N = birch::length(w);
  #line 37 "src/math/resample.birch"
  libbirch_line_(37);
  #line 37 "src/math/resample.birch"
  auto o = birch::simulate_multinomial(N - birch::type::Integer(1), birch::norm_exp(w));
  #line 38 "src/math/resample.birch"
  libbirch_line_(38);
  #line 38 "src/math/resample.birch"
  o(b) = o(b) + birch::type::Integer(1);
  #line 39 "src/math/resample.birch"
  libbirch_line_(39);
  #line 39 "src/math/resample.birch"
  auto a = birch::offspring_to_ancestors_permute(o);
  #line 40 "src/math/resample.birch"
  libbirch_line_(40);
  #line 40 "src/math/resample.birch"
  libbirch_assert_(a(b) == b);
  #line 41 "src/math/resample.birch"
  libbirch_line_(41);
  #line 41 "src/math/resample.birch"
  return std::make_tuple(a, b);
}

#line 47 "src/math/resample.birch"
birch::type::Real birch::log_sum_exp(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 47 "src/math/resample.birch"
  libbirch_function_("log_sum_exp", "src/math/resample.birch", 47);
  #line 48 "src/math/resample.birch"
  libbirch_line_(48);
  #line 48 "src/math/resample.birch"
  libbirch_assert_(birch::length(x) > birch::type::Integer(0));
  #line 49 "src/math/resample.birch"
  libbirch_line_(49);
  #line 49 "src/math/resample.birch"
  auto mx = birch::max(x);
  #line 50 "src/math/resample.birch"
  libbirch_line_(50);
  #line 50 "src/math/resample.birch"
  auto r = 0.0;
  #line 51 "src/math/resample.birch"
  libbirch_line_(51);
  #line 51 "src/math/resample.birch"
  for (auto n = birch::type::Integer(1); n <= birch::length(x); ++n) {
    #line 52 "src/math/resample.birch"
    libbirch_line_(52);
    #line 52 "src/math/resample.birch"
    r = r + birch::nan_exp(x(n) - mx);
  }
  #line 54 "src/math/resample.birch"
  libbirch_line_(54);
  #line 54 "src/math/resample.birch"
  return mx + birch::log(r);
}

#line 60 "src/math/resample.birch"
birch::type::Real birch::log_sum(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 60 "src/math/resample.birch"
  libbirch_function_("log_sum", "src/math/resample.birch", 60);
  #line 61 "src/math/resample.birch"
  libbirch_line_(61);
  #line 61 "src/math/resample.birch"
  return birch::transform_reduce<birch::type::Real>(x, 0.0, std::function<birch::type::Real(birch::type::Real,birch::type::Real)>([=](const birch::type::Real& x, const birch::type::Real& y) {
    #line 62 "src/math/resample.birch"
    libbirch_line_(62);
    #line 62 "src/math/resample.birch"
    return x + y;
  }), std::function<birch::type::Real(birch::type::Real)>([=](const birch::type::Real& x) {
    #line 62 "src/math/resample.birch"
    libbirch_line_(62);
    #line 62 "src/math/resample.birch"
    return birch::log(x);
  }));
}

#line 68 "src/math/resample.birch"
birch::type::Real birch::nan_exp(const birch::type::Real& x) {
  #line 68 "src/math/resample.birch"
  libbirch_function_("nan_exp", "src/math/resample.birch", 68);
  #line 69 "src/math/resample.birch"
  libbirch_line_(69);
  #line 69 "src/math/resample.birch"
  if (birch::isnan(x)) {
    #line 70 "src/math/resample.birch"
    libbirch_line_(70);
    #line 70 "src/math/resample.birch"
    return 0.0;
  } else {
    #line 72 "src/math/resample.birch"
    libbirch_line_(72);
    #line 72 "src/math/resample.birch"
    return birch::exp(x);
  }
}

#line 81 "src/math/resample.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::norm_exp(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 81 "src/math/resample.birch"
  libbirch_function_("norm_exp", "src/math/resample.birch", 81);
  #line 82 "src/math/resample.birch"
  libbirch_line_(82);
  #line 82 "src/math/resample.birch"
  libbirch_assert_(birch::length(x) > birch::type::Integer(0));
  #line 83 "src/math/resample.birch"
  libbirch_line_(83);
  #line 83 "src/math/resample.birch"
  auto mx = birch::max(x);
  #line 84 "src/math/resample.birch"
  libbirch_line_(84);
  #line 84 "src/math/resample.birch"
  auto r = 0.0;
  #line 85 "src/math/resample.birch"
  libbirch_line_(85);
  #line 85 "src/math/resample.birch"
  for (auto n = birch::type::Integer(1); n <= birch::length(x); ++n) {
    #line 86 "src/math/resample.birch"
    libbirch_line_(86);
    #line 86 "src/math/resample.birch"
    r = r + birch::nan_exp(x(n) - mx);
  }
  #line 88 "src/math/resample.birch"
  libbirch_line_(88);
  #line 88 "src/math/resample.birch"
  auto W = mx + birch::log(r);
  #line 89 "src/math/resample.birch"
  libbirch_line_(89);
  #line 89 "src/math/resample.birch"
  return birch::transform<birch::type::Real>(x, std::function<birch::type::Real(birch::type::Real)>([=](const birch::type::Real& w) {
    #line 89 "src/math/resample.birch"
    libbirch_line_(89);
    #line 89 "src/math/resample.birch"
    return birch::nan_exp(w - W);
  }));
}

#line 95 "src/math/resample.birch"
birch::type::Integer birch::cumulative_ancestor(const libbirch::DefaultArray<birch::type::Real,1>& W) {
  #line 95 "src/math/resample.birch"
  libbirch_function_("cumulative_ancestor", "src/math/resample.birch", 95);
  #line 96 "src/math/resample.birch"
  libbirch_line_(96);
  #line 96 "src/math/resample.birch"
  auto N = birch::length(W);
  #line 97 "src/math/resample.birch"
  libbirch_line_(97);
  #line 97 "src/math/resample.birch"
  libbirch_assert_(W(N) > 0.0);
  #line 98 "src/math/resample.birch"
  libbirch_line_(98);
  #line 98 "src/math/resample.birch"
  auto u = birch::simulate_uniform(0.0, W(N));
  #line 99 "src/math/resample.birch"
  libbirch_line_(99);
  #line 99 "src/math/resample.birch"
  auto n = birch::type::Integer(1);
  #line 100 "src/math/resample.birch"
  libbirch_line_(100);
  #line 100 "src/math/resample.birch"
  while (W(n) < u) {
    #line 101 "src/math/resample.birch"
    libbirch_line_(101);
    #line 101 "src/math/resample.birch"
    n = n + birch::type::Integer(1);
  }
  #line 103 "src/math/resample.birch"
  libbirch_line_(103);
  #line 103 "src/math/resample.birch"
  return n;
}

#line 110 "src/math/resample.birch"
birch::type::Integer birch::ancestor(const libbirch::DefaultArray<birch::type::Real,1>& w) {
  #line 110 "src/math/resample.birch"
  libbirch_function_("ancestor", "src/math/resample.birch", 110);
  #line 111 "src/math/resample.birch"
  libbirch_line_(111);
  #line 111 "src/math/resample.birch"
  auto N = birch::length(w);
  #line 112 "src/math/resample.birch"
  libbirch_line_(112);
  #line 112 "src/math/resample.birch"
  auto W = birch::cumulative_weights(w);
  #line 113 "src/math/resample.birch"
  libbirch_line_(113);
  #line 113 "src/math/resample.birch"
  if (W(N) > 0.0) {
    #line 114 "src/math/resample.birch"
    libbirch_line_(114);
    #line 114 "src/math/resample.birch"
    return birch::cumulative_ancestor(W);
  } else {
    #line 116 "src/math/resample.birch"
    libbirch_line_(116);
    #line 116 "src/math/resample.birch"
    return birch::type::Integer(0);
  }
}

#line 123 "src/math/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::systematic_cumulative_offspring(const libbirch::DefaultArray<birch::type::Real,1>& W) {
  #line 123 "src/math/resample.birch"
  libbirch_function_("systematic_cumulative_offspring", "src/math/resample.birch", 123);
  #line 124 "src/math/resample.birch"
  libbirch_line_(124);
  #line 124 "src/math/resample.birch"
  auto N = birch::length(W);
  #line 125 "src/math/resample.birch"
  libbirch_line_(125);
  #line 125 "src/math/resample.birch"
  libbirch::DefaultArray<birch::type::Integer,1> O = libbirch::make_array<birch::type::Integer>(libbirch::make_shape(N));
  #line 127 "src/math/resample.birch"
  libbirch_line_(127);
  #line 127 "src/math/resample.birch"
  auto u = birch::simulate_uniform(0.0, 1.0);
  #line 128 "src/math/resample.birch"
  libbirch_line_(128);
  #line 128 "src/math/resample.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 129 "src/math/resample.birch"
    libbirch_line_(129);
    #line 129 "src/math/resample.birch"
    auto r = N * W(n) / W(N);
    #line 130 "src/math/resample.birch"
    libbirch_line_(130);
    #line 130 "src/math/resample.birch"
    O(n) = birch::min(N, birch::Integer(birch::floor(r + u)));
  }
  #line 132 "src/math/resample.birch"
  libbirch_line_(132);
  #line 132 "src/math/resample.birch"
  return O;
}

#line 138 "src/math/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::offspring_to_ancestors(const libbirch::DefaultArray<birch::type::Integer,1>& o) {
  #line 138 "src/math/resample.birch"
  libbirch_function_("offspring_to_ancestors", "src/math/resample.birch", 138);
  #line 139 "src/math/resample.birch"
  libbirch_line_(139);
  #line 139 "src/math/resample.birch"
  auto N = birch::length(o);
  #line 140 "src/math/resample.birch"
  libbirch_line_(140);
  #line 140 "src/math/resample.birch"
  auto i = birch::type::Integer(1);
  #line 141 "src/math/resample.birch"
  libbirch_line_(141);
  #line 141 "src/math/resample.birch"
  libbirch::DefaultArray<birch::type::Integer,1> a = libbirch::make_array<birch::type::Integer>(libbirch::make_shape(N));
  #line 142 "src/math/resample.birch"
  libbirch_line_(142);
  #line 142 "src/math/resample.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 143 "src/math/resample.birch"
    libbirch_line_(143);
    #line 143 "src/math/resample.birch"
    for (auto j = birch::type::Integer(1); j <= o(n); ++j) {
      #line 144 "src/math/resample.birch"
      libbirch_line_(144);
      #line 144 "src/math/resample.birch"
      a(i) = n;
      #line 145 "src/math/resample.birch"
      libbirch_line_(145);
      #line 145 "src/math/resample.birch"
      i = i + birch::type::Integer(1);
    }
  }
  #line 148 "src/math/resample.birch"
  libbirch_line_(148);
  #line 148 "src/math/resample.birch"
  libbirch_assert_(i == N + birch::type::Integer(1));
  #line 149 "src/math/resample.birch"
  libbirch_line_(149);
  #line 149 "src/math/resample.birch"
  return a;
}

#line 155 "src/math/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::offspring_to_ancestors_permute(const libbirch::DefaultArray<birch::type::Integer,1>& o) {
  #line 155 "src/math/resample.birch"
  libbirch_function_("offspring_to_ancestors_permute", "src/math/resample.birch", 155);
  #line 156 "src/math/resample.birch"
  libbirch_line_(156);
  #line 156 "src/math/resample.birch"
  auto N = birch::length(o);
  #line 157 "src/math/resample.birch"
  libbirch_line_(157);
  #line 157 "src/math/resample.birch"
  auto i = birch::type::Integer(1);
  #line 158 "src/math/resample.birch"
  libbirch_line_(158);
  #line 158 "src/math/resample.birch"
  libbirch::DefaultArray<birch::type::Integer,1> a = libbirch::make_array<birch::type::Integer>(libbirch::make_shape(N));
  #line 159 "src/math/resample.birch"
  libbirch_line_(159);
  #line 159 "src/math/resample.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 160 "src/math/resample.birch"
    libbirch_line_(160);
    #line 160 "src/math/resample.birch"
    for (auto j = birch::type::Integer(1); j <= o(n); ++j) {
      #line 161 "src/math/resample.birch"
      libbirch_line_(161);
      #line 161 "src/math/resample.birch"
      a(i) = n;
      #line 162 "src/math/resample.birch"
      libbirch_line_(162);
      #line 162 "src/math/resample.birch"
      i = i + birch::type::Integer(1);
    }
  }
  #line 165 "src/math/resample.birch"
  libbirch_line_(165);
  #line 165 "src/math/resample.birch"
  libbirch_assert_(i == N + birch::type::Integer(1));
  #line 168 "src/math/resample.birch"
  libbirch_line_(168);
  #line 168 "src/math/resample.birch"
  auto n = birch::type::Integer(1);
  #line 169 "src/math/resample.birch"
  libbirch_line_(169);
  #line 169 "src/math/resample.birch"
  while (n <= N) {
    #line 170 "src/math/resample.birch"
    libbirch_line_(170);
    #line 170 "src/math/resample.birch"
    auto c = a(n);
    #line 171 "src/math/resample.birch"
    libbirch_line_(171);
    #line 171 "src/math/resample.birch"
    if (c != n && a(c) != c) {
      #line 172 "src/math/resample.birch"
      libbirch_line_(172);
      #line 172 "src/math/resample.birch"
      a(n) = a(c);
      #line 173 "src/math/resample.birch"
      libbirch_line_(173);
      #line 173 "src/math/resample.birch"
      a(c) = c;
    } else {
      #line 175 "src/math/resample.birch"
      libbirch_line_(175);
      #line 175 "src/math/resample.birch"
      n = n + birch::type::Integer(1);
    }
  }
  #line 179 "src/math/resample.birch"
  libbirch_line_(179);
  #line 179 "src/math/resample.birch"
  return a;
}

#line 185 "src/math/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::cumulative_offspring_to_ancestors(const libbirch::DefaultArray<birch::type::Integer,1>& O) {
  #line 185 "src/math/resample.birch"
  libbirch_function_("cumulative_offspring_to_ancestors", "src/math/resample.birch", 185);
  #line 186 "src/math/resample.birch"
  libbirch_line_(186);
  #line 186 "src/math/resample.birch"
  auto N = birch::length(O);
  #line 187 "src/math/resample.birch"
  libbirch_line_(187);
  #line 187 "src/math/resample.birch"
  libbirch::DefaultArray<birch::type::Integer,1> a = libbirch::make_array<birch::type::Integer>(libbirch::make_shape(N));
  #line 188 "src/math/resample.birch"
  libbirch_line_(188);
  #line 188 "src/math/resample.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 189 "src/math/resample.birch"
    libbirch_line_(189);
    #line 189 "src/math/resample.birch"
    birch::type::Integer start = libbirch::make<birch::type::Integer>();
    #line 190 "src/math/resample.birch"
    libbirch_line_(190);
    #line 190 "src/math/resample.birch"
    if (n == birch::type::Integer(1)) {
      #line 191 "src/math/resample.birch"
      libbirch_line_(191);
      #line 191 "src/math/resample.birch"
      start = birch::type::Integer(0);
    } else {
      #line 193 "src/math/resample.birch"
      libbirch_line_(193);
      #line 193 "src/math/resample.birch"
      start = O(n - birch::type::Integer(1));
    }
    #line 195 "src/math/resample.birch"
    libbirch_line_(195);
    #line 195 "src/math/resample.birch"
    auto o = O(n) - start;
    #line 196 "src/math/resample.birch"
    libbirch_line_(196);
    #line 196 "src/math/resample.birch"
    for (auto j = birch::type::Integer(1); j <= o; ++j) {
      #line 197 "src/math/resample.birch"
      libbirch_line_(197);
      #line 197 "src/math/resample.birch"
      a(start + j) = n;
    }
  }
  #line 200 "src/math/resample.birch"
  libbirch_line_(200);
  #line 200 "src/math/resample.birch"
  return a;
}

#line 207 "src/math/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::cumulative_offspring_to_ancestors_permute(const libbirch::DefaultArray<birch::type::Integer,1>& O) {
  #line 207 "src/math/resample.birch"
  libbirch_function_("cumulative_offspring_to_ancestors_permute", "src/math/resample.birch", 207);
  #line 209 "src/math/resample.birch"
  libbirch_line_(209);
  #line 209 "src/math/resample.birch"
  libbirch::DefaultArray<birch::type::Integer,1> a = libbirch::make_array<birch::type::Integer>(libbirch::make_shape(O(birch::length(O))));
  #line 210 "src/math/resample.birch"
  libbirch_line_(210);
  #line 210 "src/math/resample.birch"
  auto N = birch::length(a);
  #line 211 "src/math/resample.birch"
  libbirch_line_(211);
  #line 211 "src/math/resample.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 212 "src/math/resample.birch"
    libbirch_line_(212);
    #line 212 "src/math/resample.birch"
    auto start = birch::type::Integer(0);
    #line 213 "src/math/resample.birch"
    libbirch_line_(213);
    #line 213 "src/math/resample.birch"
    if (n > birch::type::Integer(1)) {
      #line 214 "src/math/resample.birch"
      libbirch_line_(214);
      #line 214 "src/math/resample.birch"
      start = O(n - birch::type::Integer(1));
    }
    #line 216 "src/math/resample.birch"
    libbirch_line_(216);
    #line 216 "src/math/resample.birch"
    auto o = O(n) - start;
    #line 217 "src/math/resample.birch"
    libbirch_line_(217);
    #line 217 "src/math/resample.birch"
    for (auto j = birch::type::Integer(1); j <= o; ++j) {
      #line 218 "src/math/resample.birch"
      libbirch_line_(218);
      #line 218 "src/math/resample.birch"
      a(start + j) = n;
    }
  }
  #line 223 "src/math/resample.birch"
  libbirch_line_(223);
  #line 223 "src/math/resample.birch"
  auto n = birch::type::Integer(1);
  #line 224 "src/math/resample.birch"
  libbirch_line_(224);
  #line 224 "src/math/resample.birch"
  while (n <= N) {
    #line 225 "src/math/resample.birch"
    libbirch_line_(225);
    #line 225 "src/math/resample.birch"
    auto c = a(n);
    #line 226 "src/math/resample.birch"
    libbirch_line_(226);
    #line 226 "src/math/resample.birch"
    if (c != n && a(c) != c) {
      #line 227 "src/math/resample.birch"
      libbirch_line_(227);
      #line 227 "src/math/resample.birch"
      a(n) = a(c);
      #line 228 "src/math/resample.birch"
      libbirch_line_(228);
      #line 228 "src/math/resample.birch"
      a(c) = c;
    } else {
      #line 230 "src/math/resample.birch"
      libbirch_line_(230);
      #line 230 "src/math/resample.birch"
      n = n + birch::type::Integer(1);
    }
  }
  #line 234 "src/math/resample.birch"
  libbirch_line_(234);
  #line 234 "src/math/resample.birch"
  return a;
}

#line 240 "src/math/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::cumulative_offspring_to_offspring(const libbirch::DefaultArray<birch::type::Integer,1>& O) {
  #line 240 "src/math/resample.birch"
  libbirch_function_("cumulative_offspring_to_offspring", "src/math/resample.birch", 240);
  #line 241 "src/math/resample.birch"
  libbirch_line_(241);
  #line 241 "src/math/resample.birch"
  return birch::adjacent_difference<birch::type::Integer>(O, std::function<birch::type::Integer(birch::type::Integer,birch::type::Integer)>([=](const birch::type::Integer& x, const birch::type::Integer& y) {
    #line 242 "src/math/resample.birch"
    libbirch_line_(242);
    #line 242 "src/math/resample.birch"
    return x - y;
  }));
}

#line 249 "src/math/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::permute_ancestors(const libbirch::DefaultArray<birch::type::Integer,1>& a) {
  #line 249 "src/math/resample.birch"
  libbirch_function_("permute_ancestors", "src/math/resample.birch", 249);
  #line 250 "src/math/resample.birch"
  libbirch_line_(250);
  #line 250 "src/math/resample.birch"
  auto N = birch::length(a);
  #line 251 "src/math/resample.birch"
  libbirch_line_(251);
  #line 251 "src/math/resample.birch"
  auto b = a;
  #line 252 "src/math/resample.birch"
  libbirch_line_(252);
  #line 252 "src/math/resample.birch"
  auto n = birch::type::Integer(1);
  #line 253 "src/math/resample.birch"
  libbirch_line_(253);
  #line 253 "src/math/resample.birch"
  while (n <= N) {
    #line 254 "src/math/resample.birch"
    libbirch_line_(254);
    #line 254 "src/math/resample.birch"
    auto c = b(n);
    #line 255 "src/math/resample.birch"
    libbirch_line_(255);
    #line 255 "src/math/resample.birch"
    if (c != n && b(c) != c) {
      #line 256 "src/math/resample.birch"
      libbirch_line_(256);
      #line 256 "src/math/resample.birch"
      b(n) = b(c);
      #line 257 "src/math/resample.birch"
      libbirch_line_(257);
      #line 257 "src/math/resample.birch"
      b(c) = c;
    } else {
      #line 259 "src/math/resample.birch"
      libbirch_line_(259);
      #line 259 "src/math/resample.birch"
      n = n + birch::type::Integer(1);
    }
  }
  #line 262 "src/math/resample.birch"
  libbirch_line_(262);
  #line 262 "src/math/resample.birch"
  return b;
}

#line 268 "src/math/resample.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::cumulative_weights(const libbirch::DefaultArray<birch::type::Real,1>& w) {
  #line 268 "src/math/resample.birch"
  libbirch_function_("cumulative_weights", "src/math/resample.birch", 268);
  #line 269 "src/math/resample.birch"
  libbirch_line_(269);
  #line 269 "src/math/resample.birch"
  auto N = birch::length(w);
  #line 270 "src/math/resample.birch"
  libbirch_line_(270);
  #line 270 "src/math/resample.birch"
  libbirch::DefaultArray<birch::type::Real,1> W = libbirch::make_array<birch::type::Real>(libbirch::make_shape(N));
  #line 272 "src/math/resample.birch"
  libbirch_line_(272);
  #line 272 "src/math/resample.birch"
  if (N > birch::type::Integer(0)) {
    #line 273 "src/math/resample.birch"
    libbirch_line_(273);
    #line 273 "src/math/resample.birch"
    auto mx = birch::max(w);
    #line 274 "src/math/resample.birch"
    libbirch_line_(274);
    #line 274 "src/math/resample.birch"
    W(birch::type::Integer(1)) = birch::nan_exp(w(birch::type::Integer(1)) - mx);
    #line 275 "src/math/resample.birch"
    libbirch_line_(275);
    #line 275 "src/math/resample.birch"
    for (auto n = birch::type::Integer(2); n <= N; ++n) {
      #line 276 "src/math/resample.birch"
      libbirch_line_(276);
      #line 276 "src/math/resample.birch"
      W(n) = W(n - birch::type::Integer(1)) + birch::nan_exp(w(n) - mx);
    }
  }
  #line 279 "src/math/resample.birch"
  libbirch_line_(279);
  #line 279 "src/math/resample.birch"
  return W;
}

#line 289 "src/math/resample.birch"
std::tuple<birch::type::Real, birch::type::Real> birch::resample_reduce(const libbirch::DefaultArray<birch::type::Real,1>& w) {
  #line 289 "src/math/resample.birch"
  libbirch_function_("resample_reduce", "src/math/resample.birch", 289);
  #line 290 "src/math/resample.birch"
  libbirch_line_(290);
  #line 290 "src/math/resample.birch"
  if (birch::length(w) == birch::type::Integer(0)) {
    #line 291 "src/math/resample.birch"
    libbirch_line_(291);
    #line 291 "src/math/resample.birch"
    return std::make_tuple(0.0, 0.0);
  } else {
    #line 293 "src/math/resample.birch"
    libbirch_line_(293);
    #line 293 "src/math/resample.birch"
    auto N = birch::length(w);
    #line 294 "src/math/resample.birch"
    libbirch_line_(294);
    #line 294 "src/math/resample.birch"
    auto W = 0.0;
    #line 295 "src/math/resample.birch"
    libbirch_line_(295);
    #line 295 "src/math/resample.birch"
    auto W2 = 0.0;
    #line 296 "src/math/resample.birch"
    libbirch_line_(296);
    #line 296 "src/math/resample.birch"
    auto mx = birch::max(w);
    #line 297 "src/math/resample.birch"
    libbirch_line_(297);
    #line 297 "src/math/resample.birch"
    for (auto n = birch::type::Integer(1); n <= N; ++n) {
      #line 298 "src/math/resample.birch"
      libbirch_line_(298);
      #line 298 "src/math/resample.birch"
      auto v = birch::nan_exp(w(n) - mx);
      #line 299 "src/math/resample.birch"
      libbirch_line_(299);
      #line 299 "src/math/resample.birch"
      W = W + v;
      #line 300 "src/math/resample.birch"
      libbirch_line_(300);
      #line 300 "src/math/resample.birch"
      W2 = W2 + v * v;
    }
    #line 302 "src/math/resample.birch"
    libbirch_line_(302);
    #line 302 "src/math/resample.birch"
    return std::make_tuple(W * W / W2, birch::log(W) + mx);
  }
}

#line 4 "src/math/scalar.birch"
birch::type::Integer birch::length(const birch::type::Real& x) {
  #line 4 "src/math/scalar.birch"
  libbirch_function_("length", "src/math/scalar.birch", 4);
  #line 5 "src/math/scalar.birch"
  libbirch_line_(5);
  #line 5 "src/math/scalar.birch"
  return birch::type::Integer(1);
}

#line 11 "src/math/scalar.birch"
birch::type::Integer birch::length(const birch::type::Integer& x) {
  #line 11 "src/math/scalar.birch"
  libbirch_function_("length", "src/math/scalar.birch", 11);
  #line 12 "src/math/scalar.birch"
  libbirch_line_(12);
  #line 12 "src/math/scalar.birch"
  return birch::type::Integer(1);
}

#line 18 "src/math/scalar.birch"
birch::type::Integer birch::length(const birch::type::Boolean& x) {
  #line 18 "src/math/scalar.birch"
  libbirch_function_("length", "src/math/scalar.birch", 18);
  #line 19 "src/math/scalar.birch"
  libbirch_line_(19);
  #line 19 "src/math/scalar.birch"
  return birch::type::Integer(1);
}

#line 25 "src/math/scalar.birch"
birch::type::Integer birch::rows(const birch::type::Real& x) {
  #line 25 "src/math/scalar.birch"
  libbirch_function_("rows", "src/math/scalar.birch", 25);
  #line 26 "src/math/scalar.birch"
  libbirch_line_(26);
  #line 26 "src/math/scalar.birch"
  return birch::type::Integer(1);
}

#line 32 "src/math/scalar.birch"
birch::type::Integer birch::rows(const birch::type::Integer& x) {
  #line 32 "src/math/scalar.birch"
  libbirch_function_("rows", "src/math/scalar.birch", 32);
  #line 33 "src/math/scalar.birch"
  libbirch_line_(33);
  #line 33 "src/math/scalar.birch"
  return birch::type::Integer(1);
}

#line 39 "src/math/scalar.birch"
birch::type::Integer birch::rows(const birch::type::Boolean& x) {
  #line 39 "src/math/scalar.birch"
  libbirch_function_("rows", "src/math/scalar.birch", 39);
  #line 40 "src/math/scalar.birch"
  libbirch_line_(40);
  #line 40 "src/math/scalar.birch"
  return birch::type::Integer(1);
}

#line 46 "src/math/scalar.birch"
birch::type::Integer birch::columns(const birch::type::Real& x) {
  #line 46 "src/math/scalar.birch"
  libbirch_function_("columns", "src/math/scalar.birch", 46);
  #line 47 "src/math/scalar.birch"
  libbirch_line_(47);
  #line 47 "src/math/scalar.birch"
  return birch::type::Integer(1);
}

#line 53 "src/math/scalar.birch"
birch::type::Integer birch::columns(const birch::type::Integer& x) {
  #line 53 "src/math/scalar.birch"
  libbirch_function_("columns", "src/math/scalar.birch", 53);
  #line 54 "src/math/scalar.birch"
  libbirch_line_(54);
  #line 54 "src/math/scalar.birch"
  return birch::type::Integer(1);
}

#line 60 "src/math/scalar.birch"
birch::type::Integer birch::columns(const birch::type::Boolean& x) {
  #line 60 "src/math/scalar.birch"
  libbirch_function_("columns", "src/math/scalar.birch", 60);
  #line 61 "src/math/scalar.birch"
  libbirch_line_(61);
  #line 61 "src/math/scalar.birch"
  return birch::type::Integer(1);
}

#line 67 "src/math/scalar.birch"
birch::type::Real birch::transpose(const birch::type::Real& x) {
  #line 67 "src/math/scalar.birch"
  libbirch_function_("transpose", "src/math/scalar.birch", 67);
  #line 68 "src/math/scalar.birch"
  libbirch_line_(68);
  #line 68 "src/math/scalar.birch"
  return x;
}

#line 74 "src/math/scalar.birch"
birch::type::Integer birch::transpose(const birch::type::Integer& x) {
  #line 74 "src/math/scalar.birch"
  libbirch_function_("transpose", "src/math/scalar.birch", 74);
  #line 75 "src/math/scalar.birch"
  libbirch_line_(75);
  #line 75 "src/math/scalar.birch"
  return x;
}

#line 81 "src/math/scalar.birch"
birch::type::Boolean birch::transpose(const birch::type::Boolean& x) {
  #line 81 "src/math/scalar.birch"
  libbirch_function_("transpose", "src/math/scalar.birch", 81);
  #line 82 "src/math/scalar.birch"
  libbirch_line_(82);
  #line 82 "src/math/scalar.birch"
  return x;
}

#line 1 "src/math/simulate.birch"

#include <random>

static auto make_rngs() {
  std::vector<std::mt19937_64,libbirch::Allocator<std::mt19937_64>> rngs(
      libbirch::get_max_threads());
  std::random_device rd;
  for (unsigned i = 0; i < rngs.size(); ++i) {
    rngs[i].seed(rd());
  }
  return rngs;
}

static auto& get_rng() {
  static auto rngs = make_rngs();
  return rngs[libbirch::get_thread_num()];
}
#line 25 "src/math/simulate.birch"
void birch::seed(const birch::type::Integer& s) {
  #line 25 "src/math/simulate.birch"
  libbirch_function_("seed", "src/math/simulate.birch", 25);
  #line 26 "src/math/simulate.birch"

  #pragma omp parallel num_threads(libbirch::get_max_threads())
  {
    get_rng().seed(s + libbirch::get_thread_num());
  }
  }

#line 37 "src/math/simulate.birch"
void birch::seed() {
  #line 37 "src/math/simulate.birch"
  libbirch_function_("seed", "src/math/simulate.birch", 37);
  #line 38 "src/math/simulate.birch"

  std::random_device rd;
  #pragma omp parallel num_threads(libbirch::get_max_threads())
  {
    #pragma omp critical
    get_rng().seed(rd());
  }
  }

#line 53 "src/math/simulate.birch"
birch::type::Boolean birch::simulate_bernoulli(const birch::type::Real& ρ) {
  #line 53 "src/math/simulate.birch"
  libbirch_function_("simulate_bernoulli", "src/math/simulate.birch", 53);
  #line 54 "src/math/simulate.birch"
  libbirch_line_(54);
  #line 54 "src/math/simulate.birch"
  libbirch_assert_(0.0 <= ρ && ρ <= 1.0);
  #line 55 "src/math/simulate.birch"

  return std::bernoulli_distribution(ρ)(get_rng());
  }

#line 65 "src/math/simulate.birch"
birch::type::Integer birch::simulate_delta(const birch::type::Integer& μ) {
  #line 65 "src/math/simulate.birch"
  libbirch_function_("simulate_delta", "src/math/simulate.birch", 65);
  #line 66 "src/math/simulate.birch"
  libbirch_line_(66);
  #line 66 "src/math/simulate.birch"
  return μ;
}

#line 75 "src/math/simulate.birch"
birch::type::Integer birch::simulate_binomial(const birch::type::Integer& n, const birch::type::Real& ρ) {
  #line 75 "src/math/simulate.birch"
  libbirch_function_("simulate_binomial", "src/math/simulate.birch", 75);
  #line 76 "src/math/simulate.birch"
  libbirch_line_(76);
  #line 76 "src/math/simulate.birch"
  libbirch_assert_(birch::type::Integer(0) <= n);
  #line 77 "src/math/simulate.birch"
  libbirch_line_(77);
  #line 77 "src/math/simulate.birch"
  libbirch_assert_(0.0 <= ρ && ρ <= 1.0);
  #line 78 "src/math/simulate.birch"

  return std::binomial_distribution<birch::type::Integer>(n, ρ)(get_rng());
  }

#line 91 "src/math/simulate.birch"
birch::type::Integer birch::simulate_negative_binomial(const birch::type::Integer& k, const birch::type::Real& ρ) {
  #line 91 "src/math/simulate.birch"
  libbirch_function_("simulate_negative_binomial", "src/math/simulate.birch", 91);
  #line 92 "src/math/simulate.birch"
  libbirch_line_(92);
  #line 92 "src/math/simulate.birch"
  libbirch_assert_(birch::type::Integer(0) < k);
  #line 93 "src/math/simulate.birch"
  libbirch_line_(93);
  #line 93 "src/math/simulate.birch"
  libbirch_assert_(0.0 <= ρ && ρ <= 1.0);
  #line 94 "src/math/simulate.birch"

  return std::negative_binomial_distribution<birch::type::Integer>(k, ρ)(get_rng());
  }

#line 104 "src/math/simulate.birch"
birch::type::Integer birch::simulate_poisson(const birch::type::Real& λ) {
  #line 104 "src/math/simulate.birch"
  libbirch_function_("simulate_poisson", "src/math/simulate.birch", 104);
  #line 105 "src/math/simulate.birch"
  libbirch_line_(105);
  #line 105 "src/math/simulate.birch"
  libbirch_assert_(0.0 <= λ);
  #line 106 "src/math/simulate.birch"
  libbirch_line_(106);
  #line 106 "src/math/simulate.birch"
  if (λ > 0.0) {
    #line 107 "src/math/simulate.birch"

    return std::poisson_distribution<birch::type::Integer>(λ)(get_rng());
      } else {
    #line 111 "src/math/simulate.birch"
    libbirch_line_(111);
    #line 111 "src/math/simulate.birch"
    return birch::type::Integer(0);
  }
}

#line 120 "src/math/simulate.birch"
birch::type::Integer birch::simulate_categorical(const libbirch::DefaultArray<birch::type::Real,1>& ρ) {
  #line 120 "src/math/simulate.birch"
  libbirch_function_("simulate_categorical", "src/math/simulate.birch", 120);
  #line 121 "src/math/simulate.birch"
  libbirch_line_(121);
  #line 121 "src/math/simulate.birch"
  return birch::simulate_categorical(ρ, 1.0);
}

#line 130 "src/math/simulate.birch"
birch::type::Integer birch::simulate_categorical(const libbirch::DefaultArray<birch::type::Real,1>& ρ, const birch::type::Real& Z) {
  #line 130 "src/math/simulate.birch"
  libbirch_function_("simulate_categorical", "src/math/simulate.birch", 130);
  #line 131 "src/math/simulate.birch"
  libbirch_line_(131);
  #line 131 "src/math/simulate.birch"
  libbirch_assert_(birch::length(ρ) > birch::type::Integer(0));
  #line 132 "src/math/simulate.birch"
  libbirch_line_(132);
  #line 132 "src/math/simulate.birch"
  libbirch_assert_(birch::abs(birch::sum(ρ) - Z) < 1.0e-6);
  #line 134 "src/math/simulate.birch"
  libbirch_line_(134);
  #line 134 "src/math/simulate.birch"
  birch::type::Real u = birch::simulate_uniform(0.0, Z);
  #line 135 "src/math/simulate.birch"
  libbirch_line_(135);
  #line 135 "src/math/simulate.birch"
  birch::type::Integer x = birch::type::Integer(1);
  #line 136 "src/math/simulate.birch"
  libbirch_line_(136);
  #line 136 "src/math/simulate.birch"
  birch::type::Real P = ρ(birch::type::Integer(1));
  #line 137 "src/math/simulate.birch"
  libbirch_line_(137);
  #line 137 "src/math/simulate.birch"
  while (P < u) {
    #line 138 "src/math/simulate.birch"
    libbirch_line_(138);
    #line 138 "src/math/simulate.birch"
    libbirch_assert_(x <= birch::length(ρ));
    #line 139 "src/math/simulate.birch"
    libbirch_line_(139);
    #line 139 "src/math/simulate.birch"
    x = x + birch::type::Integer(1);
    #line 140 "src/math/simulate.birch"
    libbirch_line_(140);
    #line 140 "src/math/simulate.birch"
    libbirch_assert_(0.0 <= ρ(x));
    #line 141 "src/math/simulate.birch"
    libbirch_line_(141);
    #line 141 "src/math/simulate.birch"
    P = P + ρ(x);
    #line 142 "src/math/simulate.birch"
    libbirch_line_(142);
    #line 142 "src/math/simulate.birch"
    libbirch_assert_(P < Z + 1.0e-6);
  }
  #line 144 "src/math/simulate.birch"
  libbirch_line_(144);
  #line 144 "src/math/simulate.birch"
  return x;
}

#line 159 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::simulate_multinomial(const birch::type::Integer& n, const libbirch::DefaultArray<birch::type::Real,1>& ρ) {
  #line 159 "src/math/simulate.birch"
  libbirch_function_("simulate_multinomial", "src/math/simulate.birch", 159);
  #line 160 "src/math/simulate.birch"
  libbirch_line_(160);
  #line 160 "src/math/simulate.birch"
  return birch::simulate_multinomial(n, ρ, 1.0);
}

#line 171 "src/math/simulate.birch"
birch::type::Real birch::simulate_inverse_gamma_gamma(const birch::type::Real& k, const birch::type::Real& α, const birch::type::Real& β) {
  #line 171 "src/math/simulate.birch"
  libbirch_function_("simulate_inverse_gamma_gamma", "src/math/simulate.birch", 171);
  #line 172 "src/math/simulate.birch"
  libbirch_line_(172);
  #line 172 "src/math/simulate.birch"
  return birch::simulate_gamma(k, birch::simulate_inverse_gamma(α, β));
}

#line 188 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::simulate_multinomial(const birch::type::Integer& n, const libbirch::DefaultArray<birch::type::Real,1>& ρ, const birch::type::Real& Z) {
  #line 188 "src/math/simulate.birch"
  libbirch_function_("simulate_multinomial", "src/math/simulate.birch", 188);
  #line 189 "src/math/simulate.birch"
  libbirch_line_(189);
  #line 189 "src/math/simulate.birch"
  libbirch_assert_(birch::length(ρ) > birch::type::Integer(0));
  #line 190 "src/math/simulate.birch"
  libbirch_line_(190);
  #line 190 "src/math/simulate.birch"
  libbirch_assert_(birch::abs(birch::sum(ρ) - Z) < 1.0e-6);
  #line 192 "src/math/simulate.birch"
  libbirch_line_(192);
  #line 192 "src/math/simulate.birch"
  birch::type::Integer D = birch::length(ρ);
  #line 193 "src/math/simulate.birch"
  libbirch_line_(193);
  #line 193 "src/math/simulate.birch"
  birch::type::Real R = ρ(D);
  #line 194 "src/math/simulate.birch"
  libbirch_line_(194);
  #line 194 "src/math/simulate.birch"
  birch::type::Real lnMax = 0.0;
  #line 195 "src/math/simulate.birch"
  libbirch_line_(195);
  #line 195 "src/math/simulate.birch"
  birch::type::Integer j = D;
  #line 196 "src/math/simulate.birch"
  libbirch_line_(196);
  #line 196 "src/math/simulate.birch"
  birch::type::Integer i = n;
  #line 197 "src/math/simulate.birch"
  libbirch_line_(197);
  #line 197 "src/math/simulate.birch"
  birch::type::Real u = libbirch::make<birch::type::Real>();
  #line 198 "src/math/simulate.birch"
  libbirch_line_(198);
  #line 198 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Integer,1> x = birch::vector(birch::type::Integer(0), D);
  #line 200 "src/math/simulate.birch"
  libbirch_line_(200);
  #line 200 "src/math/simulate.birch"
  while (i > birch::type::Integer(0)) {
    #line 201 "src/math/simulate.birch"
    libbirch_line_(201);
    #line 201 "src/math/simulate.birch"
    u = birch::simulate_uniform(0.0, 1.0);
    #line 202 "src/math/simulate.birch"
    libbirch_line_(202);
    #line 202 "src/math/simulate.birch"
    lnMax = lnMax + birch::log(u) / i;
    #line 203 "src/math/simulate.birch"
    libbirch_line_(203);
    #line 203 "src/math/simulate.birch"
    u = Z * birch::exp(lnMax);
    #line 204 "src/math/simulate.birch"
    libbirch_line_(204);
    #line 204 "src/math/simulate.birch"
    while (u < Z - R) {
      #line 205 "src/math/simulate.birch"
      libbirch_line_(205);
      #line 205 "src/math/simulate.birch"
      j = j - birch::type::Integer(1);
      #line 206 "src/math/simulate.birch"
      libbirch_line_(206);
      #line 206 "src/math/simulate.birch"
      R = R + ρ(j);
    }
    #line 208 "src/math/simulate.birch"
    libbirch_line_(208);
    #line 208 "src/math/simulate.birch"
    x(j) = x(j) + birch::type::Integer(1);
    #line 209 "src/math/simulate.birch"
    libbirch_line_(209);
    #line 209 "src/math/simulate.birch"
    i = i - birch::type::Integer(1);
  }
  #line 211 "src/math/simulate.birch"
  libbirch_line_(211);
  #line 211 "src/math/simulate.birch"
  while (j > birch::type::Integer(1)) {
    #line 212 "src/math/simulate.birch"
    libbirch_line_(212);
    #line 212 "src/math/simulate.birch"
    j = j - birch::type::Integer(1);
    #line 213 "src/math/simulate.birch"
    libbirch_line_(213);
    #line 213 "src/math/simulate.birch"
    x(j) = birch::type::Integer(0);
  }
  #line 215 "src/math/simulate.birch"
  libbirch_line_(215);
  #line 215 "src/math/simulate.birch"
  return x;
}

#line 223 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_dirichlet(const libbirch::DefaultArray<birch::type::Real,1>& α) {
  #line 223 "src/math/simulate.birch"
  libbirch_function_("simulate_dirichlet", "src/math/simulate.birch", 223);
  #line 224 "src/math/simulate.birch"
  libbirch_line_(224);
  #line 224 "src/math/simulate.birch"
  birch::type::Integer D = birch::length(α);
  #line 225 "src/math/simulate.birch"
  libbirch_line_(225);
  #line 225 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,1> x = libbirch::make_array<birch::type::Real>(libbirch::make_shape(D));
  #line 226 "src/math/simulate.birch"
  libbirch_line_(226);
  #line 226 "src/math/simulate.birch"
  birch::type::Real z = 0.0;
  #line 228 "src/math/simulate.birch"
  libbirch_line_(228);
  #line 228 "src/math/simulate.birch"
  for (auto i = birch::type::Integer(1); i <= D; ++i) {
    #line 229 "src/math/simulate.birch"
    libbirch_line_(229);
    #line 229 "src/math/simulate.birch"
    x(i) = birch::simulate_gamma(α(i), 1.0);
    #line 230 "src/math/simulate.birch"
    libbirch_line_(230);
    #line 230 "src/math/simulate.birch"
    z = z + x(i);
  }
  #line 232 "src/math/simulate.birch"
  libbirch_line_(232);
  #line 232 "src/math/simulate.birch"
  z = 1.0 / z;
  #line 233 "src/math/simulate.birch"
  libbirch_line_(233);
  #line 233 "src/math/simulate.birch"
  for (auto i = birch::type::Integer(1); i <= D; ++i) {
    #line 234 "src/math/simulate.birch"
    libbirch_line_(234);
    #line 234 "src/math/simulate.birch"
    x(i) = z * x(i);
  }
  #line 236 "src/math/simulate.birch"
  libbirch_line_(236);
  #line 236 "src/math/simulate.birch"
  return x;
}

#line 245 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_dirichlet(const birch::type::Real& α, const birch::type::Integer& D) {
  #line 245 "src/math/simulate.birch"
  libbirch_function_("simulate_dirichlet", "src/math/simulate.birch", 245);
  #line 246 "src/math/simulate.birch"
  libbirch_line_(246);
  #line 246 "src/math/simulate.birch"
  libbirch_assert_(D > birch::type::Integer(0));
  #line 247 "src/math/simulate.birch"
  libbirch_line_(247);
  #line 247 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,1> x = libbirch::make_array<birch::type::Real>(libbirch::make_shape(D));
  #line 248 "src/math/simulate.birch"
  libbirch_line_(248);
  #line 248 "src/math/simulate.birch"
  birch::type::Real z = 0.0;
  #line 250 "src/math/simulate.birch"
  libbirch_line_(250);
  #line 250 "src/math/simulate.birch"
  for (auto i = birch::type::Integer(1); i <= D; ++i) {
    #line 251 "src/math/simulate.birch"
    libbirch_line_(251);
    #line 251 "src/math/simulate.birch"
    x(i) = birch::simulate_gamma(α, 1.0);
    #line 252 "src/math/simulate.birch"
    libbirch_line_(252);
    #line 252 "src/math/simulate.birch"
    z = z + x(i);
  }
  #line 254 "src/math/simulate.birch"
  libbirch_line_(254);
  #line 254 "src/math/simulate.birch"
  z = 1.0 / z;
  #line 255 "src/math/simulate.birch"
  libbirch_line_(255);
  #line 255 "src/math/simulate.birch"
  for (auto i = birch::type::Integer(1); i <= D; ++i) {
    #line 256 "src/math/simulate.birch"
    libbirch_line_(256);
    #line 256 "src/math/simulate.birch"
    x(i) = z * x(i);
  }
  #line 258 "src/math/simulate.birch"
  libbirch_line_(258);
  #line 258 "src/math/simulate.birch"
  return x;
}

#line 267 "src/math/simulate.birch"
birch::type::Real birch::simulate_uniform(const birch::type::Real& l, const birch::type::Real& u) {
  #line 267 "src/math/simulate.birch"
  libbirch_function_("simulate_uniform", "src/math/simulate.birch", 267);
  #line 268 "src/math/simulate.birch"
  libbirch_line_(268);
  #line 268 "src/math/simulate.birch"
  libbirch_assert_(l <= u);
  #line 269 "src/math/simulate.birch"

  return std::uniform_real_distribution<birch::type::Real>(l, u)(get_rng());
  }

#line 280 "src/math/simulate.birch"
birch::type::Integer birch::simulate_uniform_int(const birch::type::Integer& l, const birch::type::Integer& u) {
  #line 280 "src/math/simulate.birch"
  libbirch_function_("simulate_uniform_int", "src/math/simulate.birch", 280);
  #line 281 "src/math/simulate.birch"
  libbirch_line_(281);
  #line 281 "src/math/simulate.birch"
  libbirch_assert_(l <= u);
  #line 282 "src/math/simulate.birch"

  return std::uniform_int_distribution<birch::type::Integer>(l, u)(get_rng());
  }

#line 292 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_uniform_unit_vector(const birch::type::Integer& D) {
  #line 292 "src/math/simulate.birch"
  libbirch_function_("simulate_uniform_unit_vector", "src/math/simulate.birch", 292);
  #line 293 "src/math/simulate.birch"
  libbirch_line_(293);
  #line 293 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,1> u = libbirch::make_array<birch::type::Real>(libbirch::make_shape(D));
  #line 294 "src/math/simulate.birch"
  libbirch_line_(294);
  #line 294 "src/math/simulate.birch"
  for (auto d = birch::type::Integer(1); d <= D; ++d) {
    #line 295 "src/math/simulate.birch"
    libbirch_line_(295);
    #line 295 "src/math/simulate.birch"
    u(d) = birch::simulate_gaussian(0.0, 1.0);
  }
  #line 297 "src/math/simulate.birch"
  libbirch_line_(297);
  #line 297 "src/math/simulate.birch"
  return u / birch::dot(u);
}

#line 305 "src/math/simulate.birch"
birch::type::Real birch::simulate_exponential(const birch::type::Real& λ) {
  #line 305 "src/math/simulate.birch"
  libbirch_function_("simulate_exponential", "src/math/simulate.birch", 305);
  #line 306 "src/math/simulate.birch"
  libbirch_line_(306);
  #line 306 "src/math/simulate.birch"
  libbirch_assert_(0.0 < λ);
  #line 307 "src/math/simulate.birch"

  return std::exponential_distribution<birch::type::Real>(λ)(get_rng());
  }

#line 318 "src/math/simulate.birch"
birch::type::Real birch::simulate_weibull(const birch::type::Real& k, const birch::type::Real& λ) {
  #line 318 "src/math/simulate.birch"
  libbirch_function_("simulate_weibull", "src/math/simulate.birch", 318);
  #line 319 "src/math/simulate.birch"
  libbirch_line_(319);
  #line 319 "src/math/simulate.birch"
  libbirch_assert_(0.0 < k);
  #line 320 "src/math/simulate.birch"
  libbirch_line_(320);
  #line 320 "src/math/simulate.birch"
  libbirch_assert_(0.0 < λ);
  #line 321 "src/math/simulate.birch"

  return std::weibull_distribution<birch::type::Real>(k, λ)(get_rng());
  }

#line 332 "src/math/simulate.birch"
birch::type::Real birch::simulate_gaussian(const birch::type::Real& μ, const birch::type::Real& σ2) {
  #line 332 "src/math/simulate.birch"
  libbirch_function_("simulate_gaussian", "src/math/simulate.birch", 332);
  #line 333 "src/math/simulate.birch"
  libbirch_line_(333);
  #line 333 "src/math/simulate.birch"
  libbirch_assert_(0.0 <= σ2);
  #line 334 "src/math/simulate.birch"
  libbirch_line_(334);
  #line 334 "src/math/simulate.birch"
  if (σ2 == 0.0) {
    #line 335 "src/math/simulate.birch"
    libbirch_line_(335);
    #line 335 "src/math/simulate.birch"
    return μ;
  } else {
    #line 337 "src/math/simulate.birch"

    return std::normal_distribution<birch::type::Real>(μ, std::sqrt(σ2))(get_rng());
      }
}

#line 348 "src/math/simulate.birch"
birch::type::Real birch::simulate_student_t(const birch::type::Real& k) {
  #line 348 "src/math/simulate.birch"
  libbirch_function_("simulate_student_t", "src/math/simulate.birch", 348);
  #line 349 "src/math/simulate.birch"
  libbirch_line_(349);
  #line 349 "src/math/simulate.birch"
  libbirch_assert_(0.0 < k);
  #line 350 "src/math/simulate.birch"

  return std::student_t_distribution<birch::type::Real>(k)(get_rng());
  }

#line 362 "src/math/simulate.birch"
birch::type::Real birch::simulate_student_t(const birch::type::Real& k, const birch::type::Real& μ, const birch::type::Real& v) {
  #line 362 "src/math/simulate.birch"
  libbirch_function_("simulate_student_t", "src/math/simulate.birch", 362);
  #line 363 "src/math/simulate.birch"
  libbirch_line_(363);
  #line 363 "src/math/simulate.birch"
  libbirch_assert_(0.0 < k);
  #line 364 "src/math/simulate.birch"
  libbirch_line_(364);
  #line 364 "src/math/simulate.birch"
  libbirch_assert_(0.0 < v);
  #line 365 "src/math/simulate.birch"
  libbirch_line_(365);
  #line 365 "src/math/simulate.birch"
  auto y = birch::simulate_gaussian(0.0, v / k);
  #line 366 "src/math/simulate.birch"
  libbirch_line_(366);
  #line 366 "src/math/simulate.birch"
  auto z = birch::simulate_chi_squared(k);
  #line 367 "src/math/simulate.birch"
  libbirch_line_(367);
  #line 367 "src/math/simulate.birch"
  return μ + y / birch::sqrt(z / k);
}

#line 379 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_multivariate_student_t(const birch::type::Real& k, const libbirch::DefaultArray<birch::type::Real,1>& μ, const birch::type::LLT& U, const birch::type::Real& v) {
  #line 379 "src/math/simulate.birch"
  libbirch_function_("simulate_multivariate_student_t", "src/math/simulate.birch", 379);
  #line 381 "src/math/simulate.birch"
  libbirch_line_(381);
  #line 381 "src/math/simulate.birch"
  libbirch_assert_(0.0 < k);
  #line 382 "src/math/simulate.birch"
  libbirch_line_(382);
  #line 382 "src/math/simulate.birch"
  libbirch_assert_(0.0 < v);
  #line 383 "src/math/simulate.birch"
  libbirch_line_(383);
  #line 383 "src/math/simulate.birch"
  auto n = birch::length(μ);
  #line 384 "src/math/simulate.birch"
  libbirch_line_(384);
  #line 384 "src/math/simulate.birch"
  auto y = birch::vector(std::function<birch::type::Real(birch::type::Integer)>([=](const birch::type::Integer& i) {
    #line 385 "src/math/simulate.birch"
    libbirch_line_(385);
    #line 385 "src/math/simulate.birch"
    return birch::simulate_gaussian(0.0, v / k);
  }), n);
  #line 387 "src/math/simulate.birch"
  libbirch_line_(387);
  #line 387 "src/math/simulate.birch"
  auto z = birch::simulate_chi_squared(k);
  #line 388 "src/math/simulate.birch"
  libbirch_line_(388);
  #line 388 "src/math/simulate.birch"
  return μ + birch::cholesky(U) * y / birch::sqrt(z / k);
}

#line 400 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_multivariate_student_t(const birch::type::Real& k, const libbirch::DefaultArray<birch::type::Real,1>& μ, const birch::type::Real& u, const birch::type::LLT& V) {
  #line 400 "src/math/simulate.birch"
  libbirch_function_("simulate_multivariate_student_t", "src/math/simulate.birch", 400);
  #line 402 "src/math/simulate.birch"
  libbirch_line_(402);
  #line 402 "src/math/simulate.birch"
  auto p = birch::length(μ);
  #line 403 "src/math/simulate.birch"
  libbirch_line_(403);
  #line 403 "src/math/simulate.birch"
  auto Σ = birch::simulate_inverse_wishart(V, k + p - 1.0);
  #line 404 "src/math/simulate.birch"
  libbirch_line_(404);
  #line 404 "src/math/simulate.birch"
  return birch::simulate_multivariate_gaussian(μ, birch::llt(u * birch::canonical(Σ)));
}

#line 415 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::simulate_matrix_student_t(const birch::type::Real& k, const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const birch::type::LLT& Ψ) {
  #line 415 "src/math/simulate.birch"
  libbirch_function_("simulate_matrix_student_t", "src/math/simulate.birch", 415);
  #line 417 "src/math/simulate.birch"
  libbirch_line_(417);
  #line 417 "src/math/simulate.birch"
  auto p = birch::columns(M);
  #line 418 "src/math/simulate.birch"
  libbirch_line_(418);
  #line 418 "src/math/simulate.birch"
  auto V = birch::simulate_inverse_wishart(Ψ, k + p - 1.0);
  #line 419 "src/math/simulate.birch"
  libbirch_line_(419);
  #line 419 "src/math/simulate.birch"
  return birch::simulate_matrix_gaussian(M, U, V);
}

#line 428 "src/math/simulate.birch"
birch::type::Real birch::simulate_beta(const birch::type::Real& α, const birch::type::Real& β) {
  #line 428 "src/math/simulate.birch"
  libbirch_function_("simulate_beta", "src/math/simulate.birch", 428);
  #line 429 "src/math/simulate.birch"
  libbirch_line_(429);
  #line 429 "src/math/simulate.birch"
  libbirch_assert_(0.0 < α);
  #line 430 "src/math/simulate.birch"
  libbirch_line_(430);
  #line 430 "src/math/simulate.birch"
  libbirch_assert_(0.0 < β);
  #line 432 "src/math/simulate.birch"
  libbirch_line_(432);
  #line 432 "src/math/simulate.birch"
  birch::type::Real u = birch::simulate_gamma(α, 1.0);
  #line 433 "src/math/simulate.birch"
  libbirch_line_(433);
  #line 433 "src/math/simulate.birch"
  birch::type::Real v = birch::simulate_gamma(β, 1.0);
  #line 435 "src/math/simulate.birch"
  libbirch_line_(435);
  #line 435 "src/math/simulate.birch"
  return u / (u + v);
}

#line 443 "src/math/simulate.birch"
birch::type::Real birch::simulate_chi_squared(const birch::type::Real& ν) {
  #line 443 "src/math/simulate.birch"
  libbirch_function_("simulate_chi_squared", "src/math/simulate.birch", 443);
  #line 444 "src/math/simulate.birch"
  libbirch_line_(444);
  #line 444 "src/math/simulate.birch"
  libbirch_assert_(0.0 < ν);
  #line 445 "src/math/simulate.birch"

  return std::chi_squared_distribution<birch::type::Real>(ν)(get_rng());
  }

#line 456 "src/math/simulate.birch"
birch::type::Real birch::simulate_gamma(const birch::type::Real& k, const birch::type::Real& θ) {
  #line 456 "src/math/simulate.birch"
  libbirch_function_("simulate_gamma", "src/math/simulate.birch", 456);
  #line 457 "src/math/simulate.birch"
  libbirch_line_(457);
  #line 457 "src/math/simulate.birch"
  libbirch_assert_(0.0 < k);
  #line 458 "src/math/simulate.birch"
  libbirch_line_(458);
  #line 458 "src/math/simulate.birch"
  libbirch_assert_(0.0 < θ);
  #line 459 "src/math/simulate.birch"

  return std::gamma_distribution<birch::type::Real>(k, θ)(get_rng());
  }

#line 470 "src/math/simulate.birch"
birch::type::LLT birch::simulate_wishart(const birch::type::LLT& Ψ, const birch::type::Real& k) {
  #line 470 "src/math/simulate.birch"
  libbirch_function_("simulate_wishart", "src/math/simulate.birch", 470);
  #line 471 "src/math/simulate.birch"
  libbirch_line_(471);
  #line 471 "src/math/simulate.birch"
  libbirch_assert_(birch::rows(Ψ) == birch::columns(Ψ));
  #line 472 "src/math/simulate.birch"
  libbirch_line_(472);
  #line 472 "src/math/simulate.birch"
  libbirch_assert_(k > birch::rows(Ψ) - 1.0);
  #line 473 "src/math/simulate.birch"
  libbirch_line_(473);
  #line 473 "src/math/simulate.birch"
  auto p = birch::rows(Ψ);
  #line 474 "src/math/simulate.birch"
  libbirch_line_(474);
  #line 474 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,2> A = libbirch::make_array<birch::type::Real>(libbirch::make_shape(p, p));
  #line 476 "src/math/simulate.birch"
  libbirch_line_(476);
  #line 476 "src/math/simulate.birch"
  for (auto i = birch::type::Integer(1); i <= p; ++i) {
    #line 477 "src/math/simulate.birch"
    libbirch_line_(477);
    #line 477 "src/math/simulate.birch"
    for (auto j = birch::type::Integer(1); j <= p; ++j) {
      #line 478 "src/math/simulate.birch"
      libbirch_line_(478);
      #line 478 "src/math/simulate.birch"
      if (j == i) {
        #line 480 "src/math/simulate.birch"
        libbirch_line_(480);
        #line 480 "src/math/simulate.birch"
        A(i, j) = birch::sqrt(birch::simulate_chi_squared(k - i + 1.0));
      } else {
        #line 481 "src/math/simulate.birch"
        libbirch_line_(481);
        #line 481 "src/math/simulate.birch"
        if (j < i) {
          #line 483 "src/math/simulate.birch"
          libbirch_line_(483);
          #line 483 "src/math/simulate.birch"
          A(i, j) = birch::simulate_gaussian(0.0, 1.0);
        } else {
          #line 486 "src/math/simulate.birch"
          libbirch_line_(486);
          #line 486 "src/math/simulate.birch"
          A(i, j) = 0.0;
        }
      }
    }
  }
  #line 490 "src/math/simulate.birch"
  libbirch_line_(490);
  #line 490 "src/math/simulate.birch"
  auto L = birch::cholesky(Ψ) * A;
  #line 491 "src/math/simulate.birch"
  libbirch_line_(491);
  #line 491 "src/math/simulate.birch"
  return birch::llt(L * birch::transpose(L));
}

#line 500 "src/math/simulate.birch"
birch::type::Real birch::simulate_inverse_gamma(const birch::type::Real& α, const birch::type::Real& β) {
  #line 500 "src/math/simulate.birch"
  libbirch_function_("simulate_inverse_gamma", "src/math/simulate.birch", 500);
  #line 501 "src/math/simulate.birch"
  libbirch_line_(501);
  #line 501 "src/math/simulate.birch"
  return 1.0 / birch::simulate_gamma(α, 1.0 / β);
}

#line 510 "src/math/simulate.birch"
birch::type::LLT birch::simulate_inverse_wishart(const birch::type::LLT& Ψ, const birch::type::Real& k) {
  #line 510 "src/math/simulate.birch"
  libbirch_function_("simulate_inverse_wishart", "src/math/simulate.birch", 510);
  #line 511 "src/math/simulate.birch"
  libbirch_line_(511);
  #line 511 "src/math/simulate.birch"
  return birch::inv(birch::simulate_wishart(birch::inv(Ψ), k));
}

#line 522 "src/math/simulate.birch"
birch::type::Real birch::simulate_normal_inverse_gamma(const birch::type::Real& μ, const birch::type::Real& a2, const birch::type::Real& α, const birch::type::Real& β) {
  #line 522 "src/math/simulate.birch"
  libbirch_function_("simulate_normal_inverse_gamma", "src/math/simulate.birch", 522);
  #line 524 "src/math/simulate.birch"
  libbirch_line_(524);
  #line 524 "src/math/simulate.birch"
  return birch::simulate_student_t(2.0 * α, μ, a2 * 2.0 * β);
}

#line 533 "src/math/simulate.birch"
birch::type::Boolean birch::simulate_beta_bernoulli(const birch::type::Real& α, const birch::type::Real& β) {
  #line 533 "src/math/simulate.birch"
  libbirch_function_("simulate_beta_bernoulli", "src/math/simulate.birch", 533);
  #line 534 "src/math/simulate.birch"
  libbirch_line_(534);
  #line 534 "src/math/simulate.birch"
  libbirch_assert_(0.0 < α);
  #line 535 "src/math/simulate.birch"
  libbirch_line_(535);
  #line 535 "src/math/simulate.birch"
  libbirch_assert_(0.0 < β);
  #line 537 "src/math/simulate.birch"
  libbirch_line_(537);
  #line 537 "src/math/simulate.birch"
  return birch::simulate_bernoulli(birch::simulate_beta(α, β));
}

#line 547 "src/math/simulate.birch"
birch::type::Integer birch::simulate_beta_binomial(const birch::type::Integer& n, const birch::type::Real& α, const birch::type::Real& β) {
  #line 547 "src/math/simulate.birch"
  libbirch_function_("simulate_beta_binomial", "src/math/simulate.birch", 547);
  #line 548 "src/math/simulate.birch"
  libbirch_line_(548);
  #line 548 "src/math/simulate.birch"
  libbirch_assert_(birch::type::Integer(0) <= n);
  #line 549 "src/math/simulate.birch"
  libbirch_line_(549);
  #line 549 "src/math/simulate.birch"
  libbirch_assert_(0.0 < α);
  #line 550 "src/math/simulate.birch"
  libbirch_line_(550);
  #line 550 "src/math/simulate.birch"
  libbirch_assert_(0.0 < β);
  #line 552 "src/math/simulate.birch"
  libbirch_line_(552);
  #line 552 "src/math/simulate.birch"
  return birch::simulate_binomial(n, birch::simulate_beta(α, β));
}

#line 562 "src/math/simulate.birch"
birch::type::Integer birch::simulate_beta_negative_binomial(const birch::type::Integer& k, const birch::type::Real& α, const birch::type::Real& β) {
  #line 562 "src/math/simulate.birch"
  libbirch_function_("simulate_beta_negative_binomial", "src/math/simulate.birch", 562);
  #line 563 "src/math/simulate.birch"
  libbirch_line_(563);
  #line 563 "src/math/simulate.birch"
  libbirch_assert_(0.0 < α);
  #line 564 "src/math/simulate.birch"
  libbirch_line_(564);
  #line 564 "src/math/simulate.birch"
  libbirch_assert_(0.0 < β);
  #line 565 "src/math/simulate.birch"
  libbirch_line_(565);
  #line 565 "src/math/simulate.birch"
  libbirch_assert_(birch::type::Integer(0) < k);
  #line 567 "src/math/simulate.birch"
  libbirch_line_(567);
  #line 567 "src/math/simulate.birch"
  return birch::simulate_negative_binomial(k, birch::simulate_beta(α, β));
}

#line 577 "src/math/simulate.birch"
birch::type::Integer birch::simulate_gamma_poisson(const birch::type::Real& k, const birch::type::Real& θ) {
  #line 577 "src/math/simulate.birch"
  libbirch_function_("simulate_gamma_poisson", "src/math/simulate.birch", 577);
  #line 578 "src/math/simulate.birch"
  libbirch_line_(578);
  #line 578 "src/math/simulate.birch"
  libbirch_assert_(0.0 < k);
  #line 579 "src/math/simulate.birch"
  libbirch_line_(579);
  #line 579 "src/math/simulate.birch"
  libbirch_assert_(0.0 < θ);
  #line 580 "src/math/simulate.birch"
  libbirch_line_(580);
  #line 580 "src/math/simulate.birch"
  libbirch_assert_(k == birch::floor(k));
  #line 582 "src/math/simulate.birch"
  libbirch_line_(582);
  #line 582 "src/math/simulate.birch"
  return birch::simulate_negative_binomial(birch::Integer(k), 1.0 / (θ + 1.0));
}

#line 591 "src/math/simulate.birch"
birch::type::Real birch::simulate_lomax(const birch::type::Real& λ, const birch::type::Real& α) {
  #line 591 "src/math/simulate.birch"
  libbirch_function_("simulate_lomax", "src/math/simulate.birch", 591);
  #line 592 "src/math/simulate.birch"
  libbirch_line_(592);
  #line 592 "src/math/simulate.birch"
  libbirch_assert_(0.0 < λ);
  #line 593 "src/math/simulate.birch"
  libbirch_line_(593);
  #line 593 "src/math/simulate.birch"
  libbirch_assert_(0.0 < α);
  #line 595 "src/math/simulate.birch"
  libbirch_line_(595);
  #line 595 "src/math/simulate.birch"
  birch::type::Real u = birch::simulate_uniform(0.0, 1.0);
  #line 596 "src/math/simulate.birch"
  libbirch_line_(596);
  #line 596 "src/math/simulate.birch"
  return λ * (birch::pow(u, -(1.0) / α) - 1.0);
}

#line 604 "src/math/simulate.birch"
birch::type::Integer birch::simulate_dirichlet_categorical(const libbirch::DefaultArray<birch::type::Real,1>& α) {
  #line 604 "src/math/simulate.birch"
  libbirch_function_("simulate_dirichlet_categorical", "src/math/simulate.birch", 604);
  #line 605 "src/math/simulate.birch"
  libbirch_line_(605);
  #line 605 "src/math/simulate.birch"
  return birch::simulate_categorical(birch::simulate_dirichlet(α));
}

#line 614 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::simulate_dirichlet_multinomial(const birch::type::Integer& n, const libbirch::DefaultArray<birch::type::Real,1>& α) {
  #line 614 "src/math/simulate.birch"
  libbirch_function_("simulate_dirichlet_multinomial", "src/math/simulate.birch", 614);
  #line 615 "src/math/simulate.birch"
  libbirch_line_(615);
  #line 615 "src/math/simulate.birch"
  return birch::simulate_multinomial(n, birch::simulate_dirichlet(α));
}

#line 627 "src/math/simulate.birch"
birch::type::Integer birch::simulate_crp_categorical(const birch::type::Real& α, const birch::type::Real& θ, const libbirch::DefaultArray<birch::type::Integer,1>& n, const birch::type::Integer& N) {
  #line 627 "src/math/simulate.birch"
  libbirch_function_("simulate_crp_categorical", "src/math/simulate.birch", 627);
  #line 629 "src/math/simulate.birch"
  libbirch_line_(629);
  #line 629 "src/math/simulate.birch"
  libbirch_assert_(N >= birch::type::Integer(0));
  #line 630 "src/math/simulate.birch"
  libbirch_line_(630);
  #line 630 "src/math/simulate.birch"
  libbirch_assert_(birch::sum(n) == N);
  #line 632 "src/math/simulate.birch"
  libbirch_line_(632);
  #line 632 "src/math/simulate.birch"
  birch::type::Integer k = birch::type::Integer(0);
  #line 633 "src/math/simulate.birch"
  libbirch_line_(633);
  #line 633 "src/math/simulate.birch"
  birch::type::Integer K = birch::length(n);
  #line 634 "src/math/simulate.birch"
  libbirch_line_(634);
  #line 634 "src/math/simulate.birch"
  if (N == birch::type::Integer(0)) {
    #line 636 "src/math/simulate.birch"
    libbirch_line_(636);
    #line 636 "src/math/simulate.birch"
    k = birch::type::Integer(1);
  } else {
    #line 638 "src/math/simulate.birch"
    libbirch_line_(638);
    #line 638 "src/math/simulate.birch"
    birch::type::Real u = birch::simulate_uniform(0.0, N + θ);
    #line 639 "src/math/simulate.birch"
    libbirch_line_(639);
    #line 639 "src/math/simulate.birch"
    birch::type::Real U = K * α + θ;
    #line 640 "src/math/simulate.birch"
    libbirch_line_(640);
    #line 640 "src/math/simulate.birch"
    if (u < U) {
      #line 642 "src/math/simulate.birch"
      libbirch_line_(642);
      #line 642 "src/math/simulate.birch"
      k = K + birch::type::Integer(1);
    } else {
      #line 645 "src/math/simulate.birch"
      libbirch_line_(645);
      #line 645 "src/math/simulate.birch"
      while (k < K && u > U) {
        #line 646 "src/math/simulate.birch"
        libbirch_line_(646);
        #line 646 "src/math/simulate.birch"
        k = k + birch::type::Integer(1);
        #line 647 "src/math/simulate.birch"
        libbirch_line_(647);
        #line 647 "src/math/simulate.birch"
        U = U + n(k) - α;
      }
    }
  }
  #line 651 "src/math/simulate.birch"
  libbirch_line_(651);
  #line 651 "src/math/simulate.birch"
  return k;
}

#line 662 "src/math/simulate.birch"
birch::type::Real birch::simulate_normal_inverse_gamma_gaussian(const birch::type::Real& μ, const birch::type::Real& a2, const birch::type::Real& α, const birch::type::Real& β) {
  #line 662 "src/math/simulate.birch"
  libbirch_function_("simulate_normal_inverse_gamma_gaussian", "src/math/simulate.birch", 662);
  #line 664 "src/math/simulate.birch"
  libbirch_line_(664);
  #line 664 "src/math/simulate.birch"
  return birch::simulate_student_t(2.0 * α, μ, 2.0 * β * (1.0 + a2));
}

#line 677 "src/math/simulate.birch"
birch::type::Real birch::simulate_linear_normal_inverse_gamma_gaussian(const birch::type::Real& a, const birch::type::Real& μ, const birch::type::Real& a2, const birch::type::Real& c, const birch::type::Real& α, const birch::type::Real& β) {
  #line 677 "src/math/simulate.birch"
  libbirch_function_("simulate_linear_normal_inverse_gamma_gaussian", "src/math/simulate.birch", 677);
  #line 679 "src/math/simulate.birch"
  libbirch_line_(679);
  #line 679 "src/math/simulate.birch"
  return birch::simulate_student_t(2.0 * α, a * μ + c, 2.0 * β * (1.0 + a * a * a2));
}

#line 688 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& μ, const birch::type::LLT& Σ) {
  #line 688 "src/math/simulate.birch"
  libbirch_function_("simulate_multivariate_gaussian", "src/math/simulate.birch", 688);
  #line 689 "src/math/simulate.birch"
  libbirch_line_(689);
  #line 689 "src/math/simulate.birch"
  auto D = birch::length(μ);
  #line 690 "src/math/simulate.birch"
  libbirch_line_(690);
  #line 690 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,1> z = libbirch::make_array<birch::type::Real>(libbirch::make_shape(D));
  #line 691 "src/math/simulate.birch"
  libbirch_line_(691);
  #line 691 "src/math/simulate.birch"
  for (auto d = birch::type::Integer(1); d <= D; ++d) {
    #line 692 "src/math/simulate.birch"
    libbirch_line_(692);
    #line 692 "src/math/simulate.birch"
    z(d) = birch::simulate_gaussian(0.0, 1.0);
  }
  #line 694 "src/math/simulate.birch"
  libbirch_line_(694);
  #line 694 "src/math/simulate.birch"
  return μ + birch::cholesky(Σ) * z;
}

#line 703 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& μ, const libbirch::DefaultArray<birch::type::Real,1>& σ2) {
  #line 703 "src/math/simulate.birch"
  libbirch_function_("simulate_multivariate_gaussian", "src/math/simulate.birch", 703);
  #line 704 "src/math/simulate.birch"
  libbirch_line_(704);
  #line 704 "src/math/simulate.birch"
  auto D = birch::length(μ);
  #line 705 "src/math/simulate.birch"
  libbirch_line_(705);
  #line 705 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,1> z = libbirch::make_array<birch::type::Real>(libbirch::make_shape(D));
  #line 706 "src/math/simulate.birch"
  libbirch_line_(706);
  #line 706 "src/math/simulate.birch"
  for (auto d = birch::type::Integer(1); d <= D; ++d) {
    #line 707 "src/math/simulate.birch"
    libbirch_line_(707);
    #line 707 "src/math/simulate.birch"
    z(d) = μ(d) + birch::simulate_gaussian(0.0, σ2(d));
  }
  #line 709 "src/math/simulate.birch"
  libbirch_line_(709);
  #line 709 "src/math/simulate.birch"
  return z;
}

#line 719 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& μ, const birch::type::Real& σ2) {
  #line 719 "src/math/simulate.birch"
  libbirch_function_("simulate_multivariate_gaussian", "src/math/simulate.birch", 719);
  #line 720 "src/math/simulate.birch"
  libbirch_line_(720);
  #line 720 "src/math/simulate.birch"
  auto D = birch::length(μ);
  #line 721 "src/math/simulate.birch"
  libbirch_line_(721);
  #line 721 "src/math/simulate.birch"
  auto σ = birch::sqrt(σ2);
  #line 722 "src/math/simulate.birch"
  libbirch_line_(722);
  #line 722 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,1> z = libbirch::make_array<birch::type::Real>(libbirch::make_shape(D));
  #line 723 "src/math/simulate.birch"
  libbirch_line_(723);
  #line 723 "src/math/simulate.birch"
  for (auto d = birch::type::Integer(1); d <= D; ++d) {
    #line 724 "src/math/simulate.birch"
    libbirch_line_(724);
    #line 724 "src/math/simulate.birch"
    z(d) = μ(d) + σ * birch::simulate_gaussian(0.0, 1.0);
  }
  #line 726 "src/math/simulate.birch"
  libbirch_line_(726);
  #line 726 "src/math/simulate.birch"
  return z;
}

#line 737 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_multivariate_normal_inverse_gamma(const libbirch::DefaultArray<birch::type::Real,1>& ν, const birch::type::LLT& Λ, const birch::type::Real& α, const birch::type::Real& β) {
  #line 737 "src/math/simulate.birch"
  libbirch_function_("simulate_multivariate_normal_inverse_gamma", "src/math/simulate.birch", 737);
  #line 739 "src/math/simulate.birch"
  libbirch_line_(739);
  #line 739 "src/math/simulate.birch"
  return birch::simulate_multivariate_student_t(2.0 * α, birch::solve(Λ, ν), birch::inv(Λ), 2.0 * β);
}

#line 752 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_multivariate_normal_inverse_gamma_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& ν, const birch::type::LLT& Λ, const birch::type::Real& α, const birch::type::Real& γ) {
  #line 752 "src/math/simulate.birch"
  libbirch_function_("simulate_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/math/simulate.birch", 752);
  #line 754 "src/math/simulate.birch"
  libbirch_line_(754);
  #line 754 "src/math/simulate.birch"
  auto n = birch::length(ν);
  #line 755 "src/math/simulate.birch"
  libbirch_line_(755);
  #line 755 "src/math/simulate.birch"
  auto μ = birch::solve(Λ, ν);
  #line 756 "src/math/simulate.birch"
  libbirch_line_(756);
  #line 756 "src/math/simulate.birch"
  auto β = γ - 0.5 * birch::dot(μ, ν);
  #line 758 "src/math/simulate.birch"
  libbirch_line_(758);
  #line 758 "src/math/simulate.birch"
  return birch::simulate_multivariate_student_t(2.0 * α, μ, birch::llt(birch::identity(n) + birch::canonical(birch::inv(Λ))), 2.0 * β);
}

#line 773 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& A, const libbirch::DefaultArray<birch::type::Real,1>& ν, const birch::type::LLT& Λ, const libbirch::DefaultArray<birch::type::Real,1>& c, const birch::type::Real& α, const birch::type::Real& γ) {
  #line 773 "src/math/simulate.birch"
  libbirch_function_("simulate_linear_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/math/simulate.birch", 773);
  #line 775 "src/math/simulate.birch"
  libbirch_line_(775);
  #line 775 "src/math/simulate.birch"
  auto n = birch::rows(A);
  #line 776 "src/math/simulate.birch"
  libbirch_line_(776);
  #line 776 "src/math/simulate.birch"
  auto μ = birch::solve(Λ, ν);
  #line 777 "src/math/simulate.birch"
  libbirch_line_(777);
  #line 777 "src/math/simulate.birch"
  auto β = γ - 0.5 * birch::dot(μ, ν);
  #line 778 "src/math/simulate.birch"
  libbirch_line_(778);
  #line 778 "src/math/simulate.birch"
  return birch::simulate_multivariate_student_t(2.0 * α, A * μ + c, birch::llt(birch::identity(n) + A * birch::solve(Λ, birch::transpose(A))), 2.0 * β);
}

#line 793 "src/math/simulate.birch"
birch::type::Real birch::simulate_linear_multivariate_normal_inverse_gamma_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& a, const libbirch::DefaultArray<birch::type::Real,1>& ν, const birch::type::LLT& Λ, const birch::type::Real& c, const birch::type::Real& α, const birch::type::Real& γ) {
  #line 793 "src/math/simulate.birch"
  libbirch_function_("simulate_linear_multivariate_normal_inverse_gamma_gaussian", "src/math/simulate.birch", 793);
  #line 795 "src/math/simulate.birch"
  libbirch_line_(795);
  #line 795 "src/math/simulate.birch"
  auto μ = birch::solve(Λ, ν);
  #line 796 "src/math/simulate.birch"
  libbirch_line_(796);
  #line 796 "src/math/simulate.birch"
  auto β = γ - 0.5 * birch::dot(μ, ν);
  #line 797 "src/math/simulate.birch"
  libbirch_line_(797);
  #line 797 "src/math/simulate.birch"
  return birch::simulate_student_t(2.0 * α, birch::dot(a, μ) + c, 2.0 * β * (1.0 + birch::dot(a, birch::solve(Λ, a))));
}

#line 808 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::simulate_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const birch::type::LLT& V) {
  #line 808 "src/math/simulate.birch"
  libbirch_function_("simulate_matrix_gaussian", "src/math/simulate.birch", 808);
  #line 809 "src/math/simulate.birch"
  libbirch_line_(809);
  #line 809 "src/math/simulate.birch"
  libbirch_assert_(birch::rows(M) == birch::rows(U));
  #line 810 "src/math/simulate.birch"
  libbirch_line_(810);
  #line 810 "src/math/simulate.birch"
  libbirch_assert_(birch::rows(M) == birch::columns(U));
  #line 811 "src/math/simulate.birch"
  libbirch_line_(811);
  #line 811 "src/math/simulate.birch"
  libbirch_assert_(birch::columns(M) == birch::rows(V));
  #line 812 "src/math/simulate.birch"
  libbirch_line_(812);
  #line 812 "src/math/simulate.birch"
  libbirch_assert_(birch::columns(M) == birch::columns(V));
  #line 814 "src/math/simulate.birch"
  libbirch_line_(814);
  #line 814 "src/math/simulate.birch"
  auto N = birch::rows(M);
  #line 815 "src/math/simulate.birch"
  libbirch_line_(815);
  #line 815 "src/math/simulate.birch"
  auto P = birch::columns(M);
  #line 816 "src/math/simulate.birch"
  libbirch_line_(816);
  #line 816 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,2> Z = libbirch::make_array<birch::type::Real>(libbirch::make_shape(N, P));
  #line 817 "src/math/simulate.birch"
  libbirch_line_(817);
  #line 817 "src/math/simulate.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 818 "src/math/simulate.birch"
    libbirch_line_(818);
    #line 818 "src/math/simulate.birch"
    for (auto p = birch::type::Integer(1); p <= P; ++p) {
      #line 819 "src/math/simulate.birch"
      libbirch_line_(819);
      #line 819 "src/math/simulate.birch"
      Z(n, p) = birch::simulate_gaussian(0.0, 1.0);
    }
  }
  #line 822 "src/math/simulate.birch"
  libbirch_line_(822);
  #line 822 "src/math/simulate.birch"
  return M + birch::cholesky(U) * Z * birch::transpose(birch::cholesky(V));
}

#line 832 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::simulate_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const libbirch::DefaultArray<birch::type::Real,1>& σ2) {
  #line 832 "src/math/simulate.birch"
  libbirch_function_("simulate_matrix_gaussian", "src/math/simulate.birch", 832);
  #line 834 "src/math/simulate.birch"
  libbirch_line_(834);
  #line 834 "src/math/simulate.birch"
  libbirch_assert_(birch::rows(M) == birch::rows(U));
  #line 835 "src/math/simulate.birch"
  libbirch_line_(835);
  #line 835 "src/math/simulate.birch"
  libbirch_assert_(birch::rows(M) == birch::columns(U));
  #line 836 "src/math/simulate.birch"
  libbirch_line_(836);
  #line 836 "src/math/simulate.birch"
  libbirch_assert_(birch::columns(M) == birch::length(σ2));
  #line 838 "src/math/simulate.birch"
  libbirch_line_(838);
  #line 838 "src/math/simulate.birch"
  auto N = birch::rows(M);
  #line 839 "src/math/simulate.birch"
  libbirch_line_(839);
  #line 839 "src/math/simulate.birch"
  auto P = birch::columns(M);
  #line 840 "src/math/simulate.birch"
  libbirch_line_(840);
  #line 840 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,2> Z = libbirch::make_array<birch::type::Real>(libbirch::make_shape(N, P));
  #line 841 "src/math/simulate.birch"
  libbirch_line_(841);
  #line 841 "src/math/simulate.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 842 "src/math/simulate.birch"
    libbirch_line_(842);
    #line 842 "src/math/simulate.birch"
    for (auto p = birch::type::Integer(1); p <= P; ++p) {
      #line 843 "src/math/simulate.birch"
      libbirch_line_(843);
      #line 843 "src/math/simulate.birch"
      Z(n, p) = birch::simulate_gaussian(0.0, 1.0);
    }
  }
  #line 846 "src/math/simulate.birch"
  libbirch_line_(846);
  #line 846 "src/math/simulate.birch"
  return M + birch::cholesky(U) * Z * birch::diagonal(birch::sqrt(σ2));
}

#line 855 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::simulate_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& V) {
  #line 855 "src/math/simulate.birch"
  libbirch_function_("simulate_matrix_gaussian", "src/math/simulate.birch", 855);
  #line 856 "src/math/simulate.birch"
  libbirch_line_(856);
  #line 856 "src/math/simulate.birch"
  libbirch_assert_(birch::columns(M) == birch::rows(V));
  #line 857 "src/math/simulate.birch"
  libbirch_line_(857);
  #line 857 "src/math/simulate.birch"
  libbirch_assert_(birch::columns(M) == birch::columns(V));
  #line 859 "src/math/simulate.birch"
  libbirch_line_(859);
  #line 859 "src/math/simulate.birch"
  auto N = birch::rows(M);
  #line 860 "src/math/simulate.birch"
  libbirch_line_(860);
  #line 860 "src/math/simulate.birch"
  auto P = birch::columns(M);
  #line 861 "src/math/simulate.birch"
  libbirch_line_(861);
  #line 861 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,2> Z = libbirch::make_array<birch::type::Real>(libbirch::make_shape(N, P));
  #line 862 "src/math/simulate.birch"
  libbirch_line_(862);
  #line 862 "src/math/simulate.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 863 "src/math/simulate.birch"
    libbirch_line_(863);
    #line 863 "src/math/simulate.birch"
    for (auto p = birch::type::Integer(1); p <= P; ++p) {
      #line 864 "src/math/simulate.birch"
      libbirch_line_(864);
      #line 864 "src/math/simulate.birch"
      Z(n, p) = birch::simulate_gaussian(0.0, 1.0);
    }
  }
  #line 867 "src/math/simulate.birch"
  libbirch_line_(867);
  #line 867 "src/math/simulate.birch"
  return M + Z * birch::transpose(birch::cholesky(V));
}

#line 876 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::simulate_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::DefaultArray<birch::type::Real,1>& σ2) {
  #line 876 "src/math/simulate.birch"
  libbirch_function_("simulate_matrix_gaussian", "src/math/simulate.birch", 876);
  #line 877 "src/math/simulate.birch"
  libbirch_line_(877);
  #line 877 "src/math/simulate.birch"
  libbirch_assert_(birch::columns(M) == birch::length(σ2));
  #line 879 "src/math/simulate.birch"
  libbirch_line_(879);
  #line 879 "src/math/simulate.birch"
  auto N = birch::rows(M);
  #line 880 "src/math/simulate.birch"
  libbirch_line_(880);
  #line 880 "src/math/simulate.birch"
  auto P = birch::columns(M);
  #line 881 "src/math/simulate.birch"
  libbirch_line_(881);
  #line 881 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,2> X = libbirch::make_array<birch::type::Real>(libbirch::make_shape(N, P));
  #line 882 "src/math/simulate.birch"
  libbirch_line_(882);
  #line 882 "src/math/simulate.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 883 "src/math/simulate.birch"
    libbirch_line_(883);
    #line 883 "src/math/simulate.birch"
    for (auto p = birch::type::Integer(1); p <= P; ++p) {
      #line 884 "src/math/simulate.birch"
      libbirch_line_(884);
      #line 884 "src/math/simulate.birch"
      X(n, p) = birch::simulate_gaussian(M(n, p), σ2(p));
    }
  }
  #line 887 "src/math/simulate.birch"
  libbirch_line_(887);
  #line 887 "src/math/simulate.birch"
  return X;
}

#line 897 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::simulate_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::Real& σ2) {
  #line 897 "src/math/simulate.birch"
  libbirch_function_("simulate_matrix_gaussian", "src/math/simulate.birch", 897);
  #line 898 "src/math/simulate.birch"
  libbirch_line_(898);
  #line 898 "src/math/simulate.birch"
  auto N = birch::rows(M);
  #line 899 "src/math/simulate.birch"
  libbirch_line_(899);
  #line 899 "src/math/simulate.birch"
  auto P = birch::columns(M);
  #line 900 "src/math/simulate.birch"
  libbirch_line_(900);
  #line 900 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,2> X = libbirch::make_array<birch::type::Real>(libbirch::make_shape(N, P));
  #line 901 "src/math/simulate.birch"
  libbirch_line_(901);
  #line 901 "src/math/simulate.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 902 "src/math/simulate.birch"
    libbirch_line_(902);
    #line 902 "src/math/simulate.birch"
    for (auto p = birch::type::Integer(1); p <= P; ++p) {
      #line 903 "src/math/simulate.birch"
      libbirch_line_(903);
      #line 903 "src/math/simulate.birch"
      X(n, p) = birch::simulate_gaussian(M(n, p), σ2);
    }
  }
  #line 906 "src/math/simulate.birch"
  libbirch_line_(906);
  #line 906 "src/math/simulate.birch"
  return X;
}

#line 917 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::simulate_matrix_normal_inverse_wishart(const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& Λ, const birch::type::LLT& Ψ, const birch::type::Real& k) {
  #line 917 "src/math/simulate.birch"
  libbirch_function_("simulate_matrix_normal_inverse_wishart", "src/math/simulate.birch", 917);
  #line 919 "src/math/simulate.birch"
  libbirch_line_(919);
  #line 919 "src/math/simulate.birch"
  auto p = birch::columns(N);
  #line 920 "src/math/simulate.birch"
  libbirch_line_(920);
  #line 920 "src/math/simulate.birch"
  auto M = birch::solve(Λ, N);
  #line 921 "src/math/simulate.birch"
  libbirch_line_(921);
  #line 921 "src/math/simulate.birch"
  return birch::simulate_matrix_student_t(k - p + 1.0, M, birch::inv(Λ), Ψ);
}

#line 932 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::simulate_matrix_normal_inverse_wishart_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& Λ, const birch::type::LLT& Ψ, const birch::type::Real& k) {
  #line 932 "src/math/simulate.birch"
  libbirch_function_("simulate_matrix_normal_inverse_wishart_matrix_gaussian", "src/math/simulate.birch", 932);
  #line 934 "src/math/simulate.birch"
  libbirch_line_(934);
  #line 934 "src/math/simulate.birch"
  auto n = birch::rows(N);
  #line 935 "src/math/simulate.birch"
  libbirch_line_(935);
  #line 935 "src/math/simulate.birch"
  auto p = birch::columns(N);
  #line 936 "src/math/simulate.birch"
  libbirch_line_(936);
  #line 936 "src/math/simulate.birch"
  auto M = birch::solve(Λ, N);
  #line 937 "src/math/simulate.birch"
  libbirch_line_(937);
  #line 937 "src/math/simulate.birch"
  auto Σ = birch::llt(birch::identity(n) + birch::canonical(birch::inv(Λ)));
  #line 938 "src/math/simulate.birch"
  libbirch_line_(938);
  #line 938 "src/math/simulate.birch"
  return birch::simulate_matrix_student_t(k - p + 1.0, M, Σ, Ψ);
}

#line 952 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::simulate_linear_matrix_normal_inverse_wishart_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& A, const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& Λ, const libbirch::DefaultArray<birch::type::Real,2>& C, const birch::type::LLT& Ψ, const birch::type::Real& k) {
  #line 952 "src/math/simulate.birch"
  libbirch_function_("simulate_linear_matrix_normal_inverse_wishart_matrix_gaussian", "src/math/simulate.birch", 952);
  #line 955 "src/math/simulate.birch"
  libbirch_line_(955);
  #line 955 "src/math/simulate.birch"
  auto n = birch::rows(A);
  #line 956 "src/math/simulate.birch"
  libbirch_line_(956);
  #line 956 "src/math/simulate.birch"
  auto p = birch::columns(N);
  #line 957 "src/math/simulate.birch"
  libbirch_line_(957);
  #line 957 "src/math/simulate.birch"
  auto M = birch::solve(Λ, N);
  #line 958 "src/math/simulate.birch"
  libbirch_line_(958);
  #line 958 "src/math/simulate.birch"
  auto Σ = birch::llt(birch::identity(n) + A * birch::solve(Λ, birch::transpose(A)));
  #line 959 "src/math/simulate.birch"
  libbirch_line_(959);
  #line 959 "src/math/simulate.birch"
  return birch::simulate_matrix_student_t(k - p + 1.0, A * M + C, Σ, Ψ);
}

#line 973 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_linear_matrix_normal_inverse_wishart_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& a, const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& Λ, const libbirch::DefaultArray<birch::type::Real,1>& c, const birch::type::LLT& Ψ, const birch::type::Real& k) {
  #line 973 "src/math/simulate.birch"
  libbirch_function_("simulate_linear_matrix_normal_inverse_wishart_multivariate_gaussian", "src/math/simulate.birch", 973);
  #line 975 "src/math/simulate.birch"
  libbirch_line_(975);
  #line 975 "src/math/simulate.birch"
  auto p = birch::columns(N);
  #line 976 "src/math/simulate.birch"
  libbirch_line_(976);
  #line 976 "src/math/simulate.birch"
  auto M = birch::solve(Λ, N);
  #line 977 "src/math/simulate.birch"
  libbirch_line_(977);
  #line 977 "src/math/simulate.birch"
  auto σ2 = 1.0 + birch::dot(a, birch::solve(Λ, a));
  #line 978 "src/math/simulate.birch"
  libbirch_line_(978);
  #line 978 "src/math/simulate.birch"
  return birch::simulate_multivariate_student_t(k - p + 1.0, birch::dot(a, M) + c, σ2, Ψ);
}

#line 987 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_independent_uniform(const libbirch::DefaultArray<birch::type::Real,1>& l, const libbirch::DefaultArray<birch::type::Real,1>& u) {
  #line 987 "src/math/simulate.birch"
  libbirch_function_("simulate_independent_uniform", "src/math/simulate.birch", 987);
  #line 988 "src/math/simulate.birch"
  libbirch_line_(988);
  #line 988 "src/math/simulate.birch"
  libbirch_assert_(birch::length(l) == birch::length(u));
  #line 989 "src/math/simulate.birch"
  libbirch_line_(989);
  #line 989 "src/math/simulate.birch"
  birch::type::Integer D = birch::length(l);
  #line 990 "src/math/simulate.birch"
  libbirch_line_(990);
  #line 990 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,1> z = libbirch::make_array<birch::type::Real>(libbirch::make_shape(D));
  #line 991 "src/math/simulate.birch"
  libbirch_line_(991);
  #line 991 "src/math/simulate.birch"
  for (auto d = birch::type::Integer(1); d <= D; ++d) {
    #line 992 "src/math/simulate.birch"
    libbirch_line_(992);
    #line 992 "src/math/simulate.birch"
    z(d) = birch::simulate_uniform(l(d), u(d));
  }
  #line 994 "src/math/simulate.birch"
  libbirch_line_(994);
  #line 994 "src/math/simulate.birch"
  return z;
}

#line 1003 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::simulate_independent_uniform_int(const libbirch::DefaultArray<birch::type::Integer,1>& l, const libbirch::DefaultArray<birch::type::Integer,1>& u) {
  #line 1003 "src/math/simulate.birch"
  libbirch_function_("simulate_independent_uniform_int", "src/math/simulate.birch", 1003);
  #line 1005 "src/math/simulate.birch"
  libbirch_line_(1005);
  #line 1005 "src/math/simulate.birch"
  libbirch_assert_(birch::length(l) == birch::length(u));
  #line 1006 "src/math/simulate.birch"
  libbirch_line_(1006);
  #line 1006 "src/math/simulate.birch"
  birch::type::Integer D = birch::length(l);
  #line 1007 "src/math/simulate.birch"
  libbirch_line_(1007);
  #line 1007 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Integer,1> z = libbirch::make_array<birch::type::Integer>(libbirch::make_shape(D));
  #line 1008 "src/math/simulate.birch"
  libbirch_line_(1008);
  #line 1008 "src/math/simulate.birch"
  for (auto d = birch::type::Integer(1); d <= D; ++d) {
    #line 1009 "src/math/simulate.birch"
    libbirch_line_(1009);
    #line 1009 "src/math/simulate.birch"
    z(d) = birch::simulate_uniform_int(l(d), u(d));
  }
  #line 1011 "src/math/simulate.birch"
  libbirch_line_(1011);
  #line 1011 "src/math/simulate.birch"
  return z;
}

#line 1 "src/math/special.birch"

#include <boost/math/special_functions.hpp>
#line 8 "src/math/special.birch"
birch::type::Real64 birch::gamma(const birch::type::Real64& x) {
  #line 8 "src/math/special.birch"
  libbirch_function_("gamma", "src/math/special.birch", 8);
  #line 9 "src/math/special.birch"

  return ::tgamma(x);
  }

#line 17 "src/math/special.birch"
birch::type::Real32 birch::gamma(const birch::type::Real32& x) {
  #line 17 "src/math/special.birch"
  libbirch_function_("gamma", "src/math/special.birch", 17);
  #line 18 "src/math/special.birch"

  return ::tgammaf(x);
  }

#line 26 "src/math/special.birch"
birch::type::Real64 birch::lgamma(const birch::type::Real64& x) {
  #line 26 "src/math/special.birch"
  libbirch_function_("lgamma", "src/math/special.birch", 26);
  #line 27 "src/math/special.birch"

  return ::lgamma(x);
  }

#line 35 "src/math/special.birch"
birch::type::Real32 birch::lgamma(const birch::type::Real32& x) {
  #line 35 "src/math/special.birch"
  libbirch_function_("lgamma", "src/math/special.birch", 35);
  #line 36 "src/math/special.birch"

  return ::lgammaf(x);
  }

#line 44 "src/math/special.birch"
birch::type::Real64 birch::gamma(const birch::type::Real64& x, const birch::type::Integer& p) {
  #line 44 "src/math/special.birch"
  libbirch_function_("gamma", "src/math/special.birch", 44);
  #line 45 "src/math/special.birch"
  libbirch_line_(45);
  #line 45 "src/math/special.birch"
  libbirch_assert_(p > birch::type::Integer(0));
  #line 46 "src/math/special.birch"
  libbirch_line_(46);
  #line 46 "src/math/special.birch"
  auto y = 0.25 * (p * (p - birch::type::Integer(1))) * birch::log(birch::π());
  #line 47 "src/math/special.birch"
  libbirch_line_(47);
  #line 47 "src/math/special.birch"
  for (auto i = birch::type::Integer(1); i <= p; ++i) {
    #line 48 "src/math/special.birch"
    libbirch_line_(48);
    #line 48 "src/math/special.birch"
    y = y * birch::gamma(x + 0.5 * (birch::type::Integer(1) - i));
  }
  #line 50 "src/math/special.birch"
  libbirch_line_(50);
  #line 50 "src/math/special.birch"
  return y;
}

#line 54 "src/math/special.birch"
birch::type::Real64 birch::expm1(const birch::type::Real64& x) {
  #line 54 "src/math/special.birch"
  libbirch_function_("expm1", "src/math/special.birch", 54);
  #line 55 "src/math/special.birch"

    return ::expm1(x);
    }

#line 60 "src/math/special.birch"
birch::type::Real32 birch::expm1(const birch::type::Real32& x) {
  #line 60 "src/math/special.birch"
  libbirch_function_("expm1", "src/math/special.birch", 60);
  #line 61 "src/math/special.birch"

    return ::expm1f(x);
    }

#line 70 "src/math/special.birch"
birch::type::Real32 birch::gamma(const birch::type::Real32& x, const birch::type::Integer& p) {
  #line 70 "src/math/special.birch"
  libbirch_function_("gamma", "src/math/special.birch", 70);
  #line 71 "src/math/special.birch"
  libbirch_line_(71);
  #line 71 "src/math/special.birch"
  libbirch_assert_(p > birch::type::Integer(0));
  #line 72 "src/math/special.birch"
  libbirch_line_(72);
  #line 72 "src/math/special.birch"
  auto y = birch::Real32(0.25) * birch::Real32(p * (p - birch::type::Integer(1))) * birch::log(birch::Real32(birch::π()));
  #line 73 "src/math/special.birch"
  libbirch_line_(73);
  #line 73 "src/math/special.birch"
  for (auto i = birch::type::Integer(1); i <= p; ++i) {
    #line 74 "src/math/special.birch"
    libbirch_line_(74);
    #line 74 "src/math/special.birch"
    y = y * birch::gamma(x + birch::Real32(0.5) * birch::Real32(birch::type::Integer(1) - i));
  }
  #line 76 "src/math/special.birch"
  libbirch_line_(76);
  #line 76 "src/math/special.birch"
  return y;
}

#line 82 "src/math/special.birch"
birch::type::Real64 birch::lgamma(const birch::type::Real64& x, const birch::type::Integer& p) {
  #line 82 "src/math/special.birch"
  libbirch_function_("lgamma", "src/math/special.birch", 82);
  #line 83 "src/math/special.birch"
  libbirch_line_(83);
  #line 83 "src/math/special.birch"
  libbirch_assert_(p > birch::type::Integer(0));
  #line 84 "src/math/special.birch"
  libbirch_line_(84);
  #line 84 "src/math/special.birch"
  auto y = 0.25 * (p * (p - birch::type::Integer(1))) * birch::log(birch::π());
  #line 85 "src/math/special.birch"
  libbirch_line_(85);
  #line 85 "src/math/special.birch"
  for (auto i = birch::type::Integer(1); i <= p; ++i) {
    #line 86 "src/math/special.birch"
    libbirch_line_(86);
    #line 86 "src/math/special.birch"
    y = y + birch::lgamma(x + 0.5 * (birch::type::Integer(1) - i));
  }
  #line 88 "src/math/special.birch"
  libbirch_line_(88);
  #line 88 "src/math/special.birch"
  return y;
}

#line 94 "src/math/special.birch"
birch::type::Real32 birch::lgamma(const birch::type::Real32& x, const birch::type::Integer& p) {
  #line 94 "src/math/special.birch"
  libbirch_function_("lgamma", "src/math/special.birch", 94);
  #line 95 "src/math/special.birch"
  libbirch_line_(95);
  #line 95 "src/math/special.birch"
  libbirch_assert_(p > birch::type::Integer(0));
  #line 96 "src/math/special.birch"
  libbirch_line_(96);
  #line 96 "src/math/special.birch"
  auto y = birch::Real32(0.25) * birch::Real32(p * (p - birch::type::Integer(1))) * birch::log(birch::Real32(birch::π()));
  #line 97 "src/math/special.birch"
  libbirch_line_(97);
  #line 97 "src/math/special.birch"
  for (auto i = birch::type::Integer(1); i <= p; ++i) {
    #line 98 "src/math/special.birch"
    libbirch_line_(98);
    #line 98 "src/math/special.birch"
    y = y + birch::lgamma(x + birch::Real32(0.5) * birch::Real32(birch::type::Integer(1) - i));
  }
  #line 100 "src/math/special.birch"
  libbirch_line_(100);
  #line 100 "src/math/special.birch"
  return y;
}

#line 106 "src/math/special.birch"
birch::type::Real64 birch::beta(const birch::type::Real64& x, const birch::type::Real64& y) {
  #line 106 "src/math/special.birch"
  libbirch_function_("beta", "src/math/special.birch", 106);
  #line 107 "src/math/special.birch"
  libbirch_line_(107);
  #line 107 "src/math/special.birch"
  return (birch::gamma(x) * birch::gamma(y)) / (birch::gamma(x + y));
}

#line 113 "src/math/special.birch"
birch::type::Real32 birch::beta(const birch::type::Real32& x, const birch::type::Real32& y) {
  #line 113 "src/math/special.birch"
  libbirch_function_("beta", "src/math/special.birch", 113);
  #line 114 "src/math/special.birch"
  libbirch_line_(114);
  #line 114 "src/math/special.birch"
  return (birch::gamma(x) * birch::gamma(y)) / (birch::gamma(x + y));
}

#line 122 "src/math/special.birch"
birch::type::Real birch::ibeta(const birch::type::Real& a, const birch::type::Real& b, const birch::type::Real& x) {
  #line 122 "src/math/special.birch"
  libbirch_function_("ibeta", "src/math/special.birch", 122);
  #line 123 "src/math/special.birch"
  libbirch_line_(123);
  #line 123 "src/math/special.birch"
  if (x < 0.0 || x > 1.0) {
    #line 124 "src/math/special.birch"
    libbirch_line_(124);
    #line 124 "src/math/special.birch"
    return birch::inf();
  }
  #line 127 "src/math/special.birch"
  libbirch_line_(127);
  #line 127 "src/math/special.birch"
  if (x > ((a + 1.0) / (a + b + 2.0))) {
    #line 128 "src/math/special.birch"
    libbirch_line_(128);
    #line 128 "src/math/special.birch"
    return 1.0 - birch::ibeta(b, a, 1.0 - x);
  }
  #line 132 "src/math/special.birch"
  libbirch_line_(132);
  #line 132 "src/math/special.birch"
  auto STOP = 1.0e-8;
  #line 135 "src/math/special.birch"
  libbirch_line_(135);
  #line 135 "src/math/special.birch"
  auto TINY = 1.0e-30;
  #line 137 "src/math/special.birch"
  libbirch_line_(137);
  #line 137 "src/math/special.birch"
  auto lbeta_ab = birch::lgamma(a) + birch::lgamma(b) - birch::lgamma(a + b);
  #line 138 "src/math/special.birch"
  libbirch_line_(138);
  #line 138 "src/math/special.birch"
  auto front = birch::exp(birch::log(x) * a + birch::log(1.0 - x) * b - lbeta_ab) / a;
  #line 141 "src/math/special.birch"
  libbirch_line_(141);
  #line 141 "src/math/special.birch"
  auto f = 1.0;
  #line 142 "src/math/special.birch"
  libbirch_line_(142);
  #line 142 "src/math/special.birch"
  auto c = 1.0;
  #line 143 "src/math/special.birch"
  libbirch_line_(143);
  #line 143 "src/math/special.birch"
  auto d = 0.0;
  #line 144 "src/math/special.birch"
  libbirch_line_(144);
  #line 144 "src/math/special.birch"
  auto numerator = 0.0;
  #line 146 "src/math/special.birch"
  libbirch_line_(146);
  #line 146 "src/math/special.birch"
  for (auto i = birch::type::Integer(0); i <= birch::type::Integer(200); ++i) {
    #line 147 "src/math/special.birch"
    libbirch_line_(147);
    #line 147 "src/math/special.birch"
    auto m = i / birch::type::Integer(2);
    #line 149 "src/math/special.birch"
    libbirch_line_(149);
    #line 149 "src/math/special.birch"
    if (i == birch::type::Integer(0)) {
      #line 150 "src/math/special.birch"
      libbirch_line_(150);
      #line 150 "src/math/special.birch"
      numerator = 1.0;
    } else {
      #line 151 "src/math/special.birch"
      libbirch_line_(151);
      #line 151 "src/math/special.birch"
      if (birch::mod(i, birch::type::Integer(2)) == birch::type::Integer(0)) {
        #line 152 "src/math/special.birch"
        libbirch_line_(152);
        #line 152 "src/math/special.birch"
        numerator = (m * (b - m) * x) / ((a + 2.0 * m - 1.0) * (a + 2.0 * m));
      } else {
        #line 154 "src/math/special.birch"
        libbirch_line_(154);
        #line 154 "src/math/special.birch"
        numerator = -(((a + m) * (a + b + m) * x)) / ((a + 2.0 * m) * (a + 2.0 * m + 1.0));
      }
    }
    #line 157 "src/math/special.birch"
    libbirch_line_(157);
    #line 157 "src/math/special.birch"
    d = 1.0 + numerator * d;
    #line 158 "src/math/special.birch"
    libbirch_line_(158);
    #line 158 "src/math/special.birch"
    if (birch::abs(d) < TINY) {
      #line 159 "src/math/special.birch"
      libbirch_line_(159);
      #line 159 "src/math/special.birch"
      d = TINY;
    }
    #line 161 "src/math/special.birch"
    libbirch_line_(161);
    #line 161 "src/math/special.birch"
    d = 1.0 / d;
    #line 163 "src/math/special.birch"
    libbirch_line_(163);
    #line 163 "src/math/special.birch"
    c = 1.0 + numerator / c;
    #line 165 "src/math/special.birch"
    libbirch_line_(165);
    #line 165 "src/math/special.birch"
    if (birch::abs(c) < TINY) {
      #line 166 "src/math/special.birch"
      libbirch_line_(166);
      #line 166 "src/math/special.birch"
      c = TINY;
    }
    #line 169 "src/math/special.birch"
    libbirch_line_(169);
    #line 169 "src/math/special.birch"
    auto cd = c * d;
    #line 172 "src/math/special.birch"
    libbirch_line_(172);
    #line 172 "src/math/special.birch"
    f = f * cd;
    #line 174 "src/math/special.birch"
    libbirch_line_(174);
    #line 174 "src/math/special.birch"
    if (birch::abs(1.0 - cd) < STOP) {
      #line 175 "src/math/special.birch"
      libbirch_line_(175);
      #line 175 "src/math/special.birch"
      return front * (f - 1.0);
    }
  }
  #line 179 "src/math/special.birch"
  libbirch_line_(179);
  #line 179 "src/math/special.birch"
  return birch::inf();
}

#line 185 "src/math/special.birch"
birch::type::Real64 birch::lbeta(const birch::type::Real64& x, const birch::type::Real64& y) {
  #line 185 "src/math/special.birch"
  libbirch_function_("lbeta", "src/math/special.birch", 185);
  #line 186 "src/math/special.birch"
  libbirch_line_(186);
  #line 186 "src/math/special.birch"
  return birch::lgamma(x) + birch::lgamma(y) - birch::lgamma(x + y);
}

#line 192 "src/math/special.birch"
birch::type::Real32 birch::lbeta(const birch::type::Real32& x, const birch::type::Real32& y) {
  #line 192 "src/math/special.birch"
  libbirch_function_("lbeta", "src/math/special.birch", 192);
  #line 193 "src/math/special.birch"
  libbirch_line_(193);
  #line 193 "src/math/special.birch"
  return birch::lgamma(x) + birch::lgamma(y) - birch::lgamma(x + y);
}

#line 199 "src/math/special.birch"
birch::type::Real64 birch::digamma(const birch::type::Real64& x) {
  #line 199 "src/math/special.birch"
  libbirch_function_("digamma", "src/math/special.birch", 199);
  #line 200 "src/math/special.birch"

  return boost::math::digamma(x);
  }

#line 208 "src/math/special.birch"
birch::type::Real32 birch::digamma(const birch::type::Real32& x) {
  #line 208 "src/math/special.birch"
  libbirch_function_("digamma", "src/math/special.birch", 208);
  #line 209 "src/math/special.birch"

  return boost::math::digamma(x);
  }

#line 217 "src/math/special.birch"
birch::type::Real64 birch::choose(const birch::type::Integer& x, const birch::type::Integer& y) {
  #line 217 "src/math/special.birch"
  libbirch_function_("choose", "src/math/special.birch", 217);
  #line 218 "src/math/special.birch"
  libbirch_line_(218);
  #line 218 "src/math/special.birch"
  libbirch_assert_(birch::type::Integer(0) <= x);
  #line 219 "src/math/special.birch"
  libbirch_line_(219);
  #line 219 "src/math/special.birch"
  libbirch_assert_(birch::type::Integer(0) <= y);
  #line 220 "src/math/special.birch"
  libbirch_line_(220);
  #line 220 "src/math/special.birch"
  libbirch_assert_(x >= y);
  #line 222 "src/math/special.birch"
  libbirch_line_(222);
  #line 222 "src/math/special.birch"
  if (y == birch::type::Integer(0)) {
    #line 223 "src/math/special.birch"
    libbirch_line_(223);
    #line 223 "src/math/special.birch"
    return 1.0;
  } else {
    #line 226 "src/math/special.birch"
    libbirch_line_(226);
    #line 226 "src/math/special.birch"
    return 1.0 / (birch::Real(y) * birch::beta(birch::Real(y), birch::Real(x - y + birch::type::Integer(1))));
  }
}

#line 233 "src/math/special.birch"
birch::type::Real64 birch::choose(const birch::type::Real64& x, const birch::type::Real64& y) {
  #line 233 "src/math/special.birch"
  libbirch_function_("choose", "src/math/special.birch", 233);
  #line 234 "src/math/special.birch"
  libbirch_line_(234);
  #line 234 "src/math/special.birch"
  libbirch_assert_(0.0 <= x);
  #line 235 "src/math/special.birch"
  libbirch_line_(235);
  #line 235 "src/math/special.birch"
  libbirch_assert_(0.0 <= y);
  #line 236 "src/math/special.birch"
  libbirch_line_(236);
  #line 236 "src/math/special.birch"
  libbirch_assert_(x >= y);
  #line 238 "src/math/special.birch"
  libbirch_line_(238);
  #line 238 "src/math/special.birch"
  if (y == 0.0) {
    #line 239 "src/math/special.birch"
    libbirch_line_(239);
    #line 239 "src/math/special.birch"
    return 1.0;
  } else {
    #line 242 "src/math/special.birch"
    libbirch_line_(242);
    #line 242 "src/math/special.birch"
    return 1.0 / (y * birch::beta(y, x - y + 1.0));
  }
}

#line 249 "src/math/special.birch"
birch::type::Real32 birch::choose(const birch::type::Real32& x, const birch::type::Real32& y) {
  #line 249 "src/math/special.birch"
  libbirch_function_("choose", "src/math/special.birch", 249);
  #line 250 "src/math/special.birch"
  libbirch_line_(250);
  #line 250 "src/math/special.birch"
  libbirch_assert_(birch::Real32(0.0) <= x);
  #line 251 "src/math/special.birch"
  libbirch_line_(251);
  #line 251 "src/math/special.birch"
  libbirch_assert_(birch::Real32(0.0) <= y);
  #line 252 "src/math/special.birch"
  libbirch_line_(252);
  #line 252 "src/math/special.birch"
  libbirch_assert_(x >= y);
  #line 254 "src/math/special.birch"
  libbirch_line_(254);
  #line 254 "src/math/special.birch"
  if (y == birch::Real32(0.0)) {
    #line 255 "src/math/special.birch"
    libbirch_line_(255);
    #line 255 "src/math/special.birch"
    return birch::Real32(1.0);
  } else {
    #line 258 "src/math/special.birch"
    libbirch_line_(258);
    #line 258 "src/math/special.birch"
    return birch::Real32(1.0) / (y * birch::beta(y, x - y + birch::Real32(1.0)));
  }
}

#line 265 "src/math/special.birch"
birch::type::Real64 birch::lchoose(const birch::type::Integer& x, const birch::type::Integer& y) {
  #line 265 "src/math/special.birch"
  libbirch_function_("lchoose", "src/math/special.birch", 265);
  #line 266 "src/math/special.birch"
  libbirch_line_(266);
  #line 266 "src/math/special.birch"
  libbirch_assert_(birch::type::Integer(0) <= x);
  #line 267 "src/math/special.birch"
  libbirch_line_(267);
  #line 267 "src/math/special.birch"
  libbirch_assert_(birch::type::Integer(0) <= y);
  #line 268 "src/math/special.birch"
  libbirch_line_(268);
  #line 268 "src/math/special.birch"
  libbirch_assert_(x >= y);
  #line 270 "src/math/special.birch"
  libbirch_line_(270);
  #line 270 "src/math/special.birch"
  if (y == birch::type::Integer(0)) {
    #line 271 "src/math/special.birch"
    libbirch_line_(271);
    #line 271 "src/math/special.birch"
    return 0.0;
  } else {
    #line 274 "src/math/special.birch"
    libbirch_line_(274);
    #line 274 "src/math/special.birch"
    return -(birch::log(birch::Real(y))) - birch::lbeta(birch::Real(y), birch::Real(x - y + birch::type::Integer(1)));
  }
}

#line 281 "src/math/special.birch"
birch::type::Real64 birch::lchoose(const birch::type::Real64& x, const birch::type::Real64& y) {
  #line 281 "src/math/special.birch"
  libbirch_function_("lchoose", "src/math/special.birch", 281);
  #line 282 "src/math/special.birch"
  libbirch_line_(282);
  #line 282 "src/math/special.birch"
  libbirch_assert_(0.0 <= x);
  #line 283 "src/math/special.birch"
  libbirch_line_(283);
  #line 283 "src/math/special.birch"
  libbirch_assert_(0.0 <= y);
  #line 284 "src/math/special.birch"
  libbirch_line_(284);
  #line 284 "src/math/special.birch"
  libbirch_assert_(x >= y);
  #line 286 "src/math/special.birch"
  libbirch_line_(286);
  #line 286 "src/math/special.birch"
  if (y == 0.0) {
    #line 287 "src/math/special.birch"
    libbirch_line_(287);
    #line 287 "src/math/special.birch"
    return 0.0;
  } else {
    #line 290 "src/math/special.birch"
    libbirch_line_(290);
    #line 290 "src/math/special.birch"
    return -(birch::log(y)) - birch::lbeta(y, x - y + 1.0);
  }
}

#line 297 "src/math/special.birch"
birch::type::Real32 birch::lchoose(const birch::type::Real32& x, const birch::type::Real32& y) {
  #line 297 "src/math/special.birch"
  libbirch_function_("lchoose", "src/math/special.birch", 297);
  #line 298 "src/math/special.birch"
  libbirch_line_(298);
  #line 298 "src/math/special.birch"
  libbirch_assert_(birch::Real32(0.0) <= x);
  #line 299 "src/math/special.birch"
  libbirch_line_(299);
  #line 299 "src/math/special.birch"
  libbirch_assert_(birch::Real32(0.0) <= y);
  #line 300 "src/math/special.birch"
  libbirch_line_(300);
  #line 300 "src/math/special.birch"
  libbirch_assert_(x >= y);
  #line 302 "src/math/special.birch"
  libbirch_line_(302);
  #line 302 "src/math/special.birch"
  if (y == birch::Real32(0.0)) {
    #line 303 "src/math/special.birch"
    libbirch_line_(303);
    #line 303 "src/math/special.birch"
    return birch::log(birch::Real32(1.0));
  } else {
    #line 306 "src/math/special.birch"
    libbirch_line_(306);
    #line 306 "src/math/special.birch"
    return -(birch::log(y)) - birch::lbeta(y, x - y + birch::Real32(1.0));
  }
}

#line 319 "src/math/special.birch"
birch::type::Real birch::lower_inc_gamma(const birch::type::Real& a, const birch::type::Real& x) {
  #line 319 "src/math/special.birch"
  libbirch_function_("lower_inc_gamma", "src/math/special.birch", 319);
  #line 323 "src/math/special.birch"
  libbirch_line_(323);
  #line 323 "src/math/special.birch"
  libbirch_assert_(x >= 0.0);
  #line 324 "src/math/special.birch"
  libbirch_line_(324);
  #line 324 "src/math/special.birch"
  libbirch_assert_(a >= 0.0);
  #line 325 "src/math/special.birch"
  libbirch_line_(325);
  #line 325 "src/math/special.birch"
  birch::type::Real64 IGAM_SMALL = birch::type::Integer(20);
  #line 326 "src/math/special.birch"
  libbirch_line_(326);
  #line 326 "src/math/special.birch"
  birch::type::Real64 IGAM_LARGE = birch::type::Integer(200);
  #line 327 "src/math/special.birch"
  libbirch_line_(327);
  #line 327 "src/math/special.birch"
  birch::type::Real64 IGAM_SMALLRATIO = 0.3;
  #line 328 "src/math/special.birch"
  libbirch_line_(328);
  #line 328 "src/math/special.birch"
  birch::type::Real64 IGAM_LARGERATIO = 4.5;
  #line 330 "src/math/special.birch"
  libbirch_line_(330);
  #line 330 "src/math/special.birch"
  birch::type::Real absxma_a = libbirch::make<birch::type::Real>();
  #line 332 "src/math/special.birch"
  libbirch_line_(332);
  #line 332 "src/math/special.birch"
  if (a == 0.0) {
    #line 333 "src/math/special.birch"
    libbirch_line_(333);
    #line 333 "src/math/special.birch"
    return 1.0;
    #line 334 "src/math/special.birch"
    libbirch_line_(334);
    #line 334 "src/math/special.birch"
    if (x > 0.0) {
      #line 335 "src/math/special.birch"
      libbirch_line_(335);
      #line 335 "src/math/special.birch"
      return 1.0;
    } else {
      #line 337 "src/math/special.birch"
      libbirch_line_(337);
      #line 337 "src/math/special.birch"
      return birch::nan();
    }
  } else {
    #line 339 "src/math/special.birch"
    libbirch_line_(339);
    #line 339 "src/math/special.birch"
    if (x == 0.0) {
      #line 340 "src/math/special.birch"
      libbirch_line_(340);
      #line 340 "src/math/special.birch"
      return 0.0;
    } else {
      #line 341 "src/math/special.birch"
      libbirch_line_(341);
      #line 341 "src/math/special.birch"
      if (birch::isinf(a)) {
        #line 342 "src/math/special.birch"
        libbirch_line_(342);
        #line 342 "src/math/special.birch"
        if (birch::isinf(x)) {
          #line 343 "src/math/special.birch"
          libbirch_line_(343);
          #line 343 "src/math/special.birch"
          return birch::nan();
        }
        #line 345 "src/math/special.birch"
        libbirch_line_(345);
        #line 345 "src/math/special.birch"
        return 0.0;
      } else {
        #line 346 "src/math/special.birch"
        libbirch_line_(346);
        #line 346 "src/math/special.birch"
        if (birch::isinf(x)) {
          #line 347 "src/math/special.birch"
          libbirch_line_(347);
          #line 347 "src/math/special.birch"
          return 1.0;
        }
      }
    }
  }
  #line 350 "src/math/special.birch"
  libbirch_line_(350);
  #line 350 "src/math/special.birch"
  absxma_a = birch::abs(x - a) / a;
  #line 351 "src/math/special.birch"
  libbirch_line_(351);
  #line 351 "src/math/special.birch"
  if ((a > IGAM_SMALL) && (a < IGAM_LARGE) && (absxma_a < IGAM_SMALLRATIO)) {
    #line 352 "src/math/special.birch"
    libbirch_line_(352);
    #line 352 "src/math/special.birch"
    return birch::asymptotic_series(a, x, birch::type::Integer(1));
  } else {
    #line 353 "src/math/special.birch"
    libbirch_line_(353);
    #line 353 "src/math/special.birch"
    if ((a > IGAM_LARGE) && (absxma_a < IGAM_LARGERATIO / birch::sqrt(a))) {
      #line 354 "src/math/special.birch"
      libbirch_line_(354);
      #line 354 "src/math/special.birch"
      return birch::asymptotic_series(a, x, birch::type::Integer(1));
    }
  }
  #line 357 "src/math/special.birch"
  libbirch_line_(357);
  #line 357 "src/math/special.birch"
  if ((x > 1.0) && (x > a)) {
    #line 358 "src/math/special.birch"
    libbirch_line_(358);
    #line 358 "src/math/special.birch"
    return (1.0 - birch::upper_inc_gamma(a, x));
  }
  #line 361 "src/math/special.birch"
  libbirch_line_(361);
  #line 361 "src/math/special.birch"
  return birch::igam_series(a, x);
}

#line 365 "src/math/special.birch"
birch::type::Real birch::upper_inc_gamma(const birch::type::Real& a, const birch::type::Real& x) {
  #line 365 "src/math/special.birch"
  libbirch_function_("upper_inc_gamma", "src/math/special.birch", 365);
  #line 367 "src/math/special.birch"
  libbirch_line_(367);
  #line 367 "src/math/special.birch"
  libbirch_assert_(x >= 0.0);
  #line 368 "src/math/special.birch"
  libbirch_line_(368);
  #line 368 "src/math/special.birch"
  libbirch_assert_(a >= 0.0);
  #line 369 "src/math/special.birch"
  libbirch_line_(369);
  #line 369 "src/math/special.birch"
  birch::type::Real64 IGAM_SMALL = birch::type::Integer(20);
  #line 370 "src/math/special.birch"
  libbirch_line_(370);
  #line 370 "src/math/special.birch"
  birch::type::Real64 IGAM_LARGE = birch::type::Integer(200);
  #line 371 "src/math/special.birch"
  libbirch_line_(371);
  #line 371 "src/math/special.birch"
  birch::type::Real64 IGAM_SMALLRATIO = 0.3;
  #line 372 "src/math/special.birch"
  libbirch_line_(372);
  #line 372 "src/math/special.birch"
  birch::type::Real64 IGAM_LARGERATIO = 4.5;
  #line 374 "src/math/special.birch"
  libbirch_line_(374);
  #line 374 "src/math/special.birch"
  birch::type::Real absxma_a = libbirch::make<birch::type::Real>();
  #line 376 "src/math/special.birch"
  libbirch_line_(376);
  #line 376 "src/math/special.birch"
  if (a == 0.0) {
    #line 377 "src/math/special.birch"
    libbirch_line_(377);
    #line 377 "src/math/special.birch"
    if (x > 0.0) {
      #line 378 "src/math/special.birch"
      libbirch_line_(378);
      #line 378 "src/math/special.birch"
      return 0.0;
    } else {
      #line 380 "src/math/special.birch"
      libbirch_line_(380);
      #line 380 "src/math/special.birch"
      return birch::nan();
    }
  } else {
    #line 383 "src/math/special.birch"
    libbirch_line_(383);
    #line 383 "src/math/special.birch"
    if (x == 0.0) {
      #line 384 "src/math/special.birch"
      libbirch_line_(384);
      #line 384 "src/math/special.birch"
      return 1.0;
    } else {
      #line 385 "src/math/special.birch"
      libbirch_line_(385);
      #line 385 "src/math/special.birch"
      if (birch::isinf(a)) {
        #line 386 "src/math/special.birch"
        libbirch_line_(386);
        #line 386 "src/math/special.birch"
        if (birch::isinf(x)) {
          #line 387 "src/math/special.birch"
          libbirch_line_(387);
          #line 387 "src/math/special.birch"
          return birch::nan();
        }
        #line 389 "src/math/special.birch"
        libbirch_line_(389);
        #line 389 "src/math/special.birch"
        return 1.0;
      } else {
        #line 390 "src/math/special.birch"
        libbirch_line_(390);
        #line 390 "src/math/special.birch"
        if (birch::isinf(x)) {
          #line 391 "src/math/special.birch"
          libbirch_line_(391);
          #line 391 "src/math/special.birch"
          return 0.0;
        }
      }
    }
  }
  #line 395 "src/math/special.birch"
  libbirch_line_(395);
  #line 395 "src/math/special.birch"
  absxma_a = birch::abs(x - a) / a;
  #line 397 "src/math/special.birch"
  libbirch_line_(397);
  #line 397 "src/math/special.birch"
  if ((a > IGAM_SMALL) && (a < IGAM_LARGE) && (absxma_a < IGAM_SMALLRATIO)) {
    #line 399 "src/math/special.birch"
    libbirch_line_(399);
    #line 399 "src/math/special.birch"
    return birch::asymptotic_series(a, x, birch::type::Integer(0));
  } else {
    #line 400 "src/math/special.birch"
    libbirch_line_(400);
    #line 400 "src/math/special.birch"
    if ((a > IGAM_LARGE) && (absxma_a < IGAM_LARGERATIO / birch::sqrt(a))) {
      #line 401 "src/math/special.birch"
      libbirch_line_(401);
      #line 401 "src/math/special.birch"
      return birch::asymptotic_series(a, x, birch::type::Integer(0));
    }
  }
  #line 404 "src/math/special.birch"
  libbirch_line_(404);
  #line 404 "src/math/special.birch"
  if (x > 1.1) {
    #line 405 "src/math/special.birch"
    libbirch_line_(405);
    #line 405 "src/math/special.birch"
    if (x < a) {
      #line 406 "src/math/special.birch"
      libbirch_line_(406);
      #line 406 "src/math/special.birch"
      return 1.0 - birch::igam_series(a, x);
    } else {
      #line 408 "src/math/special.birch"
      libbirch_line_(408);
      #line 408 "src/math/special.birch"
      return birch::igamc_continued_fraction(a, x);
    }
  } else {
    #line 411 "src/math/special.birch"
    libbirch_line_(411);
    #line 411 "src/math/special.birch"
    if (x <= 0.5) {
      #line 412 "src/math/special.birch"
      libbirch_line_(412);
      #line 412 "src/math/special.birch"
      if (-(0.4) / birch::log(x) < a) {
        #line 413 "src/math/special.birch"
        libbirch_line_(413);
        #line 413 "src/math/special.birch"
        return 1.0 - birch::igam_series(a, x);
      } else {
        #line 415 "src/math/special.birch"
        libbirch_line_(415);
        #line 415 "src/math/special.birch"
        return birch::igamc_series(a, x);
      }
    } else {
      #line 418 "src/math/special.birch"
      libbirch_line_(418);
      #line 418 "src/math/special.birch"
      if (x * 1.1 < a) {
        #line 419 "src/math/special.birch"
        libbirch_line_(419);
        #line 419 "src/math/special.birch"
        return 1.0 - birch::igam_series(a, x);
      } else {
        #line 421 "src/math/special.birch"
        libbirch_line_(421);
        #line 421 "src/math/special.birch"
        return birch::igamc_series(a, x);
      }
    }
  }
}

#line 427 "src/math/special.birch"
birch::type::Real birch::igam_fac(const birch::type::Real& a, const birch::type::Real& x) {
  #line 427 "src/math/special.birch"
  libbirch_function_("igam_fac", "src/math/special.birch", 427);
  #line 428 "src/math/special.birch"
  libbirch_line_(428);
  #line 428 "src/math/special.birch"
  birch::type::Real64 IGAM_MAXLOG = 709.782712893383996732;
  #line 429 "src/math/special.birch"
  libbirch_line_(429);
  #line 429 "src/math/special.birch"
  birch::type::Real64 IGAM_LANCZOS_G = 6.024680040776729583740234375;
  #line 431 "src/math/special.birch"
  libbirch_line_(431);
  #line 431 "src/math/special.birch"
  if (birch::abs(a - x) > 0.4 * birch::abs(a)) {
    #line 432 "src/math/special.birch"
    libbirch_line_(432);
    #line 432 "src/math/special.birch"
    auto ax = a * birch::log(x) - x - birch::lgamma(a);
    #line 433 "src/math/special.birch"
    libbirch_line_(433);
    #line 433 "src/math/special.birch"
    if (ax < -(IGAM_MAXLOG)) {
      #line 434 "src/math/special.birch"
      libbirch_line_(434);
      #line 434 "src/math/special.birch"
      return 0.0;
    }
    #line 436 "src/math/special.birch"
    libbirch_line_(436);
    #line 436 "src/math/special.birch"
    return birch::exp(ax);
  }
  #line 439 "src/math/special.birch"
  libbirch_line_(439);
  #line 439 "src/math/special.birch"
  auto fac = a + IGAM_LANCZOS_G - 0.5;
  #line 440 "src/math/special.birch"
  libbirch_line_(440);
  #line 440 "src/math/special.birch"
  auto res = birch::sqrt(fac / birch::exp(1.0)) / birch::lanczos_sum_expg_scaled(a);
  #line 442 "src/math/special.birch"
  libbirch_line_(442);
  #line 442 "src/math/special.birch"
  if ((a < 200.0) && (x < 200.0)) {
    #line 443 "src/math/special.birch"
    libbirch_line_(443);
    #line 443 "src/math/special.birch"
    res = res * birch::exp(a - x) * birch::pow(x / fac, a);
  } else {
    #line 445 "src/math/special.birch"
    libbirch_line_(445);
    #line 445 "src/math/special.birch"
    auto num = x - a - IGAM_LANCZOS_G + 0.5;
    #line 447 "src/math/special.birch"
    libbirch_line_(447);
    #line 447 "src/math/special.birch"
    res = res * birch::exp(a * (birch::log1p(num / fac) - x) + x * (0.5 - IGAM_LANCZOS_G) / fac);
  }
  #line 449 "src/math/special.birch"
  libbirch_line_(449);
  #line 449 "src/math/special.birch"
  return res;
}

#line 453 "src/math/special.birch"
birch::type::Real birch::igamc_continued_fraction(const birch::type::Real& a, const birch::type::Real& x) {
  #line 453 "src/math/special.birch"
  libbirch_function_("igamc_continued_fraction", "src/math/special.birch", 453);
  #line 454 "src/math/special.birch"
  libbirch_line_(454);
  #line 454 "src/math/special.birch"
  birch::type::Real64 IGAM_BIG = 4.503599627370496e15;
  #line 455 "src/math/special.birch"
  libbirch_line_(455);
  #line 455 "src/math/special.birch"
  birch::type::Real64 IGAM_BIGINV = 2.22044604925031308085e-16;
  #line 456 "src/math/special.birch"
  libbirch_line_(456);
  #line 456 "src/math/special.birch"
  auto ax = birch::igam_fac(a, x);
  #line 457 "src/math/special.birch"
  libbirch_line_(457);
  #line 457 "src/math/special.birch"
  if (ax == 0.0) {
    #line 458 "src/math/special.birch"
    libbirch_line_(458);
    #line 458 "src/math/special.birch"
    return 0.0;
  }
  #line 462 "src/math/special.birch"
  libbirch_line_(462);
  #line 462 "src/math/special.birch"
  auto y = 1.0 - a;
  #line 463 "src/math/special.birch"
  libbirch_line_(463);
  #line 463 "src/math/special.birch"
  auto z = x + y + 1.0;
  #line 464 "src/math/special.birch"
  libbirch_line_(464);
  #line 464 "src/math/special.birch"
  auto c = 0.0;
  #line 465 "src/math/special.birch"
  libbirch_line_(465);
  #line 465 "src/math/special.birch"
  auto pkm2 = 1.0;
  #line 466 "src/math/special.birch"
  libbirch_line_(466);
  #line 466 "src/math/special.birch"
  auto qkm2 = x;
  #line 467 "src/math/special.birch"
  libbirch_line_(467);
  #line 467 "src/math/special.birch"
  auto pkm1 = x + 1.0;
  #line 468 "src/math/special.birch"
  libbirch_line_(468);
  #line 468 "src/math/special.birch"
  auto qkm1 = z * x;
  #line 469 "src/math/special.birch"
  libbirch_line_(469);
  #line 469 "src/math/special.birch"
  auto ans = pkm1 / qkm1;
  #line 471 "src/math/special.birch"
  libbirch_line_(471);
  #line 471 "src/math/special.birch"
  auto flag = true;
  #line 472 "src/math/special.birch"
  libbirch_line_(472);
  #line 472 "src/math/special.birch"
  auto i = birch::type::Integer(0);
  #line 473 "src/math/special.birch"
  libbirch_line_(473);
  #line 473 "src/math/special.birch"
  auto t = 0.0;
  #line 474 "src/math/special.birch"
  libbirch_line_(474);
  #line 474 "src/math/special.birch"
  auto r = 0.0;
  #line 475 "src/math/special.birch"
  libbirch_line_(475);
  #line 475 "src/math/special.birch"
  while (i <= birch::type::Integer(2000) && flag) {
    #line 476 "src/math/special.birch"
    libbirch_line_(476);
    #line 476 "src/math/special.birch"
    c = c + 1.0;
    #line 477 "src/math/special.birch"
    libbirch_line_(477);
    #line 477 "src/math/special.birch"
    y = y + 1.0;
    #line 478 "src/math/special.birch"
    libbirch_line_(478);
    #line 478 "src/math/special.birch"
    z = z + 2.0;
    #line 479 "src/math/special.birch"
    libbirch_line_(479);
    #line 479 "src/math/special.birch"
    auto yc = y * c;
    #line 480 "src/math/special.birch"
    libbirch_line_(480);
    #line 480 "src/math/special.birch"
    auto pk = pkm1 * z - pkm2 * yc;
    #line 481 "src/math/special.birch"
    libbirch_line_(481);
    #line 481 "src/math/special.birch"
    auto qk = qkm1 * z - qkm2 * yc;
    #line 482 "src/math/special.birch"
    libbirch_line_(482);
    #line 482 "src/math/special.birch"
    if (qk != 0.0) {
      #line 483 "src/math/special.birch"
      libbirch_line_(483);
      #line 483 "src/math/special.birch"
      r = pk / qk;
      #line 484 "src/math/special.birch"
      libbirch_line_(484);
      #line 484 "src/math/special.birch"
      t = birch::abs((ans - r) / r);
      #line 485 "src/math/special.birch"
      libbirch_line_(485);
      #line 485 "src/math/special.birch"
      ans = r;
    } else {
      #line 487 "src/math/special.birch"
      libbirch_line_(487);
      #line 487 "src/math/special.birch"
      t = 1.0;
    }
    #line 490 "src/math/special.birch"
    libbirch_line_(490);
    #line 490 "src/math/special.birch"
    pkm2 = pkm1;
    #line 491 "src/math/special.birch"
    libbirch_line_(491);
    #line 491 "src/math/special.birch"
    pkm1 = pk;
    #line 492 "src/math/special.birch"
    libbirch_line_(492);
    #line 492 "src/math/special.birch"
    qkm2 = qkm1;
    #line 493 "src/math/special.birch"
    libbirch_line_(493);
    #line 493 "src/math/special.birch"
    qkm1 = qk;
    #line 494 "src/math/special.birch"
    libbirch_line_(494);
    #line 494 "src/math/special.birch"
    if (birch::abs(pk) > IGAM_BIG) {
      #line 495 "src/math/special.birch"
      libbirch_line_(495);
      #line 495 "src/math/special.birch"
      pkm2 = pkm2 * IGAM_BIGINV;
      #line 496 "src/math/special.birch"
      libbirch_line_(496);
      #line 496 "src/math/special.birch"
      pkm1 = pkm1 * IGAM_BIGINV;
      #line 497 "src/math/special.birch"
      libbirch_line_(497);
      #line 497 "src/math/special.birch"
      qkm2 = qkm2 * IGAM_BIGINV;
      #line 498 "src/math/special.birch"
      libbirch_line_(498);
      #line 498 "src/math/special.birch"
      qkm1 = qkm1 * IGAM_BIGINV;
    }
    #line 500 "src/math/special.birch"
    libbirch_line_(500);
    #line 500 "src/math/special.birch"
    if (t <= birch::MACHEP()) {
      #line 501 "src/math/special.birch"
      libbirch_line_(501);
      #line 501 "src/math/special.birch"
      flag = false;
    }
    #line 503 "src/math/special.birch"
    libbirch_line_(503);
    #line 503 "src/math/special.birch"
    +(+(i));
  }
  #line 506 "src/math/special.birch"
  libbirch_line_(506);
  #line 506 "src/math/special.birch"
  return (ans * ax);
}

#line 510 "src/math/special.birch"
birch::type::Real birch::igam_series(const birch::type::Real& a, const birch::type::Real& x) {
  #line 510 "src/math/special.birch"
  libbirch_function_("igam_series", "src/math/special.birch", 510);
  #line 512 "src/math/special.birch"
  libbirch_line_(512);
  #line 512 "src/math/special.birch"
  auto ax = birch::igam_fac(a, x);
  #line 513 "src/math/special.birch"
  libbirch_line_(513);
  #line 513 "src/math/special.birch"
  if (ax == 0.0) {
    #line 514 "src/math/special.birch"
    libbirch_line_(514);
    #line 514 "src/math/special.birch"
    return 0.0;
  }
  #line 518 "src/math/special.birch"
  libbirch_line_(518);
  #line 518 "src/math/special.birch"
  auto r = a;
  #line 519 "src/math/special.birch"
  libbirch_line_(519);
  #line 519 "src/math/special.birch"
  auto c = 1.0;
  #line 520 "src/math/special.birch"
  libbirch_line_(520);
  #line 520 "src/math/special.birch"
  auto ans = 1.0;
  #line 521 "src/math/special.birch"
  libbirch_line_(521);
  #line 521 "src/math/special.birch"
  auto flag = true;
  #line 522 "src/math/special.birch"
  libbirch_line_(522);
  #line 522 "src/math/special.birch"
  auto i = birch::type::Integer(0);
  #line 523 "src/math/special.birch"
  libbirch_line_(523);
  #line 523 "src/math/special.birch"
  while (i <= birch::type::Integer(2000) && flag) {
    #line 524 "src/math/special.birch"
    libbirch_line_(524);
    #line 524 "src/math/special.birch"
    r = r + 1.0;
    #line 525 "src/math/special.birch"
    libbirch_line_(525);
    #line 525 "src/math/special.birch"
    c = c * (x / r);
    #line 526 "src/math/special.birch"
    libbirch_line_(526);
    #line 526 "src/math/special.birch"
    ans = ans + c;
    #line 527 "src/math/special.birch"
    libbirch_line_(527);
    #line 527 "src/math/special.birch"
    if (c <= birch::MACHEP() * ans) {
      #line 528 "src/math/special.birch"
      libbirch_line_(528);
      #line 528 "src/math/special.birch"
      flag = false;
    }
    #line 530 "src/math/special.birch"
    libbirch_line_(530);
    #line 530 "src/math/special.birch"
    +(+(i));
  }
  #line 532 "src/math/special.birch"
  libbirch_line_(532);
  #line 532 "src/math/special.birch"
  return (ans * ax / a);
}

#line 535 "src/math/special.birch"
birch::type::Real birch::igamc_series(const birch::type::Real& a, const birch::type::Real& x) {
  #line 535 "src/math/special.birch"
  libbirch_function_("igamc_series", "src/math/special.birch", 535);
  #line 536 "src/math/special.birch"
  libbirch_line_(536);
  #line 536 "src/math/special.birch"
  auto fac = 1.0;
  #line 537 "src/math/special.birch"
  libbirch_line_(537);
  #line 537 "src/math/special.birch"
  auto sum = 0.0;
  #line 538 "src/math/special.birch"
  libbirch_line_(538);
  #line 538 "src/math/special.birch"
  birch::type::Real term = libbirch::make<birch::type::Real>();
  #line 539 "src/math/special.birch"
  libbirch_line_(539);
  #line 539 "src/math/special.birch"
  birch::type::Real logx = libbirch::make<birch::type::Real>();
  #line 541 "src/math/special.birch"
  libbirch_line_(541);
  #line 541 "src/math/special.birch"
  auto n = birch::type::Integer(1);
  #line 542 "src/math/special.birch"
  libbirch_line_(542);
  #line 542 "src/math/special.birch"
  auto flag = true;
  #line 543 "src/math/special.birch"
  libbirch_line_(543);
  #line 543 "src/math/special.birch"
  while (n <= birch::type::Integer(2000) && flag) {
    #line 544 "src/math/special.birch"
    libbirch_line_(544);
    #line 544 "src/math/special.birch"
    fac = fac * (-(x) / n);
    #line 545 "src/math/special.birch"
    libbirch_line_(545);
    #line 545 "src/math/special.birch"
    term = fac / (a + n);
    #line 546 "src/math/special.birch"
    libbirch_line_(546);
    #line 546 "src/math/special.birch"
    sum = sum + term;
    #line 547 "src/math/special.birch"
    libbirch_line_(547);
    #line 547 "src/math/special.birch"
    if (birch::abs(term) <= birch::MACHEP() * birch::abs(sum)) {
      #line 548 "src/math/special.birch"
      libbirch_line_(548);
      #line 548 "src/math/special.birch"
      flag = false;
    }
    #line 550 "src/math/special.birch"
    libbirch_line_(550);
    #line 550 "src/math/special.birch"
    +(+(n));
  }
  #line 553 "src/math/special.birch"
  libbirch_line_(553);
  #line 553 "src/math/special.birch"
  logx = birch::log(x);
  #line 554 "src/math/special.birch"
  libbirch_line_(554);
  #line 554 "src/math/special.birch"
  term = -(birch::expm1(a * logx - birch::lgamma(a + 1.0)));
  #line 555 "src/math/special.birch"
  libbirch_line_(555);
  #line 555 "src/math/special.birch"
  return term - birch::exp(a * logx - birch::lgamma(a)) * sum;
}

#line 559 "src/math/special.birch"
birch::type::Real birch::asymptotic_series(const birch::type::Real& a, const birch::type::Real& x, const birch::type::Integer& func) {
  #line 559 "src/math/special.birch"
  libbirch_function_("asymptotic_series", "src/math/special.birch", 559);
  #line 560 "src/math/special.birch"
  libbirch_line_(560);
  #line 560 "src/math/special.birch"
  auto K = birch::type::Integer(25);
  #line 561 "src/math/special.birch"
  libbirch_line_(561);
  #line 561 "src/math/special.birch"
  auto N = birch::type::Integer(25);
  #line 562 "src/math/special.birch"
  libbirch_line_(562);
  #line 562 "src/math/special.birch"
  auto sgn = birch::type::Integer(0);
  #line 563 "src/math/special.birch"
  libbirch_line_(563);
  #line 563 "src/math/special.birch"
  auto maxpow = birch::type::Integer(0);
  #line 564 "src/math/special.birch"
  libbirch_line_(564);
  #line 564 "src/math/special.birch"
  auto λ = x / a;
  #line 565 "src/math/special.birch"
  libbirch_line_(565);
  #line 565 "src/math/special.birch"
  auto σ = (x - a) / a;
  #line 566 "src/math/special.birch"
  libbirch_line_(566);
  #line 566 "src/math/special.birch"
  birch::type::Real η = libbirch::make<birch::type::Real>();
  #line 567 "src/math/special.birch"
  libbirch_line_(567);
  #line 567 "src/math/special.birch"
  birch::type::Real res = libbirch::make<birch::type::Real>();
  #line 568 "src/math/special.birch"
  libbirch_line_(568);
  #line 568 "src/math/special.birch"
  birch::type::Real ck = libbirch::make<birch::type::Real>();
  #line 569 "src/math/special.birch"
  libbirch_line_(569);
  #line 569 "src/math/special.birch"
  birch::type::Real ckterm = libbirch::make<birch::type::Real>();
  #line 570 "src/math/special.birch"
  libbirch_line_(570);
  #line 570 "src/math/special.birch"
  birch::type::Real term = libbirch::make<birch::type::Real>();
  #line 571 "src/math/special.birch"
  libbirch_line_(571);
  #line 571 "src/math/special.birch"
  birch::type::Real absterm = libbirch::make<birch::type::Real>();
  #line 572 "src/math/special.birch"
  libbirch_line_(572);
  #line 572 "src/math/special.birch"
  auto absoldterm = birch::inf();
  #line 573 "src/math/special.birch"
  libbirch_line_(573);
  #line 573 "src/math/special.birch"
  libbirch::DefaultArray<birch::type::Real,1> etapow = libbirch::make_array<birch::type::Real>(libbirch::make_shape(N));
  #line 574 "src/math/special.birch"
  libbirch_line_(574);
  #line 574 "src/math/special.birch"
  etapow(birch::type::Integer(1)) = birch::type::Integer(1);
  #line 575 "src/math/special.birch"
  libbirch_line_(575);
  #line 575 "src/math/special.birch"
  auto tot = 0.0;
  #line 576 "src/math/special.birch"
  libbirch_line_(576);
  #line 576 "src/math/special.birch"
  auto afac = 1.0;
  #line 578 "src/math/special.birch"
  libbirch_line_(578);
  #line 578 "src/math/special.birch"
  if (func == birch::type::Integer(1)) {
    #line 579 "src/math/special.birch"
    libbirch_line_(579);
    #line 579 "src/math/special.birch"
    sgn = -(birch::type::Integer(1));
  } else {
    #line 581 "src/math/special.birch"
    libbirch_line_(581);
    #line 581 "src/math/special.birch"
    sgn = birch::type::Integer(1);
  }
  #line 584 "src/math/special.birch"
  libbirch_line_(584);
  #line 584 "src/math/special.birch"
  if (λ > 1.0) {
    #line 585 "src/math/special.birch"
    libbirch_line_(585);
    #line 585 "src/math/special.birch"
    η = birch::sqrt(-(2.0) * (birch::log1p(σ) - σ));
  } else {
    #line 586 "src/math/special.birch"
    libbirch_line_(586);
    #line 586 "src/math/special.birch"
    if (λ < birch::type::Integer(1)) {
      #line 587 "src/math/special.birch"
      libbirch_line_(587);
      #line 587 "src/math/special.birch"
      η = -(birch::sqrt(-(2.0) * (birch::log1p(σ) - σ)));
    } else {
      #line 589 "src/math/special.birch"
      libbirch_line_(589);
      #line 589 "src/math/special.birch"
      η = 0.0;
    }
  }
  #line 591 "src/math/special.birch"
  libbirch_line_(591);
  #line 591 "src/math/special.birch"
  res = 0.5 * birch::erfc(sgn * η * birch::sqrt(a / 2.0));
  #line 592 "src/math/special.birch"
  libbirch_line_(592);
  #line 592 "src/math/special.birch"
  auto flag1 = true;
  #line 593 "src/math/special.birch"
  libbirch_line_(593);
  #line 593 "src/math/special.birch"
  auto k = birch::type::Integer(1);
  #line 594 "src/math/special.birch"
  libbirch_line_(594);
  #line 594 "src/math/special.birch"
  while (k <= K && flag1) {
    #line 595 "src/math/special.birch"
    libbirch_line_(595);
    #line 595 "src/math/special.birch"
    ck = birch::IGAM_ASYMPTOTIC_SERIES_D()(k, birch::type::Integer(1));
    #line 596 "src/math/special.birch"
    libbirch_line_(596);
    #line 596 "src/math/special.birch"
    auto flag2 = true;
    #line 597 "src/math/special.birch"
    libbirch_line_(597);
    #line 597 "src/math/special.birch"
    auto n = birch::type::Integer(2);
    #line 598 "src/math/special.birch"
    libbirch_line_(598);
    #line 598 "src/math/special.birch"
    while (n <= N && flag2) {
      #line 599 "src/math/special.birch"
      libbirch_line_(599);
      #line 599 "src/math/special.birch"
      if (n > maxpow) {
        #line 600 "src/math/special.birch"
        libbirch_line_(600);
        #line 600 "src/math/special.birch"
        etapow(n) = η * etapow(n - birch::type::Integer(1));
        #line 601 "src/math/special.birch"
        libbirch_line_(601);
        #line 601 "src/math/special.birch"
        maxpow = maxpow + birch::type::Integer(1);
      }
      #line 603 "src/math/special.birch"
      libbirch_line_(603);
      #line 603 "src/math/special.birch"
      ckterm = birch::IGAM_ASYMPTOTIC_SERIES_D()(k, n) * etapow(n);
      #line 604 "src/math/special.birch"
      libbirch_line_(604);
      #line 604 "src/math/special.birch"
      ck = ck + ckterm;
      #line 605 "src/math/special.birch"
      libbirch_line_(605);
      #line 605 "src/math/special.birch"
      if (birch::abs(ckterm) < birch::MACHEP() * birch::abs(ck)) {
        #line 606 "src/math/special.birch"
        libbirch_line_(606);
        #line 606 "src/math/special.birch"
        flag2 = false;
      }
      #line 608 "src/math/special.birch"
      libbirch_line_(608);
      #line 608 "src/math/special.birch"
      n = n + birch::type::Integer(1);
    }
    #line 610 "src/math/special.birch"
    libbirch_line_(610);
    #line 610 "src/math/special.birch"
    term = ck * afac;
    #line 611 "src/math/special.birch"
    libbirch_line_(611);
    #line 611 "src/math/special.birch"
    absterm = birch::abs(term);
    #line 612 "src/math/special.birch"
    libbirch_line_(612);
    #line 612 "src/math/special.birch"
    if (absterm > absoldterm) {
      #line 613 "src/math/special.birch"
      libbirch_line_(613);
      #line 613 "src/math/special.birch"
      flag1 = false;
    }
    #line 615 "src/math/special.birch"
    libbirch_line_(615);
    #line 615 "src/math/special.birch"
    tot = tot + term;
    #line 616 "src/math/special.birch"
    libbirch_line_(616);
    #line 616 "src/math/special.birch"
    if (absterm < (birch::MACHEP() * birch::abs(tot))) {
      #line 617 "src/math/special.birch"
      libbirch_line_(617);
      #line 617 "src/math/special.birch"
      flag1 = false;
    }
    #line 619 "src/math/special.birch"
    libbirch_line_(619);
    #line 619 "src/math/special.birch"
    absoldterm = absterm;
    #line 620 "src/math/special.birch"
    libbirch_line_(620);
    #line 620 "src/math/special.birch"
    afac = afac / a;
    #line 621 "src/math/special.birch"
    libbirch_line_(621);
    #line 621 "src/math/special.birch"
    +(+(k));
  }
  #line 623 "src/math/special.birch"
  libbirch_line_(623);
  #line 623 "src/math/special.birch"
  res = res + sgn * birch::exp(-(0.5) * a * η * η) * tot / birch::sqrt(2.0 * birch::π() * a);
  #line 625 "src/math/special.birch"
  libbirch_line_(625);
  #line 625 "src/math/special.birch"
  return res;
}

#line 629 "src/math/special.birch"
birch::type::Real birch::lanczos_sum_expg_scaled(const birch::type::Real& x) {
  #line 629 "src/math/special.birch"
  libbirch_function_("lanczos_sum_expg_scaled", "src/math/special.birch", 629);
  #line 630 "src/math/special.birch"
  libbirch_line_(630);
  #line 630 "src/math/special.birch"
  return birch::ratevl(x, birch::lanczos_sum_expg_scaled_num(), birch::length(birch::lanczos_sum_expg_scaled_num()) - birch::type::Integer(1), birch::lanczos_sum_expg_scaled_denom(), birch::length(birch::lanczos_sum_expg_scaled_denom()) - birch::type::Integer(1));
}

#line 635 "src/math/special.birch"
birch::type::Real birch::ratevl(const birch::type::Real& x, const libbirch::DefaultArray<birch::type::Real,1>& num, const birch::type::Integer& M, const libbirch::DefaultArray<birch::type::Real,1>& denom, const birch::type::Integer& N) {
  #line 635 "src/math/special.birch"
  libbirch_function_("ratevl", "src/math/special.birch", 635);
  #line 636 "src/math/special.birch"
  libbirch_line_(636);
  #line 636 "src/math/special.birch"
  birch::type::Integer dir = libbirch::make<birch::type::Integer>();
  #line 638 "src/math/special.birch"
  libbirch_line_(638);
  #line 638 "src/math/special.birch"
  birch::type::Real y = libbirch::make<birch::type::Real>();
  #line 639 "src/math/special.birch"
  libbirch_line_(639);
  #line 639 "src/math/special.birch"
  auto absx = birch::abs(x);
  #line 640 "src/math/special.birch"
  libbirch_line_(640);
  #line 640 "src/math/special.birch"
  auto pind = birch::type::Integer(1);
  #line 641 "src/math/special.birch"
  libbirch_line_(641);
  #line 641 "src/math/special.birch"
  auto pval = 0.0;
  #line 643 "src/math/special.birch"
  libbirch_line_(643);
  #line 643 "src/math/special.birch"
  if (absx > 1.0) {
    #line 646 "src/math/special.birch"
    libbirch_line_(646);
    #line 646 "src/math/special.birch"
    dir = -(birch::type::Integer(1));
    #line 648 "src/math/special.birch"
    libbirch_line_(648);
    #line 648 "src/math/special.birch"
    pind = M + birch::type::Integer(1);
    #line 649 "src/math/special.birch"
    libbirch_line_(649);
    #line 649 "src/math/special.birch"
    y = 1.0 / x;
  } else {
    #line 653 "src/math/special.birch"
    libbirch_line_(653);
    #line 653 "src/math/special.birch"
    dir = birch::type::Integer(1);
    #line 654 "src/math/special.birch"
    libbirch_line_(654);
    #line 654 "src/math/special.birch"
    pind = birch::type::Integer(1);
    #line 655 "src/math/special.birch"
    libbirch_line_(655);
    #line 655 "src/math/special.birch"
    y = x;
  }
  #line 662 "src/math/special.birch"
  libbirch_line_(662);
  #line 662 "src/math/special.birch"
  auto num_ans = num(pind);
  #line 663 "src/math/special.birch"
  libbirch_line_(663);
  #line 663 "src/math/special.birch"
  pind = pind + dir;
  #line 664 "src/math/special.birch"
  libbirch_line_(664);
  #line 664 "src/math/special.birch"
  for (auto i = birch::type::Integer(2); i <= (M + birch::type::Integer(1)); ++i) {
    #line 665 "src/math/special.birch"
    libbirch_line_(665);
    #line 665 "src/math/special.birch"
    num_ans = (num_ans * y) + num(pind);
    #line 666 "src/math/special.birch"
    libbirch_line_(666);
    #line 666 "src/math/special.birch"
    pind = pind + dir;
  }
  #line 670 "src/math/special.birch"
  libbirch_line_(670);
  #line 670 "src/math/special.birch"
  if (absx > 1.0) {
    #line 671 "src/math/special.birch"
    libbirch_line_(671);
    #line 671 "src/math/special.birch"
    pind = N + birch::type::Integer(1);
  } else {
    #line 673 "src/math/special.birch"
    libbirch_line_(673);
    #line 673 "src/math/special.birch"
    pind = birch::type::Integer(1);
  }
  #line 676 "src/math/special.birch"
  libbirch_line_(676);
  #line 676 "src/math/special.birch"
  auto denom_ans = denom(pind);
  #line 677 "src/math/special.birch"
  libbirch_line_(677);
  #line 677 "src/math/special.birch"
  pind = pind + dir;
  #line 678 "src/math/special.birch"
  libbirch_line_(678);
  #line 678 "src/math/special.birch"
  for (auto i = birch::type::Integer(2); i <= (N + birch::type::Integer(1)); ++i) {
    #line 679 "src/math/special.birch"
    libbirch_line_(679);
    #line 679 "src/math/special.birch"
    denom_ans = denom_ans * y + denom(pind);
    #line 680 "src/math/special.birch"
    libbirch_line_(680);
    #line 680 "src/math/special.birch"
    pind = pind + dir;
  }
  #line 683 "src/math/special.birch"
  libbirch_line_(683);
  #line 683 "src/math/special.birch"
  if (absx > 1.0) {
    #line 684 "src/math/special.birch"
    libbirch_line_(684);
    #line 684 "src/math/special.birch"
    auto i = N - M;
    #line 685 "src/math/special.birch"
    libbirch_line_(685);
    #line 685 "src/math/special.birch"
    return birch::pow(x, birch::Real(i)) * num_ans / denom_ans;
  } else {
    #line 687 "src/math/special.birch"
    libbirch_line_(687);
    #line 687 "src/math/special.birch"
    return num_ans / denom_ans;
  }
}

#line 5 "src/math/standard.birch"
birch::type::Real64 birch::log(const birch::type::Real64& x) {
  #line 5 "src/math/standard.birch"
  libbirch_function_("log", "src/math/standard.birch", 5);
  #line 6 "src/math/standard.birch"

  return ::log(x);
  }

#line 14 "src/math/standard.birch"
birch::type::Real32 birch::log(const birch::type::Real32& x) {
  #line 14 "src/math/standard.birch"
  libbirch_function_("log", "src/math/standard.birch", 14);
  #line 15 "src/math/standard.birch"

  return ::logf(x);
  }

#line 23 "src/math/standard.birch"
birch::type::Real64 birch::log1p(const birch::type::Real64& x) {
  #line 23 "src/math/standard.birch"
  libbirch_function_("log1p", "src/math/standard.birch", 23);
  #line 24 "src/math/standard.birch"

  return ::log1p(x);
  }

#line 32 "src/math/standard.birch"
birch::type::Real32 birch::log1p(const birch::type::Real32& x) {
  #line 32 "src/math/standard.birch"
  libbirch_function_("log1p", "src/math/standard.birch", 32);
  #line 33 "src/math/standard.birch"

  return ::log1pf(x);
  }

#line 41 "src/math/standard.birch"
birch::type::Real64 birch::log2(const birch::type::Real64& x) {
  #line 41 "src/math/standard.birch"
  libbirch_function_("log2", "src/math/standard.birch", 41);
  #line 42 "src/math/standard.birch"

  return ::log2(x);
  }

#line 50 "src/math/standard.birch"
birch::type::Real32 birch::log2(const birch::type::Real32& x) {
  #line 50 "src/math/standard.birch"
  libbirch_function_("log2", "src/math/standard.birch", 50);
  #line 51 "src/math/standard.birch"

  return ::log2f(x);
  }

#line 59 "src/math/standard.birch"
birch::type::Real64 birch::log10(const birch::type::Real64& x) {
  #line 59 "src/math/standard.birch"
  libbirch_function_("log10", "src/math/standard.birch", 59);
  #line 60 "src/math/standard.birch"

  return ::log10(x);
  }

#line 68 "src/math/standard.birch"
birch::type::Real32 birch::log10(const birch::type::Real32& x) {
  #line 68 "src/math/standard.birch"
  libbirch_function_("log10", "src/math/standard.birch", 68);
  #line 69 "src/math/standard.birch"

  return ::log10f(x);
  }

#line 77 "src/math/standard.birch"
birch::type::Real64 birch::exp(const birch::type::Real64& x) {
  #line 77 "src/math/standard.birch"
  libbirch_function_("exp", "src/math/standard.birch", 77);
  #line 78 "src/math/standard.birch"

  return ::exp(x);
  }

#line 86 "src/math/standard.birch"
birch::type::Real32 birch::exp(const birch::type::Real32& x) {
  #line 86 "src/math/standard.birch"
  libbirch_function_("exp", "src/math/standard.birch", 86);
  #line 87 "src/math/standard.birch"

  return ::expf(x);
  }

#line 95 "src/math/standard.birch"
birch::type::Real64 birch::sqrt(const birch::type::Real64& x) {
  #line 95 "src/math/standard.birch"
  libbirch_function_("sqrt", "src/math/standard.birch", 95);
  #line 96 "src/math/standard.birch"

  return ::sqrt(x);
  }

#line 104 "src/math/standard.birch"
birch::type::Real32 birch::sqrt(const birch::type::Real32& x) {
  #line 104 "src/math/standard.birch"
  libbirch_function_("sqrt", "src/math/standard.birch", 104);
  #line 105 "src/math/standard.birch"

  return ::sqrtf(x);
  }

#line 113 "src/math/standard.birch"
birch::type::Real64 birch::ceil(const birch::type::Real64& x) {
  #line 113 "src/math/standard.birch"
  libbirch_function_("ceil", "src/math/standard.birch", 113);
  #line 114 "src/math/standard.birch"

  return ::ceil(x);
  }

#line 122 "src/math/standard.birch"
birch::type::Real32 birch::ceil(const birch::type::Real32& x) {
  #line 122 "src/math/standard.birch"
  libbirch_function_("ceil", "src/math/standard.birch", 122);
  #line 123 "src/math/standard.birch"

  return ::ceilf(x);
  }

#line 131 "src/math/standard.birch"
birch::type::Real64 birch::floor(const birch::type::Real64& x) {
  #line 131 "src/math/standard.birch"
  libbirch_function_("floor", "src/math/standard.birch", 131);
  #line 132 "src/math/standard.birch"

  return ::floor(x);
  }

#line 140 "src/math/standard.birch"
birch::type::Real32 birch::floor(const birch::type::Real32& x) {
  #line 140 "src/math/standard.birch"
  libbirch_function_("floor", "src/math/standard.birch", 140);
  #line 141 "src/math/standard.birch"

  return ::floorf(x);
  }

#line 149 "src/math/standard.birch"
birch::type::Real64 birch::round(const birch::type::Real64& x) {
  #line 149 "src/math/standard.birch"
  libbirch_function_("round", "src/math/standard.birch", 149);
  #line 150 "src/math/standard.birch"

  return ::round(x);
  }

#line 158 "src/math/standard.birch"
birch::type::Real32 birch::round(const birch::type::Real32& x) {
  #line 158 "src/math/standard.birch"
  libbirch_function_("round", "src/math/standard.birch", 158);
  #line 159 "src/math/standard.birch"

  return ::roundf(x);
  }

#line 167 "src/math/standard.birch"
birch::type::Real64 birch::sin(const birch::type::Real64& x) {
  #line 167 "src/math/standard.birch"
  libbirch_function_("sin", "src/math/standard.birch", 167);
  #line 168 "src/math/standard.birch"

  return ::sin(x);
  }

#line 176 "src/math/standard.birch"
birch::type::Real32 birch::sin(const birch::type::Real32& x) {
  #line 176 "src/math/standard.birch"
  libbirch_function_("sin", "src/math/standard.birch", 176);
  #line 177 "src/math/standard.birch"

  return ::sinf(x);
  }

#line 185 "src/math/standard.birch"
birch::type::Real64 birch::cos(const birch::type::Real64& x) {
  #line 185 "src/math/standard.birch"
  libbirch_function_("cos", "src/math/standard.birch", 185);
  #line 186 "src/math/standard.birch"

  return ::cos(x);
  }

#line 194 "src/math/standard.birch"
birch::type::Real32 birch::cos(const birch::type::Real32& x) {
  #line 194 "src/math/standard.birch"
  libbirch_function_("cos", "src/math/standard.birch", 194);
  #line 195 "src/math/standard.birch"

  return ::cosf(x);
  }

#line 203 "src/math/standard.birch"
birch::type::Real64 birch::tan(const birch::type::Real64& x) {
  #line 203 "src/math/standard.birch"
  libbirch_function_("tan", "src/math/standard.birch", 203);
  #line 204 "src/math/standard.birch"

  return ::tan(x);
  }

#line 212 "src/math/standard.birch"
birch::type::Real32 birch::tan(const birch::type::Real32& x) {
  #line 212 "src/math/standard.birch"
  libbirch_function_("tan", "src/math/standard.birch", 212);
  #line 213 "src/math/standard.birch"

  return ::tanf(x);
  }

#line 221 "src/math/standard.birch"
birch::type::Real64 birch::asin(const birch::type::Real64& x) {
  #line 221 "src/math/standard.birch"
  libbirch_function_("asin", "src/math/standard.birch", 221);
  #line 222 "src/math/standard.birch"

  return ::asin(x);
  }

#line 230 "src/math/standard.birch"
birch::type::Real32 birch::asin(const birch::type::Real32& x) {
  #line 230 "src/math/standard.birch"
  libbirch_function_("asin", "src/math/standard.birch", 230);
  #line 231 "src/math/standard.birch"

  return  ::asinf(x);
  }

#line 239 "src/math/standard.birch"
birch::type::Real64 birch::acos(const birch::type::Real64& x) {
  #line 239 "src/math/standard.birch"
  libbirch_function_("acos", "src/math/standard.birch", 239);
  #line 240 "src/math/standard.birch"

  return ::acos(x);
  }

#line 248 "src/math/standard.birch"
birch::type::Real32 birch::acos(const birch::type::Real32& x) {
  #line 248 "src/math/standard.birch"
  libbirch_function_("acos", "src/math/standard.birch", 248);
  #line 249 "src/math/standard.birch"

  return ::acosf(x);
  }

#line 257 "src/math/standard.birch"
birch::type::Real64 birch::atan(const birch::type::Real64& x) {
  #line 257 "src/math/standard.birch"
  libbirch_function_("atan", "src/math/standard.birch", 257);
  #line 258 "src/math/standard.birch"

  return ::atan(x);
  }

#line 266 "src/math/standard.birch"
birch::type::Real32 birch::atan(const birch::type::Real32& x) {
  #line 266 "src/math/standard.birch"
  libbirch_function_("atan", "src/math/standard.birch", 266);
  #line 267 "src/math/standard.birch"

  return ::atanf(x);
  }

#line 275 "src/math/standard.birch"
birch::type::Real64 birch::atan2(const birch::type::Real64& x, const birch::type::Real64& y) {
  #line 275 "src/math/standard.birch"
  libbirch_function_("atan2", "src/math/standard.birch", 275);
  #line 276 "src/math/standard.birch"

  return ::atan2(x, y);
  }

#line 284 "src/math/standard.birch"
birch::type::Real32 birch::atan2(const birch::type::Real32& x, const birch::type::Real32& y) {
  #line 284 "src/math/standard.birch"
  libbirch_function_("atan2", "src/math/standard.birch", 284);
  #line 285 "src/math/standard.birch"

  return ::atan2f(x, y);
  }

#line 293 "src/math/standard.birch"
birch::type::Real64 birch::sinh(const birch::type::Real64& x) {
  #line 293 "src/math/standard.birch"
  libbirch_function_("sinh", "src/math/standard.birch", 293);
  #line 294 "src/math/standard.birch"

  return ::sinh(x);
  }

#line 302 "src/math/standard.birch"
birch::type::Real32 birch::sinh(const birch::type::Real32& x) {
  #line 302 "src/math/standard.birch"
  libbirch_function_("sinh", "src/math/standard.birch", 302);
  #line 303 "src/math/standard.birch"

  return ::sinhf(x);
  }

#line 311 "src/math/standard.birch"
birch::type::Real64 birch::cosh(const birch::type::Real64& x) {
  #line 311 "src/math/standard.birch"
  libbirch_function_("cosh", "src/math/standard.birch", 311);
  #line 312 "src/math/standard.birch"

  return ::cosh(x);
  }

#line 320 "src/math/standard.birch"
birch::type::Real32 birch::cosh(const birch::type::Real32& x) {
  #line 320 "src/math/standard.birch"
  libbirch_function_("cosh", "src/math/standard.birch", 320);
  #line 321 "src/math/standard.birch"

  return ::coshf(x);
  }

#line 329 "src/math/standard.birch"
birch::type::Real64 birch::tanh(const birch::type::Real64& x) {
  #line 329 "src/math/standard.birch"
  libbirch_function_("tanh", "src/math/standard.birch", 329);
  #line 330 "src/math/standard.birch"

  return ::tanh(x);
  }

#line 338 "src/math/standard.birch"
birch::type::Real32 birch::tanh(const birch::type::Real32& x) {
  #line 338 "src/math/standard.birch"
  libbirch_function_("tanh", "src/math/standard.birch", 338);
  #line 339 "src/math/standard.birch"

  return ::tanhf(x);
  }

#line 347 "src/math/standard.birch"
birch::type::Real64 birch::asinh(const birch::type::Real64& x) {
  #line 347 "src/math/standard.birch"
  libbirch_function_("asinh", "src/math/standard.birch", 347);
  #line 348 "src/math/standard.birch"

  return ::asinh(x);
  }

#line 356 "src/math/standard.birch"
birch::type::Real32 birch::asinh(const birch::type::Real32& x) {
  #line 356 "src/math/standard.birch"
  libbirch_function_("asinh", "src/math/standard.birch", 356);
  #line 357 "src/math/standard.birch"

  return ::asinhf(x);
  }

#line 365 "src/math/standard.birch"
birch::type::Real64 birch::acosh(const birch::type::Real64& x) {
  #line 365 "src/math/standard.birch"
  libbirch_function_("acosh", "src/math/standard.birch", 365);
  #line 366 "src/math/standard.birch"

  return ::acosh(x);
  }

#line 374 "src/math/standard.birch"
birch::type::Real32 birch::acosh(const birch::type::Real32& x) {
  #line 374 "src/math/standard.birch"
  libbirch_function_("acosh", "src/math/standard.birch", 374);
  #line 375 "src/math/standard.birch"

  return ::acoshf(x);
  }

#line 383 "src/math/standard.birch"
birch::type::Real64 birch::atanh(const birch::type::Real64& x) {
  #line 383 "src/math/standard.birch"
  libbirch_function_("atanh", "src/math/standard.birch", 383);
  #line 384 "src/math/standard.birch"

  return ::atanh(x);
  }

#line 392 "src/math/standard.birch"
birch::type::Real32 birch::atanh(const birch::type::Real32& x) {
  #line 392 "src/math/standard.birch"
  libbirch_function_("atanh", "src/math/standard.birch", 392);
  #line 393 "src/math/standard.birch"

  return ::atanhf(x);
  }

#line 401 "src/math/standard.birch"
birch::type::Real64 birch::erf(const birch::type::Real64& x) {
  #line 401 "src/math/standard.birch"
  libbirch_function_("erf", "src/math/standard.birch", 401);
  #line 402 "src/math/standard.birch"

  return ::erf(x);
  }

#line 410 "src/math/standard.birch"
birch::type::Real32 birch::erf(const birch::type::Real32& x) {
  #line 410 "src/math/standard.birch"
  libbirch_function_("erf", "src/math/standard.birch", 410);
  #line 411 "src/math/standard.birch"

  return ::erff(x);
  }

#line 419 "src/math/standard.birch"
birch::type::Real64 birch::erfc(const birch::type::Real64& x) {
  #line 419 "src/math/standard.birch"
  libbirch_function_("erfc", "src/math/standard.birch", 419);
  #line 420 "src/math/standard.birch"

  return ::erfc(x);
  }

#line 428 "src/math/standard.birch"
birch::type::Real32 birch::erfc(const birch::type::Real32& x) {
  #line 428 "src/math/standard.birch"
  libbirch_function_("erfc", "src/math/standard.birch", 428);
  #line 429 "src/math/standard.birch"

  return ::erfcf(x);
  }

#line 437 "src/math/standard.birch"
birch::type::Real64 birch::copysign(const birch::type::Real64& x, const birch::type::Real64& y) {
  #line 437 "src/math/standard.birch"
  libbirch_function_("copysign", "src/math/standard.birch", 437);
  #line 438 "src/math/standard.birch"

  return ::copysign(x, y);
  }

#line 446 "src/math/standard.birch"
birch::type::Real32 birch::copysign(const birch::type::Real32& x, const birch::type::Real32& y) {
  #line 446 "src/math/standard.birch"
  libbirch_function_("copysign", "src/math/standard.birch", 446);
  #line 447 "src/math/standard.birch"

  return ::copysignf(x, y);
  }

#line 455 "src/math/standard.birch"
birch::type::Real64 birch::rectify(const birch::type::Real64& x) {
  #line 455 "src/math/standard.birch"
  libbirch_function_("rectify", "src/math/standard.birch", 455);
  #line 456 "src/math/standard.birch"
  libbirch_line_(456);
  #line 456 "src/math/standard.birch"
  return birch::max(0.0, x);
}

#line 462 "src/math/standard.birch"
birch::type::Real32 birch::rectify(const birch::type::Real32& x) {
  #line 462 "src/math/standard.birch"
  libbirch_function_("rectify", "src/math/standard.birch", 462);
  #line 463 "src/math/standard.birch"
  libbirch_line_(463);
  #line 463 "src/math/standard.birch"
  return birch::max(birch::Real32(0.0), x);
}

#line 10 "src/math/update.birch"
std::tuple<birch::type::Real, birch::type::Real> birch::update_beta_bernoulli(const birch::type::Boolean& x, const birch::type::Real& α, const birch::type::Real& β) {
  #line 10 "src/math/update.birch"
  libbirch_function_("update_beta_bernoulli", "src/math/update.birch", 10);
  #line 11 "src/math/update.birch"
  libbirch_line_(11);
  #line 11 "src/math/update.birch"
  if (x) {
    #line 12 "src/math/update.birch"
    libbirch_line_(12);
    #line 12 "src/math/update.birch"
    return std::make_tuple(α + 1.0, β);
  } else {
    #line 14 "src/math/update.birch"
    libbirch_line_(14);
    #line 14 "src/math/update.birch"
    return std::make_tuple(α, β + 1.0);
  }
}

#line 28 "src/math/update.birch"
std::tuple<birch::type::Real, birch::type::Real> birch::update_beta_binomial(const birch::type::Integer& x, const birch::type::Integer& n, const birch::type::Real& α, const birch::type::Real& β) {
  #line 28 "src/math/update.birch"
  libbirch_function_("update_beta_binomial", "src/math/update.birch", 28);
  #line 30 "src/math/update.birch"
  libbirch_line_(30);
  #line 30 "src/math/update.birch"
  libbirch_assert_(birch::type::Integer(0) <= x && x <= n);
  #line 31 "src/math/update.birch"
  libbirch_line_(31);
  #line 31 "src/math/update.birch"
  libbirch_assert_(birch::type::Integer(0) <= n);
  #line 32 "src/math/update.birch"
  libbirch_line_(32);
  #line 32 "src/math/update.birch"
  libbirch_assert_(0.0 < α);
  #line 33 "src/math/update.birch"
  libbirch_line_(33);
  #line 33 "src/math/update.birch"
  libbirch_assert_(0.0 < β);
  #line 34 "src/math/update.birch"
  libbirch_line_(34);
  #line 34 "src/math/update.birch"
  return std::make_tuple(α + x, β + n - x);
}

#line 47 "src/math/update.birch"
std::tuple<birch::type::Real, birch::type::Real> birch::update_beta_negative_binomial(const birch::type::Integer& x, const birch::type::Integer& k, const birch::type::Real& α, const birch::type::Real& β) {
  #line 47 "src/math/update.birch"
  libbirch_function_("update_beta_negative_binomial", "src/math/update.birch", 47);
  #line 49 "src/math/update.birch"
  libbirch_line_(49);
  #line 49 "src/math/update.birch"
  return std::make_tuple(α + k, β + x);
}

#line 61 "src/math/update.birch"
std::tuple<birch::type::Real, birch::type::Real> birch::update_gamma_poisson(const birch::type::Integer& x, const birch::type::Real& k, const birch::type::Real& θ) {
  #line 61 "src/math/update.birch"
  libbirch_function_("update_gamma_poisson", "src/math/update.birch", 61);
  #line 62 "src/math/update.birch"
  libbirch_line_(62);
  #line 62 "src/math/update.birch"
  return std::make_tuple(k + x, θ / (θ + 1.0));
}

#line 76 "src/math/update.birch"
std::tuple<birch::type::Real, birch::type::Real> birch::update_scaled_gamma_poisson(const birch::type::Integer& x, const birch::type::Real& a, const birch::type::Real& k, const birch::type::Real& θ) {
  #line 76 "src/math/update.birch"
  libbirch_function_("update_scaled_gamma_poisson", "src/math/update.birch", 76);
  #line 78 "src/math/update.birch"
  libbirch_line_(78);
  #line 78 "src/math/update.birch"
  return std::make_tuple(k + x, θ / (a * θ + 1.0));
}

#line 91 "src/math/update.birch"
std::tuple<birch::type::Real, birch::type::Real> birch::update_gamma_exponential(const birch::type::Real& x, const birch::type::Real& k, const birch::type::Real& θ) {
  #line 91 "src/math/update.birch"
  libbirch_function_("update_gamma_exponential", "src/math/update.birch", 91);
  #line 92 "src/math/update.birch"
  libbirch_line_(92);
  #line 92 "src/math/update.birch"
  return std::make_tuple(k + 1.0, θ / (1.0 + x * θ));
}

#line 106 "src/math/update.birch"
std::tuple<birch::type::Real, birch::type::Real> birch::update_scaled_gamma_exponential(const birch::type::Real& x, const birch::type::Real& a, const birch::type::Real& k, const birch::type::Real& θ) {
  #line 106 "src/math/update.birch"
  libbirch_function_("update_scaled_gamma_exponential", "src/math/update.birch", 106);
  #line 107 "src/math/update.birch"
  libbirch_line_(107);
  #line 107 "src/math/update.birch"
  return std::make_tuple(k + 1.0, θ / (1.0 + x * a * θ));
}

#line 121 "src/math/update.birch"
std::tuple<birch::type::Real, birch::type::Real> birch::update_inverse_gamma_weibull(const birch::type::Real& x, const birch::type::Real& k, const birch::type::Real& α, const birch::type::Real& β) {
  #line 121 "src/math/update.birch"
  libbirch_function_("update_inverse_gamma_weibull", "src/math/update.birch", 121);
  #line 122 "src/math/update.birch"
  libbirch_line_(122);
  #line 122 "src/math/update.birch"
  return std::make_tuple(α + 1.0, β + birch::pow(x, k));
}

#line 137 "src/math/update.birch"
std::tuple<birch::type::Real, birch::type::Real> birch::update_scaled_inverse_gamma_weibull(const birch::type::Real& x, const birch::type::Real& k, const birch::type::Real& a, const birch::type::Real& α, const birch::type::Real& β) {
  #line 137 "src/math/update.birch"
  libbirch_function_("update_scaled_inverse_gamma_weibull", "src/math/update.birch", 137);
  #line 138 "src/math/update.birch"
  libbirch_line_(138);
  #line 138 "src/math/update.birch"
  return std::make_tuple(α + 1.0, β + birch::pow(x, k) / a);
}

#line 150 "src/math/update.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::update_dirichlet_categorical(const birch::type::Integer& x, const libbirch::DefaultArray<birch::type::Real,1>& α) {
  #line 150 "src/math/update.birch"
  libbirch_function_("update_dirichlet_categorical", "src/math/update.birch", 150);
  #line 151 "src/math/update.birch"
  libbirch_line_(151);
  #line 151 "src/math/update.birch"
  auto α_prime_ = α;
  #line 152 "src/math/update.birch"
  libbirch_line_(152);
  #line 152 "src/math/update.birch"
  α_prime_(x) = α_prime_(x) + 1.0;
  #line 153 "src/math/update.birch"
  libbirch_line_(153);
  #line 153 "src/math/update.birch"
  return α_prime_;
}

#line 166 "src/math/update.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::update_dirichlet_multinomial(const libbirch::DefaultArray<birch::type::Integer,1>& x, const birch::type::Integer& n, const libbirch::DefaultArray<birch::type::Real,1>& α) {
  #line 166 "src/math/update.birch"
  libbirch_function_("update_dirichlet_multinomial", "src/math/update.birch", 166);
  #line 168 "src/math/update.birch"
  libbirch_line_(168);
  #line 168 "src/math/update.birch"
  libbirch_assert_(birch::sum(x) == n);
  #line 171 "src/math/update.birch"
  libbirch_line_(171);
  #line 171 "src/math/update.birch"
  auto α_prime_ = α;
  #line 172 "src/math/update.birch"
  libbirch_line_(172);
  #line 172 "src/math/update.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(α); ++i) {
    #line 173 "src/math/update.birch"
    libbirch_line_(173);
    #line 173 "src/math/update.birch"
    α_prime_(i) = α(i) + x(i);
  }
  #line 175 "src/math/update.birch"
  libbirch_line_(175);
  #line 175 "src/math/update.birch"
  return α_prime_;
}

#line 189 "src/math/update.birch"
std::tuple<birch::type::Real, birch::type::Real> birch::update_gaussian_gaussian(const birch::type::Real& x, const birch::type::Real& μ, const birch::type::Real& σ2, const birch::type::Real& s2) {
  #line 189 "src/math/update.birch"
  libbirch_function_("update_gaussian_gaussian", "src/math/update.birch", 189);
  #line 191 "src/math/update.birch"
  libbirch_line_(191);
  #line 191 "src/math/update.birch"
  auto λ = 1.0 / σ2;
  #line 192 "src/math/update.birch"
  libbirch_line_(192);
  #line 192 "src/math/update.birch"
  auto l = 1.0 / s2;
  #line 193 "src/math/update.birch"
  libbirch_line_(193);
  #line 193 "src/math/update.birch"
  auto λ_prime_ = λ + l;
  #line 194 "src/math/update.birch"
  libbirch_line_(194);
  #line 194 "src/math/update.birch"
  auto μ_prime_ = (λ * μ + l * x) / λ_prime_;
  #line 195 "src/math/update.birch"
  libbirch_line_(195);
  #line 195 "src/math/update.birch"
  return std::make_tuple(μ_prime_, 1.0 / λ_prime_);
}

#line 211 "src/math/update.birch"
std::tuple<birch::type::Real, birch::type::Real> birch::update_linear_gaussian_gaussian(const birch::type::Real& x, const birch::type::Real& a, const birch::type::Real& μ, const birch::type::Real& σ2, const birch::type::Real& c, const birch::type::Real& s2) {
  #line 211 "src/math/update.birch"
  libbirch_function_("update_linear_gaussian_gaussian", "src/math/update.birch", 211);
  #line 213 "src/math/update.birch"
  libbirch_line_(213);
  #line 213 "src/math/update.birch"
  auto λ = 1.0 / σ2;
  #line 214 "src/math/update.birch"
  libbirch_line_(214);
  #line 214 "src/math/update.birch"
  auto l = 1.0 / s2;
  #line 215 "src/math/update.birch"
  libbirch_line_(215);
  #line 215 "src/math/update.birch"
  auto λ_prime_ = λ + a * a * l;
  #line 216 "src/math/update.birch"
  libbirch_line_(216);
  #line 216 "src/math/update.birch"
  auto μ_prime_ = (λ * μ + a * l * (x - c)) / λ_prime_;
  #line 217 "src/math/update.birch"
  libbirch_line_(217);
  #line 217 "src/math/update.birch"
  return std::make_tuple(μ_prime_, 1.0 / λ_prime_);
}

#line 232 "src/math/update.birch"
std::tuple<birch::type::Real, birch::type::Real> birch::update_normal_inverse_gamma(const birch::type::Real& x, const birch::type::Real& μ, const birch::type::Real& λ, const birch::type::Real& α, const birch::type::Real& β) {
  #line 232 "src/math/update.birch"
  libbirch_function_("update_normal_inverse_gamma", "src/math/update.birch", 232);
  #line 234 "src/math/update.birch"
  libbirch_line_(234);
  #line 234 "src/math/update.birch"
  return std::make_tuple(α + 0.5, β + 0.5 * birch::pow(x - μ, 2.0) * λ);
}

#line 249 "src/math/update.birch"
std::tuple<birch::type::Real, birch::type::Real, birch::type::Real, birch::type::Real> birch::update_normal_inverse_gamma_gaussian(const birch::type::Real& x, const birch::type::Real& μ, const birch::type::Real& λ, const birch::type::Real& α, const birch::type::Real& β) {
  #line 249 "src/math/update.birch"
  libbirch_function_("update_normal_inverse_gamma_gaussian", "src/math/update.birch", 249);
  #line 251 "src/math/update.birch"
  libbirch_line_(251);
  #line 251 "src/math/update.birch"
  auto λ_prime_ = λ + 1.0;
  #line 252 "src/math/update.birch"
  libbirch_line_(252);
  #line 252 "src/math/update.birch"
  auto μ_prime_ = (λ * μ + x) / λ_prime_;
  #line 253 "src/math/update.birch"
  libbirch_line_(253);
  #line 253 "src/math/update.birch"
  auto α_prime_ = α + 0.5;
  #line 254 "src/math/update.birch"
  libbirch_line_(254);
  #line 254 "src/math/update.birch"
  auto β_prime_ = β + 0.5 * (λ / λ_prime_) * birch::pow(x - μ, 2.0);
  #line 256 "src/math/update.birch"
  libbirch_line_(256);
  #line 256 "src/math/update.birch"
  return std::make_tuple(μ_prime_, λ_prime_, α_prime_, β_prime_);
}

#line 273 "src/math/update.birch"
std::tuple<birch::type::Real, birch::type::Real, birch::type::Real, birch::type::Real> birch::update_linear_normal_inverse_gamma_gaussian(const birch::type::Real& x, const birch::type::Real& a, const birch::type::Real& μ, const birch::type::Real& λ, const birch::type::Real& c, const birch::type::Real& α, const birch::type::Real& β) {
  #line 273 "src/math/update.birch"
  libbirch_function_("update_linear_normal_inverse_gamma_gaussian", "src/math/update.birch", 273);
  #line 275 "src/math/update.birch"
  libbirch_line_(275);
  #line 275 "src/math/update.birch"
  auto y = x - c;
  #line 276 "src/math/update.birch"
  libbirch_line_(276);
  #line 276 "src/math/update.birch"
  auto λ_prime_ = λ + a * a;
  #line 277 "src/math/update.birch"
  libbirch_line_(277);
  #line 277 "src/math/update.birch"
  auto μ_prime_ = (λ * μ + a * y) / λ_prime_;
  #line 278 "src/math/update.birch"
  libbirch_line_(278);
  #line 278 "src/math/update.birch"
  auto α_prime_ = α + 0.5;
  #line 279 "src/math/update.birch"
  libbirch_line_(279);
  #line 279 "src/math/update.birch"
  auto β_prime_ = β + 0.5 * (y * y + μ * μ * λ - μ_prime_ * μ_prime_ * λ_prime_);
  #line 281 "src/math/update.birch"
  libbirch_line_(281);
  #line 281 "src/math/update.birch"
  return std::make_tuple(μ_prime_, λ_prime_, α_prime_, β_prime_);
}

#line 295 "src/math/update.birch"
std::tuple<birch::type::Real, birch::type::Real> birch::update_inverse_gamma_gamma(const birch::type::Real& x, const birch::type::Real& k, const birch::type::Real& α, const birch::type::Real& β) {
  #line 295 "src/math/update.birch"
  libbirch_function_("update_inverse_gamma_gamma", "src/math/update.birch", 295);
  #line 297 "src/math/update.birch"
  libbirch_line_(297);
  #line 297 "src/math/update.birch"
  return std::make_tuple(α + k, β + x);
}

#line 311 "src/math/update.birch"
std::tuple<libbirch::DefaultArray<birch::type::Real,1>, birch::type::LLT> birch::update_multivariate_gaussian_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& μ, const birch::type::LLT& Σ, const birch::type::LLT& S) {
  #line 311 "src/math/update.birch"
  libbirch_function_("update_multivariate_gaussian_multivariate_gaussian", "src/math/update.birch", 311);
  #line 313 "src/math/update.birch"
  libbirch_line_(313);
  #line 313 "src/math/update.birch"
  auto Σ0 = birch::canonical(Σ);
  #line 314 "src/math/update.birch"
  libbirch_line_(314);
  #line 314 "src/math/update.birch"
  auto S0 = birch::canonical(S);
  #line 315 "src/math/update.birch"
  libbirch_line_(315);
  #line 315 "src/math/update.birch"
  auto K_prime_ = birch::transpose(birch::solve(birch::llt(Σ0 + S0), Σ0));
  #line 316 "src/math/update.birch"
  libbirch_line_(316);
  #line 316 "src/math/update.birch"
  auto μ_prime_ = μ + K_prime_ * (x - μ);
  #line 317 "src/math/update.birch"
  libbirch_line_(317);
  #line 317 "src/math/update.birch"
  auto Σ_prime_ = birch::llt(Σ0 - K_prime_ * Σ0);
  #line 318 "src/math/update.birch"
  libbirch_line_(318);
  #line 318 "src/math/update.birch"
  return std::make_tuple(μ_prime_, Σ_prime_);
}

#line 334 "src/math/update.birch"
std::tuple<libbirch::DefaultArray<birch::type::Real,1>, birch::type::LLT> birch::update_linear_multivariate_gaussian_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,2>& A, const libbirch::DefaultArray<birch::type::Real,1>& μ, const birch::type::LLT& Σ, const libbirch::DefaultArray<birch::type::Real,1>& c, const birch::type::LLT& S) {
  #line 334 "src/math/update.birch"
  libbirch_function_("update_linear_multivariate_gaussian_multivariate_gaussian", "src/math/update.birch", 334);
  #line 336 "src/math/update.birch"
  libbirch_line_(336);
  #line 336 "src/math/update.birch"
  auto Σ0 = birch::canonical(Σ);
  #line 337 "src/math/update.birch"
  libbirch_line_(337);
  #line 337 "src/math/update.birch"
  auto S0 = birch::canonical(S);
  #line 338 "src/math/update.birch"
  libbirch_line_(338);
  #line 338 "src/math/update.birch"
  auto K_prime_ = Σ0 * birch::transpose(birch::solve(birch::llt(A * Σ0 * birch::transpose(A) + S0), A));
  #line 339 "src/math/update.birch"
  libbirch_line_(339);
  #line 339 "src/math/update.birch"
  auto μ_prime_ = μ + K_prime_ * (x - A * μ - c);
  #line 340 "src/math/update.birch"
  libbirch_line_(340);
  #line 340 "src/math/update.birch"
  auto Σ_prime_ = birch::llt(Σ0 - K_prime_ * A * Σ0);
  #line 341 "src/math/update.birch"
  libbirch_line_(341);
  #line 341 "src/math/update.birch"
  return std::make_tuple(μ_prime_, Σ_prime_);
}

#line 358 "src/math/update.birch"
std::tuple<libbirch::DefaultArray<birch::type::Real,1>, birch::type::LLT> birch::update_linear_multivariate_gaussian_gaussian(const birch::type::Real& x, const libbirch::DefaultArray<birch::type::Real,1>& a, const libbirch::DefaultArray<birch::type::Real,1>& μ, const birch::type::LLT& Σ, const birch::type::Real& c, const birch::type::Real& s2) {
  #line 358 "src/math/update.birch"
  libbirch_function_("update_linear_multivariate_gaussian_gaussian", "src/math/update.birch", 358);
  #line 360 "src/math/update.birch"
  libbirch_line_(360);
  #line 360 "src/math/update.birch"
  auto Σ0 = birch::canonical(Σ);
  #line 361 "src/math/update.birch"
  libbirch_line_(361);
  #line 361 "src/math/update.birch"
  auto k_prime_ = Σ0 * a / (birch::dot(a, Σ0 * a) + s2);
  #line 362 "src/math/update.birch"
  libbirch_line_(362);
  #line 362 "src/math/update.birch"
  auto μ_prime_ = μ + k_prime_ * (x - birch::dot(a, μ) - c);
  #line 363 "src/math/update.birch"
  libbirch_line_(363);
  #line 363 "src/math/update.birch"
  auto Σ_prime_ = birch::llt(Σ0 - birch::outer(k_prime_, a) * Σ0);
  #line 364 "src/math/update.birch"
  libbirch_line_(364);
  #line 364 "src/math/update.birch"
  return std::make_tuple(μ_prime_, Σ_prime_);
}

#line 379 "src/math/update.birch"
std::tuple<birch::type::Real, birch::type::Real> birch::update_multivariate_normal_inverse_gamma(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& ν, const birch::type::LLT& Λ, const birch::type::Real& α, const birch::type::Real& β) {
  #line 379 "src/math/update.birch"
  libbirch_function_("update_multivariate_normal_inverse_gamma", "src/math/update.birch", 379);
  #line 381 "src/math/update.birch"
  libbirch_line_(381);
  #line 381 "src/math/update.birch"
  auto D = birch::length(x);
  #line 382 "src/math/update.birch"
  libbirch_line_(382);
  #line 382 "src/math/update.birch"
  auto μ = birch::solve(Λ, ν);
  #line 383 "src/math/update.birch"
  libbirch_line_(383);
  #line 383 "src/math/update.birch"
  return std::make_tuple(α + 0.5 * D, β + 0.5 * birch::dot(x - μ, birch::canonical(Λ) * (x - μ)));
}

#line 398 "src/math/update.birch"
std::tuple<libbirch::DefaultArray<birch::type::Real,1>, birch::type::LLT, birch::type::Real, birch::type::Real> birch::update_multivariate_normal_inverse_gamma_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& ν, const birch::type::LLT& Λ, const birch::type::Real& α, const birch::type::Real& γ) {
  #line 398 "src/math/update.birch"
  libbirch_function_("update_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/math/update.birch", 398);
  #line 401 "src/math/update.birch"
  libbirch_line_(401);
  #line 401 "src/math/update.birch"
  auto D = birch::length(x);
  #line 402 "src/math/update.birch"
  libbirch_line_(402);
  #line 402 "src/math/update.birch"
  auto Λ_prime_ = birch::rank_update(Λ, birch::identity(birch::rows(Λ)));
  #line 403 "src/math/update.birch"
  libbirch_line_(403);
  #line 403 "src/math/update.birch"
  auto ν_prime_ = ν + x;
  #line 404 "src/math/update.birch"
  libbirch_line_(404);
  #line 404 "src/math/update.birch"
  auto α_prime_ = α + 0.5 * D;
  #line 405 "src/math/update.birch"
  libbirch_line_(405);
  #line 405 "src/math/update.birch"
  auto γ_prime_ = γ + 0.5 * birch::dot(x);
  #line 406 "src/math/update.birch"
  libbirch_line_(406);
  #line 406 "src/math/update.birch"
  return std::make_tuple(ν_prime_, Λ_prime_, α_prime_, γ_prime_);
}

#line 423 "src/math/update.birch"
std::tuple<libbirch::DefaultArray<birch::type::Real,1>, birch::type::LLT, birch::type::Real, birch::type::Real> birch::update_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,2>& A, const libbirch::DefaultArray<birch::type::Real,1>& ν, const birch::type::LLT& Λ, const libbirch::DefaultArray<birch::type::Real,1>& c, const birch::type::Real& α, const birch::type::Real& γ) {
  #line 423 "src/math/update.birch"
  libbirch_function_("update_linear_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/math/update.birch", 423);
  #line 426 "src/math/update.birch"
  libbirch_line_(426);
  #line 426 "src/math/update.birch"
  auto D = birch::length(x);
  #line 427 "src/math/update.birch"
  libbirch_line_(427);
  #line 427 "src/math/update.birch"
  auto Λ_prime_ = birch::rank_update(Λ, birch::transpose(A));
  #line 428 "src/math/update.birch"
  libbirch_line_(428);
  #line 428 "src/math/update.birch"
  auto ν_prime_ = ν + birch::transpose(A) * (x - c);
  #line 429 "src/math/update.birch"
  libbirch_line_(429);
  #line 429 "src/math/update.birch"
  auto α_prime_ = α + 0.5 * D;
  #line 430 "src/math/update.birch"
  libbirch_line_(430);
  #line 430 "src/math/update.birch"
  auto γ_prime_ = γ + 0.5 * birch::dot(x - c);
  #line 431 "src/math/update.birch"
  libbirch_line_(431);
  #line 431 "src/math/update.birch"
  return std::make_tuple(ν_prime_, Λ_prime_, α_prime_, γ_prime_);
}

#line 448 "src/math/update.birch"
std::tuple<libbirch::DefaultArray<birch::type::Real,1>, birch::type::LLT, birch::type::Real, birch::type::Real> birch::update_linear_multivariate_normal_inverse_gamma_gaussian(const birch::type::Real& x, const libbirch::DefaultArray<birch::type::Real,1>& a, const libbirch::DefaultArray<birch::type::Real,1>& ν, const birch::type::LLT& Λ, const birch::type::Real& c, const birch::type::Real& α, const birch::type::Real& γ) {
  #line 448 "src/math/update.birch"
  libbirch_function_("update_linear_multivariate_normal_inverse_gamma_gaussian", "src/math/update.birch", 448);
  #line 451 "src/math/update.birch"
  libbirch_line_(451);
  #line 451 "src/math/update.birch"
  auto Λ_prime_ = birch::rank_update(Λ, a);
  #line 452 "src/math/update.birch"
  libbirch_line_(452);
  #line 452 "src/math/update.birch"
  auto ν_prime_ = ν + a * (x - c);
  #line 453 "src/math/update.birch"
  libbirch_line_(453);
  #line 453 "src/math/update.birch"
  auto α_prime_ = α + 0.5;
  #line 454 "src/math/update.birch"
  libbirch_line_(454);
  #line 454 "src/math/update.birch"
  auto γ_prime_ = γ + 0.5 * birch::pow(x - c, 2.0);
  #line 455 "src/math/update.birch"
  libbirch_line_(455);
  #line 455 "src/math/update.birch"
  return std::make_tuple(ν_prime_, Λ_prime_, α_prime_, γ_prime_);
}

#line 469 "src/math/update.birch"
std::tuple<birch::type::LLT, birch::type::Real> birch::update_matrix_normal_inverse_wishart(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& Λ, const birch::type::LLT& V, const birch::type::Real& k) {
  #line 469 "src/math/update.birch"
  libbirch_function_("update_matrix_normal_inverse_wishart", "src/math/update.birch", 469);
  #line 471 "src/math/update.birch"
  libbirch_line_(471);
  #line 471 "src/math/update.birch"
  auto n = birch::rows(X);
  #line 472 "src/math/update.birch"
  libbirch_line_(472);
  #line 472 "src/math/update.birch"
  auto M = birch::solve(Λ, N);
  #line 473 "src/math/update.birch"
  libbirch_line_(473);
  #line 473 "src/math/update.birch"
  auto V_prime_ = birch::llt(birch::canonical(V) + birch::transpose(X - M) * birch::canonical(Λ) * (X - M));
  #line 474 "src/math/update.birch"
  libbirch_line_(474);
  #line 474 "src/math/update.birch"
  auto k_prime_ = k + n;
  #line 475 "src/math/update.birch"
  libbirch_line_(475);
  #line 475 "src/math/update.birch"
  return std::make_tuple(V_prime_, k_prime_);
}

#line 490 "src/math/update.birch"
std::tuple<libbirch::DefaultArray<birch::type::Real,2>, birch::type::LLT, birch::type::LLT, birch::type::Real> birch::update_matrix_normal_inverse_wishart_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& Λ, const birch::type::LLT& V, const birch::type::Real& k) {
  #line 490 "src/math/update.birch"
  libbirch_function_("update_matrix_normal_inverse_wishart_matrix_gaussian", "src/math/update.birch", 490);
  #line 492 "src/math/update.birch"
  libbirch_line_(492);
  #line 492 "src/math/update.birch"
  auto D = birch::rows(X);
  #line 493 "src/math/update.birch"
  libbirch_line_(493);
  #line 493 "src/math/update.birch"
  auto Λ_prime_ = birch::rank_update(Λ, birch::identity(birch::rows(N)));
  #line 494 "src/math/update.birch"
  libbirch_line_(494);
  #line 494 "src/math/update.birch"
  auto N_prime_ = N + X;
  #line 495 "src/math/update.birch"
  libbirch_line_(495);
  #line 495 "src/math/update.birch"
  auto M = birch::solve(Λ, N);
  #line 496 "src/math/update.birch"
  libbirch_line_(496);
  #line 496 "src/math/update.birch"
  auto M_prime_ = birch::solve(Λ_prime_, N_prime_);
  #line 497 "src/math/update.birch"
  libbirch_line_(497);
  #line 497 "src/math/update.birch"
  auto V_prime_ = birch::llt(birch::canonical(V) + birch::transpose(X) * X + birch::transpose(M) * N - birch::transpose(M_prime_) * N_prime_);
  #line 499 "src/math/update.birch"
  libbirch_line_(499);
  #line 499 "src/math/update.birch"
  auto k_prime_ = k + D;
  #line 500 "src/math/update.birch"
  libbirch_line_(500);
  #line 500 "src/math/update.birch"
  return std::make_tuple(N_prime_, Λ_prime_, V_prime_, k_prime_);
}

#line 517 "src/math/update.birch"
std::tuple<libbirch::DefaultArray<birch::type::Real,2>, birch::type::LLT, birch::type::LLT, birch::type::Real> birch::update_linear_matrix_normal_inverse_wishart_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& A, const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& Λ, const libbirch::DefaultArray<birch::type::Real,2>& C, const birch::type::LLT& V, const birch::type::Real& k) {
  #line 517 "src/math/update.birch"
  libbirch_function_("update_linear_matrix_normal_inverse_wishart_matrix_gaussian", "src/math/update.birch", 517);
  #line 520 "src/math/update.birch"
  libbirch_line_(520);
  #line 520 "src/math/update.birch"
  auto D = birch::rows(X);
  #line 521 "src/math/update.birch"
  libbirch_line_(521);
  #line 521 "src/math/update.birch"
  auto Λ_prime_ = birch::rank_update(Λ, birch::transpose(A));
  #line 522 "src/math/update.birch"
  libbirch_line_(522);
  #line 522 "src/math/update.birch"
  auto N_prime_ = N + birch::transpose(A) * (X - C);
  #line 523 "src/math/update.birch"
  libbirch_line_(523);
  #line 523 "src/math/update.birch"
  auto M = birch::solve(Λ, N);
  #line 524 "src/math/update.birch"
  libbirch_line_(524);
  #line 524 "src/math/update.birch"
  auto M_prime_ = birch::solve(Λ_prime_, N_prime_);
  #line 525 "src/math/update.birch"
  libbirch_line_(525);
  #line 525 "src/math/update.birch"
  auto V_prime_ = birch::llt(birch::canonical(V) + birch::transpose(X - C) * (X - C) + birch::transpose(M) * N - birch::transpose(M_prime_) * N_prime_);
  #line 527 "src/math/update.birch"
  libbirch_line_(527);
  #line 527 "src/math/update.birch"
  auto k_prime_ = k + D;
  #line 528 "src/math/update.birch"
  libbirch_line_(528);
  #line 528 "src/math/update.birch"
  return std::make_tuple(N_prime_, Λ_prime_, V_prime_, k_prime_);
}

#line 545 "src/math/update.birch"
std::tuple<libbirch::DefaultArray<birch::type::Real,2>, birch::type::LLT, birch::type::LLT, birch::type::Real> birch::update_linear_matrix_normal_inverse_wishart_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& a, const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& Λ, const libbirch::DefaultArray<birch::type::Real,1>& c, const birch::type::LLT& V, const birch::type::Real& k) {
  #line 545 "src/math/update.birch"
  libbirch_function_("update_linear_matrix_normal_inverse_wishart_multivariate_gaussian", "src/math/update.birch", 545);
  #line 548 "src/math/update.birch"
  libbirch_line_(548);
  #line 548 "src/math/update.birch"
  auto Λ_prime_ = birch::rank_update(Λ, a);
  #line 549 "src/math/update.birch"
  libbirch_line_(549);
  #line 549 "src/math/update.birch"
  auto N_prime_ = N + birch::outer(a, x - c);
  #line 550 "src/math/update.birch"
  libbirch_line_(550);
  #line 550 "src/math/update.birch"
  auto M = birch::solve(Λ, N);
  #line 551 "src/math/update.birch"
  libbirch_line_(551);
  #line 551 "src/math/update.birch"
  auto M_prime_ = birch::solve(Λ_prime_, N_prime_);
  #line 552 "src/math/update.birch"
  libbirch_line_(552);
  #line 552 "src/math/update.birch"
  auto V_prime_ = birch::llt(birch::canonical(V) + birch::outer(x - birch::dot(a, M_prime_) - c) + birch::transpose(M_prime_ - M) * birch::canonical(Λ) * (M_prime_ - M));
  #line 554 "src/math/update.birch"
  libbirch_line_(554);
  #line 554 "src/math/update.birch"
  auto k_prime_ = k + birch::type::Integer(1);
  #line 555 "src/math/update.birch"
  libbirch_line_(555);
  #line 555 "src/math/update.birch"
  return std::make_tuple(N_prime_, Λ_prime_, V_prime_, k_prime_);
}

#line 10 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<birch::type::Real>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::update_lazy_beta_bernoulli(const libbirch::Shared<birch::type::Expression<birch::type::Boolean>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& β) {
  #line 10 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_beta_bernoulli", "src/math/update_lazy.birch", 10);
  #line 13 "src/math/update_lazy.birch"
  libbirch_line_(13);
  #line 13 "src/math/update_lazy.birch"
  return std::make_tuple(α + birch::Real(x), β + (1.0 - birch::Real(x)));
}

#line 26 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<birch::type::Real>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::update_lazy_beta_binomial(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& n, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& β) {
  #line 26 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_beta_binomial", "src/math/update_lazy.birch", 26);
  #line 29 "src/math/update_lazy.birch"
  libbirch_line_(29);
  #line 29 "src/math/update_lazy.birch"
  return std::make_tuple(α + birch::Real(x), β + birch::Real(n - x));
}

#line 42 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<birch::type::Real>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::update_lazy_beta_negative_binomial(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& k, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& β) {
  #line 42 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_beta_negative_binomial", "src/math/update_lazy.birch", 42);
  #line 45 "src/math/update_lazy.birch"
  libbirch_line_(45);
  #line 45 "src/math/update_lazy.birch"
  return std::make_tuple(α + birch::Real(k), β + birch::Real(x));
}

#line 57 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<birch::type::Real>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::update_lazy_gamma_poisson(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& θ) {
  #line 57 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_gamma_poisson", "src/math/update_lazy.birch", 57);
  #line 59 "src/math/update_lazy.birch"
  libbirch_line_(59);
  #line 59 "src/math/update_lazy.birch"
  return std::make_tuple(k + birch::Real(x), θ / (θ + 1.0));
}

#line 73 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<birch::type::Real>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::update_lazy_scaled_gamma_poisson(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& a, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& θ) {
  #line 73 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_scaled_gamma_poisson", "src/math/update_lazy.birch", 73);
  #line 76 "src/math/update_lazy.birch"
  libbirch_line_(76);
  #line 76 "src/math/update_lazy.birch"
  return std::make_tuple(k + birch::Real(x), θ / (a * θ + 1.0));
}

#line 89 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<birch::type::Real>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::update_lazy_gamma_exponential(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& θ) {
  #line 89 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_gamma_exponential", "src/math/update_lazy.birch", 89);
  #line 92 "src/math/update_lazy.birch"
  libbirch_line_(92);
  #line 92 "src/math/update_lazy.birch"
  return std::make_tuple(k + 1.0, θ / (1.0 + x * θ));
}

#line 106 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<birch::type::Real>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::update_lazy_scaled_gamma_exponential(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& a, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& θ) {
  #line 106 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_scaled_gamma_exponential", "src/math/update_lazy.birch", 106);
  #line 109 "src/math/update_lazy.birch"
  libbirch_line_(109);
  #line 109 "src/math/update_lazy.birch"
  return std::make_tuple(k + 1.0, θ / (1.0 + x * a * θ));
}

#line 123 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<birch::type::Real>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::update_lazy_inverse_gamma_weibull(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& β) {
  #line 123 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_inverse_gamma_weibull", "src/math/update_lazy.birch", 123);
  #line 126 "src/math/update_lazy.birch"
  libbirch_line_(126);
  #line 126 "src/math/update_lazy.birch"
  return std::make_tuple(α + 1.0, β + birch::pow(x, k));
}

#line 141 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<birch::type::Real>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::update_lazy_scaled_inverse_gamma_weibull(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& a, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& β) {
  #line 141 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_scaled_inverse_gamma_weibull", "src/math/update_lazy.birch", 141);
  #line 144 "src/math/update_lazy.birch"
  libbirch_line_(144);
  #line 144 "src/math/update_lazy.birch"
  return std::make_tuple(α + 1.0, β + birch::pow(x, k) / a);
}

#line 187 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<birch::type::Real>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::update_lazy_gaussian_gaussian(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& μ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& σ2, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& s2) {
  #line 187 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_gaussian_gaussian", "src/math/update_lazy.birch", 187);
  #line 190 "src/math/update_lazy.birch"
  libbirch_line_(190);
  #line 190 "src/math/update_lazy.birch"
  auto λ = 1.0 / σ2;
  #line 191 "src/math/update_lazy.birch"
  libbirch_line_(191);
  #line 191 "src/math/update_lazy.birch"
  auto l = 1.0 / s2;
  #line 192 "src/math/update_lazy.birch"
  libbirch_line_(192);
  #line 192 "src/math/update_lazy.birch"
  auto λ_prime_ = λ + l;
  #line 193 "src/math/update_lazy.birch"
  libbirch_line_(193);
  #line 193 "src/math/update_lazy.birch"
  auto μ_prime_ = (λ * μ + l * x) / λ_prime_;
  #line 194 "src/math/update_lazy.birch"
  libbirch_line_(194);
  #line 194 "src/math/update_lazy.birch"
  return std::make_tuple(μ_prime_, 1.0 / λ_prime_);
}

#line 210 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<birch::type::Real>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::update_lazy_linear_gaussian_gaussian(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& a, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& μ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& σ2, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& c, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& s2) {
  #line 210 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_linear_gaussian_gaussian", "src/math/update_lazy.birch", 210);
  #line 213 "src/math/update_lazy.birch"
  libbirch_line_(213);
  #line 213 "src/math/update_lazy.birch"
  auto λ = 1.0 / σ2;
  #line 214 "src/math/update_lazy.birch"
  libbirch_line_(214);
  #line 214 "src/math/update_lazy.birch"
  auto l = 1.0 / s2;
  #line 215 "src/math/update_lazy.birch"
  libbirch_line_(215);
  #line 215 "src/math/update_lazy.birch"
  auto λ_prime_ = λ + a * a * l;
  #line 216 "src/math/update_lazy.birch"
  libbirch_line_(216);
  #line 216 "src/math/update_lazy.birch"
  auto μ_prime_ = (λ * μ + a * l * (x - c)) / λ_prime_;
  #line 217 "src/math/update_lazy.birch"
  libbirch_line_(217);
  #line 217 "src/math/update_lazy.birch"
  return std::make_tuple(μ_prime_, 1.0 / λ_prime_);
}

#line 232 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<birch::type::Real>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::update_lazy_normal_inverse_gamma(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& μ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& λ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& β) {
  #line 232 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_normal_inverse_gamma", "src/math/update_lazy.birch", 232);
  #line 235 "src/math/update_lazy.birch"
  libbirch_line_(235);
  #line 235 "src/math/update_lazy.birch"
  return std::make_tuple(α + 0.5, β + 0.5 * birch::pow(x - μ, 2.0) * λ);
}

#line 250 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<birch::type::Real>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::update_lazy_normal_inverse_gamma_gaussian(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& μ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& λ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& β) {
  #line 250 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_normal_inverse_gamma_gaussian", "src/math/update_lazy.birch", 250);
  #line 254 "src/math/update_lazy.birch"
  libbirch_line_(254);
  #line 254 "src/math/update_lazy.birch"
  auto λ_prime_ = λ + 1.0;
  #line 255 "src/math/update_lazy.birch"
  libbirch_line_(255);
  #line 255 "src/math/update_lazy.birch"
  auto μ_prime_ = (λ * μ + x) / λ_prime_;
  #line 256 "src/math/update_lazy.birch"
  libbirch_line_(256);
  #line 256 "src/math/update_lazy.birch"
  auto α_prime_ = α + 0.5;
  #line 257 "src/math/update_lazy.birch"
  libbirch_line_(257);
  #line 257 "src/math/update_lazy.birch"
  auto β_prime_ = β + 0.5 * (λ / λ_prime_) * birch::pow(x - μ, 2.0);
  #line 258 "src/math/update_lazy.birch"
  libbirch_line_(258);
  #line 258 "src/math/update_lazy.birch"
  return std::make_tuple(μ_prime_, λ_prime_, α_prime_, β_prime_);
}

#line 275 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<birch::type::Real>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::update_lazy_linear_normal_inverse_gamma_gaussian(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& a, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& μ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& λ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& c, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& β) {
  #line 275 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_linear_normal_inverse_gamma_gaussian", "src/math/update_lazy.birch", 275);
  #line 279 "src/math/update_lazy.birch"
  libbirch_line_(279);
  #line 279 "src/math/update_lazy.birch"
  auto y = x - c;
  #line 280 "src/math/update_lazy.birch"
  libbirch_line_(280);
  #line 280 "src/math/update_lazy.birch"
  auto λ_prime_ = λ + a * a;
  #line 281 "src/math/update_lazy.birch"
  libbirch_line_(281);
  #line 281 "src/math/update_lazy.birch"
  auto μ_prime_ = (λ * μ + a * y) / λ_prime_;
  #line 282 "src/math/update_lazy.birch"
  libbirch_line_(282);
  #line 282 "src/math/update_lazy.birch"
  auto α_prime_ = α + 0.5;
  #line 283 "src/math/update_lazy.birch"
  libbirch_line_(283);
  #line 283 "src/math/update_lazy.birch"
  auto β_prime_ = β + 0.5 * (y * y + μ * μ * λ - μ_prime_ * μ_prime_ * λ_prime_);
  #line 284 "src/math/update_lazy.birch"
  libbirch_line_(284);
  #line 284 "src/math/update_lazy.birch"
  return std::make_tuple(μ_prime_, λ_prime_, α_prime_, β_prime_);
}

#line 298 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<birch::type::Real>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::update_lazy_inverse_gamma_gamma(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& β) {
  #line 298 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_inverse_gamma_gamma", "src/math/update_lazy.birch", 298);
  #line 301 "src/math/update_lazy.birch"
  libbirch_line_(301);
  #line 301 "src/math/update_lazy.birch"
  return std::make_tuple(α + k, β + x);
}

#line 315 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>, libbirch::Shared<birch::type::Expression<birch::type::LLT>>> birch::update_lazy_multivariate_gaussian_multivariate_gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& μ, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Σ, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& S) {
  #line 315 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_multivariate_gaussian_multivariate_gaussian", "src/math/update_lazy.birch", 315);
  #line 318 "src/math/update_lazy.birch"
  libbirch_line_(318);
  #line 318 "src/math/update_lazy.birch"
  auto Σ0 = birch::canonical(Σ);
  #line 319 "src/math/update_lazy.birch"
  libbirch_line_(319);
  #line 319 "src/math/update_lazy.birch"
  auto S0 = birch::canonical(S);
  #line 320 "src/math/update_lazy.birch"
  libbirch_line_(320);
  #line 320 "src/math/update_lazy.birch"
  auto K_prime_ = birch::transpose(birch::solve(birch::llt(Σ0 + S0), Σ0));
  #line 321 "src/math/update_lazy.birch"
  libbirch_line_(321);
  #line 321 "src/math/update_lazy.birch"
  auto μ_prime_ = μ + K_prime_ * (x - μ);
  #line 322 "src/math/update_lazy.birch"
  libbirch_line_(322);
  #line 322 "src/math/update_lazy.birch"
  auto Σ_prime_ = birch::llt(Σ0 - K_prime_ * Σ0);
  #line 323 "src/math/update_lazy.birch"
  libbirch_line_(323);
  #line 323 "src/math/update_lazy.birch"
  return std::make_tuple(μ_prime_, Σ_prime_);
}

#line 339 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>, libbirch::Shared<birch::type::Expression<birch::type::LLT>>> birch::update_lazy_linear_multivariate_gaussian_multivariate_gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& A, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& μ, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Σ, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& c, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& S) {
  #line 339 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_linear_multivariate_gaussian_multivariate_gaussian", "src/math/update_lazy.birch", 339);
  #line 343 "src/math/update_lazy.birch"
  libbirch_line_(343);
  #line 343 "src/math/update_lazy.birch"
  auto Σ0 = birch::canonical(Σ);
  #line 344 "src/math/update_lazy.birch"
  libbirch_line_(344);
  #line 344 "src/math/update_lazy.birch"
  auto S0 = birch::canonical(S);
  #line 345 "src/math/update_lazy.birch"
  libbirch_line_(345);
  #line 345 "src/math/update_lazy.birch"
  auto K_prime_ = Σ0 * birch::transpose(birch::solve(birch::llt(A * Σ0 * birch::transpose(A) + S0), A));
  #line 346 "src/math/update_lazy.birch"
  libbirch_line_(346);
  #line 346 "src/math/update_lazy.birch"
  auto μ_prime_ = μ + K_prime_ * (x - A * μ - c);
  #line 347 "src/math/update_lazy.birch"
  libbirch_line_(347);
  #line 347 "src/math/update_lazy.birch"
  auto Σ_prime_ = birch::llt(Σ0 - K_prime_ * A * Σ0);
  #line 348 "src/math/update_lazy.birch"
  libbirch_line_(348);
  #line 348 "src/math/update_lazy.birch"
  return std::make_tuple(μ_prime_, Σ_prime_);
}

#line 365 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>, libbirch::Shared<birch::type::Expression<birch::type::LLT>>> birch::update_lazy_linear_multivariate_gaussian_gaussian(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& a, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& μ, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Σ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& c, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& s2) {
  #line 365 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_linear_multivariate_gaussian_gaussian", "src/math/update_lazy.birch", 365);
  #line 369 "src/math/update_lazy.birch"
  libbirch_line_(369);
  #line 369 "src/math/update_lazy.birch"
  auto Σ0 = birch::canonical(Σ);
  #line 370 "src/math/update_lazy.birch"
  libbirch_line_(370);
  #line 370 "src/math/update_lazy.birch"
  auto k_prime_ = Σ0 * a / (birch::dot(a, Σ0 * a) + s2);
  #line 371 "src/math/update_lazy.birch"
  libbirch_line_(371);
  #line 371 "src/math/update_lazy.birch"
  auto μ_prime_ = μ + k_prime_ * (x - birch::dot(a, μ) - c);
  #line 372 "src/math/update_lazy.birch"
  libbirch_line_(372);
  #line 372 "src/math/update_lazy.birch"
  auto Σ_prime_ = birch::llt(Σ0 - birch::outer(k_prime_, a) * Σ0);
  #line 373 "src/math/update_lazy.birch"
  libbirch_line_(373);
  #line 373 "src/math/update_lazy.birch"
  return std::make_tuple(μ_prime_, Σ_prime_);
}

#line 388 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<birch::type::Real>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::update_lazy_multivariate_normal_inverse_gamma(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& ν, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Λ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& β) {
  #line 388 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_multivariate_normal_inverse_gamma", "src/math/update_lazy.birch", 388);
  #line 391 "src/math/update_lazy.birch"
  libbirch_line_(391);
  #line 391 "src/math/update_lazy.birch"
  auto D = x->length();
  #line 392 "src/math/update_lazy.birch"
  libbirch_line_(392);
  #line 392 "src/math/update_lazy.birch"
  auto μ = birch::solve(Λ, ν);
  #line 393 "src/math/update_lazy.birch"
  libbirch_line_(393);
  #line 393 "src/math/update_lazy.birch"
  return std::make_tuple(α + 0.5 * D, β + 0.5 * birch::dot(x - μ, birch::canonical(Λ) * (x - μ)));
}

#line 408 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>, libbirch::Shared<birch::type::Expression<birch::type::LLT>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::update_lazy_multivariate_normal_inverse_gamma_multivariate_gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& ν, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Λ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& γ) {
  #line 408 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/math/update_lazy.birch", 408);
  #line 412 "src/math/update_lazy.birch"
  libbirch_line_(412);
  #line 412 "src/math/update_lazy.birch"
  auto D = x->length();
  #line 413 "src/math/update_lazy.birch"
  libbirch_line_(413);
  #line 413 "src/math/update_lazy.birch"
  auto Λ_prime_ = birch::rank_update(Λ, birch::identity(birch::rows(Λ)));
  #line 414 "src/math/update_lazy.birch"
  libbirch_line_(414);
  #line 414 "src/math/update_lazy.birch"
  auto ν_prime_ = ν + x;
  #line 415 "src/math/update_lazy.birch"
  libbirch_line_(415);
  #line 415 "src/math/update_lazy.birch"
  auto α_prime_ = α + 0.5 * D;
  #line 416 "src/math/update_lazy.birch"
  libbirch_line_(416);
  #line 416 "src/math/update_lazy.birch"
  auto γ_prime_ = γ + 0.5 * birch::dot(x);
  #line 417 "src/math/update_lazy.birch"
  libbirch_line_(417);
  #line 417 "src/math/update_lazy.birch"
  return std::make_tuple(ν_prime_, Λ_prime_, α_prime_, γ_prime_);
}

#line 434 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>, libbirch::Shared<birch::type::Expression<birch::type::LLT>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::update_lazy_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& A, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& ν, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Λ, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& c, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& γ) {
  #line 434 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_linear_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/math/update_lazy.birch", 434);
  #line 439 "src/math/update_lazy.birch"
  libbirch_line_(439);
  #line 439 "src/math/update_lazy.birch"
  auto D = birch::length(x);
  #line 440 "src/math/update_lazy.birch"
  libbirch_line_(440);
  #line 440 "src/math/update_lazy.birch"
  auto Λ_prime_ = birch::rank_update(Λ, birch::transpose(A));
  #line 441 "src/math/update_lazy.birch"
  libbirch_line_(441);
  #line 441 "src/math/update_lazy.birch"
  auto ν_prime_ = ν + birch::transpose(A) * (x - c);
  #line 442 "src/math/update_lazy.birch"
  libbirch_line_(442);
  #line 442 "src/math/update_lazy.birch"
  auto α_prime_ = α + 0.5 * D;
  #line 443 "src/math/update_lazy.birch"
  libbirch_line_(443);
  #line 443 "src/math/update_lazy.birch"
  auto γ_prime_ = γ + 0.5 * birch::dot(x - c);
  #line 444 "src/math/update_lazy.birch"
  libbirch_line_(444);
  #line 444 "src/math/update_lazy.birch"
  return std::make_tuple(ν_prime_, Λ_prime_, α_prime_, γ_prime_);
}

#line 461 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>, libbirch::Shared<birch::type::Expression<birch::type::LLT>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::update_lazy_linear_multivariate_normal_inverse_gamma_gaussian(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& a, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& ν, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Λ, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& c, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& α, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& γ) {
  #line 461 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_linear_multivariate_normal_inverse_gamma_gaussian", "src/math/update_lazy.birch", 461);
  #line 466 "src/math/update_lazy.birch"
  libbirch_line_(466);
  #line 466 "src/math/update_lazy.birch"
  auto Λ_prime_ = birch::rank_update(Λ, a);
  #line 467 "src/math/update_lazy.birch"
  libbirch_line_(467);
  #line 467 "src/math/update_lazy.birch"
  auto ν_prime_ = ν + a * (x - c);
  #line 468 "src/math/update_lazy.birch"
  libbirch_line_(468);
  #line 468 "src/math/update_lazy.birch"
  auto α_prime_ = α + 0.5;
  #line 469 "src/math/update_lazy.birch"
  libbirch_line_(469);
  #line 469 "src/math/update_lazy.birch"
  auto γ_prime_ = γ + 0.5 * birch::pow(x - c, 2.0);
  #line 470 "src/math/update_lazy.birch"
  libbirch_line_(470);
  #line 470 "src/math/update_lazy.birch"
  return std::make_tuple(ν_prime_, Λ_prime_, α_prime_, γ_prime_);
}

#line 484 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<birch::type::LLT>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::update_lazy_matrix_normal_inverse_wishart(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& X, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& N, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Λ, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& V, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k) {
  #line 484 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_matrix_normal_inverse_wishart", "src/math/update_lazy.birch", 484);
  #line 487 "src/math/update_lazy.birch"
  libbirch_line_(487);
  #line 487 "src/math/update_lazy.birch"
  auto n = birch::rows(X);
  #line 488 "src/math/update_lazy.birch"
  libbirch_line_(488);
  #line 488 "src/math/update_lazy.birch"
  auto M = birch::solve(Λ, N);
  #line 489 "src/math/update_lazy.birch"
  libbirch_line_(489);
  #line 489 "src/math/update_lazy.birch"
  auto V_prime_ = birch::llt(birch::canonical(V) + birch::transpose(X - M) * birch::canonical(Λ) * (X - M));
  #line 490 "src/math/update_lazy.birch"
  libbirch_line_(490);
  #line 490 "src/math/update_lazy.birch"
  auto k_prime_ = k + n;
  #line 491 "src/math/update_lazy.birch"
  libbirch_line_(491);
  #line 491 "src/math/update_lazy.birch"
  return std::make_tuple(V_prime_, k_prime_);
}

#line 506 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::Shared<birch::type::Expression<birch::type::LLT>>, libbirch::Shared<birch::type::Expression<birch::type::LLT>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::update_lazy_matrix_normal_inverse_wishart_matrix_gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& X, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& N, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Λ, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& V, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k) {
  #line 506 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_matrix_normal_inverse_wishart_matrix_gaussian", "src/math/update_lazy.birch", 506);
  #line 510 "src/math/update_lazy.birch"
  libbirch_line_(510);
  #line 510 "src/math/update_lazy.birch"
  auto D = birch::rows(X);
  #line 511 "src/math/update_lazy.birch"
  libbirch_line_(511);
  #line 511 "src/math/update_lazy.birch"
  auto Λ_prime_ = birch::rank_update(Λ, birch::identity(birch::rows(N)));
  #line 512 "src/math/update_lazy.birch"
  libbirch_line_(512);
  #line 512 "src/math/update_lazy.birch"
  auto N_prime_ = N + X;
  #line 513 "src/math/update_lazy.birch"
  libbirch_line_(513);
  #line 513 "src/math/update_lazy.birch"
  auto M = birch::solve(Λ, N);
  #line 514 "src/math/update_lazy.birch"
  libbirch_line_(514);
  #line 514 "src/math/update_lazy.birch"
  auto M_prime_ = birch::solve(Λ_prime_, N_prime_);
  #line 515 "src/math/update_lazy.birch"
  libbirch_line_(515);
  #line 515 "src/math/update_lazy.birch"
  auto V_prime_ = birch::llt(birch::canonical(V) + birch::transpose(X) * X + birch::transpose(M) * N - birch::transpose(M_prime_) * N_prime_);
  #line 517 "src/math/update_lazy.birch"
  libbirch_line_(517);
  #line 517 "src/math/update_lazy.birch"
  auto k_prime_ = k + D;
  #line 518 "src/math/update_lazy.birch"
  libbirch_line_(518);
  #line 518 "src/math/update_lazy.birch"
  return std::make_tuple(N_prime_, Λ_prime_, V_prime_, k_prime_);
}

#line 535 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::Shared<birch::type::Expression<birch::type::LLT>>, libbirch::Shared<birch::type::Expression<birch::type::LLT>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::update_lazy_linear_matrix_normal_inverse_wishart_matrix_gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& X, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& A, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& N, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Λ, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& C, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& V, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k) {
  #line 535 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_linear_matrix_normal_inverse_wishart_matrix_gaussian", "src/math/update_lazy.birch", 535);
  #line 540 "src/math/update_lazy.birch"
  libbirch_line_(540);
  #line 540 "src/math/update_lazy.birch"
  auto D = birch::rows(X);
  #line 541 "src/math/update_lazy.birch"
  libbirch_line_(541);
  #line 541 "src/math/update_lazy.birch"
  auto Λ_prime_ = birch::rank_update(Λ, birch::transpose(A));
  #line 542 "src/math/update_lazy.birch"
  libbirch_line_(542);
  #line 542 "src/math/update_lazy.birch"
  auto N_prime_ = N + birch::transpose(A) * (X - C);
  #line 543 "src/math/update_lazy.birch"
  libbirch_line_(543);
  #line 543 "src/math/update_lazy.birch"
  auto M = birch::solve(Λ, N);
  #line 544 "src/math/update_lazy.birch"
  libbirch_line_(544);
  #line 544 "src/math/update_lazy.birch"
  auto M_prime_ = birch::solve(Λ_prime_, N_prime_);
  #line 545 "src/math/update_lazy.birch"
  libbirch_line_(545);
  #line 545 "src/math/update_lazy.birch"
  auto V_prime_ = birch::llt(birch::canonical(V) + birch::transpose(X - C) * (X - C) + birch::transpose(M) * N - birch::transpose(M_prime_) * N_prime_);
  #line 547 "src/math/update_lazy.birch"
  libbirch_line_(547);
  #line 547 "src/math/update_lazy.birch"
  auto k_prime_ = k + D;
  #line 548 "src/math/update_lazy.birch"
  libbirch_line_(548);
  #line 548 "src/math/update_lazy.birch"
  return std::make_tuple(N_prime_, Λ_prime_, V_prime_, k_prime_);
}

#line 565 "src/math/update_lazy.birch"
std::tuple<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>, libbirch::Shared<birch::type::Expression<birch::type::LLT>>, libbirch::Shared<birch::type::Expression<birch::type::LLT>>, libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::update_lazy_linear_matrix_normal_inverse_wishart_multivariate_gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& a, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& N, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& Λ, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& c, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& V, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k) {
  #line 565 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_linear_matrix_normal_inverse_wishart_multivariate_gaussian", "src/math/update_lazy.birch", 565);
  #line 570 "src/math/update_lazy.birch"
  libbirch_line_(570);
  #line 570 "src/math/update_lazy.birch"
  auto Λ_prime_ = birch::rank_update(Λ, a);
  #line 571 "src/math/update_lazy.birch"
  libbirch_line_(571);
  #line 571 "src/math/update_lazy.birch"
  auto N_prime_ = N + birch::outer(a, x - c);
  #line 572 "src/math/update_lazy.birch"
  libbirch_line_(572);
  #line 572 "src/math/update_lazy.birch"
  auto M = birch::solve(Λ, N);
  #line 573 "src/math/update_lazy.birch"
  libbirch_line_(573);
  #line 573 "src/math/update_lazy.birch"
  auto M_prime_ = birch::solve(Λ_prime_, N_prime_);
  #line 574 "src/math/update_lazy.birch"
  libbirch_line_(574);
  #line 574 "src/math/update_lazy.birch"
  auto V_prime_ = birch::llt(birch::canonical(V) + birch::outer(x - c) + birch::transpose(M) * N - birch::transpose(M_prime_) * N_prime_);
  #line 576 "src/math/update_lazy.birch"
  libbirch_line_(576);
  #line 576 "src/math/update_lazy.birch"
  auto k_prime_ = k + 1.0;
  #line 577 "src/math/update_lazy.birch"
  libbirch_line_(577);
  #line 577 "src/math/update_lazy.birch"
  return std::make_tuple(N_prime_, Λ_prime_, V_prime_, k_prime_);
}

#line 226 "src/math/vector.birch"
birch::type::String birch::String(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 226 "src/math/vector.birch"
  libbirch_function_("String", "src/math/vector.birch", 226);
  #line 227 "src/math/vector.birch"
  libbirch_line_(227);
  #line 227 "src/math/vector.birch"
  birch::type::String result = libbirch::make<birch::type::String>();
  #line 228 "src/math/vector.birch"

  std::stringstream buf;
    #line 231 "src/math/vector.birch"
  libbirch_line_(231);
  #line 231 "src/math/vector.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(x); ++i) {
    #line 232 "src/math/vector.birch"
    libbirch_line_(232);
    #line 232 "src/math/vector.birch"
    auto value = x(i);
    #line 233 "src/math/vector.birch"

    if (i > 1) {
      buf << ' ';
    }
    if (value == floor(value)) {
      buf << (int64_t)value << ".0";
    } else {
      buf << std::scientific << std::setprecision(6) << value;
    }
      }
  #line 244 "src/math/vector.birch"

  result = buf.str();
    #line 247 "src/math/vector.birch"
  libbirch_line_(247);
  #line 247 "src/math/vector.birch"
  return result;
}

#line 253 "src/math/vector.birch"
birch::type::String birch::String(const libbirch::DefaultArray<birch::type::Integer,1>& x) {
  #line 253 "src/math/vector.birch"
  libbirch_function_("String", "src/math/vector.birch", 253);
  #line 254 "src/math/vector.birch"
  libbirch_line_(254);
  #line 254 "src/math/vector.birch"
  birch::type::String result = libbirch::make<birch::type::String>();
  #line 255 "src/math/vector.birch"

  std::stringstream buf;
    #line 258 "src/math/vector.birch"
  libbirch_line_(258);
  #line 258 "src/math/vector.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(x); ++i) {
    #line 259 "src/math/vector.birch"
    libbirch_line_(259);
    #line 259 "src/math/vector.birch"
    auto value = x(i);
    #line 260 "src/math/vector.birch"

    if (i > 1) {
      buf << ' ';
    }
    buf << value;
      }
  #line 267 "src/math/vector.birch"

  result = buf.str();
    #line 270 "src/math/vector.birch"
  libbirch_line_(270);
  #line 270 "src/math/vector.birch"
  return result;
}

#line 276 "src/math/vector.birch"
birch::type::String birch::String(const libbirch::DefaultArray<birch::type::Boolean,1>& x) {
  #line 276 "src/math/vector.birch"
  libbirch_function_("String", "src/math/vector.birch", 276);
  #line 277 "src/math/vector.birch"
  libbirch_line_(277);
  #line 277 "src/math/vector.birch"
  birch::type::String result = libbirch::make<birch::type::String>();
  #line 278 "src/math/vector.birch"

  std::stringstream buf;
    #line 281 "src/math/vector.birch"
  libbirch_line_(281);
  #line 281 "src/math/vector.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(x); ++i) {
    #line 282 "src/math/vector.birch"
    libbirch_line_(282);
    #line 282 "src/math/vector.birch"
    auto value = x(i);
    #line 283 "src/math/vector.birch"

    if (i > 1) {
      buf << ' ';
    }
    if (value) {
      buf << "true";
    } else {
      buf << "false";
    }
      }
  #line 294 "src/math/vector.birch"

  result = buf.str();
    #line 297 "src/math/vector.birch"
  libbirch_line_(297);
  #line 297 "src/math/vector.birch"
  return result;
}

