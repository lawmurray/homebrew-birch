#line 1 "src/math/cdf.birch"
#include <boost/math/distributions.hpp>
#line 14 "src/math/cdf.birch"
birch::type::Real birch::cdf_binomial(const birch::type::Integer& x, const birch::type::Integer& n, const birch::type::Real& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/math/cdf.birch"
  libbirch_function_("cdf_binomial", "src/math/cdf.birch", 14);
  #line 15 "src/math/cdf.birch"
  libbirch_line_(15);
  #line 15 "src/math/cdf.birch"
  libbirch_assert_(birch::type::Integer(0) <= n);
  #line 16 "src/math/cdf.birch"
  libbirch_line_(16);
  #line 16 "src/math/cdf.birch"
  libbirch_assert_(0.0 <= _u0961 && _u0961 <= 1.0);
  #line 18 "src/math/cdf.birch"
  libbirch_line_(18);
  #line 18 "src/math/cdf.birch"
  if (x < birch::type::Integer(0)) {
    #line 19 "src/math/cdf.birch"
    libbirch_line_(19);
    #line 19 "src/math/cdf.birch"
    return 0.0;
  } else {
    #line 20 "src/math/cdf.birch"
    libbirch_line_(20);
    #line 20 "src/math/cdf.birch"
    if (x > n) {
      #line 21 "src/math/cdf.birch"
      libbirch_line_(21);
      #line 21 "src/math/cdf.birch"
      return 1.0;
    } else {
      #line 23 "src/math/cdf.birch"
return boost::math::cdf(boost::math::binomial_distribution<>(n, _u0961), x);
        }
  }
}

#line 38 "src/math/cdf.birch"
birch::type::Real birch::cdf_negative_binomial(const birch::type::Integer& x, const birch::type::Integer& k, const birch::type::Real& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "src/math/cdf.birch"
  libbirch_function_("cdf_negative_binomial", "src/math/cdf.birch", 38);
  #line 39 "src/math/cdf.birch"
  libbirch_line_(39);
  #line 39 "src/math/cdf.birch"
  libbirch_assert_(birch::type::Integer(0) < k);
  #line 40 "src/math/cdf.birch"
  libbirch_line_(40);
  #line 40 "src/math/cdf.birch"
  libbirch_assert_(0.0 <= _u0961 && _u0961 <= 1.0);
  #line 42 "src/math/cdf.birch"
  libbirch_line_(42);
  #line 42 "src/math/cdf.birch"
  if (x < birch::type::Integer(0)) {
    #line 43 "src/math/cdf.birch"
    libbirch_line_(43);
    #line 43 "src/math/cdf.birch"
    return 0.0;
  } else {
    #line 45 "src/math/cdf.birch"
return boost::math::cdf(boost::math::negative_binomial_distribution<>(k, _u0961), x);
      }
}

#line 59 "src/math/cdf.birch"
birch::type::Real birch::cdf_poisson(const birch::type::Integer& x, const birch::type::Real& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/math/cdf.birch"
  libbirch_function_("cdf_poisson", "src/math/cdf.birch", 59);
  #line 60 "src/math/cdf.birch"
  libbirch_line_(60);
  #line 60 "src/math/cdf.birch"
  libbirch_assert_(0.0 <= _u0955);
  #line 62 "src/math/cdf.birch"
  libbirch_line_(62);
  #line 62 "src/math/cdf.birch"
  if (x < birch::type::Integer(0)) {
    #line 63 "src/math/cdf.birch"
    libbirch_line_(63);
    #line 63 "src/math/cdf.birch"
    return 0.0;
  } else {
    #line 65 "src/math/cdf.birch"
return boost::math::cdf(boost::math::poisson_distribution<>(_u0955), x);
      }
}

#line 80 "src/math/cdf.birch"
birch::type::Real birch::cdf_uniform_int(const birch::type::Integer& x, const birch::type::Integer& l, const birch::type::Integer& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 80 "src/math/cdf.birch"
  libbirch_function_("cdf_uniform_int", "src/math/cdf.birch", 80);
  #line 81 "src/math/cdf.birch"
  libbirch_line_(81);
  #line 81 "src/math/cdf.birch"
  if (x < l) {
    #line 82 "src/math/cdf.birch"
    libbirch_line_(82);
    #line 82 "src/math/cdf.birch"
    return 0.0;
  } else {
    #line 83 "src/math/cdf.birch"
    libbirch_line_(83);
    #line 83 "src/math/cdf.birch"
    if (x > u) {
      #line 84 "src/math/cdf.birch"
      libbirch_line_(84);
      #line 84 "src/math/cdf.birch"
      return 1.0;
    } else {
      #line 86 "src/math/cdf.birch"
      libbirch_line_(86);
      #line 86 "src/math/cdf.birch"
      return (x - l + birch::type::Integer(1)) / birch::Real(u - l + birch::type::Integer(1), handler_);
    }
  }
}

#line 98 "src/math/cdf.birch"
birch::type::Real birch::cdf_categorical(const birch::type::Integer& x, const libbirch::DefaultArray<birch::type::Real,1>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 98 "src/math/cdf.birch"
  libbirch_function_("cdf_categorical", "src/math/cdf.birch", 98);
  #line 99 "src/math/cdf.birch"
  libbirch_line_(99);
  #line 99 "src/math/cdf.birch"
  if (birch::type::Integer(1) <= x && x <= birch::length(_u0961, handler_)) {
    #line 100 "src/math/cdf.birch"
    libbirch_line_(100);
    #line 100 "src/math/cdf.birch"
    return birch::sum(_u0961.get(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, x - 1))), handler_);
  } else {
    #line 102 "src/math/cdf.birch"
    libbirch_line_(102);
    #line 102 "src/math/cdf.birch"
    return -birch::inf();
  }
}

#line 115 "src/math/cdf.birch"
birch::type::Real birch::cdf_uniform(const birch::type::Real& x, const birch::type::Real& l, const birch::type::Real& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 115 "src/math/cdf.birch"
  libbirch_function_("cdf_uniform", "src/math/cdf.birch", 115);
  #line 116 "src/math/cdf.birch"
  libbirch_line_(116);
  #line 116 "src/math/cdf.birch"
  libbirch_assert_(l <= u);
  #line 118 "src/math/cdf.birch"
  libbirch_line_(118);
  #line 118 "src/math/cdf.birch"
  if (x <= l) {
    #line 119 "src/math/cdf.birch"
    libbirch_line_(119);
    #line 119 "src/math/cdf.birch"
    return 0.0;
  } else {
    #line 120 "src/math/cdf.birch"
    libbirch_line_(120);
    #line 120 "src/math/cdf.birch"
    if (x > u) {
      #line 121 "src/math/cdf.birch"
      libbirch_line_(121);
      #line 121 "src/math/cdf.birch"
      return 1.0;
    } else {
      #line 123 "src/math/cdf.birch"
      libbirch_line_(123);
      #line 123 "src/math/cdf.birch"
      return (x - l) / (u - l);
    }
  }
}

#line 137 "src/math/cdf.birch"
birch::type::Real birch::cdf_inverse_gamma_gamma(const birch::type::Real& x, const birch::type::Real& k, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 137 "src/math/cdf.birch"
  libbirch_function_("cdf_inverse_gamma_gamma", "src/math/cdf.birch", 137);
  #line 138 "src/math/cdf.birch"
  libbirch_line_(138);
  #line 138 "src/math/cdf.birch"
  if (x <= 0.0) {
    #line 139 "src/math/cdf.birch"
    libbirch_line_(139);
    #line 139 "src/math/cdf.birch"
    return 0.0;
  } else {
    #line 141 "src/math/cdf.birch"
    libbirch_line_(141);
    #line 141 "src/math/cdf.birch"
    return birch::ibeta(k, _u0945, x / (_u0946 + x), handler_);
  }
}

#line 153 "src/math/cdf.birch"
birch::type::Real birch::cdf_exponential(const birch::type::Real& x, const birch::type::Real& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 153 "src/math/cdf.birch"
  libbirch_function_("cdf_exponential", "src/math/cdf.birch", 153);
  #line 154 "src/math/cdf.birch"
  libbirch_line_(154);
  #line 154 "src/math/cdf.birch"
  libbirch_assert_(0.0 < _u0955);
  #line 156 "src/math/cdf.birch"
  libbirch_line_(156);
  #line 156 "src/math/cdf.birch"
  if (x <= 0.0) {
    #line 157 "src/math/cdf.birch"
    libbirch_line_(157);
    #line 157 "src/math/cdf.birch"
    return 0.0;
  } else {
    #line 159 "src/math/cdf.birch"
return boost::math::cdf(boost::math::exponential_distribution<>(_u0955), x);
      }
}

#line 174 "src/math/cdf.birch"
birch::type::Real birch::cdf_weibull(const birch::type::Real& x, const birch::type::Real& k, const birch::type::Real& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 174 "src/math/cdf.birch"
  libbirch_function_("cdf_weibull", "src/math/cdf.birch", 174);
  #line 175 "src/math/cdf.birch"
  libbirch_line_(175);
  #line 175 "src/math/cdf.birch"
  libbirch_assert_(0.0 < k);
  #line 176 "src/math/cdf.birch"
  libbirch_line_(176);
  #line 176 "src/math/cdf.birch"
  libbirch_assert_(0.0 < _u0955);
  #line 177 "src/math/cdf.birch"
return boost::math::cdf(boost::math::weibull_distribution<>(k, _u0955), x);
  }

#line 191 "src/math/cdf.birch"
birch::type::Real birch::cdf_gaussian(const birch::type::Real& x, const birch::type::Real& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 191 "src/math/cdf.birch"
  libbirch_function_("cdf_gaussian", "src/math/cdf.birch", 191);
  #line 192 "src/math/cdf.birch"
  libbirch_line_(192);
  #line 192 "src/math/cdf.birch"
  libbirch_assert_(0.0 < _u09632);
  #line 193 "src/math/cdf.birch"
return boost::math::cdf(boost::math::normal_distribution<>(_u0956, ::sqrt(_u09632)), x);
  }

#line 206 "src/math/cdf.birch"
birch::type::Real birch::cdf_student_t(const birch::type::Real& x, const birch::type::Real& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 206 "src/math/cdf.birch"
  libbirch_function_("cdf_student_t", "src/math/cdf.birch", 206);
  #line 207 "src/math/cdf.birch"
  libbirch_line_(207);
  #line 207 "src/math/cdf.birch"
  libbirch_assert_(0.0 < _u0957);
  #line 208 "src/math/cdf.birch"
return boost::math::cdf(boost::math::students_t_distribution<>(_u0957), x);
  }

#line 223 "src/math/cdf.birch"
birch::type::Real birch::cdf_student_t(const birch::type::Real& x, const birch::type::Real& _u0957, const birch::type::Real& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 223 "src/math/cdf.birch"
  libbirch_function_("cdf_student_t", "src/math/cdf.birch", 223);
  #line 224 "src/math/cdf.birch"
  libbirch_line_(224);
  #line 224 "src/math/cdf.birch"
  libbirch_assert_(0.0 < _u09632);
  #line 225 "src/math/cdf.birch"
  libbirch_line_(225);
  #line 225 "src/math/cdf.birch"
  return birch::cdf_student_t((x - _u0956) / birch::sqrt(_u09632, handler_), _u0957, handler_);
}

#line 237 "src/math/cdf.birch"
birch::type::Real birch::cdf_beta(const birch::type::Real& x, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 237 "src/math/cdf.birch"
  libbirch_function_("cdf_beta", "src/math/cdf.birch", 237);
  #line 238 "src/math/cdf.birch"
  libbirch_line_(238);
  #line 238 "src/math/cdf.birch"
  libbirch_assert_(0.0 < _u0945);
  #line 239 "src/math/cdf.birch"
  libbirch_line_(239);
  #line 239 "src/math/cdf.birch"
  libbirch_assert_(0.0 < _u0946);
  #line 241 "src/math/cdf.birch"
  libbirch_line_(241);
  #line 241 "src/math/cdf.birch"
  if (x < 0.0) {
    #line 242 "src/math/cdf.birch"
    libbirch_line_(242);
    #line 242 "src/math/cdf.birch"
    return 0.0;
  } else {
    #line 243 "src/math/cdf.birch"
    libbirch_line_(243);
    #line 243 "src/math/cdf.birch"
    if (x > 1.0) {
      #line 244 "src/math/cdf.birch"
      libbirch_line_(244);
      #line 244 "src/math/cdf.birch"
      return 1.0;
    } else {
      #line 246 "src/math/cdf.birch"
return boost::math::cdf(boost::math::beta_distribution<>(_u0945, _u0946), x);
        }
  }
}

#line 260 "src/math/cdf.birch"
birch::type::Real birch::cdf_chi_squared(const birch::type::Real& x, const birch::type::Real& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 260 "src/math/cdf.birch"
  libbirch_function_("cdf_chi_squared", "src/math/cdf.birch", 260);
  #line 261 "src/math/cdf.birch"
  libbirch_line_(261);
  #line 261 "src/math/cdf.birch"
  libbirch_assert_(0.0 < _u0957);
  #line 262 "src/math/cdf.birch"
return boost::math::cdf(boost::math::chi_squared_distribution<>(_u0957), x);
  }

#line 276 "src/math/cdf.birch"
birch::type::Real birch::cdf_gamma(const birch::type::Real& x, const birch::type::Real& k, const birch::type::Real& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 276 "src/math/cdf.birch"
  libbirch_function_("cdf_gamma", "src/math/cdf.birch", 276);
  #line 277 "src/math/cdf.birch"
  libbirch_line_(277);
  #line 277 "src/math/cdf.birch"
  libbirch_assert_(0.0 < k);
  #line 278 "src/math/cdf.birch"
  libbirch_line_(278);
  #line 278 "src/math/cdf.birch"
  libbirch_assert_(0.0 < _u0952);
  #line 280 "src/math/cdf.birch"
  libbirch_line_(280);
  #line 280 "src/math/cdf.birch"
  if (x <= 0.0) {
    #line 281 "src/math/cdf.birch"
    libbirch_line_(281);
    #line 281 "src/math/cdf.birch"
    return 0.0;
  } else {
    #line 283 "src/math/cdf.birch"
return boost::math::cdf(boost::math::gamma_distribution<>(k, _u0952), x);
      }
}

#line 298 "src/math/cdf.birch"
birch::type::Real birch::cdf_inverse_gamma(const birch::type::Real& x, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 298 "src/math/cdf.birch"
  libbirch_function_("cdf_inverse_gamma", "src/math/cdf.birch", 298);
  #line 299 "src/math/cdf.birch"
  libbirch_line_(299);
  #line 299 "src/math/cdf.birch"
  libbirch_assert_(0.0 < _u0945);
  #line 300 "src/math/cdf.birch"
  libbirch_line_(300);
  #line 300 "src/math/cdf.birch"
  libbirch_assert_(0.0 < _u0946);
  #line 302 "src/math/cdf.birch"
  libbirch_line_(302);
  #line 302 "src/math/cdf.birch"
  if (x <= 0.0) {
    #line 303 "src/math/cdf.birch"
    libbirch_line_(303);
    #line 303 "src/math/cdf.birch"
    return 0.0;
  } else {
    #line 305 "src/math/cdf.birch"
return boost::math::cdf(boost::math::inverse_gamma_distribution<>(_u0945, _u0946), x);
      }
}

#line 322 "src/math/cdf.birch"
birch::type::Real birch::cdf_normal_inverse_gamma(const birch::type::Real& x, const birch::type::Real& _u0956, const birch::type::Real& _u09632, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 322 "src/math/cdf.birch"
  libbirch_function_("cdf_normal_inverse_gamma", "src/math/cdf.birch", 322);
  #line 324 "src/math/cdf.birch"
  libbirch_line_(324);
  #line 324 "src/math/cdf.birch"
  return birch::cdf_student_t(x, 2.0 * _u0945, _u0956, _u09632 * _u0946 / _u0945, handler_);
}

#line 337 "src/math/cdf.birch"
birch::type::Real birch::cdf_beta_binomial(const birch::type::Integer& x, const birch::type::Integer& n, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 337 "src/math/cdf.birch"
  libbirch_function_("cdf_beta_binomial", "src/math/cdf.birch", 337);
  #line 338 "src/math/cdf.birch"
  libbirch_line_(338);
  #line 338 "src/math/cdf.birch"
  birch::type::Real P = 0.0;
  #line 339 "src/math/cdf.birch"
  libbirch_line_(339);
  #line 339 "src/math/cdf.birch"
  for (auto i = birch::type::Integer(0); i <= birch::min(n, x, handler_); ++i) {
    #line 340 "src/math/cdf.birch"
    libbirch_line_(340);
    #line 340 "src/math/cdf.birch"
    P = P + birch::exp(birch::logpdf_beta_binomial(i, n, _u0945, _u0946, handler_), handler_);
  }
  #line 342 "src/math/cdf.birch"
  libbirch_line_(342);
  #line 342 "src/math/cdf.birch"
  return P;
}

#line 354 "src/math/cdf.birch"
birch::type::Real birch::cdf_gamma_poisson(const birch::type::Integer& x, const birch::type::Real& k, const birch::type::Real& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 354 "src/math/cdf.birch"
  libbirch_function_("cdf_gamma_poisson", "src/math/cdf.birch", 354);
  #line 355 "src/math/cdf.birch"
  libbirch_line_(355);
  #line 355 "src/math/cdf.birch"
  libbirch_assert_(0.0 < k);
  #line 356 "src/math/cdf.birch"
  libbirch_line_(356);
  #line 356 "src/math/cdf.birch"
  libbirch_assert_(0.0 < _u0952);
  #line 357 "src/math/cdf.birch"
  libbirch_line_(357);
  #line 357 "src/math/cdf.birch"
  libbirch_assert_(k == birch::floor(k, handler_));
  #line 359 "src/math/cdf.birch"
  libbirch_line_(359);
  #line 359 "src/math/cdf.birch"
  return birch::cdf_negative_binomial(x, birch::Integer(k, handler_), 1.0 / (_u0952 + 1.0), handler_);
}

#line 371 "src/math/cdf.birch"
birch::type::Real birch::cdf_lomax(const birch::type::Real& x, const birch::type::Real& _u0955, const birch::type::Real& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 371 "src/math/cdf.birch"
  libbirch_function_("cdf_lomax", "src/math/cdf.birch", 371);
  #line 372 "src/math/cdf.birch"
  libbirch_line_(372);
  #line 372 "src/math/cdf.birch"
  libbirch_assert_(0.0 < _u0955);
  #line 373 "src/math/cdf.birch"
  libbirch_line_(373);
  #line 373 "src/math/cdf.birch"
  libbirch_assert_(0.0 < _u0945);
  #line 375 "src/math/cdf.birch"
  libbirch_line_(375);
  #line 375 "src/math/cdf.birch"
  if (x <= 0.0) {
    #line 376 "src/math/cdf.birch"
    libbirch_line_(376);
    #line 376 "src/math/cdf.birch"
    return 0.0;
  } else {
    #line 378 "src/math/cdf.birch"
return boost::math::cdf(boost::math::pareto_distribution<>(_u0955, _u0945), x + _u0955);
      }
}

#line 395 "src/math/cdf.birch"
birch::type::Real birch::cdf_normal_inverse_gamma_gaussian(const birch::type::Real& x, const birch::type::Real& _u0956, const birch::type::Real& a2, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 395 "src/math/cdf.birch"
  libbirch_function_("cdf_normal_inverse_gamma_gaussian", "src/math/cdf.birch", 395);
  #line 397 "src/math/cdf.birch"
  libbirch_line_(397);
  #line 397 "src/math/cdf.birch"
  return birch::cdf_student_t(x, 2.0 * _u0945, _u0956, (_u0946 / _u0945) * (1.0 + a2), handler_);
}

#line 414 "src/math/cdf.birch"
birch::type::Real birch::cdf_linear_normal_inverse_gamma_gaussian(const birch::type::Real& x, const birch::type::Real& a, const birch::type::Real& _u0956, const birch::type::Real& a2, const birch::type::Real& c, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 414 "src/math/cdf.birch"
  libbirch_function_("cdf_linear_normal_inverse_gamma_gaussian", "src/math/cdf.birch", 414);
  #line 416 "src/math/cdf.birch"
  libbirch_line_(416);
  #line 416 "src/math/cdf.birch"
  return birch::cdf_student_t(x, 2.0 * _u0945, a * _u0956 + c, (_u0946 / _u0945) * (1.0 + a * a * a2), handler_);
}

#line 433 "src/math/cdf.birch"
birch::type::Real birch::cdf_linear_multivariate_normal_inverse_gamma_gaussian(const birch::type::Real& x, const libbirch::DefaultArray<birch::type::Real,1>& a, const libbirch::DefaultArray<birch::type::Real,1>& _u0957, const birch::type::LLT& _u0923, const birch::type::Real& c, const birch::type::Real& _u0945, const birch::type::Real& _u0947, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 433 "src/math/cdf.birch"
  libbirch_function_("cdf_linear_multivariate_normal_inverse_gamma_gaussian", "src/math/cdf.birch", 433);
  #line 435 "src/math/cdf.birch"
  libbirch_line_(435);
  #line 435 "src/math/cdf.birch"
  auto _u0956 = birch::solve(_u0923, _u0957, handler_);
  #line 436 "src/math/cdf.birch"
  libbirch_line_(436);
  #line 436 "src/math/cdf.birch"
  auto _u0946 = _u0947 - 0.5 * birch::dot(_u0956, _u0957, handler_);
  #line 437 "src/math/cdf.birch"
  libbirch_line_(437);
  #line 437 "src/math/cdf.birch"
  return birch::cdf_student_t(x, 2.0 * _u0945, birch::dot(a, _u0956, handler_) + c, (_u0946 / _u0945) * (1.0 + birch::dot(a, birch::solve(_u0923, a, handler_), handler_)), handler_);
}

#line 10 "src/math/distance.birch"
birch::type::Real birch::wasserstein(const libbirch::DefaultArray<birch::type::Real,1>& x1, const libbirch::DefaultArray<birch::type::Real,1>& x2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/math/distance.birch"
  libbirch_function_("wasserstein", "src/math/distance.birch", 10);
  #line 11 "src/math/distance.birch"
  libbirch_line_(11);
  #line 11 "src/math/distance.birch"
  libbirch_assert_(birch::length(x1, handler_) == birch::length(x2, handler_));
  #line 12 "src/math/distance.birch"
  libbirch_line_(12);
  #line 12 "src/math/distance.birch"
  auto N = birch::length(x1, handler_);
  #line 13 "src/math/distance.birch"
  libbirch_line_(13);
  #line 13 "src/math/distance.birch"
  auto y1 = birch::sort<birch::type::Real>(x1, handler_);
  #line 14 "src/math/distance.birch"
  libbirch_line_(14);
  #line 14 "src/math/distance.birch"
  auto y2 = birch::sort<birch::type::Real>(x2, handler_);
  #line 15 "src/math/distance.birch"
  libbirch_line_(15);
  #line 15 "src/math/distance.birch"
  return birch::reduce<birch::type::Real>(y1 - y2, 0.0, std::function<birch::type::Real(birch::type::Real,birch::type::Real,const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_
)>([=](const birch::type::Real& a, const birch::type::Real& b, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr) {
    #line 16 "src/math/distance.birch"
    libbirch_line_(16);
    #line 16 "src/math/distance.birch"
    return birch::abs(a, handler_) + birch::abs(b, handler_);
  }), handler_) / N;
}

#line 10 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::operator*(const birch::type::Real& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 10 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 10);
  #line 11 "src/math/eigen.birch"
return x*y.toEigen();
  }

#line 16 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::operator*(const libbirch::DefaultArray<birch::type::Real,1>& x, const birch::type::Real& y) {
  #line 16 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 16);
  #line 17 "src/math/eigen.birch"
return x.toEigen()*y;
  }

#line 22 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator*(const birch::type::Real& x, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 22 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 22);
  #line 23 "src/math/eigen.birch"
return x*Y.toEigen();
  }

#line 28 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator*(const libbirch::DefaultArray<birch::type::Real,2>& X, const birch::type::Real& y) {
  #line 28 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 28);
  #line 29 "src/math/eigen.birch"
return X.toEigen()*y;
  }

#line 34 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::operator/(const libbirch::DefaultArray<birch::type::Real,1>& x, const birch::type::Real& y) {
  #line 34 "src/math/eigen.birch"
  libbirch_function_("/", "src/math/eigen.birch", 34);
  #line 35 "src/math/eigen.birch"
return x.toEigen()/y;
  }

#line 40 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator/(const libbirch::DefaultArray<birch::type::Real,2>& X, const birch::type::Real& y) {
  #line 40 "src/math/eigen.birch"
  libbirch_function_("/", "src/math/eigen.birch", 40);
  #line 41 "src/math/eigen.birch"
return X.toEigen()/y;
  }

#line 46 "src/math/eigen.birch"
birch::type::Boolean birch::operator==(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 46 "src/math/eigen.birch"
  libbirch_function_("==", "src/math/eigen.birch", 46);
  #line 47 "src/math/eigen.birch"
return x.toEigen() == y.toEigen();
  }

#line 52 "src/math/eigen.birch"
birch::type::Boolean birch::operator!=(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 52 "src/math/eigen.birch"
  libbirch_function_("!=", "src/math/eigen.birch", 52);
  #line 53 "src/math/eigen.birch"
return x.toEigen() != y.toEigen();
  }

#line 58 "src/math/eigen.birch"
birch::type::Boolean birch::operator==(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 58 "src/math/eigen.birch"
  libbirch_function_("==", "src/math/eigen.birch", 58);
  #line 59 "src/math/eigen.birch"
return X.toEigen() == Y.toEigen();
  }

#line 64 "src/math/eigen.birch"
birch::type::Boolean birch::operator!=(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 64 "src/math/eigen.birch"
  libbirch_function_("!=", "src/math/eigen.birch", 64);
  #line 65 "src/math/eigen.birch"
return X.toEigen() != Y.toEigen();
  }

#line 70 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::operator-(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 70 "src/math/eigen.birch"
  libbirch_function_("-", "src/math/eigen.birch", 70);
  #line 71 "src/math/eigen.birch"
return -x.toEigen();
  }

#line 76 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::operator+(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 76 "src/math/eigen.birch"
  libbirch_function_("+", "src/math/eigen.birch", 76);
  #line 77 "src/math/eigen.birch"
  libbirch_line_(77);
  #line 77 "src/math/eigen.birch"
  return x;
}

#line 80 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator-(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 80 "src/math/eigen.birch"
  libbirch_function_("-", "src/math/eigen.birch", 80);
  #line 81 "src/math/eigen.birch"
return -X.toEigen();
  }

#line 86 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator+(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 86 "src/math/eigen.birch"
  libbirch_function_("+", "src/math/eigen.birch", 86);
  #line 87 "src/math/eigen.birch"
  libbirch_line_(87);
  #line 87 "src/math/eigen.birch"
  return X;
}

#line 90 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::operator+(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 90 "src/math/eigen.birch"
  libbirch_function_("+", "src/math/eigen.birch", 90);
  #line 91 "src/math/eigen.birch"
return x.toEigen() + y.toEigen();
  }

#line 96 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::operator-(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 96 "src/math/eigen.birch"
  libbirch_function_("-", "src/math/eigen.birch", 96);
  #line 97 "src/math/eigen.birch"
return x.toEigen() - y.toEigen();
  }

#line 102 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator+(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 102 "src/math/eigen.birch"
  libbirch_function_("+", "src/math/eigen.birch", 102);
  #line 103 "src/math/eigen.birch"
return X.toEigen() + Y.toEigen();
  }

#line 108 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator-(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 108 "src/math/eigen.birch"
  libbirch_function_("-", "src/math/eigen.birch", 108);
  #line 109 "src/math/eigen.birch"
return X.toEigen() - Y.toEigen();
  }

#line 114 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::operator*(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 114 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 114);
  #line 115 "src/math/eigen.birch"
return X.toEigen()*y.toEigen();
  }

#line 120 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator*(const libbirch::DefaultArray<birch::type::Real,1>& X, const libbirch::DefaultArray<birch::type::Real,2>& y) {
  #line 120 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 120);
  #line 121 "src/math/eigen.birch"
return X.toEigen()*y.toEigen();
  }

#line 126 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::operator*(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& Y) {
  #line 126 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 126);
  #line 127 "src/math/eigen.birch"
return X.toEigen()*Y.toEigen();
  }

#line 132 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::operator*(const birch::type::Integer& x, const libbirch::DefaultArray<birch::type::Integer,1>& y) {
  #line 132 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 132);
  #line 133 "src/math/eigen.birch"
return x*y.toEigen();
  }

#line 138 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::operator*(const libbirch::DefaultArray<birch::type::Integer,1>& x, const birch::type::Integer& y) {
  #line 138 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 138);
  #line 139 "src/math/eigen.birch"
return x.toEigen()*y;
  }

#line 144 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator*(const birch::type::Integer& x, const libbirch::DefaultArray<birch::type::Integer,2>& Y) {
  #line 144 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 144);
  #line 145 "src/math/eigen.birch"
return x*Y.toEigen();
  }

#line 150 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator*(const libbirch::DefaultArray<birch::type::Integer,2>& X, const birch::type::Integer& y) {
  #line 150 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 150);
  #line 151 "src/math/eigen.birch"
return X.toEigen()*y;
  }

#line 156 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::operator/(const libbirch::DefaultArray<birch::type::Integer,1>& x, const birch::type::Integer& y) {
  #line 156 "src/math/eigen.birch"
  libbirch_function_("/", "src/math/eigen.birch", 156);
  #line 157 "src/math/eigen.birch"
return x.toEigen()/y;
  }

#line 162 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator/(const libbirch::DefaultArray<birch::type::Integer,2>& X, const birch::type::Integer& y) {
  #line 162 "src/math/eigen.birch"
  libbirch_function_("/", "src/math/eigen.birch", 162);
  #line 163 "src/math/eigen.birch"
return X.toEigen()/y;
  }

#line 168 "src/math/eigen.birch"
birch::type::Boolean birch::operator==(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::DefaultArray<birch::type::Integer,1>& y) {
  #line 168 "src/math/eigen.birch"
  libbirch_function_("==", "src/math/eigen.birch", 168);
  #line 169 "src/math/eigen.birch"
return x.toEigen() == y.toEigen();
  }

#line 174 "src/math/eigen.birch"
birch::type::Boolean birch::operator!=(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::DefaultArray<birch::type::Integer,1>& y) {
  #line 174 "src/math/eigen.birch"
  libbirch_function_("!=", "src/math/eigen.birch", 174);
  #line 175 "src/math/eigen.birch"
return x.toEigen() != y.toEigen();
  }

#line 180 "src/math/eigen.birch"
birch::type::Boolean birch::operator==(const libbirch::DefaultArray<birch::type::Integer,2>& X, const libbirch::DefaultArray<birch::type::Integer,2>& Y) {
  #line 180 "src/math/eigen.birch"
  libbirch_function_("==", "src/math/eigen.birch", 180);
  #line 181 "src/math/eigen.birch"
return X.toEigen() == Y.toEigen();
  }

#line 186 "src/math/eigen.birch"
birch::type::Boolean birch::operator!=(const libbirch::DefaultArray<birch::type::Integer,2>& X, const libbirch::DefaultArray<birch::type::Integer,2>& Y) {
  #line 186 "src/math/eigen.birch"
  libbirch_function_("!=", "src/math/eigen.birch", 186);
  #line 187 "src/math/eigen.birch"
return X.toEigen() != Y.toEigen();
  }

#line 192 "src/math/eigen.birch"
birch::type::Boolean birch::operator==(const birch::type::LLT& X, const birch::type::LLT& Y) {
  #line 192 "src/math/eigen.birch"
  libbirch_function_("==", "src/math/eigen.birch", 192);
  #line 193 "src/math/eigen.birch"
return X.reconstructedMatrix() == Y.reconstructedMatrix();
  }

#line 198 "src/math/eigen.birch"
birch::type::Boolean birch::operator!=(const birch::type::LLT& X, const birch::type::LLT& Y) {
  #line 198 "src/math/eigen.birch"
  libbirch_function_("!=", "src/math/eigen.birch", 198);
  #line 199 "src/math/eigen.birch"
return X.reconstructedMatrix() != Y.reconstructedMatrix();
  }

#line 204 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::operator-(const libbirch::DefaultArray<birch::type::Integer,1>& x) {
  #line 204 "src/math/eigen.birch"
  libbirch_function_("-", "src/math/eigen.birch", 204);
  #line 205 "src/math/eigen.birch"
return -x.toEigen();
  }

#line 210 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::operator+(const libbirch::DefaultArray<birch::type::Integer,1>& x) {
  #line 210 "src/math/eigen.birch"
  libbirch_function_("+", "src/math/eigen.birch", 210);
  #line 211 "src/math/eigen.birch"
  libbirch_line_(211);
  #line 211 "src/math/eigen.birch"
  return x;
}

#line 214 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator-(const libbirch::DefaultArray<birch::type::Integer,2>& X) {
  #line 214 "src/math/eigen.birch"
  libbirch_function_("-", "src/math/eigen.birch", 214);
  #line 215 "src/math/eigen.birch"
return -X.toEigen();
  }

#line 220 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator+(const libbirch::DefaultArray<birch::type::Integer,2>& X) {
  #line 220 "src/math/eigen.birch"
  libbirch_function_("+", "src/math/eigen.birch", 220);
  #line 221 "src/math/eigen.birch"
  libbirch_line_(221);
  #line 221 "src/math/eigen.birch"
  return X;
}

#line 224 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::operator+(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::DefaultArray<birch::type::Integer,1>& y) {
  #line 224 "src/math/eigen.birch"
  libbirch_function_("+", "src/math/eigen.birch", 224);
  #line 225 "src/math/eigen.birch"
return x.toEigen() + y.toEigen();
  }

#line 230 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::operator-(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::DefaultArray<birch::type::Integer,1>& y) {
  #line 230 "src/math/eigen.birch"
  libbirch_function_("-", "src/math/eigen.birch", 230);
  #line 231 "src/math/eigen.birch"
return x.toEigen() - y.toEigen();
  }

#line 236 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator+(const libbirch::DefaultArray<birch::type::Integer,2>& X, const libbirch::DefaultArray<birch::type::Integer,2>& Y) {
  #line 236 "src/math/eigen.birch"
  libbirch_function_("+", "src/math/eigen.birch", 236);
  #line 237 "src/math/eigen.birch"
return X.toEigen() + Y.toEigen();
  }

#line 242 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator-(const libbirch::DefaultArray<birch::type::Integer,2>& X, const libbirch::DefaultArray<birch::type::Integer,2>& Y) {
  #line 242 "src/math/eigen.birch"
  libbirch_function_("-", "src/math/eigen.birch", 242);
  #line 243 "src/math/eigen.birch"
return X.toEigen() - Y.toEigen();
  }

#line 248 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::operator*(const libbirch::DefaultArray<birch::type::Integer,2>& X, const libbirch::DefaultArray<birch::type::Integer,1>& y) {
  #line 248 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 248);
  #line 249 "src/math/eigen.birch"
return X.toEigen()*y.toEigen();
  }

#line 254 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator*(const libbirch::DefaultArray<birch::type::Integer,1>& X, const libbirch::DefaultArray<birch::type::Integer,2>& y) {
  #line 254 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 254);
  #line 255 "src/math/eigen.birch"
return X.toEigen()*y.toEigen();
  }

#line 260 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::operator*(const libbirch::DefaultArray<birch::type::Integer,2>& X, const libbirch::DefaultArray<birch::type::Integer,2>& Y) {
  #line 260 "src/math/eigen.birch"
  libbirch_function_("*", "src/math/eigen.birch", 260);
  #line 261 "src/math/eigen.birch"
return X.toEigen()*Y.toEigen();
  }

#line 269 "src/math/eigen.birch"
birch::type::Real birch::dot(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 269 "src/math/eigen.birch"
  libbirch_function_("dot", "src/math/eigen.birch", 269);
  #line 270 "src/math/eigen.birch"
return x.toEigen().squaredNorm();
  }

#line 278 "src/math/eigen.birch"
birch::type::Real birch::dot(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 278 "src/math/eigen.birch"
  libbirch_function_("dot", "src/math/eigen.birch", 278);
  #line 279 "src/math/eigen.birch"
return x.toEigen().dot(y.toEigen());
  }

#line 288 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::dot(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,2>& Y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 288 "src/math/eigen.birch"
  libbirch_function_("dot", "src/math/eigen.birch", 288);
  #line 289 "src/math/eigen.birch"
return Y.toEigen().transpose()*x.toEigen();
  }

#line 297 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::outer(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 297 "src/math/eigen.birch"
  libbirch_function_("outer", "src/math/eigen.birch", 297);
  #line 298 "src/math/eigen.birch"
auto y = x.toEigen();
  return y*y.transpose();
  }

#line 307 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::outer(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 307 "src/math/eigen.birch"
  libbirch_function_("outer", "src/math/eigen.birch", 307);
  #line 308 "src/math/eigen.birch"
return x.toEigen()*y.toEigen().transpose();
  }

#line 316 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::outer(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 316 "src/math/eigen.birch"
  libbirch_function_("outer", "src/math/eigen.birch", 316);
  #line 317 "src/math/eigen.birch"
auto Y = X.toEigen();
  return Y*Y.transpose();
  }

#line 326 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::outer(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& Y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 326 "src/math/eigen.birch"
  libbirch_function_("outer", "src/math/eigen.birch", 326);
  #line 327 "src/math/eigen.birch"
return X.toEigen()*Y.toEigen().transpose();
  }

#line 335 "src/math/eigen.birch"
birch::type::Real birch::norm(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 335 "src/math/eigen.birch"
  libbirch_function_("norm", "src/math/eigen.birch", 335);
  #line 336 "src/math/eigen.birch"
return x.toEigen().norm();
  }

#line 344 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::sqrt(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 344 "src/math/eigen.birch"
  libbirch_function_("sqrt", "src/math/eigen.birch", 344);
  #line 345 "src/math/eigen.birch"
return x.toEigen().array().sqrt().matrix();
  }

#line 353 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::transpose(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 353 "src/math/eigen.birch"
  libbirch_function_("transpose", "src/math/eigen.birch", 353);
  #line 354 "src/math/eigen.birch"
return X.toEigen().transpose();
  }

#line 362 "src/math/eigen.birch"
birch::type::LLT birch::transpose(const birch::type::LLT& S, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 362 "src/math/eigen.birch"
  libbirch_function_("transpose", "src/math/eigen.birch", 362);
  #line 363 "src/math/eigen.birch"
  libbirch_line_(363);
  #line 363 "src/math/eigen.birch"
  return S;
}

#line 369 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::transpose(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 369 "src/math/eigen.birch"
  libbirch_function_("transpose", "src/math/eigen.birch", 369);
  #line 370 "src/math/eigen.birch"
return x.toEigen().transpose();
  }

#line 378 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::diagonal(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 378 "src/math/eigen.birch"
  libbirch_function_("diagonal", "src/math/eigen.birch", 378);
  #line 379 "src/math/eigen.birch"
return x.toEigen().asDiagonal();
  }

#line 387 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::diagonal(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 387 "src/math/eigen.birch"
  libbirch_function_("diagonal", "src/math/eigen.birch", 387);
  #line 388 "src/math/eigen.birch"
return X.toEigen().diagonal();
  }

#line 396 "src/math/eigen.birch"
birch::type::Real birch::trace(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 396 "src/math/eigen.birch"
  libbirch_function_("trace", "src/math/eigen.birch", 396);
  #line 397 "src/math/eigen.birch"
return X.toEigen().trace();
  }

#line 405 "src/math/eigen.birch"
birch::type::Real birch::trace(const birch::type::LLT& S, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 405 "src/math/eigen.birch"
  libbirch_function_("trace", "src/math/eigen.birch", 405);
  #line 406 "src/math/eigen.birch"
return S.reconstructedMatrix().trace();
  }

#line 414 "src/math/eigen.birch"
birch::type::Real birch::det(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 414 "src/math/eigen.birch"
  libbirch_function_("det", "src/math/eigen.birch", 414);
  #line 415 "src/math/eigen.birch"
return X.toEigen().determinant();
  }

#line 423 "src/math/eigen.birch"
birch::type::Real birch::ldet(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 423 "src/math/eigen.birch"
  libbirch_function_("ldet", "src/math/eigen.birch", 423);
  #line 424 "src/math/eigen.birch"
return X.toEigen().householderQr().logAbsDeterminant();
  }

#line 432 "src/math/eigen.birch"
birch::type::Real birch::det(const birch::type::LLT& S, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 432 "src/math/eigen.birch"
  libbirch_function_("det", "src/math/eigen.birch", 432);
  #line 433 "src/math/eigen.birch"
auto d = S.matrixL().determinant();
  return d*d;
  }

#line 442 "src/math/eigen.birch"
birch::type::Real birch::ldet(const birch::type::LLT& S, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 442 "src/math/eigen.birch"
  libbirch_function_("ldet", "src/math/eigen.birch", 442);
  #line 443 "src/math/eigen.birch"
return 2.0*S.matrixL().nestedExpression().diagonal().array().log().sum();
  }

#line 451 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::inv(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 451 "src/math/eigen.birch"
  libbirch_function_("inv", "src/math/eigen.birch", 451);
  #line 452 "src/math/eigen.birch"
return X.toEigen().inverse();
  }

#line 460 "src/math/eigen.birch"
birch::type::LLT birch::inv(const birch::type::LLT& S, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 460 "src/math/eigen.birch"
  libbirch_function_("inv", "src/math/eigen.birch", 460);
  #line 461 "src/math/eigen.birch"
return S.solve(libbirch::EigenMatrix<birch::type::Real>::Identity(
      S.rows(), S.cols())).llt();
  }

#line 470 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::solve(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 470 "src/math/eigen.birch"
  libbirch_function_("solve", "src/math/eigen.birch", 470);
  #line 471 "src/math/eigen.birch"
return X.toEigen().householderQr().solve(y.toEigen()).eval();
  }

#line 479 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::solve(const birch::type::LLT& S, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 479 "src/math/eigen.birch"
  libbirch_function_("solve", "src/math/eigen.birch", 479);
  #line 480 "src/math/eigen.birch"
return S.solve(y.toEigen()).eval();
  }

#line 488 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::solve(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& Y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 488 "src/math/eigen.birch"
  libbirch_function_("solve", "src/math/eigen.birch", 488);
  #line 489 "src/math/eigen.birch"
return X.toEigen().householderQr().solve(Y.toEigen()).eval();
  }

#line 497 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::solve(const birch::type::LLT& S, const libbirch::DefaultArray<birch::type::Real,2>& Y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 497 "src/math/eigen.birch"
  libbirch_function_("solve", "src/math/eigen.birch", 497);
  #line 498 "src/math/eigen.birch"
return S.solve(Y.toEigen()).eval();
  }

#line 508 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::cholesky(const birch::type::LLT& S, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 508 "src/math/eigen.birch"
  libbirch_function_("cholesky", "src/math/eigen.birch", 508);
  #line 509 "src/math/eigen.birch"
return S.matrixL();
  }

#line 517 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::hadamard(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 517 "src/math/eigen.birch"
  libbirch_function_("hadamard", "src/math/eigen.birch", 517);
  #line 518 "src/math/eigen.birch"
return x.toEigen().cwiseProduct(y.toEigen());
  }

#line 526 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::hadamard(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& Y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 526 "src/math/eigen.birch"
  libbirch_function_("hadamard", "src/math/eigen.birch", 526);
  #line 527 "src/math/eigen.birch"
return X.toEigen().cwiseProduct(Y.toEigen());
  }

#line 535 "src/math/eigen.birch"
birch::type::Real birch::canonical(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 535 "src/math/eigen.birch"
  libbirch_function_("canonical", "src/math/eigen.birch", 535);
  #line 536 "src/math/eigen.birch"
  libbirch_line_(536);
  #line 536 "src/math/eigen.birch"
  return x;
}

#line 542 "src/math/eigen.birch"
birch::type::Integer birch::canonical(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 542 "src/math/eigen.birch"
  libbirch_function_("canonical", "src/math/eigen.birch", 542);
  #line 543 "src/math/eigen.birch"
  libbirch_line_(543);
  #line 543 "src/math/eigen.birch"
  return x;
}

#line 549 "src/math/eigen.birch"
birch::type::Boolean birch::canonical(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 549 "src/math/eigen.birch"
  libbirch_function_("canonical", "src/math/eigen.birch", 549);
  #line 550 "src/math/eigen.birch"
  libbirch_line_(550);
  #line 550 "src/math/eigen.birch"
  return x;
}

#line 556 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::canonical(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 556 "src/math/eigen.birch"
  libbirch_function_("canonical", "src/math/eigen.birch", 556);
  #line 557 "src/math/eigen.birch"
  libbirch_line_(557);
  #line 557 "src/math/eigen.birch"
  return x;
}

#line 563 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::canonical(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 563 "src/math/eigen.birch"
  libbirch_function_("canonical", "src/math/eigen.birch", 563);
  #line 564 "src/math/eigen.birch"
  libbirch_line_(564);
  #line 564 "src/math/eigen.birch"
  return x;
}

#line 569 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Boolean,1> birch::canonical(const libbirch::DefaultArray<birch::type::Boolean,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 569 "src/math/eigen.birch"
  libbirch_function_("canonical", "src/math/eigen.birch", 569);
  #line 570 "src/math/eigen.birch"
  libbirch_line_(570);
  #line 570 "src/math/eigen.birch"
  return x;
}

#line 576 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::canonical(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 576 "src/math/eigen.birch"
  libbirch_function_("canonical", "src/math/eigen.birch", 576);
  #line 577 "src/math/eigen.birch"
  libbirch_line_(577);
  #line 577 "src/math/eigen.birch"
  return X;
}

#line 583 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::canonical(const libbirch::DefaultArray<birch::type::Integer,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 583 "src/math/eigen.birch"
  libbirch_function_("canonical", "src/math/eigen.birch", 583);
  #line 584 "src/math/eigen.birch"
  libbirch_line_(584);
  #line 584 "src/math/eigen.birch"
  return X;
}

#line 590 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Boolean,2> birch::canonical(const libbirch::DefaultArray<birch::type::Boolean,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 590 "src/math/eigen.birch"
  libbirch_function_("canonical", "src/math/eigen.birch", 590);
  #line 591 "src/math/eigen.birch"
  libbirch_line_(591);
  #line 591 "src/math/eigen.birch"
  return X;
}

#line 597 "src/math/eigen.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::canonical(const birch::type::LLT& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 597 "src/math/eigen.birch"
  libbirch_function_("canonical", "src/math/eigen.birch", 597);
  #line 598 "src/math/eigen.birch"
return X.reconstructedMatrix();
  }

#line 9 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_bernoulli(const birch::type::Boolean& x, const birch::type::Real& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/math/logpdf.birch"
  libbirch_function_("logpdf_bernoulli", "src/math/logpdf.birch", 9);
  #line 10 "src/math/logpdf.birch"
  libbirch_line_(10);
  #line 10 "src/math/logpdf.birch"
  libbirch_assert_(0.0 <= _u0961 && _u0961 <= 1.0);
  #line 11 "src/math/logpdf.birch"
  libbirch_line_(11);
  #line 11 "src/math/logpdf.birch"
  if (x) {
    #line 12 "src/math/logpdf.birch"
    libbirch_line_(12);
    #line 12 "src/math/logpdf.birch"
    return birch::log(_u0961, handler_);
  } else {
    #line 14 "src/math/logpdf.birch"
    libbirch_line_(14);
    #line 14 "src/math/logpdf.birch"
    return birch::log1p(-_u0961, handler_);
  }
}

#line 26 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_delta(const birch::type::Integer& x, const birch::type::Integer& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/math/logpdf.birch"
  libbirch_function_("logpdf_delta", "src/math/logpdf.birch", 26);
  #line 27 "src/math/logpdf.birch"
  libbirch_line_(27);
  #line 27 "src/math/logpdf.birch"
  if (x == _u0956) {
    #line 28 "src/math/logpdf.birch"
    libbirch_line_(28);
    #line 28 "src/math/logpdf.birch"
    return 0.0;
  } else {
    #line 30 "src/math/logpdf.birch"
    libbirch_line_(30);
    #line 30 "src/math/logpdf.birch"
    return -birch::inf();
  }
}

#line 43 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_binomial(const birch::type::Integer& x, const birch::type::Integer& n, const birch::type::Real& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "src/math/logpdf.birch"
  libbirch_function_("logpdf_binomial", "src/math/logpdf.birch", 43);
  #line 44 "src/math/logpdf.birch"
  libbirch_line_(44);
  #line 44 "src/math/logpdf.birch"
  libbirch_assert_(birch::type::Integer(0) <= n);
  #line 45 "src/math/logpdf.birch"
  libbirch_line_(45);
  #line 45 "src/math/logpdf.birch"
  libbirch_assert_(0.0 <= _u0961 && _u0961 <= 1.0);
  #line 47 "src/math/logpdf.birch"
  libbirch_line_(47);
  #line 47 "src/math/logpdf.birch"
  if (_u0961 == 0.0 || _u0961 == 1.0) {
    #line 48 "src/math/logpdf.birch"
    libbirch_line_(48);
    #line 48 "src/math/logpdf.birch"
    if (x == n * _u0961) {
      #line 49 "src/math/logpdf.birch"
      libbirch_line_(49);
      #line 49 "src/math/logpdf.birch"
      return 0.0;
    } else {
      #line 51 "src/math/logpdf.birch"
      libbirch_line_(51);
      #line 51 "src/math/logpdf.birch"
      return -birch::inf();
    }
  } else {
    #line 53 "src/math/logpdf.birch"
    libbirch_line_(53);
    #line 53 "src/math/logpdf.birch"
    if (birch::type::Integer(0) <= x && x <= n) {
      #line 54 "src/math/logpdf.birch"
      libbirch_line_(54);
      #line 54 "src/math/logpdf.birch"
      return x * birch::log(_u0961, handler_) + (n - x) * birch::log1p(-_u0961, handler_) + birch::lchoose(n, x, handler_);
    } else {
      #line 56 "src/math/logpdf.birch"
      libbirch_line_(56);
      #line 56 "src/math/logpdf.birch"
      return -birch::inf();
    }
  }
}

#line 69 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_negative_binomial(const birch::type::Integer& x, const birch::type::Integer& k, const birch::type::Real& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "src/math/logpdf.birch"
  libbirch_function_("logpdf_negative_binomial", "src/math/logpdf.birch", 69);
  #line 70 "src/math/logpdf.birch"
  libbirch_line_(70);
  #line 70 "src/math/logpdf.birch"
  libbirch_assert_(birch::type::Integer(0) < k);
  #line 71 "src/math/logpdf.birch"
  libbirch_line_(71);
  #line 71 "src/math/logpdf.birch"
  libbirch_assert_(0.0 <= _u0961 && _u0961 <= 1.0);
  #line 73 "src/math/logpdf.birch"
  libbirch_line_(73);
  #line 73 "src/math/logpdf.birch"
  if (x >= birch::type::Integer(0)) {
    #line 74 "src/math/logpdf.birch"
    libbirch_line_(74);
    #line 74 "src/math/logpdf.birch"
    return k * birch::log(_u0961, handler_) + x * birch::log1p(-_u0961, handler_) + birch::lchoose(x + k - birch::type::Integer(1), x, handler_);
  } else {
    #line 76 "src/math/logpdf.birch"
    libbirch_line_(76);
    #line 76 "src/math/logpdf.birch"
    return -birch::inf();
  }
}

#line 88 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_poisson(const birch::type::Integer& x, const birch::type::Real& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 88 "src/math/logpdf.birch"
  libbirch_function_("logpdf_poisson", "src/math/logpdf.birch", 88);
  #line 89 "src/math/logpdf.birch"
  libbirch_line_(89);
  #line 89 "src/math/logpdf.birch"
  libbirch_assert_(0.0 <= _u0955);
  #line 91 "src/math/logpdf.birch"
  libbirch_line_(91);
  #line 91 "src/math/logpdf.birch"
  if (_u0955 > 0.0) {
    #line 92 "src/math/logpdf.birch"
    libbirch_line_(92);
    #line 92 "src/math/logpdf.birch"
    if (x >= birch::type::Integer(0)) {
      #line 93 "src/math/logpdf.birch"
      libbirch_line_(93);
      #line 93 "src/math/logpdf.birch"
      return x * birch::log(_u0955, handler_) - _u0955 - birch::lgamma(x + 1.0, handler_);
    } else {
      #line 95 "src/math/logpdf.birch"
      libbirch_line_(95);
      #line 95 "src/math/logpdf.birch"
      return -birch::inf();
    }
  } else {
    #line 98 "src/math/logpdf.birch"
    libbirch_line_(98);
    #line 98 "src/math/logpdf.birch"
    if (x == birch::type::Integer(0)) {
      #line 99 "src/math/logpdf.birch"
      libbirch_line_(99);
      #line 99 "src/math/logpdf.birch"
      return birch::inf();
    } else {
      #line 101 "src/math/logpdf.birch"
      libbirch_line_(101);
      #line 101 "src/math/logpdf.birch"
      return -birch::inf();
    }
  }
}

#line 115 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_uniform_int(const birch::type::Integer& x, const birch::type::Integer& l, const birch::type::Integer& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 115 "src/math/logpdf.birch"
  libbirch_function_("logpdf_uniform_int", "src/math/logpdf.birch", 115);
  #line 116 "src/math/logpdf.birch"
  libbirch_line_(116);
  #line 116 "src/math/logpdf.birch"
  if (x >= l && x <= u) {
    #line 117 "src/math/logpdf.birch"
    libbirch_line_(117);
    #line 117 "src/math/logpdf.birch"
    return -birch::log1p(birch::Real(u - l, handler_), handler_);
  } else {
    #line 119 "src/math/logpdf.birch"
    libbirch_line_(119);
    #line 119 "src/math/logpdf.birch"
    return -birch::inf();
  }
}

#line 131 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_categorical(const birch::type::Integer& x, const libbirch::DefaultArray<birch::type::Real,1>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 131 "src/math/logpdf.birch"
  libbirch_function_("logpdf_categorical", "src/math/logpdf.birch", 131);
  #line 132 "src/math/logpdf.birch"
  libbirch_line_(132);
  #line 132 "src/math/logpdf.birch"
  if (birch::type::Integer(1) <= x && x <= birch::length(_u0961, handler_)) {
    #line 133 "src/math/logpdf.birch"
    libbirch_line_(133);
    #line 133 "src/math/logpdf.birch"
    libbirch_assert_(_u0961.get(libbirch::make_slice(x - 1)) >= 0.0);
    #line 134 "src/math/logpdf.birch"
    libbirch_line_(134);
    #line 134 "src/math/logpdf.birch"
    return birch::log(_u0961.get(libbirch::make_slice(x - 1)), handler_);
  } else {
    #line 136 "src/math/logpdf.birch"
    libbirch_line_(136);
    #line 136 "src/math/logpdf.birch"
    return -birch::inf();
  }
}

#line 149 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_multinomial(const libbirch::DefaultArray<birch::type::Integer,1>& x, const birch::type::Integer& n, const libbirch::DefaultArray<birch::type::Real,1>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 149 "src/math/logpdf.birch"
  libbirch_function_("logpdf_multinomial", "src/math/logpdf.birch", 149);
  #line 150 "src/math/logpdf.birch"
  libbirch_line_(150);
  #line 150 "src/math/logpdf.birch"
  libbirch_assert_(birch::length(x, handler_) == birch::length(_u0961, handler_));
  #line 152 "src/math/logpdf.birch"
  libbirch_line_(152);
  #line 152 "src/math/logpdf.birch"
  birch::type::Integer m = birch::type::Integer(0);
  #line 153 "src/math/logpdf.birch"
  libbirch_line_(153);
  #line 153 "src/math/logpdf.birch"
  birch::type::Real w = birch::lgamma(n + 1.0, handler_);
  #line 154 "src/math/logpdf.birch"
  libbirch_line_(154);
  #line 154 "src/math/logpdf.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(x, handler_); ++i) {
    #line 155 "src/math/logpdf.birch"
    libbirch_line_(155);
    #line 155 "src/math/logpdf.birch"
    libbirch_assert_(x.get(libbirch::make_slice(i - 1)) >= birch::type::Integer(0));
    #line 156 "src/math/logpdf.birch"
    libbirch_line_(156);
    #line 156 "src/math/logpdf.birch"
    libbirch_assert_(_u0961.get(libbirch::make_slice(i - 1)) >= 0.0);
    #line 157 "src/math/logpdf.birch"
    libbirch_line_(157);
    #line 157 "src/math/logpdf.birch"
    m = m + x.get(libbirch::make_slice(i - 1));
    #line 158 "src/math/logpdf.birch"
    libbirch_line_(158);
    #line 158 "src/math/logpdf.birch"
    w = w + x.get(libbirch::make_slice(i - 1)) * birch::log(_u0961.get(libbirch::make_slice(i - 1)), handler_) - birch::lgamma(x.get(libbirch::make_slice(i - 1)) + 1.0, handler_);
  }
  #line 160 "src/math/logpdf.birch"
  libbirch_line_(160);
  #line 160 "src/math/logpdf.birch"
  if (m == n) {
    #line 161 "src/math/logpdf.birch"
    libbirch_line_(161);
    #line 161 "src/math/logpdf.birch"
    return w;
  } else {
    #line 163 "src/math/logpdf.birch"
    libbirch_line_(163);
    #line 163 "src/math/logpdf.birch"
    return -birch::inf();
  }
}

#line 175 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_dirichlet(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 175 "src/math/logpdf.birch"
  libbirch_function_("logpdf_dirichlet", "src/math/logpdf.birch", 175);
  #line 176 "src/math/logpdf.birch"
  libbirch_line_(176);
  #line 176 "src/math/logpdf.birch"
  libbirch_assert_(birch::length(x, handler_) == birch::length(_u0945, handler_));
  #line 178 "src/math/logpdf.birch"
  libbirch_line_(178);
  #line 178 "src/math/logpdf.birch"
  birch::type::Integer D = birch::length(x, handler_);
  #line 179 "src/math/logpdf.birch"
  libbirch_line_(179);
  #line 179 "src/math/logpdf.birch"
  birch::type::Real w = 0.0;
  #line 180 "src/math/logpdf.birch"
  libbirch_line_(180);
  #line 180 "src/math/logpdf.birch"
  for (auto i = birch::type::Integer(1); i <= D; ++i) {
    #line 181 "src/math/logpdf.birch"
    libbirch_line_(181);
    #line 181 "src/math/logpdf.birch"
    if (x.get(libbirch::make_slice(i - 1)) < 0.0) {
      #line 182 "src/math/logpdf.birch"
      libbirch_line_(182);
      #line 182 "src/math/logpdf.birch"
      return -birch::inf();
    }
    #line 184 "src/math/logpdf.birch"
    libbirch_line_(184);
    #line 184 "src/math/logpdf.birch"
    w = w + (_u0945.get(libbirch::make_slice(i - 1)) - 1.0) * birch::log(x.get(libbirch::make_slice(i - 1)), handler_) - birch::lgamma(_u0945.get(libbirch::make_slice(i - 1)), handler_);
  }
  #line 186 "src/math/logpdf.birch"
  libbirch_line_(186);
  #line 186 "src/math/logpdf.birch"
  w = w + birch::lgamma(birch::sum(_u0945, handler_), handler_);
  #line 187 "src/math/logpdf.birch"
  libbirch_line_(187);
  #line 187 "src/math/logpdf.birch"
  return w;
}

#line 199 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_uniform(const birch::type::Real& x, const birch::type::Real& l, const birch::type::Real& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 199 "src/math/logpdf.birch"
  libbirch_function_("logpdf_uniform", "src/math/logpdf.birch", 199);
  #line 200 "src/math/logpdf.birch"
  libbirch_line_(200);
  #line 200 "src/math/logpdf.birch"
  libbirch_assert_(l <= u);
  #line 202 "src/math/logpdf.birch"
  libbirch_line_(202);
  #line 202 "src/math/logpdf.birch"
  if (x >= l && x <= u) {
    #line 203 "src/math/logpdf.birch"
    libbirch_line_(203);
    #line 203 "src/math/logpdf.birch"
    return -birch::log(u - l, handler_);
  } else {
    #line 205 "src/math/logpdf.birch"
    libbirch_line_(205);
    #line 205 "src/math/logpdf.birch"
    return -birch::inf();
  }
}

#line 217 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_exponential(const birch::type::Real& x, const birch::type::Real& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 217 "src/math/logpdf.birch"
  libbirch_function_("logpdf_exponential", "src/math/logpdf.birch", 217);
  #line 218 "src/math/logpdf.birch"
  libbirch_line_(218);
  #line 218 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < _u0955);
  #line 219 "src/math/logpdf.birch"
  libbirch_line_(219);
  #line 219 "src/math/logpdf.birch"
  return birch::if_then_else(x < 0.0, -birch::inf(), birch::log(_u0955, handler_) - _u0955 * x, handler_);
}

#line 231 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_weibull(const birch::type::Real& x, const birch::type::Real& k, const birch::type::Real& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 231 "src/math/logpdf.birch"
  libbirch_function_("logpdf_weibull", "src/math/logpdf.birch", 231);
  #line 232 "src/math/logpdf.birch"
  libbirch_line_(232);
  #line 232 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < _u0955);
  #line 233 "src/math/logpdf.birch"
  libbirch_line_(233);
  #line 233 "src/math/logpdf.birch"
  return birch::if_then_else(x < 0.0, -birch::inf(), birch::log(k, handler_) + (k - 1.0) * birch::log(x, handler_) - k * birch::log(_u0955, handler_) - birch::pow(x / _u0955, k, handler_), handler_);
}

#line 246 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_gaussian(const birch::type::Real& x, const birch::type::Real& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 246 "src/math/logpdf.birch"
  libbirch_function_("logpdf_gaussian", "src/math/logpdf.birch", 246);
  #line 247 "src/math/logpdf.birch"
  libbirch_line_(247);
  #line 247 "src/math/logpdf.birch"
  libbirch_assert_(0.0 <= _u09632);
  #line 248 "src/math/logpdf.birch"
  libbirch_line_(248);
  #line 248 "src/math/logpdf.birch"
  return -0.5 * (birch::pow(x - _u0956, 2.0, handler_) / _u09632 + birch::log(2.0 * birch::_u0960() * _u09632, handler_));
}

#line 259 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_student_t(const birch::type::Real& x, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 259 "src/math/logpdf.birch"
  libbirch_function_("logpdf_student_t", "src/math/logpdf.birch", 259);
  #line 260 "src/math/logpdf.birch"
  libbirch_line_(260);
  #line 260 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < k);
  #line 261 "src/math/logpdf.birch"
  libbirch_line_(261);
  #line 261 "src/math/logpdf.birch"
  auto a = 0.5 * (k + 1.0);
  #line 262 "src/math/logpdf.birch"
  libbirch_line_(262);
  #line 262 "src/math/logpdf.birch"
  return birch::lgamma(a, handler_) - birch::lgamma(0.5 * k, handler_) - 0.5 * birch::log(birch::_u0960() * k, handler_) - a * birch::log1p(x * x / k, handler_);
}

#line 275 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_student_t(const birch::type::Real& x, const birch::type::Real& k, const birch::type::Real& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 275 "src/math/logpdf.birch"
  libbirch_function_("logpdf_student_t", "src/math/logpdf.birch", 275);
  #line 276 "src/math/logpdf.birch"
  libbirch_line_(276);
  #line 276 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < k);
  #line 277 "src/math/logpdf.birch"
  libbirch_line_(277);
  #line 277 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < _u09632);
  #line 278 "src/math/logpdf.birch"
  libbirch_line_(278);
  #line 278 "src/math/logpdf.birch"
  return birch::logpdf_student_t((x - _u0956) / birch::sqrt(_u09632, handler_), k, handler_) - 0.5 * birch::log(_u09632, handler_);
}

#line 290 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_beta(const birch::type::Real& x, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 290 "src/math/logpdf.birch"
  libbirch_function_("logpdf_beta", "src/math/logpdf.birch", 290);
  #line 291 "src/math/logpdf.birch"
  libbirch_line_(291);
  #line 291 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < _u0945);
  #line 292 "src/math/logpdf.birch"
  libbirch_line_(292);
  #line 292 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < _u0946);
  #line 294 "src/math/logpdf.birch"
  libbirch_line_(294);
  #line 294 "src/math/logpdf.birch"
  if (0.0 < x && x < 1.0) {
    #line 295 "src/math/logpdf.birch"
    libbirch_line_(295);
    #line 295 "src/math/logpdf.birch"
    return (_u0945 - 1.0) * birch::log(x, handler_) + (_u0946 - 1.0) * birch::log1p(-x, handler_) - birch::lbeta(_u0945, _u0946, handler_);
  } else {
    #line 297 "src/math/logpdf.birch"
    libbirch_line_(297);
    #line 297 "src/math/logpdf.birch"
    return -birch::inf();
  }
}

#line 309 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_chi_squared(const birch::type::Real& x, const birch::type::Real& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 309 "src/math/logpdf.birch"
  libbirch_function_("logpdf_chi_squared", "src/math/logpdf.birch", 309);
  #line 310 "src/math/logpdf.birch"
  libbirch_line_(310);
  #line 310 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < _u0957);
  #line 311 "src/math/logpdf.birch"
  libbirch_line_(311);
  #line 311 "src/math/logpdf.birch"
  if (x > 0.0 || (x >= 0.0 && _u0957 > 1.0)) {
    #line 312 "src/math/logpdf.birch"
    libbirch_line_(312);
    #line 312 "src/math/logpdf.birch"
    auto k = 0.5 * _u0957;
    #line 313 "src/math/logpdf.birch"
    libbirch_line_(313);
    #line 313 "src/math/logpdf.birch"
    return (k - 1.0) * birch::log(x, handler_) - 0.5 * x - birch::lgamma(k, handler_) - k * birch::log(2.0, handler_);
  } else {
    #line 315 "src/math/logpdf.birch"
    libbirch_line_(315);
    #line 315 "src/math/logpdf.birch"
    return -birch::inf();
  }
}

#line 328 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_gamma(const birch::type::Real& x, const birch::type::Real& k, const birch::type::Real& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 328 "src/math/logpdf.birch"
  libbirch_function_("logpdf_gamma", "src/math/logpdf.birch", 328);
  #line 329 "src/math/logpdf.birch"
  libbirch_line_(329);
  #line 329 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < k);
  #line 330 "src/math/logpdf.birch"
  libbirch_line_(330);
  #line 330 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < _u0952);
  #line 331 "src/math/logpdf.birch"
  libbirch_line_(331);
  #line 331 "src/math/logpdf.birch"
  return birch::if_then_else(x < 0.0, -birch::inf(), (k - 1.0) * birch::log(x, handler_) - x / _u0952 - birch::lgamma(k, handler_) - k * birch::log(_u0952, handler_), handler_);
}

#line 343 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_wishart(const birch::type::LLT& X, const birch::type::LLT& _u0936, const birch::type::Real& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 343 "src/math/logpdf.birch"
  libbirch_function_("logpdf_wishart", "src/math/logpdf.birch", 343);
  #line 344 "src/math/logpdf.birch"
  libbirch_line_(344);
  #line 344 "src/math/logpdf.birch"
  libbirch_assert_(_u0957 > birch::rows(_u0936, handler_) - birch::type::Integer(1));
  #line 345 "src/math/logpdf.birch"
  libbirch_line_(345);
  #line 345 "src/math/logpdf.birch"
  auto p = birch::rows(_u0936, handler_);
  #line 346 "src/math/logpdf.birch"
  libbirch_line_(346);
  #line 346 "src/math/logpdf.birch"
  return 0.5 * (_u0957 - p - 1.0) * birch::ldet(X, handler_) - 0.5 * birch::trace(birch::solve(_u0936, birch::canonical(X, handler_), handler_), handler_) - 0.5 * _u0957 * p * birch::log(2.0, handler_) - 0.5 * _u0957 * birch::ldet(_u0936, handler_) - birch::lgamma(0.5 * _u0957, p, handler_);
}

#line 359 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_inverse_gamma(const birch::type::Real& x, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 359 "src/math/logpdf.birch"
  libbirch_function_("logpdf_inverse_gamma", "src/math/logpdf.birch", 359);
  #line 360 "src/math/logpdf.birch"
  libbirch_line_(360);
  #line 360 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < _u0945);
  #line 361 "src/math/logpdf.birch"
  libbirch_line_(361);
  #line 361 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < _u0946);
  #line 362 "src/math/logpdf.birch"
  libbirch_line_(362);
  #line 362 "src/math/logpdf.birch"
  return birch::if_then_else(x < 0.0, -birch::inf(), _u0945 * birch::log(_u0946, handler_) - (_u0945 + 1.0) * birch::log(x, handler_) - _u0946 / x - birch::lgamma(_u0945, handler_), handler_);
}

#line 375 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_inverse_wishart(const birch::type::LLT& X, const birch::type::LLT& _u0936, const birch::type::Real& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 375 "src/math/logpdf.birch"
  libbirch_function_("logpdf_inverse_wishart", "src/math/logpdf.birch", 375);
  #line 376 "src/math/logpdf.birch"
  libbirch_line_(376);
  #line 376 "src/math/logpdf.birch"
  libbirch_assert_(_u0957 > birch::rows(_u0936, handler_) - birch::type::Integer(1));
  #line 377 "src/math/logpdf.birch"
  libbirch_line_(377);
  #line 377 "src/math/logpdf.birch"
  auto p = birch::rows(_u0936, handler_);
  #line 378 "src/math/logpdf.birch"
  libbirch_line_(378);
  #line 378 "src/math/logpdf.birch"
  return 0.5 * _u0957 * birch::ldet(_u0936, handler_) - 0.5 * (_u0957 + p - 1.0) * birch::ldet(X, handler_) - 0.5 * birch::trace(birch::solve(X, birch::canonical(birch::transpose(_u0936, handler_), handler_), handler_), handler_) - 0.5 * _u0957 * p * birch::log(2.0, handler_) - birch::lgamma(0.5 * _u0957, p, handler_);
}

#line 393 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_inverse_gamma_gamma(const birch::type::Real& x, const birch::type::Real& k, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 393 "src/math/logpdf.birch"
  libbirch_function_("logpdf_inverse_gamma_gamma", "src/math/logpdf.birch", 393);
  #line 394 "src/math/logpdf.birch"
  libbirch_line_(394);
  #line 394 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < k);
  #line 395 "src/math/logpdf.birch"
  libbirch_line_(395);
  #line 395 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < _u0945);
  #line 396 "src/math/logpdf.birch"
  libbirch_line_(396);
  #line 396 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < _u0946);
  #line 397 "src/math/logpdf.birch"
  libbirch_line_(397);
  #line 397 "src/math/logpdf.birch"
  return birch::if_then_else(x < 0.0, -birch::inf(), (k - birch::type::Integer(1)) * birch::log(x, handler_) + _u0945 * birch::log(_u0946, handler_) - (_u0945 + k) * birch::log(_u0946 + x, handler_) - birch::lbeta(_u0945, k, handler_), handler_);
}

#line 412 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_normal_inverse_gamma(const birch::type::Real& x, const birch::type::Real& _u0956, const birch::type::Real& a2, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 412 "src/math/logpdf.birch"
  libbirch_function_("logpdf_normal_inverse_gamma", "src/math/logpdf.birch", 412);
  #line 414 "src/math/logpdf.birch"
  libbirch_line_(414);
  #line 414 "src/math/logpdf.birch"
  return birch::logpdf_student_t(x, 2.0 * _u0945, _u0956, a2 * _u0946 / _u0945, handler_);
}

#line 426 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_beta_bernoulli(const birch::type::Boolean& x, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 426 "src/math/logpdf.birch"
  libbirch_function_("logpdf_beta_bernoulli", "src/math/logpdf.birch", 426);
  #line 427 "src/math/logpdf.birch"
  libbirch_line_(427);
  #line 427 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < _u0945);
  #line 428 "src/math/logpdf.birch"
  libbirch_line_(428);
  #line 428 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < _u0946);
  #line 430 "src/math/logpdf.birch"
  libbirch_line_(430);
  #line 430 "src/math/logpdf.birch"
  if (x) {
    #line 431 "src/math/logpdf.birch"
    libbirch_line_(431);
    #line 431 "src/math/logpdf.birch"
    return birch::log(_u0945, handler_) - birch::log(_u0945 + _u0946, handler_);
  } else {
    #line 433 "src/math/logpdf.birch"
    libbirch_line_(433);
    #line 433 "src/math/logpdf.birch"
    return birch::log(_u0946, handler_) - birch::log(_u0945 + _u0946, handler_);
  }
}

#line 447 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_beta_binomial(const birch::type::Integer& x, const birch::type::Integer& n, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 447 "src/math/logpdf.birch"
  libbirch_function_("logpdf_beta_binomial", "src/math/logpdf.birch", 447);
  #line 448 "src/math/logpdf.birch"
  libbirch_line_(448);
  #line 448 "src/math/logpdf.birch"
  libbirch_assert_(birch::type::Integer(0) <= n);
  #line 449 "src/math/logpdf.birch"
  libbirch_line_(449);
  #line 449 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < _u0945);
  #line 450 "src/math/logpdf.birch"
  libbirch_line_(450);
  #line 450 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < _u0946);
  #line 452 "src/math/logpdf.birch"
  libbirch_line_(452);
  #line 452 "src/math/logpdf.birch"
  if (birch::type::Integer(0) <= x && x <= n) {
    #line 453 "src/math/logpdf.birch"
    libbirch_line_(453);
    #line 453 "src/math/logpdf.birch"
    return birch::lbeta(x + _u0945, n - x + _u0946, handler_) - birch::lbeta(_u0945, _u0946, handler_) + birch::lchoose(n, x, handler_);
  } else {
    #line 455 "src/math/logpdf.birch"
    libbirch_line_(455);
    #line 455 "src/math/logpdf.birch"
    return -birch::inf();
  }
}

#line 469 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_beta_negative_binomial(const birch::type::Integer& x, const birch::type::Integer& k, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 469 "src/math/logpdf.birch"
  libbirch_function_("logpdf_beta_negative_binomial", "src/math/logpdf.birch", 469);
  #line 470 "src/math/logpdf.birch"
  libbirch_line_(470);
  #line 470 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < _u0945);
  #line 471 "src/math/logpdf.birch"
  libbirch_line_(471);
  #line 471 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < _u0946);
  #line 473 "src/math/logpdf.birch"
  libbirch_line_(473);
  #line 473 "src/math/logpdf.birch"
  if (x >= birch::type::Integer(0)) {
    #line 474 "src/math/logpdf.birch"
    libbirch_line_(474);
    #line 474 "src/math/logpdf.birch"
    return birch::lbeta(_u0945 + k, _u0946 + x, handler_) - birch::lbeta(_u0945, _u0946, handler_) + birch::lchoose(x + k - birch::type::Integer(1), x, handler_);
  } else {
    #line 476 "src/math/logpdf.birch"
    libbirch_line_(476);
    #line 476 "src/math/logpdf.birch"
    return -birch::inf();
  }
}

#line 489 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_gamma_poisson(const birch::type::Integer& x, const birch::type::Real& k, const birch::type::Real& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 489 "src/math/logpdf.birch"
  libbirch_function_("logpdf_gamma_poisson", "src/math/logpdf.birch", 489);
  #line 490 "src/math/logpdf.birch"
  libbirch_line_(490);
  #line 490 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < k);
  #line 491 "src/math/logpdf.birch"
  libbirch_line_(491);
  #line 491 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < _u0952);
  #line 492 "src/math/logpdf.birch"
  libbirch_line_(492);
  #line 492 "src/math/logpdf.birch"
  libbirch_assert_(k == birch::floor(k, handler_));
  #line 494 "src/math/logpdf.birch"
  libbirch_line_(494);
  #line 494 "src/math/logpdf.birch"
  return birch::logpdf_negative_binomial(x, birch::Integer(k, handler_), 1.0 / (_u0952 + 1.0), handler_);
}

#line 506 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_lomax(const birch::type::Real& x, const birch::type::Real& _u0955, const birch::type::Real& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 506 "src/math/logpdf.birch"
  libbirch_function_("logpdf_lomax", "src/math/logpdf.birch", 506);
  #line 507 "src/math/logpdf.birch"
  libbirch_line_(507);
  #line 507 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < _u0955);
  #line 508 "src/math/logpdf.birch"
  libbirch_line_(508);
  #line 508 "src/math/logpdf.birch"
  libbirch_assert_(0.0 < _u0945);
  #line 509 "src/math/logpdf.birch"
  libbirch_line_(509);
  #line 509 "src/math/logpdf.birch"
  return birch::if_then_else(x < 0.0, -birch::inf(), birch::log(_u0945, handler_) - birch::log(_u0955, handler_) - (_u0945 + 1.0) * birch::log1p(x / _u0955, handler_), handler_);
}

#line 521 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_dirichlet_categorical(const birch::type::Integer& x, const libbirch::DefaultArray<birch::type::Real,1>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 521 "src/math/logpdf.birch"
  libbirch_function_("logpdf_dirichlet_categorical", "src/math/logpdf.birch", 521);
  #line 522 "src/math/logpdf.birch"
  libbirch_line_(522);
  #line 522 "src/math/logpdf.birch"
  if (birch::type::Integer(1) <= x && x <= birch::length(_u0945, handler_)) {
    #line 523 "src/math/logpdf.birch"
    libbirch_line_(523);
    #line 523 "src/math/logpdf.birch"
    birch::type::Real A = birch::sum(_u0945, handler_);
    #line 524 "src/math/logpdf.birch"
    libbirch_line_(524);
    #line 524 "src/math/logpdf.birch"
    return birch::lgamma(1.0 + _u0945.get(libbirch::make_slice(x - 1)), handler_) - birch::lgamma(_u0945.get(libbirch::make_slice(x - 1)), handler_) + birch::lgamma(A, handler_) - birch::lgamma(1.0 + A, handler_);
  } else {
    #line 526 "src/math/logpdf.birch"
    libbirch_line_(526);
    #line 526 "src/math/logpdf.birch"
    return -birch::inf();
  }
}

#line 539 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_dirichlet_multinomial(const libbirch::DefaultArray<birch::type::Integer,1>& x, const birch::type::Integer& n, const libbirch::DefaultArray<birch::type::Real,1>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 539 "src/math/logpdf.birch"
  libbirch_function_("logpdf_dirichlet_multinomial", "src/math/logpdf.birch", 539);
  #line 540 "src/math/logpdf.birch"
  libbirch_line_(540);
  #line 540 "src/math/logpdf.birch"
  libbirch_assert_(birch::length(x, handler_) == birch::length(_u0945, handler_));
  #line 542 "src/math/logpdf.birch"
  libbirch_line_(542);
  #line 542 "src/math/logpdf.birch"
  birch::type::Real A = birch::sum(_u0945, handler_);
  #line 543 "src/math/logpdf.birch"
  libbirch_line_(543);
  #line 543 "src/math/logpdf.birch"
  birch::type::Integer m = birch::type::Integer(0);
  #line 544 "src/math/logpdf.birch"
  libbirch_line_(544);
  #line 544 "src/math/logpdf.birch"
  birch::type::Real w = birch::lgamma(n + 1.0, handler_) + birch::lgamma(A, handler_) - birch::lgamma(n + A, handler_);
  #line 545 "src/math/logpdf.birch"
  libbirch_line_(545);
  #line 545 "src/math/logpdf.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(_u0945, handler_); ++i) {
    #line 546 "src/math/logpdf.birch"
    libbirch_line_(546);
    #line 546 "src/math/logpdf.birch"
    libbirch_assert_(x.get(libbirch::make_slice(i - 1)) >= birch::type::Integer(0));
    #line 547 "src/math/logpdf.birch"
    libbirch_line_(547);
    #line 547 "src/math/logpdf.birch"
    m = m + x.get(libbirch::make_slice(i - 1));
    #line 548 "src/math/logpdf.birch"
    libbirch_line_(548);
    #line 548 "src/math/logpdf.birch"
    w = w + birch::lgamma(x.get(libbirch::make_slice(i - 1)) + _u0945.get(libbirch::make_slice(i - 1)), handler_) - birch::lgamma(x.get(libbirch::make_slice(i - 1)) + 1.0, handler_) - birch::lgamma(_u0945.get(libbirch::make_slice(i - 1)), handler_);
  }
  #line 550 "src/math/logpdf.birch"
  libbirch_line_(550);
  #line 550 "src/math/logpdf.birch"
  if (m == n) {
    #line 551 "src/math/logpdf.birch"
    libbirch_line_(551);
    #line 551 "src/math/logpdf.birch"
    return w;
  } else {
    #line 553 "src/math/logpdf.birch"
    libbirch_line_(553);
    #line 553 "src/math/logpdf.birch"
    return -birch::inf();
  }
}

#line 567 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_crp_categorical(const birch::type::Integer& k, const birch::type::Real& _u0945, const birch::type::Real& _u0952, const libbirch::DefaultArray<birch::type::Integer,1>& n, const birch::type::Integer& N, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 567 "src/math/logpdf.birch"
  libbirch_function_("logpdf_crp_categorical", "src/math/logpdf.birch", 567);
  #line 569 "src/math/logpdf.birch"
  libbirch_line_(569);
  #line 569 "src/math/logpdf.birch"
  birch::type::Integer K = birch::length(n, handler_);
  #line 570 "src/math/logpdf.birch"
  libbirch_line_(570);
  #line 570 "src/math/logpdf.birch"
  if (k > K + birch::type::Integer(1)) {
    #line 571 "src/math/logpdf.birch"
    libbirch_line_(571);
    #line 571 "src/math/logpdf.birch"
    return -birch::inf();
  } else {
    #line 572 "src/math/logpdf.birch"
    libbirch_line_(572);
    #line 572 "src/math/logpdf.birch"
    if (k == K + birch::type::Integer(1)) {
      #line 573 "src/math/logpdf.birch"
      libbirch_line_(573);
      #line 573 "src/math/logpdf.birch"
      return birch::log(K * _u0945 + _u0952, handler_) - birch::log(N + _u0952, handler_);
    } else {
      #line 575 "src/math/logpdf.birch"
      libbirch_line_(575);
      #line 575 "src/math/logpdf.birch"
      return birch::log(n.get(libbirch::make_slice(k - 1)) - _u0945, handler_) - birch::log(N + _u0952, handler_);
    }
  }
}

#line 590 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_normal_inverse_gamma_gaussian(const birch::type::Real& x, const birch::type::Real& _u0956, const birch::type::Real& a2, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 590 "src/math/logpdf.birch"
  libbirch_function_("logpdf_normal_inverse_gamma_gaussian", "src/math/logpdf.birch", 590);
  #line 592 "src/math/logpdf.birch"
  libbirch_line_(592);
  #line 592 "src/math/logpdf.birch"
  return birch::logpdf_student_t(x, 2.0 * _u0945, _u0956, (_u0946 / _u0945) * (1.0 + a2), handler_);
}

#line 609 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_linear_normal_inverse_gamma_gaussian(const birch::type::Real& x, const birch::type::Real& a, const birch::type::Real& _u0956, const birch::type::Real& a2, const birch::type::Real& c, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 609 "src/math/logpdf.birch"
  libbirch_function_("logpdf_linear_normal_inverse_gamma_gaussian", "src/math/logpdf.birch", 609);
  #line 611 "src/math/logpdf.birch"
  libbirch_line_(611);
  #line 611 "src/math/logpdf.birch"
  return birch::logpdf_student_t(x, 2.0 * _u0945, a * _u0956 + c, (_u0946 / _u0945) * (1.0 + a * a * a2), handler_);
}

#line 623 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const birch::type::LLT& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 623 "src/math/logpdf.birch"
  libbirch_function_("logpdf_multivariate_gaussian", "src/math/logpdf.birch", 623);
  #line 624 "src/math/logpdf.birch"
  libbirch_line_(624);
  #line 624 "src/math/logpdf.birch"
  auto n = birch::length(_u0956, handler_);
  #line 625 "src/math/logpdf.birch"
  libbirch_line_(625);
  #line 625 "src/math/logpdf.birch"
  return -0.5 * (birch::dot(x - _u0956, birch::solve(_u0931, x - _u0956, handler_), handler_) + n * birch::log(2.0 * birch::_u0960(), handler_) + birch::ldet(_u0931, handler_));
}

#line 637 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 637 "src/math/logpdf.birch"
  libbirch_function_("logpdf_multivariate_gaussian", "src/math/logpdf.birch", 637);
  #line 638 "src/math/logpdf.birch"
  libbirch_line_(638);
  #line 638 "src/math/logpdf.birch"
  auto n = birch::length(_u0956, handler_);
  #line 639 "src/math/logpdf.birch"
  libbirch_line_(639);
  #line 639 "src/math/logpdf.birch"
  auto w = 0.0;
  #line 640 "src/math/logpdf.birch"
  libbirch_line_(640);
  #line 640 "src/math/logpdf.birch"
  for (auto d = birch::type::Integer(1); d <= n; ++d) {
    #line 641 "src/math/logpdf.birch"
    libbirch_line_(641);
    #line 641 "src/math/logpdf.birch"
    w = w + birch::logpdf_gaussian(x.get(libbirch::make_slice(d - 1)), _u0956.get(libbirch::make_slice(d - 1)), _u09632.get(libbirch::make_slice(d - 1)), handler_);
  }
  #line 643 "src/math/logpdf.birch"
  libbirch_line_(643);
  #line 643 "src/math/logpdf.birch"
  return w;
}

#line 656 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 656 "src/math/logpdf.birch"
  libbirch_function_("logpdf_multivariate_gaussian", "src/math/logpdf.birch", 656);
  #line 657 "src/math/logpdf.birch"
  libbirch_line_(657);
  #line 657 "src/math/logpdf.birch"
  auto n = birch::length(_u0956, handler_);
  #line 658 "src/math/logpdf.birch"
  libbirch_line_(658);
  #line 658 "src/math/logpdf.birch"
  return -0.5 * (birch::dot(x - _u0956, handler_) / _u09632 + n * birch::log(2.0 * birch::_u0960() * _u09632, handler_));
}

#line 672 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_multivariate_normal_inverse_gamma(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& _u0957, const birch::type::LLT& _u0923, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 672 "src/math/logpdf.birch"
  libbirch_function_("logpdf_multivariate_normal_inverse_gamma", "src/math/logpdf.birch", 672);
  #line 674 "src/math/logpdf.birch"
  libbirch_line_(674);
  #line 674 "src/math/logpdf.birch"
  return birch::logpdf_multivariate_student_t(x, 2.0 * _u0945, birch::solve(_u0923, _u0957, handler_), birch::llt((_u0946 / _u0945) * birch::canonical(birch::inv(_u0923, handler_), handler_), handler_), handler_);
}

#line 690 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_multivariate_normal_inverse_gamma_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& _u0957, const birch::type::LLT& _u0923, const birch::type::Real& _u0945, const birch::type::Real& _u0947, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 690 "src/math/logpdf.birch"
  libbirch_function_("logpdf_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/math/logpdf.birch", 690);
  #line 692 "src/math/logpdf.birch"
  libbirch_line_(692);
  #line 692 "src/math/logpdf.birch"
  auto n = birch::length(_u0957, handler_);
  #line 693 "src/math/logpdf.birch"
  libbirch_line_(693);
  #line 693 "src/math/logpdf.birch"
  auto _u0956 = birch::solve(_u0923, _u0957, handler_);
  #line 694 "src/math/logpdf.birch"
  libbirch_line_(694);
  #line 694 "src/math/logpdf.birch"
  auto _u0946 = _u0947 - 0.5 * birch::dot(_u0956, _u0957, handler_);
  #line 695 "src/math/logpdf.birch"
  libbirch_line_(695);
  #line 695 "src/math/logpdf.birch"
  return birch::logpdf_multivariate_student_t(x, 2.0 * _u0945, _u0956, birch::llt((_u0946 / _u0945) * (birch::identity(n, handler_) + birch::canonical(birch::inv(_u0923, handler_), handler_)), handler_), handler_);
}

#line 713 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,2>& A, const libbirch::DefaultArray<birch::type::Real,1>& _u0957, const birch::type::LLT& _u0923, const libbirch::DefaultArray<birch::type::Real,1>& c, const birch::type::Real& _u0945, const birch::type::Real& _u0947, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 713 "src/math/logpdf.birch"
  libbirch_function_("logpdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/math/logpdf.birch", 713);
  #line 716 "src/math/logpdf.birch"
  libbirch_line_(716);
  #line 716 "src/math/logpdf.birch"
  auto n = birch::rows(A, handler_);
  #line 717 "src/math/logpdf.birch"
  libbirch_line_(717);
  #line 717 "src/math/logpdf.birch"
  auto _u0956 = birch::solve(_u0923, _u0957, handler_);
  #line 718 "src/math/logpdf.birch"
  libbirch_line_(718);
  #line 718 "src/math/logpdf.birch"
  auto _u0946 = _u0947 - 0.5 * birch::dot(_u0956, _u0957, handler_);
  #line 719 "src/math/logpdf.birch"
  libbirch_line_(719);
  #line 719 "src/math/logpdf.birch"
  return birch::logpdf_multivariate_student_t(x, 2.0 * _u0945, A * _u0956 + c, birch::llt((_u0946 / _u0945) * (birch::identity(n, handler_) + A * birch::solve(_u0923, birch::transpose(A, handler_), handler_)), handler_), handler_);
}

#line 737 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_linear_multivariate_normal_inverse_gamma_gaussian(const birch::type::Real& x, const libbirch::DefaultArray<birch::type::Real,1>& a, const libbirch::DefaultArray<birch::type::Real,1>& _u0957, const birch::type::LLT& _u0923, const birch::type::Real& c, const birch::type::Real& _u0945, const birch::type::Real& _u0947, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 737 "src/math/logpdf.birch"
  libbirch_function_("logpdf_linear_multivariate_normal_inverse_gamma_gaussian", "src/math/logpdf.birch", 737);
  #line 739 "src/math/logpdf.birch"
  libbirch_line_(739);
  #line 739 "src/math/logpdf.birch"
  auto _u0956 = birch::solve(_u0923, _u0957, handler_);
  #line 740 "src/math/logpdf.birch"
  libbirch_line_(740);
  #line 740 "src/math/logpdf.birch"
  auto _u0946 = _u0947 - 0.5 * birch::dot(_u0956, _u0957, handler_);
  #line 741 "src/math/logpdf.birch"
  libbirch_line_(741);
  #line 741 "src/math/logpdf.birch"
  return birch::logpdf_student_t(x, 2.0 * _u0945, birch::dot(a, _u0956, handler_) + c, (_u0946 / _u0945) * (1.0 + birch::dot(a, birch::solve(_u0923, a, handler_), handler_)), handler_);
}

#line 755 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const birch::type::LLT& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 755 "src/math/logpdf.birch"
  libbirch_function_("logpdf_matrix_gaussian", "src/math/logpdf.birch", 755);
  #line 757 "src/math/logpdf.birch"
  libbirch_line_(757);
  #line 757 "src/math/logpdf.birch"
  auto n = birch::rows(M, handler_);
  #line 758 "src/math/logpdf.birch"
  libbirch_line_(758);
  #line 758 "src/math/logpdf.birch"
  auto p = birch::columns(M, handler_);
  #line 759 "src/math/logpdf.birch"
  libbirch_line_(759);
  #line 759 "src/math/logpdf.birch"
  return -0.5 * (birch::trace(birch::solve(V, birch::transpose(X - M, handler_), handler_) * birch::solve(U, X - M, handler_), handler_) + n * p * birch::log(2.0 * birch::_u0960(), handler_) + n * birch::ldet(V, handler_) + p * birch::ldet(U, handler_));
}

#line 773 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 773 "src/math/logpdf.birch"
  libbirch_function_("logpdf_matrix_gaussian", "src/math/logpdf.birch", 773);
  #line 775 "src/math/logpdf.birch"
  libbirch_line_(775);
  #line 775 "src/math/logpdf.birch"
  auto n = birch::rows(M, handler_);
  #line 776 "src/math/logpdf.birch"
  libbirch_line_(776);
  #line 776 "src/math/logpdf.birch"
  auto p = birch::columns(M, handler_);
  #line 777 "src/math/logpdf.birch"
  libbirch_line_(777);
  #line 777 "src/math/logpdf.birch"
  return -0.5 * (birch::trace(birch::solve(birch::diagonal(_u09632, handler_), birch::transpose(X - M, handler_), handler_) * birch::solve(U, X - M, handler_), handler_) + n * p * birch::log(2.0 * birch::_u0960(), handler_) + n * birch::ldet(birch::diagonal(_u09632, handler_), handler_) + p * birch::ldet(U, handler_));
}

#line 790 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 790 "src/math/logpdf.birch"
  libbirch_function_("logpdf_matrix_gaussian", "src/math/logpdf.birch", 790);
  #line 791 "src/math/logpdf.birch"
  libbirch_line_(791);
  #line 791 "src/math/logpdf.birch"
  auto n = birch::rows(M, handler_);
  #line 792 "src/math/logpdf.birch"
  libbirch_line_(792);
  #line 792 "src/math/logpdf.birch"
  auto p = birch::columns(M, handler_);
  #line 793 "src/math/logpdf.birch"
  libbirch_line_(793);
  #line 793 "src/math/logpdf.birch"
  return -0.5 * (birch::trace(birch::solve(V, birch::transpose(X - M, handler_), handler_) * (X - M), handler_) + n * p * birch::log(2.0 * birch::_u0960(), handler_) + n * birch::ldet(V, handler_));
}

#line 806 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 806 "src/math/logpdf.birch"
  libbirch_function_("logpdf_matrix_gaussian", "src/math/logpdf.birch", 806);
  #line 808 "src/math/logpdf.birch"
  libbirch_line_(808);
  #line 808 "src/math/logpdf.birch"
  auto n = birch::rows(M, handler_);
  #line 809 "src/math/logpdf.birch"
  libbirch_line_(809);
  #line 809 "src/math/logpdf.birch"
  auto p = birch::columns(M, handler_);
  #line 810 "src/math/logpdf.birch"
  libbirch_line_(810);
  #line 810 "src/math/logpdf.birch"
  return -0.5 * (birch::trace(birch::solve(birch::diagonal(_u09632, handler_), birch::outer(birch::transpose(X - M, handler_), handler_), handler_), handler_) + n * p * birch::log(2.0 * birch::_u0960(), handler_) + n * birch::ldet(birch::diagonal(_u09632, handler_), handler_));
}

#line 824 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 824 "src/math/logpdf.birch"
  libbirch_function_("logpdf_matrix_gaussian", "src/math/logpdf.birch", 824);
  #line 826 "src/math/logpdf.birch"
  libbirch_line_(826);
  #line 826 "src/math/logpdf.birch"
  auto n = birch::rows(M, handler_);
  #line 827 "src/math/logpdf.birch"
  libbirch_line_(827);
  #line 827 "src/math/logpdf.birch"
  auto p = birch::columns(M, handler_);
  #line 828 "src/math/logpdf.birch"
  libbirch_line_(828);
  #line 828 "src/math/logpdf.birch"
  return -0.5 * (birch::trace(birch::outer(birch::transpose(X - M, handler_), handler_) / _u09632, handler_) + n * p * birch::log(2.0 * birch::_u0960() * _u09632, handler_));
}

#line 842 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_matrix_normal_inverse_wishart(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& _u0923, const birch::type::LLT& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 842 "src/math/logpdf.birch"
  libbirch_function_("logpdf_matrix_normal_inverse_wishart", "src/math/logpdf.birch", 842);
  #line 844 "src/math/logpdf.birch"
  libbirch_line_(844);
  #line 844 "src/math/logpdf.birch"
  auto p = birch::columns(N, handler_);
  #line 845 "src/math/logpdf.birch"
  libbirch_line_(845);
  #line 845 "src/math/logpdf.birch"
  auto M = birch::solve(_u0923, N, handler_);
  #line 846 "src/math/logpdf.birch"
  libbirch_line_(846);
  #line 846 "src/math/logpdf.birch"
  auto _u0931 = birch::llt(birch::canonical(birch::inv(_u0923, handler_), handler_) / (k - p + 1.0), handler_);
  #line 847 "src/math/logpdf.birch"
  libbirch_line_(847);
  #line 847 "src/math/logpdf.birch"
  return birch::logpdf_matrix_student_t(X, k - p + 1.0, M, _u0931, _u0936, handler_);
}

#line 861 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_matrix_normal_inverse_wishart_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& _u0923, const birch::type::LLT& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 861 "src/math/logpdf.birch"
  libbirch_function_("logpdf_matrix_normal_inverse_wishart_matrix_gaussian", "src/math/logpdf.birch", 861);
  #line 863 "src/math/logpdf.birch"
  libbirch_line_(863);
  #line 863 "src/math/logpdf.birch"
  auto n = birch::rows(N, handler_);
  #line 864 "src/math/logpdf.birch"
  libbirch_line_(864);
  #line 864 "src/math/logpdf.birch"
  auto p = birch::columns(N, handler_);
  #line 865 "src/math/logpdf.birch"
  libbirch_line_(865);
  #line 865 "src/math/logpdf.birch"
  auto M = birch::solve(_u0923, N, handler_);
  #line 866 "src/math/logpdf.birch"
  libbirch_line_(866);
  #line 866 "src/math/logpdf.birch"
  auto _u0931 = birch::llt((birch::identity(n, handler_) + birch::canonical(birch::inv(_u0923, handler_), handler_)) / (k - p + 1.0), handler_);
  #line 867 "src/math/logpdf.birch"
  libbirch_line_(867);
  #line 867 "src/math/logpdf.birch"
  return birch::logpdf_matrix_student_t(X, k - p + 1.0, M, _u0931, _u0936, handler_);
}

#line 884 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_linear_matrix_normal_inverse_wishart_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& A, const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& _u0923, const libbirch::DefaultArray<birch::type::Real,2>& C, const birch::type::LLT& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 884 "src/math/logpdf.birch"
  libbirch_function_("logpdf_linear_matrix_normal_inverse_wishart_matrix_gaussian", "src/math/logpdf.birch", 884);
  #line 887 "src/math/logpdf.birch"
  libbirch_line_(887);
  #line 887 "src/math/logpdf.birch"
  auto n = birch::rows(A, handler_);
  #line 888 "src/math/logpdf.birch"
  libbirch_line_(888);
  #line 888 "src/math/logpdf.birch"
  auto p = birch::columns(N, handler_);
  #line 889 "src/math/logpdf.birch"
  libbirch_line_(889);
  #line 889 "src/math/logpdf.birch"
  auto M = birch::solve(_u0923, N, handler_);
  #line 890 "src/math/logpdf.birch"
  libbirch_line_(890);
  #line 890 "src/math/logpdf.birch"
  auto _u0931 = birch::llt((birch::identity(n, handler_) + A * birch::solve(_u0923, birch::transpose(A, handler_), handler_)) / (k - p + 1.0), handler_);
  #line 891 "src/math/logpdf.birch"
  libbirch_line_(891);
  #line 891 "src/math/logpdf.birch"
  return birch::logpdf_matrix_student_t(X, k - p + 1.0, A * M + C, _u0931, _u0936, handler_);
}

#line 908 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& a, const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& _u0923, const libbirch::DefaultArray<birch::type::Real,1>& c, const birch::type::LLT& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 908 "src/math/logpdf.birch"
  libbirch_function_("logpdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian", "src/math/logpdf.birch", 908);
  #line 911 "src/math/logpdf.birch"
  libbirch_line_(911);
  #line 911 "src/math/logpdf.birch"
  auto p = birch::columns(N, handler_);
  #line 912 "src/math/logpdf.birch"
  libbirch_line_(912);
  #line 912 "src/math/logpdf.birch"
  auto M = birch::solve(_u0923, N, handler_);
  #line 913 "src/math/logpdf.birch"
  libbirch_line_(913);
  #line 913 "src/math/logpdf.birch"
  auto _u09632 = (1.0 + birch::dot(a, birch::solve(_u0923, a, handler_), handler_)) / (k - p + 1.0);
  #line 914 "src/math/logpdf.birch"
  libbirch_line_(914);
  #line 914 "src/math/logpdf.birch"
  return birch::logpdf_multivariate_student_t(x, k - p + 1.0, birch::dot(a, M, handler_) + c, birch::llt(_u09632 * birch::canonical(_u0936, handler_), handler_), handler_);
}

#line 928 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_multivariate_student_t(const libbirch::DefaultArray<birch::type::Real,1>& x, const birch::type::Real& k, const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const birch::type::LLT& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 928 "src/math/logpdf.birch"
  libbirch_function_("logpdf_multivariate_student_t", "src/math/logpdf.birch", 928);
  #line 930 "src/math/logpdf.birch"
  libbirch_line_(930);
  #line 930 "src/math/logpdf.birch"
  auto n = birch::length(_u0956, handler_);
  #line 931 "src/math/logpdf.birch"
  libbirch_line_(931);
  #line 931 "src/math/logpdf.birch"
  auto a = 0.5 * (k + n);
  #line 932 "src/math/logpdf.birch"
  libbirch_line_(932);
  #line 932 "src/math/logpdf.birch"
  return birch::lgamma(a, handler_) - birch::lgamma(0.5 * k, handler_) - 0.5 * n * birch::log(k * birch::_u0960(), handler_) - 0.5 * birch::ldet(_u0931, handler_) - a * birch::log1p(birch::dot(x - _u0956, birch::solve(_u0931, x - _u0956, handler_), handler_) / k, handler_);
}

#line 947 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_multivariate_student_t(const libbirch::DefaultArray<birch::type::Real,1>& x, const birch::type::Real& k, const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 947 "src/math/logpdf.birch"
  libbirch_function_("logpdf_multivariate_student_t", "src/math/logpdf.birch", 947);
  #line 949 "src/math/logpdf.birch"
  libbirch_line_(949);
  #line 949 "src/math/logpdf.birch"
  auto n = birch::length(_u0956, handler_);
  #line 950 "src/math/logpdf.birch"
  libbirch_line_(950);
  #line 950 "src/math/logpdf.birch"
  auto a = 0.5 * (k + n);
  #line 951 "src/math/logpdf.birch"
  libbirch_line_(951);
  #line 951 "src/math/logpdf.birch"
  return birch::lgamma(a, handler_) - birch::lgamma(0.5 * k, handler_) - 0.5 * n * birch::log(k * birch::_u0960(), handler_) - 0.5 * n * birch::log(_u09632, handler_) - a * birch::log1p(birch::dot(x - _u0956, handler_) / (_u09632 * k), handler_);
}

#line 967 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_matrix_student_t(const libbirch::DefaultArray<birch::type::Real,2>& X, const birch::type::Real& k, const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const birch::type::LLT& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 967 "src/math/logpdf.birch"
  libbirch_function_("logpdf_matrix_student_t", "src/math/logpdf.birch", 967);
  #line 969 "src/math/logpdf.birch"
  libbirch_line_(969);
  #line 969 "src/math/logpdf.birch"
  auto n = birch::rows(M, handler_);
  #line 970 "src/math/logpdf.birch"
  libbirch_line_(970);
  #line 970 "src/math/logpdf.birch"
  auto p = birch::columns(M, handler_);
  #line 971 "src/math/logpdf.birch"
  libbirch_line_(971);
  #line 971 "src/math/logpdf.birch"
  auto a = 0.5 * (k + n + p - 1.0);
  #line 972 "src/math/logpdf.birch"
  libbirch_line_(972);
  #line 972 "src/math/logpdf.birch"
  auto b = 0.5 * (k + p - 1.0);
  #line 973 "src/math/logpdf.birch"
  libbirch_line_(973);
  #line 973 "src/math/logpdf.birch"
  auto E = birch::identity(n, handler_) + birch::solve(U, X - M, handler_) * birch::solve(V, birch::transpose(X - M, handler_), handler_);
  #line 975 "src/math/logpdf.birch"
  libbirch_line_(975);
  #line 975 "src/math/logpdf.birch"
  return birch::lgamma(a, p, handler_) - birch::lgamma(b, p, handler_) - 0.5 * n * p * birch::log(birch::_u0960(), handler_) - 0.5 * n * birch::ldet(U, handler_) - 0.5 * p * birch::ldet(V, handler_) - a * birch::ldet(E, handler_);
}

#line 991 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_matrix_student_t(const libbirch::DefaultArray<birch::type::Real,2>& X, const birch::type::Real& k, const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const libbirch::DefaultArray<birch::type::Real,1>& v, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 991 "src/math/logpdf.birch"
  libbirch_function_("logpdf_matrix_student_t", "src/math/logpdf.birch", 991);
  #line 993 "src/math/logpdf.birch"
  libbirch_line_(993);
  #line 993 "src/math/logpdf.birch"
  auto n = birch::rows(M, handler_);
  #line 994 "src/math/logpdf.birch"
  libbirch_line_(994);
  #line 994 "src/math/logpdf.birch"
  auto p = birch::columns(M, handler_);
  #line 995 "src/math/logpdf.birch"
  libbirch_line_(995);
  #line 995 "src/math/logpdf.birch"
  auto a = 0.5 * (k + n + p - 1.0);
  #line 996 "src/math/logpdf.birch"
  libbirch_line_(996);
  #line 996 "src/math/logpdf.birch"
  auto b = 0.5 * (k + p - 1.0);
  #line 997 "src/math/logpdf.birch"
  libbirch_line_(997);
  #line 997 "src/math/logpdf.birch"
  auto E = birch::identity(n, handler_) + birch::solve(U, X - M, handler_) * birch::solve(birch::diagonal(v, handler_), birch::transpose(X - M, handler_), handler_);
  #line 999 "src/math/logpdf.birch"
  libbirch_line_(999);
  #line 999 "src/math/logpdf.birch"
  return birch::lgamma(a, p, handler_) - birch::lgamma(b, p, handler_) - 0.5 * n * p * birch::log(birch::_u0960(), handler_) - 0.5 * n * birch::ldet(U, handler_) - 0.5 * p * birch::ldet(birch::diagonal(v, handler_), handler_) - a * birch::ldet(E, handler_);
}

#line 1012 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_independent_uniform(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& l, const libbirch::DefaultArray<birch::type::Real,1>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1012 "src/math/logpdf.birch"
  libbirch_function_("logpdf_independent_uniform", "src/math/logpdf.birch", 1012);
  #line 1013 "src/math/logpdf.birch"
  libbirch_line_(1013);
  #line 1013 "src/math/logpdf.birch"
  libbirch_assert_(birch::length(x, handler_) > birch::type::Integer(0));
  #line 1014 "src/math/logpdf.birch"
  libbirch_line_(1014);
  #line 1014 "src/math/logpdf.birch"
  libbirch_assert_(birch::length(l, handler_) == birch::length(x, handler_));
  #line 1015 "src/math/logpdf.birch"
  libbirch_line_(1015);
  #line 1015 "src/math/logpdf.birch"
  libbirch_assert_(birch::length(u, handler_) == birch::length(x, handler_));
  #line 1017 "src/math/logpdf.birch"
  libbirch_line_(1017);
  #line 1017 "src/math/logpdf.birch"
  birch::type::Integer D = birch::length(l, handler_);
  #line 1018 "src/math/logpdf.birch"
  libbirch_line_(1018);
  #line 1018 "src/math/logpdf.birch"
  birch::type::Real w = 0.0;
  #line 1019 "src/math/logpdf.birch"
  libbirch_line_(1019);
  #line 1019 "src/math/logpdf.birch"
  for (auto d = birch::type::Integer(1); d <= D; ++d) {
    #line 1020 "src/math/logpdf.birch"
    libbirch_line_(1020);
    #line 1020 "src/math/logpdf.birch"
    w = w + birch::logpdf_uniform(x.get(libbirch::make_slice(d - 1)), l.get(libbirch::make_slice(d - 1)), u.get(libbirch::make_slice(d - 1)), handler_);
  }
  #line 1022 "src/math/logpdf.birch"
  libbirch_line_(1022);
  #line 1022 "src/math/logpdf.birch"
  return w;
}

#line 1034 "src/math/logpdf.birch"
birch::type::Real birch::logpdf_independent_uniform_int(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::DefaultArray<birch::type::Integer,1>& l, const libbirch::DefaultArray<birch::type::Integer,1>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1034 "src/math/logpdf.birch"
  libbirch_function_("logpdf_independent_uniform_int", "src/math/logpdf.birch", 1034);
  #line 1035 "src/math/logpdf.birch"
  libbirch_line_(1035);
  #line 1035 "src/math/logpdf.birch"
  libbirch_assert_(birch::length(x, handler_) > birch::type::Integer(0));
  #line 1036 "src/math/logpdf.birch"
  libbirch_line_(1036);
  #line 1036 "src/math/logpdf.birch"
  libbirch_assert_(birch::length(l, handler_) == birch::length(x, handler_));
  #line 1037 "src/math/logpdf.birch"
  libbirch_line_(1037);
  #line 1037 "src/math/logpdf.birch"
  libbirch_assert_(birch::length(u, handler_) == birch::length(x, handler_));
  #line 1039 "src/math/logpdf.birch"
  libbirch_line_(1039);
  #line 1039 "src/math/logpdf.birch"
  birch::type::Integer D = birch::length(x, handler_);
  #line 1040 "src/math/logpdf.birch"
  libbirch_line_(1040);
  #line 1040 "src/math/logpdf.birch"
  birch::type::Real w = 0.0;
  #line 1041 "src/math/logpdf.birch"
  libbirch_line_(1041);
  #line 1041 "src/math/logpdf.birch"
  for (auto d = birch::type::Integer(1); d <= D; ++d) {
    #line 1042 "src/math/logpdf.birch"
    libbirch_line_(1042);
    #line 1042 "src/math/logpdf.birch"
    w = w + birch::logpdf_uniform_int(x.get(libbirch::make_slice(d - 1)), l.get(libbirch::make_slice(d - 1)), u.get(libbirch::make_slice(d - 1)), handler_);
  }
  #line 1044 "src/math/logpdf.birch"
  libbirch_line_(1044);
  #line 1044 "src/math/logpdf.birch"
  return w;
}

#line 9 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_bernoulli(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Boolean>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_bernoulli", "src/math/logpdf_lazy.birch", 9);
  #line 10 "src/math/logpdf_lazy.birch"
  libbirch_line_(10);
  #line 10 "src/math/logpdf_lazy.birch"
  return birch::Real(x, handler_) * birch::log(_u0961, handler_) + (1.0 - birch::Real(x, handler_)) * birch::log1p(-_u0961, handler_);
}

#line 22 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_binomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& n, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_binomial", "src/math/logpdf_lazy.birch", 22);
  #line 23 "src/math/logpdf_lazy.birch"
  libbirch_line_(23);
  #line 23 "src/math/logpdf_lazy.birch"
  return birch::Real(x, handler_) * birch::log(_u0961, handler_) + birch::Real(n - x, handler_) * birch::log1p(-_u0961, handler_) + birch::lchoose(n, x, handler_);
}

#line 35 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_negative_binomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_negative_binomial", "src/math/logpdf_lazy.birch", 35);
  #line 36 "src/math/logpdf_lazy.birch"
  libbirch_line_(36);
  #line 36 "src/math/logpdf_lazy.birch"
  return birch::Real(k, handler_) * birch::log(_u0961, handler_) + birch::Real(x, handler_) * birch::log1p(-_u0961, handler_) + birch::lchoose(x + k - birch::type::Integer(1), x, handler_);
}

#line 47 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_poisson(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_poisson", "src/math/logpdf_lazy.birch", 47);
  #line 48 "src/math/logpdf_lazy.birch"
  libbirch_line_(48);
  #line 48 "src/math/logpdf_lazy.birch"
  return birch::Real(x, handler_) * birch::log(_u0955, handler_) - _u0955 - birch::lgamma(birch::Real(x + birch::type::Integer(1), handler_), handler_);
}

#line 122 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_exponential(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 122 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_exponential", "src/math/logpdf_lazy.birch", 122);
  #line 123 "src/math/logpdf_lazy.birch"
  libbirch_line_(123);
  #line 123 "src/math/logpdf_lazy.birch"
  return birch::if_then_else(x < 0.0, -birch::inf(), birch::log(_u0955, handler_) - _u0955 * x, handler_);
}

#line 135 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_weibull(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 135 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_weibull", "src/math/logpdf_lazy.birch", 135);
  #line 136 "src/math/logpdf_lazy.birch"
  libbirch_line_(136);
  #line 136 "src/math/logpdf_lazy.birch"
  return birch::if_then_else(x < 0.0, -birch::inf(), birch::log(k, handler_) + (k - 1.0) * birch::log(x, handler_) - k * birch::log(_u0955, handler_) - birch::pow(x / _u0955, k, handler_), handler_);
}

#line 149 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 149 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_gaussian", "src/math/logpdf_lazy.birch", 149);
  #line 150 "src/math/logpdf_lazy.birch"
  libbirch_line_(150);
  #line 150 "src/math/logpdf_lazy.birch"
  return -0.5 * (birch::pow(x - _u0956, 2.0, handler_) / _u09632 + birch::log(2.0 * birch::_u0960() * _u09632, handler_));
}

#line 161 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_student_t(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 161 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_student_t", "src/math/logpdf_lazy.birch", 161);
  #line 162 "src/math/logpdf_lazy.birch"
  libbirch_line_(162);
  #line 162 "src/math/logpdf_lazy.birch"
  auto a = 0.5 * (k + 1.0);
  #line 163 "src/math/logpdf_lazy.birch"
  libbirch_line_(163);
  #line 163 "src/math/logpdf_lazy.birch"
  return birch::lgamma(a, handler_) - birch::lgamma(0.5 * k, handler_) - 0.5 * birch::log(birch::_u0960() * k, handler_) - a * birch::log1p(x * x / k, handler_);
}

#line 176 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_student_t(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 176 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_student_t", "src/math/logpdf_lazy.birch", 176);
  #line 177 "src/math/logpdf_lazy.birch"
  libbirch_line_(177);
  #line 177 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_student_t((x - _u0956) / birch::sqrt(_u09632, handler_), k, handler_) - 0.5 * birch::log(_u09632, handler_);
}

#line 189 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_beta(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 189 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_beta", "src/math/logpdf_lazy.birch", 189);
  #line 190 "src/math/logpdf_lazy.birch"
  libbirch_line_(190);
  #line 190 "src/math/logpdf_lazy.birch"
  return (_u0945 - 1.0) * birch::log(x, handler_) + (_u0946 - 1.0) * birch::log1p(-x, handler_) - birch::lbeta(_u0945, _u0946, handler_);
}

#line 201 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_chi_squared(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 201 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_chi_squared", "src/math/logpdf_lazy.birch", 201);
  #line 202 "src/math/logpdf_lazy.birch"
  libbirch_line_(202);
  #line 202 "src/math/logpdf_lazy.birch"
  auto k = 0.5 * _u0957;
  #line 203 "src/math/logpdf_lazy.birch"
  libbirch_line_(203);
  #line 203 "src/math/logpdf_lazy.birch"
  return (k - 1.0) * birch::log(x, handler_) - 0.5 * x - birch::lgamma(k, handler_) - k * birch::log(2.0, handler_);
}

#line 215 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_gamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 215 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_gamma", "src/math/logpdf_lazy.birch", 215);
  #line 216 "src/math/logpdf_lazy.birch"
  libbirch_line_(216);
  #line 216 "src/math/logpdf_lazy.birch"
  return birch::if_then_else(x < 0.0, -birch::inf(), (k - 1.0) * birch::log(x, handler_) - x / _u0952 - birch::lgamma(k, handler_) - k * birch::log(_u0952, handler_), handler_);
}

#line 229 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_wishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 229 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_wishart", "src/math/logpdf_lazy.birch", 229);
  #line 230 "src/math/logpdf_lazy.birch"
  libbirch_line_(230);
  #line 230 "src/math/logpdf_lazy.birch"
  auto p = birch::rows(_u0936, handler_);
  #line 231 "src/math/logpdf_lazy.birch"
  libbirch_line_(231);
  #line 231 "src/math/logpdf_lazy.birch"
  return 0.5 * (_u0957 - p - 1.0) * birch::ldet(X, handler_) - 0.5 * birch::trace(birch::solve(_u0936, birch::canonical(X, handler_), handler_), handler_) - 0.5 * _u0957 * p * birch::log(2.0, handler_) - 0.5 * _u0957 * birch::ldet(_u0936, handler_) - birch::lgamma(0.5 * _u0957, p, handler_);
}

#line 244 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_inverse_gamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 244 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_inverse_gamma", "src/math/logpdf_lazy.birch", 244);
  #line 245 "src/math/logpdf_lazy.birch"
  libbirch_line_(245);
  #line 245 "src/math/logpdf_lazy.birch"
  return birch::if_then_else(x < 0.0, -birch::inf(), _u0945 * birch::log(_u0946, handler_) - (_u0945 + 1.0) * birch::log(x, handler_) - _u0946 / x - birch::lgamma(_u0945, handler_), handler_);
}

#line 258 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_inverse_wishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 258 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_inverse_wishart", "src/math/logpdf_lazy.birch", 258);
  #line 259 "src/math/logpdf_lazy.birch"
  libbirch_line_(259);
  #line 259 "src/math/logpdf_lazy.birch"
  auto p = birch::rows(_u0936, handler_);
  #line 260 "src/math/logpdf_lazy.birch"
  libbirch_line_(260);
  #line 260 "src/math/logpdf_lazy.birch"
  return 0.5 * _u0957 * birch::ldet(_u0936, handler_) - 0.5 * (_u0957 + p - 1.0) * birch::ldet(X, handler_) - 0.5 * birch::trace(birch::solve(X, birch::canonical(birch::transpose(_u0936, handler_), handler_), handler_), handler_) - 0.5 * _u0957 * p * birch::log(2.0, handler_) - birch::lgamma(0.5 * _u0957, p, handler_);
}

#line 274 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_inverse_gamma_gamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 274 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_inverse_gamma_gamma", "src/math/logpdf_lazy.birch", 274);
  #line 275 "src/math/logpdf_lazy.birch"
  libbirch_line_(275);
  #line 275 "src/math/logpdf_lazy.birch"
  return (k - birch::type::Integer(1)) * birch::log(x, handler_) + _u0945 * birch::log(_u0946, handler_) - (_u0945 + k) * birch::log(_u0946 + x, handler_) - birch::lbeta(_u0945, k, handler_);
}

#line 289 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_normal_inverse_gamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a2, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 289 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_normal_inverse_gamma", "src/math/logpdf_lazy.birch", 289);
  #line 291 "src/math/logpdf_lazy.birch"
  libbirch_line_(291);
  #line 291 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_student_t(x, 2.0 * _u0945, _u0956, a2 * _u0946 / _u0945, handler_);
}

#line 303 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_beta_bernoulli(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Boolean>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 303 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_beta_bernoulli", "src/math/logpdf_lazy.birch", 303);
  #line 304 "src/math/logpdf_lazy.birch"
  libbirch_line_(304);
  #line 304 "src/math/logpdf_lazy.birch"
  return birch::Real(x, handler_) * birch::log(_u0945, handler_) + (1.0 - birch::Real(x, handler_)) * birch::log(_u0946, handler_) - birch::log(_u0945 + _u0946, handler_);
}

#line 317 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_beta_binomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& n, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 317 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_beta_binomial", "src/math/logpdf_lazy.birch", 317);
  #line 318 "src/math/logpdf_lazy.birch"
  libbirch_line_(318);
  #line 318 "src/math/logpdf_lazy.birch"
  return birch::lbeta(birch::Real(x, handler_) + _u0945, birch::Real(n - x, handler_) + _u0946, handler_) - birch::lbeta(_u0945, _u0946, handler_) + birch::lchoose(n, x, handler_);
}

#line 331 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_beta_negative_binomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 331 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_beta_negative_binomial", "src/math/logpdf_lazy.birch", 331);
  #line 332 "src/math/logpdf_lazy.birch"
  libbirch_line_(332);
  #line 332 "src/math/logpdf_lazy.birch"
  return birch::lbeta(_u0945 + birch::Real(k, handler_), _u0946 + birch::Real(x, handler_), handler_) - birch::lbeta(_u0945, _u0946, handler_) + birch::lchoose(x + k - birch::type::Integer(1), x, handler_);
}

#line 344 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_gamma_poisson(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 344 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_gamma_poisson", "src/math/logpdf_lazy.birch", 344);
  #line 345 "src/math/logpdf_lazy.birch"
  libbirch_line_(345);
  #line 345 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_negative_binomial(x, birch::Integer(k, handler_), 1.0 / (_u0952 + 1.0), handler_);
}

#line 357 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_lomax(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 357 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_lomax", "src/math/logpdf_lazy.birch", 357);
  #line 358 "src/math/logpdf_lazy.birch"
  libbirch_line_(358);
  #line 358 "src/math/logpdf_lazy.birch"
  return birch::if_then_else(x < 0.0, -birch::inf(), birch::log(_u0945, handler_) - birch::log(_u0955, handler_) - (_u0945 + 1.0) * birch::log1p(x / _u0955, handler_), handler_);
}

#line 412 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_normal_inverse_gamma_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a2, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 412 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_normal_inverse_gamma_gaussian", "src/math/logpdf_lazy.birch", 412);
  #line 414 "src/math/logpdf_lazy.birch"
  libbirch_line_(414);
  #line 414 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_student_t(x, 2.0 * _u0945, _u0956, (_u0946 / _u0945) * (1.0 + a2), handler_);
}

#line 431 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_linear_normal_inverse_gamma_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a2, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 431 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_linear_normal_inverse_gamma_gaussian", "src/math/logpdf_lazy.birch", 431);
  #line 433 "src/math/logpdf_lazy.birch"
  libbirch_line_(433);
  #line 433 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_student_t(x, 2.0 * _u0945, a * _u0956 + c, (_u0946 / _u0945) * (1.0 + a * a * a2), handler_);
}

#line 445 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_multivariate_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 445 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_multivariate_gaussian", "src/math/logpdf_lazy.birch", 445);
  #line 446 "src/math/logpdf_lazy.birch"
  libbirch_line_(446);
  #line 446 "src/math/logpdf_lazy.birch"
  auto n = birch::length(_u0956, handler_);
  #line 447 "src/math/logpdf_lazy.birch"
  libbirch_line_(447);
  #line 447 "src/math/logpdf_lazy.birch"
  return -0.5 * (birch::dot(x - _u0956, birch::solve(_u0931, x - _u0956, handler_), handler_) + n * birch::log(2.0 * birch::_u0960(), handler_) + birch::ldet(_u0931, handler_));
}

#line 459 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_multivariate_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 459 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_multivariate_gaussian", "src/math/logpdf_lazy.birch", 459);
  #line 461 "src/math/logpdf_lazy.birch"
  libbirch_line_(461);
  #line 461 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_multivariate_gaussian(x, _u0956, birch::llt(birch::diagonal(_u09632, handler_), handler_), handler_);
}

#line 474 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_multivariate_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 474 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_multivariate_gaussian", "src/math/logpdf_lazy.birch", 474);
  #line 475 "src/math/logpdf_lazy.birch"
  libbirch_line_(475);
  #line 475 "src/math/logpdf_lazy.birch"
  auto n = _u0956->length(handler_);
  #line 476 "src/math/logpdf_lazy.birch"
  libbirch_line_(476);
  #line 476 "src/math/logpdf_lazy.birch"
  return -0.5 * (birch::dot(x - _u0956, handler_) / _u09632 + n * birch::log(2.0 * birch::_u0960() * _u09632, handler_));
}

#line 490 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_multivariate_normal_inverse_gamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0923, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 490 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_multivariate_normal_inverse_gamma", "src/math/logpdf_lazy.birch", 490);
  #line 492 "src/math/logpdf_lazy.birch"
  libbirch_line_(492);
  #line 492 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_multivariate_student_t(x, 2.0 * _u0945, birch::solve(_u0923, _u0957, handler_), birch::llt((_u0946 / _u0945) * birch::canonical(birch::inv(_u0923, handler_), handler_), handler_), handler_);
}

#line 508 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_multivariate_normal_inverse_gamma_multivariate_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0923, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0947, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 508 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/math/logpdf_lazy.birch", 508);
  #line 510 "src/math/logpdf_lazy.birch"
  libbirch_line_(510);
  #line 510 "src/math/logpdf_lazy.birch"
  auto n = _u0957->length(handler_);
  #line 511 "src/math/logpdf_lazy.birch"
  libbirch_line_(511);
  #line 511 "src/math/logpdf_lazy.birch"
  auto _u0956 = birch::solve(_u0923, _u0957, handler_);
  #line 512 "src/math/logpdf_lazy.birch"
  libbirch_line_(512);
  #line 512 "src/math/logpdf_lazy.birch"
  auto _u0946 = _u0947 - 0.5 * birch::dot(_u0956, _u0957, handler_);
  #line 513 "src/math/logpdf_lazy.birch"
  libbirch_line_(513);
  #line 513 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_multivariate_student_t(x, 2.0 * _u0945, _u0956, birch::llt((_u0946 / _u0945) * (birch::identity(n, handler_) + birch::canonical(birch::inv(_u0923, handler_), handler_)), handler_), handler_);
}

#line 531 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& A, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0923, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0947, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 531 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_linear_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/math/logpdf_lazy.birch", 531);
  #line 534 "src/math/logpdf_lazy.birch"
  libbirch_line_(534);
  #line 534 "src/math/logpdf_lazy.birch"
  auto n = birch::rows(A, handler_);
  #line 535 "src/math/logpdf_lazy.birch"
  libbirch_line_(535);
  #line 535 "src/math/logpdf_lazy.birch"
  auto _u0956 = birch::solve(_u0923, _u0957, handler_);
  #line 536 "src/math/logpdf_lazy.birch"
  libbirch_line_(536);
  #line 536 "src/math/logpdf_lazy.birch"
  auto _u0946 = _u0947 - 0.5 * birch::dot(_u0956, _u0957, handler_);
  #line 537 "src/math/logpdf_lazy.birch"
  libbirch_line_(537);
  #line 537 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_multivariate_student_t(x, 2.0 * _u0945, A * _u0956 + c, birch::llt((_u0946 / _u0945) * (birch::identity(n, handler_) + A * birch::solve(_u0923, birch::transpose(A, handler_), handler_)), handler_), handler_);
}

#line 555 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_linear_multivariate_normal_inverse_gamma_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0923, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0947, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 555 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_linear_multivariate_normal_inverse_gamma_gaussian", "src/math/logpdf_lazy.birch", 555);
  #line 557 "src/math/logpdf_lazy.birch"
  libbirch_line_(557);
  #line 557 "src/math/logpdf_lazy.birch"
  auto _u0956 = birch::solve(_u0923, _u0957, handler_);
  #line 558 "src/math/logpdf_lazy.birch"
  libbirch_line_(558);
  #line 558 "src/math/logpdf_lazy.birch"
  auto _u0946 = _u0947 - 0.5 * birch::dot(_u0956, _u0957, handler_);
  #line 559 "src/math/logpdf_lazy.birch"
  libbirch_line_(559);
  #line 559 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_student_t(x, 2.0 * _u0945, birch::dot(a, _u0956, handler_) + c, (_u0946 / _u0945) * (1.0 + birch::dot(a, birch::solve(_u0923, a, handler_), handler_)), handler_);
}

#line 573 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_matrix_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 573 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_matrix_gaussian", "src/math/logpdf_lazy.birch", 573);
  #line 575 "src/math/logpdf_lazy.birch"
  libbirch_line_(575);
  #line 575 "src/math/logpdf_lazy.birch"
  auto n = birch::rows(M, handler_);
  #line 576 "src/math/logpdf_lazy.birch"
  libbirch_line_(576);
  #line 576 "src/math/logpdf_lazy.birch"
  auto p = birch::columns(M, handler_);
  #line 577 "src/math/logpdf_lazy.birch"
  libbirch_line_(577);
  #line 577 "src/math/logpdf_lazy.birch"
  return -0.5 * (birch::trace(birch::solve(V, birch::transpose(X - M, handler_), handler_) * birch::solve(U, X - M, handler_), handler_) + n * p * birch::log(2.0 * birch::_u0960(), handler_) + n * birch::ldet(V, handler_) + p * birch::ldet(U, handler_));
}

#line 591 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_matrix_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 591 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_matrix_gaussian", "src/math/logpdf_lazy.birch", 591);
  #line 594 "src/math/logpdf_lazy.birch"
  libbirch_line_(594);
  #line 594 "src/math/logpdf_lazy.birch"
  auto n = birch::rows(M, handler_);
  #line 595 "src/math/logpdf_lazy.birch"
  libbirch_line_(595);
  #line 595 "src/math/logpdf_lazy.birch"
  auto p = birch::columns(M, handler_);
  #line 596 "src/math/logpdf_lazy.birch"
  libbirch_line_(596);
  #line 596 "src/math/logpdf_lazy.birch"
  return -0.5 * (birch::trace(birch::solve(birch::diagonal(_u09632, handler_), birch::transpose(X - M, handler_), handler_) * birch::solve(U, X - M, handler_), handler_) + n * p * birch::log(2.0 * birch::_u0960(), handler_) + n * birch::ldet(birch::diagonal(_u09632, handler_), handler_) + p * birch::ldet(U, handler_));
}

#line 609 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_matrix_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 609 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_matrix_gaussian", "src/math/logpdf_lazy.birch", 609);
  #line 610 "src/math/logpdf_lazy.birch"
  libbirch_line_(610);
  #line 610 "src/math/logpdf_lazy.birch"
  auto n = birch::rows(M, handler_);
  #line 611 "src/math/logpdf_lazy.birch"
  libbirch_line_(611);
  #line 611 "src/math/logpdf_lazy.birch"
  auto p = birch::columns(M, handler_);
  #line 612 "src/math/logpdf_lazy.birch"
  libbirch_line_(612);
  #line 612 "src/math/logpdf_lazy.birch"
  return -0.5 * (birch::trace(birch::solve(V, birch::transpose(X - M, handler_), handler_) * (X - M), handler_) + n * p * birch::log(2.0 * birch::_u0960(), handler_) + n * birch::ldet(V, handler_));
}

#line 625 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_matrix_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 625 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_matrix_gaussian", "src/math/logpdf_lazy.birch", 625);
  #line 627 "src/math/logpdf_lazy.birch"
  libbirch_line_(627);
  #line 627 "src/math/logpdf_lazy.birch"
  auto n = birch::rows(M, handler_);
  #line 628 "src/math/logpdf_lazy.birch"
  libbirch_line_(628);
  #line 628 "src/math/logpdf_lazy.birch"
  auto p = birch::columns(M, handler_);
  #line 629 "src/math/logpdf_lazy.birch"
  libbirch_line_(629);
  #line 629 "src/math/logpdf_lazy.birch"
  return -0.5 * (birch::trace(birch::solve(birch::diagonal(_u09632, handler_), birch::transpose(X - M, handler_) * (X - M), handler_), handler_) + n * p * birch::log(2.0 * birch::_u0960(), handler_) + n * birch::ldet(birch::diagonal(_u09632, handler_), handler_));
}

#line 643 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_matrix_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 643 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_matrix_gaussian", "src/math/logpdf_lazy.birch", 643);
  #line 645 "src/math/logpdf_lazy.birch"
  libbirch_line_(645);
  #line 645 "src/math/logpdf_lazy.birch"
  auto n = birch::rows(M, handler_);
  #line 646 "src/math/logpdf_lazy.birch"
  libbirch_line_(646);
  #line 646 "src/math/logpdf_lazy.birch"
  auto p = birch::columns(M, handler_);
  #line 647 "src/math/logpdf_lazy.birch"
  libbirch_line_(647);
  #line 647 "src/math/logpdf_lazy.birch"
  return -0.5 * (birch::trace(birch::transpose(X - M, handler_) * (X - M) / _u09632, handler_) + n * p * birch::log(2.0 * birch::_u0960() * _u09632, handler_));
}

#line 661 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_matrix_normal_inverse_wishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& N, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0923, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 661 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_matrix_normal_inverse_wishart", "src/math/logpdf_lazy.birch", 661);
  #line 663 "src/math/logpdf_lazy.birch"
  libbirch_line_(663);
  #line 663 "src/math/logpdf_lazy.birch"
  auto p = birch::columns(N, handler_);
  #line 664 "src/math/logpdf_lazy.birch"
  libbirch_line_(664);
  #line 664 "src/math/logpdf_lazy.birch"
  auto M = birch::solve(_u0923, N, handler_);
  #line 665 "src/math/logpdf_lazy.birch"
  libbirch_line_(665);
  #line 665 "src/math/logpdf_lazy.birch"
  auto _u0931 = birch::llt(birch::canonical(birch::inv(_u0923, handler_), handler_) / (k - p + 1.0), handler_);
  #line 666 "src/math/logpdf_lazy.birch"
  libbirch_line_(666);
  #line 666 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_matrix_student_t(X, k - p + 1.0, M, _u0931, _u0936, handler_);
}

#line 680 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_matrix_normal_inverse_wishart_matrix_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& N, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0923, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 680 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_matrix_normal_inverse_wishart_matrix_gaussian", "src/math/logpdf_lazy.birch", 680);
  #line 682 "src/math/logpdf_lazy.birch"
  libbirch_line_(682);
  #line 682 "src/math/logpdf_lazy.birch"
  auto n = birch::rows(N, handler_);
  #line 683 "src/math/logpdf_lazy.birch"
  libbirch_line_(683);
  #line 683 "src/math/logpdf_lazy.birch"
  auto p = birch::columns(N, handler_);
  #line 684 "src/math/logpdf_lazy.birch"
  libbirch_line_(684);
  #line 684 "src/math/logpdf_lazy.birch"
  auto M = birch::solve(_u0923, N, handler_);
  #line 685 "src/math/logpdf_lazy.birch"
  libbirch_line_(685);
  #line 685 "src/math/logpdf_lazy.birch"
  auto _u0931 = birch::llt((birch::identity(n, handler_) + birch::canonical(birch::inv(_u0923, handler_), handler_)) / (k - p + 1.0), handler_);
  #line 686 "src/math/logpdf_lazy.birch"
  libbirch_line_(686);
  #line 686 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_matrix_student_t(X, k - p + 1.0, M, _u0931, _u0936, handler_);
}

#line 703 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_linear_matrix_normal_inverse_wishart_matrix_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& A, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& N, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0923, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& C, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 703 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_linear_matrix_normal_inverse_wishart_matrix_gaussian", "src/math/logpdf_lazy.birch", 703);
  #line 706 "src/math/logpdf_lazy.birch"
  libbirch_line_(706);
  #line 706 "src/math/logpdf_lazy.birch"
  auto n = birch::rows(A, handler_);
  #line 707 "src/math/logpdf_lazy.birch"
  libbirch_line_(707);
  #line 707 "src/math/logpdf_lazy.birch"
  auto p = birch::columns(N, handler_);
  #line 708 "src/math/logpdf_lazy.birch"
  libbirch_line_(708);
  #line 708 "src/math/logpdf_lazy.birch"
  auto M = birch::solve(_u0923, N, handler_);
  #line 709 "src/math/logpdf_lazy.birch"
  libbirch_line_(709);
  #line 709 "src/math/logpdf_lazy.birch"
  auto _u0931 = birch::llt((birch::identity(n, handler_) + A * birch::solve(_u0923, birch::transpose(A, handler_), handler_)) / (k - p + 1.0), handler_);
  #line 710 "src/math/logpdf_lazy.birch"
  libbirch_line_(710);
  #line 710 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_matrix_student_t(X, k - p + 1.0, A * M + C, _u0931, _u0936, handler_);
}

#line 727 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_linear_matrix_normal_inverse_wishart_multivariate_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& N, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0923, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 727 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_linear_matrix_normal_inverse_wishart_multivariate_gaussian", "src/math/logpdf_lazy.birch", 727);
  #line 731 "src/math/logpdf_lazy.birch"
  libbirch_line_(731);
  #line 731 "src/math/logpdf_lazy.birch"
  auto p = birch::columns(N, handler_);
  #line 732 "src/math/logpdf_lazy.birch"
  libbirch_line_(732);
  #line 732 "src/math/logpdf_lazy.birch"
  auto M = birch::solve(_u0923, N, handler_);
  #line 733 "src/math/logpdf_lazy.birch"
  libbirch_line_(733);
  #line 733 "src/math/logpdf_lazy.birch"
  auto _u09632 = 1.0 + birch::dot(a, birch::solve(_u0923, a, handler_), handler_) / (k - p + 1.0);
  #line 734 "src/math/logpdf_lazy.birch"
  libbirch_line_(734);
  #line 734 "src/math/logpdf_lazy.birch"
  return birch::logpdf_lazy_multivariate_student_t(x, k - p + 1.0, birch::dot(a, M, handler_) + c, birch::llt(_u09632 * birch::canonical(_u0936, handler_), handler_), handler_);
}

#line 749 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_multivariate_student_t(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 749 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_multivariate_student_t", "src/math/logpdf_lazy.birch", 749);
  #line 751 "src/math/logpdf_lazy.birch"
  libbirch_line_(751);
  #line 751 "src/math/logpdf_lazy.birch"
  auto n = birch::length(_u0956, handler_);
  #line 752 "src/math/logpdf_lazy.birch"
  libbirch_line_(752);
  #line 752 "src/math/logpdf_lazy.birch"
  auto a = 0.5 * (k + n);
  #line 753 "src/math/logpdf_lazy.birch"
  libbirch_line_(753);
  #line 753 "src/math/logpdf_lazy.birch"
  return birch::lgamma(a, handler_) - birch::lgamma(0.5 * k, handler_) - 0.5 * n * birch::log(k * birch::_u0960(), handler_) - 0.5 * birch::ldet(_u0931, handler_) - a * birch::log1p(birch::dot(x - _u0956, birch::solve(_u0931, x - _u0956, handler_), handler_) / k, handler_);
}

#line 768 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_multivariate_student_t(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 768 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_multivariate_student_t", "src/math/logpdf_lazy.birch", 768);
  #line 770 "src/math/logpdf_lazy.birch"
  libbirch_line_(770);
  #line 770 "src/math/logpdf_lazy.birch"
  auto n = birch::length(_u0956, handler_);
  #line 771 "src/math/logpdf_lazy.birch"
  libbirch_line_(771);
  #line 771 "src/math/logpdf_lazy.birch"
  auto a = 0.5 * (k + n);
  #line 772 "src/math/logpdf_lazy.birch"
  libbirch_line_(772);
  #line 772 "src/math/logpdf_lazy.birch"
  return birch::lgamma(a, handler_) - birch::lgamma(0.5 * k, handler_) - 0.5 * n * birch::log(k * birch::_u0960(), handler_) - 0.5 * n * birch::log(_u09632, handler_) - a * birch::log1p(birch::dot(x - _u0956, handler_) / (_u09632 * k), handler_);
}

#line 788 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_matrix_student_t(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 788 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_matrix_student_t", "src/math/logpdf_lazy.birch", 788);
  #line 790 "src/math/logpdf_lazy.birch"
  libbirch_line_(790);
  #line 790 "src/math/logpdf_lazy.birch"
  auto n = birch::rows(M, handler_);
  #line 791 "src/math/logpdf_lazy.birch"
  libbirch_line_(791);
  #line 791 "src/math/logpdf_lazy.birch"
  auto p = birch::columns(M, handler_);
  #line 792 "src/math/logpdf_lazy.birch"
  libbirch_line_(792);
  #line 792 "src/math/logpdf_lazy.birch"
  auto a = 0.5 * (k + n + p - 1.0);
  #line 793 "src/math/logpdf_lazy.birch"
  libbirch_line_(793);
  #line 793 "src/math/logpdf_lazy.birch"
  auto b = 0.5 * (k + p - 1.0);
  #line 794 "src/math/logpdf_lazy.birch"
  libbirch_line_(794);
  #line 794 "src/math/logpdf_lazy.birch"
  auto E = birch::identity(n, handler_) + birch::solve(U, X - M, handler_) * birch::solve(V, birch::transpose(X - M, handler_), handler_);
  #line 796 "src/math/logpdf_lazy.birch"
  libbirch_line_(796);
  #line 796 "src/math/logpdf_lazy.birch"
  return birch::lgamma(a, p, handler_) - birch::lgamma(b, p, handler_) - 0.5 * n * p * birch::log(birch::_u0960(), handler_) - 0.5 * n * birch::ldet(U, handler_) - 0.5 * p * birch::ldet(V, handler_) - a * birch::ldet(E, handler_);
}

#line 812 "src/math/logpdf_lazy.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::logpdf_lazy_matrix_student_t(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& v, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 812 "src/math/logpdf_lazy.birch"
  libbirch_function_("logpdf_lazy_matrix_student_t", "src/math/logpdf_lazy.birch", 812);
  #line 814 "src/math/logpdf_lazy.birch"
  libbirch_line_(814);
  #line 814 "src/math/logpdf_lazy.birch"
  auto n = birch::rows(M, handler_);
  #line 815 "src/math/logpdf_lazy.birch"
  libbirch_line_(815);
  #line 815 "src/math/logpdf_lazy.birch"
  auto p = birch::columns(M, handler_);
  #line 816 "src/math/logpdf_lazy.birch"
  libbirch_line_(816);
  #line 816 "src/math/logpdf_lazy.birch"
  auto a = 0.5 * (k + n + p - 1.0);
  #line 817 "src/math/logpdf_lazy.birch"
  libbirch_line_(817);
  #line 817 "src/math/logpdf_lazy.birch"
  auto b = 0.5 * (k + p - 1.0);
  #line 818 "src/math/logpdf_lazy.birch"
  libbirch_line_(818);
  #line 818 "src/math/logpdf_lazy.birch"
  auto E = birch::identity(n, handler_) + birch::solve(U, X - M, handler_) * birch::solve(birch::diagonal(v, handler_), birch::transpose(X - M, handler_), handler_);
  #line 820 "src/math/logpdf_lazy.birch"
  libbirch_line_(820);
  #line 820 "src/math/logpdf_lazy.birch"
  return birch::lgamma(a, p, handler_) - birch::lgamma(b, p, handler_) - 0.5 * n * p * birch::log(birch::_u0960(), handler_) - 0.5 * n * birch::ldet(U, handler_) - 0.5 * p * birch::ldet(birch::diagonal(v, handler_), handler_) - a * birch::ldet(E, handler_);
}

#line 130 "src/math/matrix.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::diagonal(const birch::type::Real& x, const birch::type::Integer& length, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 130 "src/math/matrix.birch"
  libbirch_function_("diagonal", "src/math/matrix.birch", 130);
  #line 131 "src/math/matrix.birch"
  libbirch_line_(131);
  #line 131 "src/math/matrix.birch"
  return birch::matrix(std::function<birch::type::Real(birch::type::Integer,birch::type::Integer,const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_
)>([=](const birch::type::Integer& i, const birch::type::Integer& j, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr) {
    #line 132 "src/math/matrix.birch"
    libbirch_line_(132);
    #line 132 "src/math/matrix.birch"
    if (i == j) {
      #line 133 "src/math/matrix.birch"
      libbirch_line_(133);
      #line 133 "src/math/matrix.birch"
      return x;
    } else {
      #line 135 "src/math/matrix.birch"
      libbirch_line_(135);
      #line 135 "src/math/matrix.birch"
      return 0.0;
    }
  }), length, length, handler_);
}

#line 146 "src/math/matrix.birch"
libbirch::DefaultArray<birch::type::Integer,2> birch::diagonal(const birch::type::Integer& x, const birch::type::Integer& length, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 146 "src/math/matrix.birch"
  libbirch_function_("diagonal", "src/math/matrix.birch", 146);
  #line 147 "src/math/matrix.birch"
  libbirch_line_(147);
  #line 147 "src/math/matrix.birch"
  return birch::matrix(std::function<birch::type::Integer(birch::type::Integer,birch::type::Integer,const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_
)>([=](const birch::type::Integer& i, const birch::type::Integer& j, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr) {
    #line 148 "src/math/matrix.birch"
    libbirch_line_(148);
    #line 148 "src/math/matrix.birch"
    if (i == j) {
      #line 149 "src/math/matrix.birch"
      libbirch_line_(149);
      #line 149 "src/math/matrix.birch"
      return x;
    } else {
      #line 151 "src/math/matrix.birch"
      libbirch_line_(151);
      #line 151 "src/math/matrix.birch"
      return birch::type::Integer(0);
    }
  }), length, length, handler_);
}

#line 162 "src/math/matrix.birch"
libbirch::DefaultArray<birch::type::Boolean,2> birch::diagonal(const birch::type::Boolean& x, const birch::type::Integer& length, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 162 "src/math/matrix.birch"
  libbirch_function_("diagonal", "src/math/matrix.birch", 162);
  #line 163 "src/math/matrix.birch"
  libbirch_line_(163);
  #line 163 "src/math/matrix.birch"
  return birch::matrix(std::function<birch::type::Boolean(birch::type::Integer,birch::type::Integer,const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_
)>([=](const birch::type::Integer& i, const birch::type::Integer& j, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr) {
    #line 164 "src/math/matrix.birch"
    libbirch_line_(164);
    #line 164 "src/math/matrix.birch"
    if (i == j) {
      #line 165 "src/math/matrix.birch"
      libbirch_line_(165);
      #line 165 "src/math/matrix.birch"
      return x;
    } else {
      #line 167 "src/math/matrix.birch"
      libbirch_line_(167);
      #line 167 "src/math/matrix.birch"
      return false;
    }
  }), length, length, handler_);
}

#line 178 "src/math/matrix.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::identity(const birch::type::Integer& length, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 178 "src/math/matrix.birch"
  libbirch_function_("identity", "src/math/matrix.birch", 178);
  #line 179 "src/math/matrix.birch"
  libbirch_line_(179);
  #line 179 "src/math/matrix.birch"
  return birch::diagonal(1.0, length, handler_);
}

#line 222 "src/math/matrix.birch"
birch::type::String birch::String(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 222 "src/math/matrix.birch"
  libbirch_function_("String", "src/math/matrix.birch", 222);
  #line 223 "src/math/matrix.birch"
  libbirch_line_(223);
  #line 223 "src/math/matrix.birch"
  birch::type::String result;
  #line 224 "src/math/matrix.birch"
std::stringstream buf;
    #line 227 "src/math/matrix.birch"
  libbirch_line_(227);
  #line 227 "src/math/matrix.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(X, handler_); ++i) {
    #line 228 "src/math/matrix.birch"
if (i > 1) {
      buf << '\n';
    }
        #line 233 "src/math/matrix.birch"
    libbirch_line_(233);
    #line 233 "src/math/matrix.birch"
    for (auto j = birch::type::Integer(1); j <= birch::columns(X, handler_); ++j) {
      #line 234 "src/math/matrix.birch"
      libbirch_line_(234);
      #line 234 "src/math/matrix.birch"
      auto value = X.get(libbirch::make_slice(i - 1, j - 1));
      #line 235 "src/math/matrix.birch"
if (j > 1) {
        buf << ' ';
      }
      if (value == floor(value)) {
        buf << (int64_t)value << ".0";
      } else {
        buf << std::scientific << std::setprecision(14) << value;
      }
          }
  }
  #line 247 "src/math/matrix.birch"
result = buf.str();
    #line 250 "src/math/matrix.birch"
  libbirch_line_(250);
  #line 250 "src/math/matrix.birch"
  return result;
}

#line 256 "src/math/matrix.birch"
birch::type::String birch::String(const libbirch::DefaultArray<birch::type::Integer,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 256 "src/math/matrix.birch"
  libbirch_function_("String", "src/math/matrix.birch", 256);
  #line 257 "src/math/matrix.birch"
  libbirch_line_(257);
  #line 257 "src/math/matrix.birch"
  birch::type::String result;
  #line 258 "src/math/matrix.birch"
std::stringstream buf;
    #line 261 "src/math/matrix.birch"
  libbirch_line_(261);
  #line 261 "src/math/matrix.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(X, handler_); ++i) {
    #line 262 "src/math/matrix.birch"
if (i > 1) {
      buf << '\n';
    }
        #line 267 "src/math/matrix.birch"
    libbirch_line_(267);
    #line 267 "src/math/matrix.birch"
    for (auto j = birch::type::Integer(1); j <= birch::columns(X, handler_); ++j) {
      #line 268 "src/math/matrix.birch"
      libbirch_line_(268);
      #line 268 "src/math/matrix.birch"
      auto value = X.get(libbirch::make_slice(i - 1, j - 1));
      #line 269 "src/math/matrix.birch"
if (j > 1) {
        buf << ' ';
      }
      buf << value;
          }
  }
  #line 277 "src/math/matrix.birch"
result = buf.str();
    #line 280 "src/math/matrix.birch"
  libbirch_line_(280);
  #line 280 "src/math/matrix.birch"
  return result;
}

#line 286 "src/math/matrix.birch"
birch::type::String birch::String(const libbirch::DefaultArray<birch::type::Boolean,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 286 "src/math/matrix.birch"
  libbirch_function_("String", "src/math/matrix.birch", 286);
  #line 287 "src/math/matrix.birch"
  libbirch_line_(287);
  #line 287 "src/math/matrix.birch"
  birch::type::String result;
  #line 288 "src/math/matrix.birch"
std::stringstream buf;
    #line 291 "src/math/matrix.birch"
  libbirch_line_(291);
  #line 291 "src/math/matrix.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(X, handler_); ++i) {
    #line 292 "src/math/matrix.birch"
if (i > 1) {
      buf << '\n';
    }
        #line 297 "src/math/matrix.birch"
    libbirch_line_(297);
    #line 297 "src/math/matrix.birch"
    for (auto j = birch::type::Integer(1); j <= birch::columns(X, handler_); ++j) {
      #line 298 "src/math/matrix.birch"
      libbirch_line_(298);
      #line 298 "src/math/matrix.birch"
      auto value = X.get(libbirch::make_slice(i - 1, j - 1));
      #line 299 "src/math/matrix.birch"
if (j > 1) {
        buf << ' ';
      }
      if (value) {
        buf << "true";
      } else {
        buf << "false";
      }
          }
  }
  #line 311 "src/math/matrix.birch"
result = buf.str();
    #line 314 "src/math/matrix.birch"
  libbirch_line_(314);
  #line 314 "src/math/matrix.birch"
  return result;
}

#line 320 "src/math/matrix.birch"
birch::type::String birch::String(const birch::type::LLT& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 320 "src/math/matrix.birch"
  libbirch_function_("String", "src/math/matrix.birch", 320);
  #line 321 "src/math/matrix.birch"
  libbirch_line_(321);
  #line 321 "src/math/matrix.birch"
  return birch::String(birch::canonical(X, handler_), handler_);
}

#line 1 "src/math/quantile.birch"
#include <boost/math/distributions.hpp>
#line 14 "src/math/quantile.birch"
birch::type::Integer birch::quantile_binomial(const birch::type::Real& P, const birch::type::Integer& n, const birch::type::Real& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/math/quantile.birch"
  libbirch_function_("quantile_binomial", "src/math/quantile.birch", 14);
  #line 15 "src/math/quantile.birch"
  libbirch_line_(15);
  #line 15 "src/math/quantile.birch"
  libbirch_assert_(birch::type::Integer(0) <= n);
  #line 16 "src/math/quantile.birch"
  libbirch_line_(16);
  #line 16 "src/math/quantile.birch"
  libbirch_assert_(0.0 <= _u0961 && _u0961 <= 1.0);
  #line 17 "src/math/quantile.birch"
return boost::math::quantile(boost::math::binomial_distribution<>(n, _u0961), P);
  }

#line 31 "src/math/quantile.birch"
birch::type::Integer birch::quantile_negative_binomial(const birch::type::Real& P, const birch::type::Integer& k, const birch::type::Real& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "src/math/quantile.birch"
  libbirch_function_("quantile_negative_binomial", "src/math/quantile.birch", 31);
  #line 32 "src/math/quantile.birch"
  libbirch_line_(32);
  #line 32 "src/math/quantile.birch"
  libbirch_assert_(birch::type::Integer(0) < k);
  #line 33 "src/math/quantile.birch"
  libbirch_line_(33);
  #line 33 "src/math/quantile.birch"
  libbirch_assert_(0.0 <= _u0961 && _u0961 <= 1.0);
  #line 34 "src/math/quantile.birch"
return boost::math::quantile(boost::math::negative_binomial_distribution<>(k, _u0961), P);
  }

#line 47 "src/math/quantile.birch"
birch::type::Integer birch::quantile_poisson(const birch::type::Real& P, const birch::type::Real& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "src/math/quantile.birch"
  libbirch_function_("quantile_poisson", "src/math/quantile.birch", 47);
  #line 48 "src/math/quantile.birch"
  libbirch_line_(48);
  #line 48 "src/math/quantile.birch"
  libbirch_assert_(0.0 <= _u0955);
  #line 49 "src/math/quantile.birch"
return boost::math::quantile(boost::math::poisson_distribution<>(_u0955), P);
  }

#line 63 "src/math/quantile.birch"
birch::type::Integer birch::quantile_uniform_int(const birch::type::Real& P, const birch::type::Integer& l, const birch::type::Integer& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 63 "src/math/quantile.birch"
  libbirch_function_("quantile_uniform_int", "src/math/quantile.birch", 63);
  #line 64 "src/math/quantile.birch"
  libbirch_line_(64);
  #line 64 "src/math/quantile.birch"
  libbirch_assert_(l <= u);
  #line 65 "src/math/quantile.birch"
  libbirch_line_(65);
  #line 65 "src/math/quantile.birch"
  return l + birch::Integer(P * (u - l), handler_);
}

#line 76 "src/math/quantile.birch"
birch::type::Integer birch::quantile_categorical(const birch::type::Real& P, const libbirch::DefaultArray<birch::type::Real,1>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "src/math/quantile.birch"
  libbirch_function_("quantile_categorical", "src/math/quantile.birch", 76);
  #line 77 "src/math/quantile.birch"
  libbirch_line_(77);
  #line 77 "src/math/quantile.birch"
  auto i = birch::type::Integer(1);
  #line 78 "src/math/quantile.birch"
  libbirch_line_(78);
  #line 78 "src/math/quantile.birch"
  auto R = _u0961.get(libbirch::make_slice(birch::type::Integer(1) - 1));
  #line 79 "src/math/quantile.birch"
  libbirch_line_(79);
  #line 79 "src/math/quantile.birch"
  while (R < P && i < birch::length(_u0961, handler_)) {
    #line 80 "src/math/quantile.birch"
    libbirch_line_(80);
    #line 80 "src/math/quantile.birch"
    i = i + birch::type::Integer(1);
    #line 81 "src/math/quantile.birch"
    libbirch_line_(81);
    #line 81 "src/math/quantile.birch"
    R = R + _u0961.get(libbirch::make_slice(i - 1));
  }
  #line 83 "src/math/quantile.birch"
  libbirch_line_(83);
  #line 83 "src/math/quantile.birch"
  return i;
}

#line 95 "src/math/quantile.birch"
birch::type::Real birch::quantile_uniform(const birch::type::Real& P, const birch::type::Real& l, const birch::type::Real& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "src/math/quantile.birch"
  libbirch_function_("quantile_uniform", "src/math/quantile.birch", 95);
  #line 96 "src/math/quantile.birch"
  libbirch_line_(96);
  #line 96 "src/math/quantile.birch"
  libbirch_assert_(l <= u);
  #line 97 "src/math/quantile.birch"
  libbirch_line_(97);
  #line 97 "src/math/quantile.birch"
  return l + P * (u - l);
}

#line 108 "src/math/quantile.birch"
birch::type::Real birch::quantile_exponential(const birch::type::Real& P, const birch::type::Real& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 108 "src/math/quantile.birch"
  libbirch_function_("quantile_exponential", "src/math/quantile.birch", 108);
  #line 109 "src/math/quantile.birch"
  libbirch_line_(109);
  #line 109 "src/math/quantile.birch"
  libbirch_assert_(0.0 < _u0955);
  #line 110 "src/math/quantile.birch"
return boost::math::quantile(boost::math::exponential_distribution<>(_u0955), P);
  }

#line 124 "src/math/quantile.birch"
birch::type::Real birch::quantile_weibull(const birch::type::Real& P, const birch::type::Real& k, const birch::type::Real& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 124 "src/math/quantile.birch"
  libbirch_function_("quantile_weibull", "src/math/quantile.birch", 124);
  #line 125 "src/math/quantile.birch"
  libbirch_line_(125);
  #line 125 "src/math/quantile.birch"
  libbirch_assert_(0.0 < k);
  #line 126 "src/math/quantile.birch"
  libbirch_line_(126);
  #line 126 "src/math/quantile.birch"
  libbirch_assert_(0.0 < _u0955);
  #line 127 "src/math/quantile.birch"
return boost::math::quantile(boost::math::weibull_distribution<>(k, _u0955), P);
  }

#line 141 "src/math/quantile.birch"
birch::type::Real birch::quantile_gaussian(const birch::type::Real& P, const birch::type::Real& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 141 "src/math/quantile.birch"
  libbirch_function_("quantile_gaussian", "src/math/quantile.birch", 141);
  #line 142 "src/math/quantile.birch"
  libbirch_line_(142);
  #line 142 "src/math/quantile.birch"
  libbirch_assert_(0.0 < _u09632);
  #line 143 "src/math/quantile.birch"
return boost::math::quantile(boost::math::normal_distribution<>(_u0956, ::sqrt(_u09632)), P);
  }

#line 156 "src/math/quantile.birch"
birch::type::Real birch::quantile_student_t(const birch::type::Real& P, const birch::type::Real& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 156 "src/math/quantile.birch"
  libbirch_function_("quantile_student_t", "src/math/quantile.birch", 156);
  #line 157 "src/math/quantile.birch"
  libbirch_line_(157);
  #line 157 "src/math/quantile.birch"
  libbirch_assert_(0.0 < _u0957);
  #line 158 "src/math/quantile.birch"
return boost::math::quantile(boost::math::students_t_distribution<>(_u0957), P);
  }

#line 173 "src/math/quantile.birch"
birch::type::Real birch::quantile_student_t(const birch::type::Real& P, const birch::type::Real& _u0957, const birch::type::Real& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 173 "src/math/quantile.birch"
  libbirch_function_("quantile_student_t", "src/math/quantile.birch", 173);
  #line 174 "src/math/quantile.birch"
  libbirch_line_(174);
  #line 174 "src/math/quantile.birch"
  libbirch_assert_(0.0 < _u09632);
  #line 175 "src/math/quantile.birch"
  libbirch_line_(175);
  #line 175 "src/math/quantile.birch"
  return birch::quantile_student_t(P, _u0957, handler_) * birch::sqrt(_u09632, handler_) + _u0956;
}

#line 187 "src/math/quantile.birch"
birch::type::Real birch::quantile_beta(const birch::type::Real& P, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 187 "src/math/quantile.birch"
  libbirch_function_("quantile_beta", "src/math/quantile.birch", 187);
  #line 188 "src/math/quantile.birch"
  libbirch_line_(188);
  #line 188 "src/math/quantile.birch"
  libbirch_assert_(0.0 < _u0945);
  #line 189 "src/math/quantile.birch"
  libbirch_line_(189);
  #line 189 "src/math/quantile.birch"
  libbirch_assert_(0.0 < _u0946);
  #line 190 "src/math/quantile.birch"
return boost::math::quantile(boost::math::beta_distribution<>(_u0945, _u0946), P);
  }

#line 203 "src/math/quantile.birch"
birch::type::Real birch::quantile_chi_squared(const birch::type::Real& P, const birch::type::Real& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 203 "src/math/quantile.birch"
  libbirch_function_("quantile_chi_squared", "src/math/quantile.birch", 203);
  #line 204 "src/math/quantile.birch"
  libbirch_line_(204);
  #line 204 "src/math/quantile.birch"
  libbirch_assert_(0.0 < _u0957);
  #line 205 "src/math/quantile.birch"
return boost::math::quantile(boost::math::chi_squared_distribution<>(_u0957), P);
  }

#line 219 "src/math/quantile.birch"
birch::type::Real birch::quantile_gamma(const birch::type::Real& P, const birch::type::Real& k, const birch::type::Real& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 219 "src/math/quantile.birch"
  libbirch_function_("quantile_gamma", "src/math/quantile.birch", 219);
  #line 220 "src/math/quantile.birch"
  libbirch_line_(220);
  #line 220 "src/math/quantile.birch"
  libbirch_assert_(0.0 < k);
  #line 221 "src/math/quantile.birch"
  libbirch_line_(221);
  #line 221 "src/math/quantile.birch"
  libbirch_assert_(0.0 < _u0952);
  #line 222 "src/math/quantile.birch"
return boost::math::quantile(boost::math::gamma_distribution<>(k, _u0952), P);
  }

#line 236 "src/math/quantile.birch"
birch::type::Real birch::quantile_inverse_gamma(const birch::type::Real& P, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 236 "src/math/quantile.birch"
  libbirch_function_("quantile_inverse_gamma", "src/math/quantile.birch", 236);
  #line 237 "src/math/quantile.birch"
  libbirch_line_(237);
  #line 237 "src/math/quantile.birch"
  libbirch_assert_(0.0 < _u0945);
  #line 238 "src/math/quantile.birch"
  libbirch_line_(238);
  #line 238 "src/math/quantile.birch"
  libbirch_assert_(0.0 < _u0946);
  #line 239 "src/math/quantile.birch"
  libbirch_line_(239);
  #line 239 "src/math/quantile.birch"
  if (P == 0.0) {
    #line 240 "src/math/quantile.birch"
    libbirch_line_(240);
    #line 240 "src/math/quantile.birch"
    return 0.0;
  } else {
    #line 242 "src/math/quantile.birch"
return boost::math::quantile(boost::math::inverse_gamma_distribution<>(_u0945, _u0946), P);
      }
}

#line 259 "src/math/quantile.birch"
birch::type::Real birch::quantile_normal_inverse_gamma(const birch::type::Real& P, const birch::type::Real& _u0956, const birch::type::Real& a2, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 259 "src/math/quantile.birch"
  libbirch_function_("quantile_normal_inverse_gamma", "src/math/quantile.birch", 259);
  #line 261 "src/math/quantile.birch"
  libbirch_line_(261);
  #line 261 "src/math/quantile.birch"
  return birch::quantile_student_t(P, 2.0 * _u0945, _u0956, a2 * _u0946 / _u0945, handler_);
}

#line 273 "src/math/quantile.birch"
birch::type::Integer birch::quantile_gamma_poisson(const birch::type::Real& P, const birch::type::Real& k, const birch::type::Real& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 273 "src/math/quantile.birch"
  libbirch_function_("quantile_gamma_poisson", "src/math/quantile.birch", 273);
  #line 274 "src/math/quantile.birch"
  libbirch_line_(274);
  #line 274 "src/math/quantile.birch"
  libbirch_assert_(0.0 < k);
  #line 275 "src/math/quantile.birch"
  libbirch_line_(275);
  #line 275 "src/math/quantile.birch"
  libbirch_assert_(0.0 < _u0952);
  #line 276 "src/math/quantile.birch"
  libbirch_line_(276);
  #line 276 "src/math/quantile.birch"
  libbirch_assert_(k == birch::floor(k, handler_));
  #line 277 "src/math/quantile.birch"
  libbirch_line_(277);
  #line 277 "src/math/quantile.birch"
  return birch::quantile_negative_binomial(P, birch::Integer(k, handler_), 1.0 / (_u0952 + 1.0), handler_);
}

#line 289 "src/math/quantile.birch"
birch::type::Real birch::quantile_lomax(const birch::type::Real& P, const birch::type::Real& _u0955, const birch::type::Real& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 289 "src/math/quantile.birch"
  libbirch_function_("quantile_lomax", "src/math/quantile.birch", 289);
  #line 290 "src/math/quantile.birch"
  libbirch_line_(290);
  #line 290 "src/math/quantile.birch"
  libbirch_assert_(0.0 < _u0955);
  #line 291 "src/math/quantile.birch"
  libbirch_line_(291);
  #line 291 "src/math/quantile.birch"
  libbirch_assert_(0.0 < _u0945);
  #line 292 "src/math/quantile.birch"
return boost::math::quantile(boost::math::pareto_distribution<>(_u0955, _u0945), P) - _u0955;
  }

#line 308 "src/math/quantile.birch"
birch::type::Real birch::quantile_normal_inverse_gamma_gaussian(const birch::type::Real& P, const birch::type::Real& _u0956, const birch::type::Real& a2, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 308 "src/math/quantile.birch"
  libbirch_function_("quantile_normal_inverse_gamma_gaussian", "src/math/quantile.birch", 308);
  #line 310 "src/math/quantile.birch"
  libbirch_line_(310);
  #line 310 "src/math/quantile.birch"
  return birch::quantile_student_t(P, 2.0 * _u0945, _u0956, (_u0946 / _u0945) * (1.0 + a2), handler_);
}

#line 327 "src/math/quantile.birch"
birch::type::Real birch::quantile_linear_normal_inverse_gamma_gaussian(const birch::type::Real& P, const birch::type::Real& a, const birch::type::Real& _u0956, const birch::type::Real& a2, const birch::type::Real& c, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 327 "src/math/quantile.birch"
  libbirch_function_("quantile_linear_normal_inverse_gamma_gaussian", "src/math/quantile.birch", 327);
  #line 329 "src/math/quantile.birch"
  libbirch_line_(329);
  #line 329 "src/math/quantile.birch"
  return birch::quantile_student_t(P, 2.0 * _u0945, a * _u0956 + c, (_u0946 / _u0945) * (1.0 + a * a * a2), handler_);
}

#line 346 "src/math/quantile.birch"
birch::type::Real birch::quantile_linear_multivariate_normal_inverse_gamma_gaussian(const birch::type::Real& P, const libbirch::DefaultArray<birch::type::Real,1>& a, const libbirch::DefaultArray<birch::type::Real,1>& _u0957, const birch::type::LLT& _u0923, const birch::type::Real& c, const birch::type::Real& _u0945, const birch::type::Real& _u0947, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 346 "src/math/quantile.birch"
  libbirch_function_("quantile_linear_multivariate_normal_inverse_gamma_gaussian", "src/math/quantile.birch", 346);
  #line 348 "src/math/quantile.birch"
  libbirch_line_(348);
  #line 348 "src/math/quantile.birch"
  auto _u0956 = birch::solve(_u0923, _u0957, handler_);
  #line 349 "src/math/quantile.birch"
  libbirch_line_(349);
  #line 349 "src/math/quantile.birch"
  auto _u0946 = _u0947 - 0.5 * birch::dot(_u0956, _u0957, handler_);
  #line 350 "src/math/quantile.birch"
  libbirch_line_(350);
  #line 350 "src/math/quantile.birch"
  return birch::quantile_student_t(P, 2.0 * _u0945, birch::dot(a, _u0956, handler_) + c, (_u0946 / _u0945) * (1.0 + birch::dot(a, birch::solve(_u0923, a, handler_), handler_)), handler_);
}

#line 8 "src/math/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::resample_systematic(const libbirch::DefaultArray<birch::type::Real,1>& w, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 8 "src/math/resample.birch"
  libbirch_function_("resample_systematic", "src/math/resample.birch", 8);
  #line 9 "src/math/resample.birch"
  libbirch_line_(9);
  #line 9 "src/math/resample.birch"
  return birch::cumulative_offspring_to_ancestors_permute(birch::systematic_cumulative_offspring(birch::cumulative_weights(w, handler_), handler_), handler_);
}

#line 20 "src/math/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::resample_multinomial(const libbirch::DefaultArray<birch::type::Real,1>& w, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/math/resample.birch"
  libbirch_function_("resample_multinomial", "src/math/resample.birch", 20);
  #line 21 "src/math/resample.birch"
  libbirch_line_(21);
  #line 21 "src/math/resample.birch"
  return birch::offspring_to_ancestors_permute(birch::simulate_multinomial(birch::length(w, handler_), birch::norm_exp(w, handler_), handler_), handler_);
}

#line 34 "src/math/resample.birch"
libbirch::Tuple<libbirch::DefaultArray<birch::type::Integer,1>, birch::type::Integer> birch::conditional_resample_multinomial(const libbirch::DefaultArray<birch::type::Real,1>& w, const birch::type::Integer& b, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/math/resample.birch"
  libbirch_function_("conditional_resample_multinomial", "src/math/resample.birch", 34);
  #line 36 "src/math/resample.birch"
  libbirch_line_(36);
  #line 36 "src/math/resample.birch"
  auto N = birch::length(w, handler_);
  #line 37 "src/math/resample.birch"
  libbirch_line_(37);
  #line 37 "src/math/resample.birch"
  auto o = birch::simulate_multinomial(N - birch::type::Integer(1), birch::norm_exp(w, handler_), handler_);
  #line 38 "src/math/resample.birch"
  libbirch_line_(38);
  #line 38 "src/math/resample.birch"
  o.set(libbirch::make_slice(b - 1), o.get(libbirch::make_slice(b - 1)) + birch::type::Integer(1));
  #line 39 "src/math/resample.birch"
  libbirch_line_(39);
  #line 39 "src/math/resample.birch"
  auto a = birch::offspring_to_ancestors_permute(o, handler_);
  #line 40 "src/math/resample.birch"
  libbirch_line_(40);
  #line 40 "src/math/resample.birch"
  libbirch_assert_(a.get(libbirch::make_slice(b - 1)) == b);
  #line 41 "src/math/resample.birch"
  libbirch_line_(41);
  #line 41 "src/math/resample.birch"
  return libbirch::make_tuple(a, b);
}

#line 47 "src/math/resample.birch"
birch::type::Real birch::log_sum_exp(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "src/math/resample.birch"
  libbirch_function_("log_sum_exp", "src/math/resample.birch", 47);
  #line 48 "src/math/resample.birch"
  libbirch_line_(48);
  #line 48 "src/math/resample.birch"
  libbirch_assert_(birch::length(x, handler_) > birch::type::Integer(0));
  #line 49 "src/math/resample.birch"
  libbirch_line_(49);
  #line 49 "src/math/resample.birch"
  auto mx = birch::max(x, handler_);
  #line 50 "src/math/resample.birch"
  libbirch_line_(50);
  #line 50 "src/math/resample.birch"
  auto r = 0.0;
  #line 51 "src/math/resample.birch"
  libbirch_line_(51);
  #line 51 "src/math/resample.birch"
  for (auto n = birch::type::Integer(1); n <= birch::length(x, handler_); ++n) {
    #line 52 "src/math/resample.birch"
    libbirch_line_(52);
    #line 52 "src/math/resample.birch"
    r = r + birch::nan_exp(x.get(libbirch::make_slice(n - 1)) - mx, handler_);
  }
  #line 54 "src/math/resample.birch"
  libbirch_line_(54);
  #line 54 "src/math/resample.birch"
  return mx + birch::log(r, handler_);
}

#line 60 "src/math/resample.birch"
birch::type::Real birch::log_sum(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "src/math/resample.birch"
  libbirch_function_("log_sum", "src/math/resample.birch", 60);
  #line 61 "src/math/resample.birch"
  libbirch_line_(61);
  #line 61 "src/math/resample.birch"
  return birch::transform_reduce<birch::type::Real>(x, 0.0, std::function<birch::type::Real(birch::type::Real,birch::type::Real,const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_
)>([=](const birch::type::Real& x, const birch::type::Real& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr) {
    #line 62 "src/math/resample.birch"
    libbirch_line_(62);
    #line 62 "src/math/resample.birch"
    return x + y;
  }), std::function<birch::type::Real(birch::type::Real,const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_
)>([=](const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr) {
    #line 62 "src/math/resample.birch"
    libbirch_line_(62);
    #line 62 "src/math/resample.birch"
    return birch::log(x, handler_);
  }), handler_);
}

#line 68 "src/math/resample.birch"
birch::type::Real birch::nan_exp(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 68 "src/math/resample.birch"
  libbirch_function_("nan_exp", "src/math/resample.birch", 68);
  #line 69 "src/math/resample.birch"
  libbirch_line_(69);
  #line 69 "src/math/resample.birch"
  if (birch::isnan(x, handler_)) {
    #line 70 "src/math/resample.birch"
    libbirch_line_(70);
    #line 70 "src/math/resample.birch"
    return 0.0;
  } else {
    #line 72 "src/math/resample.birch"
    libbirch_line_(72);
    #line 72 "src/math/resample.birch"
    return birch::exp(x, handler_);
  }
}

#line 81 "src/math/resample.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::norm_exp(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "src/math/resample.birch"
  libbirch_function_("norm_exp", "src/math/resample.birch", 81);
  #line 82 "src/math/resample.birch"
  libbirch_line_(82);
  #line 82 "src/math/resample.birch"
  libbirch_assert_(birch::length(x, handler_) > birch::type::Integer(0));
  #line 83 "src/math/resample.birch"
  libbirch_line_(83);
  #line 83 "src/math/resample.birch"
  auto mx = birch::max(x, handler_);
  #line 84 "src/math/resample.birch"
  libbirch_line_(84);
  #line 84 "src/math/resample.birch"
  auto r = 0.0;
  #line 85 "src/math/resample.birch"
  libbirch_line_(85);
  #line 85 "src/math/resample.birch"
  for (auto n = birch::type::Integer(1); n <= birch::length(x, handler_); ++n) {
    #line 86 "src/math/resample.birch"
    libbirch_line_(86);
    #line 86 "src/math/resample.birch"
    r = r + birch::nan_exp(x.get(libbirch::make_slice(n - 1)) - mx, handler_);
  }
  #line 88 "src/math/resample.birch"
  libbirch_line_(88);
  #line 88 "src/math/resample.birch"
  auto W = mx + birch::log(r, handler_);
  #line 89 "src/math/resample.birch"
  libbirch_line_(89);
  #line 89 "src/math/resample.birch"
  return birch::transform<birch::type::Real>(x, std::function<birch::type::Real(birch::type::Real,const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_
)>([=](const birch::type::Real& w, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr) {
    #line 89 "src/math/resample.birch"
    libbirch_line_(89);
    #line 89 "src/math/resample.birch"
    return birch::nan_exp(w - W, handler_);
  }), handler_);
}

#line 95 "src/math/resample.birch"
birch::type::Integer birch::cumulative_ancestor(const libbirch::DefaultArray<birch::type::Real,1>& W, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "src/math/resample.birch"
  libbirch_function_("cumulative_ancestor", "src/math/resample.birch", 95);
  #line 96 "src/math/resample.birch"
  libbirch_line_(96);
  #line 96 "src/math/resample.birch"
  auto N = birch::length(W, handler_);
  #line 97 "src/math/resample.birch"
  libbirch_line_(97);
  #line 97 "src/math/resample.birch"
  libbirch_assert_(W.get(libbirch::make_slice(N - 1)) > 0.0);
  #line 98 "src/math/resample.birch"
  libbirch_line_(98);
  #line 98 "src/math/resample.birch"
  auto u = birch::simulate_uniform(0.0, W.get(libbirch::make_slice(N - 1)), handler_);
  #line 99 "src/math/resample.birch"
  libbirch_line_(99);
  #line 99 "src/math/resample.birch"
  auto n = birch::type::Integer(1);
  #line 100 "src/math/resample.birch"
  libbirch_line_(100);
  #line 100 "src/math/resample.birch"
  while (W.get(libbirch::make_slice(n - 1)) < u) {
    #line 101 "src/math/resample.birch"
    libbirch_line_(101);
    #line 101 "src/math/resample.birch"
    n = n + birch::type::Integer(1);
  }
  #line 103 "src/math/resample.birch"
  libbirch_line_(103);
  #line 103 "src/math/resample.birch"
  return n;
}

#line 110 "src/math/resample.birch"
birch::type::Integer birch::ancestor(const libbirch::DefaultArray<birch::type::Real,1>& w, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 110 "src/math/resample.birch"
  libbirch_function_("ancestor", "src/math/resample.birch", 110);
  #line 111 "src/math/resample.birch"
  libbirch_line_(111);
  #line 111 "src/math/resample.birch"
  auto N = birch::length(w, handler_);
  #line 112 "src/math/resample.birch"
  libbirch_line_(112);
  #line 112 "src/math/resample.birch"
  auto W = birch::cumulative_weights(w, handler_);
  #line 113 "src/math/resample.birch"
  libbirch_line_(113);
  #line 113 "src/math/resample.birch"
  if (W.get(libbirch::make_slice(N - 1)) > 0.0) {
    #line 114 "src/math/resample.birch"
    libbirch_line_(114);
    #line 114 "src/math/resample.birch"
    return birch::cumulative_ancestor(W, handler_);
  } else {
    #line 116 "src/math/resample.birch"
    libbirch_line_(116);
    #line 116 "src/math/resample.birch"
    return birch::type::Integer(0);
  }
}

#line 123 "src/math/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::systematic_cumulative_offspring(const libbirch::DefaultArray<birch::type::Real,1>& W, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 123 "src/math/resample.birch"
  libbirch_function_("systematic_cumulative_offspring", "src/math/resample.birch", 123);
  #line 124 "src/math/resample.birch"
  libbirch_line_(124);
  #line 124 "src/math/resample.birch"
  auto N = birch::length(W, handler_);
  #line 125 "src/math/resample.birch"
  libbirch_line_(125);
  #line 125 "src/math/resample.birch"
  libbirch::DefaultArray<birch::type::Integer,1> O(libbirch::make_shape(N));
  #line 127 "src/math/resample.birch"
  libbirch_line_(127);
  #line 127 "src/math/resample.birch"
  auto u = birch::simulate_uniform(0.0, 1.0, handler_);
  #line 128 "src/math/resample.birch"
  libbirch_line_(128);
  #line 128 "src/math/resample.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 129 "src/math/resample.birch"
    libbirch_line_(129);
    #line 129 "src/math/resample.birch"
    auto r = N * W.get(libbirch::make_slice(n - 1)) / W.get(libbirch::make_slice(N - 1));
    #line 130 "src/math/resample.birch"
    libbirch_line_(130);
    #line 130 "src/math/resample.birch"
    O.set(libbirch::make_slice(n - 1), birch::min(N, birch::Integer(birch::floor(r + u, handler_), handler_), handler_));
  }
  #line 132 "src/math/resample.birch"
  libbirch_line_(132);
  #line 132 "src/math/resample.birch"
  return O;
}

#line 138 "src/math/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::offspring_to_ancestors(const libbirch::DefaultArray<birch::type::Integer,1>& o, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 138 "src/math/resample.birch"
  libbirch_function_("offspring_to_ancestors", "src/math/resample.birch", 138);
  #line 139 "src/math/resample.birch"
  libbirch_line_(139);
  #line 139 "src/math/resample.birch"
  auto N = birch::length(o, handler_);
  #line 140 "src/math/resample.birch"
  libbirch_line_(140);
  #line 140 "src/math/resample.birch"
  auto i = birch::type::Integer(1);
  #line 141 "src/math/resample.birch"
  libbirch_line_(141);
  #line 141 "src/math/resample.birch"
  libbirch::DefaultArray<birch::type::Integer,1> a(libbirch::make_shape(N));
  #line 142 "src/math/resample.birch"
  libbirch_line_(142);
  #line 142 "src/math/resample.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 143 "src/math/resample.birch"
    libbirch_line_(143);
    #line 143 "src/math/resample.birch"
    for (auto j = birch::type::Integer(1); j <= o.get(libbirch::make_slice(n - 1)); ++j) {
      #line 144 "src/math/resample.birch"
      libbirch_line_(144);
      #line 144 "src/math/resample.birch"
      a.set(libbirch::make_slice(i - 1), n);
      #line 145 "src/math/resample.birch"
      libbirch_line_(145);
      #line 145 "src/math/resample.birch"
      i = i + birch::type::Integer(1);
    }
  }
  #line 148 "src/math/resample.birch"
  libbirch_line_(148);
  #line 148 "src/math/resample.birch"
  libbirch_assert_(i == N + birch::type::Integer(1));
  #line 149 "src/math/resample.birch"
  libbirch_line_(149);
  #line 149 "src/math/resample.birch"
  return a;
}

#line 155 "src/math/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::offspring_to_ancestors_permute(const libbirch::DefaultArray<birch::type::Integer,1>& o, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 155 "src/math/resample.birch"
  libbirch_function_("offspring_to_ancestors_permute", "src/math/resample.birch", 155);
  #line 156 "src/math/resample.birch"
  libbirch_line_(156);
  #line 156 "src/math/resample.birch"
  auto N = birch::length(o, handler_);
  #line 157 "src/math/resample.birch"
  libbirch_line_(157);
  #line 157 "src/math/resample.birch"
  auto i = birch::type::Integer(1);
  #line 158 "src/math/resample.birch"
  libbirch_line_(158);
  #line 158 "src/math/resample.birch"
  libbirch::DefaultArray<birch::type::Integer,1> a(libbirch::make_shape(N));
  #line 159 "src/math/resample.birch"
  libbirch_line_(159);
  #line 159 "src/math/resample.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 160 "src/math/resample.birch"
    libbirch_line_(160);
    #line 160 "src/math/resample.birch"
    for (auto j = birch::type::Integer(1); j <= o.get(libbirch::make_slice(n - 1)); ++j) {
      #line 161 "src/math/resample.birch"
      libbirch_line_(161);
      #line 161 "src/math/resample.birch"
      a.set(libbirch::make_slice(i - 1), n);
      #line 162 "src/math/resample.birch"
      libbirch_line_(162);
      #line 162 "src/math/resample.birch"
      i = i + birch::type::Integer(1);
    }
  }
  #line 165 "src/math/resample.birch"
  libbirch_line_(165);
  #line 165 "src/math/resample.birch"
  libbirch_assert_(i == N + birch::type::Integer(1));
  #line 168 "src/math/resample.birch"
  libbirch_line_(168);
  #line 168 "src/math/resample.birch"
  auto n = birch::type::Integer(1);
  #line 169 "src/math/resample.birch"
  libbirch_line_(169);
  #line 169 "src/math/resample.birch"
  while (n <= N) {
    #line 170 "src/math/resample.birch"
    libbirch_line_(170);
    #line 170 "src/math/resample.birch"
    auto c = a.get(libbirch::make_slice(n - 1));
    #line 171 "src/math/resample.birch"
    libbirch_line_(171);
    #line 171 "src/math/resample.birch"
    if (c != n && a.get(libbirch::make_slice(c - 1)) != c) {
      #line 172 "src/math/resample.birch"
      libbirch_line_(172);
      #line 172 "src/math/resample.birch"
      a.set(libbirch::make_slice(n - 1), a.get(libbirch::make_slice(c - 1)));
      #line 173 "src/math/resample.birch"
      libbirch_line_(173);
      #line 173 "src/math/resample.birch"
      a.set(libbirch::make_slice(c - 1), c);
    } else {
      #line 175 "src/math/resample.birch"
      libbirch_line_(175);
      #line 175 "src/math/resample.birch"
      n = n + birch::type::Integer(1);
    }
  }
  #line 179 "src/math/resample.birch"
  libbirch_line_(179);
  #line 179 "src/math/resample.birch"
  return a;
}

#line 185 "src/math/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::cumulative_offspring_to_ancestors(const libbirch::DefaultArray<birch::type::Integer,1>& O, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 185 "src/math/resample.birch"
  libbirch_function_("cumulative_offspring_to_ancestors", "src/math/resample.birch", 185);
  #line 186 "src/math/resample.birch"
  libbirch_line_(186);
  #line 186 "src/math/resample.birch"
  auto N = birch::length(O, handler_);
  #line 187 "src/math/resample.birch"
  libbirch_line_(187);
  #line 187 "src/math/resample.birch"
  libbirch::DefaultArray<birch::type::Integer,1> a(libbirch::make_shape(N));
  #line 188 "src/math/resample.birch"
  libbirch_line_(188);
  #line 188 "src/math/resample.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 189 "src/math/resample.birch"
    libbirch_line_(189);
    #line 189 "src/math/resample.birch"
    birch::type::Integer start;
    #line 190 "src/math/resample.birch"
    libbirch_line_(190);
    #line 190 "src/math/resample.birch"
    if (n == birch::type::Integer(1)) {
      #line 191 "src/math/resample.birch"
      libbirch_line_(191);
      #line 191 "src/math/resample.birch"
      start = birch::type::Integer(0);
    } else {
      #line 193 "src/math/resample.birch"
      libbirch_line_(193);
      #line 193 "src/math/resample.birch"
      start = O.get(libbirch::make_slice(n - birch::type::Integer(1) - 1));
    }
    #line 195 "src/math/resample.birch"
    libbirch_line_(195);
    #line 195 "src/math/resample.birch"
    auto o = O.get(libbirch::make_slice(n - 1)) - start;
    #line 196 "src/math/resample.birch"
    libbirch_line_(196);
    #line 196 "src/math/resample.birch"
    for (auto j = birch::type::Integer(1); j <= o; ++j) {
      #line 197 "src/math/resample.birch"
      libbirch_line_(197);
      #line 197 "src/math/resample.birch"
      a.set(libbirch::make_slice(start + j - 1), n);
    }
  }
  #line 200 "src/math/resample.birch"
  libbirch_line_(200);
  #line 200 "src/math/resample.birch"
  return a;
}

#line 207 "src/math/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::cumulative_offspring_to_ancestors_permute(const libbirch::DefaultArray<birch::type::Integer,1>& O, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 207 "src/math/resample.birch"
  libbirch_function_("cumulative_offspring_to_ancestors_permute", "src/math/resample.birch", 207);
  #line 209 "src/math/resample.birch"
  libbirch_line_(209);
  #line 209 "src/math/resample.birch"
  libbirch::DefaultArray<birch::type::Integer,1> a(libbirch::make_shape(O.get(libbirch::make_slice(birch::length(O, handler_) - 1))));
  #line 210 "src/math/resample.birch"
  libbirch_line_(210);
  #line 210 "src/math/resample.birch"
  auto N = birch::length(a, handler_);
  #line 211 "src/math/resample.birch"
  libbirch_line_(211);
  #line 211 "src/math/resample.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 212 "src/math/resample.birch"
    libbirch_line_(212);
    #line 212 "src/math/resample.birch"
    auto start = birch::type::Integer(0);
    #line 213 "src/math/resample.birch"
    libbirch_line_(213);
    #line 213 "src/math/resample.birch"
    if (n > birch::type::Integer(1)) {
      #line 214 "src/math/resample.birch"
      libbirch_line_(214);
      #line 214 "src/math/resample.birch"
      start = O.get(libbirch::make_slice(n - birch::type::Integer(1) - 1));
    }
    #line 216 "src/math/resample.birch"
    libbirch_line_(216);
    #line 216 "src/math/resample.birch"
    auto o = O.get(libbirch::make_slice(n - 1)) - start;
    #line 217 "src/math/resample.birch"
    libbirch_line_(217);
    #line 217 "src/math/resample.birch"
    for (auto j = birch::type::Integer(1); j <= o; ++j) {
      #line 218 "src/math/resample.birch"
      libbirch_line_(218);
      #line 218 "src/math/resample.birch"
      a.set(libbirch::make_slice(start + j - 1), n);
    }
  }
  #line 223 "src/math/resample.birch"
  libbirch_line_(223);
  #line 223 "src/math/resample.birch"
  auto n = birch::type::Integer(1);
  #line 224 "src/math/resample.birch"
  libbirch_line_(224);
  #line 224 "src/math/resample.birch"
  while (n <= N) {
    #line 225 "src/math/resample.birch"
    libbirch_line_(225);
    #line 225 "src/math/resample.birch"
    auto c = a.get(libbirch::make_slice(n - 1));
    #line 226 "src/math/resample.birch"
    libbirch_line_(226);
    #line 226 "src/math/resample.birch"
    if (c != n && a.get(libbirch::make_slice(c - 1)) != c) {
      #line 227 "src/math/resample.birch"
      libbirch_line_(227);
      #line 227 "src/math/resample.birch"
      a.set(libbirch::make_slice(n - 1), a.get(libbirch::make_slice(c - 1)));
      #line 228 "src/math/resample.birch"
      libbirch_line_(228);
      #line 228 "src/math/resample.birch"
      a.set(libbirch::make_slice(c - 1), c);
    } else {
      #line 230 "src/math/resample.birch"
      libbirch_line_(230);
      #line 230 "src/math/resample.birch"
      n = n + birch::type::Integer(1);
    }
  }
  #line 234 "src/math/resample.birch"
  libbirch_line_(234);
  #line 234 "src/math/resample.birch"
  return a;
}

#line 240 "src/math/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::cumulative_offspring_to_offspring(const libbirch::DefaultArray<birch::type::Integer,1>& O, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 240 "src/math/resample.birch"
  libbirch_function_("cumulative_offspring_to_offspring", "src/math/resample.birch", 240);
  #line 241 "src/math/resample.birch"
  libbirch_line_(241);
  #line 241 "src/math/resample.birch"
  return birch::adjacent_difference<birch::type::Integer>(O, std::function<birch::type::Integer(birch::type::Integer,birch::type::Integer,const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_
)>([=](const birch::type::Integer& x, const birch::type::Integer& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr) {
    #line 242 "src/math/resample.birch"
    libbirch_line_(242);
    #line 242 "src/math/resample.birch"
    return x - y;
  }), handler_);
}

#line 249 "src/math/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::permute_ancestors(const libbirch::DefaultArray<birch::type::Integer,1>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 249 "src/math/resample.birch"
  libbirch_function_("permute_ancestors", "src/math/resample.birch", 249);
  #line 250 "src/math/resample.birch"
  libbirch_line_(250);
  #line 250 "src/math/resample.birch"
  auto N = birch::length(a, handler_);
  #line 251 "src/math/resample.birch"
  libbirch_line_(251);
  #line 251 "src/math/resample.birch"
  auto b = a;
  #line 252 "src/math/resample.birch"
  libbirch_line_(252);
  #line 252 "src/math/resample.birch"
  auto n = birch::type::Integer(1);
  #line 253 "src/math/resample.birch"
  libbirch_line_(253);
  #line 253 "src/math/resample.birch"
  while (n <= N) {
    #line 254 "src/math/resample.birch"
    libbirch_line_(254);
    #line 254 "src/math/resample.birch"
    auto c = b.get(libbirch::make_slice(n - 1));
    #line 255 "src/math/resample.birch"
    libbirch_line_(255);
    #line 255 "src/math/resample.birch"
    if (c != n && b.get(libbirch::make_slice(c - 1)) != c) {
      #line 256 "src/math/resample.birch"
      libbirch_line_(256);
      #line 256 "src/math/resample.birch"
      b.set(libbirch::make_slice(n - 1), b.get(libbirch::make_slice(c - 1)));
      #line 257 "src/math/resample.birch"
      libbirch_line_(257);
      #line 257 "src/math/resample.birch"
      b.set(libbirch::make_slice(c - 1), c);
    } else {
      #line 259 "src/math/resample.birch"
      libbirch_line_(259);
      #line 259 "src/math/resample.birch"
      n = n + birch::type::Integer(1);
    }
  }
  #line 262 "src/math/resample.birch"
  libbirch_line_(262);
  #line 262 "src/math/resample.birch"
  return b;
}

#line 268 "src/math/resample.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::cumulative_weights(const libbirch::DefaultArray<birch::type::Real,1>& w, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 268 "src/math/resample.birch"
  libbirch_function_("cumulative_weights", "src/math/resample.birch", 268);
  #line 269 "src/math/resample.birch"
  libbirch_line_(269);
  #line 269 "src/math/resample.birch"
  auto N = birch::length(w, handler_);
  #line 270 "src/math/resample.birch"
  libbirch_line_(270);
  #line 270 "src/math/resample.birch"
  libbirch::DefaultArray<birch::type::Real,1> W(libbirch::make_shape(N));
  #line 272 "src/math/resample.birch"
  libbirch_line_(272);
  #line 272 "src/math/resample.birch"
  if (N > birch::type::Integer(0)) {
    #line 273 "src/math/resample.birch"
    libbirch_line_(273);
    #line 273 "src/math/resample.birch"
    auto mx = birch::max(w, handler_);
    #line 274 "src/math/resample.birch"
    libbirch_line_(274);
    #line 274 "src/math/resample.birch"
    W.set(libbirch::make_slice(birch::type::Integer(1) - 1), birch::nan_exp(w.get(libbirch::make_slice(birch::type::Integer(1) - 1)) - mx, handler_));
    #line 275 "src/math/resample.birch"
    libbirch_line_(275);
    #line 275 "src/math/resample.birch"
    for (auto n = birch::type::Integer(2); n <= N; ++n) {
      #line 276 "src/math/resample.birch"
      libbirch_line_(276);
      #line 276 "src/math/resample.birch"
      W.set(libbirch::make_slice(n - 1), W.get(libbirch::make_slice(n - birch::type::Integer(1) - 1)) + birch::nan_exp(w.get(libbirch::make_slice(n - 1)) - mx, handler_));
    }
  }
  #line 279 "src/math/resample.birch"
  libbirch_line_(279);
  #line 279 "src/math/resample.birch"
  return W;
}

#line 289 "src/math/resample.birch"
libbirch::Tuple<birch::type::Real, birch::type::Real> birch::resample_reduce(const libbirch::DefaultArray<birch::type::Real,1>& w, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 289 "src/math/resample.birch"
  libbirch_function_("resample_reduce", "src/math/resample.birch", 289);
  #line 290 "src/math/resample.birch"
  libbirch_line_(290);
  #line 290 "src/math/resample.birch"
  if (birch::length(w, handler_) == birch::type::Integer(0)) {
    #line 291 "src/math/resample.birch"
    libbirch_line_(291);
    #line 291 "src/math/resample.birch"
    return libbirch::make_tuple(0.0, 0.0);
  } else {
    #line 293 "src/math/resample.birch"
    libbirch_line_(293);
    #line 293 "src/math/resample.birch"
    auto N = birch::length(w, handler_);
    #line 294 "src/math/resample.birch"
    libbirch_line_(294);
    #line 294 "src/math/resample.birch"
    auto W = 0.0;
    #line 295 "src/math/resample.birch"
    libbirch_line_(295);
    #line 295 "src/math/resample.birch"
    auto W2 = 0.0;
    #line 296 "src/math/resample.birch"
    libbirch_line_(296);
    #line 296 "src/math/resample.birch"
    auto mx = birch::max(w, handler_);
    #line 297 "src/math/resample.birch"
    libbirch_line_(297);
    #line 297 "src/math/resample.birch"
    for (auto n = birch::type::Integer(1); n <= N; ++n) {
      #line 298 "src/math/resample.birch"
      libbirch_line_(298);
      #line 298 "src/math/resample.birch"
      auto v = birch::nan_exp(w.get(libbirch::make_slice(n - 1)) - mx, handler_);
      #line 299 "src/math/resample.birch"
      libbirch_line_(299);
      #line 299 "src/math/resample.birch"
      W = W + v;
      #line 300 "src/math/resample.birch"
      libbirch_line_(300);
      #line 300 "src/math/resample.birch"
      W2 = W2 + v * v;
    }
    #line 302 "src/math/resample.birch"
    libbirch_line_(302);
    #line 302 "src/math/resample.birch"
    return libbirch::make_tuple(W * W / W2, birch::log(W, handler_) + mx);
  }
}

#line 4 "src/math/scalar.birch"
birch::type::Integer birch::length(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 4 "src/math/scalar.birch"
  libbirch_function_("length", "src/math/scalar.birch", 4);
  #line 5 "src/math/scalar.birch"
  libbirch_line_(5);
  #line 5 "src/math/scalar.birch"
  return birch::type::Integer(1);
}

#line 11 "src/math/scalar.birch"
birch::type::Integer birch::length(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/math/scalar.birch"
  libbirch_function_("length", "src/math/scalar.birch", 11);
  #line 12 "src/math/scalar.birch"
  libbirch_line_(12);
  #line 12 "src/math/scalar.birch"
  return birch::type::Integer(1);
}

#line 18 "src/math/scalar.birch"
birch::type::Integer birch::length(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/math/scalar.birch"
  libbirch_function_("length", "src/math/scalar.birch", 18);
  #line 19 "src/math/scalar.birch"
  libbirch_line_(19);
  #line 19 "src/math/scalar.birch"
  return birch::type::Integer(1);
}

#line 25 "src/math/scalar.birch"
birch::type::Integer birch::rows(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/math/scalar.birch"
  libbirch_function_("rows", "src/math/scalar.birch", 25);
  #line 26 "src/math/scalar.birch"
  libbirch_line_(26);
  #line 26 "src/math/scalar.birch"
  return birch::type::Integer(1);
}

#line 32 "src/math/scalar.birch"
birch::type::Integer birch::rows(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/math/scalar.birch"
  libbirch_function_("rows", "src/math/scalar.birch", 32);
  #line 33 "src/math/scalar.birch"
  libbirch_line_(33);
  #line 33 "src/math/scalar.birch"
  return birch::type::Integer(1);
}

#line 39 "src/math/scalar.birch"
birch::type::Integer birch::rows(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/math/scalar.birch"
  libbirch_function_("rows", "src/math/scalar.birch", 39);
  #line 40 "src/math/scalar.birch"
  libbirch_line_(40);
  #line 40 "src/math/scalar.birch"
  return birch::type::Integer(1);
}

#line 46 "src/math/scalar.birch"
birch::type::Integer birch::columns(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/math/scalar.birch"
  libbirch_function_("columns", "src/math/scalar.birch", 46);
  #line 47 "src/math/scalar.birch"
  libbirch_line_(47);
  #line 47 "src/math/scalar.birch"
  return birch::type::Integer(1);
}

#line 53 "src/math/scalar.birch"
birch::type::Integer birch::columns(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "src/math/scalar.birch"
  libbirch_function_("columns", "src/math/scalar.birch", 53);
  #line 54 "src/math/scalar.birch"
  libbirch_line_(54);
  #line 54 "src/math/scalar.birch"
  return birch::type::Integer(1);
}

#line 60 "src/math/scalar.birch"
birch::type::Integer birch::columns(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "src/math/scalar.birch"
  libbirch_function_("columns", "src/math/scalar.birch", 60);
  #line 61 "src/math/scalar.birch"
  libbirch_line_(61);
  #line 61 "src/math/scalar.birch"
  return birch::type::Integer(1);
}

#line 67 "src/math/scalar.birch"
birch::type::Real birch::transpose(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 67 "src/math/scalar.birch"
  libbirch_function_("transpose", "src/math/scalar.birch", 67);
  #line 68 "src/math/scalar.birch"
  libbirch_line_(68);
  #line 68 "src/math/scalar.birch"
  return x;
}

#line 74 "src/math/scalar.birch"
birch::type::Integer birch::transpose(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 74 "src/math/scalar.birch"
  libbirch_function_("transpose", "src/math/scalar.birch", 74);
  #line 75 "src/math/scalar.birch"
  libbirch_line_(75);
  #line 75 "src/math/scalar.birch"
  return x;
}

#line 81 "src/math/scalar.birch"
birch::type::Boolean birch::transpose(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "src/math/scalar.birch"
  libbirch_function_("transpose", "src/math/scalar.birch", 81);
  #line 82 "src/math/scalar.birch"
  libbirch_line_(82);
  #line 82 "src/math/scalar.birch"
  return x;
}

#line 1 "src/math/simulate.birch"
#include <random>

static auto make_rngs() {
  std::vector<std::mt19937_64,libbirch::Allocator<std::mt19937_64>> rngs(
      libbirch::get_max_threads());
  std::random_device rd;
  for (unsigned i = 0; i < rngs.size(); ++i) {
    rngs[i].seed(rd());
  }
  return rngs;
}

static auto& get_rng() {
  static std::vector<std::mt19937_64,libbirch::Allocator<std::mt19937_64>> rngs(
      make_rngs());
  return rngs[libbirch::get_thread_num()];
}
#line 26 "src/math/simulate.birch"
void birch::seed(const birch::type::Integer& s, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/math/simulate.birch"
  libbirch_function_("seed", "src/math/simulate.birch", 26);
  #line 27 "src/math/simulate.birch"
#pragma omp parallel num_threads(libbirch::get_max_threads())
  {
    get_rng().seed(s + libbirch::get_thread_num());
  }
  }

#line 38 "src/math/simulate.birch"
void birch::seed(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "src/math/simulate.birch"
  libbirch_function_("seed", "src/math/simulate.birch", 38);
  #line 39 "src/math/simulate.birch"
std::random_device rd;
  #pragma omp parallel num_threads(libbirch::get_max_threads())
  {
    #pragma omp critical
    get_rng().seed(rd());
  }
  }

#line 54 "src/math/simulate.birch"
birch::type::Boolean birch::simulate_bernoulli(const birch::type::Real& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "src/math/simulate.birch"
  libbirch_function_("simulate_bernoulli", "src/math/simulate.birch", 54);
  #line 55 "src/math/simulate.birch"
  libbirch_line_(55);
  #line 55 "src/math/simulate.birch"
  libbirch_assert_(0.0 <= _u0961 && _u0961 <= 1.0);
  #line 56 "src/math/simulate.birch"
return std::bernoulli_distribution(_u0961)(get_rng());
  }

#line 66 "src/math/simulate.birch"
birch::type::Integer birch::simulate_delta(const birch::type::Integer& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "src/math/simulate.birch"
  libbirch_function_("simulate_delta", "src/math/simulate.birch", 66);
  #line 67 "src/math/simulate.birch"
  libbirch_line_(67);
  #line 67 "src/math/simulate.birch"
  return _u0956;
}

#line 76 "src/math/simulate.birch"
birch::type::Integer birch::simulate_binomial(const birch::type::Integer& n, const birch::type::Real& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "src/math/simulate.birch"
  libbirch_function_("simulate_binomial", "src/math/simulate.birch", 76);
  #line 77 "src/math/simulate.birch"
  libbirch_line_(77);
  #line 77 "src/math/simulate.birch"
  libbirch_assert_(birch::type::Integer(0) <= n);
  #line 78 "src/math/simulate.birch"
  libbirch_line_(78);
  #line 78 "src/math/simulate.birch"
  libbirch_assert_(0.0 <= _u0961 && _u0961 <= 1.0);
  #line 79 "src/math/simulate.birch"
return std::binomial_distribution<birch::type::Integer>(n, _u0961)(get_rng());
  }

#line 92 "src/math/simulate.birch"
birch::type::Integer birch::simulate_negative_binomial(const birch::type::Integer& k, const birch::type::Real& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 92 "src/math/simulate.birch"
  libbirch_function_("simulate_negative_binomial", "src/math/simulate.birch", 92);
  #line 93 "src/math/simulate.birch"
  libbirch_line_(93);
  #line 93 "src/math/simulate.birch"
  libbirch_assert_(birch::type::Integer(0) < k);
  #line 94 "src/math/simulate.birch"
  libbirch_line_(94);
  #line 94 "src/math/simulate.birch"
  libbirch_assert_(0.0 <= _u0961 && _u0961 <= 1.0);
  #line 95 "src/math/simulate.birch"
return std::negative_binomial_distribution<birch::type::Integer>(k, _u0961)(get_rng());
  }

#line 105 "src/math/simulate.birch"
birch::type::Integer birch::simulate_poisson(const birch::type::Real& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 105 "src/math/simulate.birch"
  libbirch_function_("simulate_poisson", "src/math/simulate.birch", 105);
  #line 106 "src/math/simulate.birch"
  libbirch_line_(106);
  #line 106 "src/math/simulate.birch"
  libbirch_assert_(0.0 <= _u0955);
  #line 107 "src/math/simulate.birch"
  libbirch_line_(107);
  #line 107 "src/math/simulate.birch"
  if (_u0955 > 0.0) {
    #line 108 "src/math/simulate.birch"
return std::poisson_distribution<birch::type::Integer>(_u0955)(get_rng());
      } else {
    #line 112 "src/math/simulate.birch"
    libbirch_line_(112);
    #line 112 "src/math/simulate.birch"
    return birch::type::Integer(0);
  }
}

#line 121 "src/math/simulate.birch"
birch::type::Integer birch::simulate_categorical(const libbirch::DefaultArray<birch::type::Real,1>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 121 "src/math/simulate.birch"
  libbirch_function_("simulate_categorical", "src/math/simulate.birch", 121);
  #line 122 "src/math/simulate.birch"
  libbirch_line_(122);
  #line 122 "src/math/simulate.birch"
  return birch::simulate_categorical(_u0961, 1.0, handler_);
}

#line 131 "src/math/simulate.birch"
birch::type::Integer birch::simulate_categorical(const libbirch::DefaultArray<birch::type::Real,1>& _u0961, const birch::type::Real& Z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 131 "src/math/simulate.birch"
  libbirch_function_("simulate_categorical", "src/math/simulate.birch", 131);
  #line 132 "src/math/simulate.birch"
  libbirch_line_(132);
  #line 132 "src/math/simulate.birch"
  libbirch_assert_(birch::length(_u0961, handler_) > birch::type::Integer(0));
  #line 133 "src/math/simulate.birch"
  libbirch_line_(133);
  #line 133 "src/math/simulate.birch"
  libbirch_assert_(birch::abs(birch::sum(_u0961, handler_) - Z, handler_) < 1.0e-6);
  #line 135 "src/math/simulate.birch"
  libbirch_line_(135);
  #line 135 "src/math/simulate.birch"
  birch::type::Real u = birch::simulate_uniform(0.0, Z, handler_);
  #line 136 "src/math/simulate.birch"
  libbirch_line_(136);
  #line 136 "src/math/simulate.birch"
  birch::type::Integer x = birch::type::Integer(1);
  #line 137 "src/math/simulate.birch"
  libbirch_line_(137);
  #line 137 "src/math/simulate.birch"
  birch::type::Real P = _u0961.get(libbirch::make_slice(birch::type::Integer(1) - 1));
  #line 138 "src/math/simulate.birch"
  libbirch_line_(138);
  #line 138 "src/math/simulate.birch"
  while (P < u) {
    #line 139 "src/math/simulate.birch"
    libbirch_line_(139);
    #line 139 "src/math/simulate.birch"
    libbirch_assert_(x <= birch::length(_u0961, handler_));
    #line 140 "src/math/simulate.birch"
    libbirch_line_(140);
    #line 140 "src/math/simulate.birch"
    x = x + birch::type::Integer(1);
    #line 141 "src/math/simulate.birch"
    libbirch_line_(141);
    #line 141 "src/math/simulate.birch"
    libbirch_assert_(0.0 <= _u0961.get(libbirch::make_slice(x - 1)));
    #line 142 "src/math/simulate.birch"
    libbirch_line_(142);
    #line 142 "src/math/simulate.birch"
    P = P + _u0961.get(libbirch::make_slice(x - 1));
    #line 143 "src/math/simulate.birch"
    libbirch_line_(143);
    #line 143 "src/math/simulate.birch"
    libbirch_assert_(P < Z + 1.0e-6);
  }
  #line 145 "src/math/simulate.birch"
  libbirch_line_(145);
  #line 145 "src/math/simulate.birch"
  return x;
}

#line 160 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::simulate_multinomial(const birch::type::Integer& n, const libbirch::DefaultArray<birch::type::Real,1>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 160 "src/math/simulate.birch"
  libbirch_function_("simulate_multinomial", "src/math/simulate.birch", 160);
  #line 161 "src/math/simulate.birch"
  libbirch_line_(161);
  #line 161 "src/math/simulate.birch"
  return birch::simulate_multinomial(n, _u0961, 1.0, handler_);
}

#line 172 "src/math/simulate.birch"
birch::type::Real birch::simulate_inverse_gamma_gamma(const birch::type::Real& k, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 172 "src/math/simulate.birch"
  libbirch_function_("simulate_inverse_gamma_gamma", "src/math/simulate.birch", 172);
  #line 173 "src/math/simulate.birch"
  libbirch_line_(173);
  #line 173 "src/math/simulate.birch"
  return birch::simulate_gamma(k, birch::simulate_inverse_gamma(_u0945, _u0946, handler_), handler_);
}

#line 189 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::simulate_multinomial(const birch::type::Integer& n, const libbirch::DefaultArray<birch::type::Real,1>& _u0961, const birch::type::Real& Z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 189 "src/math/simulate.birch"
  libbirch_function_("simulate_multinomial", "src/math/simulate.birch", 189);
  #line 190 "src/math/simulate.birch"
  libbirch_line_(190);
  #line 190 "src/math/simulate.birch"
  libbirch_assert_(birch::length(_u0961, handler_) > birch::type::Integer(0));
  #line 191 "src/math/simulate.birch"
  libbirch_line_(191);
  #line 191 "src/math/simulate.birch"
  libbirch_assert_(birch::abs(birch::sum(_u0961, handler_) - Z, handler_) < 1.0e-6);
  #line 193 "src/math/simulate.birch"
  libbirch_line_(193);
  #line 193 "src/math/simulate.birch"
  birch::type::Integer D = birch::length(_u0961, handler_);
  #line 194 "src/math/simulate.birch"
  libbirch_line_(194);
  #line 194 "src/math/simulate.birch"
  birch::type::Real R = _u0961.get(libbirch::make_slice(D - 1));
  #line 195 "src/math/simulate.birch"
  libbirch_line_(195);
  #line 195 "src/math/simulate.birch"
  birch::type::Real lnMax = 0.0;
  #line 196 "src/math/simulate.birch"
  libbirch_line_(196);
  #line 196 "src/math/simulate.birch"
  birch::type::Integer j = D;
  #line 197 "src/math/simulate.birch"
  libbirch_line_(197);
  #line 197 "src/math/simulate.birch"
  birch::type::Integer i = n;
  #line 198 "src/math/simulate.birch"
  libbirch_line_(198);
  #line 198 "src/math/simulate.birch"
  birch::type::Real u;
  #line 199 "src/math/simulate.birch"
  libbirch_line_(199);
  #line 199 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Integer,1> x = birch::vector(birch::type::Integer(0), D, handler_);
  #line 201 "src/math/simulate.birch"
  libbirch_line_(201);
  #line 201 "src/math/simulate.birch"
  while (i > birch::type::Integer(0)) {
    #line 202 "src/math/simulate.birch"
    libbirch_line_(202);
    #line 202 "src/math/simulate.birch"
    u = birch::simulate_uniform(0.0, 1.0, handler_);
    #line 203 "src/math/simulate.birch"
    libbirch_line_(203);
    #line 203 "src/math/simulate.birch"
    lnMax = lnMax + birch::log(u, handler_) / i;
    #line 204 "src/math/simulate.birch"
    libbirch_line_(204);
    #line 204 "src/math/simulate.birch"
    u = Z * birch::exp(lnMax, handler_);
    #line 205 "src/math/simulate.birch"
    libbirch_line_(205);
    #line 205 "src/math/simulate.birch"
    while (u < Z - R) {
      #line 206 "src/math/simulate.birch"
      libbirch_line_(206);
      #line 206 "src/math/simulate.birch"
      j = j - birch::type::Integer(1);
      #line 207 "src/math/simulate.birch"
      libbirch_line_(207);
      #line 207 "src/math/simulate.birch"
      R = R + _u0961.get(libbirch::make_slice(j - 1));
    }
    #line 209 "src/math/simulate.birch"
    libbirch_line_(209);
    #line 209 "src/math/simulate.birch"
    x.set(libbirch::make_slice(j - 1), x.get(libbirch::make_slice(j - 1)) + birch::type::Integer(1));
    #line 210 "src/math/simulate.birch"
    libbirch_line_(210);
    #line 210 "src/math/simulate.birch"
    i = i - birch::type::Integer(1);
  }
  #line 212 "src/math/simulate.birch"
  libbirch_line_(212);
  #line 212 "src/math/simulate.birch"
  while (j > birch::type::Integer(1)) {
    #line 213 "src/math/simulate.birch"
    libbirch_line_(213);
    #line 213 "src/math/simulate.birch"
    j = j - birch::type::Integer(1);
    #line 214 "src/math/simulate.birch"
    libbirch_line_(214);
    #line 214 "src/math/simulate.birch"
    x.set(libbirch::make_slice(j - 1), birch::type::Integer(0));
  }
  #line 216 "src/math/simulate.birch"
  libbirch_line_(216);
  #line 216 "src/math/simulate.birch"
  return x;
}

#line 224 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_dirichlet(const libbirch::DefaultArray<birch::type::Real,1>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 224 "src/math/simulate.birch"
  libbirch_function_("simulate_dirichlet", "src/math/simulate.birch", 224);
  #line 225 "src/math/simulate.birch"
  libbirch_line_(225);
  #line 225 "src/math/simulate.birch"
  birch::type::Integer D = birch::length(_u0945, handler_);
  #line 226 "src/math/simulate.birch"
  libbirch_line_(226);
  #line 226 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,1> x(libbirch::make_shape(D));
  #line 227 "src/math/simulate.birch"
  libbirch_line_(227);
  #line 227 "src/math/simulate.birch"
  birch::type::Real z = 0.0;
  #line 229 "src/math/simulate.birch"
  libbirch_line_(229);
  #line 229 "src/math/simulate.birch"
  for (auto i = birch::type::Integer(1); i <= D; ++i) {
    #line 230 "src/math/simulate.birch"
    libbirch_line_(230);
    #line 230 "src/math/simulate.birch"
    x.set(libbirch::make_slice(i - 1), birch::simulate_gamma(_u0945.get(libbirch::make_slice(i - 1)), 1.0, handler_));
    #line 231 "src/math/simulate.birch"
    libbirch_line_(231);
    #line 231 "src/math/simulate.birch"
    z = z + x.get(libbirch::make_slice(i - 1));
  }
  #line 233 "src/math/simulate.birch"
  libbirch_line_(233);
  #line 233 "src/math/simulate.birch"
  z = 1.0 / z;
  #line 234 "src/math/simulate.birch"
  libbirch_line_(234);
  #line 234 "src/math/simulate.birch"
  for (auto i = birch::type::Integer(1); i <= D; ++i) {
    #line 235 "src/math/simulate.birch"
    libbirch_line_(235);
    #line 235 "src/math/simulate.birch"
    x.set(libbirch::make_slice(i - 1), z * x.get(libbirch::make_slice(i - 1)));
  }
  #line 237 "src/math/simulate.birch"
  libbirch_line_(237);
  #line 237 "src/math/simulate.birch"
  return x;
}

#line 246 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_dirichlet(const birch::type::Real& _u0945, const birch::type::Integer& D, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 246 "src/math/simulate.birch"
  libbirch_function_("simulate_dirichlet", "src/math/simulate.birch", 246);
  #line 247 "src/math/simulate.birch"
  libbirch_line_(247);
  #line 247 "src/math/simulate.birch"
  libbirch_assert_(D > birch::type::Integer(0));
  #line 248 "src/math/simulate.birch"
  libbirch_line_(248);
  #line 248 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,1> x(libbirch::make_shape(D));
  #line 249 "src/math/simulate.birch"
  libbirch_line_(249);
  #line 249 "src/math/simulate.birch"
  birch::type::Real z = 0.0;
  #line 251 "src/math/simulate.birch"
  libbirch_line_(251);
  #line 251 "src/math/simulate.birch"
  for (auto i = birch::type::Integer(1); i <= D; ++i) {
    #line 252 "src/math/simulate.birch"
    libbirch_line_(252);
    #line 252 "src/math/simulate.birch"
    x.set(libbirch::make_slice(i - 1), birch::simulate_gamma(_u0945, 1.0, handler_));
    #line 253 "src/math/simulate.birch"
    libbirch_line_(253);
    #line 253 "src/math/simulate.birch"
    z = z + x.get(libbirch::make_slice(i - 1));
  }
  #line 255 "src/math/simulate.birch"
  libbirch_line_(255);
  #line 255 "src/math/simulate.birch"
  z = 1.0 / z;
  #line 256 "src/math/simulate.birch"
  libbirch_line_(256);
  #line 256 "src/math/simulate.birch"
  for (auto i = birch::type::Integer(1); i <= D; ++i) {
    #line 257 "src/math/simulate.birch"
    libbirch_line_(257);
    #line 257 "src/math/simulate.birch"
    x.set(libbirch::make_slice(i - 1), z * x.get(libbirch::make_slice(i - 1)));
  }
  #line 259 "src/math/simulate.birch"
  libbirch_line_(259);
  #line 259 "src/math/simulate.birch"
  return x;
}

#line 268 "src/math/simulate.birch"
birch::type::Real birch::simulate_uniform(const birch::type::Real& l, const birch::type::Real& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 268 "src/math/simulate.birch"
  libbirch_function_("simulate_uniform", "src/math/simulate.birch", 268);
  #line 269 "src/math/simulate.birch"
  libbirch_line_(269);
  #line 269 "src/math/simulate.birch"
  libbirch_assert_(l <= u);
  #line 270 "src/math/simulate.birch"
return std::uniform_real_distribution<birch::type::Real>(l, u)(get_rng());
  }

#line 281 "src/math/simulate.birch"
birch::type::Integer birch::simulate_uniform_int(const birch::type::Integer& l, const birch::type::Integer& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 281 "src/math/simulate.birch"
  libbirch_function_("simulate_uniform_int", "src/math/simulate.birch", 281);
  #line 282 "src/math/simulate.birch"
  libbirch_line_(282);
  #line 282 "src/math/simulate.birch"
  libbirch_assert_(l <= u);
  #line 283 "src/math/simulate.birch"
return std::uniform_int_distribution<birch::type::Integer>(l, u)(get_rng());
  }

#line 293 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_uniform_unit_vector(const birch::type::Integer& D, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 293 "src/math/simulate.birch"
  libbirch_function_("simulate_uniform_unit_vector", "src/math/simulate.birch", 293);
  #line 294 "src/math/simulate.birch"
  libbirch_line_(294);
  #line 294 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,1> u(libbirch::make_shape(D));
  #line 295 "src/math/simulate.birch"
  libbirch_line_(295);
  #line 295 "src/math/simulate.birch"
  for (auto d = birch::type::Integer(1); d <= D; ++d) {
    #line 296 "src/math/simulate.birch"
    libbirch_line_(296);
    #line 296 "src/math/simulate.birch"
    u.set(libbirch::make_slice(d - 1), birch::simulate_gaussian(0.0, 1.0, handler_));
  }
  #line 298 "src/math/simulate.birch"
  libbirch_line_(298);
  #line 298 "src/math/simulate.birch"
  return u / birch::dot(u, handler_);
}

#line 306 "src/math/simulate.birch"
birch::type::Real birch::simulate_exponential(const birch::type::Real& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 306 "src/math/simulate.birch"
  libbirch_function_("simulate_exponential", "src/math/simulate.birch", 306);
  #line 307 "src/math/simulate.birch"
  libbirch_line_(307);
  #line 307 "src/math/simulate.birch"
  libbirch_assert_(0.0 < _u0955);
  #line 308 "src/math/simulate.birch"
return std::exponential_distribution<birch::type::Real>(_u0955)(get_rng());
  }

#line 319 "src/math/simulate.birch"
birch::type::Real birch::simulate_weibull(const birch::type::Real& k, const birch::type::Real& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 319 "src/math/simulate.birch"
  libbirch_function_("simulate_weibull", "src/math/simulate.birch", 319);
  #line 320 "src/math/simulate.birch"
  libbirch_line_(320);
  #line 320 "src/math/simulate.birch"
  libbirch_assert_(0.0 < k);
  #line 321 "src/math/simulate.birch"
  libbirch_line_(321);
  #line 321 "src/math/simulate.birch"
  libbirch_assert_(0.0 < _u0955);
  #line 322 "src/math/simulate.birch"
return std::weibull_distribution<birch::type::Real>(k, _u0955)(get_rng());
  }

#line 333 "src/math/simulate.birch"
birch::type::Real birch::simulate_gaussian(const birch::type::Real& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 333 "src/math/simulate.birch"
  libbirch_function_("simulate_gaussian", "src/math/simulate.birch", 333);
  #line 334 "src/math/simulate.birch"
  libbirch_line_(334);
  #line 334 "src/math/simulate.birch"
  libbirch_assert_(0.0 <= _u09632);
  #line 335 "src/math/simulate.birch"
  libbirch_line_(335);
  #line 335 "src/math/simulate.birch"
  if (_u09632 == 0.0) {
    #line 336 "src/math/simulate.birch"
    libbirch_line_(336);
    #line 336 "src/math/simulate.birch"
    return _u0956;
  } else {
    #line 338 "src/math/simulate.birch"
return std::normal_distribution<birch::type::Real>(_u0956, std::sqrt(_u09632))(get_rng());
      }
}

#line 349 "src/math/simulate.birch"
birch::type::Real birch::simulate_student_t(const birch::type::Real& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 349 "src/math/simulate.birch"
  libbirch_function_("simulate_student_t", "src/math/simulate.birch", 349);
  #line 350 "src/math/simulate.birch"
  libbirch_line_(350);
  #line 350 "src/math/simulate.birch"
  libbirch_assert_(0.0 < _u0957);
  #line 351 "src/math/simulate.birch"
return std::student_t_distribution<birch::type::Real>(_u0957)(get_rng());
  }

#line 363 "src/math/simulate.birch"
birch::type::Real birch::simulate_student_t(const birch::type::Real& _u0957, const birch::type::Real& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 363 "src/math/simulate.birch"
  libbirch_function_("simulate_student_t", "src/math/simulate.birch", 363);
  #line 364 "src/math/simulate.birch"
  libbirch_line_(364);
  #line 364 "src/math/simulate.birch"
  libbirch_assert_(0.0 < _u0957);
  #line 365 "src/math/simulate.birch"
  libbirch_line_(365);
  #line 365 "src/math/simulate.birch"
  if (_u09632 == 0.0) {
    #line 366 "src/math/simulate.birch"
    libbirch_line_(366);
    #line 366 "src/math/simulate.birch"
    return _u0956;
  } else {
    #line 368 "src/math/simulate.birch"
    libbirch_line_(368);
    #line 368 "src/math/simulate.birch"
    return _u0956 + birch::sqrt(_u09632, handler_) * birch::simulate_student_t(_u0957, handler_);
  }
}

#line 378 "src/math/simulate.birch"
birch::type::Real birch::simulate_beta(const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 378 "src/math/simulate.birch"
  libbirch_function_("simulate_beta", "src/math/simulate.birch", 378);
  #line 379 "src/math/simulate.birch"
  libbirch_line_(379);
  #line 379 "src/math/simulate.birch"
  libbirch_assert_(0.0 < _u0945);
  #line 380 "src/math/simulate.birch"
  libbirch_line_(380);
  #line 380 "src/math/simulate.birch"
  libbirch_assert_(0.0 < _u0946);
  #line 382 "src/math/simulate.birch"
  libbirch_line_(382);
  #line 382 "src/math/simulate.birch"
  birch::type::Real u = birch::simulate_gamma(_u0945, 1.0, handler_);
  #line 383 "src/math/simulate.birch"
  libbirch_line_(383);
  #line 383 "src/math/simulate.birch"
  birch::type::Real v = birch::simulate_gamma(_u0946, 1.0, handler_);
  #line 385 "src/math/simulate.birch"
  libbirch_line_(385);
  #line 385 "src/math/simulate.birch"
  return u / (u + v);
}

#line 393 "src/math/simulate.birch"
birch::type::Real birch::simulate_chi_squared(const birch::type::Real& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 393 "src/math/simulate.birch"
  libbirch_function_("simulate_chi_squared", "src/math/simulate.birch", 393);
  #line 394 "src/math/simulate.birch"
  libbirch_line_(394);
  #line 394 "src/math/simulate.birch"
  libbirch_assert_(0.0 < _u0957);
  #line 395 "src/math/simulate.birch"
return std::chi_squared_distribution<birch::type::Real>(_u0957)(get_rng());
  }

#line 406 "src/math/simulate.birch"
birch::type::Real birch::simulate_gamma(const birch::type::Real& k, const birch::type::Real& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 406 "src/math/simulate.birch"
  libbirch_function_("simulate_gamma", "src/math/simulate.birch", 406);
  #line 407 "src/math/simulate.birch"
  libbirch_line_(407);
  #line 407 "src/math/simulate.birch"
  libbirch_assert_(0.0 < k);
  #line 408 "src/math/simulate.birch"
  libbirch_line_(408);
  #line 408 "src/math/simulate.birch"
  libbirch_assert_(0.0 < _u0952);
  #line 409 "src/math/simulate.birch"
return std::gamma_distribution<birch::type::Real>(k, _u0952)(get_rng());
  }

#line 420 "src/math/simulate.birch"
birch::type::LLT birch::simulate_wishart(const birch::type::LLT& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 420 "src/math/simulate.birch"
  libbirch_function_("simulate_wishart", "src/math/simulate.birch", 420);
  #line 421 "src/math/simulate.birch"
  libbirch_line_(421);
  #line 421 "src/math/simulate.birch"
  libbirch_assert_(birch::rows(_u0936, handler_) == birch::columns(_u0936, handler_));
  #line 422 "src/math/simulate.birch"
  libbirch_line_(422);
  #line 422 "src/math/simulate.birch"
  libbirch_assert_(k > birch::rows(_u0936, handler_) - birch::type::Integer(1));
  #line 423 "src/math/simulate.birch"
  libbirch_line_(423);
  #line 423 "src/math/simulate.birch"
  auto p = birch::rows(_u0936, handler_);
  #line 424 "src/math/simulate.birch"
  libbirch_line_(424);
  #line 424 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,2> A(libbirch::make_shape(p, p));
  #line 426 "src/math/simulate.birch"
  libbirch_line_(426);
  #line 426 "src/math/simulate.birch"
  for (auto i = birch::type::Integer(1); i <= p; ++i) {
    #line 427 "src/math/simulate.birch"
    libbirch_line_(427);
    #line 427 "src/math/simulate.birch"
    for (auto j = birch::type::Integer(1); j <= p; ++j) {
      #line 428 "src/math/simulate.birch"
      libbirch_line_(428);
      #line 428 "src/math/simulate.birch"
      if (j == i) {
        #line 430 "src/math/simulate.birch"
        libbirch_line_(430);
        #line 430 "src/math/simulate.birch"
        A.set(libbirch::make_slice(i - 1, j - 1), birch::sqrt(birch::simulate_chi_squared(k - i + birch::type::Integer(1), handler_), handler_));
      } else {
        #line 431 "src/math/simulate.birch"
        libbirch_line_(431);
        #line 431 "src/math/simulate.birch"
        if (j < i) {
          #line 433 "src/math/simulate.birch"
          libbirch_line_(433);
          #line 433 "src/math/simulate.birch"
          A.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_gaussian(0.0, 1.0, handler_));
        } else {
          #line 436 "src/math/simulate.birch"
          libbirch_line_(436);
          #line 436 "src/math/simulate.birch"
          A.set(libbirch::make_slice(i - 1, j - 1), 0.0);
        }
      }
    }
  }
  #line 440 "src/math/simulate.birch"
  libbirch_line_(440);
  #line 440 "src/math/simulate.birch"
  auto L = birch::cholesky(_u0936, handler_) * A;
  #line 441 "src/math/simulate.birch"
  libbirch_line_(441);
  #line 441 "src/math/simulate.birch"
  return birch::llt(L * birch::transpose(L, handler_), handler_);
}

#line 450 "src/math/simulate.birch"
birch::type::Real birch::simulate_inverse_gamma(const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 450 "src/math/simulate.birch"
  libbirch_function_("simulate_inverse_gamma", "src/math/simulate.birch", 450);
  #line 451 "src/math/simulate.birch"
  libbirch_line_(451);
  #line 451 "src/math/simulate.birch"
  return 1.0 / birch::simulate_gamma(_u0945, 1.0 / _u0946, handler_);
}

#line 460 "src/math/simulate.birch"
birch::type::LLT birch::simulate_inverse_wishart(const birch::type::LLT& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 460 "src/math/simulate.birch"
  libbirch_function_("simulate_inverse_wishart", "src/math/simulate.birch", 460);
  #line 461 "src/math/simulate.birch"
  libbirch_line_(461);
  #line 461 "src/math/simulate.birch"
  return birch::inv(birch::simulate_wishart(birch::inv(_u0936, handler_), k, handler_), handler_);
}

#line 472 "src/math/simulate.birch"
birch::type::Real birch::simulate_normal_inverse_gamma(const birch::type::Real& _u0956, const birch::type::Real& a2, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 472 "src/math/simulate.birch"
  libbirch_function_("simulate_normal_inverse_gamma", "src/math/simulate.birch", 472);
  #line 474 "src/math/simulate.birch"
  libbirch_line_(474);
  #line 474 "src/math/simulate.birch"
  return birch::simulate_student_t(2.0 * _u0945, _u0956, a2 * _u0946 / _u0945, handler_);
}

#line 483 "src/math/simulate.birch"
birch::type::Boolean birch::simulate_beta_bernoulli(const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 483 "src/math/simulate.birch"
  libbirch_function_("simulate_beta_bernoulli", "src/math/simulate.birch", 483);
  #line 484 "src/math/simulate.birch"
  libbirch_line_(484);
  #line 484 "src/math/simulate.birch"
  libbirch_assert_(0.0 < _u0945);
  #line 485 "src/math/simulate.birch"
  libbirch_line_(485);
  #line 485 "src/math/simulate.birch"
  libbirch_assert_(0.0 < _u0946);
  #line 487 "src/math/simulate.birch"
  libbirch_line_(487);
  #line 487 "src/math/simulate.birch"
  return birch::simulate_bernoulli(birch::simulate_beta(_u0945, _u0946, handler_), handler_);
}

#line 497 "src/math/simulate.birch"
birch::type::Integer birch::simulate_beta_binomial(const birch::type::Integer& n, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 497 "src/math/simulate.birch"
  libbirch_function_("simulate_beta_binomial", "src/math/simulate.birch", 497);
  #line 498 "src/math/simulate.birch"
  libbirch_line_(498);
  #line 498 "src/math/simulate.birch"
  libbirch_assert_(birch::type::Integer(0) <= n);
  #line 499 "src/math/simulate.birch"
  libbirch_line_(499);
  #line 499 "src/math/simulate.birch"
  libbirch_assert_(0.0 < _u0945);
  #line 500 "src/math/simulate.birch"
  libbirch_line_(500);
  #line 500 "src/math/simulate.birch"
  libbirch_assert_(0.0 < _u0946);
  #line 502 "src/math/simulate.birch"
  libbirch_line_(502);
  #line 502 "src/math/simulate.birch"
  return birch::simulate_binomial(n, birch::simulate_beta(_u0945, _u0946, handler_), handler_);
}

#line 512 "src/math/simulate.birch"
birch::type::Integer birch::simulate_beta_negative_binomial(const birch::type::Integer& k, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 512 "src/math/simulate.birch"
  libbirch_function_("simulate_beta_negative_binomial", "src/math/simulate.birch", 512);
  #line 513 "src/math/simulate.birch"
  libbirch_line_(513);
  #line 513 "src/math/simulate.birch"
  libbirch_assert_(0.0 < _u0945);
  #line 514 "src/math/simulate.birch"
  libbirch_line_(514);
  #line 514 "src/math/simulate.birch"
  libbirch_assert_(0.0 < _u0946);
  #line 515 "src/math/simulate.birch"
  libbirch_line_(515);
  #line 515 "src/math/simulate.birch"
  libbirch_assert_(birch::type::Integer(0) < k);
  #line 517 "src/math/simulate.birch"
  libbirch_line_(517);
  #line 517 "src/math/simulate.birch"
  return birch::simulate_negative_binomial(k, birch::simulate_beta(_u0945, _u0946, handler_), handler_);
}

#line 527 "src/math/simulate.birch"
birch::type::Integer birch::simulate_gamma_poisson(const birch::type::Real& k, const birch::type::Real& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 527 "src/math/simulate.birch"
  libbirch_function_("simulate_gamma_poisson", "src/math/simulate.birch", 527);
  #line 528 "src/math/simulate.birch"
  libbirch_line_(528);
  #line 528 "src/math/simulate.birch"
  libbirch_assert_(0.0 < k);
  #line 529 "src/math/simulate.birch"
  libbirch_line_(529);
  #line 529 "src/math/simulate.birch"
  libbirch_assert_(0.0 < _u0952);
  #line 530 "src/math/simulate.birch"
  libbirch_line_(530);
  #line 530 "src/math/simulate.birch"
  libbirch_assert_(k == birch::floor(k, handler_));
  #line 532 "src/math/simulate.birch"
  libbirch_line_(532);
  #line 532 "src/math/simulate.birch"
  return birch::simulate_negative_binomial(birch::Integer(k, handler_), 1.0 / (_u0952 + 1.0), handler_);
}

#line 541 "src/math/simulate.birch"
birch::type::Real birch::simulate_lomax(const birch::type::Real& _u0955, const birch::type::Real& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 541 "src/math/simulate.birch"
  libbirch_function_("simulate_lomax", "src/math/simulate.birch", 541);
  #line 542 "src/math/simulate.birch"
  libbirch_line_(542);
  #line 542 "src/math/simulate.birch"
  libbirch_assert_(0.0 < _u0955);
  #line 543 "src/math/simulate.birch"
  libbirch_line_(543);
  #line 543 "src/math/simulate.birch"
  libbirch_assert_(0.0 < _u0945);
  #line 545 "src/math/simulate.birch"
  libbirch_line_(545);
  #line 545 "src/math/simulate.birch"
  birch::type::Real u = birch::simulate_uniform(0.0, 1.0, handler_);
  #line 546 "src/math/simulate.birch"
  libbirch_line_(546);
  #line 546 "src/math/simulate.birch"
  return _u0955 * (birch::pow(u, -1.0 / _u0945, handler_) - 1.0);
}

#line 554 "src/math/simulate.birch"
birch::type::Integer birch::simulate_dirichlet_categorical(const libbirch::DefaultArray<birch::type::Real,1>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 554 "src/math/simulate.birch"
  libbirch_function_("simulate_dirichlet_categorical", "src/math/simulate.birch", 554);
  #line 555 "src/math/simulate.birch"
  libbirch_line_(555);
  #line 555 "src/math/simulate.birch"
  return birch::simulate_categorical(birch::simulate_dirichlet(_u0945, handler_), handler_);
}

#line 564 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::simulate_dirichlet_multinomial(const birch::type::Integer& n, const libbirch::DefaultArray<birch::type::Real,1>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 564 "src/math/simulate.birch"
  libbirch_function_("simulate_dirichlet_multinomial", "src/math/simulate.birch", 564);
  #line 565 "src/math/simulate.birch"
  libbirch_line_(565);
  #line 565 "src/math/simulate.birch"
  return birch::simulate_multinomial(n, birch::simulate_dirichlet(_u0945, handler_), handler_);
}

#line 577 "src/math/simulate.birch"
birch::type::Integer birch::simulate_crp_categorical(const birch::type::Real& _u0945, const birch::type::Real& _u0952, const libbirch::DefaultArray<birch::type::Integer,1>& n, const birch::type::Integer& N, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 577 "src/math/simulate.birch"
  libbirch_function_("simulate_crp_categorical", "src/math/simulate.birch", 577);
  #line 579 "src/math/simulate.birch"
  libbirch_line_(579);
  #line 579 "src/math/simulate.birch"
  libbirch_assert_(N >= birch::type::Integer(0));
  #line 580 "src/math/simulate.birch"
  libbirch_line_(580);
  #line 580 "src/math/simulate.birch"
  libbirch_assert_(birch::sum(n, handler_) == N);
  #line 582 "src/math/simulate.birch"
  libbirch_line_(582);
  #line 582 "src/math/simulate.birch"
  birch::type::Integer k = birch::type::Integer(0);
  #line 583 "src/math/simulate.birch"
  libbirch_line_(583);
  #line 583 "src/math/simulate.birch"
  birch::type::Integer K = birch::length(n, handler_);
  #line 584 "src/math/simulate.birch"
  libbirch_line_(584);
  #line 584 "src/math/simulate.birch"
  if (N == birch::type::Integer(0)) {
    #line 586 "src/math/simulate.birch"
    libbirch_line_(586);
    #line 586 "src/math/simulate.birch"
    k = birch::type::Integer(1);
  } else {
    #line 588 "src/math/simulate.birch"
    libbirch_line_(588);
    #line 588 "src/math/simulate.birch"
    birch::type::Real u = birch::simulate_uniform(0.0, N + _u0952, handler_);
    #line 589 "src/math/simulate.birch"
    libbirch_line_(589);
    #line 589 "src/math/simulate.birch"
    birch::type::Real U = K * _u0945 + _u0952;
    #line 590 "src/math/simulate.birch"
    libbirch_line_(590);
    #line 590 "src/math/simulate.birch"
    if (u < U) {
      #line 592 "src/math/simulate.birch"
      libbirch_line_(592);
      #line 592 "src/math/simulate.birch"
      k = K + birch::type::Integer(1);
    } else {
      #line 595 "src/math/simulate.birch"
      libbirch_line_(595);
      #line 595 "src/math/simulate.birch"
      while (k < K && u > U) {
        #line 596 "src/math/simulate.birch"
        libbirch_line_(596);
        #line 596 "src/math/simulate.birch"
        k = k + birch::type::Integer(1);
        #line 597 "src/math/simulate.birch"
        libbirch_line_(597);
        #line 597 "src/math/simulate.birch"
        U = U + n.get(libbirch::make_slice(k - 1)) - _u0945;
      }
    }
  }
  #line 601 "src/math/simulate.birch"
  libbirch_line_(601);
  #line 601 "src/math/simulate.birch"
  return k;
}

#line 612 "src/math/simulate.birch"
birch::type::Real birch::simulate_normal_inverse_gamma_gaussian(const birch::type::Real& _u0956, const birch::type::Real& a2, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 612 "src/math/simulate.birch"
  libbirch_function_("simulate_normal_inverse_gamma_gaussian", "src/math/simulate.birch", 612);
  #line 614 "src/math/simulate.birch"
  libbirch_line_(614);
  #line 614 "src/math/simulate.birch"
  return birch::simulate_student_t(2.0 * _u0945, _u0956, (_u0946 / _u0945) * (1.0 + a2), handler_);
}

#line 627 "src/math/simulate.birch"
birch::type::Real birch::simulate_linear_normal_inverse_gamma_gaussian(const birch::type::Real& a, const birch::type::Real& _u0956, const birch::type::Real& a2, const birch::type::Real& c, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 627 "src/math/simulate.birch"
  libbirch_function_("simulate_linear_normal_inverse_gamma_gaussian", "src/math/simulate.birch", 627);
  #line 629 "src/math/simulate.birch"
  libbirch_line_(629);
  #line 629 "src/math/simulate.birch"
  return birch::simulate_student_t(2.0 * _u0945, a * _u0956 + c, (_u0946 / _u0945) * (1.0 + a * a * a2), handler_);
}

#line 638 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const birch::type::LLT& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 638 "src/math/simulate.birch"
  libbirch_function_("simulate_multivariate_gaussian", "src/math/simulate.birch", 638);
  #line 639 "src/math/simulate.birch"
  libbirch_line_(639);
  #line 639 "src/math/simulate.birch"
  auto D = birch::length(_u0956, handler_);
  #line 640 "src/math/simulate.birch"
  libbirch_line_(640);
  #line 640 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,1> z(libbirch::make_shape(D));
  #line 641 "src/math/simulate.birch"
  libbirch_line_(641);
  #line 641 "src/math/simulate.birch"
  for (auto d = birch::type::Integer(1); d <= D; ++d) {
    #line 642 "src/math/simulate.birch"
    libbirch_line_(642);
    #line 642 "src/math/simulate.birch"
    z.set(libbirch::make_slice(d - 1), birch::simulate_gaussian(0.0, 1.0, handler_));
  }
  #line 644 "src/math/simulate.birch"
  libbirch_line_(644);
  #line 644 "src/math/simulate.birch"
  return _u0956 + birch::cholesky(_u0931, handler_) * z;
}

#line 653 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 653 "src/math/simulate.birch"
  libbirch_function_("simulate_multivariate_gaussian", "src/math/simulate.birch", 653);
  #line 654 "src/math/simulate.birch"
  libbirch_line_(654);
  #line 654 "src/math/simulate.birch"
  auto D = birch::length(_u0956, handler_);
  #line 655 "src/math/simulate.birch"
  libbirch_line_(655);
  #line 655 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,1> z(libbirch::make_shape(D));
  #line 656 "src/math/simulate.birch"
  libbirch_line_(656);
  #line 656 "src/math/simulate.birch"
  for (auto d = birch::type::Integer(1); d <= D; ++d) {
    #line 657 "src/math/simulate.birch"
    libbirch_line_(657);
    #line 657 "src/math/simulate.birch"
    z.set(libbirch::make_slice(d - 1), _u0956.get(libbirch::make_slice(d - 1)) + birch::simulate_gaussian(0.0, _u09632.get(libbirch::make_slice(d - 1)), handler_));
  }
  #line 659 "src/math/simulate.birch"
  libbirch_line_(659);
  #line 659 "src/math/simulate.birch"
  return z;
}

#line 669 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 669 "src/math/simulate.birch"
  libbirch_function_("simulate_multivariate_gaussian", "src/math/simulate.birch", 669);
  #line 670 "src/math/simulate.birch"
  libbirch_line_(670);
  #line 670 "src/math/simulate.birch"
  auto D = birch::length(_u0956, handler_);
  #line 671 "src/math/simulate.birch"
  libbirch_line_(671);
  #line 671 "src/math/simulate.birch"
  auto _u0963 = birch::sqrt(_u09632, handler_);
  #line 672 "src/math/simulate.birch"
  libbirch_line_(672);
  #line 672 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,1> z(libbirch::make_shape(D));
  #line 673 "src/math/simulate.birch"
  libbirch_line_(673);
  #line 673 "src/math/simulate.birch"
  for (auto d = birch::type::Integer(1); d <= D; ++d) {
    #line 674 "src/math/simulate.birch"
    libbirch_line_(674);
    #line 674 "src/math/simulate.birch"
    z.set(libbirch::make_slice(d - 1), _u0956.get(libbirch::make_slice(d - 1)) + _u0963 * birch::simulate_gaussian(0.0, 1.0, handler_));
  }
  #line 676 "src/math/simulate.birch"
  libbirch_line_(676);
  #line 676 "src/math/simulate.birch"
  return z;
}

#line 687 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_multivariate_normal_inverse_gamma(const libbirch::DefaultArray<birch::type::Real,1>& _u0957, const birch::type::LLT& _u0923, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 687 "src/math/simulate.birch"
  libbirch_function_("simulate_multivariate_normal_inverse_gamma", "src/math/simulate.birch", 687);
  #line 689 "src/math/simulate.birch"
  libbirch_line_(689);
  #line 689 "src/math/simulate.birch"
  return birch::simulate_multivariate_student_t(2.0 * _u0945, birch::solve(_u0923, _u0957, handler_), birch::llt((_u0946 / _u0945) * birch::canonical(birch::inv(_u0923, handler_), handler_), handler_), handler_);
}

#line 703 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_multivariate_normal_inverse_gamma_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0957, const birch::type::LLT& _u0923, const birch::type::Real& _u0945, const birch::type::Real& _u0947, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 703 "src/math/simulate.birch"
  libbirch_function_("simulate_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/math/simulate.birch", 703);
  #line 705 "src/math/simulate.birch"
  libbirch_line_(705);
  #line 705 "src/math/simulate.birch"
  auto n = birch::length(_u0957, handler_);
  #line 706 "src/math/simulate.birch"
  libbirch_line_(706);
  #line 706 "src/math/simulate.birch"
  auto _u0956 = birch::solve(_u0923, _u0957, handler_);
  #line 707 "src/math/simulate.birch"
  libbirch_line_(707);
  #line 707 "src/math/simulate.birch"
  auto _u0946 = _u0947 - 0.5 * birch::dot(_u0956, _u0957, handler_);
  #line 708 "src/math/simulate.birch"
  libbirch_line_(708);
  #line 708 "src/math/simulate.birch"
  return birch::simulate_multivariate_student_t(2.0 * _u0945, _u0956, birch::llt((_u0946 / _u0945) * (birch::identity(n, handler_) + birch::canonical(birch::inv(_u0923, handler_), handler_)), handler_), handler_);
}

#line 723 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& A, const libbirch::DefaultArray<birch::type::Real,1>& _u0957, const birch::type::LLT& _u0923, const libbirch::DefaultArray<birch::type::Real,1>& c, const birch::type::Real& _u0945, const birch::type::Real& _u0947, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 723 "src/math/simulate.birch"
  libbirch_function_("simulate_linear_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/math/simulate.birch", 723);
  #line 725 "src/math/simulate.birch"
  libbirch_line_(725);
  #line 725 "src/math/simulate.birch"
  auto n = birch::rows(A, handler_);
  #line 726 "src/math/simulate.birch"
  libbirch_line_(726);
  #line 726 "src/math/simulate.birch"
  auto _u0956 = birch::solve(_u0923, _u0957, handler_);
  #line 727 "src/math/simulate.birch"
  libbirch_line_(727);
  #line 727 "src/math/simulate.birch"
  auto _u0946 = _u0947 - 0.5 * birch::dot(_u0956, _u0957, handler_);
  #line 728 "src/math/simulate.birch"
  libbirch_line_(728);
  #line 728 "src/math/simulate.birch"
  return birch::simulate_multivariate_student_t(2.0 * _u0945, A * _u0956 + c, birch::llt((_u0946 / _u0945) * (birch::identity(n, handler_) + A * birch::solve(_u0923, birch::transpose(A, handler_), handler_)), handler_), handler_);
}

#line 743 "src/math/simulate.birch"
birch::type::Real birch::simulate_linear_multivariate_normal_inverse_gamma_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& a, const libbirch::DefaultArray<birch::type::Real,1>& _u0957, const birch::type::LLT& _u0923, const birch::type::Real& c, const birch::type::Real& _u0945, const birch::type::Real& _u0947, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 743 "src/math/simulate.birch"
  libbirch_function_("simulate_linear_multivariate_normal_inverse_gamma_gaussian", "src/math/simulate.birch", 743);
  #line 745 "src/math/simulate.birch"
  libbirch_line_(745);
  #line 745 "src/math/simulate.birch"
  auto _u0956 = birch::solve(_u0923, _u0957, handler_);
  #line 746 "src/math/simulate.birch"
  libbirch_line_(746);
  #line 746 "src/math/simulate.birch"
  auto _u0946 = _u0947 - 0.5 * birch::dot(_u0956, _u0957, handler_);
  #line 747 "src/math/simulate.birch"
  libbirch_line_(747);
  #line 747 "src/math/simulate.birch"
  return birch::simulate_student_t(2.0 * _u0945, birch::dot(a, _u0956, handler_) + c, (_u0946 / _u0945) * (1.0 + birch::dot(a, birch::solve(_u0923, a, handler_), handler_)), handler_);
}

#line 759 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::simulate_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const birch::type::LLT& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 759 "src/math/simulate.birch"
  libbirch_function_("simulate_matrix_gaussian", "src/math/simulate.birch", 759);
  #line 760 "src/math/simulate.birch"
  libbirch_line_(760);
  #line 760 "src/math/simulate.birch"
  libbirch_assert_(birch::rows(M, handler_) == birch::rows(U, handler_));
  #line 761 "src/math/simulate.birch"
  libbirch_line_(761);
  #line 761 "src/math/simulate.birch"
  libbirch_assert_(birch::rows(M, handler_) == birch::columns(U, handler_));
  #line 762 "src/math/simulate.birch"
  libbirch_line_(762);
  #line 762 "src/math/simulate.birch"
  libbirch_assert_(birch::columns(M, handler_) == birch::rows(V, handler_));
  #line 763 "src/math/simulate.birch"
  libbirch_line_(763);
  #line 763 "src/math/simulate.birch"
  libbirch_assert_(birch::columns(M, handler_) == birch::columns(V, handler_));
  #line 765 "src/math/simulate.birch"
  libbirch_line_(765);
  #line 765 "src/math/simulate.birch"
  auto N = birch::rows(M, handler_);
  #line 766 "src/math/simulate.birch"
  libbirch_line_(766);
  #line 766 "src/math/simulate.birch"
  auto P = birch::columns(M, handler_);
  #line 767 "src/math/simulate.birch"
  libbirch_line_(767);
  #line 767 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,2> Z(libbirch::make_shape(N, P));
  #line 768 "src/math/simulate.birch"
  libbirch_line_(768);
  #line 768 "src/math/simulate.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 769 "src/math/simulate.birch"
    libbirch_line_(769);
    #line 769 "src/math/simulate.birch"
    for (auto p = birch::type::Integer(1); p <= P; ++p) {
      #line 770 "src/math/simulate.birch"
      libbirch_line_(770);
      #line 770 "src/math/simulate.birch"
      Z.set(libbirch::make_slice(n - 1, p - 1), birch::simulate_gaussian(0.0, 1.0, handler_));
    }
  }
  #line 773 "src/math/simulate.birch"
  libbirch_line_(773);
  #line 773 "src/math/simulate.birch"
  return M + birch::cholesky(U, handler_) * Z * birch::transpose(birch::cholesky(V, handler_), handler_);
}

#line 783 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::simulate_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 783 "src/math/simulate.birch"
  libbirch_function_("simulate_matrix_gaussian", "src/math/simulate.birch", 783);
  #line 785 "src/math/simulate.birch"
  libbirch_line_(785);
  #line 785 "src/math/simulate.birch"
  libbirch_assert_(birch::rows(M, handler_) == birch::rows(U, handler_));
  #line 786 "src/math/simulate.birch"
  libbirch_line_(786);
  #line 786 "src/math/simulate.birch"
  libbirch_assert_(birch::rows(M, handler_) == birch::columns(U, handler_));
  #line 787 "src/math/simulate.birch"
  libbirch_line_(787);
  #line 787 "src/math/simulate.birch"
  libbirch_assert_(birch::columns(M, handler_) == birch::length(_u09632, handler_));
  #line 789 "src/math/simulate.birch"
  libbirch_line_(789);
  #line 789 "src/math/simulate.birch"
  auto N = birch::rows(M, handler_);
  #line 790 "src/math/simulate.birch"
  libbirch_line_(790);
  #line 790 "src/math/simulate.birch"
  auto P = birch::columns(M, handler_);
  #line 791 "src/math/simulate.birch"
  libbirch_line_(791);
  #line 791 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,2> Z(libbirch::make_shape(N, P));
  #line 792 "src/math/simulate.birch"
  libbirch_line_(792);
  #line 792 "src/math/simulate.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 793 "src/math/simulate.birch"
    libbirch_line_(793);
    #line 793 "src/math/simulate.birch"
    for (auto p = birch::type::Integer(1); p <= P; ++p) {
      #line 794 "src/math/simulate.birch"
      libbirch_line_(794);
      #line 794 "src/math/simulate.birch"
      Z.set(libbirch::make_slice(n - 1, p - 1), birch::simulate_gaussian(0.0, 1.0, handler_));
    }
  }
  #line 797 "src/math/simulate.birch"
  libbirch_line_(797);
  #line 797 "src/math/simulate.birch"
  return M + birch::cholesky(U, handler_) * Z * birch::diagonal(birch::sqrt(_u09632, handler_), handler_);
}

#line 806 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::simulate_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 806 "src/math/simulate.birch"
  libbirch_function_("simulate_matrix_gaussian", "src/math/simulate.birch", 806);
  #line 807 "src/math/simulate.birch"
  libbirch_line_(807);
  #line 807 "src/math/simulate.birch"
  libbirch_assert_(birch::columns(M, handler_) == birch::rows(V, handler_));
  #line 808 "src/math/simulate.birch"
  libbirch_line_(808);
  #line 808 "src/math/simulate.birch"
  libbirch_assert_(birch::columns(M, handler_) == birch::columns(V, handler_));
  #line 810 "src/math/simulate.birch"
  libbirch_line_(810);
  #line 810 "src/math/simulate.birch"
  auto N = birch::rows(M, handler_);
  #line 811 "src/math/simulate.birch"
  libbirch_line_(811);
  #line 811 "src/math/simulate.birch"
  auto P = birch::columns(M, handler_);
  #line 812 "src/math/simulate.birch"
  libbirch_line_(812);
  #line 812 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,2> Z(libbirch::make_shape(N, P));
  #line 813 "src/math/simulate.birch"
  libbirch_line_(813);
  #line 813 "src/math/simulate.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 814 "src/math/simulate.birch"
    libbirch_line_(814);
    #line 814 "src/math/simulate.birch"
    for (auto p = birch::type::Integer(1); p <= P; ++p) {
      #line 815 "src/math/simulate.birch"
      libbirch_line_(815);
      #line 815 "src/math/simulate.birch"
      Z.set(libbirch::make_slice(n - 1, p - 1), birch::simulate_gaussian(0.0, 1.0, handler_));
    }
  }
  #line 818 "src/math/simulate.birch"
  libbirch_line_(818);
  #line 818 "src/math/simulate.birch"
  return M + Z * birch::transpose(birch::cholesky(V, handler_), handler_);
}

#line 827 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::simulate_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 827 "src/math/simulate.birch"
  libbirch_function_("simulate_matrix_gaussian", "src/math/simulate.birch", 827);
  #line 828 "src/math/simulate.birch"
  libbirch_line_(828);
  #line 828 "src/math/simulate.birch"
  libbirch_assert_(birch::columns(M, handler_) == birch::length(_u09632, handler_));
  #line 830 "src/math/simulate.birch"
  libbirch_line_(830);
  #line 830 "src/math/simulate.birch"
  auto N = birch::rows(M, handler_);
  #line 831 "src/math/simulate.birch"
  libbirch_line_(831);
  #line 831 "src/math/simulate.birch"
  auto P = birch::columns(M, handler_);
  #line 832 "src/math/simulate.birch"
  libbirch_line_(832);
  #line 832 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,2> X(libbirch::make_shape(N, P));
  #line 833 "src/math/simulate.birch"
  libbirch_line_(833);
  #line 833 "src/math/simulate.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 834 "src/math/simulate.birch"
    libbirch_line_(834);
    #line 834 "src/math/simulate.birch"
    for (auto p = birch::type::Integer(1); p <= P; ++p) {
      #line 835 "src/math/simulate.birch"
      libbirch_line_(835);
      #line 835 "src/math/simulate.birch"
      X.set(libbirch::make_slice(n - 1, p - 1), birch::simulate_gaussian(M.get(libbirch::make_slice(n - 1, p - 1)), _u09632.get(libbirch::make_slice(p - 1)), handler_));
    }
  }
  #line 838 "src/math/simulate.birch"
  libbirch_line_(838);
  #line 838 "src/math/simulate.birch"
  return X;
}

#line 848 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::simulate_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 848 "src/math/simulate.birch"
  libbirch_function_("simulate_matrix_gaussian", "src/math/simulate.birch", 848);
  #line 849 "src/math/simulate.birch"
  libbirch_line_(849);
  #line 849 "src/math/simulate.birch"
  auto N = birch::rows(M, handler_);
  #line 850 "src/math/simulate.birch"
  libbirch_line_(850);
  #line 850 "src/math/simulate.birch"
  auto P = birch::columns(M, handler_);
  #line 851 "src/math/simulate.birch"
  libbirch_line_(851);
  #line 851 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,2> X(libbirch::make_shape(N, P));
  #line 852 "src/math/simulate.birch"
  libbirch_line_(852);
  #line 852 "src/math/simulate.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 853 "src/math/simulate.birch"
    libbirch_line_(853);
    #line 853 "src/math/simulate.birch"
    for (auto p = birch::type::Integer(1); p <= P; ++p) {
      #line 854 "src/math/simulate.birch"
      libbirch_line_(854);
      #line 854 "src/math/simulate.birch"
      X.set(libbirch::make_slice(n - 1, p - 1), birch::simulate_gaussian(M.get(libbirch::make_slice(n - 1, p - 1)), _u09632, handler_));
    }
  }
  #line 857 "src/math/simulate.birch"
  libbirch_line_(857);
  #line 857 "src/math/simulate.birch"
  return X;
}

#line 868 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::simulate_matrix_normal_inverse_wishart(const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& _u0923, const birch::type::LLT& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 868 "src/math/simulate.birch"
  libbirch_function_("simulate_matrix_normal_inverse_wishart", "src/math/simulate.birch", 868);
  #line 870 "src/math/simulate.birch"
  libbirch_line_(870);
  #line 870 "src/math/simulate.birch"
  auto p = birch::columns(N, handler_);
  #line 871 "src/math/simulate.birch"
  libbirch_line_(871);
  #line 871 "src/math/simulate.birch"
  auto M = birch::solve(_u0923, N, handler_);
  #line 872 "src/math/simulate.birch"
  libbirch_line_(872);
  #line 872 "src/math/simulate.birch"
  auto _u0931 = birch::llt(birch::canonical(birch::inv(_u0923, handler_), handler_) / (k - p + 1.0), handler_);
  #line 873 "src/math/simulate.birch"
  libbirch_line_(873);
  #line 873 "src/math/simulate.birch"
  return birch::simulate_matrix_student_t(k - p + 1.0, M, _u0931, _u0936, handler_);
}

#line 884 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::simulate_matrix_normal_inverse_wishart_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& _u0923, const birch::type::LLT& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 884 "src/math/simulate.birch"
  libbirch_function_("simulate_matrix_normal_inverse_wishart_matrix_gaussian", "src/math/simulate.birch", 884);
  #line 886 "src/math/simulate.birch"
  libbirch_line_(886);
  #line 886 "src/math/simulate.birch"
  auto n = birch::rows(N, handler_);
  #line 887 "src/math/simulate.birch"
  libbirch_line_(887);
  #line 887 "src/math/simulate.birch"
  auto p = birch::columns(N, handler_);
  #line 888 "src/math/simulate.birch"
  libbirch_line_(888);
  #line 888 "src/math/simulate.birch"
  auto M = birch::solve(_u0923, N, handler_);
  #line 889 "src/math/simulate.birch"
  libbirch_line_(889);
  #line 889 "src/math/simulate.birch"
  auto _u0931 = birch::llt((birch::identity(n, handler_) + birch::canonical(birch::inv(_u0923, handler_), handler_)) / (k - p + 1.0), handler_);
  #line 890 "src/math/simulate.birch"
  libbirch_line_(890);
  #line 890 "src/math/simulate.birch"
  return birch::simulate_matrix_student_t(k - p + 1.0, M, _u0931, _u0936, handler_);
}

#line 904 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::simulate_linear_matrix_normal_inverse_wishart_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& A, const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& _u0923, const libbirch::DefaultArray<birch::type::Real,2>& C, const birch::type::LLT& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 904 "src/math/simulate.birch"
  libbirch_function_("simulate_linear_matrix_normal_inverse_wishart_matrix_gaussian", "src/math/simulate.birch", 904);
  #line 907 "src/math/simulate.birch"
  libbirch_line_(907);
  #line 907 "src/math/simulate.birch"
  auto n = birch::rows(A, handler_);
  #line 908 "src/math/simulate.birch"
  libbirch_line_(908);
  #line 908 "src/math/simulate.birch"
  auto p = birch::columns(N, handler_);
  #line 909 "src/math/simulate.birch"
  libbirch_line_(909);
  #line 909 "src/math/simulate.birch"
  auto M = birch::solve(_u0923, N, handler_);
  #line 910 "src/math/simulate.birch"
  libbirch_line_(910);
  #line 910 "src/math/simulate.birch"
  auto _u0931 = birch::llt((birch::identity(birch::rows(A, handler_), handler_) + A * birch::solve(_u0923, birch::transpose(A, handler_), handler_)) / (k - p + 1.0), handler_);
  #line 911 "src/math/simulate.birch"
  libbirch_line_(911);
  #line 911 "src/math/simulate.birch"
  return birch::simulate_matrix_student_t(k - p + 1.0, A * M + C, _u0931, _u0936, handler_);
}

#line 925 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_linear_matrix_normal_inverse_wishart_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& a, const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& _u0923, const libbirch::DefaultArray<birch::type::Real,1>& c, const birch::type::LLT& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 925 "src/math/simulate.birch"
  libbirch_function_("simulate_linear_matrix_normal_inverse_wishart_multivariate_gaussian", "src/math/simulate.birch", 925);
  #line 927 "src/math/simulate.birch"
  libbirch_line_(927);
  #line 927 "src/math/simulate.birch"
  auto p = birch::columns(N, handler_);
  #line 928 "src/math/simulate.birch"
  libbirch_line_(928);
  #line 928 "src/math/simulate.birch"
  auto M = birch::solve(_u0923, N, handler_);
  #line 929 "src/math/simulate.birch"
  libbirch_line_(929);
  #line 929 "src/math/simulate.birch"
  auto _u09632 = (1.0 + birch::dot(a, birch::solve(_u0923, a, handler_), handler_)) / (k - p + 1.0);
  #line 930 "src/math/simulate.birch"
  libbirch_line_(930);
  #line 930 "src/math/simulate.birch"
  return birch::simulate_multivariate_student_t(k - p + 1.0, birch::dot(a, M, handler_) + c, birch::llt(_u09632 * birch::canonical(_u0936, handler_), handler_), handler_);
}

#line 942 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_multivariate_student_t(const birch::type::Real& k, const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const birch::type::LLT& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 942 "src/math/simulate.birch"
  libbirch_function_("simulate_multivariate_student_t", "src/math/simulate.birch", 942);
  #line 944 "src/math/simulate.birch"
  libbirch_line_(944);
  #line 944 "src/math/simulate.birch"
  auto D = birch::length(_u0956, handler_);
  #line 945 "src/math/simulate.birch"
  libbirch_line_(945);
  #line 945 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,1> z(libbirch::make_shape(D));
  #line 946 "src/math/simulate.birch"
  libbirch_line_(946);
  #line 946 "src/math/simulate.birch"
  for (auto d = birch::type::Integer(1); d <= D; ++d) {
    #line 947 "src/math/simulate.birch"
    libbirch_line_(947);
    #line 947 "src/math/simulate.birch"
    z.set(libbirch::make_slice(d - 1), birch::simulate_student_t(k, handler_));
  }
  #line 949 "src/math/simulate.birch"
  libbirch_line_(949);
  #line 949 "src/math/simulate.birch"
  return _u0956 + birch::cholesky(_u0931, handler_) * z;
}

#line 960 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_multivariate_student_t(const birch::type::Real& k, const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 960 "src/math/simulate.birch"
  libbirch_function_("simulate_multivariate_student_t", "src/math/simulate.birch", 960);
  #line 962 "src/math/simulate.birch"
  libbirch_line_(962);
  #line 962 "src/math/simulate.birch"
  auto D = birch::length(_u0956, handler_);
  #line 963 "src/math/simulate.birch"
  libbirch_line_(963);
  #line 963 "src/math/simulate.birch"
  auto _u0963 = birch::sqrt(_u09632, handler_);
  #line 964 "src/math/simulate.birch"
  libbirch_line_(964);
  #line 964 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,1> z(libbirch::make_shape(D));
  #line 965 "src/math/simulate.birch"
  libbirch_line_(965);
  #line 965 "src/math/simulate.birch"
  for (auto d = birch::type::Integer(1); d <= D; ++d) {
    #line 966 "src/math/simulate.birch"
    libbirch_line_(966);
    #line 966 "src/math/simulate.birch"
    z.set(libbirch::make_slice(d - 1), _u0956.get(libbirch::make_slice(d - 1)) + _u0963 * birch::simulate_student_t(k, handler_));
  }
  #line 968 "src/math/simulate.birch"
  libbirch_line_(968);
  #line 968 "src/math/simulate.birch"
  return z;
}

#line 979 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::simulate_matrix_student_t(const birch::type::Real& k, const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const birch::type::LLT& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 979 "src/math/simulate.birch"
  libbirch_function_("simulate_matrix_student_t", "src/math/simulate.birch", 979);
  #line 981 "src/math/simulate.birch"
  libbirch_line_(981);
  #line 981 "src/math/simulate.birch"
  libbirch_assert_(birch::rows(M, handler_) == birch::rows(U, handler_));
  #line 982 "src/math/simulate.birch"
  libbirch_line_(982);
  #line 982 "src/math/simulate.birch"
  libbirch_assert_(birch::rows(M, handler_) == birch::columns(U, handler_));
  #line 983 "src/math/simulate.birch"
  libbirch_line_(983);
  #line 983 "src/math/simulate.birch"
  libbirch_assert_(birch::columns(M, handler_) == birch::rows(V, handler_));
  #line 984 "src/math/simulate.birch"
  libbirch_line_(984);
  #line 984 "src/math/simulate.birch"
  libbirch_assert_(birch::columns(M, handler_) == birch::columns(V, handler_));
  #line 986 "src/math/simulate.birch"
  libbirch_line_(986);
  #line 986 "src/math/simulate.birch"
  auto N = birch::rows(M, handler_);
  #line 987 "src/math/simulate.birch"
  libbirch_line_(987);
  #line 987 "src/math/simulate.birch"
  auto P = birch::columns(M, handler_);
  #line 988 "src/math/simulate.birch"
  libbirch_line_(988);
  #line 988 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,2> Z(libbirch::make_shape(N, P));
  #line 989 "src/math/simulate.birch"
  libbirch_line_(989);
  #line 989 "src/math/simulate.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 990 "src/math/simulate.birch"
    libbirch_line_(990);
    #line 990 "src/math/simulate.birch"
    for (auto p = birch::type::Integer(1); p <= P; ++p) {
      #line 991 "src/math/simulate.birch"
      libbirch_line_(991);
      #line 991 "src/math/simulate.birch"
      Z.set(libbirch::make_slice(n - 1, p - 1), birch::simulate_student_t(k, handler_));
    }
  }
  #line 994 "src/math/simulate.birch"
  libbirch_line_(994);
  #line 994 "src/math/simulate.birch"
  return M + birch::cholesky(U, handler_) * Z * birch::transpose(birch::cholesky(V, handler_), handler_);
}

#line 1005 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::simulate_matrix_student_t(const birch::type::Real& k, const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const libbirch::DefaultArray<birch::type::Real,1>& v, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1005 "src/math/simulate.birch"
  libbirch_function_("simulate_matrix_student_t", "src/math/simulate.birch", 1005);
  #line 1007 "src/math/simulate.birch"
  libbirch_line_(1007);
  #line 1007 "src/math/simulate.birch"
  libbirch_assert_(birch::rows(M, handler_) == birch::rows(U, handler_));
  #line 1008 "src/math/simulate.birch"
  libbirch_line_(1008);
  #line 1008 "src/math/simulate.birch"
  libbirch_assert_(birch::rows(M, handler_) == birch::columns(U, handler_));
  #line 1009 "src/math/simulate.birch"
  libbirch_line_(1009);
  #line 1009 "src/math/simulate.birch"
  libbirch_assert_(birch::columns(M, handler_) == birch::length(v, handler_));
  #line 1011 "src/math/simulate.birch"
  libbirch_line_(1011);
  #line 1011 "src/math/simulate.birch"
  auto N = birch::rows(M, handler_);
  #line 1012 "src/math/simulate.birch"
  libbirch_line_(1012);
  #line 1012 "src/math/simulate.birch"
  auto P = birch::columns(M, handler_);
  #line 1013 "src/math/simulate.birch"
  libbirch_line_(1013);
  #line 1013 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,2> Z(libbirch::make_shape(N, P));
  #line 1014 "src/math/simulate.birch"
  libbirch_line_(1014);
  #line 1014 "src/math/simulate.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 1015 "src/math/simulate.birch"
    libbirch_line_(1015);
    #line 1015 "src/math/simulate.birch"
    for (auto p = birch::type::Integer(1); p <= P; ++p) {
      #line 1016 "src/math/simulate.birch"
      libbirch_line_(1016);
      #line 1016 "src/math/simulate.birch"
      Z.set(libbirch::make_slice(n - 1, p - 1), birch::simulate_student_t(k, handler_));
    }
  }
  #line 1019 "src/math/simulate.birch"
  libbirch_line_(1019);
  #line 1019 "src/math/simulate.birch"
  return M + birch::cholesky(U, handler_) * Z * birch::diagonal(birch::sqrt(v, handler_), handler_);
}

#line 1028 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::simulate_independent_uniform(const libbirch::DefaultArray<birch::type::Real,1>& l, const libbirch::DefaultArray<birch::type::Real,1>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1028 "src/math/simulate.birch"
  libbirch_function_("simulate_independent_uniform", "src/math/simulate.birch", 1028);
  #line 1029 "src/math/simulate.birch"
  libbirch_line_(1029);
  #line 1029 "src/math/simulate.birch"
  libbirch_assert_(birch::length(l, handler_) == birch::length(u, handler_));
  #line 1030 "src/math/simulate.birch"
  libbirch_line_(1030);
  #line 1030 "src/math/simulate.birch"
  birch::type::Integer D = birch::length(l, handler_);
  #line 1031 "src/math/simulate.birch"
  libbirch_line_(1031);
  #line 1031 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Real,1> z(libbirch::make_shape(D));
  #line 1032 "src/math/simulate.birch"
  libbirch_line_(1032);
  #line 1032 "src/math/simulate.birch"
  for (auto d = birch::type::Integer(1); d <= D; ++d) {
    #line 1033 "src/math/simulate.birch"
    libbirch_line_(1033);
    #line 1033 "src/math/simulate.birch"
    z.set(libbirch::make_slice(d - 1), birch::simulate_uniform(l.get(libbirch::make_slice(d - 1)), u.get(libbirch::make_slice(d - 1)), handler_));
  }
  #line 1035 "src/math/simulate.birch"
  libbirch_line_(1035);
  #line 1035 "src/math/simulate.birch"
  return z;
}

#line 1044 "src/math/simulate.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::simulate_independent_uniform_int(const libbirch::DefaultArray<birch::type::Integer,1>& l, const libbirch::DefaultArray<birch::type::Integer,1>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 1044 "src/math/simulate.birch"
  libbirch_function_("simulate_independent_uniform_int", "src/math/simulate.birch", 1044);
  #line 1046 "src/math/simulate.birch"
  libbirch_line_(1046);
  #line 1046 "src/math/simulate.birch"
  libbirch_assert_(birch::length(l, handler_) == birch::length(u, handler_));
  #line 1047 "src/math/simulate.birch"
  libbirch_line_(1047);
  #line 1047 "src/math/simulate.birch"
  birch::type::Integer D = birch::length(l, handler_);
  #line 1048 "src/math/simulate.birch"
  libbirch_line_(1048);
  #line 1048 "src/math/simulate.birch"
  libbirch::DefaultArray<birch::type::Integer,1> z(libbirch::make_shape(D));
  #line 1049 "src/math/simulate.birch"
  libbirch_line_(1049);
  #line 1049 "src/math/simulate.birch"
  for (auto d = birch::type::Integer(1); d <= D; ++d) {
    #line 1050 "src/math/simulate.birch"
    libbirch_line_(1050);
    #line 1050 "src/math/simulate.birch"
    z.set(libbirch::make_slice(d - 1), birch::simulate_uniform_int(l.get(libbirch::make_slice(d - 1)), u.get(libbirch::make_slice(d - 1)), handler_));
  }
  #line 1052 "src/math/simulate.birch"
  libbirch_line_(1052);
  #line 1052 "src/math/simulate.birch"
  return z;
}

#line 1 "src/math/special.birch"
#include <boost/math/special_functions.hpp>
#line 8 "src/math/special.birch"
birch::type::Real64 birch::gamma(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 8 "src/math/special.birch"
  libbirch_function_("gamma", "src/math/special.birch", 8);
  #line 9 "src/math/special.birch"
return ::tgamma(x);
  }

#line 17 "src/math/special.birch"
birch::type::Real32 birch::gamma(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 17 "src/math/special.birch"
  libbirch_function_("gamma", "src/math/special.birch", 17);
  #line 18 "src/math/special.birch"
return ::tgammaf(x);
  }

#line 26 "src/math/special.birch"
birch::type::Real64 birch::lgamma(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/math/special.birch"
  libbirch_function_("lgamma", "src/math/special.birch", 26);
  #line 27 "src/math/special.birch"
return ::lgamma(x);
  }

#line 35 "src/math/special.birch"
birch::type::Real32 birch::lgamma(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "src/math/special.birch"
  libbirch_function_("lgamma", "src/math/special.birch", 35);
  #line 36 "src/math/special.birch"
return ::lgammaf(x);
  }

#line 44 "src/math/special.birch"
birch::type::Real64 birch::gamma(const birch::type::Real64& x, const birch::type::Integer& p, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/math/special.birch"
  libbirch_function_("gamma", "src/math/special.birch", 44);
  #line 45 "src/math/special.birch"
  libbirch_line_(45);
  #line 45 "src/math/special.birch"
  libbirch_assert_(p > birch::type::Integer(0));
  #line 46 "src/math/special.birch"
  libbirch_line_(46);
  #line 46 "src/math/special.birch"
  auto y = 0.25 * (p * (p - birch::type::Integer(1))) * birch::log(birch::_u0960(), handler_);
  #line 47 "src/math/special.birch"
  libbirch_line_(47);
  #line 47 "src/math/special.birch"
  for (auto i = birch::type::Integer(1); i <= p; ++i) {
    #line 48 "src/math/special.birch"
    libbirch_line_(48);
    #line 48 "src/math/special.birch"
    y = y * birch::gamma(x + 0.5 * (birch::type::Integer(1) - i), handler_);
  }
  #line 50 "src/math/special.birch"
  libbirch_line_(50);
  #line 50 "src/math/special.birch"
  return y;
}

#line 56 "src/math/special.birch"
birch::type::Real32 birch::gamma(const birch::type::Real32& x, const birch::type::Integer& p, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 56 "src/math/special.birch"
  libbirch_function_("gamma", "src/math/special.birch", 56);
  #line 57 "src/math/special.birch"
  libbirch_line_(57);
  #line 57 "src/math/special.birch"
  libbirch_assert_(p > birch::type::Integer(0));
  #line 58 "src/math/special.birch"
  libbirch_line_(58);
  #line 58 "src/math/special.birch"
  auto y = birch::Real32(0.25, handler_) * birch::Real32(p * (p - birch::type::Integer(1)), handler_) * birch::log(birch::Real32(birch::_u0960(), handler_), handler_);
  #line 59 "src/math/special.birch"
  libbirch_line_(59);
  #line 59 "src/math/special.birch"
  for (auto i = birch::type::Integer(1); i <= p; ++i) {
    #line 60 "src/math/special.birch"
    libbirch_line_(60);
    #line 60 "src/math/special.birch"
    y = y * birch::gamma(x + birch::Real32(0.5, handler_) * birch::Real32(birch::type::Integer(1) - i, handler_), handler_);
  }
  #line 62 "src/math/special.birch"
  libbirch_line_(62);
  #line 62 "src/math/special.birch"
  return y;
}

#line 68 "src/math/special.birch"
birch::type::Real64 birch::lgamma(const birch::type::Real64& x, const birch::type::Integer& p, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 68 "src/math/special.birch"
  libbirch_function_("lgamma", "src/math/special.birch", 68);
  #line 69 "src/math/special.birch"
  libbirch_line_(69);
  #line 69 "src/math/special.birch"
  libbirch_assert_(p > birch::type::Integer(0));
  #line 70 "src/math/special.birch"
  libbirch_line_(70);
  #line 70 "src/math/special.birch"
  auto y = 0.25 * (p * (p - birch::type::Integer(1))) * birch::log(birch::_u0960(), handler_);
  #line 71 "src/math/special.birch"
  libbirch_line_(71);
  #line 71 "src/math/special.birch"
  for (auto i = birch::type::Integer(1); i <= p; ++i) {
    #line 72 "src/math/special.birch"
    libbirch_line_(72);
    #line 72 "src/math/special.birch"
    y = y + birch::lgamma(x + 0.5 * (birch::type::Integer(1) - i), handler_);
  }
  #line 74 "src/math/special.birch"
  libbirch_line_(74);
  #line 74 "src/math/special.birch"
  return y;
}

#line 80 "src/math/special.birch"
birch::type::Real32 birch::lgamma(const birch::type::Real32& x, const birch::type::Integer& p, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 80 "src/math/special.birch"
  libbirch_function_("lgamma", "src/math/special.birch", 80);
  #line 81 "src/math/special.birch"
  libbirch_line_(81);
  #line 81 "src/math/special.birch"
  libbirch_assert_(p > birch::type::Integer(0));
  #line 82 "src/math/special.birch"
  libbirch_line_(82);
  #line 82 "src/math/special.birch"
  auto y = birch::Real32(0.25, handler_) * birch::Real32(p * (p - birch::type::Integer(1)), handler_) * birch::log(birch::Real32(birch::_u0960(), handler_), handler_);
  #line 83 "src/math/special.birch"
  libbirch_line_(83);
  #line 83 "src/math/special.birch"
  for (auto i = birch::type::Integer(1); i <= p; ++i) {
    #line 84 "src/math/special.birch"
    libbirch_line_(84);
    #line 84 "src/math/special.birch"
    y = y + birch::lgamma(x + birch::Real32(0.5, handler_) * birch::Real32(birch::type::Integer(1) - i, handler_), handler_);
  }
  #line 86 "src/math/special.birch"
  libbirch_line_(86);
  #line 86 "src/math/special.birch"
  return y;
}

#line 92 "src/math/special.birch"
birch::type::Real64 birch::beta(const birch::type::Real64& x, const birch::type::Real64& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 92 "src/math/special.birch"
  libbirch_function_("beta", "src/math/special.birch", 92);
  #line 93 "src/math/special.birch"
return boost::math::beta(x, y);
  }

#line 101 "src/math/special.birch"
birch::type::Real32 birch::beta(const birch::type::Real32& x, const birch::type::Real32& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 101 "src/math/special.birch"
  libbirch_function_("beta", "src/math/special.birch", 101);
  #line 102 "src/math/special.birch"
return boost::math::beta(x, y);
  }

#line 110 "src/math/special.birch"
birch::type::Real64 birch::ibeta(const birch::type::Real64& a, const birch::type::Real64& b, const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 110 "src/math/special.birch"
  libbirch_function_("ibeta", "src/math/special.birch", 110);
  #line 111 "src/math/special.birch"
return boost::math::ibeta(a, b, x);
  }

#line 119 "src/math/special.birch"
birch::type::Real32 birch::ibeta(const birch::type::Real32& a, const birch::type::Real32& b, const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 119 "src/math/special.birch"
  libbirch_function_("ibeta", "src/math/special.birch", 119);
  #line 120 "src/math/special.birch"
return boost::math::ibeta(a, b, x);
  }

#line 128 "src/math/special.birch"
birch::type::Real64 birch::lbeta(const birch::type::Real64& x, const birch::type::Real64& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 128 "src/math/special.birch"
  libbirch_function_("lbeta", "src/math/special.birch", 128);
  #line 129 "src/math/special.birch"
  libbirch_line_(129);
  #line 129 "src/math/special.birch"
  return birch::lgamma(x, handler_) + birch::lgamma(y, handler_) - birch::lgamma(x + y, handler_);
}

#line 135 "src/math/special.birch"
birch::type::Real32 birch::lbeta(const birch::type::Real32& x, const birch::type::Real32& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 135 "src/math/special.birch"
  libbirch_function_("lbeta", "src/math/special.birch", 135);
  #line 136 "src/math/special.birch"
  libbirch_line_(136);
  #line 136 "src/math/special.birch"
  return birch::lgamma(x, handler_) + birch::lgamma(y, handler_) - birch::lgamma(x + y, handler_);
}

#line 142 "src/math/special.birch"
birch::type::Real64 birch::digamma(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 142 "src/math/special.birch"
  libbirch_function_("digamma", "src/math/special.birch", 142);
  #line 143 "src/math/special.birch"
return boost::math::digamma(x);
  }

#line 151 "src/math/special.birch"
birch::type::Real32 birch::digamma(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 151 "src/math/special.birch"
  libbirch_function_("digamma", "src/math/special.birch", 151);
  #line 152 "src/math/special.birch"
return boost::math::digamma(x);
  }

#line 160 "src/math/special.birch"
birch::type::Real64 birch::choose(const birch::type::Integer& x, const birch::type::Integer& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 160 "src/math/special.birch"
  libbirch_function_("choose", "src/math/special.birch", 160);
  #line 161 "src/math/special.birch"
  libbirch_line_(161);
  #line 161 "src/math/special.birch"
  libbirch_assert_(birch::type::Integer(0) <= x);
  #line 162 "src/math/special.birch"
  libbirch_line_(162);
  #line 162 "src/math/special.birch"
  libbirch_assert_(birch::type::Integer(0) <= y);
  #line 163 "src/math/special.birch"
  libbirch_line_(163);
  #line 163 "src/math/special.birch"
  libbirch_assert_(x >= y);
  #line 165 "src/math/special.birch"
  libbirch_line_(165);
  #line 165 "src/math/special.birch"
  if (y == birch::type::Integer(0)) {
    #line 166 "src/math/special.birch"
    libbirch_line_(166);
    #line 166 "src/math/special.birch"
    return 1.0;
  } else {
    #line 169 "src/math/special.birch"
    libbirch_line_(169);
    #line 169 "src/math/special.birch"
    return 1.0 / (birch::Real(y, handler_) * birch::beta(birch::Real(y, handler_), birch::Real(x - y + birch::type::Integer(1), handler_), handler_));
  }
}

#line 176 "src/math/special.birch"
birch::type::Real64 birch::choose(const birch::type::Real64& x, const birch::type::Real64& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 176 "src/math/special.birch"
  libbirch_function_("choose", "src/math/special.birch", 176);
  #line 177 "src/math/special.birch"
  libbirch_line_(177);
  #line 177 "src/math/special.birch"
  libbirch_assert_(0.0 <= x);
  #line 178 "src/math/special.birch"
  libbirch_line_(178);
  #line 178 "src/math/special.birch"
  libbirch_assert_(0.0 <= y);
  #line 179 "src/math/special.birch"
  libbirch_line_(179);
  #line 179 "src/math/special.birch"
  libbirch_assert_(x >= y);
  #line 181 "src/math/special.birch"
  libbirch_line_(181);
  #line 181 "src/math/special.birch"
  if (y == 0.0) {
    #line 182 "src/math/special.birch"
    libbirch_line_(182);
    #line 182 "src/math/special.birch"
    return 1.0;
  } else {
    #line 185 "src/math/special.birch"
    libbirch_line_(185);
    #line 185 "src/math/special.birch"
    return 1.0 / (y * birch::beta(y, x - y + 1.0, handler_));
  }
}

#line 192 "src/math/special.birch"
birch::type::Real32 birch::choose(const birch::type::Real32& x, const birch::type::Real32& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 192 "src/math/special.birch"
  libbirch_function_("choose", "src/math/special.birch", 192);
  #line 193 "src/math/special.birch"
  libbirch_line_(193);
  #line 193 "src/math/special.birch"
  libbirch_assert_(birch::Real32(0.0, handler_) <= x);
  #line 194 "src/math/special.birch"
  libbirch_line_(194);
  #line 194 "src/math/special.birch"
  libbirch_assert_(birch::Real32(0.0, handler_) <= y);
  #line 195 "src/math/special.birch"
  libbirch_line_(195);
  #line 195 "src/math/special.birch"
  libbirch_assert_(x >= y);
  #line 197 "src/math/special.birch"
  libbirch_line_(197);
  #line 197 "src/math/special.birch"
  if (y == birch::Real32(0.0, handler_)) {
    #line 198 "src/math/special.birch"
    libbirch_line_(198);
    #line 198 "src/math/special.birch"
    return birch::Real32(1.0, handler_);
  } else {
    #line 201 "src/math/special.birch"
    libbirch_line_(201);
    #line 201 "src/math/special.birch"
    return birch::Real32(1.0, handler_) / (y * birch::beta(y, x - y + birch::Real32(1.0, handler_), handler_));
  }
}

#line 208 "src/math/special.birch"
birch::type::Real64 birch::lchoose(const birch::type::Integer& x, const birch::type::Integer& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 208 "src/math/special.birch"
  libbirch_function_("lchoose", "src/math/special.birch", 208);
  #line 209 "src/math/special.birch"
  libbirch_line_(209);
  #line 209 "src/math/special.birch"
  libbirch_assert_(birch::type::Integer(0) <= x);
  #line 210 "src/math/special.birch"
  libbirch_line_(210);
  #line 210 "src/math/special.birch"
  libbirch_assert_(birch::type::Integer(0) <= y);
  #line 211 "src/math/special.birch"
  libbirch_line_(211);
  #line 211 "src/math/special.birch"
  libbirch_assert_(x >= y);
  #line 213 "src/math/special.birch"
  libbirch_line_(213);
  #line 213 "src/math/special.birch"
  if (y == birch::type::Integer(0)) {
    #line 214 "src/math/special.birch"
    libbirch_line_(214);
    #line 214 "src/math/special.birch"
    return 0.0;
  } else {
    #line 217 "src/math/special.birch"
    libbirch_line_(217);
    #line 217 "src/math/special.birch"
    return -birch::log(birch::Real(y, handler_), handler_) - birch::lbeta(birch::Real(y, handler_), birch::Real(x - y + birch::type::Integer(1), handler_), handler_);
  }
}

#line 224 "src/math/special.birch"
birch::type::Real64 birch::lchoose(const birch::type::Real64& x, const birch::type::Real64& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 224 "src/math/special.birch"
  libbirch_function_("lchoose", "src/math/special.birch", 224);
  #line 225 "src/math/special.birch"
  libbirch_line_(225);
  #line 225 "src/math/special.birch"
  libbirch_assert_(0.0 <= x);
  #line 226 "src/math/special.birch"
  libbirch_line_(226);
  #line 226 "src/math/special.birch"
  libbirch_assert_(0.0 <= y);
  #line 227 "src/math/special.birch"
  libbirch_line_(227);
  #line 227 "src/math/special.birch"
  libbirch_assert_(x >= y);
  #line 229 "src/math/special.birch"
  libbirch_line_(229);
  #line 229 "src/math/special.birch"
  if (y == 0.0) {
    #line 230 "src/math/special.birch"
    libbirch_line_(230);
    #line 230 "src/math/special.birch"
    return 0.0;
  } else {
    #line 233 "src/math/special.birch"
    libbirch_line_(233);
    #line 233 "src/math/special.birch"
    return -birch::log(y, handler_) - birch::lbeta(y, x - y + 1.0, handler_);
  }
}

#line 240 "src/math/special.birch"
birch::type::Real32 birch::lchoose(const birch::type::Real32& x, const birch::type::Real32& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 240 "src/math/special.birch"
  libbirch_function_("lchoose", "src/math/special.birch", 240);
  #line 241 "src/math/special.birch"
  libbirch_line_(241);
  #line 241 "src/math/special.birch"
  libbirch_assert_(birch::Real32(0.0, handler_) <= x);
  #line 242 "src/math/special.birch"
  libbirch_line_(242);
  #line 242 "src/math/special.birch"
  libbirch_assert_(birch::Real32(0.0, handler_) <= y);
  #line 243 "src/math/special.birch"
  libbirch_line_(243);
  #line 243 "src/math/special.birch"
  libbirch_assert_(x >= y);
  #line 245 "src/math/special.birch"
  libbirch_line_(245);
  #line 245 "src/math/special.birch"
  if (y == birch::Real32(0.0, handler_)) {
    #line 246 "src/math/special.birch"
    libbirch_line_(246);
    #line 246 "src/math/special.birch"
    return birch::log(birch::Real32(1.0, handler_), handler_);
  } else {
    #line 249 "src/math/special.birch"
    libbirch_line_(249);
    #line 249 "src/math/special.birch"
    return -birch::log(y, handler_) - birch::lbeta(y, x - y + birch::Real32(1.0, handler_), handler_);
  }
}

#line 4 "src/math/standard.birch"
birch::type::Real64& birch::_u0960() {
  #line 4 "src/math/standard.birch"
  static birch::type::Real64 result = 3.1415926535897932384626433832795;
  #line 4 "src/math/standard.birch"
  return result;
}

#line 9 "src/math/standard.birch"
birch::type::Real64& birch::inf() {
  #line 9 "src/math/standard.birch"
  static birch::type::Real64 result = 1.0 / 0.0;
  #line 9 "src/math/standard.birch"
  return result;
}

#line 14 "src/math/standard.birch"
birch::type::Real64& birch::nan() {
  #line 14 "src/math/standard.birch"
  static birch::type::Real64 result = 0.0 / 0.0;
  #line 14 "src/math/standard.birch"
  return result;
}

#line 19 "src/math/standard.birch"
birch::type::Real64 birch::log(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/math/standard.birch"
  libbirch_function_("log", "src/math/standard.birch", 19);
  #line 20 "src/math/standard.birch"
return ::log(x);
  }

#line 28 "src/math/standard.birch"
birch::type::Real32 birch::log(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/math/standard.birch"
  libbirch_function_("log", "src/math/standard.birch", 28);
  #line 29 "src/math/standard.birch"
return ::logf(x);
  }

#line 37 "src/math/standard.birch"
birch::type::Real64 birch::log1p(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/math/standard.birch"
  libbirch_function_("log1p", "src/math/standard.birch", 37);
  #line 38 "src/math/standard.birch"
return ::log1p(x);
  }

#line 46 "src/math/standard.birch"
birch::type::Real32 birch::log1p(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/math/standard.birch"
  libbirch_function_("log1p", "src/math/standard.birch", 46);
  #line 47 "src/math/standard.birch"
return ::log1pf(x);
  }

#line 55 "src/math/standard.birch"
birch::type::Real64 birch::log2(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 55 "src/math/standard.birch"
  libbirch_function_("log2", "src/math/standard.birch", 55);
  #line 56 "src/math/standard.birch"
return ::log2(x);
  }

#line 64 "src/math/standard.birch"
birch::type::Real32 birch::log2(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "src/math/standard.birch"
  libbirch_function_("log2", "src/math/standard.birch", 64);
  #line 65 "src/math/standard.birch"
return ::log2f(x);
  }

#line 73 "src/math/standard.birch"
birch::type::Real64 birch::log10(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 73 "src/math/standard.birch"
  libbirch_function_("log10", "src/math/standard.birch", 73);
  #line 74 "src/math/standard.birch"
return ::log10(x);
  }

#line 82 "src/math/standard.birch"
birch::type::Real32 birch::log10(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 82 "src/math/standard.birch"
  libbirch_function_("log10", "src/math/standard.birch", 82);
  #line 83 "src/math/standard.birch"
return ::log10f(x);
  }

#line 91 "src/math/standard.birch"
birch::type::Real64 birch::exp(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 91 "src/math/standard.birch"
  libbirch_function_("exp", "src/math/standard.birch", 91);
  #line 92 "src/math/standard.birch"
return ::exp(x);
  }

#line 100 "src/math/standard.birch"
birch::type::Real32 birch::exp(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 100 "src/math/standard.birch"
  libbirch_function_("exp", "src/math/standard.birch", 100);
  #line 101 "src/math/standard.birch"
return ::expf(x);
  }

#line 109 "src/math/standard.birch"
birch::type::Real64 birch::sqrt(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 109 "src/math/standard.birch"
  libbirch_function_("sqrt", "src/math/standard.birch", 109);
  #line 110 "src/math/standard.birch"
return ::sqrt(x);
  }

#line 118 "src/math/standard.birch"
birch::type::Real32 birch::sqrt(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 118 "src/math/standard.birch"
  libbirch_function_("sqrt", "src/math/standard.birch", 118);
  #line 119 "src/math/standard.birch"
return ::sqrtf(x);
  }

#line 127 "src/math/standard.birch"
birch::type::Real64 birch::ceil(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 127 "src/math/standard.birch"
  libbirch_function_("ceil", "src/math/standard.birch", 127);
  #line 128 "src/math/standard.birch"
return ::ceil(x);
  }

#line 136 "src/math/standard.birch"
birch::type::Real32 birch::ceil(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 136 "src/math/standard.birch"
  libbirch_function_("ceil", "src/math/standard.birch", 136);
  #line 137 "src/math/standard.birch"
return ::ceilf(x);
  }

#line 145 "src/math/standard.birch"
birch::type::Real64 birch::floor(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 145 "src/math/standard.birch"
  libbirch_function_("floor", "src/math/standard.birch", 145);
  #line 146 "src/math/standard.birch"
return ::floor(x);
  }

#line 154 "src/math/standard.birch"
birch::type::Real32 birch::floor(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 154 "src/math/standard.birch"
  libbirch_function_("floor", "src/math/standard.birch", 154);
  #line 155 "src/math/standard.birch"
return ::floorf(x);
  }

#line 163 "src/math/standard.birch"
birch::type::Real64 birch::round(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 163 "src/math/standard.birch"
  libbirch_function_("round", "src/math/standard.birch", 163);
  #line 164 "src/math/standard.birch"
return ::round(x);
  }

#line 172 "src/math/standard.birch"
birch::type::Real32 birch::round(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 172 "src/math/standard.birch"
  libbirch_function_("round", "src/math/standard.birch", 172);
  #line 173 "src/math/standard.birch"
return ::roundf(x);
  }

#line 181 "src/math/standard.birch"
birch::type::Real64 birch::sin(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 181 "src/math/standard.birch"
  libbirch_function_("sin", "src/math/standard.birch", 181);
  #line 182 "src/math/standard.birch"
return ::sin(x);
  }

#line 190 "src/math/standard.birch"
birch::type::Real32 birch::sin(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 190 "src/math/standard.birch"
  libbirch_function_("sin", "src/math/standard.birch", 190);
  #line 191 "src/math/standard.birch"
return ::sinf(x);
  }

#line 199 "src/math/standard.birch"
birch::type::Real64 birch::cos(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 199 "src/math/standard.birch"
  libbirch_function_("cos", "src/math/standard.birch", 199);
  #line 200 "src/math/standard.birch"
return ::cos(x);
  }

#line 208 "src/math/standard.birch"
birch::type::Real32 birch::cos(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 208 "src/math/standard.birch"
  libbirch_function_("cos", "src/math/standard.birch", 208);
  #line 209 "src/math/standard.birch"
return ::cosf(x);
  }

#line 217 "src/math/standard.birch"
birch::type::Real64 birch::tan(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 217 "src/math/standard.birch"
  libbirch_function_("tan", "src/math/standard.birch", 217);
  #line 218 "src/math/standard.birch"
return ::tan(x);
  }

#line 226 "src/math/standard.birch"
birch::type::Real32 birch::tan(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 226 "src/math/standard.birch"
  libbirch_function_("tan", "src/math/standard.birch", 226);
  #line 227 "src/math/standard.birch"
return ::tanf(x);
  }

#line 235 "src/math/standard.birch"
birch::type::Real64 birch::asin(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 235 "src/math/standard.birch"
  libbirch_function_("asin", "src/math/standard.birch", 235);
  #line 236 "src/math/standard.birch"
return ::asin(x);
  }

#line 244 "src/math/standard.birch"
birch::type::Real32 birch::asin(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 244 "src/math/standard.birch"
  libbirch_function_("asin", "src/math/standard.birch", 244);
  #line 245 "src/math/standard.birch"
return  ::asinf(x);
  }

#line 253 "src/math/standard.birch"
birch::type::Real64 birch::acos(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 253 "src/math/standard.birch"
  libbirch_function_("acos", "src/math/standard.birch", 253);
  #line 254 "src/math/standard.birch"
return ::acos(x);
  }

#line 262 "src/math/standard.birch"
birch::type::Real32 birch::acos(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 262 "src/math/standard.birch"
  libbirch_function_("acos", "src/math/standard.birch", 262);
  #line 263 "src/math/standard.birch"
return ::acosf(x);
  }

#line 271 "src/math/standard.birch"
birch::type::Real64 birch::atan(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 271 "src/math/standard.birch"
  libbirch_function_("atan", "src/math/standard.birch", 271);
  #line 272 "src/math/standard.birch"
return ::atan(x);
  }

#line 280 "src/math/standard.birch"
birch::type::Real32 birch::atan(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 280 "src/math/standard.birch"
  libbirch_function_("atan", "src/math/standard.birch", 280);
  #line 281 "src/math/standard.birch"
return ::atanf(x);
  }

#line 289 "src/math/standard.birch"
birch::type::Real64 birch::atan2(const birch::type::Real64& x, const birch::type::Real64& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 289 "src/math/standard.birch"
  libbirch_function_("atan2", "src/math/standard.birch", 289);
  #line 290 "src/math/standard.birch"
return ::atan2(x, y);
  }

#line 298 "src/math/standard.birch"
birch::type::Real32 birch::atan2(const birch::type::Real32& x, const birch::type::Real32& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 298 "src/math/standard.birch"
  libbirch_function_("atan2", "src/math/standard.birch", 298);
  #line 299 "src/math/standard.birch"
return ::atan2f(x, y);
  }

#line 307 "src/math/standard.birch"
birch::type::Real64 birch::sinh(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 307 "src/math/standard.birch"
  libbirch_function_("sinh", "src/math/standard.birch", 307);
  #line 308 "src/math/standard.birch"
return ::sinh(x);
  }

#line 316 "src/math/standard.birch"
birch::type::Real32 birch::sinh(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 316 "src/math/standard.birch"
  libbirch_function_("sinh", "src/math/standard.birch", 316);
  #line 317 "src/math/standard.birch"
return ::sinhf(x);
  }

#line 325 "src/math/standard.birch"
birch::type::Real64 birch::cosh(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 325 "src/math/standard.birch"
  libbirch_function_("cosh", "src/math/standard.birch", 325);
  #line 326 "src/math/standard.birch"
return ::cosh(x);
  }

#line 334 "src/math/standard.birch"
birch::type::Real32 birch::cosh(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 334 "src/math/standard.birch"
  libbirch_function_("cosh", "src/math/standard.birch", 334);
  #line 335 "src/math/standard.birch"
return ::coshf(x);
  }

#line 343 "src/math/standard.birch"
birch::type::Real64 birch::tanh(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 343 "src/math/standard.birch"
  libbirch_function_("tanh", "src/math/standard.birch", 343);
  #line 344 "src/math/standard.birch"
return ::tanh(x);
  }

#line 352 "src/math/standard.birch"
birch::type::Real32 birch::tanh(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 352 "src/math/standard.birch"
  libbirch_function_("tanh", "src/math/standard.birch", 352);
  #line 353 "src/math/standard.birch"
return ::tanhf(x);
  }

#line 361 "src/math/standard.birch"
birch::type::Real64 birch::asinh(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 361 "src/math/standard.birch"
  libbirch_function_("asinh", "src/math/standard.birch", 361);
  #line 362 "src/math/standard.birch"
return ::asinh(x);
  }

#line 370 "src/math/standard.birch"
birch::type::Real32 birch::asinh(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 370 "src/math/standard.birch"
  libbirch_function_("asinh", "src/math/standard.birch", 370);
  #line 371 "src/math/standard.birch"
return ::asinhf(x);
  }

#line 379 "src/math/standard.birch"
birch::type::Real64 birch::acosh(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 379 "src/math/standard.birch"
  libbirch_function_("acosh", "src/math/standard.birch", 379);
  #line 380 "src/math/standard.birch"
return ::acosh(x);
  }

#line 388 "src/math/standard.birch"
birch::type::Real32 birch::acosh(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 388 "src/math/standard.birch"
  libbirch_function_("acosh", "src/math/standard.birch", 388);
  #line 389 "src/math/standard.birch"
return ::acoshf(x);
  }

#line 397 "src/math/standard.birch"
birch::type::Real64 birch::atanh(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 397 "src/math/standard.birch"
  libbirch_function_("atanh", "src/math/standard.birch", 397);
  #line 398 "src/math/standard.birch"
return ::atanh(x);
  }

#line 406 "src/math/standard.birch"
birch::type::Real32 birch::atanh(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 406 "src/math/standard.birch"
  libbirch_function_("atanh", "src/math/standard.birch", 406);
  #line 407 "src/math/standard.birch"
return ::atanhf(x);
  }

#line 415 "src/math/standard.birch"
birch::type::Real64 birch::erf(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 415 "src/math/standard.birch"
  libbirch_function_("erf", "src/math/standard.birch", 415);
  #line 416 "src/math/standard.birch"
return ::erf(x);
  }

#line 424 "src/math/standard.birch"
birch::type::Real32 birch::erf(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 424 "src/math/standard.birch"
  libbirch_function_("erf", "src/math/standard.birch", 424);
  #line 425 "src/math/standard.birch"
return ::erff(x);
  }

#line 433 "src/math/standard.birch"
birch::type::Real64 birch::erfc(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 433 "src/math/standard.birch"
  libbirch_function_("erfc", "src/math/standard.birch", 433);
  #line 434 "src/math/standard.birch"
return ::erfc(x);
  }

#line 442 "src/math/standard.birch"
birch::type::Real32 birch::erfc(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 442 "src/math/standard.birch"
  libbirch_function_("erfc", "src/math/standard.birch", 442);
  #line 443 "src/math/standard.birch"
return ::erfcf(x);
  }

#line 451 "src/math/standard.birch"
birch::type::Real64 birch::copysign(const birch::type::Real64& x, const birch::type::Real64& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 451 "src/math/standard.birch"
  libbirch_function_("copysign", "src/math/standard.birch", 451);
  #line 452 "src/math/standard.birch"
return ::copysign(x, y);
  }

#line 460 "src/math/standard.birch"
birch::type::Real32 birch::copysign(const birch::type::Real32& x, const birch::type::Real32& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 460 "src/math/standard.birch"
  libbirch_function_("copysign", "src/math/standard.birch", 460);
  #line 461 "src/math/standard.birch"
return ::copysignf(x, y);
  }

#line 469 "src/math/standard.birch"
birch::type::Real64 birch::rectify(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 469 "src/math/standard.birch"
  libbirch_function_("rectify", "src/math/standard.birch", 469);
  #line 470 "src/math/standard.birch"
  libbirch_line_(470);
  #line 470 "src/math/standard.birch"
  return birch::max(0.0, x, handler_);
}

#line 476 "src/math/standard.birch"
birch::type::Real32 birch::rectify(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 476 "src/math/standard.birch"
  libbirch_function_("rectify", "src/math/standard.birch", 476);
  #line 477 "src/math/standard.birch"
  libbirch_line_(477);
  #line 477 "src/math/standard.birch"
  return birch::max(birch::Real32(0.0, handler_), x, handler_);
}

#line 10 "src/math/update.birch"
libbirch::Tuple<birch::type::Real, birch::type::Real> birch::update_beta_bernoulli(const birch::type::Boolean& x, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/math/update.birch"
  libbirch_function_("update_beta_bernoulli", "src/math/update.birch", 10);
  #line 11 "src/math/update.birch"
  libbirch_line_(11);
  #line 11 "src/math/update.birch"
  if (x) {
    #line 12 "src/math/update.birch"
    libbirch_line_(12);
    #line 12 "src/math/update.birch"
    return libbirch::make_tuple(_u0945 + 1.0, _u0946);
  } else {
    #line 14 "src/math/update.birch"
    libbirch_line_(14);
    #line 14 "src/math/update.birch"
    return libbirch::make_tuple(_u0945, _u0946 + 1.0);
  }
}

#line 28 "src/math/update.birch"
libbirch::Tuple<birch::type::Real, birch::type::Real> birch::update_beta_binomial(const birch::type::Integer& x, const birch::type::Integer& n, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/math/update.birch"
  libbirch_function_("update_beta_binomial", "src/math/update.birch", 28);
  #line 30 "src/math/update.birch"
  libbirch_line_(30);
  #line 30 "src/math/update.birch"
  libbirch_assert_(birch::type::Integer(0) <= x && x <= n);
  #line 31 "src/math/update.birch"
  libbirch_line_(31);
  #line 31 "src/math/update.birch"
  libbirch_assert_(birch::type::Integer(0) <= n);
  #line 32 "src/math/update.birch"
  libbirch_line_(32);
  #line 32 "src/math/update.birch"
  libbirch_assert_(0.0 < _u0945);
  #line 33 "src/math/update.birch"
  libbirch_line_(33);
  #line 33 "src/math/update.birch"
  libbirch_assert_(0.0 < _u0946);
  #line 34 "src/math/update.birch"
  libbirch_line_(34);
  #line 34 "src/math/update.birch"
  return libbirch::make_tuple(_u0945 + x, _u0946 + n - x);
}

#line 47 "src/math/update.birch"
libbirch::Tuple<birch::type::Real, birch::type::Real> birch::update_beta_negative_binomial(const birch::type::Integer& x, const birch::type::Integer& k, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "src/math/update.birch"
  libbirch_function_("update_beta_negative_binomial", "src/math/update.birch", 47);
  #line 49 "src/math/update.birch"
  libbirch_line_(49);
  #line 49 "src/math/update.birch"
  return libbirch::make_tuple(_u0945 + k, _u0946 + x);
}

#line 61 "src/math/update.birch"
libbirch::Tuple<birch::type::Real, birch::type::Real> birch::update_gamma_poisson(const birch::type::Integer& x, const birch::type::Real& k, const birch::type::Real& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "src/math/update.birch"
  libbirch_function_("update_gamma_poisson", "src/math/update.birch", 61);
  #line 62 "src/math/update.birch"
  libbirch_line_(62);
  #line 62 "src/math/update.birch"
  return libbirch::make_tuple(k + x, _u0952 / (_u0952 + 1.0));
}

#line 76 "src/math/update.birch"
libbirch::Tuple<birch::type::Real, birch::type::Real> birch::update_scaled_gamma_poisson(const birch::type::Integer& x, const birch::type::Real& a, const birch::type::Real& k, const birch::type::Real& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "src/math/update.birch"
  libbirch_function_("update_scaled_gamma_poisson", "src/math/update.birch", 76);
  #line 78 "src/math/update.birch"
  libbirch_line_(78);
  #line 78 "src/math/update.birch"
  return libbirch::make_tuple(k + x, _u0952 / (a * _u0952 + 1.0));
}

#line 91 "src/math/update.birch"
libbirch::Tuple<birch::type::Real, birch::type::Real> birch::update_gamma_exponential(const birch::type::Real& x, const birch::type::Real& k, const birch::type::Real& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 91 "src/math/update.birch"
  libbirch_function_("update_gamma_exponential", "src/math/update.birch", 91);
  #line 92 "src/math/update.birch"
  libbirch_line_(92);
  #line 92 "src/math/update.birch"
  return libbirch::make_tuple(k + 1.0, _u0952 / (1.0 + x * _u0952));
}

#line 106 "src/math/update.birch"
libbirch::Tuple<birch::type::Real, birch::type::Real> birch::update_scaled_gamma_exponential(const birch::type::Real& x, const birch::type::Real& a, const birch::type::Real& k, const birch::type::Real& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 106 "src/math/update.birch"
  libbirch_function_("update_scaled_gamma_exponential", "src/math/update.birch", 106);
  #line 107 "src/math/update.birch"
  libbirch_line_(107);
  #line 107 "src/math/update.birch"
  return libbirch::make_tuple(k + 1.0, _u0952 / (1.0 + x * a * _u0952));
}

#line 121 "src/math/update.birch"
libbirch::Tuple<birch::type::Real, birch::type::Real> birch::update_inverse_gamma_weibull(const birch::type::Real& x, const birch::type::Real& k, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 121 "src/math/update.birch"
  libbirch_function_("update_inverse_gamma_weibull", "src/math/update.birch", 121);
  #line 122 "src/math/update.birch"
  libbirch_line_(122);
  #line 122 "src/math/update.birch"
  return libbirch::make_tuple(_u0945 + 1.0, _u0946 + birch::pow(x, k, handler_));
}

#line 137 "src/math/update.birch"
libbirch::Tuple<birch::type::Real, birch::type::Real> birch::update_scaled_inverse_gamma_weibull(const birch::type::Real& x, const birch::type::Real& k, const birch::type::Real& a, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 137 "src/math/update.birch"
  libbirch_function_("update_scaled_inverse_gamma_weibull", "src/math/update.birch", 137);
  #line 138 "src/math/update.birch"
  libbirch_line_(138);
  #line 138 "src/math/update.birch"
  return libbirch::make_tuple(_u0945 + 1.0, _u0946 + birch::pow(x, k, handler_) / a);
}

#line 150 "src/math/update.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::update_dirichlet_categorical(const birch::type::Integer& x, const libbirch::DefaultArray<birch::type::Real,1>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 150 "src/math/update.birch"
  libbirch_function_("update_dirichlet_categorical", "src/math/update.birch", 150);
  #line 151 "src/math/update.birch"
  libbirch_line_(151);
  #line 151 "src/math/update.birch"
  auto _u0945_prime_ = _u0945;
  #line 152 "src/math/update.birch"
  libbirch_line_(152);
  #line 152 "src/math/update.birch"
  _u0945_prime_.set(libbirch::make_slice(x - 1), _u0945_prime_.get(libbirch::make_slice(x - 1)) + 1.0);
  #line 153 "src/math/update.birch"
  libbirch_line_(153);
  #line 153 "src/math/update.birch"
  return _u0945_prime_;
}

#line 166 "src/math/update.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::update_dirichlet_multinomial(const libbirch::DefaultArray<birch::type::Integer,1>& x, const birch::type::Integer& n, const libbirch::DefaultArray<birch::type::Real,1>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 166 "src/math/update.birch"
  libbirch_function_("update_dirichlet_multinomial", "src/math/update.birch", 166);
  #line 168 "src/math/update.birch"
  libbirch_line_(168);
  #line 168 "src/math/update.birch"
  libbirch_assert_(birch::sum(x, handler_) == n);
  #line 171 "src/math/update.birch"
  libbirch_line_(171);
  #line 171 "src/math/update.birch"
  auto _u0945_prime_ = _u0945;
  #line 172 "src/math/update.birch"
  libbirch_line_(172);
  #line 172 "src/math/update.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(_u0945, handler_); ++i) {
    #line 173 "src/math/update.birch"
    libbirch_line_(173);
    #line 173 "src/math/update.birch"
    _u0945_prime_.set(libbirch::make_slice(i - 1), _u0945.get(libbirch::make_slice(i - 1)) + x.get(libbirch::make_slice(i - 1)));
  }
  #line 175 "src/math/update.birch"
  libbirch_line_(175);
  #line 175 "src/math/update.birch"
  return _u0945_prime_;
}

#line 189 "src/math/update.birch"
libbirch::Tuple<birch::type::Real, birch::type::Real> birch::update_gaussian_gaussian(const birch::type::Real& x, const birch::type::Real& _u0956, const birch::type::Real& _u09632, const birch::type::Real& s2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 189 "src/math/update.birch"
  libbirch_function_("update_gaussian_gaussian", "src/math/update.birch", 189);
  #line 191 "src/math/update.birch"
  libbirch_line_(191);
  #line 191 "src/math/update.birch"
  auto _u0955 = 1.0 / _u09632;
  #line 192 "src/math/update.birch"
  libbirch_line_(192);
  #line 192 "src/math/update.birch"
  auto l = 1.0 / s2;
  #line 193 "src/math/update.birch"
  libbirch_line_(193);
  #line 193 "src/math/update.birch"
  auto _u0955_prime_ = _u0955 + l;
  #line 194 "src/math/update.birch"
  libbirch_line_(194);
  #line 194 "src/math/update.birch"
  auto _u0956_prime_ = (_u0955 * _u0956 + l * x) / _u0955_prime_;
  #line 195 "src/math/update.birch"
  libbirch_line_(195);
  #line 195 "src/math/update.birch"
  return libbirch::make_tuple(_u0956_prime_, 1.0 / _u0955_prime_);
}

#line 211 "src/math/update.birch"
libbirch::Tuple<birch::type::Real, birch::type::Real> birch::update_linear_gaussian_gaussian(const birch::type::Real& x, const birch::type::Real& a, const birch::type::Real& _u0956, const birch::type::Real& _u09632, const birch::type::Real& c, const birch::type::Real& s2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 211 "src/math/update.birch"
  libbirch_function_("update_linear_gaussian_gaussian", "src/math/update.birch", 211);
  #line 213 "src/math/update.birch"
  libbirch_line_(213);
  #line 213 "src/math/update.birch"
  auto _u0955 = 1.0 / _u09632;
  #line 214 "src/math/update.birch"
  libbirch_line_(214);
  #line 214 "src/math/update.birch"
  auto l = 1.0 / s2;
  #line 215 "src/math/update.birch"
  libbirch_line_(215);
  #line 215 "src/math/update.birch"
  auto _u0955_prime_ = _u0955 + a * a * l;
  #line 216 "src/math/update.birch"
  libbirch_line_(216);
  #line 216 "src/math/update.birch"
  auto _u0956_prime_ = (_u0955 * _u0956 + a * l * (x - c)) / _u0955_prime_;
  #line 217 "src/math/update.birch"
  libbirch_line_(217);
  #line 217 "src/math/update.birch"
  return libbirch::make_tuple(_u0956_prime_, 1.0 / _u0955_prime_);
}

#line 232 "src/math/update.birch"
libbirch::Tuple<birch::type::Real, birch::type::Real> birch::update_normal_inverse_gamma(const birch::type::Real& x, const birch::type::Real& _u0956, const birch::type::Real& _u0955, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 232 "src/math/update.birch"
  libbirch_function_("update_normal_inverse_gamma", "src/math/update.birch", 232);
  #line 234 "src/math/update.birch"
  libbirch_line_(234);
  #line 234 "src/math/update.birch"
  return libbirch::make_tuple(_u0945 + 0.5, _u0946 + 0.5 * birch::pow(x - _u0956, 2.0, handler_) * _u0955);
}

#line 249 "src/math/update.birch"
libbirch::Tuple<birch::type::Real, birch::type::Real, birch::type::Real, birch::type::Real> birch::update_normal_inverse_gamma_gaussian(const birch::type::Real& x, const birch::type::Real& _u0956, const birch::type::Real& _u0955, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 249 "src/math/update.birch"
  libbirch_function_("update_normal_inverse_gamma_gaussian", "src/math/update.birch", 249);
  #line 251 "src/math/update.birch"
  libbirch_line_(251);
  #line 251 "src/math/update.birch"
  auto _u0955_prime_ = _u0955 + 1.0;
  #line 252 "src/math/update.birch"
  libbirch_line_(252);
  #line 252 "src/math/update.birch"
  auto _u0956_prime_ = (_u0955 * _u0956 + x) / _u0955_prime_;
  #line 253 "src/math/update.birch"
  libbirch_line_(253);
  #line 253 "src/math/update.birch"
  auto _u0945_prime_ = _u0945 + 0.5;
  #line 254 "src/math/update.birch"
  libbirch_line_(254);
  #line 254 "src/math/update.birch"
  auto _u0946_prime_ = _u0946 + 0.5 * (_u0955 / _u0955_prime_) * birch::pow(x - _u0956, 2.0, handler_);
  #line 256 "src/math/update.birch"
  libbirch_line_(256);
  #line 256 "src/math/update.birch"
  return libbirch::make_tuple(_u0956_prime_, _u0955_prime_, _u0945_prime_, _u0946_prime_);
}

#line 273 "src/math/update.birch"
libbirch::Tuple<birch::type::Real, birch::type::Real, birch::type::Real, birch::type::Real> birch::update_linear_normal_inverse_gamma_gaussian(const birch::type::Real& x, const birch::type::Real& a, const birch::type::Real& _u0956, const birch::type::Real& _u0955, const birch::type::Real& c, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 273 "src/math/update.birch"
  libbirch_function_("update_linear_normal_inverse_gamma_gaussian", "src/math/update.birch", 273);
  #line 275 "src/math/update.birch"
  libbirch_line_(275);
  #line 275 "src/math/update.birch"
  auto y = x - c;
  #line 276 "src/math/update.birch"
  libbirch_line_(276);
  #line 276 "src/math/update.birch"
  auto _u0955_prime_ = _u0955 + a * a;
  #line 277 "src/math/update.birch"
  libbirch_line_(277);
  #line 277 "src/math/update.birch"
  auto _u0956_prime_ = (_u0955 * _u0956 + a * y) / _u0955_prime_;
  #line 278 "src/math/update.birch"
  libbirch_line_(278);
  #line 278 "src/math/update.birch"
  auto _u0945_prime_ = _u0945 + 0.5;
  #line 279 "src/math/update.birch"
  libbirch_line_(279);
  #line 279 "src/math/update.birch"
  auto _u0946_prime_ = _u0946 + 0.5 * (y * y + _u0956 * _u0956 * _u0955 - _u0956_prime_ * _u0956_prime_ * _u0955_prime_);
  #line 281 "src/math/update.birch"
  libbirch_line_(281);
  #line 281 "src/math/update.birch"
  return libbirch::make_tuple(_u0956_prime_, _u0955_prime_, _u0945_prime_, _u0946_prime_);
}

#line 295 "src/math/update.birch"
libbirch::Tuple<birch::type::Real, birch::type::Real> birch::update_inverse_gamma_gamma(const birch::type::Real& x, const birch::type::Real& k, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 295 "src/math/update.birch"
  libbirch_function_("update_inverse_gamma_gamma", "src/math/update.birch", 295);
  #line 297 "src/math/update.birch"
  libbirch_line_(297);
  #line 297 "src/math/update.birch"
  return libbirch::make_tuple(_u0945 + k, _u0946 + x);
}

#line 311 "src/math/update.birch"
libbirch::Tuple<libbirch::DefaultArray<birch::type::Real,1>, birch::type::LLT> birch::update_multivariate_gaussian_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const birch::type::LLT& _u0931, const birch::type::LLT& S, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 311 "src/math/update.birch"
  libbirch_function_("update_multivariate_gaussian_multivariate_gaussian", "src/math/update.birch", 311);
  #line 313 "src/math/update.birch"
  libbirch_line_(313);
  #line 313 "src/math/update.birch"
  auto _u09310 = birch::canonical(_u0931, handler_);
  #line 314 "src/math/update.birch"
  libbirch_line_(314);
  #line 314 "src/math/update.birch"
  auto S0 = birch::canonical(S, handler_);
  #line 315 "src/math/update.birch"
  libbirch_line_(315);
  #line 315 "src/math/update.birch"
  auto K_prime_ = birch::transpose(birch::solve(birch::llt(_u09310 + S0, handler_), _u09310, handler_), handler_);
  #line 316 "src/math/update.birch"
  libbirch_line_(316);
  #line 316 "src/math/update.birch"
  auto _u0956_prime_ = _u0956 + K_prime_ * (x - _u0956);
  #line 317 "src/math/update.birch"
  libbirch_line_(317);
  #line 317 "src/math/update.birch"
  auto _u0931_prime_ = birch::llt(_u09310 - K_prime_ * _u09310, handler_);
  #line 318 "src/math/update.birch"
  libbirch_line_(318);
  #line 318 "src/math/update.birch"
  return libbirch::make_tuple(_u0956_prime_, _u0931_prime_);
}

#line 334 "src/math/update.birch"
libbirch::Tuple<libbirch::DefaultArray<birch::type::Real,1>, birch::type::LLT> birch::update_linear_multivariate_gaussian_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,2>& A, const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const birch::type::LLT& _u0931, const libbirch::DefaultArray<birch::type::Real,1>& c, const birch::type::LLT& S, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 334 "src/math/update.birch"
  libbirch_function_("update_linear_multivariate_gaussian_multivariate_gaussian", "src/math/update.birch", 334);
  #line 336 "src/math/update.birch"
  libbirch_line_(336);
  #line 336 "src/math/update.birch"
  auto _u09310 = birch::canonical(_u0931, handler_);
  #line 337 "src/math/update.birch"
  libbirch_line_(337);
  #line 337 "src/math/update.birch"
  auto S0 = birch::canonical(S, handler_);
  #line 338 "src/math/update.birch"
  libbirch_line_(338);
  #line 338 "src/math/update.birch"
  auto K_prime_ = _u09310 * birch::transpose(birch::solve(birch::llt(A * _u09310 * birch::transpose(A, handler_) + S0, handler_), A, handler_), handler_);
  #line 339 "src/math/update.birch"
  libbirch_line_(339);
  #line 339 "src/math/update.birch"
  auto _u0956_prime_ = _u0956 + K_prime_ * (x - A * _u0956 - c);
  #line 340 "src/math/update.birch"
  libbirch_line_(340);
  #line 340 "src/math/update.birch"
  auto _u0931_prime_ = birch::llt(_u09310 - K_prime_ * A * _u09310, handler_);
  #line 341 "src/math/update.birch"
  libbirch_line_(341);
  #line 341 "src/math/update.birch"
  return libbirch::make_tuple(_u0956_prime_, _u0931_prime_);
}

#line 358 "src/math/update.birch"
libbirch::Tuple<libbirch::DefaultArray<birch::type::Real,1>, birch::type::LLT> birch::update_linear_multivariate_gaussian_gaussian(const birch::type::Real& x, const libbirch::DefaultArray<birch::type::Real,1>& a, const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const birch::type::LLT& _u0931, const birch::type::Real& c, const birch::type::Real& s2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 358 "src/math/update.birch"
  libbirch_function_("update_linear_multivariate_gaussian_gaussian", "src/math/update.birch", 358);
  #line 360 "src/math/update.birch"
  libbirch_line_(360);
  #line 360 "src/math/update.birch"
  auto _u09310 = birch::canonical(_u0931, handler_);
  #line 361 "src/math/update.birch"
  libbirch_line_(361);
  #line 361 "src/math/update.birch"
  auto k_prime_ = _u09310 * a / (birch::dot(a, _u09310 * a, handler_) + s2);
  #line 362 "src/math/update.birch"
  libbirch_line_(362);
  #line 362 "src/math/update.birch"
  auto _u0956_prime_ = _u0956 + k_prime_ * (x - birch::dot(a, _u0956, handler_) - c);
  #line 363 "src/math/update.birch"
  libbirch_line_(363);
  #line 363 "src/math/update.birch"
  auto _u0931_prime_ = birch::llt(_u09310 - birch::outer(k_prime_, a, handler_) * _u09310, handler_);
  #line 364 "src/math/update.birch"
  libbirch_line_(364);
  #line 364 "src/math/update.birch"
  return libbirch::make_tuple(_u0956_prime_, _u0931_prime_);
}

#line 379 "src/math/update.birch"
libbirch::Tuple<birch::type::Real, birch::type::Real> birch::update_multivariate_normal_inverse_gamma(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& _u0957, const birch::type::LLT& _u0923, const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 379 "src/math/update.birch"
  libbirch_function_("update_multivariate_normal_inverse_gamma", "src/math/update.birch", 379);
  #line 381 "src/math/update.birch"
  libbirch_line_(381);
  #line 381 "src/math/update.birch"
  auto D = birch::length(x, handler_);
  #line 382 "src/math/update.birch"
  libbirch_line_(382);
  #line 382 "src/math/update.birch"
  auto _u0956 = birch::solve(_u0923, _u0957, handler_);
  #line 383 "src/math/update.birch"
  libbirch_line_(383);
  #line 383 "src/math/update.birch"
  return libbirch::make_tuple(_u0945 + 0.5 * D, _u0946 + 0.5 * birch::dot(x - _u0956, birch::canonical(_u0923, handler_) * (x - _u0956), handler_));
}

#line 398 "src/math/update.birch"
libbirch::Tuple<libbirch::DefaultArray<birch::type::Real,1>, birch::type::LLT, birch::type::Real, birch::type::Real> birch::update_multivariate_normal_inverse_gamma_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& _u0957, const birch::type::LLT& _u0923, const birch::type::Real& _u0945, const birch::type::Real& _u0947, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 398 "src/math/update.birch"
  libbirch_function_("update_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/math/update.birch", 398);
  #line 401 "src/math/update.birch"
  libbirch_line_(401);
  #line 401 "src/math/update.birch"
  auto D = birch::length(x, handler_);
  #line 402 "src/math/update.birch"
  libbirch_line_(402);
  #line 402 "src/math/update.birch"
  auto _u0923_prime_ = birch::rank_update(_u0923, birch::identity(birch::rows(_u0923, handler_), handler_), handler_);
  #line 403 "src/math/update.birch"
  libbirch_line_(403);
  #line 403 "src/math/update.birch"
  auto _u0957_prime_ = _u0957 + x;
  #line 404 "src/math/update.birch"
  libbirch_line_(404);
  #line 404 "src/math/update.birch"
  auto _u0945_prime_ = _u0945 + 0.5 * D;
  #line 405 "src/math/update.birch"
  libbirch_line_(405);
  #line 405 "src/math/update.birch"
  auto _u0947_prime_ = _u0947 + 0.5 * birch::dot(x, handler_);
  #line 406 "src/math/update.birch"
  libbirch_line_(406);
  #line 406 "src/math/update.birch"
  return libbirch::make_tuple(_u0957_prime_, _u0923_prime_, _u0945_prime_, _u0947_prime_);
}

#line 423 "src/math/update.birch"
libbirch::Tuple<libbirch::DefaultArray<birch::type::Real,1>, birch::type::LLT, birch::type::Real, birch::type::Real> birch::update_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,2>& A, const libbirch::DefaultArray<birch::type::Real,1>& _u0957, const birch::type::LLT& _u0923, const libbirch::DefaultArray<birch::type::Real,1>& c, const birch::type::Real& _u0945, const birch::type::Real& _u0947, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 423 "src/math/update.birch"
  libbirch_function_("update_linear_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/math/update.birch", 423);
  #line 426 "src/math/update.birch"
  libbirch_line_(426);
  #line 426 "src/math/update.birch"
  auto D = birch::length(x, handler_);
  #line 427 "src/math/update.birch"
  libbirch_line_(427);
  #line 427 "src/math/update.birch"
  auto _u0923_prime_ = birch::rank_update(_u0923, birch::transpose(A, handler_), handler_);
  #line 428 "src/math/update.birch"
  libbirch_line_(428);
  #line 428 "src/math/update.birch"
  auto _u0957_prime_ = _u0957 + birch::transpose(A, handler_) * (x - c);
  #line 429 "src/math/update.birch"
  libbirch_line_(429);
  #line 429 "src/math/update.birch"
  auto _u0945_prime_ = _u0945 + 0.5 * D;
  #line 430 "src/math/update.birch"
  libbirch_line_(430);
  #line 430 "src/math/update.birch"
  auto _u0947_prime_ = _u0947 + 0.5 * birch::dot(x - c, handler_);
  #line 431 "src/math/update.birch"
  libbirch_line_(431);
  #line 431 "src/math/update.birch"
  return libbirch::make_tuple(_u0957_prime_, _u0923_prime_, _u0945_prime_, _u0947_prime_);
}

#line 448 "src/math/update.birch"
libbirch::Tuple<libbirch::DefaultArray<birch::type::Real,1>, birch::type::LLT, birch::type::Real, birch::type::Real> birch::update_linear_multivariate_normal_inverse_gamma_gaussian(const birch::type::Real& x, const libbirch::DefaultArray<birch::type::Real,1>& a, const libbirch::DefaultArray<birch::type::Real,1>& _u0957, const birch::type::LLT& _u0923, const birch::type::Real& c, const birch::type::Real& _u0945, const birch::type::Real& _u0947, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 448 "src/math/update.birch"
  libbirch_function_("update_linear_multivariate_normal_inverse_gamma_gaussian", "src/math/update.birch", 448);
  #line 451 "src/math/update.birch"
  libbirch_line_(451);
  #line 451 "src/math/update.birch"
  auto _u0923_prime_ = birch::rank_update(_u0923, a, handler_);
  #line 452 "src/math/update.birch"
  libbirch_line_(452);
  #line 452 "src/math/update.birch"
  auto _u0957_prime_ = _u0957 + a * (x - c);
  #line 453 "src/math/update.birch"
  libbirch_line_(453);
  #line 453 "src/math/update.birch"
  auto _u0945_prime_ = _u0945 + 0.5;
  #line 454 "src/math/update.birch"
  libbirch_line_(454);
  #line 454 "src/math/update.birch"
  auto _u0947_prime_ = _u0947 + 0.5 * birch::pow(x - c, 2.0, handler_);
  #line 455 "src/math/update.birch"
  libbirch_line_(455);
  #line 455 "src/math/update.birch"
  return libbirch::make_tuple(_u0957_prime_, _u0923_prime_, _u0945_prime_, _u0947_prime_);
}

#line 469 "src/math/update.birch"
libbirch::Tuple<birch::type::LLT, birch::type::Real> birch::update_matrix_normal_inverse_wishart(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& _u0923, const birch::type::LLT& V, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 469 "src/math/update.birch"
  libbirch_function_("update_matrix_normal_inverse_wishart", "src/math/update.birch", 469);
  #line 471 "src/math/update.birch"
  libbirch_line_(471);
  #line 471 "src/math/update.birch"
  auto D = birch::rows(X, handler_);
  #line 472 "src/math/update.birch"
  libbirch_line_(472);
  #line 472 "src/math/update.birch"
  auto M = birch::solve(_u0923, N, handler_);
  #line 473 "src/math/update.birch"
  libbirch_line_(473);
  #line 473 "src/math/update.birch"
  auto V_prime_ = birch::rank_update(V, birch::transpose(X - M, handler_), handler_);
  #line 474 "src/math/update.birch"
  libbirch_line_(474);
  #line 474 "src/math/update.birch"
  auto k_prime_ = k + D;
  #line 475 "src/math/update.birch"
  libbirch_line_(475);
  #line 475 "src/math/update.birch"
  return libbirch::make_tuple(V_prime_, k_prime_);
}

#line 490 "src/math/update.birch"
libbirch::Tuple<libbirch::DefaultArray<birch::type::Real,2>, birch::type::LLT, birch::type::LLT, birch::type::Real> birch::update_matrix_normal_inverse_wishart_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& _u0923, const birch::type::LLT& V, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 490 "src/math/update.birch"
  libbirch_function_("update_matrix_normal_inverse_wishart_matrix_gaussian", "src/math/update.birch", 490);
  #line 492 "src/math/update.birch"
  libbirch_line_(492);
  #line 492 "src/math/update.birch"
  auto D = birch::rows(X, handler_);
  #line 493 "src/math/update.birch"
  libbirch_line_(493);
  #line 493 "src/math/update.birch"
  auto _u0923_prime_ = birch::rank_update(_u0923, birch::identity(birch::rows(N, handler_), handler_), handler_);
  #line 494 "src/math/update.birch"
  libbirch_line_(494);
  #line 494 "src/math/update.birch"
  auto N_prime_ = N + X;
  #line 495 "src/math/update.birch"
  libbirch_line_(495);
  #line 495 "src/math/update.birch"
  auto M = birch::solve(_u0923, N, handler_);
  #line 496 "src/math/update.birch"
  libbirch_line_(496);
  #line 496 "src/math/update.birch"
  auto M_prime_ = birch::solve(_u0923_prime_, N_prime_, handler_);
  #line 497 "src/math/update.birch"
  libbirch_line_(497);
  #line 497 "src/math/update.birch"
  auto V_prime_ = birch::llt(birch::canonical(V, handler_) + birch::transpose(X - M_prime_, handler_) * (X - M_prime_) + birch::transpose(M_prime_ - M, handler_) * birch::canonical(_u0923, handler_) * (M_prime_ - M), handler_);
  #line 499 "src/math/update.birch"
  libbirch_line_(499);
  #line 499 "src/math/update.birch"
  auto k_prime_ = k + D;
  #line 500 "src/math/update.birch"
  libbirch_line_(500);
  #line 500 "src/math/update.birch"
  return libbirch::make_tuple(N_prime_, _u0923_prime_, V_prime_, k_prime_);
}

#line 517 "src/math/update.birch"
libbirch::Tuple<libbirch::DefaultArray<birch::type::Real,2>, birch::type::LLT, birch::type::LLT, birch::type::Real> birch::update_linear_matrix_normal_inverse_wishart_matrix_gaussian(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::DefaultArray<birch::type::Real,2>& A, const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& _u0923, const libbirch::DefaultArray<birch::type::Real,2>& C, const birch::type::LLT& V, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 517 "src/math/update.birch"
  libbirch_function_("update_linear_matrix_normal_inverse_wishart_matrix_gaussian", "src/math/update.birch", 517);
  #line 520 "src/math/update.birch"
  libbirch_line_(520);
  #line 520 "src/math/update.birch"
  auto D = birch::rows(X, handler_);
  #line 521 "src/math/update.birch"
  libbirch_line_(521);
  #line 521 "src/math/update.birch"
  auto _u0923_prime_ = birch::rank_update(_u0923, birch::transpose(A, handler_), handler_);
  #line 522 "src/math/update.birch"
  libbirch_line_(522);
  #line 522 "src/math/update.birch"
  auto N_prime_ = N + birch::transpose(A, handler_) * (X - C);
  #line 523 "src/math/update.birch"
  libbirch_line_(523);
  #line 523 "src/math/update.birch"
  auto M = birch::solve(_u0923, N, handler_);
  #line 524 "src/math/update.birch"
  libbirch_line_(524);
  #line 524 "src/math/update.birch"
  auto M_prime_ = birch::solve(_u0923_prime_, N_prime_, handler_);
  #line 525 "src/math/update.birch"
  libbirch_line_(525);
  #line 525 "src/math/update.birch"
  auto V_prime_ = birch::llt(birch::canonical(V, handler_) + birch::transpose(X - A * M_prime_ - C, handler_) * (X - A * M_prime_ - C) + birch::transpose(M_prime_ - M, handler_) * birch::canonical(_u0923, handler_) * (M_prime_ - M), handler_);
  #line 527 "src/math/update.birch"
  libbirch_line_(527);
  #line 527 "src/math/update.birch"
  auto k_prime_ = k + D;
  #line 528 "src/math/update.birch"
  libbirch_line_(528);
  #line 528 "src/math/update.birch"
  return libbirch::make_tuple(N_prime_, _u0923_prime_, V_prime_, k_prime_);
}

#line 545 "src/math/update.birch"
libbirch::Tuple<libbirch::DefaultArray<birch::type::Real,2>, birch::type::LLT, birch::type::LLT, birch::type::Real> birch::update_linear_matrix_normal_inverse_wishart_multivariate_gaussian(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::DefaultArray<birch::type::Real,1>& a, const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& _u0923, const libbirch::DefaultArray<birch::type::Real,1>& c, const birch::type::LLT& V, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 545 "src/math/update.birch"
  libbirch_function_("update_linear_matrix_normal_inverse_wishart_multivariate_gaussian", "src/math/update.birch", 545);
  #line 548 "src/math/update.birch"
  libbirch_line_(548);
  #line 548 "src/math/update.birch"
  auto _u0923_prime_ = birch::rank_update(_u0923, a, handler_);
  #line 549 "src/math/update.birch"
  libbirch_line_(549);
  #line 549 "src/math/update.birch"
  auto N_prime_ = N + a * birch::transpose(x - c, handler_);
  #line 550 "src/math/update.birch"
  libbirch_line_(550);
  #line 550 "src/math/update.birch"
  auto M = birch::solve(_u0923, N, handler_);
  #line 551 "src/math/update.birch"
  libbirch_line_(551);
  #line 551 "src/math/update.birch"
  auto M_prime_ = birch::solve(_u0923_prime_, N_prime_, handler_);
  #line 552 "src/math/update.birch"
  libbirch_line_(552);
  #line 552 "src/math/update.birch"
  auto V_prime_ = birch::llt(birch::canonical(V, handler_) + birch::outer(x - birch::dot(a, M_prime_, handler_) - c, handler_) + birch::transpose(M_prime_ - M, handler_) * birch::canonical(_u0923, handler_) * (M_prime_ - M), handler_);
  #line 554 "src/math/update.birch"
  libbirch_line_(554);
  #line 554 "src/math/update.birch"
  auto k_prime_ = k + birch::type::Integer(1);
  #line 555 "src/math/update.birch"
  libbirch_line_(555);
  #line 555 "src/math/update.birch"
  return libbirch::make_tuple(N_prime_, _u0923_prime_, V_prime_, k_prime_);
}

#line 10 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::update_lazy_beta_bernoulli(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Boolean>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_beta_bernoulli", "src/math/update_lazy.birch", 10);
  #line 13 "src/math/update_lazy.birch"
  libbirch_line_(13);
  #line 13 "src/math/update_lazy.birch"
  return libbirch::make_tuple(_u0945 + birch::Real(x, handler_), _u0946 + (1.0 - birch::Real(x, handler_)));
}

#line 26 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::update_lazy_beta_binomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& n, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_beta_binomial", "src/math/update_lazy.birch", 26);
  #line 29 "src/math/update_lazy.birch"
  libbirch_line_(29);
  #line 29 "src/math/update_lazy.birch"
  return libbirch::make_tuple(_u0945 + birch::Real(x, handler_), _u0946 + birch::Real(n - x, handler_));
}

#line 42 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::update_lazy_beta_negative_binomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_beta_negative_binomial", "src/math/update_lazy.birch", 42);
  #line 45 "src/math/update_lazy.birch"
  libbirch_line_(45);
  #line 45 "src/math/update_lazy.birch"
  return libbirch::make_tuple(_u0945 + birch::Real(k, handler_), _u0946 + birch::Real(x, handler_));
}

#line 57 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::update_lazy_gamma_poisson(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 57 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_gamma_poisson", "src/math/update_lazy.birch", 57);
  #line 59 "src/math/update_lazy.birch"
  libbirch_line_(59);
  #line 59 "src/math/update_lazy.birch"
  return libbirch::make_tuple(k + birch::Real(x, handler_), _u0952 / (_u0952 + 1.0));
}

#line 73 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::update_lazy_scaled_gamma_poisson(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 73 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_scaled_gamma_poisson", "src/math/update_lazy.birch", 73);
  #line 76 "src/math/update_lazy.birch"
  libbirch_line_(76);
  #line 76 "src/math/update_lazy.birch"
  return libbirch::make_tuple(k + birch::Real(x, handler_), _u0952 / (a * _u0952 + 1.0));
}

#line 89 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::update_lazy_gamma_exponential(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 89 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_gamma_exponential", "src/math/update_lazy.birch", 89);
  #line 92 "src/math/update_lazy.birch"
  libbirch_line_(92);
  #line 92 "src/math/update_lazy.birch"
  return libbirch::make_tuple(k + 1.0, _u0952 / (1.0 + x * _u0952));
}

#line 106 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::update_lazy_scaled_gamma_exponential(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 106 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_scaled_gamma_exponential", "src/math/update_lazy.birch", 106);
  #line 109 "src/math/update_lazy.birch"
  libbirch_line_(109);
  #line 109 "src/math/update_lazy.birch"
  return libbirch::make_tuple(k + 1.0, _u0952 / (1.0 + x * a * _u0952));
}

#line 123 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::update_lazy_inverse_gamma_weibull(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 123 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_inverse_gamma_weibull", "src/math/update_lazy.birch", 123);
  #line 126 "src/math/update_lazy.birch"
  libbirch_line_(126);
  #line 126 "src/math/update_lazy.birch"
  return libbirch::make_tuple(_u0945 + 1.0, _u0946 + birch::pow(x, k, handler_));
}

#line 141 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::update_lazy_scaled_inverse_gamma_weibull(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 141 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_scaled_inverse_gamma_weibull", "src/math/update_lazy.birch", 141);
  #line 144 "src/math/update_lazy.birch"
  libbirch_line_(144);
  #line 144 "src/math/update_lazy.birch"
  return libbirch::make_tuple(_u0945 + 1.0, _u0946 + birch::pow(x, k, handler_) / a);
}

#line 187 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::update_lazy_gaussian_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& s2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 187 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_gaussian_gaussian", "src/math/update_lazy.birch", 187);
  #line 190 "src/math/update_lazy.birch"
  libbirch_line_(190);
  #line 190 "src/math/update_lazy.birch"
  auto _u0955 = 1.0 / _u09632;
  #line 191 "src/math/update_lazy.birch"
  libbirch_line_(191);
  #line 191 "src/math/update_lazy.birch"
  auto l = 1.0 / s2;
  #line 192 "src/math/update_lazy.birch"
  libbirch_line_(192);
  #line 192 "src/math/update_lazy.birch"
  auto _u0955_prime_ = _u0955 + l;
  #line 193 "src/math/update_lazy.birch"
  libbirch_line_(193);
  #line 193 "src/math/update_lazy.birch"
  auto _u0956_prime_ = (_u0955 * _u0956 + l * x) / _u0955_prime_;
  #line 194 "src/math/update_lazy.birch"
  libbirch_line_(194);
  #line 194 "src/math/update_lazy.birch"
  return libbirch::make_tuple(_u0956_prime_, 1.0 / _u0955_prime_);
}

#line 210 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::update_lazy_linear_gaussian_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& s2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 210 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_linear_gaussian_gaussian", "src/math/update_lazy.birch", 210);
  #line 213 "src/math/update_lazy.birch"
  libbirch_line_(213);
  #line 213 "src/math/update_lazy.birch"
  auto _u0955 = 1.0 / _u09632;
  #line 214 "src/math/update_lazy.birch"
  libbirch_line_(214);
  #line 214 "src/math/update_lazy.birch"
  auto l = 1.0 / s2;
  #line 215 "src/math/update_lazy.birch"
  libbirch_line_(215);
  #line 215 "src/math/update_lazy.birch"
  auto _u0955_prime_ = _u0955 + a * a * l;
  #line 216 "src/math/update_lazy.birch"
  libbirch_line_(216);
  #line 216 "src/math/update_lazy.birch"
  auto _u0956_prime_ = (_u0955 * _u0956 + a * l * (x - c)) / _u0955_prime_;
  #line 217 "src/math/update_lazy.birch"
  libbirch_line_(217);
  #line 217 "src/math/update_lazy.birch"
  return libbirch::make_tuple(_u0956_prime_, 1.0 / _u0955_prime_);
}

#line 232 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::update_lazy_normal_inverse_gamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 232 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_normal_inverse_gamma", "src/math/update_lazy.birch", 232);
  #line 235 "src/math/update_lazy.birch"
  libbirch_line_(235);
  #line 235 "src/math/update_lazy.birch"
  return libbirch::make_tuple(_u0945 + 0.5, _u0946 + 0.5 * birch::pow(x - _u0956, 2.0, handler_) * _u0955);
}

#line 250 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::update_lazy_normal_inverse_gamma_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 250 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_normal_inverse_gamma_gaussian", "src/math/update_lazy.birch", 250);
  #line 254 "src/math/update_lazy.birch"
  libbirch_line_(254);
  #line 254 "src/math/update_lazy.birch"
  auto _u0955_prime_ = _u0955 + 1.0;
  #line 255 "src/math/update_lazy.birch"
  libbirch_line_(255);
  #line 255 "src/math/update_lazy.birch"
  auto _u0956_prime_ = (_u0955 * _u0956 + x) / _u0955_prime_;
  #line 256 "src/math/update_lazy.birch"
  libbirch_line_(256);
  #line 256 "src/math/update_lazy.birch"
  auto _u0945_prime_ = _u0945 + 0.5;
  #line 257 "src/math/update_lazy.birch"
  libbirch_line_(257);
  #line 257 "src/math/update_lazy.birch"
  auto _u0946_prime_ = _u0946 + 0.5 * (_u0955 / _u0955_prime_) * birch::pow(x - _u0956, 2.0, handler_);
  #line 258 "src/math/update_lazy.birch"
  libbirch_line_(258);
  #line 258 "src/math/update_lazy.birch"
  return libbirch::make_tuple(_u0956_prime_, _u0955_prime_, _u0945_prime_, _u0946_prime_);
}

#line 275 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::update_lazy_linear_normal_inverse_gamma_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 275 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_linear_normal_inverse_gamma_gaussian", "src/math/update_lazy.birch", 275);
  #line 279 "src/math/update_lazy.birch"
  libbirch_line_(279);
  #line 279 "src/math/update_lazy.birch"
  auto y = x - c;
  #line 280 "src/math/update_lazy.birch"
  libbirch_line_(280);
  #line 280 "src/math/update_lazy.birch"
  auto _u0955_prime_ = _u0955 + a * a;
  #line 281 "src/math/update_lazy.birch"
  libbirch_line_(281);
  #line 281 "src/math/update_lazy.birch"
  auto _u0956_prime_ = (_u0955 * _u0956 + a * y) / _u0955_prime_;
  #line 282 "src/math/update_lazy.birch"
  libbirch_line_(282);
  #line 282 "src/math/update_lazy.birch"
  auto _u0945_prime_ = _u0945 + 0.5;
  #line 283 "src/math/update_lazy.birch"
  libbirch_line_(283);
  #line 283 "src/math/update_lazy.birch"
  auto _u0946_prime_ = _u0946 + 0.5 * (y * y + _u0956 * _u0956 * _u0955 - _u0956_prime_ * _u0956_prime_ * _u0955_prime_);
  #line 284 "src/math/update_lazy.birch"
  libbirch_line_(284);
  #line 284 "src/math/update_lazy.birch"
  return libbirch::make_tuple(_u0956_prime_, _u0955_prime_, _u0945_prime_, _u0946_prime_);
}

#line 298 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::update_lazy_inverse_gamma_gamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 298 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_inverse_gamma_gamma", "src/math/update_lazy.birch", 298);
  #line 301 "src/math/update_lazy.birch"
  libbirch_line_(301);
  #line 301 "src/math/update_lazy.birch"
  return libbirch::make_tuple(_u0945 + k, _u0946 + x);
}

#line 315 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>> birch::update_lazy_multivariate_gaussian_multivariate_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& S, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 315 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_multivariate_gaussian_multivariate_gaussian", "src/math/update_lazy.birch", 315);
  #line 318 "src/math/update_lazy.birch"
  libbirch_line_(318);
  #line 318 "src/math/update_lazy.birch"
  auto _u09310 = birch::canonical(_u0931, handler_);
  #line 319 "src/math/update_lazy.birch"
  libbirch_line_(319);
  #line 319 "src/math/update_lazy.birch"
  auto S0 = birch::canonical(S, handler_);
  #line 320 "src/math/update_lazy.birch"
  libbirch_line_(320);
  #line 320 "src/math/update_lazy.birch"
  auto K_prime_ = birch::transpose(birch::solve(birch::llt(_u09310 + S0, handler_), _u09310, handler_), handler_);
  #line 321 "src/math/update_lazy.birch"
  libbirch_line_(321);
  #line 321 "src/math/update_lazy.birch"
  auto _u0956_prime_ = _u0956 + K_prime_ * (x - _u0956);
  #line 322 "src/math/update_lazy.birch"
  libbirch_line_(322);
  #line 322 "src/math/update_lazy.birch"
  auto _u0931_prime_ = birch::llt(_u09310 - K_prime_ * _u09310, handler_);
  #line 323 "src/math/update_lazy.birch"
  libbirch_line_(323);
  #line 323 "src/math/update_lazy.birch"
  return libbirch::make_tuple(_u0956_prime_, _u0931_prime_);
}

#line 339 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>> birch::update_lazy_linear_multivariate_gaussian_multivariate_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& A, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& S, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 339 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_linear_multivariate_gaussian_multivariate_gaussian", "src/math/update_lazy.birch", 339);
  #line 343 "src/math/update_lazy.birch"
  libbirch_line_(343);
  #line 343 "src/math/update_lazy.birch"
  auto _u09310 = birch::canonical(_u0931, handler_);
  #line 344 "src/math/update_lazy.birch"
  libbirch_line_(344);
  #line 344 "src/math/update_lazy.birch"
  auto S0 = birch::canonical(S, handler_);
  #line 345 "src/math/update_lazy.birch"
  libbirch_line_(345);
  #line 345 "src/math/update_lazy.birch"
  auto K_prime_ = _u09310 * birch::transpose(birch::solve(birch::llt(A * _u09310 * birch::transpose(A, handler_) + S0, handler_), A, handler_), handler_);
  #line 346 "src/math/update_lazy.birch"
  libbirch_line_(346);
  #line 346 "src/math/update_lazy.birch"
  auto _u0956_prime_ = _u0956 + K_prime_ * (x - A * _u0956 - c);
  #line 347 "src/math/update_lazy.birch"
  libbirch_line_(347);
  #line 347 "src/math/update_lazy.birch"
  auto _u0931_prime_ = birch::llt(_u09310 - K_prime_ * A * _u09310, handler_);
  #line 348 "src/math/update_lazy.birch"
  libbirch_line_(348);
  #line 348 "src/math/update_lazy.birch"
  return libbirch::make_tuple(_u0956_prime_, _u0931_prime_);
}

#line 365 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>> birch::update_lazy_linear_multivariate_gaussian_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& s2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 365 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_linear_multivariate_gaussian_gaussian", "src/math/update_lazy.birch", 365);
  #line 369 "src/math/update_lazy.birch"
  libbirch_line_(369);
  #line 369 "src/math/update_lazy.birch"
  auto _u09310 = birch::canonical(_u0931, handler_);
  #line 370 "src/math/update_lazy.birch"
  libbirch_line_(370);
  #line 370 "src/math/update_lazy.birch"
  auto k_prime_ = _u09310 * a / (birch::dot(a, _u09310 * a, handler_) + s2);
  #line 371 "src/math/update_lazy.birch"
  libbirch_line_(371);
  #line 371 "src/math/update_lazy.birch"
  auto _u0956_prime_ = _u0956 + k_prime_ * (x - birch::dot(a, _u0956, handler_) - c);
  #line 372 "src/math/update_lazy.birch"
  libbirch_line_(372);
  #line 372 "src/math/update_lazy.birch"
  auto _u0931_prime_ = birch::llt(_u09310 - birch::outer(k_prime_, a, handler_) * _u09310, handler_);
  #line 373 "src/math/update_lazy.birch"
  libbirch_line_(373);
  #line 373 "src/math/update_lazy.birch"
  return libbirch::make_tuple(_u0956_prime_, _u0931_prime_);
}

#line 388 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::update_lazy_multivariate_normal_inverse_gamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0923, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 388 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_multivariate_normal_inverse_gamma", "src/math/update_lazy.birch", 388);
  #line 391 "src/math/update_lazy.birch"
  libbirch_line_(391);
  #line 391 "src/math/update_lazy.birch"
  auto D = x->length(handler_);
  #line 392 "src/math/update_lazy.birch"
  libbirch_line_(392);
  #line 392 "src/math/update_lazy.birch"
  auto _u0956 = birch::solve(_u0923, _u0957, handler_);
  #line 393 "src/math/update_lazy.birch"
  libbirch_line_(393);
  #line 393 "src/math/update_lazy.birch"
  return libbirch::make_tuple(_u0945 + 0.5 * D, _u0946 + 0.5 * birch::dot(x - _u0956, birch::canonical(_u0923, handler_) * (x - _u0956), handler_));
}

#line 408 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::update_lazy_multivariate_normal_inverse_gamma_multivariate_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0923, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0947, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 408 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/math/update_lazy.birch", 408);
  #line 412 "src/math/update_lazy.birch"
  libbirch_line_(412);
  #line 412 "src/math/update_lazy.birch"
  auto D = x->length(handler_);
  #line 413 "src/math/update_lazy.birch"
  libbirch_line_(413);
  #line 413 "src/math/update_lazy.birch"
  auto _u0923_prime_ = birch::rank_update(_u0923, birch::identity(birch::rows(_u0923, handler_), handler_), handler_);
  #line 414 "src/math/update_lazy.birch"
  libbirch_line_(414);
  #line 414 "src/math/update_lazy.birch"
  auto _u0957_prime_ = _u0957 + x;
  #line 415 "src/math/update_lazy.birch"
  libbirch_line_(415);
  #line 415 "src/math/update_lazy.birch"
  auto _u0945_prime_ = _u0945 + 0.5 * D;
  #line 416 "src/math/update_lazy.birch"
  libbirch_line_(416);
  #line 416 "src/math/update_lazy.birch"
  auto _u0947_prime_ = _u0947 + 0.5 * birch::dot(x, handler_);
  #line 417 "src/math/update_lazy.birch"
  libbirch_line_(417);
  #line 417 "src/math/update_lazy.birch"
  return libbirch::make_tuple(_u0957_prime_, _u0923_prime_, _u0945_prime_, _u0947_prime_);
}

#line 434 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::update_lazy_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& A, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0923, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0947, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 434 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_linear_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/math/update_lazy.birch", 434);
  #line 439 "src/math/update_lazy.birch"
  libbirch_line_(439);
  #line 439 "src/math/update_lazy.birch"
  auto D = birch::length(x, handler_);
  #line 440 "src/math/update_lazy.birch"
  libbirch_line_(440);
  #line 440 "src/math/update_lazy.birch"
  auto _u0923_prime_ = birch::rank_update(_u0923, birch::transpose(A, handler_), handler_);
  #line 441 "src/math/update_lazy.birch"
  libbirch_line_(441);
  #line 441 "src/math/update_lazy.birch"
  auto _u0957_prime_ = _u0957 + birch::transpose(A, handler_) * (x - c);
  #line 442 "src/math/update_lazy.birch"
  libbirch_line_(442);
  #line 442 "src/math/update_lazy.birch"
  auto _u0945_prime_ = _u0945 + 0.5 * D;
  #line 443 "src/math/update_lazy.birch"
  libbirch_line_(443);
  #line 443 "src/math/update_lazy.birch"
  auto _u0947_prime_ = _u0947 + 0.5 * birch::dot(x - c, handler_);
  #line 444 "src/math/update_lazy.birch"
  libbirch_line_(444);
  #line 444 "src/math/update_lazy.birch"
  return libbirch::make_tuple(_u0957_prime_, _u0923_prime_, _u0945_prime_, _u0947_prime_);
}

#line 461 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::update_lazy_linear_multivariate_normal_inverse_gamma_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0923, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0947, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 461 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_linear_multivariate_normal_inverse_gamma_gaussian", "src/math/update_lazy.birch", 461);
  #line 466 "src/math/update_lazy.birch"
  libbirch_line_(466);
  #line 466 "src/math/update_lazy.birch"
  auto _u0923_prime_ = birch::rank_update(_u0923, a, handler_);
  #line 467 "src/math/update_lazy.birch"
  libbirch_line_(467);
  #line 467 "src/math/update_lazy.birch"
  auto _u0957_prime_ = _u0957 + a * (x - c);
  #line 468 "src/math/update_lazy.birch"
  libbirch_line_(468);
  #line 468 "src/math/update_lazy.birch"
  auto _u0945_prime_ = _u0945 + 0.5;
  #line 469 "src/math/update_lazy.birch"
  libbirch_line_(469);
  #line 469 "src/math/update_lazy.birch"
  auto _u0947_prime_ = _u0947 + 0.5 * birch::pow(x - c, 2.0, handler_);
  #line 470 "src/math/update_lazy.birch"
  libbirch_line_(470);
  #line 470 "src/math/update_lazy.birch"
  return libbirch::make_tuple(_u0957_prime_, _u0923_prime_, _u0945_prime_, _u0947_prime_);
}

#line 484 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::update_lazy_matrix_normal_inverse_wishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& N, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0923, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 484 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_matrix_normal_inverse_wishart", "src/math/update_lazy.birch", 484);
  #line 487 "src/math/update_lazy.birch"
  libbirch_line_(487);
  #line 487 "src/math/update_lazy.birch"
  auto D = birch::rows(X, handler_);
  #line 488 "src/math/update_lazy.birch"
  libbirch_line_(488);
  #line 488 "src/math/update_lazy.birch"
  auto M = birch::solve(_u0923, N, handler_);
  #line 489 "src/math/update_lazy.birch"
  libbirch_line_(489);
  #line 489 "src/math/update_lazy.birch"
  auto V_prime_ = birch::rank_update(V, birch::transpose(X - M, handler_), handler_);
  #line 490 "src/math/update_lazy.birch"
  libbirch_line_(490);
  #line 490 "src/math/update_lazy.birch"
  auto k_prime_ = k + D;
  #line 491 "src/math/update_lazy.birch"
  libbirch_line_(491);
  #line 491 "src/math/update_lazy.birch"
  return libbirch::make_tuple(V_prime_, k_prime_);
}

#line 506 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::update_lazy_matrix_normal_inverse_wishart_matrix_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& N, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0923, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 506 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_matrix_normal_inverse_wishart_matrix_gaussian", "src/math/update_lazy.birch", 506);
  #line 510 "src/math/update_lazy.birch"
  libbirch_line_(510);
  #line 510 "src/math/update_lazy.birch"
  auto D = birch::rows(X, handler_);
  #line 511 "src/math/update_lazy.birch"
  libbirch_line_(511);
  #line 511 "src/math/update_lazy.birch"
  auto _u0923_prime_ = birch::rank_update(_u0923, birch::identity(birch::rows(N, handler_), handler_), handler_);
  #line 512 "src/math/update_lazy.birch"
  libbirch_line_(512);
  #line 512 "src/math/update_lazy.birch"
  auto N_prime_ = N + X;
  #line 513 "src/math/update_lazy.birch"
  libbirch_line_(513);
  #line 513 "src/math/update_lazy.birch"
  auto M = birch::solve(_u0923, N, handler_);
  #line 514 "src/math/update_lazy.birch"
  libbirch_line_(514);
  #line 514 "src/math/update_lazy.birch"
  auto M_prime_ = birch::solve(_u0923_prime_, N_prime_, handler_);
  #line 515 "src/math/update_lazy.birch"
  libbirch_line_(515);
  #line 515 "src/math/update_lazy.birch"
  auto V_prime_ = birch::llt(birch::canonical(V, handler_) + birch::transpose(X - M_prime_, handler_) * (X - M_prime_) + birch::transpose(M_prime_ - M, handler_) * birch::canonical(_u0923, handler_) * (M_prime_ - M), handler_);
  #line 517 "src/math/update_lazy.birch"
  libbirch_line_(517);
  #line 517 "src/math/update_lazy.birch"
  auto k_prime_ = k + D;
  #line 518 "src/math/update_lazy.birch"
  libbirch_line_(518);
  #line 518 "src/math/update_lazy.birch"
  return libbirch::make_tuple(N_prime_, _u0923_prime_, V_prime_, k_prime_);
}

#line 535 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::update_lazy_linear_matrix_normal_inverse_wishart_matrix_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& A, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& N, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0923, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& C, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 535 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_linear_matrix_normal_inverse_wishart_matrix_gaussian", "src/math/update_lazy.birch", 535);
  #line 540 "src/math/update_lazy.birch"
  libbirch_line_(540);
  #line 540 "src/math/update_lazy.birch"
  auto D = birch::rows(X, handler_);
  #line 541 "src/math/update_lazy.birch"
  libbirch_line_(541);
  #line 541 "src/math/update_lazy.birch"
  auto _u0923_prime_ = birch::rank_update(_u0923, birch::transpose(A, handler_), handler_);
  #line 542 "src/math/update_lazy.birch"
  libbirch_line_(542);
  #line 542 "src/math/update_lazy.birch"
  auto N_prime_ = N + birch::transpose(A, handler_) * (X - C);
  #line 543 "src/math/update_lazy.birch"
  libbirch_line_(543);
  #line 543 "src/math/update_lazy.birch"
  auto M = birch::solve(_u0923, N, handler_);
  #line 544 "src/math/update_lazy.birch"
  libbirch_line_(544);
  #line 544 "src/math/update_lazy.birch"
  auto M_prime_ = birch::solve(_u0923_prime_, N_prime_, handler_);
  #line 545 "src/math/update_lazy.birch"
  libbirch_line_(545);
  #line 545 "src/math/update_lazy.birch"
  auto V_prime_ = birch::llt(birch::canonical(V, handler_) + birch::transpose(X - A * M_prime_ - C, handler_) * (X - A * M_prime_ - C) + birch::transpose(M_prime_ - M, handler_) * birch::canonical(_u0923, handler_) * (M_prime_ - M), handler_);
  #line 547 "src/math/update_lazy.birch"
  libbirch_line_(547);
  #line 547 "src/math/update_lazy.birch"
  auto k_prime_ = k + D;
  #line 548 "src/math/update_lazy.birch"
  libbirch_line_(548);
  #line 548 "src/math/update_lazy.birch"
  return libbirch::make_tuple(N_prime_, _u0923_prime_, V_prime_, k_prime_);
}

#line 565 "src/math/update_lazy.birch"
libbirch::Tuple<libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>, libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::update_lazy_linear_matrix_normal_inverse_wishart_multivariate_gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& N, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0923, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 565 "src/math/update_lazy.birch"
  libbirch_function_("update_lazy_linear_matrix_normal_inverse_wishart_multivariate_gaussian", "src/math/update_lazy.birch", 565);
  #line 570 "src/math/update_lazy.birch"
  libbirch_line_(570);
  #line 570 "src/math/update_lazy.birch"
  auto _u0923_prime_ = birch::rank_update(_u0923, a, handler_);
  #line 571 "src/math/update_lazy.birch"
  libbirch_line_(571);
  #line 571 "src/math/update_lazy.birch"
  auto N_prime_ = N + birch::outer(a, x - c, handler_);
  #line 572 "src/math/update_lazy.birch"
  libbirch_line_(572);
  #line 572 "src/math/update_lazy.birch"
  auto M = birch::solve(_u0923, N, handler_);
  #line 573 "src/math/update_lazy.birch"
  libbirch_line_(573);
  #line 573 "src/math/update_lazy.birch"
  auto M_prime_ = birch::solve(_u0923_prime_, N_prime_, handler_);
  #line 574 "src/math/update_lazy.birch"
  libbirch_line_(574);
  #line 574 "src/math/update_lazy.birch"
  auto V_prime_ = birch::llt(birch::canonical(V, handler_) + birch::outer(x - birch::dot(a, M_prime_, handler_) - c, handler_) + birch::transpose(M_prime_ - M, handler_) * birch::canonical(_u0923, handler_) * (M_prime_ - M), handler_);
  #line 576 "src/math/update_lazy.birch"
  libbirch_line_(576);
  #line 576 "src/math/update_lazy.birch"
  auto k_prime_ = k + birch::type::Integer(1);
  #line 577 "src/math/update_lazy.birch"
  libbirch_line_(577);
  #line 577 "src/math/update_lazy.birch"
  return libbirch::make_tuple(N_prime_, _u0923_prime_, V_prime_, k_prime_);
}

#line 168 "src/math/vector.birch"
birch::type::String birch::String(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 168 "src/math/vector.birch"
  libbirch_function_("String", "src/math/vector.birch", 168);
  #line 169 "src/math/vector.birch"
  libbirch_line_(169);
  #line 169 "src/math/vector.birch"
  birch::type::String result;
  #line 170 "src/math/vector.birch"
std::stringstream buf;
    #line 173 "src/math/vector.birch"
  libbirch_line_(173);
  #line 173 "src/math/vector.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(x, handler_); ++i) {
    #line 174 "src/math/vector.birch"
    libbirch_line_(174);
    #line 174 "src/math/vector.birch"
    auto value = x.get(libbirch::make_slice(i - 1));
    #line 175 "src/math/vector.birch"
if (i > 1) {
      buf << ' ';
    }
    if (value == floor(value)) {
      buf << (int64_t)value << ".0";
    } else {
      buf << std::scientific << std::setprecision(6) << value;
    }
      }
  #line 186 "src/math/vector.birch"
result = buf.str();
    #line 189 "src/math/vector.birch"
  libbirch_line_(189);
  #line 189 "src/math/vector.birch"
  return result;
}

#line 195 "src/math/vector.birch"
birch::type::String birch::String(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 195 "src/math/vector.birch"
  libbirch_function_("String", "src/math/vector.birch", 195);
  #line 196 "src/math/vector.birch"
  libbirch_line_(196);
  #line 196 "src/math/vector.birch"
  birch::type::String result;
  #line 197 "src/math/vector.birch"
std::stringstream buf;
    #line 200 "src/math/vector.birch"
  libbirch_line_(200);
  #line 200 "src/math/vector.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(x, handler_); ++i) {
    #line 201 "src/math/vector.birch"
    libbirch_line_(201);
    #line 201 "src/math/vector.birch"
    auto value = x.get(libbirch::make_slice(i - 1));
    #line 202 "src/math/vector.birch"
if (i > 1) {
      buf << ' ';
    }
    buf << value;
      }
  #line 209 "src/math/vector.birch"
result = buf.str();
    #line 212 "src/math/vector.birch"
  libbirch_line_(212);
  #line 212 "src/math/vector.birch"
  return result;
}

#line 218 "src/math/vector.birch"
birch::type::String birch::String(const libbirch::DefaultArray<birch::type::Boolean,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 218 "src/math/vector.birch"
  libbirch_function_("String", "src/math/vector.birch", 218);
  #line 219 "src/math/vector.birch"
  libbirch_line_(219);
  #line 219 "src/math/vector.birch"
  birch::type::String result;
  #line 220 "src/math/vector.birch"
std::stringstream buf;
    #line 223 "src/math/vector.birch"
  libbirch_line_(223);
  #line 223 "src/math/vector.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(x, handler_); ++i) {
    #line 224 "src/math/vector.birch"
    libbirch_line_(224);
    #line 224 "src/math/vector.birch"
    auto value = x.get(libbirch::make_slice(i - 1));
    #line 225 "src/math/vector.birch"
if (i > 1) {
      buf << ' ';
    }
    if (value) {
      buf << "true";
    } else {
      buf << "false";
    }
      }
  #line 236 "src/math/vector.birch"
result = buf.str();
    #line 239 "src/math/vector.birch"
  libbirch_line_(239);
  #line 239 "src/math/vector.birch"
  return result;
}

