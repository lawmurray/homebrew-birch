#line 4 "src/distribution/AddBoundedDiscrete.birch"
birch::type::AddBoundedDiscrete::AddBoundedDiscrete(const libbirch::Shared<birch::type::BoundedDiscrete>& x1, const libbirch::Shared<birch::type::BoundedDiscrete>& x2) :
    #line 4 "src/distribution/AddBoundedDiscrete.birch"
    base_type_(),
    #line 9 "src/distribution/AddBoundedDiscrete.birch"
    x1(std::move(x1)),
    #line 14 "src/distribution/AddBoundedDiscrete.birch"
    x2(std::move(x2)),
    #line 19 "src/distribution/AddBoundedDiscrete.birch"
    x(libbirch::make<std::optional<birch::type::Integer>>()),
    #line 24 "src/distribution/AddBoundedDiscrete.birch"
    x0(libbirch::make<birch::type::Integer>()),
    #line 30 "src/distribution/AddBoundedDiscrete.birch"
    z(libbirch::make<libbirch::DefaultArray<birch::type::Real,1>>()),
    #line 35 "src/distribution/AddBoundedDiscrete.birch"
    Z(libbirch::make<birch::type::Real>()) {
  //
}

#line 37 "src/distribution/AddBoundedDiscrete.birch"
void birch::type::AddBoundedDiscrete::enumerate(const birch::type::Integer& x) {
  #line 37 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("enumerate", "src/distribution/AddBoundedDiscrete.birch", 37);
  #line 38 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(38);
  #line 38 "src/distribution/AddBoundedDiscrete.birch"
  if (!(this->x.has_value()) || this->x.value() != x) {
    #line 39 "src/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(39);
    #line 39 "src/distribution/AddBoundedDiscrete.birch"
    auto l = birch::max(this->x1->lower().value(), x - this->x2->upper().value());
    #line 40 "src/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(40);
    #line 40 "src/distribution/AddBoundedDiscrete.birch"
    auto u = birch::min(this->x1->upper().value(), x - this->x2->lower().value());
    #line 42 "src/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(42);
    #line 42 "src/distribution/AddBoundedDiscrete.birch"
    this->x0 = l;
    #line 43 "src/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(43);
    #line 43 "src/distribution/AddBoundedDiscrete.birch"
    this->Z = 0.0;
    #line 44 "src/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(44);
    #line 44 "src/distribution/AddBoundedDiscrete.birch"
    if (l <= u) {
      #line 46 "src/distribution/AddBoundedDiscrete.birch"
      libbirch_line_(46);
      #line 46 "src/distribution/AddBoundedDiscrete.birch"
      this->z = birch::vector(0.0, u - l + birch::type::Integer(1));
      #line 47 "src/distribution/AddBoundedDiscrete.birch"
      libbirch_line_(47);
      #line 47 "src/distribution/AddBoundedDiscrete.birch"
      for (auto n = l; n <= u; ++n) {
        #line 48 "src/distribution/AddBoundedDiscrete.birch"
        libbirch_line_(48);
        #line 48 "src/distribution/AddBoundedDiscrete.birch"
        this->z(n - l + birch::type::Integer(1)) = birch::exp(this->x1->logpdf(n) + this->x2->logpdf(x - n));
        #line 49 "src/distribution/AddBoundedDiscrete.birch"
        libbirch_line_(49);
        #line 49 "src/distribution/AddBoundedDiscrete.birch"
        this->Z = this->Z + this->z(n - l + birch::type::Integer(1));
      }
    }
    #line 52 "src/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(52);
    #line 52 "src/distribution/AddBoundedDiscrete.birch"
    this->x = x;
  }
}

#line 60 "src/distribution/AddBoundedDiscrete.birch"
birch::type::Integer birch::type::AddBoundedDiscrete::simulate() {
  #line 60 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("simulate", "src/distribution/AddBoundedDiscrete.birch", 60);
  #line 61 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/AddBoundedDiscrete.birch"
  return birch::simulate_delta(this->x1->simulate() + this->x2->simulate());
}

#line 68 "src/distribution/AddBoundedDiscrete.birch"
birch::type::Real birch::type::AddBoundedDiscrete::logpdf(const birch::type::Integer& x) {
  #line 68 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("logpdf", "src/distribution/AddBoundedDiscrete.birch", 68);
  #line 69 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(69);
  #line 69 "src/distribution/AddBoundedDiscrete.birch"
  this->enumerate(x);
  #line 70 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(70);
  #line 70 "src/distribution/AddBoundedDiscrete.birch"
  return birch::log(this->Z);
}

#line 78 "src/distribution/AddBoundedDiscrete.birch"
void birch::type::AddBoundedDiscrete::update(const birch::type::Integer& x) {
  #line 78 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("update", "src/distribution/AddBoundedDiscrete.birch", 78);
  #line 80 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(80);
  #line 80 "src/distribution/AddBoundedDiscrete.birch"
  this->enumerate(x);
  #line 81 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(81);
  #line 81 "src/distribution/AddBoundedDiscrete.birch"
  auto n = birch::simulate_categorical(this->z, this->Z) + this->x0 - birch::type::Integer(1);
  #line 82 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(82);
  #line 82 "src/distribution/AddBoundedDiscrete.birch"
  this->x1->clamp(n);
  #line 83 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(83);
  #line 83 "src/distribution/AddBoundedDiscrete.birch"
  this->x2->clamp(x - n);
}

#line 90 "src/distribution/AddBoundedDiscrete.birch"
std::optional<birch::type::Real> birch::type::AddBoundedDiscrete::cdf(const birch::type::Integer& x) {
  #line 90 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("cdf", "src/distribution/AddBoundedDiscrete.birch", 90);
  #line 91 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(91);
  #line 91 "src/distribution/AddBoundedDiscrete.birch"
  auto P = 0.0;
  #line 92 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(92);
  #line 92 "src/distribution/AddBoundedDiscrete.birch"
  for (auto n = this->lower().value(); n <= x; ++n) {
    #line 93 "src/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(93);
    #line 93 "src/distribution/AddBoundedDiscrete.birch"
    P = P + this->pdf(n);
  }
  #line 95 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(95);
  #line 95 "src/distribution/AddBoundedDiscrete.birch"
  return P;
}

#line 98 "src/distribution/AddBoundedDiscrete.birch"
std::optional<birch::type::Integer> birch::type::AddBoundedDiscrete::lower() {
  #line 98 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("lower", "src/distribution/AddBoundedDiscrete.birch", 98);
  #line 99 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(99);
  #line 99 "src/distribution/AddBoundedDiscrete.birch"
  return this->x1->lower().value() + this->x2->lower().value();
}

#line 102 "src/distribution/AddBoundedDiscrete.birch"
std::optional<birch::type::Integer> birch::type::AddBoundedDiscrete::upper() {
  #line 102 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("upper", "src/distribution/AddBoundedDiscrete.birch", 102);
  #line 103 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(103);
  #line 103 "src/distribution/AddBoundedDiscrete.birch"
  return this->x1->upper().value() + this->x2->upper().value();
}

#line 106 "src/distribution/AddBoundedDiscrete.birch"
void birch::type::AddBoundedDiscrete::link() {
  #line 106 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("link", "src/distribution/AddBoundedDiscrete.birch", 106);
  #line 107 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(107);
  #line 107 "src/distribution/AddBoundedDiscrete.birch"
  this->x1->setChild(this->shared_from_this_());
  #line 108 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(108);
  #line 108 "src/distribution/AddBoundedDiscrete.birch"
  this->x2->setChild(this->shared_from_this_());
}

#line 111 "src/distribution/AddBoundedDiscrete.birch"
void birch::type::AddBoundedDiscrete::unlink() {
  #line 111 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("unlink", "src/distribution/AddBoundedDiscrete.birch", 111);
  #line 112 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(112);
  #line 112 "src/distribution/AddBoundedDiscrete.birch"
  this->x1->releaseChild(this->shared_from_this_());
  #line 113 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(113);
  #line 113 "src/distribution/AddBoundedDiscrete.birch"
  this->x2->releaseChild(this->shared_from_this_());
}

#line 117 "src/distribution/AddBoundedDiscrete.birch"
libbirch::Shared<birch::type::AddBoundedDiscrete> birch::AddBoundedDiscrete(const libbirch::Shared<birch::type::BoundedDiscrete>& x1, const libbirch::Shared<birch::type::BoundedDiscrete>& x2) {
  #line 117 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("AddBoundedDiscrete", "src/distribution/AddBoundedDiscrete.birch", 117);
  #line 119 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(119);
  #line 119 "src/distribution/AddBoundedDiscrete.birch"
  libbirch::Shared<birch::type::AddBoundedDiscrete> m = libbirch::make<libbirch::Shared<birch::type::AddBoundedDiscrete>>(std::in_place, x1, x2);
  #line 120 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(120);
  #line 120 "src/distribution/AddBoundedDiscrete.birch"
  m->link();
  #line 121 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(121);
  #line 121 "src/distribution/AddBoundedDiscrete.birch"
  return m;
}

#line 4 "src/distribution/Bernoulli.birch"
birch::type::Bernoulli::Bernoulli(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0961) :
    #line 4 "src/distribution/Bernoulli.birch"
    base_type_(),
    #line 8 "src/distribution/Bernoulli.birch"
    _u0961(std::move(_u0961)) {
  //
}

#line 10 "src/distribution/Bernoulli.birch"
birch::type::Boolean birch::type::Bernoulli::supportsLazy() {
  #line 10 "src/distribution/Bernoulli.birch"
  libbirch_function_("supportsLazy", "src/distribution/Bernoulli.birch", 10);
  #line 11 "src/distribution/Bernoulli.birch"
  libbirch_line_(11);
  #line 11 "src/distribution/Bernoulli.birch"
  return true;
}

#line 14 "src/distribution/Bernoulli.birch"
birch::type::Boolean birch::type::Bernoulli::simulate() {
  #line 14 "src/distribution/Bernoulli.birch"
  libbirch_function_("simulate", "src/distribution/Bernoulli.birch", 14);
  #line 15 "src/distribution/Bernoulli.birch"
  libbirch_line_(15);
  #line 15 "src/distribution/Bernoulli.birch"
  return birch::simulate_bernoulli(this->_u0961->value());
}

#line 18 "src/distribution/Bernoulli.birch"
std::optional<birch::type::Boolean> birch::type::Bernoulli::simulateLazy() {
  #line 18 "src/distribution/Bernoulli.birch"
  libbirch_function_("simulateLazy", "src/distribution/Bernoulli.birch", 18);
  #line 19 "src/distribution/Bernoulli.birch"
  libbirch_line_(19);
  #line 19 "src/distribution/Bernoulli.birch"
  return birch::simulate_bernoulli(this->_u0961->get());
}

#line 22 "src/distribution/Bernoulli.birch"
birch::type::Real birch::type::Bernoulli::logpdf(const birch::type::Boolean& x) {
  #line 22 "src/distribution/Bernoulli.birch"
  libbirch_function_("logpdf", "src/distribution/Bernoulli.birch", 22);
  #line 23 "src/distribution/Bernoulli.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/Bernoulli.birch"
  return birch::logpdf_bernoulli(x, this->_u0961->value());
}

#line 26 "src/distribution/Bernoulli.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::Bernoulli::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::Boolean>>& x) {
  #line 26 "src/distribution/Bernoulli.birch"
  libbirch_function_("logpdfLazy", "src/distribution/Bernoulli.birch", 26);
  #line 27 "src/distribution/Bernoulli.birch"
  libbirch_line_(27);
  #line 27 "src/distribution/Bernoulli.birch"
  return birch::logpdf_lazy_bernoulli(x, this->_u0961);
}

#line 30 "src/distribution/Bernoulli.birch"
void birch::type::Bernoulli::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 30 "src/distribution/Bernoulli.birch"
  libbirch_function_("write", "src/distribution/Bernoulli.birch", 30);
  #line 31 "src/distribution/Bernoulli.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/Bernoulli.birch"
  this->prune();
  #line 32 "src/distribution/Bernoulli.birch"
  libbirch_line_(32);
  #line 32 "src/distribution/Bernoulli.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Bernoulli"));
  #line 33 "src/distribution/Bernoulli.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/Bernoulli.birch"
  buffer->set(birch::type::String("ρ"), this->_u0961);
}

#line 40 "src/distribution/Bernoulli.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Boolean>> birch::Bernoulli(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0961) {
  #line 40 "src/distribution/Bernoulli.birch"
  libbirch_function_("Bernoulli", "src/distribution/Bernoulli.birch", 40);
  #line 41 "src/distribution/Bernoulli.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/Bernoulli.birch"
  std::optional<libbirch::Shared<birch::type::Beta>> m = libbirch::make<std::optional<libbirch::Shared<birch::type::Beta>>>();
  #line 42 "src/distribution/Bernoulli.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/Bernoulli.birch"
  if ((m = _u0961->graftBeta()).has_value()) {
    #line 43 "src/distribution/Bernoulli.birch"
    libbirch_line_(43);
    #line 43 "src/distribution/Bernoulli.birch"
    return birch::BetaBernoulli(m.value());
  } else {
    #line 45 "src/distribution/Bernoulli.birch"
    libbirch_line_(45);
    #line 45 "src/distribution/Bernoulli.birch"
    return birch::construct<libbirch::Shared<birch::type::Bernoulli>>(_u0961);
  }
}

#line 52 "src/distribution/Bernoulli.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Boolean>> birch::Bernoulli(const birch::type::Real& _u0961) {
  #line 52 "src/distribution/Bernoulli.birch"
  libbirch_function_("Bernoulli", "src/distribution/Bernoulli.birch", 52);
  #line 53 "src/distribution/Bernoulli.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/Bernoulli.birch"
  return birch::Bernoulli(birch::box(_u0961));
}

#line 4 "src/distribution/Beta.birch"
birch::type::Beta::Beta(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0945, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0946) :
    #line 4 "src/distribution/Beta.birch"
    base_type_(),
    #line 9 "src/distribution/Beta.birch"
    _u0945(std::move(_u0945)),
    #line 14 "src/distribution/Beta.birch"
    _u0946(std::move(_u0946)) {
  //
}

#line 16 "src/distribution/Beta.birch"
birch::type::Boolean birch::type::Beta::supportsLazy() {
  #line 16 "src/distribution/Beta.birch"
  libbirch_function_("supportsLazy", "src/distribution/Beta.birch", 16);
  #line 17 "src/distribution/Beta.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/Beta.birch"
  return true;
}

#line 20 "src/distribution/Beta.birch"
birch::type::Real birch::type::Beta::simulate() {
  #line 20 "src/distribution/Beta.birch"
  libbirch_function_("simulate", "src/distribution/Beta.birch", 20);
  #line 21 "src/distribution/Beta.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/Beta.birch"
  return birch::simulate_beta(this->_u0945->value(), this->_u0946->value());
}

#line 24 "src/distribution/Beta.birch"
std::optional<birch::type::Real> birch::type::Beta::simulateLazy() {
  #line 24 "src/distribution/Beta.birch"
  libbirch_function_("simulateLazy", "src/distribution/Beta.birch", 24);
  #line 25 "src/distribution/Beta.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/Beta.birch"
  return birch::simulate_beta(this->_u0945->get(), this->_u0946->get());
}

#line 28 "src/distribution/Beta.birch"
birch::type::Real birch::type::Beta::logpdf(const birch::type::Real& x) {
  #line 28 "src/distribution/Beta.birch"
  libbirch_function_("logpdf", "src/distribution/Beta.birch", 28);
  #line 29 "src/distribution/Beta.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/Beta.birch"
  return birch::logpdf_beta(x, this->_u0945->value(), this->_u0946->value());
}

#line 32 "src/distribution/Beta.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::Beta::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 32 "src/distribution/Beta.birch"
  libbirch_function_("logpdfLazy", "src/distribution/Beta.birch", 32);
  #line 33 "src/distribution/Beta.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/Beta.birch"
  return birch::logpdf_lazy_beta(x, this->_u0945, this->_u0946);
}

#line 36 "src/distribution/Beta.birch"
std::optional<birch::type::Real> birch::type::Beta::cdf(const birch::type::Real& x) {
  #line 36 "src/distribution/Beta.birch"
  libbirch_function_("cdf", "src/distribution/Beta.birch", 36);
  #line 37 "src/distribution/Beta.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/Beta.birch"
  return birch::cdf_beta(x, this->_u0945->value(), this->_u0946->value());
}

#line 40 "src/distribution/Beta.birch"
std::optional<birch::type::Real> birch::type::Beta::quantile(const birch::type::Real& P) {
  #line 40 "src/distribution/Beta.birch"
  libbirch_function_("quantile", "src/distribution/Beta.birch", 40);
  #line 41 "src/distribution/Beta.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/Beta.birch"
  return birch::quantile_beta(P, this->_u0945->value(), this->_u0946->value());
}

#line 44 "src/distribution/Beta.birch"
std::optional<birch::type::Real> birch::type::Beta::lower() {
  #line 44 "src/distribution/Beta.birch"
  libbirch_function_("lower", "src/distribution/Beta.birch", 44);
  #line 45 "src/distribution/Beta.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/Beta.birch"
  return 0.0;
}

#line 48 "src/distribution/Beta.birch"
std::optional<birch::type::Real> birch::type::Beta::upper() {
  #line 48 "src/distribution/Beta.birch"
  libbirch_function_("upper", "src/distribution/Beta.birch", 48);
  #line 49 "src/distribution/Beta.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/Beta.birch"
  return 1.0;
}

#line 52 "src/distribution/Beta.birch"
std::optional<libbirch::Shared<birch::type::Beta>> birch::type::Beta::graftBeta() {
  #line 52 "src/distribution/Beta.birch"
  libbirch_function_("graftBeta", "src/distribution/Beta.birch", 52);
  #line 53 "src/distribution/Beta.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/Beta.birch"
  this->prune();
  #line 54 "src/distribution/Beta.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/Beta.birch"
  return this->shared_from_this_();
}

#line 57 "src/distribution/Beta.birch"
void birch::type::Beta::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 57 "src/distribution/Beta.birch"
  libbirch_function_("write", "src/distribution/Beta.birch", 57);
  #line 58 "src/distribution/Beta.birch"
  libbirch_line_(58);
  #line 58 "src/distribution/Beta.birch"
  this->prune();
  #line 59 "src/distribution/Beta.birch"
  libbirch_line_(59);
  #line 59 "src/distribution/Beta.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Beta"));
  #line 60 "src/distribution/Beta.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/Beta.birch"
  buffer->set(birch::type::String("α"), this->_u0945);
  #line 61 "src/distribution/Beta.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/Beta.birch"
  buffer->set(birch::type::String("β"), this->_u0946);
}

#line 68 "src/distribution/Beta.birch"
libbirch::Shared<birch::type::Beta> birch::Beta(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0945, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0946) {
  #line 68 "src/distribution/Beta.birch"
  libbirch_function_("Beta", "src/distribution/Beta.birch", 68);
  #line 69 "src/distribution/Beta.birch"
  libbirch_line_(69);
  #line 69 "src/distribution/Beta.birch"
  return birch::construct<libbirch::Shared<birch::type::Beta>>(_u0945, _u0946);
}

#line 75 "src/distribution/Beta.birch"
libbirch::Shared<birch::type::Beta> birch::Beta(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0945, const birch::type::Real& _u0946) {
  #line 75 "src/distribution/Beta.birch"
  libbirch_function_("Beta", "src/distribution/Beta.birch", 75);
  #line 76 "src/distribution/Beta.birch"
  libbirch_line_(76);
  #line 76 "src/distribution/Beta.birch"
  return birch::Beta(_u0945, birch::box(_u0946));
}

#line 82 "src/distribution/Beta.birch"
libbirch::Shared<birch::type::Beta> birch::Beta(const birch::type::Real& _u0945, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0946) {
  #line 82 "src/distribution/Beta.birch"
  libbirch_function_("Beta", "src/distribution/Beta.birch", 82);
  #line 83 "src/distribution/Beta.birch"
  libbirch_line_(83);
  #line 83 "src/distribution/Beta.birch"
  return birch::Beta(birch::box(_u0945), _u0946);
}

#line 89 "src/distribution/Beta.birch"
libbirch::Shared<birch::type::Beta> birch::Beta(const birch::type::Real& _u0945, const birch::type::Real& _u0946) {
  #line 89 "src/distribution/Beta.birch"
  libbirch_function_("Beta", "src/distribution/Beta.birch", 89);
  #line 90 "src/distribution/Beta.birch"
  libbirch_line_(90);
  #line 90 "src/distribution/Beta.birch"
  return birch::Beta(birch::box(_u0945), birch::box(_u0946));
}

#line 4 "src/distribution/BetaBernoulli.birch"
birch::type::BetaBernoulli::BetaBernoulli(const libbirch::Shared<birch::type::Beta>& _u0961) :
    #line 4 "src/distribution/BetaBernoulli.birch"
    base_type_(),
    #line 8 "src/distribution/BetaBernoulli.birch"
    _u0961(std::move(_u0961)) {
  //
}

#line 10 "src/distribution/BetaBernoulli.birch"
birch::type::Boolean birch::type::BetaBernoulli::supportsLazy() {
  #line 10 "src/distribution/BetaBernoulli.birch"
  libbirch_function_("supportsLazy", "src/distribution/BetaBernoulli.birch", 10);
  #line 11 "src/distribution/BetaBernoulli.birch"
  libbirch_line_(11);
  #line 11 "src/distribution/BetaBernoulli.birch"
  return true;
}

#line 14 "src/distribution/BetaBernoulli.birch"
birch::type::Boolean birch::type::BetaBernoulli::simulate() {
  #line 14 "src/distribution/BetaBernoulli.birch"
  libbirch_function_("simulate", "src/distribution/BetaBernoulli.birch", 14);
  #line 15 "src/distribution/BetaBernoulli.birch"
  libbirch_line_(15);
  #line 15 "src/distribution/BetaBernoulli.birch"
  return birch::simulate_beta_bernoulli(this->_u0961->_u0945->value(), this->_u0961->_u0946->value());
}

#line 18 "src/distribution/BetaBernoulli.birch"
std::optional<birch::type::Boolean> birch::type::BetaBernoulli::simulateLazy() {
  #line 18 "src/distribution/BetaBernoulli.birch"
  libbirch_function_("simulateLazy", "src/distribution/BetaBernoulli.birch", 18);
  #line 19 "src/distribution/BetaBernoulli.birch"
  libbirch_line_(19);
  #line 19 "src/distribution/BetaBernoulli.birch"
  return birch::simulate_beta_bernoulli(this->_u0961->_u0945->get(), this->_u0961->_u0946->get());
}

#line 22 "src/distribution/BetaBernoulli.birch"
birch::type::Real birch::type::BetaBernoulli::logpdf(const birch::type::Boolean& x) {
  #line 22 "src/distribution/BetaBernoulli.birch"
  libbirch_function_("logpdf", "src/distribution/BetaBernoulli.birch", 22);
  #line 23 "src/distribution/BetaBernoulli.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/BetaBernoulli.birch"
  return birch::logpdf_beta_bernoulli(x, this->_u0961->_u0945->value(), this->_u0961->_u0946->value());
}

#line 26 "src/distribution/BetaBernoulli.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::BetaBernoulli::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::Boolean>>& x) {
  #line 26 "src/distribution/BetaBernoulli.birch"
  libbirch_function_("logpdfLazy", "src/distribution/BetaBernoulli.birch", 26);
  #line 27 "src/distribution/BetaBernoulli.birch"
  libbirch_line_(27);
  #line 27 "src/distribution/BetaBernoulli.birch"
  return birch::logpdf_lazy_beta_bernoulli(x, this->_u0961->_u0945, this->_u0961->_u0946);
}

#line 30 "src/distribution/BetaBernoulli.birch"
void birch::type::BetaBernoulli::update(const birch::type::Boolean& x) {
  #line 30 "src/distribution/BetaBernoulli.birch"
  libbirch_function_("update", "src/distribution/BetaBernoulli.birch", 30);
  #line 31 "src/distribution/BetaBernoulli.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/BetaBernoulli.birch"
  std::tie(this->_u0961->_u0945, this->_u0961->_u0946) = birch::box(birch::update_beta_bernoulli(x, this->_u0961->_u0945->value(), this->_u0961->_u0946->value()));
}

#line 34 "src/distribution/BetaBernoulli.birch"
void birch::type::BetaBernoulli::updateLazy(const libbirch::Shared<birch::type::Expression<birch::type::Boolean>>& x) {
  #line 34 "src/distribution/BetaBernoulli.birch"
  libbirch_function_("updateLazy", "src/distribution/BetaBernoulli.birch", 34);
  #line 35 "src/distribution/BetaBernoulli.birch"
  libbirch_line_(35);
  #line 35 "src/distribution/BetaBernoulli.birch"
  std::tie(this->_u0961->_u0945, this->_u0961->_u0946) = birch::update_lazy_beta_bernoulli(x, this->_u0961->_u0945, this->_u0961->_u0946);
}

#line 38 "src/distribution/BetaBernoulli.birch"
void birch::type::BetaBernoulli::link() {
  #line 38 "src/distribution/BetaBernoulli.birch"
  libbirch_function_("link", "src/distribution/BetaBernoulli.birch", 38);
  #line 39 "src/distribution/BetaBernoulli.birch"
  libbirch_line_(39);
  #line 39 "src/distribution/BetaBernoulli.birch"
  this->_u0961->setChild(this->shared_from_this_());
}

#line 42 "src/distribution/BetaBernoulli.birch"
void birch::type::BetaBernoulli::unlink() {
  #line 42 "src/distribution/BetaBernoulli.birch"
  libbirch_function_("unlink", "src/distribution/BetaBernoulli.birch", 42);
  #line 43 "src/distribution/BetaBernoulli.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/BetaBernoulli.birch"
  this->_u0961->releaseChild(this->shared_from_this_());
}

#line 47 "src/distribution/BetaBernoulli.birch"
libbirch::Shared<birch::type::BetaBernoulli> birch::BetaBernoulli(const libbirch::Shared<birch::type::Beta>& _u0961) {
  #line 47 "src/distribution/BetaBernoulli.birch"
  libbirch_function_("BetaBernoulli", "src/distribution/BetaBernoulli.birch", 47);
  #line 48 "src/distribution/BetaBernoulli.birch"
  libbirch_line_(48);
  #line 48 "src/distribution/BetaBernoulli.birch"
  libbirch::Shared<birch::type::BetaBernoulli> m = libbirch::make<libbirch::Shared<birch::type::BetaBernoulli>>(std::in_place, _u0961);
  #line 49 "src/distribution/BetaBernoulli.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/BetaBernoulli.birch"
  m->link();
  #line 50 "src/distribution/BetaBernoulli.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/BetaBernoulli.birch"
  return m;
}

#line 4 "src/distribution/BetaBinomial.birch"
birch::type::BetaBinomial::BetaBinomial(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& n, const libbirch::Shared<birch::type::Beta>& _u0961) :
    #line 4 "src/distribution/BetaBinomial.birch"
    base_type_(),
    #line 8 "src/distribution/BetaBinomial.birch"
    n(std::move(n)),
    #line 13 "src/distribution/BetaBinomial.birch"
    _u0961(std::move(_u0961)) {
  //
}

#line 15 "src/distribution/BetaBinomial.birch"
birch::type::Boolean birch::type::BetaBinomial::supportsLazy() {
  #line 15 "src/distribution/BetaBinomial.birch"
  libbirch_function_("supportsLazy", "src/distribution/BetaBinomial.birch", 15);
  #line 16 "src/distribution/BetaBinomial.birch"
  libbirch_line_(16);
  #line 16 "src/distribution/BetaBinomial.birch"
  return true;
}

#line 19 "src/distribution/BetaBinomial.birch"
birch::type::Integer birch::type::BetaBinomial::simulate() {
  #line 19 "src/distribution/BetaBinomial.birch"
  libbirch_function_("simulate", "src/distribution/BetaBinomial.birch", 19);
  #line 20 "src/distribution/BetaBinomial.birch"
  libbirch_line_(20);
  #line 20 "src/distribution/BetaBinomial.birch"
  return birch::simulate_beta_binomial(this->n->value(), this->_u0961->_u0945->value(), this->_u0961->_u0946->value());
}

#line 23 "src/distribution/BetaBinomial.birch"
std::optional<birch::type::Integer> birch::type::BetaBinomial::simulateLazy() {
  #line 23 "src/distribution/BetaBinomial.birch"
  libbirch_function_("simulateLazy", "src/distribution/BetaBinomial.birch", 23);
  #line 24 "src/distribution/BetaBinomial.birch"
  libbirch_line_(24);
  #line 24 "src/distribution/BetaBinomial.birch"
  return birch::simulate_beta_binomial(this->n->get(), this->_u0961->_u0945->get(), this->_u0961->_u0946->get());
}

#line 27 "src/distribution/BetaBinomial.birch"
birch::type::Real birch::type::BetaBinomial::logpdf(const birch::type::Integer& x) {
  #line 27 "src/distribution/BetaBinomial.birch"
  libbirch_function_("logpdf", "src/distribution/BetaBinomial.birch", 27);
  #line 28 "src/distribution/BetaBinomial.birch"
  libbirch_line_(28);
  #line 28 "src/distribution/BetaBinomial.birch"
  return birch::logpdf_beta_binomial(x, this->n->value(), this->_u0961->_u0945->value(), this->_u0961->_u0946->value());
}

#line 31 "src/distribution/BetaBinomial.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::BetaBinomial::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& x) {
  #line 31 "src/distribution/BetaBinomial.birch"
  libbirch_function_("logpdfLazy", "src/distribution/BetaBinomial.birch", 31);
  #line 32 "src/distribution/BetaBinomial.birch"
  libbirch_line_(32);
  #line 32 "src/distribution/BetaBinomial.birch"
  return birch::logpdf_lazy_beta_binomial(x, this->n, this->_u0961->_u0945, this->_u0961->_u0946);
}

#line 35 "src/distribution/BetaBinomial.birch"
void birch::type::BetaBinomial::update(const birch::type::Integer& x) {
  #line 35 "src/distribution/BetaBinomial.birch"
  libbirch_function_("update", "src/distribution/BetaBinomial.birch", 35);
  #line 36 "src/distribution/BetaBinomial.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/BetaBinomial.birch"
  std::tie(this->_u0961->_u0945, this->_u0961->_u0946) = birch::box(birch::update_beta_binomial(x, this->n->value(), this->_u0961->_u0945->value(), this->_u0961->_u0946->value()));
}

#line 39 "src/distribution/BetaBinomial.birch"
void birch::type::BetaBinomial::updateLazy(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& x) {
  #line 39 "src/distribution/BetaBinomial.birch"
  libbirch_function_("updateLazy", "src/distribution/BetaBinomial.birch", 39);
  #line 40 "src/distribution/BetaBinomial.birch"
  libbirch_line_(40);
  #line 40 "src/distribution/BetaBinomial.birch"
  std::tie(this->_u0961->_u0945, this->_u0961->_u0946) = birch::update_lazy_beta_binomial(x, this->n, this->_u0961->_u0945, this->_u0961->_u0946);
}

#line 43 "src/distribution/BetaBinomial.birch"
std::optional<birch::type::Real> birch::type::BetaBinomial::cdf(const birch::type::Integer& x) {
  #line 43 "src/distribution/BetaBinomial.birch"
  libbirch_function_("cdf", "src/distribution/BetaBinomial.birch", 43);
  #line 44 "src/distribution/BetaBinomial.birch"
  libbirch_line_(44);
  #line 44 "src/distribution/BetaBinomial.birch"
  return birch::cdf_beta_binomial(x, this->n->value(), this->_u0961->_u0945->value(), this->_u0961->_u0946->value());
}

#line 47 "src/distribution/BetaBinomial.birch"
std::optional<birch::type::Integer> birch::type::BetaBinomial::lower() {
  #line 47 "src/distribution/BetaBinomial.birch"
  libbirch_function_("lower", "src/distribution/BetaBinomial.birch", 47);
  #line 48 "src/distribution/BetaBinomial.birch"
  libbirch_line_(48);
  #line 48 "src/distribution/BetaBinomial.birch"
  return birch::type::Integer(0);
}

#line 51 "src/distribution/BetaBinomial.birch"
std::optional<birch::type::Integer> birch::type::BetaBinomial::upper() {
  #line 51 "src/distribution/BetaBinomial.birch"
  libbirch_function_("upper", "src/distribution/BetaBinomial.birch", 51);
  #line 52 "src/distribution/BetaBinomial.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/BetaBinomial.birch"
  return this->n->value();
}

#line 55 "src/distribution/BetaBinomial.birch"
void birch::type::BetaBinomial::link() {
  #line 55 "src/distribution/BetaBinomial.birch"
  libbirch_function_("link", "src/distribution/BetaBinomial.birch", 55);
  #line 56 "src/distribution/BetaBinomial.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/BetaBinomial.birch"
  this->_u0961->setChild(this->shared_from_this_());
}

#line 59 "src/distribution/BetaBinomial.birch"
void birch::type::BetaBinomial::unlink() {
  #line 59 "src/distribution/BetaBinomial.birch"
  libbirch_function_("unlink", "src/distribution/BetaBinomial.birch", 59);
  #line 60 "src/distribution/BetaBinomial.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/BetaBinomial.birch"
  this->_u0961->releaseChild(this->shared_from_this_());
}

#line 64 "src/distribution/BetaBinomial.birch"
libbirch::Shared<birch::type::BetaBinomial> birch::BetaBinomial(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& n, const libbirch::Shared<birch::type::Beta>& _u0961) {
  #line 64 "src/distribution/BetaBinomial.birch"
  libbirch_function_("BetaBinomial", "src/distribution/BetaBinomial.birch", 64);
  #line 65 "src/distribution/BetaBinomial.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/BetaBinomial.birch"
  libbirch::Shared<birch::type::BetaBinomial> m = libbirch::make<libbirch::Shared<birch::type::BetaBinomial>>(std::in_place, n, _u0961);
  #line 66 "src/distribution/BetaBinomial.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/BetaBinomial.birch"
  m->link();
  #line 67 "src/distribution/BetaBinomial.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/BetaBinomial.birch"
  return m;
}

#line 4 "src/distribution/BetaNegativeBinomial.birch"
birch::type::BetaNegativeBinomial::BetaNegativeBinomial(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& k, const libbirch::Shared<birch::type::Beta>& _u0961) :
    #line 4 "src/distribution/BetaNegativeBinomial.birch"
    base_type_(),
    #line 8 "src/distribution/BetaNegativeBinomial.birch"
    k(std::move(k)),
    #line 13 "src/distribution/BetaNegativeBinomial.birch"
    _u0961(std::move(_u0961)) {
  //
}

#line 15 "src/distribution/BetaNegativeBinomial.birch"
birch::type::Boolean birch::type::BetaNegativeBinomial::supportsLazy() {
  #line 15 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("supportsLazy", "src/distribution/BetaNegativeBinomial.birch", 15);
  #line 16 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(16);
  #line 16 "src/distribution/BetaNegativeBinomial.birch"
  return true;
}

#line 19 "src/distribution/BetaNegativeBinomial.birch"
birch::type::Integer birch::type::BetaNegativeBinomial::simulate() {
  #line 19 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("simulate", "src/distribution/BetaNegativeBinomial.birch", 19);
  #line 20 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(20);
  #line 20 "src/distribution/BetaNegativeBinomial.birch"
  return birch::simulate_beta_negative_binomial(this->k->value(), this->_u0961->_u0945->value(), this->_u0961->_u0946->value());
}

#line 23 "src/distribution/BetaNegativeBinomial.birch"
std::optional<birch::type::Integer> birch::type::BetaNegativeBinomial::simulateLazy() {
  #line 23 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("simulateLazy", "src/distribution/BetaNegativeBinomial.birch", 23);
  #line 24 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(24);
  #line 24 "src/distribution/BetaNegativeBinomial.birch"
  return birch::simulate_beta_negative_binomial(this->k->get(), this->_u0961->_u0945->get(), this->_u0961->_u0946->get());
}

#line 27 "src/distribution/BetaNegativeBinomial.birch"
birch::type::Real birch::type::BetaNegativeBinomial::logpdf(const birch::type::Integer& x) {
  #line 27 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("logpdf", "src/distribution/BetaNegativeBinomial.birch", 27);
  #line 28 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(28);
  #line 28 "src/distribution/BetaNegativeBinomial.birch"
  return birch::logpdf_beta_negative_binomial(x, this->k->value(), this->_u0961->_u0945->value(), this->_u0961->_u0946->value());
}

#line 31 "src/distribution/BetaNegativeBinomial.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::BetaNegativeBinomial::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& x) {
  #line 31 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("logpdfLazy", "src/distribution/BetaNegativeBinomial.birch", 31);
  #line 32 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(32);
  #line 32 "src/distribution/BetaNegativeBinomial.birch"
  return birch::logpdf_lazy_beta_negative_binomial(x, this->k, this->_u0961->_u0945, this->_u0961->_u0946);
}

#line 35 "src/distribution/BetaNegativeBinomial.birch"
void birch::type::BetaNegativeBinomial::update(const birch::type::Integer& x) {
  #line 35 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("update", "src/distribution/BetaNegativeBinomial.birch", 35);
  #line 36 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/BetaNegativeBinomial.birch"
  std::tie(this->_u0961->_u0945, this->_u0961->_u0946) = birch::box(birch::update_beta_negative_binomial(x, this->k->value(), this->_u0961->_u0945->value(), this->_u0961->_u0946->value()));
}

#line 39 "src/distribution/BetaNegativeBinomial.birch"
void birch::type::BetaNegativeBinomial::updateLazy(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& x) {
  #line 39 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("updateLazy", "src/distribution/BetaNegativeBinomial.birch", 39);
  #line 40 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(40);
  #line 40 "src/distribution/BetaNegativeBinomial.birch"
  std::tie(this->_u0961->_u0945, this->_u0961->_u0946) = birch::update_lazy_beta_negative_binomial(x, this->k, this->_u0961->_u0945, this->_u0961->_u0946);
}

#line 43 "src/distribution/BetaNegativeBinomial.birch"
std::optional<birch::type::Integer> birch::type::BetaNegativeBinomial::lower() {
  #line 43 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("lower", "src/distribution/BetaNegativeBinomial.birch", 43);
  #line 44 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(44);
  #line 44 "src/distribution/BetaNegativeBinomial.birch"
  return birch::type::Integer(0);
}

#line 47 "src/distribution/BetaNegativeBinomial.birch"
void birch::type::BetaNegativeBinomial::link() {
  #line 47 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("link", "src/distribution/BetaNegativeBinomial.birch", 47);
  #line 48 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(48);
  #line 48 "src/distribution/BetaNegativeBinomial.birch"
  this->_u0961->setChild(this->shared_from_this_());
}

#line 51 "src/distribution/BetaNegativeBinomial.birch"
void birch::type::BetaNegativeBinomial::unlink() {
  #line 51 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("unlink", "src/distribution/BetaNegativeBinomial.birch", 51);
  #line 52 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/BetaNegativeBinomial.birch"
  this->_u0961->releaseChild(this->shared_from_this_());
}

#line 56 "src/distribution/BetaNegativeBinomial.birch"
libbirch::Shared<birch::type::BetaNegativeBinomial> birch::BetaNegativeBinomial(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& k, const libbirch::Shared<birch::type::Beta>& _u0961) {
  #line 56 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("BetaNegativeBinomial", "src/distribution/BetaNegativeBinomial.birch", 56);
  #line 58 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(58);
  #line 58 "src/distribution/BetaNegativeBinomial.birch"
  libbirch::Shared<birch::type::BetaNegativeBinomial> m = libbirch::make<libbirch::Shared<birch::type::BetaNegativeBinomial>>(std::in_place, k, _u0961);
  #line 59 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(59);
  #line 59 "src/distribution/BetaNegativeBinomial.birch"
  m->link();
  #line 60 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/BetaNegativeBinomial.birch"
  return m;
}

#line 4 "src/distribution/Binomial.birch"
birch::type::Binomial::Binomial(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& n, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0961) :
    #line 4 "src/distribution/Binomial.birch"
    base_type_(),
    #line 9 "src/distribution/Binomial.birch"
    n(std::move(n)),
    #line 14 "src/distribution/Binomial.birch"
    _u0961(std::move(_u0961)) {
  //
}

#line 16 "src/distribution/Binomial.birch"
birch::type::Boolean birch::type::Binomial::supportsLazy() {
  #line 16 "src/distribution/Binomial.birch"
  libbirch_function_("supportsLazy", "src/distribution/Binomial.birch", 16);
  #line 17 "src/distribution/Binomial.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/Binomial.birch"
  return true;
}

#line 20 "src/distribution/Binomial.birch"
birch::type::Integer birch::type::Binomial::simulate() {
  #line 20 "src/distribution/Binomial.birch"
  libbirch_function_("simulate", "src/distribution/Binomial.birch", 20);
  #line 21 "src/distribution/Binomial.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/Binomial.birch"
  return birch::simulate_binomial(this->n->value(), this->_u0961->value());
}

#line 24 "src/distribution/Binomial.birch"
std::optional<birch::type::Integer> birch::type::Binomial::simulateLazy() {
  #line 24 "src/distribution/Binomial.birch"
  libbirch_function_("simulateLazy", "src/distribution/Binomial.birch", 24);
  #line 25 "src/distribution/Binomial.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/Binomial.birch"
  return birch::simulate_binomial(this->n->get(), this->_u0961->get());
}

#line 28 "src/distribution/Binomial.birch"
birch::type::Real birch::type::Binomial::logpdf(const birch::type::Integer& x) {
  #line 28 "src/distribution/Binomial.birch"
  libbirch_function_("logpdf", "src/distribution/Binomial.birch", 28);
  #line 29 "src/distribution/Binomial.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/Binomial.birch"
  return birch::logpdf_binomial(x, this->n->value(), this->_u0961->value());
}

#line 32 "src/distribution/Binomial.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::Binomial::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& x) {
  #line 32 "src/distribution/Binomial.birch"
  libbirch_function_("logpdfLazy", "src/distribution/Binomial.birch", 32);
  #line 33 "src/distribution/Binomial.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/Binomial.birch"
  return birch::logpdf_lazy_binomial(x, this->n, this->_u0961);
}

#line 36 "src/distribution/Binomial.birch"
std::optional<birch::type::Real> birch::type::Binomial::cdf(const birch::type::Integer& x) {
  #line 36 "src/distribution/Binomial.birch"
  libbirch_function_("cdf", "src/distribution/Binomial.birch", 36);
  #line 37 "src/distribution/Binomial.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/Binomial.birch"
  return birch::cdf_binomial(x, this->n->value(), this->_u0961->value());
}

#line 40 "src/distribution/Binomial.birch"
std::optional<birch::type::Integer> birch::type::Binomial::quantile(const birch::type::Real& P) {
  #line 40 "src/distribution/Binomial.birch"
  libbirch_function_("quantile", "src/distribution/Binomial.birch", 40);
  #line 41 "src/distribution/Binomial.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/Binomial.birch"
  return birch::quantile_binomial(P, this->n->value(), this->_u0961->value());
}

#line 44 "src/distribution/Binomial.birch"
std::optional<birch::type::Integer> birch::type::Binomial::lower() {
  #line 44 "src/distribution/Binomial.birch"
  libbirch_function_("lower", "src/distribution/Binomial.birch", 44);
  #line 45 "src/distribution/Binomial.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/Binomial.birch"
  return birch::type::Integer(0);
}

#line 48 "src/distribution/Binomial.birch"
std::optional<birch::type::Integer> birch::type::Binomial::upper() {
  #line 48 "src/distribution/Binomial.birch"
  libbirch_function_("upper", "src/distribution/Binomial.birch", 48);
  #line 49 "src/distribution/Binomial.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/Binomial.birch"
  return this->n->value();
}

#line 52 "src/distribution/Binomial.birch"
void birch::type::Binomial::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 52 "src/distribution/Binomial.birch"
  libbirch_function_("write", "src/distribution/Binomial.birch", 52);
  #line 53 "src/distribution/Binomial.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/Binomial.birch"
  this->prune();
  #line 54 "src/distribution/Binomial.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/Binomial.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Binomial"));
  #line 55 "src/distribution/Binomial.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/Binomial.birch"
  buffer->set(birch::type::String("n"), this->n);
  #line 56 "src/distribution/Binomial.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/Binomial.birch"
  buffer->set(birch::type::String("ρ"), this->_u0961);
}

#line 63 "src/distribution/Binomial.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Integer>> birch::Binomial(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& n, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0961) {
  #line 63 "src/distribution/Binomial.birch"
  libbirch_function_("Binomial", "src/distribution/Binomial.birch", 63);
  #line 65 "src/distribution/Binomial.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/Binomial.birch"
  std::optional<libbirch::Shared<birch::type::Beta>> m = libbirch::make<std::optional<libbirch::Shared<birch::type::Beta>>>();
  #line 66 "src/distribution/Binomial.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/Binomial.birch"
  if ((m = _u0961->graftBeta()).has_value()) {
    #line 67 "src/distribution/Binomial.birch"
    libbirch_line_(67);
    #line 67 "src/distribution/Binomial.birch"
    return birch::BetaBinomial(n, m.value());
  } else {
    #line 69 "src/distribution/Binomial.birch"
    libbirch_line_(69);
    #line 69 "src/distribution/Binomial.birch"
    return birch::construct<libbirch::Shared<birch::type::Binomial>>(n, _u0961);
  }
}

#line 76 "src/distribution/Binomial.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Integer>> birch::Binomial(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& n, const birch::type::Real& _u0961) {
  #line 76 "src/distribution/Binomial.birch"
  libbirch_function_("Binomial", "src/distribution/Binomial.birch", 76);
  #line 77 "src/distribution/Binomial.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/Binomial.birch"
  return birch::Binomial(n, birch::box(_u0961));
}

#line 83 "src/distribution/Binomial.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Integer>> birch::Binomial(const birch::type::Integer& n, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0961) {
  #line 83 "src/distribution/Binomial.birch"
  libbirch_function_("Binomial", "src/distribution/Binomial.birch", 83);
  #line 84 "src/distribution/Binomial.birch"
  libbirch_line_(84);
  #line 84 "src/distribution/Binomial.birch"
  return birch::Binomial(birch::box(n), _u0961);
}

#line 90 "src/distribution/Binomial.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Integer>> birch::Binomial(const birch::type::Integer& n, const birch::type::Real& _u0961) {
  #line 90 "src/distribution/Binomial.birch"
  libbirch_function_("Binomial", "src/distribution/Binomial.birch", 90);
  #line 91 "src/distribution/Binomial.birch"
  libbirch_line_(91);
  #line 91 "src/distribution/Binomial.birch"
  return birch::Binomial(birch::box(n), birch::box(_u0961));
}

#line 4 "src/distribution/BoundedDiscrete.birch"
birch::type::BoundedDiscrete::BoundedDiscrete() :
    #line 4 "src/distribution/BoundedDiscrete.birch"
    base_type_() {
  //
}

#line 8 "src/distribution/BoundedDiscrete.birch"
std::optional<libbirch::Shared<birch::type::BoundedDiscrete>> birch::type::BoundedDiscrete::graftBoundedDiscrete() {
  #line 8 "src/distribution/BoundedDiscrete.birch"
  libbirch_function_("graftBoundedDiscrete", "src/distribution/BoundedDiscrete.birch", 8);
  #line 9 "src/distribution/BoundedDiscrete.birch"
  libbirch_line_(9);
  #line 9 "src/distribution/BoundedDiscrete.birch"
  this->prune();
  #line 10 "src/distribution/BoundedDiscrete.birch"
  libbirch_line_(10);
  #line 10 "src/distribution/BoundedDiscrete.birch"
  if (this->hasClamp()) {
    #line 11 "src/distribution/BoundedDiscrete.birch"
    libbirch_line_(11);
    #line 11 "src/distribution/BoundedDiscrete.birch"
    return std::nullopt;
  } else {
    #line 13 "src/distribution/BoundedDiscrete.birch"
    libbirch_line_(13);
    #line 13 "src/distribution/BoundedDiscrete.birch"
    return this->shared_from_this_();
  }
}

#line 4 "src/distribution/Categorical.birch"
birch::type::Categorical::Categorical(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0961) :
    #line 4 "src/distribution/Categorical.birch"
    base_type_(),
    #line 8 "src/distribution/Categorical.birch"
    _u0961(std::move(_u0961)) {
  //
}

#line 10 "src/distribution/Categorical.birch"
birch::type::Boolean birch::type::Categorical::supportsLazy() {
  #line 10 "src/distribution/Categorical.birch"
  libbirch_function_("supportsLazy", "src/distribution/Categorical.birch", 10);
  #line 11 "src/distribution/Categorical.birch"
  libbirch_line_(11);
  #line 11 "src/distribution/Categorical.birch"
  return false;
}

#line 14 "src/distribution/Categorical.birch"
birch::type::Integer birch::type::Categorical::simulate() {
  #line 14 "src/distribution/Categorical.birch"
  libbirch_function_("simulate", "src/distribution/Categorical.birch", 14);
  #line 15 "src/distribution/Categorical.birch"
  libbirch_line_(15);
  #line 15 "src/distribution/Categorical.birch"
  return birch::simulate_categorical(this->_u0961->value());
}

#line 22 "src/distribution/Categorical.birch"
birch::type::Real birch::type::Categorical::logpdf(const birch::type::Integer& x) {
  #line 22 "src/distribution/Categorical.birch"
  libbirch_function_("logpdf", "src/distribution/Categorical.birch", 22);
  #line 23 "src/distribution/Categorical.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/Categorical.birch"
  return birch::logpdf_categorical(x, this->_u0961->value());
}

#line 30 "src/distribution/Categorical.birch"
std::optional<birch::type::Real> birch::type::Categorical::cdf(const birch::type::Integer& x) {
  #line 30 "src/distribution/Categorical.birch"
  libbirch_function_("cdf", "src/distribution/Categorical.birch", 30);
  #line 31 "src/distribution/Categorical.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/Categorical.birch"
  return birch::cdf_categorical(x, this->_u0961->value());
}

#line 34 "src/distribution/Categorical.birch"
std::optional<birch::type::Integer> birch::type::Categorical::quantile(const birch::type::Real& P) {
  #line 34 "src/distribution/Categorical.birch"
  libbirch_function_("quantile", "src/distribution/Categorical.birch", 34);
  #line 35 "src/distribution/Categorical.birch"
  libbirch_line_(35);
  #line 35 "src/distribution/Categorical.birch"
  return birch::quantile_categorical(P, this->_u0961->value());
}

#line 38 "src/distribution/Categorical.birch"
std::optional<birch::type::Integer> birch::type::Categorical::lower() {
  #line 38 "src/distribution/Categorical.birch"
  libbirch_function_("lower", "src/distribution/Categorical.birch", 38);
  #line 39 "src/distribution/Categorical.birch"
  libbirch_line_(39);
  #line 39 "src/distribution/Categorical.birch"
  return birch::type::Integer(1);
}

#line 42 "src/distribution/Categorical.birch"
std::optional<birch::type::Integer> birch::type::Categorical::upper() {
  #line 42 "src/distribution/Categorical.birch"
  libbirch_function_("upper", "src/distribution/Categorical.birch", 42);
  #line 43 "src/distribution/Categorical.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/Categorical.birch"
  return this->_u0961->rows();
}

#line 46 "src/distribution/Categorical.birch"
void birch::type::Categorical::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 46 "src/distribution/Categorical.birch"
  libbirch_function_("write", "src/distribution/Categorical.birch", 46);
  #line 47 "src/distribution/Categorical.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/Categorical.birch"
  this->prune();
  #line 48 "src/distribution/Categorical.birch"
  libbirch_line_(48);
  #line 48 "src/distribution/Categorical.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Categorical"));
  #line 49 "src/distribution/Categorical.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/Categorical.birch"
  buffer->set(birch::type::String("ρ"), this->_u0961);
}

#line 56 "src/distribution/Categorical.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Integer>> birch::Categorical(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0961) {
  #line 56 "src/distribution/Categorical.birch"
  libbirch_function_("Categorical", "src/distribution/Categorical.birch", 56);
  #line 57 "src/distribution/Categorical.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/Categorical.birch"
  std::optional<libbirch::Shared<birch::type::Dirichlet>> m1 = libbirch::make<std::optional<libbirch::Shared<birch::type::Dirichlet>>>();
  #line 58 "src/distribution/Categorical.birch"
  libbirch_line_(58);
  #line 58 "src/distribution/Categorical.birch"
  std::optional<libbirch::Shared<birch::type::Restaurant>> m2 = libbirch::make<std::optional<libbirch::Shared<birch::type::Restaurant>>>();
  #line 59 "src/distribution/Categorical.birch"
  libbirch_line_(59);
  #line 59 "src/distribution/Categorical.birch"
  if ((m1 = _u0961->graftDirichlet()).has_value()) {
    #line 60 "src/distribution/Categorical.birch"
    libbirch_line_(60);
    #line 60 "src/distribution/Categorical.birch"
    return birch::DirichletCategorical(m1.value());
  } else {
    #line 61 "src/distribution/Categorical.birch"
    libbirch_line_(61);
    #line 61 "src/distribution/Categorical.birch"
    if ((m2 = _u0961->graftRestaurant()).has_value()) {
      #line 62 "src/distribution/Categorical.birch"
      libbirch_line_(62);
      #line 62 "src/distribution/Categorical.birch"
      return birch::RestaurantCategorical(m2.value());
    } else {
      #line 64 "src/distribution/Categorical.birch"
      libbirch_line_(64);
      #line 64 "src/distribution/Categorical.birch"
      return birch::construct<libbirch::Shared<birch::type::Categorical>>(_u0961);
    }
  }
}

#line 71 "src/distribution/Categorical.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Integer>> birch::Categorical(const libbirch::DefaultArray<birch::type::Real,1>& _u0961) {
  #line 71 "src/distribution/Categorical.birch"
  libbirch_function_("Categorical", "src/distribution/Categorical.birch", 71);
  #line 72 "src/distribution/Categorical.birch"
  libbirch_line_(72);
  #line 72 "src/distribution/Categorical.birch"
  return birch::Categorical(birch::box(_u0961));
}

#line 7 "src/distribution/DelayDistribution.birch"
birch::type::DelayDistribution::DelayDistribution() :
    #line 7 "src/distribution/DelayDistribution.birch"
    base_type_(),
    #line 11 "src/distribution/DelayDistribution.birch"
    child(libbirch::make<std::optional<libbirch::Shared<birch::type::DelayDistribution>>>()) {
  //
}

#line 21 "src/distribution/DelayDistribution.birch"
void birch::type::DelayDistribution::prune() {
  #line 21 "src/distribution/DelayDistribution.birch"
  libbirch_function_("prune", "src/distribution/DelayDistribution.birch", 21);
  #line 22 "src/distribution/DelayDistribution.birch"
  libbirch_line_(22);
  #line 22 "src/distribution/DelayDistribution.birch"
  if (this->child.has_value()) {
    #line 23 "src/distribution/DelayDistribution.birch"
    libbirch_line_(23);
    #line 23 "src/distribution/DelayDistribution.birch"
    this->child.value()->realize();
  }
  #line 25 "src/distribution/DelayDistribution.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/DelayDistribution.birch"
  libbirch_assert_(!(this->child.has_value()));
}

#line 35 "src/distribution/DelayDistribution.birch"
void birch::type::DelayDistribution::setChild(const libbirch::Shared<birch::type::DelayDistribution>& child) {
  #line 35 "src/distribution/DelayDistribution.birch"
  libbirch_function_("setChild", "src/distribution/DelayDistribution.birch", 35);
  #line 36 "src/distribution/DelayDistribution.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/DelayDistribution.birch"
  libbirch_assert_(!(this->child.has_value()) || this->child.value() == child);
  #line 37 "src/distribution/DelayDistribution.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/DelayDistribution.birch"
  this->child = child;
}

#line 47 "src/distribution/DelayDistribution.birch"
void birch::type::DelayDistribution::releaseChild(const libbirch::Shared<birch::type::DelayDistribution>& child) {
  #line 47 "src/distribution/DelayDistribution.birch"
  libbirch_function_("releaseChild", "src/distribution/DelayDistribution.birch", 47);
  #line 48 "src/distribution/DelayDistribution.birch"
  libbirch_line_(48);
  #line 48 "src/distribution/DelayDistribution.birch"
  libbirch_assert_(!(this->child.has_value()) || this->child.value() == child);
  #line 49 "src/distribution/DelayDistribution.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/DelayDistribution.birch"
  this->child = std::nullopt;
}

#line 55 "src/distribution/DelayDistribution.birch"
void birch::type::DelayDistribution::link() {
  #line 55 "src/distribution/DelayDistribution.birch"
  libbirch_function_("link", "src/distribution/DelayDistribution.birch", 55);
}

#line 62 "src/distribution/DelayDistribution.birch"
void birch::type::DelayDistribution::unlink() {
  #line 62 "src/distribution/DelayDistribution.birch"
  libbirch_function_("unlink", "src/distribution/DelayDistribution.birch", 62);
}

#line 5 "src/distribution/Delta.birch"
birch::type::Delta::Delta(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& _u0956) :
    #line 5 "src/distribution/Delta.birch"
    base_type_(),
    #line 9 "src/distribution/Delta.birch"
    _u0956(std::move(_u0956)) {
  //
}

#line 11 "src/distribution/Delta.birch"
birch::type::Boolean birch::type::Delta::supportsLazy() {
  #line 11 "src/distribution/Delta.birch"
  libbirch_function_("supportsLazy", "src/distribution/Delta.birch", 11);
  #line 12 "src/distribution/Delta.birch"
  libbirch_line_(12);
  #line 12 "src/distribution/Delta.birch"
  return false;
}

#line 15 "src/distribution/Delta.birch"
birch::type::Integer birch::type::Delta::simulate() {
  #line 15 "src/distribution/Delta.birch"
  libbirch_function_("simulate", "src/distribution/Delta.birch", 15);
  #line 16 "src/distribution/Delta.birch"
  libbirch_line_(16);
  #line 16 "src/distribution/Delta.birch"
  return birch::simulate_delta(this->_u0956->value());
}

#line 23 "src/distribution/Delta.birch"
birch::type::Real birch::type::Delta::logpdf(const birch::type::Integer& x) {
  #line 23 "src/distribution/Delta.birch"
  libbirch_function_("logpdf", "src/distribution/Delta.birch", 23);
  #line 24 "src/distribution/Delta.birch"
  libbirch_line_(24);
  #line 24 "src/distribution/Delta.birch"
  return birch::logpdf_delta(x, this->_u0956->value());
}

#line 31 "src/distribution/Delta.birch"
std::optional<birch::type::Integer> birch::type::Delta::lower() {
  #line 31 "src/distribution/Delta.birch"
  libbirch_function_("lower", "src/distribution/Delta.birch", 31);
  #line 32 "src/distribution/Delta.birch"
  libbirch_line_(32);
  #line 32 "src/distribution/Delta.birch"
  return this->_u0956->value();
}

#line 35 "src/distribution/Delta.birch"
std::optional<birch::type::Integer> birch::type::Delta::upper() {
  #line 35 "src/distribution/Delta.birch"
  libbirch_function_("upper", "src/distribution/Delta.birch", 35);
  #line 36 "src/distribution/Delta.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/Delta.birch"
  return this->_u0956->value();
}

#line 39 "src/distribution/Delta.birch"
void birch::type::Delta::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 39 "src/distribution/Delta.birch"
  libbirch_function_("write", "src/distribution/Delta.birch", 39);
  #line 40 "src/distribution/Delta.birch"
  libbirch_line_(40);
  #line 40 "src/distribution/Delta.birch"
  this->prune();
  #line 41 "src/distribution/Delta.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/Delta.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Delta"));
  #line 42 "src/distribution/Delta.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/Delta.birch"
  buffer->set(birch::type::String("μ"), this->_u0956);
}

#line 51 "src/distribution/Delta.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Integer>> birch::Delta(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& _u0956) {
  #line 51 "src/distribution/Delta.birch"
  libbirch_function_("Delta", "src/distribution/Delta.birch", 51);
  #line 52 "src/distribution/Delta.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/Delta.birch"
  std::optional<libbirch::Shared<birch::type::Discrete>> m = libbirch::make<std::optional<libbirch::Shared<birch::type::Discrete>>>();
  #line 53 "src/distribution/Delta.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/Delta.birch"
  if ((m = _u0956->graftDiscrete()).has_value()) {
    #line 54 "src/distribution/Delta.birch"
    libbirch_line_(54);
    #line 54 "src/distribution/Delta.birch"
    return birch::DiscreteDelta(m.value());
  } else {
    #line 56 "src/distribution/Delta.birch"
    libbirch_line_(56);
    #line 56 "src/distribution/Delta.birch"
    return birch::construct<libbirch::Shared<birch::type::Delta>>(_u0956);
  }
}

#line 65 "src/distribution/Delta.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Integer>> birch::Delta(const birch::type::Integer& _u0956) {
  #line 65 "src/distribution/Delta.birch"
  libbirch_function_("Delta", "src/distribution/Delta.birch", 65);
  #line 66 "src/distribution/Delta.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/Delta.birch"
  return birch::Delta(birch::box(_u0956));
}

#line 4 "src/distribution/Dirichlet.birch"
birch::type::Dirichlet::Dirichlet(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0945) :
    #line 4 "src/distribution/Dirichlet.birch"
    base_type_(),
    #line 8 "src/distribution/Dirichlet.birch"
    _u0945(std::move(_u0945)) {
  //
}

#line 10 "src/distribution/Dirichlet.birch"
birch::type::Boolean birch::type::Dirichlet::supportsLazy() {
  #line 10 "src/distribution/Dirichlet.birch"
  libbirch_function_("supportsLazy", "src/distribution/Dirichlet.birch", 10);
  #line 11 "src/distribution/Dirichlet.birch"
  libbirch_line_(11);
  #line 11 "src/distribution/Dirichlet.birch"
  return false;
}

#line 14 "src/distribution/Dirichlet.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::Dirichlet::simulate() {
  #line 14 "src/distribution/Dirichlet.birch"
  libbirch_function_("simulate", "src/distribution/Dirichlet.birch", 14);
  #line 15 "src/distribution/Dirichlet.birch"
  libbirch_line_(15);
  #line 15 "src/distribution/Dirichlet.birch"
  return birch::simulate_dirichlet(this->_u0945->value());
}

#line 22 "src/distribution/Dirichlet.birch"
birch::type::Real birch::type::Dirichlet::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 22 "src/distribution/Dirichlet.birch"
  libbirch_function_("logpdf", "src/distribution/Dirichlet.birch", 22);
  #line 23 "src/distribution/Dirichlet.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/Dirichlet.birch"
  return birch::logpdf_dirichlet(x, this->_u0945->value());
}

#line 30 "src/distribution/Dirichlet.birch"
std::optional<libbirch::Shared<birch::type::Dirichlet>> birch::type::Dirichlet::graftDirichlet() {
  #line 30 "src/distribution/Dirichlet.birch"
  libbirch_function_("graftDirichlet", "src/distribution/Dirichlet.birch", 30);
  #line 31 "src/distribution/Dirichlet.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/Dirichlet.birch"
  this->prune();
  #line 32 "src/distribution/Dirichlet.birch"
  libbirch_line_(32);
  #line 32 "src/distribution/Dirichlet.birch"
  return this->shared_from_this_();
}

#line 35 "src/distribution/Dirichlet.birch"
void birch::type::Dirichlet::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 35 "src/distribution/Dirichlet.birch"
  libbirch_function_("write", "src/distribution/Dirichlet.birch", 35);
  #line 36 "src/distribution/Dirichlet.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/Dirichlet.birch"
  this->prune();
  #line 37 "src/distribution/Dirichlet.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/Dirichlet.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Dirichlet"));
  #line 38 "src/distribution/Dirichlet.birch"
  libbirch_line_(38);
  #line 38 "src/distribution/Dirichlet.birch"
  buffer->set(birch::type::String("α"), this->_u0945);
}

#line 45 "src/distribution/Dirichlet.birch"
libbirch::Shared<birch::type::Dirichlet> birch::Dirichlet(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0945) {
  #line 45 "src/distribution/Dirichlet.birch"
  libbirch_function_("Dirichlet", "src/distribution/Dirichlet.birch", 45);
  #line 46 "src/distribution/Dirichlet.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/Dirichlet.birch"
  return birch::construct<libbirch::Shared<birch::type::Dirichlet>>(_u0945);
}

#line 52 "src/distribution/Dirichlet.birch"
libbirch::Shared<birch::type::Dirichlet> birch::Dirichlet(const libbirch::DefaultArray<birch::type::Real,1>& _u0945) {
  #line 52 "src/distribution/Dirichlet.birch"
  libbirch_function_("Dirichlet", "src/distribution/Dirichlet.birch", 52);
  #line 53 "src/distribution/Dirichlet.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/Dirichlet.birch"
  return birch::Dirichlet(birch::box(_u0945));
}

#line 4 "src/distribution/DirichletCategorical.birch"
birch::type::DirichletCategorical::DirichletCategorical(const libbirch::Shared<birch::type::Dirichlet>& _u0961) :
    #line 4 "src/distribution/DirichletCategorical.birch"
    base_type_(),
    #line 8 "src/distribution/DirichletCategorical.birch"
    _u0961(std::move(_u0961)) {
  //
}

#line 10 "src/distribution/DirichletCategorical.birch"
birch::type::Boolean birch::type::DirichletCategorical::supportsLazy() {
  #line 10 "src/distribution/DirichletCategorical.birch"
  libbirch_function_("supportsLazy", "src/distribution/DirichletCategorical.birch", 10);
  #line 11 "src/distribution/DirichletCategorical.birch"
  libbirch_line_(11);
  #line 11 "src/distribution/DirichletCategorical.birch"
  return false;
}

#line 14 "src/distribution/DirichletCategorical.birch"
birch::type::Integer birch::type::DirichletCategorical::simulate() {
  #line 14 "src/distribution/DirichletCategorical.birch"
  libbirch_function_("simulate", "src/distribution/DirichletCategorical.birch", 14);
  #line 15 "src/distribution/DirichletCategorical.birch"
  libbirch_line_(15);
  #line 15 "src/distribution/DirichletCategorical.birch"
  return birch::simulate_dirichlet_categorical(this->_u0961->_u0945->value());
}

#line 22 "src/distribution/DirichletCategorical.birch"
birch::type::Real birch::type::DirichletCategorical::logpdf(const birch::type::Integer& x) {
  #line 22 "src/distribution/DirichletCategorical.birch"
  libbirch_function_("logpdf", "src/distribution/DirichletCategorical.birch", 22);
  #line 23 "src/distribution/DirichletCategorical.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/DirichletCategorical.birch"
  return birch::logpdf_dirichlet_categorical(x, this->_u0961->_u0945->value());
}

#line 30 "src/distribution/DirichletCategorical.birch"
void birch::type::DirichletCategorical::update(const birch::type::Integer& x) {
  #line 30 "src/distribution/DirichletCategorical.birch"
  libbirch_function_("update", "src/distribution/DirichletCategorical.birch", 30);
  #line 31 "src/distribution/DirichletCategorical.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/DirichletCategorical.birch"
  this->_u0961->_u0945 = birch::box(birch::update_dirichlet_categorical(x, this->_u0961->_u0945->value()));
}

#line 38 "src/distribution/DirichletCategorical.birch"
std::optional<birch::type::Integer> birch::type::DirichletCategorical::lower() {
  #line 38 "src/distribution/DirichletCategorical.birch"
  libbirch_function_("lower", "src/distribution/DirichletCategorical.birch", 38);
  #line 39 "src/distribution/DirichletCategorical.birch"
  libbirch_line_(39);
  #line 39 "src/distribution/DirichletCategorical.birch"
  return birch::type::Integer(1);
}

#line 42 "src/distribution/DirichletCategorical.birch"
std::optional<birch::type::Integer> birch::type::DirichletCategorical::upper() {
  #line 42 "src/distribution/DirichletCategorical.birch"
  libbirch_function_("upper", "src/distribution/DirichletCategorical.birch", 42);
  #line 43 "src/distribution/DirichletCategorical.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/DirichletCategorical.birch"
  return this->_u0961->_u0945->rows();
}

#line 46 "src/distribution/DirichletCategorical.birch"
void birch::type::DirichletCategorical::link() {
  #line 46 "src/distribution/DirichletCategorical.birch"
  libbirch_function_("link", "src/distribution/DirichletCategorical.birch", 46);
  #line 47 "src/distribution/DirichletCategorical.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/DirichletCategorical.birch"
  this->_u0961->setChild(this->shared_from_this_());
}

#line 50 "src/distribution/DirichletCategorical.birch"
void birch::type::DirichletCategorical::unlink() {
  #line 50 "src/distribution/DirichletCategorical.birch"
  libbirch_function_("unlink", "src/distribution/DirichletCategorical.birch", 50);
  #line 51 "src/distribution/DirichletCategorical.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/DirichletCategorical.birch"
  this->_u0961->releaseChild(this->shared_from_this_());
}

#line 55 "src/distribution/DirichletCategorical.birch"
libbirch::Shared<birch::type::DirichletCategorical> birch::DirichletCategorical(const libbirch::Shared<birch::type::Dirichlet>& _u0961) {
  #line 55 "src/distribution/DirichletCategorical.birch"
  libbirch_function_("DirichletCategorical", "src/distribution/DirichletCategorical.birch", 55);
  #line 56 "src/distribution/DirichletCategorical.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/DirichletCategorical.birch"
  libbirch::Shared<birch::type::DirichletCategorical> m = libbirch::make<libbirch::Shared<birch::type::DirichletCategorical>>(std::in_place, _u0961);
  #line 57 "src/distribution/DirichletCategorical.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/DirichletCategorical.birch"
  m->link();
  #line 58 "src/distribution/DirichletCategorical.birch"
  libbirch_line_(58);
  #line 58 "src/distribution/DirichletCategorical.birch"
  return m;
}

#line 4 "src/distribution/DirichletMultinomial.birch"
birch::type::DirichletMultinomial::DirichletMultinomial(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& n, const libbirch::Shared<birch::type::Dirichlet>& _u0961) :
    #line 4 "src/distribution/DirichletMultinomial.birch"
    base_type_(),
    #line 9 "src/distribution/DirichletMultinomial.birch"
    n(std::move(n)),
    #line 14 "src/distribution/DirichletMultinomial.birch"
    _u0961(std::move(_u0961)) {
  //
}

#line 16 "src/distribution/DirichletMultinomial.birch"
birch::type::Boolean birch::type::DirichletMultinomial::supportsLazy() {
  #line 16 "src/distribution/DirichletMultinomial.birch"
  libbirch_function_("supportsLazy", "src/distribution/DirichletMultinomial.birch", 16);
  #line 17 "src/distribution/DirichletMultinomial.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/DirichletMultinomial.birch"
  return false;
}

#line 20 "src/distribution/DirichletMultinomial.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::type::DirichletMultinomial::simulate() {
  #line 20 "src/distribution/DirichletMultinomial.birch"
  libbirch_function_("simulate", "src/distribution/DirichletMultinomial.birch", 20);
  #line 21 "src/distribution/DirichletMultinomial.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/DirichletMultinomial.birch"
  return birch::simulate_dirichlet_multinomial(this->n->value(), this->_u0961->_u0945->value());
}

#line 28 "src/distribution/DirichletMultinomial.birch"
birch::type::Real birch::type::DirichletMultinomial::logpdf(const libbirch::DefaultArray<birch::type::Integer,1>& x) {
  #line 28 "src/distribution/DirichletMultinomial.birch"
  libbirch_function_("logpdf", "src/distribution/DirichletMultinomial.birch", 28);
  #line 29 "src/distribution/DirichletMultinomial.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/DirichletMultinomial.birch"
  return birch::logpdf_dirichlet_multinomial(x, this->n->value(), this->_u0961->_u0945->value());
}

#line 36 "src/distribution/DirichletMultinomial.birch"
void birch::type::DirichletMultinomial::update(const libbirch::DefaultArray<birch::type::Integer,1>& x) {
  #line 36 "src/distribution/DirichletMultinomial.birch"
  libbirch_function_("update", "src/distribution/DirichletMultinomial.birch", 36);
  #line 37 "src/distribution/DirichletMultinomial.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/DirichletMultinomial.birch"
  this->_u0961->_u0945 = birch::box(birch::update_dirichlet_multinomial(x, this->n->value(), this->_u0961->_u0945->value()));
}

#line 44 "src/distribution/DirichletMultinomial.birch"
void birch::type::DirichletMultinomial::link() {
  #line 44 "src/distribution/DirichletMultinomial.birch"
  libbirch_function_("link", "src/distribution/DirichletMultinomial.birch", 44);
  #line 45 "src/distribution/DirichletMultinomial.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/DirichletMultinomial.birch"
  this->_u0961->setChild(this->shared_from_this_());
}

#line 48 "src/distribution/DirichletMultinomial.birch"
void birch::type::DirichletMultinomial::unlink() {
  #line 48 "src/distribution/DirichletMultinomial.birch"
  libbirch_function_("unlink", "src/distribution/DirichletMultinomial.birch", 48);
  #line 49 "src/distribution/DirichletMultinomial.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/DirichletMultinomial.birch"
  this->_u0961->releaseChild(this->shared_from_this_());
}

#line 53 "src/distribution/DirichletMultinomial.birch"
libbirch::Shared<birch::type::DirichletMultinomial> birch::DirichletMultinomial(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& n, const libbirch::Shared<birch::type::Dirichlet>& _u0961) {
  #line 53 "src/distribution/DirichletMultinomial.birch"
  libbirch_function_("DirichletMultinomial", "src/distribution/DirichletMultinomial.birch", 53);
  #line 55 "src/distribution/DirichletMultinomial.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/DirichletMultinomial.birch"
  libbirch::Shared<birch::type::DirichletMultinomial> m = libbirch::make<libbirch::Shared<birch::type::DirichletMultinomial>>(std::in_place, n, _u0961);
  #line 56 "src/distribution/DirichletMultinomial.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/DirichletMultinomial.birch"
  m->link();
  #line 57 "src/distribution/DirichletMultinomial.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/DirichletMultinomial.birch"
  return m;
}

#line 4 "src/distribution/Discrete.birch"
birch::type::Discrete::Discrete() :
    #line 4 "src/distribution/Discrete.birch"
    base_type_() {
  //
}

#line 5 "src/distribution/Discrete.birch"
std::optional<libbirch::Shared<birch::type::Discrete>> birch::type::Discrete::graftDiscrete() {
  #line 5 "src/distribution/Discrete.birch"
  libbirch_function_("graftDiscrete", "src/distribution/Discrete.birch", 5);
  #line 6 "src/distribution/Discrete.birch"
  libbirch_line_(6);
  #line 6 "src/distribution/Discrete.birch"
  this->prune();
  #line 7 "src/distribution/Discrete.birch"
  libbirch_line_(7);
  #line 7 "src/distribution/Discrete.birch"
  if (this->hasClamp()) {
    #line 8 "src/distribution/Discrete.birch"
    libbirch_line_(8);
    #line 8 "src/distribution/Discrete.birch"
    return std::nullopt;
  } else {
    #line 10 "src/distribution/Discrete.birch"
    libbirch_line_(10);
    #line 10 "src/distribution/Discrete.birch"
    return this->shared_from_this_();
  }
}

#line 4 "src/distribution/DiscreteDelta.birch"
birch::type::DiscreteDelta::DiscreteDelta(const libbirch::Shared<birch::type::Discrete>& _u0956) :
    #line 4 "src/distribution/DiscreteDelta.birch"
    base_type_(),
    #line 8 "src/distribution/DiscreteDelta.birch"
    _u0956(std::move(_u0956)) {
  //
}

#line 10 "src/distribution/DiscreteDelta.birch"
birch::type::Boolean birch::type::DiscreteDelta::supportsLazy() {
  #line 10 "src/distribution/DiscreteDelta.birch"
  libbirch_function_("supportsLazy", "src/distribution/DiscreteDelta.birch", 10);
  #line 11 "src/distribution/DiscreteDelta.birch"
  libbirch_line_(11);
  #line 11 "src/distribution/DiscreteDelta.birch"
  return false;
}

#line 14 "src/distribution/DiscreteDelta.birch"
birch::type::Integer birch::type::DiscreteDelta::simulate() {
  #line 14 "src/distribution/DiscreteDelta.birch"
  libbirch_function_("simulate", "src/distribution/DiscreteDelta.birch", 14);
  #line 15 "src/distribution/DiscreteDelta.birch"
  libbirch_line_(15);
  #line 15 "src/distribution/DiscreteDelta.birch"
  return birch::simulate_delta(this->_u0956->simulate());
}

#line 22 "src/distribution/DiscreteDelta.birch"
birch::type::Real birch::type::DiscreteDelta::logpdf(const birch::type::Integer& x) {
  #line 22 "src/distribution/DiscreteDelta.birch"
  libbirch_function_("logpdf", "src/distribution/DiscreteDelta.birch", 22);
  #line 23 "src/distribution/DiscreteDelta.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/DiscreteDelta.birch"
  return this->_u0956->logpdf(x);
}

#line 30 "src/distribution/DiscreteDelta.birch"
void birch::type::DiscreteDelta::update(const birch::type::Integer& x) {
  #line 30 "src/distribution/DiscreteDelta.birch"
  libbirch_function_("update", "src/distribution/DiscreteDelta.birch", 30);
  #line 31 "src/distribution/DiscreteDelta.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/DiscreteDelta.birch"
  this->_u0956->clamp(x);
}

#line 38 "src/distribution/DiscreteDelta.birch"
std::optional<birch::type::Real> birch::type::DiscreteDelta::cdf(const birch::type::Integer& x) {
  #line 38 "src/distribution/DiscreteDelta.birch"
  libbirch_function_("cdf", "src/distribution/DiscreteDelta.birch", 38);
  #line 39 "src/distribution/DiscreteDelta.birch"
  libbirch_line_(39);
  #line 39 "src/distribution/DiscreteDelta.birch"
  return this->_u0956->cdf(x);
}

#line 42 "src/distribution/DiscreteDelta.birch"
std::optional<birch::type::Integer> birch::type::DiscreteDelta::lower() {
  #line 42 "src/distribution/DiscreteDelta.birch"
  libbirch_function_("lower", "src/distribution/DiscreteDelta.birch", 42);
  #line 43 "src/distribution/DiscreteDelta.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/DiscreteDelta.birch"
  return this->_u0956->lower();
}

#line 46 "src/distribution/DiscreteDelta.birch"
std::optional<birch::type::Integer> birch::type::DiscreteDelta::upper() {
  #line 46 "src/distribution/DiscreteDelta.birch"
  libbirch_function_("upper", "src/distribution/DiscreteDelta.birch", 46);
  #line 47 "src/distribution/DiscreteDelta.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/DiscreteDelta.birch"
  return this->_u0956->upper();
}

#line 50 "src/distribution/DiscreteDelta.birch"
void birch::type::DiscreteDelta::link() {
  #line 50 "src/distribution/DiscreteDelta.birch"
  libbirch_function_("link", "src/distribution/DiscreteDelta.birch", 50);
  #line 51 "src/distribution/DiscreteDelta.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/DiscreteDelta.birch"
  this->_u0956->setChild(this->shared_from_this_());
}

#line 54 "src/distribution/DiscreteDelta.birch"
void birch::type::DiscreteDelta::unlink() {
  #line 54 "src/distribution/DiscreteDelta.birch"
  libbirch_function_("unlink", "src/distribution/DiscreteDelta.birch", 54);
  #line 55 "src/distribution/DiscreteDelta.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/DiscreteDelta.birch"
  this->_u0956->releaseChild(this->shared_from_this_());
}

#line 59 "src/distribution/DiscreteDelta.birch"
libbirch::Shared<birch::type::DiscreteDelta> birch::DiscreteDelta(const libbirch::Shared<birch::type::Discrete>& _u0956) {
  #line 59 "src/distribution/DiscreteDelta.birch"
  libbirch_function_("DiscreteDelta", "src/distribution/DiscreteDelta.birch", 59);
  #line 60 "src/distribution/DiscreteDelta.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/DiscreteDelta.birch"
  libbirch::Shared<birch::type::DiscreteDelta> m = libbirch::make<libbirch::Shared<birch::type::DiscreteDelta>>(std::in_place, _u0956);
  #line 61 "src/distribution/DiscreteDelta.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/DiscreteDelta.birch"
  m->link();
  #line 62 "src/distribution/DiscreteDelta.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/DiscreteDelta.birch"
  return m;
}

#line 4 "src/distribution/Exponential.birch"
birch::type::Exponential::Exponential(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0955) :
    #line 4 "src/distribution/Exponential.birch"
    base_type_(),
    #line 8 "src/distribution/Exponential.birch"
    _u0955(std::move(_u0955)) {
  //
}

#line 10 "src/distribution/Exponential.birch"
birch::type::Boolean birch::type::Exponential::supportsLazy() {
  #line 10 "src/distribution/Exponential.birch"
  libbirch_function_("supportsLazy", "src/distribution/Exponential.birch", 10);
  #line 11 "src/distribution/Exponential.birch"
  libbirch_line_(11);
  #line 11 "src/distribution/Exponential.birch"
  return true;
}

#line 14 "src/distribution/Exponential.birch"
birch::type::Real birch::type::Exponential::simulate() {
  #line 14 "src/distribution/Exponential.birch"
  libbirch_function_("simulate", "src/distribution/Exponential.birch", 14);
  #line 15 "src/distribution/Exponential.birch"
  libbirch_line_(15);
  #line 15 "src/distribution/Exponential.birch"
  return birch::simulate_exponential(this->_u0955->value());
}

#line 18 "src/distribution/Exponential.birch"
std::optional<birch::type::Real> birch::type::Exponential::simulateLazy() {
  #line 18 "src/distribution/Exponential.birch"
  libbirch_function_("simulateLazy", "src/distribution/Exponential.birch", 18);
  #line 19 "src/distribution/Exponential.birch"
  libbirch_line_(19);
  #line 19 "src/distribution/Exponential.birch"
  return birch::simulate_exponential(this->_u0955->get());
}

#line 22 "src/distribution/Exponential.birch"
birch::type::Real birch::type::Exponential::logpdf(const birch::type::Real& x) {
  #line 22 "src/distribution/Exponential.birch"
  libbirch_function_("logpdf", "src/distribution/Exponential.birch", 22);
  #line 23 "src/distribution/Exponential.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/Exponential.birch"
  return birch::logpdf_exponential(x, this->_u0955->value());
}

#line 26 "src/distribution/Exponential.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::Exponential::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 26 "src/distribution/Exponential.birch"
  libbirch_function_("logpdfLazy", "src/distribution/Exponential.birch", 26);
  #line 27 "src/distribution/Exponential.birch"
  libbirch_line_(27);
  #line 27 "src/distribution/Exponential.birch"
  return birch::logpdf_lazy_exponential(x, this->_u0955);
}

#line 30 "src/distribution/Exponential.birch"
std::optional<birch::type::Real> birch::type::Exponential::cdf(const birch::type::Real& x) {
  #line 30 "src/distribution/Exponential.birch"
  libbirch_function_("cdf", "src/distribution/Exponential.birch", 30);
  #line 31 "src/distribution/Exponential.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/Exponential.birch"
  return birch::cdf_exponential(x, this->_u0955->value());
}

#line 34 "src/distribution/Exponential.birch"
std::optional<birch::type::Real> birch::type::Exponential::quantile(const birch::type::Real& P) {
  #line 34 "src/distribution/Exponential.birch"
  libbirch_function_("quantile", "src/distribution/Exponential.birch", 34);
  #line 35 "src/distribution/Exponential.birch"
  libbirch_line_(35);
  #line 35 "src/distribution/Exponential.birch"
  return birch::quantile_exponential(P, this->_u0955->value());
}

#line 38 "src/distribution/Exponential.birch"
std::optional<birch::type::Real> birch::type::Exponential::lower() {
  #line 38 "src/distribution/Exponential.birch"
  libbirch_function_("lower", "src/distribution/Exponential.birch", 38);
  #line 39 "src/distribution/Exponential.birch"
  libbirch_line_(39);
  #line 39 "src/distribution/Exponential.birch"
  return 0.0;
}

#line 42 "src/distribution/Exponential.birch"
void birch::type::Exponential::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 42 "src/distribution/Exponential.birch"
  libbirch_function_("write", "src/distribution/Exponential.birch", 42);
  #line 43 "src/distribution/Exponential.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/Exponential.birch"
  this->prune();
  #line 44 "src/distribution/Exponential.birch"
  libbirch_line_(44);
  #line 44 "src/distribution/Exponential.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Exponential"));
  #line 45 "src/distribution/Exponential.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/Exponential.birch"
  buffer->set(birch::type::String("λ"), this->_u0955);
}

#line 52 "src/distribution/Exponential.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::Exponential(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0955) {
  #line 52 "src/distribution/Exponential.birch"
  libbirch_function_("Exponential", "src/distribution/Exponential.birch", 52);
  #line 53 "src/distribution/Exponential.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/Exponential.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gamma>>>> m1 = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gamma>>>>>();
  #line 54 "src/distribution/Exponential.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/Exponential.birch"
  std::optional<libbirch::Shared<birch::type::Gamma>> m2 = libbirch::make<std::optional<libbirch::Shared<birch::type::Gamma>>>();
  #line 55 "src/distribution/Exponential.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/Exponential.birch"
  if ((m1 = _u0955->graftScaledGamma()).has_value()) {
    #line 56 "src/distribution/Exponential.birch"
    libbirch_line_(56);
    #line 56 "src/distribution/Exponential.birch"
    return birch::ScaledGammaExponential(m1.value()->a, m1.value()->x);
  } else {
    #line 57 "src/distribution/Exponential.birch"
    libbirch_line_(57);
    #line 57 "src/distribution/Exponential.birch"
    if ((m2 = _u0955->graftGamma()).has_value()) {
      #line 58 "src/distribution/Exponential.birch"
      libbirch_line_(58);
      #line 58 "src/distribution/Exponential.birch"
      return birch::GammaExponential(m2.value());
    } else {
      #line 60 "src/distribution/Exponential.birch"
      libbirch_line_(60);
      #line 60 "src/distribution/Exponential.birch"
      return birch::construct<libbirch::Shared<birch::type::Exponential>>(_u0955);
    }
  }
}

#line 67 "src/distribution/Exponential.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::Exponential(const birch::type::Real& _u0955) {
  #line 67 "src/distribution/Exponential.birch"
  libbirch_function_("Exponential", "src/distribution/Exponential.birch", 67);
  #line 68 "src/distribution/Exponential.birch"
  libbirch_line_(68);
  #line 68 "src/distribution/Exponential.birch"
  return birch::Exponential(birch::box(_u0955));
}

#line 4 "src/distribution/Gamma.birch"
birch::type::Gamma::Gamma(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0952) :
    #line 4 "src/distribution/Gamma.birch"
    base_type_(),
    #line 9 "src/distribution/Gamma.birch"
    k(std::move(k)),
    #line 14 "src/distribution/Gamma.birch"
    _u0952(std::move(_u0952)) {
  //
}

#line 16 "src/distribution/Gamma.birch"
birch::type::Boolean birch::type::Gamma::supportsLazy() {
  #line 16 "src/distribution/Gamma.birch"
  libbirch_function_("supportsLazy", "src/distribution/Gamma.birch", 16);
  #line 17 "src/distribution/Gamma.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/Gamma.birch"
  return true;
}

#line 20 "src/distribution/Gamma.birch"
birch::type::Real birch::type::Gamma::simulate() {
  #line 20 "src/distribution/Gamma.birch"
  libbirch_function_("simulate", "src/distribution/Gamma.birch", 20);
  #line 21 "src/distribution/Gamma.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/Gamma.birch"
  return birch::simulate_gamma(this->k->value(), this->_u0952->value());
}

#line 24 "src/distribution/Gamma.birch"
std::optional<birch::type::Real> birch::type::Gamma::simulateLazy() {
  #line 24 "src/distribution/Gamma.birch"
  libbirch_function_("simulateLazy", "src/distribution/Gamma.birch", 24);
  #line 25 "src/distribution/Gamma.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/Gamma.birch"
  return birch::simulate_gamma(this->k->get(), this->_u0952->get());
}

#line 28 "src/distribution/Gamma.birch"
birch::type::Real birch::type::Gamma::logpdf(const birch::type::Real& x) {
  #line 28 "src/distribution/Gamma.birch"
  libbirch_function_("logpdf", "src/distribution/Gamma.birch", 28);
  #line 29 "src/distribution/Gamma.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/Gamma.birch"
  return birch::logpdf_gamma(x, this->k->value(), this->_u0952->value());
}

#line 32 "src/distribution/Gamma.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::Gamma::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 32 "src/distribution/Gamma.birch"
  libbirch_function_("logpdfLazy", "src/distribution/Gamma.birch", 32);
  #line 33 "src/distribution/Gamma.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/Gamma.birch"
  return birch::logpdf_lazy_gamma(x, this->k, this->_u0952);
}

#line 36 "src/distribution/Gamma.birch"
std::optional<birch::type::Real> birch::type::Gamma::cdf(const birch::type::Real& x) {
  #line 36 "src/distribution/Gamma.birch"
  libbirch_function_("cdf", "src/distribution/Gamma.birch", 36);
  #line 37 "src/distribution/Gamma.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/Gamma.birch"
  return birch::cdf_gamma(x, this->k->value(), this->_u0952->value());
}

#line 40 "src/distribution/Gamma.birch"
std::optional<birch::type::Real> birch::type::Gamma::quantile(const birch::type::Real& P) {
  #line 40 "src/distribution/Gamma.birch"
  libbirch_function_("quantile", "src/distribution/Gamma.birch", 40);
  #line 41 "src/distribution/Gamma.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/Gamma.birch"
  return birch::quantile_gamma(P, this->k->value(), this->_u0952->value());
}

#line 44 "src/distribution/Gamma.birch"
std::optional<birch::type::Real> birch::type::Gamma::lower() {
  #line 44 "src/distribution/Gamma.birch"
  libbirch_function_("lower", "src/distribution/Gamma.birch", 44);
  #line 45 "src/distribution/Gamma.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/Gamma.birch"
  return 0.0;
}

#line 48 "src/distribution/Gamma.birch"
std::optional<libbirch::Shared<birch::type::Gamma>> birch::type::Gamma::graftGamma() {
  #line 48 "src/distribution/Gamma.birch"
  libbirch_function_("graftGamma", "src/distribution/Gamma.birch", 48);
  #line 49 "src/distribution/Gamma.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/Gamma.birch"
  this->prune();
  #line 50 "src/distribution/Gamma.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/Gamma.birch"
  return this->shared_from_this_();
}

#line 53 "src/distribution/Gamma.birch"
void birch::type::Gamma::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 53 "src/distribution/Gamma.birch"
  libbirch_function_("write", "src/distribution/Gamma.birch", 53);
  #line 54 "src/distribution/Gamma.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/Gamma.birch"
  this->prune();
  #line 55 "src/distribution/Gamma.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/Gamma.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Gamma"));
  #line 56 "src/distribution/Gamma.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/Gamma.birch"
  buffer->set(birch::type::String("k"), this->k);
  #line 57 "src/distribution/Gamma.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/Gamma.birch"
  buffer->set(birch::type::String("θ"), this->_u0952);
}

#line 64 "src/distribution/Gamma.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::Gamma(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0952) {
  #line 64 "src/distribution/Gamma.birch"
  libbirch_function_("Gamma", "src/distribution/Gamma.birch", 64);
  #line 65 "src/distribution/Gamma.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/Gamma.birch"
  std::optional<libbirch::Shared<birch::type::InverseGamma>> _u09521 = libbirch::make<std::optional<libbirch::Shared<birch::type::InverseGamma>>>();
  #line 66 "src/distribution/Gamma.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/Gamma.birch"
  if ((_u09521 = _u0952->graftInverseGamma()).has_value()) {
    #line 67 "src/distribution/Gamma.birch"
    libbirch_line_(67);
    #line 67 "src/distribution/Gamma.birch"
    return birch::InverseGammaGamma(k, _u09521.value());
  } else {
    #line 69 "src/distribution/Gamma.birch"
    libbirch_line_(69);
    #line 69 "src/distribution/Gamma.birch"
    return birch::construct<libbirch::Shared<birch::type::Gamma>>(k, _u0952);
  }
}

#line 76 "src/distribution/Gamma.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::Gamma(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k, const birch::type::Real& _u0952) {
  #line 76 "src/distribution/Gamma.birch"
  libbirch_function_("Gamma", "src/distribution/Gamma.birch", 76);
  #line 77 "src/distribution/Gamma.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/Gamma.birch"
  return birch::Gamma(k, birch::box(_u0952));
}

#line 83 "src/distribution/Gamma.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::Gamma(const birch::type::Real& k, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0952) {
  #line 83 "src/distribution/Gamma.birch"
  libbirch_function_("Gamma", "src/distribution/Gamma.birch", 83);
  #line 84 "src/distribution/Gamma.birch"
  libbirch_line_(84);
  #line 84 "src/distribution/Gamma.birch"
  return birch::Gamma(birch::box(k), _u0952);
}

#line 90 "src/distribution/Gamma.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::Gamma(const birch::type::Real& k, const birch::type::Real& _u0952) {
  #line 90 "src/distribution/Gamma.birch"
  libbirch_function_("Gamma", "src/distribution/Gamma.birch", 90);
  #line 91 "src/distribution/Gamma.birch"
  libbirch_line_(91);
  #line 91 "src/distribution/Gamma.birch"
  return birch::Gamma(birch::box(k), birch::box(_u0952));
}

#line 4 "src/distribution/GammaExponential.birch"
birch::type::GammaExponential::GammaExponential(const libbirch::Shared<birch::type::Gamma>& _u0955) :
    #line 4 "src/distribution/GammaExponential.birch"
    base_type_(),
    #line 8 "src/distribution/GammaExponential.birch"
    _u0955(std::move(_u0955)) {
  //
}

#line 10 "src/distribution/GammaExponential.birch"
birch::type::Boolean birch::type::GammaExponential::supportsLazy() {
  #line 10 "src/distribution/GammaExponential.birch"
  libbirch_function_("supportsLazy", "src/distribution/GammaExponential.birch", 10);
  #line 11 "src/distribution/GammaExponential.birch"
  libbirch_line_(11);
  #line 11 "src/distribution/GammaExponential.birch"
  return true;
}

#line 14 "src/distribution/GammaExponential.birch"
birch::type::Real birch::type::GammaExponential::simulate() {
  #line 14 "src/distribution/GammaExponential.birch"
  libbirch_function_("simulate", "src/distribution/GammaExponential.birch", 14);
  #line 15 "src/distribution/GammaExponential.birch"
  libbirch_line_(15);
  #line 15 "src/distribution/GammaExponential.birch"
  return birch::simulate_lomax(1.0 / this->_u0955->_u0952->value(), this->_u0955->k->value());
}

#line 18 "src/distribution/GammaExponential.birch"
std::optional<birch::type::Real> birch::type::GammaExponential::simulateLazy() {
  #line 18 "src/distribution/GammaExponential.birch"
  libbirch_function_("simulateLazy", "src/distribution/GammaExponential.birch", 18);
  #line 19 "src/distribution/GammaExponential.birch"
  libbirch_line_(19);
  #line 19 "src/distribution/GammaExponential.birch"
  return birch::simulate_lomax(1.0 / this->_u0955->_u0952->get(), this->_u0955->k->get());
}

#line 22 "src/distribution/GammaExponential.birch"
birch::type::Real birch::type::GammaExponential::logpdf(const birch::type::Real& x) {
  #line 22 "src/distribution/GammaExponential.birch"
  libbirch_function_("logpdf", "src/distribution/GammaExponential.birch", 22);
  #line 23 "src/distribution/GammaExponential.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/GammaExponential.birch"
  return birch::logpdf_lomax(x, 1.0 / this->_u0955->_u0952->value(), this->_u0955->k->value());
}

#line 26 "src/distribution/GammaExponential.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::GammaExponential::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 26 "src/distribution/GammaExponential.birch"
  libbirch_function_("logpdfLazy", "src/distribution/GammaExponential.birch", 26);
  #line 27 "src/distribution/GammaExponential.birch"
  libbirch_line_(27);
  #line 27 "src/distribution/GammaExponential.birch"
  return birch::logpdf_lazy_lomax(x, 1.0 / this->_u0955->_u0952, this->_u0955->k);
}

#line 30 "src/distribution/GammaExponential.birch"
void birch::type::GammaExponential::update(const birch::type::Real& x) {
  #line 30 "src/distribution/GammaExponential.birch"
  libbirch_function_("update", "src/distribution/GammaExponential.birch", 30);
  #line 31 "src/distribution/GammaExponential.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/GammaExponential.birch"
  std::tie(this->_u0955->k, this->_u0955->_u0952) = birch::box(birch::update_gamma_exponential(x, this->_u0955->k->value(), this->_u0955->_u0952->value()));
}

#line 34 "src/distribution/GammaExponential.birch"
void birch::type::GammaExponential::updateLazy(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 34 "src/distribution/GammaExponential.birch"
  libbirch_function_("updateLazy", "src/distribution/GammaExponential.birch", 34);
  #line 35 "src/distribution/GammaExponential.birch"
  libbirch_line_(35);
  #line 35 "src/distribution/GammaExponential.birch"
  std::tie(this->_u0955->k, this->_u0955->_u0952) = birch::update_lazy_gamma_exponential(x, this->_u0955->k, this->_u0955->_u0952);
}

#line 38 "src/distribution/GammaExponential.birch"
std::optional<birch::type::Real> birch::type::GammaExponential::cdf(const birch::type::Real& x) {
  #line 38 "src/distribution/GammaExponential.birch"
  libbirch_function_("cdf", "src/distribution/GammaExponential.birch", 38);
  #line 39 "src/distribution/GammaExponential.birch"
  libbirch_line_(39);
  #line 39 "src/distribution/GammaExponential.birch"
  return birch::cdf_lomax(x, 1.0 / this->_u0955->_u0952->value(), this->_u0955->k->value());
}

#line 42 "src/distribution/GammaExponential.birch"
std::optional<birch::type::Real> birch::type::GammaExponential::quantile(const birch::type::Real& P) {
  #line 42 "src/distribution/GammaExponential.birch"
  libbirch_function_("quantile", "src/distribution/GammaExponential.birch", 42);
  #line 43 "src/distribution/GammaExponential.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/GammaExponential.birch"
  return birch::quantile_lomax(P, 1.0 / this->_u0955->_u0952->value(), this->_u0955->k->value());
}

#line 46 "src/distribution/GammaExponential.birch"
std::optional<birch::type::Real> birch::type::GammaExponential::lower() {
  #line 46 "src/distribution/GammaExponential.birch"
  libbirch_function_("lower", "src/distribution/GammaExponential.birch", 46);
  #line 47 "src/distribution/GammaExponential.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/GammaExponential.birch"
  return 0.0;
}

#line 50 "src/distribution/GammaExponential.birch"
void birch::type::GammaExponential::link() {
  #line 50 "src/distribution/GammaExponential.birch"
  libbirch_function_("link", "src/distribution/GammaExponential.birch", 50);
  #line 51 "src/distribution/GammaExponential.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/GammaExponential.birch"
  this->_u0955->setChild(this->shared_from_this_());
}

#line 54 "src/distribution/GammaExponential.birch"
void birch::type::GammaExponential::unlink() {
  #line 54 "src/distribution/GammaExponential.birch"
  libbirch_function_("unlink", "src/distribution/GammaExponential.birch", 54);
  #line 55 "src/distribution/GammaExponential.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/GammaExponential.birch"
  this->_u0955->releaseChild(this->shared_from_this_());
}

#line 59 "src/distribution/GammaExponential.birch"
libbirch::Shared<birch::type::GammaExponential> birch::GammaExponential(const libbirch::Shared<birch::type::Gamma>& _u0955) {
  #line 59 "src/distribution/GammaExponential.birch"
  libbirch_function_("GammaExponential", "src/distribution/GammaExponential.birch", 59);
  #line 60 "src/distribution/GammaExponential.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/GammaExponential.birch"
  libbirch::Shared<birch::type::GammaExponential> m = libbirch::make<libbirch::Shared<birch::type::GammaExponential>>(std::in_place, _u0955);
  #line 61 "src/distribution/GammaExponential.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/GammaExponential.birch"
  m->link();
  #line 62 "src/distribution/GammaExponential.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/GammaExponential.birch"
  return m;
}

#line 4 "src/distribution/GammaPoisson.birch"
birch::type::GammaPoisson::GammaPoisson(const libbirch::Shared<birch::type::Gamma>& _u0955) :
    #line 4 "src/distribution/GammaPoisson.birch"
    base_type_(),
    #line 8 "src/distribution/GammaPoisson.birch"
    _u0955(std::move(_u0955)) {
  //
}

#line 10 "src/distribution/GammaPoisson.birch"
birch::type::Boolean birch::type::GammaPoisson::supportsLazy() {
  #line 10 "src/distribution/GammaPoisson.birch"
  libbirch_function_("supportsLazy", "src/distribution/GammaPoisson.birch", 10);
  #line 11 "src/distribution/GammaPoisson.birch"
  libbirch_line_(11);
  #line 11 "src/distribution/GammaPoisson.birch"
  return true;
}

#line 14 "src/distribution/GammaPoisson.birch"
birch::type::Integer birch::type::GammaPoisson::simulate() {
  #line 14 "src/distribution/GammaPoisson.birch"
  libbirch_function_("simulate", "src/distribution/GammaPoisson.birch", 14);
  #line 15 "src/distribution/GammaPoisson.birch"
  libbirch_line_(15);
  #line 15 "src/distribution/GammaPoisson.birch"
  return birch::simulate_gamma_poisson(this->_u0955->k->value(), this->_u0955->_u0952->value());
}

#line 18 "src/distribution/GammaPoisson.birch"
std::optional<birch::type::Integer> birch::type::GammaPoisson::simulateLazy() {
  #line 18 "src/distribution/GammaPoisson.birch"
  libbirch_function_("simulateLazy", "src/distribution/GammaPoisson.birch", 18);
  #line 19 "src/distribution/GammaPoisson.birch"
  libbirch_line_(19);
  #line 19 "src/distribution/GammaPoisson.birch"
  return birch::simulate_gamma_poisson(this->_u0955->k->get(), this->_u0955->_u0952->get());
}

#line 22 "src/distribution/GammaPoisson.birch"
birch::type::Real birch::type::GammaPoisson::logpdf(const birch::type::Integer& x) {
  #line 22 "src/distribution/GammaPoisson.birch"
  libbirch_function_("logpdf", "src/distribution/GammaPoisson.birch", 22);
  #line 23 "src/distribution/GammaPoisson.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/GammaPoisson.birch"
  return birch::logpdf_gamma_poisson(x, this->_u0955->k->value(), this->_u0955->_u0952->value());
}

#line 26 "src/distribution/GammaPoisson.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::GammaPoisson::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& x) {
  #line 26 "src/distribution/GammaPoisson.birch"
  libbirch_function_("logpdfLazy", "src/distribution/GammaPoisson.birch", 26);
  #line 27 "src/distribution/GammaPoisson.birch"
  libbirch_line_(27);
  #line 27 "src/distribution/GammaPoisson.birch"
  return birch::logpdf_lazy_gamma_poisson(x, this->_u0955->k, this->_u0955->_u0952);
}

#line 30 "src/distribution/GammaPoisson.birch"
void birch::type::GammaPoisson::update(const birch::type::Integer& x) {
  #line 30 "src/distribution/GammaPoisson.birch"
  libbirch_function_("update", "src/distribution/GammaPoisson.birch", 30);
  #line 31 "src/distribution/GammaPoisson.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/GammaPoisson.birch"
  std::tie(this->_u0955->k, this->_u0955->_u0952) = birch::box(birch::update_gamma_poisson(x, this->_u0955->k->value(), this->_u0955->_u0952->value()));
}

#line 34 "src/distribution/GammaPoisson.birch"
void birch::type::GammaPoisson::updateLazy(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& x) {
  #line 34 "src/distribution/GammaPoisson.birch"
  libbirch_function_("updateLazy", "src/distribution/GammaPoisson.birch", 34);
  #line 35 "src/distribution/GammaPoisson.birch"
  libbirch_line_(35);
  #line 35 "src/distribution/GammaPoisson.birch"
  std::tie(this->_u0955->k, this->_u0955->_u0952) = birch::update_lazy_gamma_poisson(x, this->_u0955->k, this->_u0955->_u0952);
}

#line 38 "src/distribution/GammaPoisson.birch"
std::optional<birch::type::Real> birch::type::GammaPoisson::cdf(const birch::type::Integer& x) {
  #line 38 "src/distribution/GammaPoisson.birch"
  libbirch_function_("cdf", "src/distribution/GammaPoisson.birch", 38);
  #line 39 "src/distribution/GammaPoisson.birch"
  libbirch_line_(39);
  #line 39 "src/distribution/GammaPoisson.birch"
  return birch::cdf_gamma_poisson(x, this->_u0955->k->value(), this->_u0955->_u0952->value());
}

#line 42 "src/distribution/GammaPoisson.birch"
std::optional<birch::type::Integer> birch::type::GammaPoisson::quantile(const birch::type::Real& P) {
  #line 42 "src/distribution/GammaPoisson.birch"
  libbirch_function_("quantile", "src/distribution/GammaPoisson.birch", 42);
  #line 43 "src/distribution/GammaPoisson.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/GammaPoisson.birch"
  return birch::quantile_gamma_poisson(P, this->_u0955->k->value(), this->_u0955->_u0952->value());
}

#line 46 "src/distribution/GammaPoisson.birch"
std::optional<birch::type::Integer> birch::type::GammaPoisson::lower() {
  #line 46 "src/distribution/GammaPoisson.birch"
  libbirch_function_("lower", "src/distribution/GammaPoisson.birch", 46);
  #line 47 "src/distribution/GammaPoisson.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/GammaPoisson.birch"
  return birch::type::Integer(0);
}

#line 50 "src/distribution/GammaPoisson.birch"
void birch::type::GammaPoisson::link() {
  #line 50 "src/distribution/GammaPoisson.birch"
  libbirch_function_("link", "src/distribution/GammaPoisson.birch", 50);
  #line 51 "src/distribution/GammaPoisson.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/GammaPoisson.birch"
  this->_u0955->setChild(this->shared_from_this_());
}

#line 54 "src/distribution/GammaPoisson.birch"
void birch::type::GammaPoisson::unlink() {
  #line 54 "src/distribution/GammaPoisson.birch"
  libbirch_function_("unlink", "src/distribution/GammaPoisson.birch", 54);
  #line 55 "src/distribution/GammaPoisson.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/GammaPoisson.birch"
  this->_u0955->releaseChild(this->shared_from_this_());
}

#line 59 "src/distribution/GammaPoisson.birch"
libbirch::Shared<birch::type::GammaPoisson> birch::GammaPoisson(const libbirch::Shared<birch::type::Gamma>& _u0955) {
  #line 59 "src/distribution/GammaPoisson.birch"
  libbirch_function_("GammaPoisson", "src/distribution/GammaPoisson.birch", 59);
  #line 60 "src/distribution/GammaPoisson.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/GammaPoisson.birch"
  libbirch::Shared<birch::type::GammaPoisson> m = libbirch::make<libbirch::Shared<birch::type::GammaPoisson>>(std::in_place, _u0955);
  #line 61 "src/distribution/GammaPoisson.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/GammaPoisson.birch"
  m->link();
  #line 62 "src/distribution/GammaPoisson.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/GammaPoisson.birch"
  return m;
}

#line 1 "src/distribution/Gaussian.birch"
birch::type::Gaussian::Gaussian(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632) :
    #line 1 "src/distribution/Gaussian.birch"
    base_type_(),
    #line 8 "src/distribution/Gaussian.birch"
    _u0956(std::move(_u0956)),
    #line 13 "src/distribution/Gaussian.birch"
    _u09632(std::move(_u09632)) {
  //
}

#line 15 "src/distribution/Gaussian.birch"
birch::type::Boolean birch::type::Gaussian::supportsLazy() {
  #line 15 "src/distribution/Gaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/Gaussian.birch", 15);
  #line 16 "src/distribution/Gaussian.birch"
  libbirch_line_(16);
  #line 16 "src/distribution/Gaussian.birch"
  return true;
}

#line 19 "src/distribution/Gaussian.birch"
birch::type::Real birch::type::Gaussian::simulate() {
  #line 19 "src/distribution/Gaussian.birch"
  libbirch_function_("simulate", "src/distribution/Gaussian.birch", 19);
  #line 20 "src/distribution/Gaussian.birch"
  libbirch_line_(20);
  #line 20 "src/distribution/Gaussian.birch"
  return birch::simulate_gaussian(this->_u0956->value(), this->_u09632->value());
}

#line 23 "src/distribution/Gaussian.birch"
std::optional<birch::type::Real> birch::type::Gaussian::simulateLazy() {
  #line 23 "src/distribution/Gaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/Gaussian.birch", 23);
  #line 24 "src/distribution/Gaussian.birch"
  libbirch_line_(24);
  #line 24 "src/distribution/Gaussian.birch"
  return birch::simulate_gaussian(this->_u0956->get(), this->_u09632->get());
}

#line 27 "src/distribution/Gaussian.birch"
birch::type::Real birch::type::Gaussian::logpdf(const birch::type::Real& x) {
  #line 27 "src/distribution/Gaussian.birch"
  libbirch_function_("logpdf", "src/distribution/Gaussian.birch", 27);
  #line 28 "src/distribution/Gaussian.birch"
  libbirch_line_(28);
  #line 28 "src/distribution/Gaussian.birch"
  return birch::logpdf_gaussian(x, this->_u0956->value(), this->_u09632->value());
}

#line 31 "src/distribution/Gaussian.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::Gaussian::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 31 "src/distribution/Gaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/Gaussian.birch", 31);
  #line 32 "src/distribution/Gaussian.birch"
  libbirch_line_(32);
  #line 32 "src/distribution/Gaussian.birch"
  return birch::logpdf_lazy_gaussian(x, this->_u0956, this->_u09632);
}

#line 35 "src/distribution/Gaussian.birch"
std::optional<birch::type::Real> birch::type::Gaussian::cdf(const birch::type::Real& x) {
  #line 35 "src/distribution/Gaussian.birch"
  libbirch_function_("cdf", "src/distribution/Gaussian.birch", 35);
  #line 36 "src/distribution/Gaussian.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/Gaussian.birch"
  return birch::cdf_gaussian(x, this->_u0956->value(), this->_u09632->value());
}

#line 39 "src/distribution/Gaussian.birch"
std::optional<birch::type::Real> birch::type::Gaussian::quantile(const birch::type::Real& P) {
  #line 39 "src/distribution/Gaussian.birch"
  libbirch_function_("quantile", "src/distribution/Gaussian.birch", 39);
  #line 40 "src/distribution/Gaussian.birch"
  libbirch_line_(40);
  #line 40 "src/distribution/Gaussian.birch"
  return birch::quantile_gaussian(P, this->_u0956->value(), this->_u09632->value());
}

#line 43 "src/distribution/Gaussian.birch"
std::optional<libbirch::Shared<birch::type::Gaussian>> birch::type::Gaussian::graftGaussian() {
  #line 43 "src/distribution/Gaussian.birch"
  libbirch_function_("graftGaussian", "src/distribution/Gaussian.birch", 43);
  #line 44 "src/distribution/Gaussian.birch"
  libbirch_line_(44);
  #line 44 "src/distribution/Gaussian.birch"
  this->prune();
  #line 45 "src/distribution/Gaussian.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/Gaussian.birch"
  return this->shared_from_this_();
}

#line 48 "src/distribution/Gaussian.birch"
void birch::type::Gaussian::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 48 "src/distribution/Gaussian.birch"
  libbirch_function_("write", "src/distribution/Gaussian.birch", 48);
  #line 49 "src/distribution/Gaussian.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/Gaussian.birch"
  this->prune();
  #line 50 "src/distribution/Gaussian.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/Gaussian.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Gaussian"));
  #line 51 "src/distribution/Gaussian.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/Gaussian.birch"
  buffer->set(birch::type::String("μ"), this->_u0956);
  #line 52 "src/distribution/Gaussian.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/Gaussian.birch"
  buffer->set(birch::type::String("σ2"), this->_u09632);
}

#line 59 "src/distribution/Gaussian.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632) {
  #line 59 "src/distribution/Gaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/Gaussian.birch", 59);
  #line 60 "src/distribution/Gaussian.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/Gaussian.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>>> m1 = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::NormalInverseGamma>>>>>();
  #line 61 "src/distribution/Gaussian.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/Gaussian.birch"
  std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>> m2 = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>();
  #line 62 "src/distribution/Gaussian.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/Gaussian.birch"
  std::optional<libbirch::Shared<birch::type::NormalInverseGamma>> m3 = libbirch::make<std::optional<libbirch::Shared<birch::type::NormalInverseGamma>>>();
  #line 63 "src/distribution/Gaussian.birch"
  libbirch_line_(63);
  #line 63 "src/distribution/Gaussian.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gaussian>>>> m4 = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gaussian>>>>>();
  #line 64 "src/distribution/Gaussian.birch"
  libbirch_line_(64);
  #line 64 "src/distribution/Gaussian.birch"
  std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateGaussian>>>> m5 = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformDot<libbirch::Shared<birch::type::MultivariateGaussian>>>>>();
  #line 65 "src/distribution/Gaussian.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/Gaussian.birch"
  std::optional<libbirch::Shared<birch::type::Gaussian>> m6 = libbirch::make<std::optional<libbirch::Shared<birch::type::Gaussian>>>();
  #line 66 "src/distribution/Gaussian.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/Gaussian.birch"
  std::optional<libbirch::Shared<birch::type::InverseGamma>> s2 = libbirch::make<std::optional<libbirch::Shared<birch::type::InverseGamma>>>();
  #line 67 "src/distribution/Gaussian.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/Gaussian.birch"
  auto compare = _u09632->distribution();
  #line 68 "src/distribution/Gaussian.birch"
  libbirch_line_(68);
  #line 68 "src/distribution/Gaussian.birch"
  if (compare.has_value() && (m1 = _u0956->graftLinearNormalInverseGamma(compare.value())).has_value()) {
    #line 69 "src/distribution/Gaussian.birch"
    libbirch_line_(69);
    #line 69 "src/distribution/Gaussian.birch"
    return birch::LinearNormalInverseGammaGaussian(m1.value()->a, m1.value()->x, m1.value()->c);
  } else {
    #line 70 "src/distribution/Gaussian.birch"
    libbirch_line_(70);
    #line 70 "src/distribution/Gaussian.birch"
    if (compare.has_value() && (m2 = _u0956->graftDotMultivariateNormalInverseGamma(compare.value())).has_value()) {
      #line 71 "src/distribution/Gaussian.birch"
      libbirch_line_(71);
      #line 71 "src/distribution/Gaussian.birch"
      return birch::LinearMultivariateNormalInverseGammaGaussian(m2.value()->a, m2.value()->x, m2.value()->c);
    } else {
      #line 72 "src/distribution/Gaussian.birch"
      libbirch_line_(72);
      #line 72 "src/distribution/Gaussian.birch"
      if (compare.has_value() && (m3 = _u0956->graftNormalInverseGamma(compare.value())).has_value()) {
        #line 73 "src/distribution/Gaussian.birch"
        libbirch_line_(73);
        #line 73 "src/distribution/Gaussian.birch"
        return birch::NormalInverseGammaGaussian(m3.value());
      } else {
        #line 74 "src/distribution/Gaussian.birch"
        libbirch_line_(74);
        #line 74 "src/distribution/Gaussian.birch"
        if ((m4 = _u0956->graftLinearGaussian()).has_value()) {
          #line 75 "src/distribution/Gaussian.birch"
          libbirch_line_(75);
          #line 75 "src/distribution/Gaussian.birch"
          return birch::LinearGaussianGaussian(m4.value()->a, m4.value()->x, m4.value()->c, _u09632);
        } else {
          #line 76 "src/distribution/Gaussian.birch"
          libbirch_line_(76);
          #line 76 "src/distribution/Gaussian.birch"
          if ((m5 = _u0956->graftDotMultivariateGaussian()).has_value()) {
            #line 77 "src/distribution/Gaussian.birch"
            libbirch_line_(77);
            #line 77 "src/distribution/Gaussian.birch"
            return birch::LinearMultivariateGaussianGaussian(m5.value()->a, m5.value()->x, m5.value()->c, _u09632);
          } else {
            #line 78 "src/distribution/Gaussian.birch"
            libbirch_line_(78);
            #line 78 "src/distribution/Gaussian.birch"
            if ((m6 = _u0956->graftGaussian()).has_value()) {
              #line 79 "src/distribution/Gaussian.birch"
              libbirch_line_(79);
              #line 79 "src/distribution/Gaussian.birch"
              return birch::GaussianGaussian(m6.value(), _u09632);
            } else {
              #line 80 "src/distribution/Gaussian.birch"
              libbirch_line_(80);
              #line 80 "src/distribution/Gaussian.birch"
              if ((s2 = _u09632->graftInverseGamma()).has_value()) {
                #line 81 "src/distribution/Gaussian.birch"
                libbirch_line_(81);
                #line 81 "src/distribution/Gaussian.birch"
                return birch::NormalInverseGamma(_u0956, birch::box(1.0), s2.value());
              } else {
                #line 83 "src/distribution/Gaussian.birch"
                libbirch_line_(83);
                #line 83 "src/distribution/Gaussian.birch"
                return birch::construct<libbirch::Shared<birch::type::Gaussian>>(_u0956, _u09632);
              }
            }
          }
        }
      }
    }
  }
}

#line 90 "src/distribution/Gaussian.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0956, const birch::type::Real& _u09632) {
  #line 90 "src/distribution/Gaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/Gaussian.birch", 90);
  #line 91 "src/distribution/Gaussian.birch"
  libbirch_line_(91);
  #line 91 "src/distribution/Gaussian.birch"
  return birch::Gaussian(_u0956, birch::box(_u09632));
}

#line 97 "src/distribution/Gaussian.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::Gaussian(const birch::type::Real& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632) {
  #line 97 "src/distribution/Gaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/Gaussian.birch", 97);
  #line 98 "src/distribution/Gaussian.birch"
  libbirch_line_(98);
  #line 98 "src/distribution/Gaussian.birch"
  return birch::Gaussian(birch::box(_u0956), _u09632);
}

#line 104 "src/distribution/Gaussian.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::Gaussian(const birch::type::Real& _u0956, const birch::type::Real& _u09632) {
  #line 104 "src/distribution/Gaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/Gaussian.birch", 104);
  #line 105 "src/distribution/Gaussian.birch"
  libbirch_line_(105);
  #line 105 "src/distribution/Gaussian.birch"
  return birch::Gaussian(birch::box(_u0956), birch::box(_u09632));
}

#line 113 "src/distribution/Gaussian.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09642) {
  #line 113 "src/distribution/Gaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/Gaussian.birch", 113);
  #line 115 "src/distribution/Gaussian.birch"
  libbirch_line_(115);
  #line 115 "src/distribution/Gaussian.birch"
  std::optional<libbirch::Shared<birch::type::InverseGamma>> s1 = libbirch::make<std::optional<libbirch::Shared<birch::type::InverseGamma>>>();
  #line 116 "src/distribution/Gaussian.birch"
  libbirch_line_(116);
  #line 116 "src/distribution/Gaussian.birch"
  if ((s1 = _u09632->graftInverseGamma()).has_value()) {
    #line 117 "src/distribution/Gaussian.birch"
    libbirch_line_(117);
    #line 117 "src/distribution/Gaussian.birch"
    return birch::NormalInverseGamma(_u0956, _u09642, s1.value());
  } else {
    #line 118 "src/distribution/Gaussian.birch"
    libbirch_line_(118);
    #line 118 "src/distribution/Gaussian.birch"
    if ((s1 = _u09642->graftInverseGamma()).has_value()) {
      #line 119 "src/distribution/Gaussian.birch"
      libbirch_line_(119);
      #line 119 "src/distribution/Gaussian.birch"
      return birch::NormalInverseGamma(_u0956, _u09632, s1.value());
    } else {
      #line 121 "src/distribution/Gaussian.birch"
      libbirch_line_(121);
      #line 121 "src/distribution/Gaussian.birch"
      return birch::construct<libbirch::Shared<birch::type::Gaussian>>(_u0956, _u09632 * _u09642);
    }
  }
}

#line 130 "src/distribution/Gaussian.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632, const birch::type::Real& _u09642) {
  #line 130 "src/distribution/Gaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/Gaussian.birch", 130);
  #line 132 "src/distribution/Gaussian.birch"
  libbirch_line_(132);
  #line 132 "src/distribution/Gaussian.birch"
  return birch::Gaussian(_u0956, _u09632, birch::box(_u09642));
}

#line 140 "src/distribution/Gaussian.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0956, const birch::type::Real& _u09632, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09642) {
  #line 140 "src/distribution/Gaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/Gaussian.birch", 140);
  #line 142 "src/distribution/Gaussian.birch"
  libbirch_line_(142);
  #line 142 "src/distribution/Gaussian.birch"
  return birch::Gaussian(_u0956, birch::box(_u09632), _u09642);
}

#line 150 "src/distribution/Gaussian.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0956, const birch::type::Real& _u09632, const birch::type::Real& _u09642) {
  #line 150 "src/distribution/Gaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/Gaussian.birch", 150);
  #line 152 "src/distribution/Gaussian.birch"
  libbirch_line_(152);
  #line 152 "src/distribution/Gaussian.birch"
  return birch::Gaussian(_u0956, _u09632 * _u09642);
}

#line 160 "src/distribution/Gaussian.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::Gaussian(const birch::type::Real& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09642) {
  #line 160 "src/distribution/Gaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/Gaussian.birch", 160);
  #line 162 "src/distribution/Gaussian.birch"
  libbirch_line_(162);
  #line 162 "src/distribution/Gaussian.birch"
  return birch::Gaussian(birch::box(_u0956), _u09632, _u09642);
}

#line 170 "src/distribution/Gaussian.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::Gaussian(const birch::type::Real& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632, const birch::type::Real& _u09642) {
  #line 170 "src/distribution/Gaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/Gaussian.birch", 170);
  #line 172 "src/distribution/Gaussian.birch"
  libbirch_line_(172);
  #line 172 "src/distribution/Gaussian.birch"
  return birch::Gaussian(birch::box(_u0956), _u09632, birch::box(_u09642));
}

#line 180 "src/distribution/Gaussian.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::Gaussian(const birch::type::Real& _u0956, const birch::type::Real& _u09632, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09642) {
  #line 180 "src/distribution/Gaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/Gaussian.birch", 180);
  #line 182 "src/distribution/Gaussian.birch"
  libbirch_line_(182);
  #line 182 "src/distribution/Gaussian.birch"
  return birch::Gaussian(birch::box(_u0956), birch::box(_u09632), _u09642);
}

#line 190 "src/distribution/Gaussian.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::Gaussian(const birch::type::Real& _u0956, const birch::type::Real& _u09632, const birch::type::Real& _u09642) {
  #line 190 "src/distribution/Gaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/Gaussian.birch", 190);
  #line 191 "src/distribution/Gaussian.birch"
  libbirch_line_(191);
  #line 191 "src/distribution/Gaussian.birch"
  return birch::Gaussian(_u0956, _u09632 * _u09642);
}

#line 4 "src/distribution/GaussianGaussian.birch"
birch::type::GaussianGaussian::GaussianGaussian(const libbirch::Shared<birch::type::Gaussian>& m, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& s2) :
    #line 4 "src/distribution/GaussianGaussian.birch"
    base_type_(m->_u0956, m->_u09632 + s2),
    #line 9 "src/distribution/GaussianGaussian.birch"
    m(m),
    #line 14 "src/distribution/GaussianGaussian.birch"
    s2(s2) {
  //
}

#line 16 "src/distribution/GaussianGaussian.birch"
void birch::type::GaussianGaussian::update(const birch::type::Real& x) {
  #line 16 "src/distribution/GaussianGaussian.birch"
  libbirch_function_("update", "src/distribution/GaussianGaussian.birch", 16);
  #line 17 "src/distribution/GaussianGaussian.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/GaussianGaussian.birch"
  std::tie(this->m->_u0956, this->m->_u09632) = birch::box(birch::update_gaussian_gaussian(x, this->m->_u0956->value(), this->m->_u09632->value(), this->s2->value()));
}

#line 20 "src/distribution/GaussianGaussian.birch"
void birch::type::GaussianGaussian::updateLazy(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 20 "src/distribution/GaussianGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/GaussianGaussian.birch", 20);
  #line 21 "src/distribution/GaussianGaussian.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/GaussianGaussian.birch"
  std::tie(this->m->_u0956, this->m->_u09632) = birch::update_lazy_gaussian_gaussian(x, this->m->_u0956, this->m->_u09632, this->s2);
}

#line 24 "src/distribution/GaussianGaussian.birch"
void birch::type::GaussianGaussian::link() {
  #line 24 "src/distribution/GaussianGaussian.birch"
  libbirch_function_("link", "src/distribution/GaussianGaussian.birch", 24);
  #line 25 "src/distribution/GaussianGaussian.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/GaussianGaussian.birch"
  this->m->setChild(this->shared_from_this_());
}

#line 28 "src/distribution/GaussianGaussian.birch"
void birch::type::GaussianGaussian::unlink() {
  #line 28 "src/distribution/GaussianGaussian.birch"
  libbirch_function_("unlink", "src/distribution/GaussianGaussian.birch", 28);
  #line 29 "src/distribution/GaussianGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/GaussianGaussian.birch"
  this->m->releaseChild(this->shared_from_this_());
}

#line 33 "src/distribution/GaussianGaussian.birch"
libbirch::Shared<birch::type::GaussianGaussian> birch::GaussianGaussian(const libbirch::Shared<birch::type::Gaussian>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632) {
  #line 33 "src/distribution/GaussianGaussian.birch"
  libbirch_function_("GaussianGaussian", "src/distribution/GaussianGaussian.birch", 33);
  #line 34 "src/distribution/GaussianGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/distribution/GaussianGaussian.birch"
  libbirch::Shared<birch::type::GaussianGaussian> m = libbirch::make<libbirch::Shared<birch::type::GaussianGaussian>>(std::in_place, _u0956, _u09632);
  #line 35 "src/distribution/GaussianGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/distribution/GaussianGaussian.birch"
  m->link();
  #line 36 "src/distribution/GaussianGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/GaussianGaussian.birch"
  return m;
}

#line 4 "src/distribution/Geometric.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Integer>> birch::Geometric(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0961) {
  #line 4 "src/distribution/Geometric.birch"
  libbirch_function_("Geometric", "src/distribution/Geometric.birch", 4);
  #line 5 "src/distribution/Geometric.birch"
  libbirch_line_(5);
  #line 5 "src/distribution/Geometric.birch"
  return birch::NegativeBinomial(birch::box(birch::type::Integer(1)), _u0961);
}

#line 11 "src/distribution/Geometric.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Integer>> birch::Geometric(const birch::type::Real& _u0961) {
  #line 11 "src/distribution/Geometric.birch"
  libbirch_function_("Geometric", "src/distribution/Geometric.birch", 11);
  #line 12 "src/distribution/Geometric.birch"
  libbirch_line_(12);
  #line 12 "src/distribution/Geometric.birch"
  return birch::Geometric(birch::box(_u0961));
}

#line 4 "src/distribution/IndependentUniform.birch"
birch::type::IndependentUniform::IndependentUniform(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& l, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& u) :
    #line 4 "src/distribution/IndependentUniform.birch"
    base_type_(),
    #line 9 "src/distribution/IndependentUniform.birch"
    l(std::move(l)),
    #line 14 "src/distribution/IndependentUniform.birch"
    u(std::move(u)) {
  //
}

#line 16 "src/distribution/IndependentUniform.birch"
birch::type::Integer birch::type::IndependentUniform::rows() {
  #line 16 "src/distribution/IndependentUniform.birch"
  libbirch_function_("rows", "src/distribution/IndependentUniform.birch", 16);
  #line 17 "src/distribution/IndependentUniform.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/IndependentUniform.birch"
  return this->l->rows();
}

#line 20 "src/distribution/IndependentUniform.birch"
birch::type::Boolean birch::type::IndependentUniform::supportsLazy() {
  #line 20 "src/distribution/IndependentUniform.birch"
  libbirch_function_("supportsLazy", "src/distribution/IndependentUniform.birch", 20);
  #line 21 "src/distribution/IndependentUniform.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/IndependentUniform.birch"
  return false;
}

#line 24 "src/distribution/IndependentUniform.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::IndependentUniform::simulate() {
  #line 24 "src/distribution/IndependentUniform.birch"
  libbirch_function_("simulate", "src/distribution/IndependentUniform.birch", 24);
  #line 25 "src/distribution/IndependentUniform.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/IndependentUniform.birch"
  return birch::simulate_independent_uniform(this->l->value(), this->u->value());
}

#line 32 "src/distribution/IndependentUniform.birch"
birch::type::Real birch::type::IndependentUniform::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 32 "src/distribution/IndependentUniform.birch"
  libbirch_function_("logpdf", "src/distribution/IndependentUniform.birch", 32);
  #line 33 "src/distribution/IndependentUniform.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/IndependentUniform.birch"
  return birch::logpdf_independent_uniform(x, this->l->value(), this->u->value());
}

#line 40 "src/distribution/IndependentUniform.birch"
void birch::type::IndependentUniform::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 40 "src/distribution/IndependentUniform.birch"
  libbirch_function_("write", "src/distribution/IndependentUniform.birch", 40);
  #line 41 "src/distribution/IndependentUniform.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/IndependentUniform.birch"
  this->prune();
  #line 42 "src/distribution/IndependentUniform.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/IndependentUniform.birch"
  buffer->set(birch::type::String("class"), birch::type::String("IndependentUniform"));
  #line 43 "src/distribution/IndependentUniform.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/IndependentUniform.birch"
  buffer->set(birch::type::String("l"), this->l);
  #line 44 "src/distribution/IndependentUniform.birch"
  libbirch_line_(44);
  #line 44 "src/distribution/IndependentUniform.birch"
  buffer->set(birch::type::String("u"), this->u);
}

#line 52 "src/distribution/IndependentUniform.birch"
libbirch::Shared<birch::type::IndependentUniform> birch::Uniform(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& l, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& u) {
  #line 52 "src/distribution/IndependentUniform.birch"
  libbirch_function_("Uniform", "src/distribution/IndependentUniform.birch", 52);
  #line 54 "src/distribution/IndependentUniform.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/IndependentUniform.birch"
  return birch::construct<libbirch::Shared<birch::type::IndependentUniform>>(l, u);
}

#line 61 "src/distribution/IndependentUniform.birch"
libbirch::Shared<birch::type::IndependentUniform> birch::Uniform(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& l, const libbirch::DefaultArray<birch::type::Real,1>& u) {
  #line 61 "src/distribution/IndependentUniform.birch"
  libbirch_function_("Uniform", "src/distribution/IndependentUniform.birch", 61);
  #line 62 "src/distribution/IndependentUniform.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/IndependentUniform.birch"
  return birch::Uniform(l, birch::box(u));
}

#line 69 "src/distribution/IndependentUniform.birch"
libbirch::Shared<birch::type::IndependentUniform> birch::Uniform(const libbirch::DefaultArray<birch::type::Real,1>& l, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& u) {
  #line 69 "src/distribution/IndependentUniform.birch"
  libbirch_function_("Uniform", "src/distribution/IndependentUniform.birch", 69);
  #line 70 "src/distribution/IndependentUniform.birch"
  libbirch_line_(70);
  #line 70 "src/distribution/IndependentUniform.birch"
  return birch::Uniform(birch::box(l), u);
}

#line 77 "src/distribution/IndependentUniform.birch"
libbirch::Shared<birch::type::IndependentUniform> birch::Uniform(const libbirch::DefaultArray<birch::type::Real,1>& l, const libbirch::DefaultArray<birch::type::Real,1>& u) {
  #line 77 "src/distribution/IndependentUniform.birch"
  libbirch_function_("Uniform", "src/distribution/IndependentUniform.birch", 77);
  #line 78 "src/distribution/IndependentUniform.birch"
  libbirch_line_(78);
  #line 78 "src/distribution/IndependentUniform.birch"
  return birch::Uniform(birch::box(l), birch::box(u));
}

#line 5 "src/distribution/IndependentUniformInteger.birch"
birch::type::IndependentUniformInteger::IndependentUniformInteger(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Integer,1>>>& l, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Integer,1>>>& u) :
    #line 5 "src/distribution/IndependentUniformInteger.birch"
    base_type_(),
    #line 10 "src/distribution/IndependentUniformInteger.birch"
    l(std::move(l)),
    #line 15 "src/distribution/IndependentUniformInteger.birch"
    u(std::move(u)) {
  //
}

#line 17 "src/distribution/IndependentUniformInteger.birch"
birch::type::Integer birch::type::IndependentUniformInteger::rows() {
  #line 17 "src/distribution/IndependentUniformInteger.birch"
  libbirch_function_("rows", "src/distribution/IndependentUniformInteger.birch", 17);
  #line 18 "src/distribution/IndependentUniformInteger.birch"
  libbirch_line_(18);
  #line 18 "src/distribution/IndependentUniformInteger.birch"
  return this->l->rows();
}

#line 21 "src/distribution/IndependentUniformInteger.birch"
birch::type::Boolean birch::type::IndependentUniformInteger::supportsLazy() {
  #line 21 "src/distribution/IndependentUniformInteger.birch"
  libbirch_function_("supportsLazy", "src/distribution/IndependentUniformInteger.birch", 21);
  #line 22 "src/distribution/IndependentUniformInteger.birch"
  libbirch_line_(22);
  #line 22 "src/distribution/IndependentUniformInteger.birch"
  return false;
}

#line 25 "src/distribution/IndependentUniformInteger.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::type::IndependentUniformInteger::simulate() {
  #line 25 "src/distribution/IndependentUniformInteger.birch"
  libbirch_function_("simulate", "src/distribution/IndependentUniformInteger.birch", 25);
  #line 26 "src/distribution/IndependentUniformInteger.birch"
  libbirch_line_(26);
  #line 26 "src/distribution/IndependentUniformInteger.birch"
  return birch::simulate_independent_uniform_int(this->l->value(), this->u->value());
}

#line 33 "src/distribution/IndependentUniformInteger.birch"
birch::type::Real birch::type::IndependentUniformInteger::logpdf(const libbirch::DefaultArray<birch::type::Integer,1>& x) {
  #line 33 "src/distribution/IndependentUniformInteger.birch"
  libbirch_function_("logpdf", "src/distribution/IndependentUniformInteger.birch", 33);
  #line 34 "src/distribution/IndependentUniformInteger.birch"
  libbirch_line_(34);
  #line 34 "src/distribution/IndependentUniformInteger.birch"
  return birch::logpdf_independent_uniform_int(x, this->l->value(), this->u->value());
}

#line 41 "src/distribution/IndependentUniformInteger.birch"
void birch::type::IndependentUniformInteger::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 41 "src/distribution/IndependentUniformInteger.birch"
  libbirch_function_("write", "src/distribution/IndependentUniformInteger.birch", 41);
  #line 42 "src/distribution/IndependentUniformInteger.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/IndependentUniformInteger.birch"
  this->prune();
  #line 43 "src/distribution/IndependentUniformInteger.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/IndependentUniformInteger.birch"
  buffer->set(birch::type::String("class"), birch::type::String("IndependentUniformInteger"));
  #line 44 "src/distribution/IndependentUniformInteger.birch"
  libbirch_line_(44);
  #line 44 "src/distribution/IndependentUniformInteger.birch"
  buffer->set(birch::type::String("l"), this->l);
  #line 45 "src/distribution/IndependentUniformInteger.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/IndependentUniformInteger.birch"
  buffer->set(birch::type::String("u"), this->u);
}

#line 53 "src/distribution/IndependentUniformInteger.birch"
libbirch::Shared<birch::type::IndependentUniformInteger> birch::Uniform(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Integer,1>>>& l, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Integer,1>>>& u) {
  #line 53 "src/distribution/IndependentUniformInteger.birch"
  libbirch_function_("Uniform", "src/distribution/IndependentUniformInteger.birch", 53);
  #line 55 "src/distribution/IndependentUniformInteger.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/IndependentUniformInteger.birch"
  return birch::construct<libbirch::Shared<birch::type::IndependentUniformInteger>>(l, u);
}

#line 62 "src/distribution/IndependentUniformInteger.birch"
libbirch::Shared<birch::type::IndependentUniformInteger> birch::Uniform(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Integer,1>>>& l, const libbirch::DefaultArray<birch::type::Integer,1>& u) {
  #line 62 "src/distribution/IndependentUniformInteger.birch"
  libbirch_function_("Uniform", "src/distribution/IndependentUniformInteger.birch", 62);
  #line 64 "src/distribution/IndependentUniformInteger.birch"
  libbirch_line_(64);
  #line 64 "src/distribution/IndependentUniformInteger.birch"
  return birch::Uniform(l, birch::box(u));
}

#line 71 "src/distribution/IndependentUniformInteger.birch"
libbirch::Shared<birch::type::IndependentUniformInteger> birch::Uniform(const libbirch::DefaultArray<birch::type::Integer,1>& l, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Integer,1>>>& u) {
  #line 71 "src/distribution/IndependentUniformInteger.birch"
  libbirch_function_("Uniform", "src/distribution/IndependentUniformInteger.birch", 71);
  #line 73 "src/distribution/IndependentUniformInteger.birch"
  libbirch_line_(73);
  #line 73 "src/distribution/IndependentUniformInteger.birch"
  return birch::Uniform(birch::box(l), u);
}

#line 80 "src/distribution/IndependentUniformInteger.birch"
libbirch::Shared<birch::type::IndependentUniformInteger> birch::Uniform(const libbirch::DefaultArray<birch::type::Integer,1>& l, const libbirch::DefaultArray<birch::type::Integer,1>& u) {
  #line 80 "src/distribution/IndependentUniformInteger.birch"
  libbirch_function_("Uniform", "src/distribution/IndependentUniformInteger.birch", 80);
  #line 81 "src/distribution/IndependentUniformInteger.birch"
  libbirch_line_(81);
  #line 81 "src/distribution/IndependentUniformInteger.birch"
  return birch::Uniform(birch::box(l), birch::box(u));
}

#line 4 "src/distribution/InverseGamma.birch"
birch::type::InverseGamma::InverseGamma(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0945, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0946) :
    #line 4 "src/distribution/InverseGamma.birch"
    base_type_(),
    #line 9 "src/distribution/InverseGamma.birch"
    _u0945(std::move(_u0945)),
    #line 14 "src/distribution/InverseGamma.birch"
    _u0946(std::move(_u0946)) {
  //
}

#line 16 "src/distribution/InverseGamma.birch"
birch::type::Boolean birch::type::InverseGamma::supportsLazy() {
  #line 16 "src/distribution/InverseGamma.birch"
  libbirch_function_("supportsLazy", "src/distribution/InverseGamma.birch", 16);
  #line 17 "src/distribution/InverseGamma.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/InverseGamma.birch"
  return true;
}

#line 20 "src/distribution/InverseGamma.birch"
birch::type::Real birch::type::InverseGamma::simulate() {
  #line 20 "src/distribution/InverseGamma.birch"
  libbirch_function_("simulate", "src/distribution/InverseGamma.birch", 20);
  #line 21 "src/distribution/InverseGamma.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/InverseGamma.birch"
  return birch::simulate_inverse_gamma(this->_u0945->value(), this->_u0946->value());
}

#line 24 "src/distribution/InverseGamma.birch"
std::optional<birch::type::Real> birch::type::InverseGamma::simulateLazy() {
  #line 24 "src/distribution/InverseGamma.birch"
  libbirch_function_("simulateLazy", "src/distribution/InverseGamma.birch", 24);
  #line 25 "src/distribution/InverseGamma.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/InverseGamma.birch"
  return birch::simulate_inverse_gamma(this->_u0945->get(), this->_u0946->get());
}

#line 28 "src/distribution/InverseGamma.birch"
birch::type::Real birch::type::InverseGamma::logpdf(const birch::type::Real& x) {
  #line 28 "src/distribution/InverseGamma.birch"
  libbirch_function_("logpdf", "src/distribution/InverseGamma.birch", 28);
  #line 29 "src/distribution/InverseGamma.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/InverseGamma.birch"
  return birch::logpdf_inverse_gamma(x, this->_u0945->value(), this->_u0946->value());
}

#line 32 "src/distribution/InverseGamma.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::InverseGamma::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 32 "src/distribution/InverseGamma.birch"
  libbirch_function_("logpdfLazy", "src/distribution/InverseGamma.birch", 32);
  #line 33 "src/distribution/InverseGamma.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/InverseGamma.birch"
  return birch::logpdf_lazy_inverse_gamma(x, this->_u0945, this->_u0946);
}

#line 36 "src/distribution/InverseGamma.birch"
std::optional<birch::type::Real> birch::type::InverseGamma::cdf(const birch::type::Real& x) {
  #line 36 "src/distribution/InverseGamma.birch"
  libbirch_function_("cdf", "src/distribution/InverseGamma.birch", 36);
  #line 37 "src/distribution/InverseGamma.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/InverseGamma.birch"
  return birch::cdf_inverse_gamma(x, this->_u0945->value(), this->_u0946->value());
}

#line 40 "src/distribution/InverseGamma.birch"
std::optional<birch::type::Real> birch::type::InverseGamma::quantile(const birch::type::Real& P) {
  #line 40 "src/distribution/InverseGamma.birch"
  libbirch_function_("quantile", "src/distribution/InverseGamma.birch", 40);
  #line 41 "src/distribution/InverseGamma.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/InverseGamma.birch"
  return birch::quantile_inverse_gamma(P, this->_u0945->value(), this->_u0946->value());
}

#line 44 "src/distribution/InverseGamma.birch"
std::optional<birch::type::Real> birch::type::InverseGamma::lower() {
  #line 44 "src/distribution/InverseGamma.birch"
  libbirch_function_("lower", "src/distribution/InverseGamma.birch", 44);
  #line 45 "src/distribution/InverseGamma.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/InverseGamma.birch"
  return 0.0;
}

#line 48 "src/distribution/InverseGamma.birch"
std::optional<libbirch::Shared<birch::type::InverseGamma>> birch::type::InverseGamma::graftInverseGamma() {
  #line 48 "src/distribution/InverseGamma.birch"
  libbirch_function_("graftInverseGamma", "src/distribution/InverseGamma.birch", 48);
  #line 49 "src/distribution/InverseGamma.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/InverseGamma.birch"
  this->prune();
  #line 50 "src/distribution/InverseGamma.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/InverseGamma.birch"
  return this->shared_from_this_();
}

#line 53 "src/distribution/InverseGamma.birch"
void birch::type::InverseGamma::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 53 "src/distribution/InverseGamma.birch"
  libbirch_function_("write", "src/distribution/InverseGamma.birch", 53);
  #line 54 "src/distribution/InverseGamma.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/InverseGamma.birch"
  this->prune();
  #line 55 "src/distribution/InverseGamma.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/InverseGamma.birch"
  buffer->set(birch::type::String("class"), birch::type::String("InverseGamma"));
  #line 56 "src/distribution/InverseGamma.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/InverseGamma.birch"
  buffer->set(birch::type::String("α"), this->_u0945);
  #line 57 "src/distribution/InverseGamma.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/InverseGamma.birch"
  buffer->set(birch::type::String("β"), this->_u0946);
}

#line 64 "src/distribution/InverseGamma.birch"
libbirch::Shared<birch::type::InverseGamma> birch::InverseGamma(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0945, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0946) {
  #line 64 "src/distribution/InverseGamma.birch"
  libbirch_function_("InverseGamma", "src/distribution/InverseGamma.birch", 64);
  #line 66 "src/distribution/InverseGamma.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/InverseGamma.birch"
  return birch::construct<libbirch::Shared<birch::type::InverseGamma>>(_u0945, _u0946);
}

#line 72 "src/distribution/InverseGamma.birch"
libbirch::Shared<birch::type::InverseGamma> birch::InverseGamma(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0945, const birch::type::Real& _u0946) {
  #line 72 "src/distribution/InverseGamma.birch"
  libbirch_function_("InverseGamma", "src/distribution/InverseGamma.birch", 72);
  #line 73 "src/distribution/InverseGamma.birch"
  libbirch_line_(73);
  #line 73 "src/distribution/InverseGamma.birch"
  return birch::InverseGamma(_u0945, birch::box(_u0946));
}

#line 79 "src/distribution/InverseGamma.birch"
libbirch::Shared<birch::type::InverseGamma> birch::InverseGamma(const birch::type::Real& _u0945, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0946) {
  #line 79 "src/distribution/InverseGamma.birch"
  libbirch_function_("InverseGamma", "src/distribution/InverseGamma.birch", 79);
  #line 80 "src/distribution/InverseGamma.birch"
  libbirch_line_(80);
  #line 80 "src/distribution/InverseGamma.birch"
  return birch::InverseGamma(birch::box(_u0945), _u0946);
}

#line 86 "src/distribution/InverseGamma.birch"
libbirch::Shared<birch::type::InverseGamma> birch::InverseGamma(const birch::type::Real& _u0945, const birch::type::Real& _u0946) {
  #line 86 "src/distribution/InverseGamma.birch"
  libbirch_function_("InverseGamma", "src/distribution/InverseGamma.birch", 86);
  #line 87 "src/distribution/InverseGamma.birch"
  libbirch_line_(87);
  #line 87 "src/distribution/InverseGamma.birch"
  return birch::InverseGamma(birch::box(_u0945), birch::box(_u0946));
}

#line 4 "src/distribution/InverseGammaGamma.birch"
birch::type::InverseGammaGamma::InverseGammaGamma(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k, const libbirch::Shared<birch::type::InverseGamma>& _u0952) :
    #line 4 "src/distribution/InverseGammaGamma.birch"
    base_type_(),
    #line 9 "src/distribution/InverseGammaGamma.birch"
    k(std::move(k)),
    #line 14 "src/distribution/InverseGammaGamma.birch"
    _u0952(std::move(_u0952)) {
  //
}

#line 16 "src/distribution/InverseGammaGamma.birch"
birch::type::Boolean birch::type::InverseGammaGamma::supportsLazy() {
  #line 16 "src/distribution/InverseGammaGamma.birch"
  libbirch_function_("supportsLazy", "src/distribution/InverseGammaGamma.birch", 16);
  #line 17 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/InverseGammaGamma.birch"
  return true;
}

#line 20 "src/distribution/InverseGammaGamma.birch"
birch::type::Real birch::type::InverseGammaGamma::simulate() {
  #line 20 "src/distribution/InverseGammaGamma.birch"
  libbirch_function_("simulate", "src/distribution/InverseGammaGamma.birch", 20);
  #line 21 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/InverseGammaGamma.birch"
  return birch::simulate_inverse_gamma_gamma(this->k->value(), this->_u0952->_u0945->value(), this->_u0952->_u0946->value());
}

#line 24 "src/distribution/InverseGammaGamma.birch"
std::optional<birch::type::Real> birch::type::InverseGammaGamma::simulateLazy() {
  #line 24 "src/distribution/InverseGammaGamma.birch"
  libbirch_function_("simulateLazy", "src/distribution/InverseGammaGamma.birch", 24);
  #line 25 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/InverseGammaGamma.birch"
  return birch::simulate_inverse_gamma_gamma(this->k->get(), this->_u0952->_u0945->get(), this->_u0952->_u0946->get());
}

#line 28 "src/distribution/InverseGammaGamma.birch"
birch::type::Real birch::type::InverseGammaGamma::logpdf(const birch::type::Real& x) {
  #line 28 "src/distribution/InverseGammaGamma.birch"
  libbirch_function_("logpdf", "src/distribution/InverseGammaGamma.birch", 28);
  #line 29 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/InverseGammaGamma.birch"
  return birch::logpdf_inverse_gamma_gamma(x, this->k->value(), this->_u0952->_u0945->value(), this->_u0952->_u0946->value());
}

#line 32 "src/distribution/InverseGammaGamma.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::InverseGammaGamma::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 32 "src/distribution/InverseGammaGamma.birch"
  libbirch_function_("logpdfLazy", "src/distribution/InverseGammaGamma.birch", 32);
  #line 33 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/InverseGammaGamma.birch"
  return birch::logpdf_lazy_inverse_gamma_gamma(x, this->k, this->_u0952->_u0945, this->_u0952->_u0946);
}

#line 36 "src/distribution/InverseGammaGamma.birch"
void birch::type::InverseGammaGamma::update(const birch::type::Real& x) {
  #line 36 "src/distribution/InverseGammaGamma.birch"
  libbirch_function_("update", "src/distribution/InverseGammaGamma.birch", 36);
  #line 37 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/InverseGammaGamma.birch"
  std::tie(this->_u0952->_u0945, this->_u0952->_u0946) = birch::box(birch::update_inverse_gamma_gamma(x, this->k->value(), this->_u0952->_u0945->value(), this->_u0952->_u0946->value()));
}

#line 40 "src/distribution/InverseGammaGamma.birch"
void birch::type::InverseGammaGamma::updateLazy(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 40 "src/distribution/InverseGammaGamma.birch"
  libbirch_function_("updateLazy", "src/distribution/InverseGammaGamma.birch", 40);
  #line 41 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/InverseGammaGamma.birch"
  std::tie(this->_u0952->_u0945, this->_u0952->_u0946) = birch::update_lazy_inverse_gamma_gamma(x, this->k, this->_u0952->_u0945, this->_u0952->_u0946);
}

#line 44 "src/distribution/InverseGammaGamma.birch"
std::optional<birch::type::Real> birch::type::InverseGammaGamma::cdf(const birch::type::Real& x) {
  #line 44 "src/distribution/InverseGammaGamma.birch"
  libbirch_function_("cdf", "src/distribution/InverseGammaGamma.birch", 44);
  #line 45 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/InverseGammaGamma.birch"
  return birch::cdf_inverse_gamma_gamma(x, this->k->value(), this->_u0952->_u0945->value(), this->_u0952->_u0946->value());
}

#line 48 "src/distribution/InverseGammaGamma.birch"
std::optional<birch::type::Real> birch::type::InverseGammaGamma::lower() {
  #line 48 "src/distribution/InverseGammaGamma.birch"
  libbirch_function_("lower", "src/distribution/InverseGammaGamma.birch", 48);
  #line 49 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/InverseGammaGamma.birch"
  return 0.0;
}

#line 52 "src/distribution/InverseGammaGamma.birch"
void birch::type::InverseGammaGamma::link() {
  #line 52 "src/distribution/InverseGammaGamma.birch"
  libbirch_function_("link", "src/distribution/InverseGammaGamma.birch", 52);
  #line 53 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/InverseGammaGamma.birch"
  this->_u0952->setChild(this->shared_from_this_());
}

#line 56 "src/distribution/InverseGammaGamma.birch"
void birch::type::InverseGammaGamma::unlink() {
  #line 56 "src/distribution/InverseGammaGamma.birch"
  libbirch_function_("unlink", "src/distribution/InverseGammaGamma.birch", 56);
  #line 57 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/InverseGammaGamma.birch"
  this->_u0952->releaseChild(this->shared_from_this_());
}

#line 61 "src/distribution/InverseGammaGamma.birch"
libbirch::Shared<birch::type::InverseGammaGamma> birch::InverseGammaGamma(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k, const libbirch::Shared<birch::type::InverseGamma>& _u0952) {
  #line 61 "src/distribution/InverseGammaGamma.birch"
  libbirch_function_("InverseGammaGamma", "src/distribution/InverseGammaGamma.birch", 61);
  #line 63 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(63);
  #line 63 "src/distribution/InverseGammaGamma.birch"
  libbirch::Shared<birch::type::InverseGammaGamma> m = libbirch::make<libbirch::Shared<birch::type::InverseGammaGamma>>(std::in_place, k, _u0952);
  #line 64 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(64);
  #line 64 "src/distribution/InverseGammaGamma.birch"
  m->link();
  #line 65 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/InverseGammaGamma.birch"
  return m;
}

#line 30 "src/distribution/InverseWishart.birch"
birch::type::InverseWishart::InverseWishart(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& _u0936, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k) :
    #line 30 "src/distribution/InverseWishart.birch"
    base_type_(),
    #line 35 "src/distribution/InverseWishart.birch"
    _u0936(std::move(_u0936)),
    #line 40 "src/distribution/InverseWishart.birch"
    k(std::move(k)) {
  //
}

#line 42 "src/distribution/InverseWishart.birch"
birch::type::Integer birch::type::InverseWishart::rows() {
  #line 42 "src/distribution/InverseWishart.birch"
  libbirch_function_("rows", "src/distribution/InverseWishart.birch", 42);
  #line 43 "src/distribution/InverseWishart.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/InverseWishart.birch"
  return this->_u0936->rows();
}

#line 46 "src/distribution/InverseWishart.birch"
birch::type::Integer birch::type::InverseWishart::columns() {
  #line 46 "src/distribution/InverseWishart.birch"
  libbirch_function_("columns", "src/distribution/InverseWishart.birch", 46);
  #line 47 "src/distribution/InverseWishart.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/InverseWishart.birch"
  return this->_u0936->columns();
}

#line 50 "src/distribution/InverseWishart.birch"
birch::type::Boolean birch::type::InverseWishart::supportsLazy() {
  #line 50 "src/distribution/InverseWishart.birch"
  libbirch_function_("supportsLazy", "src/distribution/InverseWishart.birch", 50);
  #line 51 "src/distribution/InverseWishart.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/InverseWishart.birch"
  return true;
}

#line 54 "src/distribution/InverseWishart.birch"
birch::type::LLT birch::type::InverseWishart::simulate() {
  #line 54 "src/distribution/InverseWishart.birch"
  libbirch_function_("simulate", "src/distribution/InverseWishart.birch", 54);
  #line 55 "src/distribution/InverseWishart.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/InverseWishart.birch"
  return birch::simulate_inverse_wishart(this->_u0936->value(), this->k->value());
}

#line 58 "src/distribution/InverseWishart.birch"
std::optional<birch::type::LLT> birch::type::InverseWishart::simulateLazy() {
  #line 58 "src/distribution/InverseWishart.birch"
  libbirch_function_("simulateLazy", "src/distribution/InverseWishart.birch", 58);
  #line 59 "src/distribution/InverseWishart.birch"
  libbirch_line_(59);
  #line 59 "src/distribution/InverseWishart.birch"
  return birch::simulate_inverse_wishart(this->_u0936->get(), this->k->get());
}

#line 62 "src/distribution/InverseWishart.birch"
birch::type::Real birch::type::InverseWishart::logpdf(const birch::type::LLT& X) {
  #line 62 "src/distribution/InverseWishart.birch"
  libbirch_function_("logpdf", "src/distribution/InverseWishart.birch", 62);
  #line 63 "src/distribution/InverseWishart.birch"
  libbirch_line_(63);
  #line 63 "src/distribution/InverseWishart.birch"
  return birch::logpdf_inverse_wishart(X, this->_u0936->value(), this->k->value());
}

#line 66 "src/distribution/InverseWishart.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::InverseWishart::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& X) {
  #line 66 "src/distribution/InverseWishart.birch"
  libbirch_function_("logpdfLazy", "src/distribution/InverseWishart.birch", 66);
  #line 67 "src/distribution/InverseWishart.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/InverseWishart.birch"
  return birch::logpdf_lazy_inverse_wishart(X, this->_u0936, this->k);
}

#line 70 "src/distribution/InverseWishart.birch"
std::optional<libbirch::Shared<birch::type::InverseWishart>> birch::type::InverseWishart::graftInverseWishart() {
  #line 70 "src/distribution/InverseWishart.birch"
  libbirch_function_("graftInverseWishart", "src/distribution/InverseWishart.birch", 70);
  #line 71 "src/distribution/InverseWishart.birch"
  libbirch_line_(71);
  #line 71 "src/distribution/InverseWishart.birch"
  this->prune();
  #line 72 "src/distribution/InverseWishart.birch"
  libbirch_line_(72);
  #line 72 "src/distribution/InverseWishart.birch"
  return this->shared_from_this_();
}

#line 75 "src/distribution/InverseWishart.birch"
void birch::type::InverseWishart::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 75 "src/distribution/InverseWishart.birch"
  libbirch_function_("write", "src/distribution/InverseWishart.birch", 75);
  #line 76 "src/distribution/InverseWishart.birch"
  libbirch_line_(76);
  #line 76 "src/distribution/InverseWishart.birch"
  this->prune();
  #line 77 "src/distribution/InverseWishart.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/InverseWishart.birch"
  buffer->set(birch::type::String("class"), birch::type::String("InverseWishart"));
  #line 78 "src/distribution/InverseWishart.birch"
  libbirch_line_(78);
  #line 78 "src/distribution/InverseWishart.birch"
  buffer->set(birch::type::String("Ψ"), this->_u0936);
  #line 79 "src/distribution/InverseWishart.birch"
  libbirch_line_(79);
  #line 79 "src/distribution/InverseWishart.birch"
  buffer->set(birch::type::String("k"), this->k);
}

#line 86 "src/distribution/InverseWishart.birch"
libbirch::Shared<birch::type::InverseWishart> birch::InverseWishart(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& _u0936, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k) {
  #line 86 "src/distribution/InverseWishart.birch"
  libbirch_function_("InverseWishart", "src/distribution/InverseWishart.birch", 86);
  #line 88 "src/distribution/InverseWishart.birch"
  libbirch_line_(88);
  #line 88 "src/distribution/InverseWishart.birch"
  return birch::construct<libbirch::Shared<birch::type::InverseWishart>>(_u0936, k);
}

#line 94 "src/distribution/InverseWishart.birch"
libbirch::Shared<birch::type::InverseWishart> birch::InverseWishart(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& _u0936, const birch::type::Real& k) {
  #line 94 "src/distribution/InverseWishart.birch"
  libbirch_function_("InverseWishart", "src/distribution/InverseWishart.birch", 94);
  #line 95 "src/distribution/InverseWishart.birch"
  libbirch_line_(95);
  #line 95 "src/distribution/InverseWishart.birch"
  return birch::InverseWishart(_u0936, birch::box(k));
}

#line 101 "src/distribution/InverseWishart.birch"
libbirch::Shared<birch::type::InverseWishart> birch::InverseWishart(const birch::type::LLT& _u0936, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k) {
  #line 101 "src/distribution/InverseWishart.birch"
  libbirch_function_("InverseWishart", "src/distribution/InverseWishart.birch", 101);
  #line 102 "src/distribution/InverseWishart.birch"
  libbirch_line_(102);
  #line 102 "src/distribution/InverseWishart.birch"
  return birch::InverseWishart(birch::box(_u0936), k);
}

#line 108 "src/distribution/InverseWishart.birch"
libbirch::Shared<birch::type::InverseWishart> birch::InverseWishart(const birch::type::LLT& _u0936, const birch::type::Real& k) {
  #line 108 "src/distribution/InverseWishart.birch"
  libbirch_function_("InverseWishart", "src/distribution/InverseWishart.birch", 108);
  #line 109 "src/distribution/InverseWishart.birch"
  libbirch_line_(109);
  #line 109 "src/distribution/InverseWishart.birch"
  return birch::InverseWishart(birch::box(_u0936), birch::box(k));
}

#line 115 "src/distribution/InverseWishart.birch"
libbirch::Shared<birch::type::InverseWishart> birch::InverseWishart(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& _u0936, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k) {
  #line 115 "src/distribution/InverseWishart.birch"
  libbirch_function_("InverseWishart", "src/distribution/InverseWishart.birch", 115);
  #line 117 "src/distribution/InverseWishart.birch"
  libbirch_line_(117);
  #line 117 "src/distribution/InverseWishart.birch"
  return birch::InverseWishart(birch::llt(_u0936), k);
}

#line 123 "src/distribution/InverseWishart.birch"
libbirch::Shared<birch::type::InverseWishart> birch::InverseWishart(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& _u0936, const birch::type::Real& k) {
  #line 123 "src/distribution/InverseWishart.birch"
  libbirch_function_("InverseWishart", "src/distribution/InverseWishart.birch", 123);
  #line 124 "src/distribution/InverseWishart.birch"
  libbirch_line_(124);
  #line 124 "src/distribution/InverseWishart.birch"
  return birch::InverseWishart(birch::llt(_u0936), k);
}

#line 130 "src/distribution/InverseWishart.birch"
libbirch::Shared<birch::type::InverseWishart> birch::InverseWishart(const libbirch::DefaultArray<birch::type::Real,2>& _u0936, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k) {
  #line 130 "src/distribution/InverseWishart.birch"
  libbirch_function_("InverseWishart", "src/distribution/InverseWishart.birch", 130);
  #line 131 "src/distribution/InverseWishart.birch"
  libbirch_line_(131);
  #line 131 "src/distribution/InverseWishart.birch"
  return birch::InverseWishart(birch::llt(_u0936), k);
}

#line 137 "src/distribution/InverseWishart.birch"
libbirch::Shared<birch::type::InverseWishart> birch::InverseWishart(const libbirch::DefaultArray<birch::type::Real,2>& _u0936, const birch::type::Real& k) {
  #line 137 "src/distribution/InverseWishart.birch"
  libbirch_function_("InverseWishart", "src/distribution/InverseWishart.birch", 137);
  #line 138 "src/distribution/InverseWishart.birch"
  libbirch_line_(138);
  #line 138 "src/distribution/InverseWishart.birch"
  return birch::InverseWishart(birch::llt(_u0936), k);
}

#line 5 "src/distribution/LinearBoundedDiscrete.birch"
birch::type::LinearBoundedDiscrete::LinearBoundedDiscrete(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& a, const libbirch::Shared<birch::type::BoundedDiscrete>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& c) :
    #line 5 "src/distribution/LinearBoundedDiscrete.birch"
    base_type_(),
    #line 10 "src/distribution/LinearBoundedDiscrete.birch"
    a(std::move(a)),
    #line 15 "src/distribution/LinearBoundedDiscrete.birch"
    _u0956(std::move(_u0956)),
    #line 20 "src/distribution/LinearBoundedDiscrete.birch"
    c(std::move(c)) {
  //
}

#line 22 "src/distribution/LinearBoundedDiscrete.birch"
birch::type::Boolean birch::type::LinearBoundedDiscrete::supportsLazy() {
  #line 22 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("supportsLazy", "src/distribution/LinearBoundedDiscrete.birch", 22);
  #line 23 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/LinearBoundedDiscrete.birch"
  return false;
}

#line 26 "src/distribution/LinearBoundedDiscrete.birch"
birch::type::Integer birch::type::LinearBoundedDiscrete::simulate() {
  #line 26 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("simulate", "src/distribution/LinearBoundedDiscrete.birch", 26);
  #line 27 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(27);
  #line 27 "src/distribution/LinearBoundedDiscrete.birch"
  return birch::simulate_delta(this->a->value() * this->_u0956->simulate() + this->c->value());
}

#line 34 "src/distribution/LinearBoundedDiscrete.birch"
birch::type::Real birch::type::LinearBoundedDiscrete::logpdf(const birch::type::Integer& x) {
  #line 34 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("logpdf", "src/distribution/LinearBoundedDiscrete.birch", 34);
  #line 35 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(35);
  #line 35 "src/distribution/LinearBoundedDiscrete.birch"
  return this->_u0956->logpdf((x - this->c->value()) / this->a->value()) - birch::log(birch::abs(birch::Real(this->a->value())));
}

#line 42 "src/distribution/LinearBoundedDiscrete.birch"
void birch::type::LinearBoundedDiscrete::update(const birch::type::Integer& x) {
  #line 42 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("update", "src/distribution/LinearBoundedDiscrete.birch", 42);
  #line 43 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/LinearBoundedDiscrete.birch"
  this->_u0956->clamp((x - this->c->value()) / this->a->value());
}

#line 50 "src/distribution/LinearBoundedDiscrete.birch"
std::optional<birch::type::Real> birch::type::LinearBoundedDiscrete::cdf(const birch::type::Integer& x) {
  #line 50 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("cdf", "src/distribution/LinearBoundedDiscrete.birch", 50);
  #line 51 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/LinearBoundedDiscrete.birch"
  return this->_u0956->cdf((x - this->c->value()) / this->a->value());
}

#line 54 "src/distribution/LinearBoundedDiscrete.birch"
std::optional<birch::type::Integer> birch::type::LinearBoundedDiscrete::lower() {
  #line 54 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("lower", "src/distribution/LinearBoundedDiscrete.birch", 54);
  #line 55 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/LinearBoundedDiscrete.birch"
  auto a = this->a->value();
  #line 56 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/LinearBoundedDiscrete.birch"
  if (a > birch::type::Integer(0)) {
    #line 57 "src/distribution/LinearBoundedDiscrete.birch"
    libbirch_line_(57);
    #line 57 "src/distribution/LinearBoundedDiscrete.birch"
    return a * this->_u0956->lower().value() + this->c->value();
  } else {
    #line 59 "src/distribution/LinearBoundedDiscrete.birch"
    libbirch_line_(59);
    #line 59 "src/distribution/LinearBoundedDiscrete.birch"
    return a * this->_u0956->upper().value() + this->c->value();
  }
}

#line 63 "src/distribution/LinearBoundedDiscrete.birch"
std::optional<birch::type::Integer> birch::type::LinearBoundedDiscrete::upper() {
  #line 63 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("upper", "src/distribution/LinearBoundedDiscrete.birch", 63);
  #line 64 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(64);
  #line 64 "src/distribution/LinearBoundedDiscrete.birch"
  auto a = this->a->value();
  #line 65 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/LinearBoundedDiscrete.birch"
  if (a > birch::type::Integer(0)) {
    #line 66 "src/distribution/LinearBoundedDiscrete.birch"
    libbirch_line_(66);
    #line 66 "src/distribution/LinearBoundedDiscrete.birch"
    return a * this->_u0956->upper().value() + this->c->value();
  } else {
    #line 68 "src/distribution/LinearBoundedDiscrete.birch"
    libbirch_line_(68);
    #line 68 "src/distribution/LinearBoundedDiscrete.birch"
    return a * this->_u0956->lower().value() + this->c->value();
  }
}

#line 72 "src/distribution/LinearBoundedDiscrete.birch"
void birch::type::LinearBoundedDiscrete::link() {
  #line 72 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("link", "src/distribution/LinearBoundedDiscrete.birch", 72);
  #line 73 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(73);
  #line 73 "src/distribution/LinearBoundedDiscrete.birch"
  this->_u0956->setChild(this->shared_from_this_());
}

#line 76 "src/distribution/LinearBoundedDiscrete.birch"
void birch::type::LinearBoundedDiscrete::unlink() {
  #line 76 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("unlink", "src/distribution/LinearBoundedDiscrete.birch", 76);
  #line 77 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/LinearBoundedDiscrete.birch"
  this->_u0956->releaseChild(this->shared_from_this_());
}

#line 81 "src/distribution/LinearBoundedDiscrete.birch"
libbirch::Shared<birch::type::LinearBoundedDiscrete> birch::LinearBoundedDiscrete(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& a, const libbirch::Shared<birch::type::BoundedDiscrete>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& c) {
  #line 81 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("LinearBoundedDiscrete", "src/distribution/LinearBoundedDiscrete.birch", 81);
  #line 83 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(83);
  #line 83 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch::Shared<birch::type::LinearBoundedDiscrete> m = libbirch::make<libbirch::Shared<birch::type::LinearBoundedDiscrete>>(std::in_place, a, _u0956, c);
  #line 84 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(84);
  #line 84 "src/distribution/LinearBoundedDiscrete.birch"
  m->link();
  #line 85 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(85);
  #line 85 "src/distribution/LinearBoundedDiscrete.birch"
  return m;
}

#line 5 "src/distribution/LinearDiscrete.birch"
birch::type::LinearDiscrete::LinearDiscrete(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& a, const libbirch::Shared<birch::type::Discrete>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& c) :
    #line 5 "src/distribution/LinearDiscrete.birch"
    base_type_(),
    #line 10 "src/distribution/LinearDiscrete.birch"
    a(std::move(a)),
    #line 15 "src/distribution/LinearDiscrete.birch"
    _u0956(std::move(_u0956)),
    #line 20 "src/distribution/LinearDiscrete.birch"
    c(std::move(c)) {
  //
}

#line 22 "src/distribution/LinearDiscrete.birch"
birch::type::Boolean birch::type::LinearDiscrete::supportsLazy() {
  #line 22 "src/distribution/LinearDiscrete.birch"
  libbirch_function_("supportsLazy", "src/distribution/LinearDiscrete.birch", 22);
  #line 23 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/LinearDiscrete.birch"
  return false;
}

#line 26 "src/distribution/LinearDiscrete.birch"
birch::type::Integer birch::type::LinearDiscrete::simulate() {
  #line 26 "src/distribution/LinearDiscrete.birch"
  libbirch_function_("simulate", "src/distribution/LinearDiscrete.birch", 26);
  #line 27 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(27);
  #line 27 "src/distribution/LinearDiscrete.birch"
  return birch::simulate_delta(this->a->value() * this->_u0956->simulate() + this->c->value());
}

#line 34 "src/distribution/LinearDiscrete.birch"
birch::type::Real birch::type::LinearDiscrete::logpdf(const birch::type::Integer& x) {
  #line 34 "src/distribution/LinearDiscrete.birch"
  libbirch_function_("logpdf", "src/distribution/LinearDiscrete.birch", 34);
  #line 35 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(35);
  #line 35 "src/distribution/LinearDiscrete.birch"
  return this->_u0956->logpdf((x - this->c->value()) / this->a->value()) - birch::log(birch::abs(birch::Real(this->a->value())));
}

#line 42 "src/distribution/LinearDiscrete.birch"
void birch::type::LinearDiscrete::update(const birch::type::Integer& x) {
  #line 42 "src/distribution/LinearDiscrete.birch"
  libbirch_function_("update", "src/distribution/LinearDiscrete.birch", 42);
  #line 43 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/LinearDiscrete.birch"
  this->_u0956->clamp((x - this->c->value()) / this->a->value());
}

#line 50 "src/distribution/LinearDiscrete.birch"
std::optional<birch::type::Real> birch::type::LinearDiscrete::cdf(const birch::type::Integer& x) {
  #line 50 "src/distribution/LinearDiscrete.birch"
  libbirch_function_("cdf", "src/distribution/LinearDiscrete.birch", 50);
  #line 51 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/LinearDiscrete.birch"
  return this->_u0956->cdf((x - this->c->value()) / this->a->value());
}

#line 54 "src/distribution/LinearDiscrete.birch"
std::optional<birch::type::Integer> birch::type::LinearDiscrete::lower() {
  #line 54 "src/distribution/LinearDiscrete.birch"
  libbirch_function_("lower", "src/distribution/LinearDiscrete.birch", 54);
  #line 55 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/LinearDiscrete.birch"
  auto l = this->_u0956->lower();
  #line 56 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/LinearDiscrete.birch"
  if (l.has_value()) {
    #line 57 "src/distribution/LinearDiscrete.birch"
    libbirch_line_(57);
    #line 57 "src/distribution/LinearDiscrete.birch"
    l = this->a->value() * l.value() + this->c->value();
  }
  #line 59 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(59);
  #line 59 "src/distribution/LinearDiscrete.birch"
  return l;
}

#line 62 "src/distribution/LinearDiscrete.birch"
std::optional<birch::type::Integer> birch::type::LinearDiscrete::upper() {
  #line 62 "src/distribution/LinearDiscrete.birch"
  libbirch_function_("upper", "src/distribution/LinearDiscrete.birch", 62);
  #line 63 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(63);
  #line 63 "src/distribution/LinearDiscrete.birch"
  auto u = this->_u0956->upper();
  #line 64 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(64);
  #line 64 "src/distribution/LinearDiscrete.birch"
  if (u.has_value()) {
    #line 65 "src/distribution/LinearDiscrete.birch"
    libbirch_line_(65);
    #line 65 "src/distribution/LinearDiscrete.birch"
    u = this->a->value() * u.value() + this->c->value();
  }
  #line 67 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/LinearDiscrete.birch"
  return u;
}

#line 70 "src/distribution/LinearDiscrete.birch"
void birch::type::LinearDiscrete::link() {
  #line 70 "src/distribution/LinearDiscrete.birch"
  libbirch_function_("link", "src/distribution/LinearDiscrete.birch", 70);
  #line 71 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(71);
  #line 71 "src/distribution/LinearDiscrete.birch"
  this->_u0956->setChild(this->shared_from_this_());
}

#line 74 "src/distribution/LinearDiscrete.birch"
void birch::type::LinearDiscrete::unlink() {
  #line 74 "src/distribution/LinearDiscrete.birch"
  libbirch_function_("unlink", "src/distribution/LinearDiscrete.birch", 74);
  #line 75 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(75);
  #line 75 "src/distribution/LinearDiscrete.birch"
  this->_u0956->releaseChild(this->shared_from_this_());
}

#line 79 "src/distribution/LinearDiscrete.birch"
libbirch::Shared<birch::type::LinearDiscrete> birch::LinearDiscrete(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& a, const libbirch::Shared<birch::type::Discrete>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& c) {
  #line 79 "src/distribution/LinearDiscrete.birch"
  libbirch_function_("LinearDiscrete", "src/distribution/LinearDiscrete.birch", 79);
  #line 81 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(81);
  #line 81 "src/distribution/LinearDiscrete.birch"
  libbirch::Shared<birch::type::LinearDiscrete> m = libbirch::make<libbirch::Shared<birch::type::LinearDiscrete>>(std::in_place, a, _u0956, c);
  #line 82 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(82);
  #line 82 "src/distribution/LinearDiscrete.birch"
  m->link();
  #line 83 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(83);
  #line 83 "src/distribution/LinearDiscrete.birch"
  return m;
}

#line 4 "src/distribution/LinearGaussianGaussian.birch"
birch::type::LinearGaussianGaussian::LinearGaussianGaussian(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& a, const libbirch::Shared<birch::type::Gaussian>& m, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& c, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& s2) :
    #line 4 "src/distribution/LinearGaussianGaussian.birch"
    base_type_(a * m->_u0956 + c, a * a * m->_u09632 + s2),
    #line 10 "src/distribution/LinearGaussianGaussian.birch"
    a(a),
    #line 15 "src/distribution/LinearGaussianGaussian.birch"
    m(m),
    #line 20 "src/distribution/LinearGaussianGaussian.birch"
    c(c),
    #line 25 "src/distribution/LinearGaussianGaussian.birch"
    s2(s2) {
  //
}

#line 27 "src/distribution/LinearGaussianGaussian.birch"
void birch::type::LinearGaussianGaussian::update(const birch::type::Real& x) {
  #line 27 "src/distribution/LinearGaussianGaussian.birch"
  libbirch_function_("update", "src/distribution/LinearGaussianGaussian.birch", 27);
  #line 28 "src/distribution/LinearGaussianGaussian.birch"
  libbirch_line_(28);
  #line 28 "src/distribution/LinearGaussianGaussian.birch"
  std::tie(this->m->_u0956, this->m->_u09632) = birch::box(birch::update_linear_gaussian_gaussian(x, this->a->value(), this->m->_u0956->value(), this->m->_u09632->value(), this->c->value(), this->s2->value()));
}

#line 31 "src/distribution/LinearGaussianGaussian.birch"
void birch::type::LinearGaussianGaussian::updateLazy(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 31 "src/distribution/LinearGaussianGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/LinearGaussianGaussian.birch", 31);
  #line 32 "src/distribution/LinearGaussianGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/distribution/LinearGaussianGaussian.birch"
  std::tie(this->m->_u0956, this->m->_u09632) = birch::update_lazy_linear_gaussian_gaussian(x, this->a, this->m->_u0956, this->m->_u09632, this->c, this->s2);
}

#line 35 "src/distribution/LinearGaussianGaussian.birch"
void birch::type::LinearGaussianGaussian::link() {
  #line 35 "src/distribution/LinearGaussianGaussian.birch"
  libbirch_function_("link", "src/distribution/LinearGaussianGaussian.birch", 35);
  #line 36 "src/distribution/LinearGaussianGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/LinearGaussianGaussian.birch"
  this->m->setChild(this->shared_from_this_());
}

#line 39 "src/distribution/LinearGaussianGaussian.birch"
void birch::type::LinearGaussianGaussian::unlink() {
  #line 39 "src/distribution/LinearGaussianGaussian.birch"
  libbirch_function_("unlink", "src/distribution/LinearGaussianGaussian.birch", 39);
  #line 40 "src/distribution/LinearGaussianGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/distribution/LinearGaussianGaussian.birch"
  this->m->releaseChild(this->shared_from_this_());
}

#line 44 "src/distribution/LinearGaussianGaussian.birch"
libbirch::Shared<birch::type::LinearGaussianGaussian> birch::LinearGaussianGaussian(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& a, const libbirch::Shared<birch::type::Gaussian>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& c, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632) {
  #line 44 "src/distribution/LinearGaussianGaussian.birch"
  libbirch_function_("LinearGaussianGaussian", "src/distribution/LinearGaussianGaussian.birch", 44);
  #line 46 "src/distribution/LinearGaussianGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/LinearGaussianGaussian.birch"
  libbirch::Shared<birch::type::LinearGaussianGaussian> m = libbirch::make<libbirch::Shared<birch::type::LinearGaussianGaussian>>(std::in_place, a, _u0956, c, _u09632);
  #line 47 "src/distribution/LinearGaussianGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/LinearGaussianGaussian.birch"
  m->link();
  #line 48 "src/distribution/LinearGaussianGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/distribution/LinearGaussianGaussian.birch"
  return m;
}

#line 5 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::LinearMatrixNormalInverseWishartMatrixGaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& A, const libbirch::Shared<birch::type::MatrixNormalInverseWishart>& M, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& C) :
    #line 5 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
    base_type_(),
    #line 11 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
    A(std::move(A)),
    #line 16 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
    M(std::move(M)),
    #line 21 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
    C(std::move(C)) {
  //
}

#line 23 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Integer birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::rows() {
  #line 23 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("rows", "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 23);
  #line 24 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(24);
  #line 24 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return this->C->rows();
}

#line 27 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Integer birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::columns() {
  #line 27 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("columns", "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 27);
  #line 28 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(28);
  #line 28 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return this->C->columns();
}

#line 31 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Boolean birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::supportsLazy() {
  #line 31 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 31);
  #line 32 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return true;
}

#line 35 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::simulate() {
  #line 35 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("simulate", "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 35);
  #line 36 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return birch::simulate_linear_matrix_normal_inverse_wishart_matrix_gaussian(this->A->value(), this->M->N->value(), this->M->_u0923->value(), this->C->value(), this->M->V->_u0936->value(), this->M->V->k->value());
}

#line 40 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
std::optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::simulateLazy() {
  #line 40 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 40);
  #line 41 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return birch::simulate_linear_matrix_normal_inverse_wishart_matrix_gaussian(this->A->get(), this->M->N->get(), this->M->_u0923->get(), this->C->get(), this->M->V->_u0936->get(), this->M->V->k->get());
}

#line 45 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Real birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 45 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 45);
  #line 46 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return birch::logpdf_linear_matrix_normal_inverse_wishart_matrix_gaussian(X, this->A->value(), this->M->N->value(), this->M->_u0923->value(), this->C->value(), this->M->V->_u0936->value(), this->M->V->k->value());
}

#line 50 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::logpdfLazy(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& X) {
  #line 50 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 50);
  #line 51 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return birch::logpdf_lazy_linear_matrix_normal_inverse_wishart_matrix_gaussian(X, this->A, this->M->N, this->M->_u0923, this->C, this->M->V->_u0936, this->M->V->k);
}

#line 55 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::update(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 55 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("update", "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 55);
  #line 56 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  std::tie(this->M->N, this->M->_u0923, this->M->V->_u0936, this->M->V->k) = birch::box(birch::update_linear_matrix_normal_inverse_wishart_matrix_gaussian(X, this->A->value(), this->M->N->value(), this->M->_u0923->value(), this->C->value(), this->M->V->_u0936->value(), this->M->V->k->value()));
}

#line 60 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::updateLazy(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& X) {
  #line 60 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 60);
  #line 61 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  std::tie(this->M->N, this->M->_u0923, this->M->V->_u0936, this->M->V->k) = birch::update_lazy_linear_matrix_normal_inverse_wishart_matrix_gaussian(X, this->A, this->M->N, this->M->_u0923, this->C, this->M->V->_u0936, this->M->V->k);
}

#line 65 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::link() {
  #line 65 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("link", "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 65);
  #line 66 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this->M->setChild(this->shared_from_this_());
}

#line 69 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::unlink() {
  #line 69 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("unlink", "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 69);
  #line 70 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(70);
  #line 70 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this->M->releaseChild(this->shared_from_this_());
}

#line 74 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::Shared<birch::type::LinearMatrixNormalInverseWishartMatrixGaussian> birch::LinearMatrixNormalInverseWishartMatrixGaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& A, const libbirch::Shared<birch::type::MatrixNormalInverseWishart>& M, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& C) {
  #line 74 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("LinearMatrixNormalInverseWishartMatrixGaussian", "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 74);
  #line 77 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::Shared<birch::type::LinearMatrixNormalInverseWishartMatrixGaussian> m = libbirch::make<libbirch::Shared<birch::type::LinearMatrixNormalInverseWishartMatrixGaussian>>(std::in_place, A, M, C);
  #line 78 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(78);
  #line 78 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  m->link();
  #line 79 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(79);
  #line 79 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return m;
}

#line 5 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
birch::type::LinearMatrixNormalInverseWishartMultivariateGaussian::LinearMatrixNormalInverseWishartMultivariateGaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& a, const libbirch::Shared<birch::type::MatrixNormalInverseWishart>& M, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& c) :
    #line 5 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    base_type_(),
    #line 11 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    a(std::move(a)),
    #line 15 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    M(std::move(M)),
    #line 20 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    c(std::move(c)) {
  //
}

#line 22 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
birch::type::Integer birch::type::LinearMatrixNormalInverseWishartMultivariateGaussian::rows() {
  #line 22 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_function_("rows", "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch", 22);
  #line 23 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  return this->c->rows();
}

#line 26 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
birch::type::Boolean birch::type::LinearMatrixNormalInverseWishartMultivariateGaussian::supportsLazy() {
  #line 26 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch", 26);
  #line 27 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(27);
  #line 27 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  return true;
}

#line 30 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::LinearMatrixNormalInverseWishartMultivariateGaussian::simulate() {
  #line 30 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_function_("simulate", "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch", 30);
  #line 31 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  return birch::simulate_linear_matrix_normal_inverse_wishart_multivariate_gaussian(this->a->value(), this->M->N->value(), this->M->_u0923->value(), this->c->value(), this->M->V->_u0936->value(), this->M->V->k->value());
}

#line 36 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
std::optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::LinearMatrixNormalInverseWishartMultivariateGaussian::simulateLazy() {
  #line 36 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch", 36);
  #line 37 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  return birch::simulate_linear_matrix_normal_inverse_wishart_multivariate_gaussian(this->a->get(), this->M->N->get(), this->M->_u0923->get(), this->c->get(), this->M->V->_u0936->get(), this->M->V->k->get());
}

#line 41 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
birch::type::Real birch::type::LinearMatrixNormalInverseWishartMultivariateGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 41 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch", 41);
  #line 42 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  return birch::logpdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian(x, this->a->value(), this->M->N->value(), this->M->_u0923->value(), this->c->value(), this->M->V->_u0936->value(), this->M->V->k->value());
}

#line 47 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::LinearMatrixNormalInverseWishartMultivariateGaussian::logpdfLazy(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x) {
  #line 47 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch", 47);
  #line 48 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  return birch::logpdf_lazy_linear_matrix_normal_inverse_wishart_multivariate_gaussian(x, this->a, this->M->N, this->M->_u0923, this->c, this->M->V->_u0936, this->M->V->k);
}

#line 52 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
void birch::type::LinearMatrixNormalInverseWishartMultivariateGaussian::update(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 52 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_function_("update", "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch", 52);
  #line 53 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  std::tie(this->M->N, this->M->_u0923, this->M->V->_u0936, this->M->V->k) = birch::box(birch::update_linear_matrix_normal_inverse_wishart_multivariate_gaussian(x, this->a->value(), this->M->N->value(), this->M->_u0923->value(), this->c->value(), this->M->V->_u0936->value(), this->M->V->k->value()));
}

#line 58 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
void birch::type::LinearMatrixNormalInverseWishartMultivariateGaussian::updateLazy(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x) {
  #line 58 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch", 58);
  #line 59 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(59);
  #line 59 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  std::tie(this->M->N, this->M->_u0923, this->M->V->_u0936, this->M->V->k) = birch::update_lazy_linear_matrix_normal_inverse_wishart_multivariate_gaussian(x, this->a, this->M->N, this->M->_u0923, this->c, this->M->V->_u0936, this->M->V->k);
}

#line 63 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
void birch::type::LinearMatrixNormalInverseWishartMultivariateGaussian::link() {
  #line 63 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_function_("link", "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch", 63);
  #line 64 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(64);
  #line 64 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  this->M->setChild(this->shared_from_this_());
}

#line 67 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
void birch::type::LinearMatrixNormalInverseWishartMultivariateGaussian::unlink() {
  #line 67 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_function_("unlink", "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch", 67);
  #line 68 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(68);
  #line 68 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  this->M->releaseChild(this->shared_from_this_());
}

#line 72 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
libbirch::Shared<birch::type::LinearMatrixNormalInverseWishartMultivariateGaussian> birch::LinearMatrixNormalInverseWishartMultivariateGaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& a, const libbirch::Shared<birch::type::MatrixNormalInverseWishart>& M, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& c) {
  #line 72 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_function_("LinearMatrixNormalInverseWishartMultivariateGaussian", "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch", 72);
  #line 76 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(76);
  #line 76 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch::Shared<birch::type::LinearMatrixNormalInverseWishartMultivariateGaussian> m = libbirch::make<libbirch::Shared<birch::type::LinearMatrixNormalInverseWishartMultivariateGaussian>>(std::in_place, a, M, c);
  #line 77 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  m->link();
  #line 78 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(78);
  #line 78 "src/distribution/LinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  return m;
}

#line 4 "src/distribution/LinearMultivariateGaussianGaussian.birch"
birch::type::LinearMultivariateGaussianGaussian::LinearMultivariateGaussianGaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& a, const libbirch::Shared<birch::type::MultivariateGaussian>& m, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& c, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& s2) :
    #line 4 "src/distribution/LinearMultivariateGaussianGaussian.birch"
    base_type_(birch::dot(a, m->_u0956) + c, birch::dot(a, birch::canonical(m->_u0931) * a) + s2),
    #line 10 "src/distribution/LinearMultivariateGaussianGaussian.birch"
    a(a),
    #line 15 "src/distribution/LinearMultivariateGaussianGaussian.birch"
    m(m),
    #line 20 "src/distribution/LinearMultivariateGaussianGaussian.birch"
    c(c),
    #line 25 "src/distribution/LinearMultivariateGaussianGaussian.birch"
    s2(s2) {
  //
}

#line 27 "src/distribution/LinearMultivariateGaussianGaussian.birch"
void birch::type::LinearMultivariateGaussianGaussian::update(const birch::type::Real& x) {
  #line 27 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_function_("update", "src/distribution/LinearMultivariateGaussianGaussian.birch", 27);
  #line 28 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_line_(28);
  #line 28 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  std::tie(this->m->_u0956, this->m->_u0931) = birch::box(birch::update_linear_multivariate_gaussian_gaussian(x, this->a->value(), this->m->_u0956->value(), this->m->_u0931->value(), this->c->value(), this->s2->value()));
}

#line 32 "src/distribution/LinearMultivariateGaussianGaussian.birch"
void birch::type::LinearMultivariateGaussianGaussian::updateLazy(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 32 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/LinearMultivariateGaussianGaussian.birch", 32);
  #line 33 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  std::tie(this->m->_u0956, this->m->_u0931) = birch::update_lazy_linear_multivariate_gaussian_gaussian(x, this->a, this->m->_u0956, this->m->_u0931, this->c, this->s2);
}

#line 37 "src/distribution/LinearMultivariateGaussianGaussian.birch"
void birch::type::LinearMultivariateGaussianGaussian::link() {
  #line 37 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_function_("link", "src/distribution/LinearMultivariateGaussianGaussian.birch", 37);
  #line 38 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  this->m->setChild(this->shared_from_this_());
}

#line 41 "src/distribution/LinearMultivariateGaussianGaussian.birch"
void birch::type::LinearMultivariateGaussianGaussian::unlink() {
  #line 41 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_function_("unlink", "src/distribution/LinearMultivariateGaussianGaussian.birch", 41);
  #line 42 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  this->m->releaseChild(this->shared_from_this_());
}

#line 46 "src/distribution/LinearMultivariateGaussianGaussian.birch"
libbirch::Shared<birch::type::LinearMultivariateGaussianGaussian> birch::LinearMultivariateGaussianGaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& a, const libbirch::Shared<birch::type::MultivariateGaussian>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& c, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632) {
  #line 46 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_function_("LinearMultivariateGaussianGaussian", "src/distribution/LinearMultivariateGaussianGaussian.birch", 46);
  #line 49 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch::Shared<birch::type::LinearMultivariateGaussianGaussian> m = libbirch::make<libbirch::Shared<birch::type::LinearMultivariateGaussianGaussian>>(std::in_place, a, _u0956, c, _u09632);
  #line 50 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  m->link();
  #line 51 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  return m;
}

#line 4 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
birch::type::LinearMultivariateGaussianMultivariateGaussian::LinearMultivariateGaussianMultivariateGaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& A, const libbirch::Shared<birch::type::MultivariateGaussian>& m, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& c, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& S) :
    #line 4 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
    base_type_(A * m->_u0956 + c, birch::llt(A * birch::canonical(m->_u0931) * birch::transpose(A) + birch::canonical(S))),
    #line 11 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
    A(A),
    #line 16 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
    m(m),
    #line 21 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
    c(c),
    #line 26 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
    S(S) {
  //
}

#line 28 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
void birch::type::LinearMultivariateGaussianMultivariateGaussian::update(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 28 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("update", "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch", 28);
  #line 29 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  std::tie(this->m->_u0956, this->m->_u0931) = birch::box(birch::update_linear_multivariate_gaussian_multivariate_gaussian(x, this->A->value(), this->m->_u0956->value(), this->m->_u0931->value(), this->c->value(), this->S->value()));
}

#line 33 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
void birch::type::LinearMultivariateGaussianMultivariateGaussian::updateLazy(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x) {
  #line 33 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch", 33);
  #line 34 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  std::tie(this->m->_u0956, this->m->_u0931) = birch::update_lazy_linear_multivariate_gaussian_multivariate_gaussian(x, this->A, this->m->_u0956, this->m->_u0931, this->c, this->S);
}

#line 38 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
void birch::type::LinearMultivariateGaussianMultivariateGaussian::link() {
  #line 38 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("link", "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch", 38);
  #line 39 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  this->m->setChild(this->shared_from_this_());
}

#line 42 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
void birch::type::LinearMultivariateGaussianMultivariateGaussian::unlink() {
  #line 42 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("unlink", "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch", 42);
  #line 43 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  this->m->releaseChild(this->shared_from_this_());
}

#line 47 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
libbirch::Shared<birch::type::LinearMultivariateGaussianMultivariateGaussian> birch::LinearMultivariateGaussianMultivariateGaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& A, const libbirch::Shared<birch::type::MultivariateGaussian>& _u0956, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& c, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& _u0931) {
  #line 47 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("LinearMultivariateGaussianMultivariateGaussian", "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch", 47);
  #line 51 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch::Shared<birch::type::LinearMultivariateGaussianMultivariateGaussian> m = libbirch::make<libbirch::Shared<birch::type::LinearMultivariateGaussianMultivariateGaussian>>(std::in_place, A, _u0956, c, _u0931);
  #line 52 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  m->link();
  #line 53 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  return m;
}

#line 4 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
birch::type::LinearMultivariateNormalInverseGammaGaussian::LinearMultivariateNormalInverseGammaGaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& a, const libbirch::Shared<birch::type::MultivariateNormalInverseGamma>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& c) :
    #line 4 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
    base_type_(),
    #line 10 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
    a(std::move(a)),
    #line 15 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
    _u0956(std::move(_u0956)),
    #line 20 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
    c(std::move(c)) {
  //
}

#line 22 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
birch::type::Integer birch::type::LinearMultivariateNormalInverseGammaGaussian::rows() {
  #line 22 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("rows", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 22);
  #line 23 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return this->c->rows();
}

#line 26 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
birch::type::Boolean birch::type::LinearMultivariateNormalInverseGammaGaussian::supportsLazy() {
  #line 26 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 26);
  #line 27 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(27);
  #line 27 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return true;
}

#line 30 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
birch::type::Real birch::type::LinearMultivariateNormalInverseGammaGaussian::simulate() {
  #line 30 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("simulate", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 30);
  #line 31 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return birch::simulate_linear_multivariate_normal_inverse_gamma_gaussian(this->a->value(), this->_u0956->_u0957->value(), this->_u0956->_u0923->value(), this->c->value(), this->_u0956->_u0945->value(), this->_u0956->_u0947->value());
}

#line 36 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
std::optional<birch::type::Real> birch::type::LinearMultivariateNormalInverseGammaGaussian::simulateLazy() {
  #line 36 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 36);
  #line 37 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return birch::simulate_linear_multivariate_normal_inverse_gamma_gaussian(this->a->get(), this->_u0956->_u0957->get(), this->_u0956->_u0923->get(), this->c->get(), this->_u0956->_u0945->get(), this->_u0956->_u0947->get());
}

#line 42 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
birch::type::Real birch::type::LinearMultivariateNormalInverseGammaGaussian::logpdf(const birch::type::Real& x) {
  #line 42 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 42);
  #line 43 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return birch::logpdf_linear_multivariate_normal_inverse_gamma_gaussian(x, this->a->value(), this->_u0956->_u0957->value(), this->_u0956->_u0923->value(), this->c->value(), this->_u0956->_u0945->value(), this->_u0956->_u0947->value());
}

#line 48 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::LinearMultivariateNormalInverseGammaGaussian::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 48 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 48);
  #line 49 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return birch::logpdf_lazy_linear_multivariate_normal_inverse_gamma_gaussian(x, this->a, this->_u0956->_u0957, this->_u0956->_u0923, this->c, this->_u0956->_u0945, this->_u0956->_u0947);
}

#line 53 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaGaussian::update(const birch::type::Real& x) {
  #line 53 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("update", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 53);
  #line 54 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  std::tie(this->_u0956->_u0957, this->_u0956->_u0923, this->_u0956->_u0945, this->_u0956->_u0947) = birch::box(birch::update_linear_multivariate_normal_inverse_gamma_gaussian(x, this->a->value(), this->_u0956->_u0957->value(), this->_u0956->_u0923->value(), this->c->value(), this->_u0956->_u0945->value(), this->_u0956->_u0947->value()));
}

#line 59 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaGaussian::updateLazy(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 59 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 59);
  #line 60 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  std::tie(this->_u0956->_u0957, this->_u0956->_u0923, this->_u0956->_u0945, this->_u0956->_u0947) = birch::update_lazy_linear_multivariate_normal_inverse_gamma_gaussian(x, this->a, this->_u0956->_u0957, this->_u0956->_u0923, this->c, this->_u0956->_u0945, this->_u0956->_u0947);
}

#line 64 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
std::optional<birch::type::Real> birch::type::LinearMultivariateNormalInverseGammaGaussian::cdf(const birch::type::Real& x) {
  #line 64 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("cdf", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 64);
  #line 65 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return birch::cdf_linear_multivariate_normal_inverse_gamma_gaussian(x, this->a->value(), this->_u0956->_u0957->value(), this->_u0956->_u0923->value(), this->c->value(), this->_u0956->_u0945->value(), this->_u0956->_u0947->value());
}

#line 70 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
std::optional<birch::type::Real> birch::type::LinearMultivariateNormalInverseGammaGaussian::quantile(const birch::type::Real& P) {
  #line 70 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("quantile", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 70);
  #line 71 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(71);
  #line 71 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return birch::quantile_linear_multivariate_normal_inverse_gamma_gaussian(P, this->a->value(), this->_u0956->_u0957->value(), this->_u0956->_u0923->value(), this->c->value(), this->_u0956->_u0945->value(), this->_u0956->_u0947->value());
}

#line 76 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaGaussian::link() {
  #line 76 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("link", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 76);
  #line 77 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  this->_u0956->setChild(this->shared_from_this_());
}

#line 80 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaGaussian::unlink() {
  #line 80 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("unlink", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 80);
  #line 81 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(81);
  #line 81 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  this->_u0956->releaseChild(this->shared_from_this_());
}

#line 85 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
libbirch::Shared<birch::type::LinearMultivariateNormalInverseGammaGaussian> birch::LinearMultivariateNormalInverseGammaGaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& a, const libbirch::Shared<birch::type::MultivariateNormalInverseGamma>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& c) {
  #line 85 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("LinearMultivariateNormalInverseGammaGaussian", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 85);
  #line 88 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(88);
  #line 88 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch::Shared<birch::type::LinearMultivariateNormalInverseGammaGaussian> m = libbirch::make<libbirch::Shared<birch::type::LinearMultivariateNormalInverseGammaGaussian>>(std::in_place, a, _u0956, c);
  #line 89 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(89);
  #line 89 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  m->link();
  #line 90 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(90);
  #line 90 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return m;
}

#line 5 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::LinearMultivariateNormalInverseGammaMultivariateGaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& A, const libbirch::Shared<birch::type::MultivariateNormalInverseGamma>& _u0956, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& c) :
    #line 5 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    base_type_(),
    #line 11 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    A(std::move(A)),
    #line 16 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    _u0956(std::move(_u0956)),
    #line 21 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    c(std::move(c)) {
  //
}

#line 23 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::Integer birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::rows() {
  #line 23 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("rows", "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 23);
  #line 24 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(24);
  #line 24 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return this->c->rows();
}

#line 27 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::Boolean birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::supportsLazy() {
  #line 27 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 27);
  #line 28 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(28);
  #line 28 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return true;
}

#line 31 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::simulate() {
  #line 31 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("simulate", "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 31);
  #line 32 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return birch::simulate_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(this->A->value(), this->_u0956->_u0957->value(), this->_u0956->_u0923->value(), this->c->value(), this->_u0956->_u0945->value(), this->_u0956->_u0947->value());
}

#line 36 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
std::optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::simulateLazy() {
  #line 36 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 36);
  #line 37 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return birch::simulate_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(this->A->get(), this->_u0956->_u0957->get(), this->_u0956->_u0923->get(), this->c->get(), this->_u0956->_u0945->get(), this->_u0956->_u0947->get());
}

#line 41 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::Real birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 41 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 41);
  #line 42 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return birch::logpdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this->A->value(), this->_u0956->_u0957->value(), this->_u0956->_u0923->value(), this->c->value(), this->_u0956->_u0945->value(), this->_u0956->_u0947->value());
}

#line 46 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::logpdfLazy(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x) {
  #line 46 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 46);
  #line 47 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return birch::logpdf_lazy_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this->A, this->_u0956->_u0957, this->_u0956->_u0923, this->c, this->_u0956->_u0945, this->_u0956->_u0947);
}

#line 51 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::update(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 51 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("update", "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 51);
  #line 52 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  std::tie(this->_u0956->_u0957, this->_u0956->_u0923, this->_u0956->_u0945, this->_u0956->_u0947) = birch::box(birch::update_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this->A->value(), this->_u0956->_u0957->value(), this->_u0956->_u0923->value(), this->c->value(), this->_u0956->_u0945->value(), this->_u0956->_u0947->value()));
}

#line 56 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::updateLazy(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x) {
  #line 56 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 56);
  #line 57 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  std::tie(this->_u0956->_u0957, this->_u0956->_u0923, this->_u0956->_u0945, this->_u0956->_u0947) = birch::update_lazy_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this->A, this->_u0956->_u0957, this->_u0956->_u0923, this->c, this->_u0956->_u0945, this->_u0956->_u0947);
}

#line 61 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::link() {
  #line 61 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("link", "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 61);
  #line 62 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  this->_u0956->setChild(this->shared_from_this_());
}

#line 65 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::unlink() {
  #line 65 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("unlink", "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 65);
  #line 66 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  this->_u0956->releaseChild(this->shared_from_this_());
}

#line 70 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::Shared<birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian> birch::LinearMultivariateNormalInverseGammaMultivariateGaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& A, const libbirch::Shared<birch::type::MultivariateNormalInverseGamma>& _u0956, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& c) {
  #line 70 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("LinearMultivariateNormalInverseGammaMultivariateGaussian", "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 70);
  #line 74 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(74);
  #line 74 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::Shared<birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian> m = libbirch::make<libbirch::Shared<birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian>>(std::in_place, A, _u0956, c);
  #line 75 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(75);
  #line 75 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  m->link();
  #line 76 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(76);
  #line 76 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return m;
}

#line 4 "src/distribution/LinearNormalInverseGammaGaussian.birch"
birch::type::LinearNormalInverseGammaGaussian::LinearNormalInverseGammaGaussian(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& a, const libbirch::Shared<birch::type::NormalInverseGamma>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& c) :
    #line 4 "src/distribution/LinearNormalInverseGammaGaussian.birch"
    base_type_(),
    #line 9 "src/distribution/LinearNormalInverseGammaGaussian.birch"
    a(std::move(a)),
    #line 14 "src/distribution/LinearNormalInverseGammaGaussian.birch"
    _u0956(std::move(_u0956)),
    #line 19 "src/distribution/LinearNormalInverseGammaGaussian.birch"
    c(std::move(c)) {
  //
}

#line 21 "src/distribution/LinearNormalInverseGammaGaussian.birch"
birch::type::Boolean birch::type::LinearNormalInverseGammaGaussian::supportsLazy() {
  #line 21 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/LinearNormalInverseGammaGaussian.birch", 21);
  #line 22 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(22);
  #line 22 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  return true;
}

#line 25 "src/distribution/LinearNormalInverseGammaGaussian.birch"
birch::type::Real birch::type::LinearNormalInverseGammaGaussian::simulate() {
  #line 25 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("simulate", "src/distribution/LinearNormalInverseGammaGaussian.birch", 25);
  #line 26 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  return birch::simulate_linear_normal_inverse_gamma_gaussian(this->a->value(), this->_u0956->_u0956->value(), 1.0 / this->_u0956->_u0955->value(), this->c->value(), this->_u0956->_u09632->_u0945->value(), this->_u0956->_u09632->_u0946->value());
}

#line 31 "src/distribution/LinearNormalInverseGammaGaussian.birch"
std::optional<birch::type::Real> birch::type::LinearNormalInverseGammaGaussian::simulateLazy() {
  #line 31 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/LinearNormalInverseGammaGaussian.birch", 31);
  #line 32 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  return birch::simulate_linear_normal_inverse_gamma_gaussian(this->a->get(), this->_u0956->_u0956->get(), 1.0 / this->_u0956->_u0955->get(), this->c->get(), this->_u0956->_u09632->_u0945->get(), this->_u0956->_u09632->_u0946->get());
}

#line 36 "src/distribution/LinearNormalInverseGammaGaussian.birch"
birch::type::Real birch::type::LinearNormalInverseGammaGaussian::logpdf(const birch::type::Real& x) {
  #line 36 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/LinearNormalInverseGammaGaussian.birch", 36);
  #line 37 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  return birch::logpdf_linear_normal_inverse_gamma_gaussian(x, this->a->value(), this->_u0956->_u0956->value(), 1.0 / this->_u0956->_u0955->value(), this->c->value(), this->_u0956->_u09632->_u0945->value(), this->_u0956->_u09632->_u0946->value());
}

#line 42 "src/distribution/LinearNormalInverseGammaGaussian.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::LinearNormalInverseGammaGaussian::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 42 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/LinearNormalInverseGammaGaussian.birch", 42);
  #line 43 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  return birch::logpdf_lazy_linear_normal_inverse_gamma_gaussian(x, this->a, this->_u0956->_u0956, 1.0 / this->_u0956->_u0955, this->c, this->_u0956->_u09632->_u0945, this->_u0956->_u09632->_u0946);
}

#line 47 "src/distribution/LinearNormalInverseGammaGaussian.birch"
void birch::type::LinearNormalInverseGammaGaussian::update(const birch::type::Real& x) {
  #line 47 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("update", "src/distribution/LinearNormalInverseGammaGaussian.birch", 47);
  #line 48 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  std::tie(this->_u0956->_u0956, this->_u0956->_u0955, this->_u0956->_u09632->_u0945, this->_u0956->_u09632->_u0946) = birch::box(birch::update_linear_normal_inverse_gamma_gaussian(x, this->a->value(), this->_u0956->_u0956->value(), this->_u0956->_u0955->value(), this->c->value(), this->_u0956->_u09632->_u0945->value(), this->_u0956->_u09632->_u0946->value()));
}

#line 53 "src/distribution/LinearNormalInverseGammaGaussian.birch"
void birch::type::LinearNormalInverseGammaGaussian::updateLazy(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 53 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/LinearNormalInverseGammaGaussian.birch", 53);
  #line 54 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  std::tie(this->_u0956->_u0956, this->_u0956->_u0955, this->_u0956->_u09632->_u0945, this->_u0956->_u09632->_u0946) = birch::update_lazy_linear_normal_inverse_gamma_gaussian(x, this->a, this->_u0956->_u0956, this->_u0956->_u0955, this->c, this->_u0956->_u09632->_u0945, this->_u0956->_u09632->_u0946);
}

#line 58 "src/distribution/LinearNormalInverseGammaGaussian.birch"
std::optional<birch::type::Real> birch::type::LinearNormalInverseGammaGaussian::cdf(const birch::type::Real& x) {
  #line 58 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("cdf", "src/distribution/LinearNormalInverseGammaGaussian.birch", 58);
  #line 59 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(59);
  #line 59 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  return birch::cdf_linear_normal_inverse_gamma_gaussian(x, this->a->value(), this->_u0956->_u0956->value(), 1.0 / this->_u0956->_u0955->value(), this->c->value(), this->_u0956->_u09632->_u0945->value(), this->_u0956->_u09632->_u0946->value());
}

#line 64 "src/distribution/LinearNormalInverseGammaGaussian.birch"
std::optional<birch::type::Real> birch::type::LinearNormalInverseGammaGaussian::quantile(const birch::type::Real& P) {
  #line 64 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("quantile", "src/distribution/LinearNormalInverseGammaGaussian.birch", 64);
  #line 65 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  return birch::quantile_linear_normal_inverse_gamma_gaussian(P, this->a->value(), this->_u0956->_u0956->value(), 1.0 / this->_u0956->_u0955->value(), this->c->value(), this->_u0956->_u09632->_u0945->value(), this->_u0956->_u09632->_u0946->value());
}

#line 70 "src/distribution/LinearNormalInverseGammaGaussian.birch"
void birch::type::LinearNormalInverseGammaGaussian::link() {
  #line 70 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("link", "src/distribution/LinearNormalInverseGammaGaussian.birch", 70);
  #line 71 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(71);
  #line 71 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  this->_u0956->setChild(this->shared_from_this_());
}

#line 74 "src/distribution/LinearNormalInverseGammaGaussian.birch"
void birch::type::LinearNormalInverseGammaGaussian::unlink() {
  #line 74 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("unlink", "src/distribution/LinearNormalInverseGammaGaussian.birch", 74);
  #line 75 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(75);
  #line 75 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  this->_u0956->releaseChild(this->shared_from_this_());
}

#line 79 "src/distribution/LinearNormalInverseGammaGaussian.birch"
libbirch::Shared<birch::type::LinearNormalInverseGammaGaussian> birch::LinearNormalInverseGammaGaussian(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& a, const libbirch::Shared<birch::type::NormalInverseGamma>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& c) {
  #line 79 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("LinearNormalInverseGammaGaussian", "src/distribution/LinearNormalInverseGammaGaussian.birch", 79);
  #line 82 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(82);
  #line 82 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch::Shared<birch::type::LinearNormalInverseGammaGaussian> m = libbirch::make<libbirch::Shared<birch::type::LinearNormalInverseGammaGaussian>>(std::in_place, a, _u0956, c);
  #line 83 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(83);
  #line 83 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  m->link();
  #line 84 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(84);
  #line 84 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  return m;
}

#line 1 "src/distribution/MatrixGaussian.birch"
birch::type::MatrixGaussian::MatrixGaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& U, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& V) :
    #line 1 "src/distribution/MatrixGaussian.birch"
    base_type_(),
    #line 13 "src/distribution/MatrixGaussian.birch"
    M(std::move(M)),
    #line 18 "src/distribution/MatrixGaussian.birch"
    U(std::move(U)),
    #line 23 "src/distribution/MatrixGaussian.birch"
    V(std::move(V)) {
  //
}

#line 25 "src/distribution/MatrixGaussian.birch"
birch::type::Integer birch::type::MatrixGaussian::rows() {
  #line 25 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("rows", "src/distribution/MatrixGaussian.birch", 25);
  #line 26 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/distribution/MatrixGaussian.birch"
  return this->M->rows();
}

#line 29 "src/distribution/MatrixGaussian.birch"
birch::type::Integer birch::type::MatrixGaussian::columns() {
  #line 29 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("columns", "src/distribution/MatrixGaussian.birch", 29);
  #line 30 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/distribution/MatrixGaussian.birch"
  return this->M->columns();
}

#line 33 "src/distribution/MatrixGaussian.birch"
birch::type::Boolean birch::type::MatrixGaussian::supportsLazy() {
  #line 33 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/MatrixGaussian.birch", 33);
  #line 34 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/distribution/MatrixGaussian.birch"
  return true;
}

#line 37 "src/distribution/MatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixGaussian::simulate() {
  #line 37 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("simulate", "src/distribution/MatrixGaussian.birch", 37);
  #line 38 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/distribution/MatrixGaussian.birch"
  return birch::simulate_matrix_gaussian(this->M->value(), this->U->value(), this->V->value());
}

#line 41 "src/distribution/MatrixGaussian.birch"
std::optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::MatrixGaussian::simulateLazy() {
  #line 41 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/MatrixGaussian.birch", 41);
  #line 42 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/MatrixGaussian.birch"
  return birch::simulate_matrix_gaussian(this->M->get(), this->U->get(), this->V->get());
}

#line 45 "src/distribution/MatrixGaussian.birch"
birch::type::Real birch::type::MatrixGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 45 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/MatrixGaussian.birch", 45);
  #line 46 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/MatrixGaussian.birch"
  return birch::logpdf_matrix_gaussian(X, this->M->value(), this->U->value(), this->V->value());
}

#line 49 "src/distribution/MatrixGaussian.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::MatrixGaussian::logpdfLazy(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& X) {
  #line 49 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/MatrixGaussian.birch", 49);
  #line 50 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/MatrixGaussian.birch"
  return birch::logpdf_lazy_matrix_gaussian(X, this->M, this->U, this->V);
}

#line 53 "src/distribution/MatrixGaussian.birch"
std::optional<libbirch::Shared<birch::type::MatrixGaussian>> birch::type::MatrixGaussian::graftMatrixGaussian() {
  #line 53 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("graftMatrixGaussian", "src/distribution/MatrixGaussian.birch", 53);
  #line 54 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/MatrixGaussian.birch"
  this->prune();
  #line 55 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/MatrixGaussian.birch"
  return this->shared_from_this_();
}

#line 58 "src/distribution/MatrixGaussian.birch"
void birch::type::MatrixGaussian::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 58 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("write", "src/distribution/MatrixGaussian.birch", 58);
  #line 59 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(59);
  #line 59 "src/distribution/MatrixGaussian.birch"
  this->prune();
  #line 60 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/MatrixGaussian.birch"
  buffer->set(birch::type::String("class"), birch::type::String("MatrixGaussian"));
  #line 61 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/MatrixGaussian.birch"
  buffer->set(birch::type::String("M"), this->M);
  #line 62 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/MatrixGaussian.birch"
  buffer->set(birch::type::String("U"), this->U);
  #line 63 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(63);
  #line 63 "src/distribution/MatrixGaussian.birch"
  buffer->set(birch::type::String("V"), this->V);
}

#line 70 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& U, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& V) {
  #line 70 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 70);
  #line 72 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(72);
  #line 72 "src/distribution/MatrixGaussian.birch"
  std::optional<libbirch::Shared<birch::type::InverseWishart>> s1 = libbirch::make<std::optional<libbirch::Shared<birch::type::InverseWishart>>>();
  #line 73 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(73);
  #line 73 "src/distribution/MatrixGaussian.birch"
  if ((s1 = V->graftInverseWishart()).has_value()) {
    #line 74 "src/distribution/MatrixGaussian.birch"
    libbirch_line_(74);
    #line 74 "src/distribution/MatrixGaussian.birch"
    return birch::MatrixNormalInverseWishart(M, U, s1.value());
  } else {
    #line 76 "src/distribution/MatrixGaussian.birch"
    libbirch_line_(76);
    #line 76 "src/distribution/MatrixGaussian.birch"
    return birch::construct<libbirch::Shared<birch::type::MatrixGaussian>>(M, U, V);
  }
}

#line 83 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& U, const birch::type::LLT& V) {
  #line 83 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 83);
  #line 85 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(85);
  #line 85 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::box(V));
}

#line 91 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const birch::type::LLT& U, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& V) {
  #line 91 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 91);
  #line 93 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(93);
  #line 93 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::box(U), V);
}

#line 99 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const birch::type::LLT& U, const birch::type::LLT& V) {
  #line 99 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 99);
  #line 101 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(101);
  #line 101 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::box(U), birch::box(V));
}

#line 107 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& U, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& V) {
  #line 107 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 107);
  #line 109 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(109);
  #line 109 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(birch::box(M), U, V);
}

#line 115 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& U, const birch::type::LLT& V) {
  #line 115 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 115);
  #line 117 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(117);
  #line 117 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(birch::box(M), U, birch::box(V));
}

#line 123 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& V) {
  #line 123 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 123);
  #line 125 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(125);
  #line 125 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(birch::box(M), birch::box(U), V);
}

#line 131 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const birch::type::LLT& V) {
  #line 131 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 131);
  #line 132 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(132);
  #line 132 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(birch::box(M), birch::box(U), birch::box(V));
}

#line 138 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& U, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& V) {
  #line 138 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 138);
  #line 140 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(140);
  #line 140 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U), V);
}

#line 146 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& U, const birch::type::LLT& V) {
  #line 146 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 146);
  #line 148 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(148);
  #line 148 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U), V);
}

#line 154 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& V) {
  #line 154 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 154);
  #line 156 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(156);
  #line 156 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U), V);
}

#line 162 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const birch::type::LLT& V) {
  #line 162 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 162);
  #line 164 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(164);
  #line 164 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U), V);
}

#line 170 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& U, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& V) {
  #line 170 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 170);
  #line 172 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(172);
  #line 172 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U), V);
}

#line 178 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& U, const birch::type::LLT& V) {
  #line 178 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 178);
  #line 180 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(180);
  #line 180 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U), V);
}

#line 186 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& V) {
  #line 186 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 186);
  #line 188 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(188);
  #line 188 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U), V);
}

#line 194 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const birch::type::LLT& V) {
  #line 194 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 194);
  #line 195 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(195);
  #line 195 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U), V);
}

#line 201 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& U, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& V) {
  #line 201 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 201);
  #line 203 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(203);
  #line 203 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::llt(V));
}

#line 209 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& U, const libbirch::DefaultArray<birch::type::Real,2>& V) {
  #line 209 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 209);
  #line 211 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(211);
  #line 211 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::llt(V));
}

#line 217 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const birch::type::LLT& U, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& V) {
  #line 217 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 217);
  #line 219 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(219);
  #line 219 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::llt(V));
}

#line 225 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const birch::type::LLT& U, const libbirch::DefaultArray<birch::type::Real,2>& V) {
  #line 225 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 225);
  #line 227 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(227);
  #line 227 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::llt(V));
}

#line 233 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& U, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& V) {
  #line 233 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 233);
  #line 235 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(235);
  #line 235 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::llt(V));
}

#line 241 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& U, const libbirch::DefaultArray<birch::type::Real,2>& V) {
  #line 241 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 241);
  #line 243 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(243);
  #line 243 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::llt(V));
}

#line 249 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& V) {
  #line 249 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 249);
  #line 251 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(251);
  #line 251 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::llt(V));
}

#line 257 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const libbirch::DefaultArray<birch::type::Real,2>& V) {
  #line 257 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 257);
  #line 259 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(259);
  #line 259 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::llt(V));
}

#line 265 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& U, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& V) {
  #line 265 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 265);
  #line 267 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(267);
  #line 267 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U), birch::llt(V));
}

#line 273 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& U, const libbirch::DefaultArray<birch::type::Real,2>& V) {
  #line 273 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 273);
  #line 275 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(275);
  #line 275 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U), birch::llt(V));
}

#line 281 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& V) {
  #line 281 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 281);
  #line 283 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(283);
  #line 283 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U), birch::llt(V));
}

#line 289 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::DefaultArray<birch::type::Real,2>& V) {
  #line 289 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 289);
  #line 291 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(291);
  #line 291 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U), birch::llt(V));
}

#line 297 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& U, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& V) {
  #line 297 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 297);
  #line 299 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(299);
  #line 299 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U), birch::llt(V));
}

#line 305 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& U, const libbirch::DefaultArray<birch::type::Real,2>& V) {
  #line 305 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 305);
  #line 307 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(307);
  #line 307 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U), birch::llt(V));
}

#line 313 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& V) {
  #line 313 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 313);
  #line 315 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(315);
  #line 315 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U), birch::llt(V));
}

#line 321 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::DefaultArray<birch::type::Real,2>& V) {
  #line 321 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 321);
  #line 323 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(323);
  #line 323 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U), birch::llt(V));
}

#line 329 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& V) {
  #line 329 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 329);
  #line 331 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(331);
  #line 331 "src/distribution/MatrixGaussian.birch"
  std::optional<libbirch::Shared<birch::type::InverseWishart>> s1 = libbirch::make<std::optional<libbirch::Shared<birch::type::InverseWishart>>>();
  #line 332 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(332);
  #line 332 "src/distribution/MatrixGaussian.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>> m1 = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>>>();
  #line 333 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(333);
  #line 333 "src/distribution/MatrixGaussian.birch"
  std::optional<libbirch::Shared<birch::type::MatrixNormalInverseWishart>> m2 = libbirch::make<std::optional<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>();
  #line 334 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(334);
  #line 334 "src/distribution/MatrixGaussian.birch"
  auto compare = V->distribution();
  #line 335 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(335);
  #line 335 "src/distribution/MatrixGaussian.birch"
  if (compare.has_value() && (m1 = M->graftLinearMatrixNormalInverseWishart(compare.value())).has_value()) {
    #line 336 "src/distribution/MatrixGaussian.birch"
    libbirch_line_(336);
    #line 336 "src/distribution/MatrixGaussian.birch"
    return birch::LinearMatrixNormalInverseWishartMatrixGaussian(m1.value()->A, m1.value()->X, m1.value()->C);
  } else {
    #line 337 "src/distribution/MatrixGaussian.birch"
    libbirch_line_(337);
    #line 337 "src/distribution/MatrixGaussian.birch"
    if (compare.has_value() && (m2 = M->graftMatrixNormalInverseWishart(compare.value())).has_value()) {
      #line 338 "src/distribution/MatrixGaussian.birch"
      libbirch_line_(338);
      #line 338 "src/distribution/MatrixGaussian.birch"
      return birch::MatrixNormalInverseWishartMatrixGaussian(m2.value());
    } else {
      #line 339 "src/distribution/MatrixGaussian.birch"
      libbirch_line_(339);
      #line 339 "src/distribution/MatrixGaussian.birch"
      if ((s1 = V->graftInverseWishart()).has_value()) {
        #line 340 "src/distribution/MatrixGaussian.birch"
        libbirch_line_(340);
        #line 340 "src/distribution/MatrixGaussian.birch"
        return birch::MatrixNormalInverseWishart(M, birch::box(birch::llt(birch::identity(M->rows()))), s1.value());
      } else {
        #line 342 "src/distribution/MatrixGaussian.birch"
        libbirch_line_(342);
        #line 342 "src/distribution/MatrixGaussian.birch"
        return birch::construct<libbirch::Shared<birch::type::MatrixGaussian>>(M, birch::box(birch::llt(birch::identity(M->rows()))), V);
      }
    }
  }
}

#line 349 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const birch::type::LLT& V) {
  #line 349 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 349);
  #line 350 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(350);
  #line 350 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::box(V));
}

#line 356 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& V) {
  #line 356 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 356);
  #line 357 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(357);
  #line 357 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(birch::box(M), V);
}

#line 363 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& V) {
  #line 363 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 363);
  #line 365 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(365);
  #line 365 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(V));
}

#line 371 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const libbirch::DefaultArray<birch::type::Real,2>& V) {
  #line 371 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 371);
  #line 373 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(373);
  #line 373 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(V));
}

#line 379 "src/distribution/MatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& V) {
  #line 379 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 379);
  #line 381 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(381);
  #line 381 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(V));
}

#line 4 "src/distribution/MatrixNormalInverseWishart.birch"
birch::type::MatrixNormalInverseWishart::MatrixNormalInverseWishart(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& U, const libbirch::Shared<birch::type::InverseWishart>& V) :
    #line 4 "src/distribution/MatrixNormalInverseWishart.birch"
    base_type_(),
    #line 9 "src/distribution/MatrixNormalInverseWishart.birch"
    _u0923(birch::inv(std::move(U))),
    #line 14 "src/distribution/MatrixNormalInverseWishart.birch"
    N(birch::canonical(_u0923) * std::move(M)),
    #line 19 "src/distribution/MatrixNormalInverseWishart.birch"
    V(std::move(V)) {
  //
}

#line 21 "src/distribution/MatrixNormalInverseWishart.birch"
birch::type::Integer birch::type::MatrixNormalInverseWishart::rows() {
  #line 21 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("rows", "src/distribution/MatrixNormalInverseWishart.birch", 21);
  #line 22 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(22);
  #line 22 "src/distribution/MatrixNormalInverseWishart.birch"
  return this->N->rows();
}

#line 25 "src/distribution/MatrixNormalInverseWishart.birch"
birch::type::Integer birch::type::MatrixNormalInverseWishart::columns() {
  #line 25 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("columns", "src/distribution/MatrixNormalInverseWishart.birch", 25);
  #line 26 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(26);
  #line 26 "src/distribution/MatrixNormalInverseWishart.birch"
  return this->N->columns();
}

#line 29 "src/distribution/MatrixNormalInverseWishart.birch"
birch::type::Boolean birch::type::MatrixNormalInverseWishart::supportsLazy() {
  #line 29 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("supportsLazy", "src/distribution/MatrixNormalInverseWishart.birch", 29);
  #line 30 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(30);
  #line 30 "src/distribution/MatrixNormalInverseWishart.birch"
  return true;
}

#line 33 "src/distribution/MatrixNormalInverseWishart.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixNormalInverseWishart::simulate() {
  #line 33 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("simulate", "src/distribution/MatrixNormalInverseWishart.birch", 33);
  #line 34 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(34);
  #line 34 "src/distribution/MatrixNormalInverseWishart.birch"
  return birch::simulate_matrix_normal_inverse_wishart(this->N->value(), this->_u0923->value(), this->V->_u0936->value(), this->V->k->value());
}

#line 37 "src/distribution/MatrixNormalInverseWishart.birch"
std::optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::MatrixNormalInverseWishart::simulateLazy() {
  #line 37 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("simulateLazy", "src/distribution/MatrixNormalInverseWishart.birch", 37);
  #line 38 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(38);
  #line 38 "src/distribution/MatrixNormalInverseWishart.birch"
  return birch::simulate_matrix_normal_inverse_wishart(this->N->get(), this->_u0923->get(), this->V->_u0936->get(), this->V->k->get());
}

#line 41 "src/distribution/MatrixNormalInverseWishart.birch"
birch::type::Real birch::type::MatrixNormalInverseWishart::logpdf(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 41 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("logpdf", "src/distribution/MatrixNormalInverseWishart.birch", 41);
  #line 42 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/MatrixNormalInverseWishart.birch"
  return birch::logpdf_matrix_normal_inverse_wishart(X, this->N->value(), this->_u0923->value(), this->V->_u0936->value(), this->V->k->value());
}

#line 45 "src/distribution/MatrixNormalInverseWishart.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::MatrixNormalInverseWishart::logpdfLazy(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& X) {
  #line 45 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("logpdfLazy", "src/distribution/MatrixNormalInverseWishart.birch", 45);
  #line 46 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/MatrixNormalInverseWishart.birch"
  return birch::logpdf_lazy_matrix_normal_inverse_wishart(X, this->N, this->_u0923, this->V->_u0936, this->V->k);
}

#line 49 "src/distribution/MatrixNormalInverseWishart.birch"
void birch::type::MatrixNormalInverseWishart::update(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 49 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("update", "src/distribution/MatrixNormalInverseWishart.birch", 49);
  #line 50 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/MatrixNormalInverseWishart.birch"
  std::tie(this->V->_u0936, this->V->k) = birch::box(birch::update_matrix_normal_inverse_wishart(X, this->N->value(), this->_u0923->value(), this->V->_u0936->value(), this->V->k->value()));
}

#line 53 "src/distribution/MatrixNormalInverseWishart.birch"
void birch::type::MatrixNormalInverseWishart::updateLazy(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& X) {
  #line 53 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("updateLazy", "src/distribution/MatrixNormalInverseWishart.birch", 53);
  #line 54 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/MatrixNormalInverseWishart.birch"
  std::tie(this->V->_u0936, this->V->k) = birch::update_lazy_matrix_normal_inverse_wishart(X, this->N, this->_u0923, this->V->_u0936, this->V->k);
}

#line 57 "src/distribution/MatrixNormalInverseWishart.birch"
std::optional<libbirch::Shared<birch::type::MatrixNormalInverseWishart>> birch::type::MatrixNormalInverseWishart::graftMatrixNormalInverseWishart(const libbirch::Shared<birch::type::Distribution<birch::type::LLT>>& compare) {
  #line 57 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("graftMatrixNormalInverseWishart", "src/distribution/MatrixNormalInverseWishart.birch", 57);
  #line 59 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(59);
  #line 59 "src/distribution/MatrixNormalInverseWishart.birch"
  this->prune();
  #line 60 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/MatrixNormalInverseWishart.birch"
  if (this->V == compare) {
    #line 61 "src/distribution/MatrixNormalInverseWishart.birch"
    libbirch_line_(61);
    #line 61 "src/distribution/MatrixNormalInverseWishart.birch"
    return this->shared_from_this_();
  } else {
    #line 63 "src/distribution/MatrixNormalInverseWishart.birch"
    libbirch_line_(63);
    #line 63 "src/distribution/MatrixNormalInverseWishart.birch"
    return std::nullopt;
  }
}

#line 67 "src/distribution/MatrixNormalInverseWishart.birch"
void birch::type::MatrixNormalInverseWishart::link() {
  #line 67 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("link", "src/distribution/MatrixNormalInverseWishart.birch", 67);
  #line 68 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(68);
  #line 68 "src/distribution/MatrixNormalInverseWishart.birch"
  this->V->setChild(this->shared_from_this_());
}

#line 71 "src/distribution/MatrixNormalInverseWishart.birch"
void birch::type::MatrixNormalInverseWishart::unlink() {
  #line 71 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("unlink", "src/distribution/MatrixNormalInverseWishart.birch", 71);
  #line 72 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(72);
  #line 72 "src/distribution/MatrixNormalInverseWishart.birch"
  this->V->releaseChild(this->shared_from_this_());
}

#line 75 "src/distribution/MatrixNormalInverseWishart.birch"
void birch::type::MatrixNormalInverseWishart::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 75 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("write", "src/distribution/MatrixNormalInverseWishart.birch", 75);
  #line 76 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(76);
  #line 76 "src/distribution/MatrixNormalInverseWishart.birch"
  this->prune();
  #line 77 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/MatrixNormalInverseWishart.birch"
  buffer->set(birch::type::String("class"), birch::type::String("MatrixNormalInverseWishart"));
  #line 78 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(78);
  #line 78 "src/distribution/MatrixNormalInverseWishart.birch"
  buffer->set(birch::type::String("M"), birch::solve(this->_u0923->value(), this->N->value()));
  #line 79 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(79);
  #line 79 "src/distribution/MatrixNormalInverseWishart.birch"
  buffer->set(birch::type::String("Σ"), birch::inv(this->_u0923->value()));
  #line 80 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(80);
  #line 80 "src/distribution/MatrixNormalInverseWishart.birch"
  buffer->set(birch::type::String("Ψ"), this->V->_u0936->value());
  #line 81 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(81);
  #line 81 "src/distribution/MatrixNormalInverseWishart.birch"
  buffer->set(birch::type::String("k"), this->V->k->value());
}

#line 85 "src/distribution/MatrixNormalInverseWishart.birch"
libbirch::Shared<birch::type::MatrixNormalInverseWishart> birch::MatrixNormalInverseWishart(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& M, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& U, const libbirch::Shared<birch::type::InverseWishart>& V) {
  #line 85 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("MatrixNormalInverseWishart", "src/distribution/MatrixNormalInverseWishart.birch", 85);
  #line 87 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(87);
  #line 87 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch::Shared<birch::type::MatrixNormalInverseWishart> m = libbirch::make<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>(std::in_place, M, U, V);
  #line 88 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(88);
  #line 88 "src/distribution/MatrixNormalInverseWishart.birch"
  m->link();
  #line 89 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(89);
  #line 89 "src/distribution/MatrixNormalInverseWishart.birch"
  return m;
}

#line 4 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::MatrixNormalInverseWishartMatrixGaussian::MatrixNormalInverseWishartMatrixGaussian(const libbirch::Shared<birch::type::MatrixNormalInverseWishart>& M) :
    #line 4 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
    base_type_(),
    #line 9 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
    M(std::move(M)) {
  //
}

#line 11 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Integer birch::type::MatrixNormalInverseWishartMatrixGaussian::rows() {
  #line 11 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("rows", "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 11);
  #line 12 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(12);
  #line 12 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  return this->M->rows();
}

#line 15 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Integer birch::type::MatrixNormalInverseWishartMatrixGaussian::columns() {
  #line 15 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("columns", "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 15);
  #line 16 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  return this->M->columns();
}

#line 19 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Boolean birch::type::MatrixNormalInverseWishartMatrixGaussian::supportsLazy() {
  #line 19 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 19);
  #line 20 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(20);
  #line 20 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  return true;
}

#line 23 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixNormalInverseWishartMatrixGaussian::simulate() {
  #line 23 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("simulate", "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 23);
  #line 24 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(24);
  #line 24 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  return birch::simulate_matrix_normal_inverse_wishart_matrix_gaussian(this->M->N->value(), this->M->_u0923->value(), this->M->V->_u0936->value(), this->M->V->k->value());
}

#line 28 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
std::optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::MatrixNormalInverseWishartMatrixGaussian::simulateLazy() {
  #line 28 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 28);
  #line 29 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  return birch::simulate_matrix_normal_inverse_wishart_matrix_gaussian(this->M->N->get(), this->M->_u0923->get(), this->M->V->_u0936->get(), this->M->V->k->get());
}

#line 33 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Real birch::type::MatrixNormalInverseWishartMatrixGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 33 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 33);
  #line 34 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  return birch::logpdf_matrix_normal_inverse_wishart_matrix_gaussian(X, this->M->N->value(), this->M->_u0923->value(), this->M->V->_u0936->value(), this->M->V->k->value());
}

#line 38 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::MatrixNormalInverseWishartMatrixGaussian::logpdfLazy(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& X) {
  #line 38 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 38);
  #line 39 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  return birch::logpdf_lazy_matrix_normal_inverse_wishart_matrix_gaussian(X, this->M->N, this->M->_u0923, this->M->V->_u0936, this->M->V->k);
}

#line 43 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::MatrixNormalInverseWishartMatrixGaussian::update(const libbirch::DefaultArray<birch::type::Real,2>& X) {
  #line 43 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("update", "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 43);
  #line 44 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(44);
  #line 44 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  std::tie(this->M->N, this->M->_u0923, this->M->V->_u0936, this->M->V->k) = birch::box(birch::update_matrix_normal_inverse_wishart_matrix_gaussian(X, this->M->N->value(), this->M->_u0923->value(), this->M->V->_u0936->value(), this->M->V->k->value()));
}

#line 48 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::MatrixNormalInverseWishartMatrixGaussian::updateLazy(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& X) {
  #line 48 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 48);
  #line 49 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  std::tie(this->M->N, this->M->_u0923, this->M->V->_u0936, this->M->V->k) = birch::update_lazy_matrix_normal_inverse_wishart_matrix_gaussian(X, this->M->N, this->M->_u0923, this->M->V->_u0936, this->M->V->k);
}

#line 53 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::MatrixNormalInverseWishartMatrixGaussian::link() {
  #line 53 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("link", "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 53);
  #line 54 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  this->M->setChild(this->shared_from_this_());
}

#line 57 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::MatrixNormalInverseWishartMatrixGaussian::unlink() {
  #line 57 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("unlink", "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 57);
  #line 58 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(58);
  #line 58 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  this->M->releaseChild(this->shared_from_this_());
}

#line 62 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::Shared<birch::type::MatrixNormalInverseWishartMatrixGaussian> birch::MatrixNormalInverseWishartMatrixGaussian(const libbirch::Shared<birch::type::MatrixNormalInverseWishart>& M) {
  #line 62 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("MatrixNormalInverseWishartMatrixGaussian", "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 62);
  #line 65 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::Shared<birch::type::MatrixNormalInverseWishartMatrixGaussian> m = libbirch::make<libbirch::Shared<birch::type::MatrixNormalInverseWishartMatrixGaussian>>(std::in_place, M);
  #line 66 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  m->link();
  #line 67 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  return m;
}

#line 4 "src/distribution/Multinomial.birch"
birch::type::Multinomial::Multinomial(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& n, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0961) :
    #line 4 "src/distribution/Multinomial.birch"
    base_type_(),
    #line 9 "src/distribution/Multinomial.birch"
    n(std::move(n)),
    #line 14 "src/distribution/Multinomial.birch"
    _u0961(std::move(_u0961)) {
  //
}

#line 16 "src/distribution/Multinomial.birch"
birch::type::Integer birch::type::Multinomial::rows() {
  #line 16 "src/distribution/Multinomial.birch"
  libbirch_function_("rows", "src/distribution/Multinomial.birch", 16);
  #line 17 "src/distribution/Multinomial.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/Multinomial.birch"
  return this->_u0961->rows();
}

#line 20 "src/distribution/Multinomial.birch"
birch::type::Boolean birch::type::Multinomial::supportsLazy() {
  #line 20 "src/distribution/Multinomial.birch"
  libbirch_function_("supportsLazy", "src/distribution/Multinomial.birch", 20);
  #line 21 "src/distribution/Multinomial.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/Multinomial.birch"
  return false;
}

#line 24 "src/distribution/Multinomial.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::type::Multinomial::simulate() {
  #line 24 "src/distribution/Multinomial.birch"
  libbirch_function_("simulate", "src/distribution/Multinomial.birch", 24);
  #line 25 "src/distribution/Multinomial.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/Multinomial.birch"
  return birch::simulate_multinomial(this->n->value(), this->_u0961->value());
}

#line 32 "src/distribution/Multinomial.birch"
birch::type::Real birch::type::Multinomial::logpdf(const libbirch::DefaultArray<birch::type::Integer,1>& x) {
  #line 32 "src/distribution/Multinomial.birch"
  libbirch_function_("logpdf", "src/distribution/Multinomial.birch", 32);
  #line 33 "src/distribution/Multinomial.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/Multinomial.birch"
  return birch::logpdf_multinomial(x, this->n->value(), this->_u0961->value());
}

#line 40 "src/distribution/Multinomial.birch"
void birch::type::Multinomial::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 40 "src/distribution/Multinomial.birch"
  libbirch_function_("write", "src/distribution/Multinomial.birch", 40);
  #line 41 "src/distribution/Multinomial.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/Multinomial.birch"
  this->prune();
  #line 42 "src/distribution/Multinomial.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/Multinomial.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Multinomial"));
  #line 43 "src/distribution/Multinomial.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/Multinomial.birch"
  buffer->set(birch::type::String("n"), this->n);
  #line 44 "src/distribution/Multinomial.birch"
  libbirch_line_(44);
  #line 44 "src/distribution/Multinomial.birch"
  buffer->set(birch::type::String("ρ"), this->_u0961);
}

#line 51 "src/distribution/Multinomial.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Integer,1>>> birch::Multinomial(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& n, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0961) {
  #line 51 "src/distribution/Multinomial.birch"
  libbirch_function_("Multinomial", "src/distribution/Multinomial.birch", 51);
  #line 53 "src/distribution/Multinomial.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/Multinomial.birch"
  std::optional<libbirch::Shared<birch::type::Dirichlet>> m = libbirch::make<std::optional<libbirch::Shared<birch::type::Dirichlet>>>();
  #line 54 "src/distribution/Multinomial.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/Multinomial.birch"
  if ((m = _u0961->graftDirichlet()).has_value()) {
    #line 55 "src/distribution/Multinomial.birch"
    libbirch_line_(55);
    #line 55 "src/distribution/Multinomial.birch"
    return birch::DirichletMultinomial(n, m.value());
  } else {
    #line 57 "src/distribution/Multinomial.birch"
    libbirch_line_(57);
    #line 57 "src/distribution/Multinomial.birch"
    return birch::construct<libbirch::Shared<birch::type::Multinomial>>(n, _u0961);
  }
}

#line 64 "src/distribution/Multinomial.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Integer,1>>> birch::Multinomial(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& n, const libbirch::DefaultArray<birch::type::Real,1>& _u0961) {
  #line 64 "src/distribution/Multinomial.birch"
  libbirch_function_("Multinomial", "src/distribution/Multinomial.birch", 64);
  #line 66 "src/distribution/Multinomial.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/Multinomial.birch"
  return birch::Multinomial(n, birch::box(_u0961));
}

#line 72 "src/distribution/Multinomial.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Integer,1>>> birch::Multinomial(const birch::type::Integer& n, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0961) {
  #line 72 "src/distribution/Multinomial.birch"
  libbirch_function_("Multinomial", "src/distribution/Multinomial.birch", 72);
  #line 74 "src/distribution/Multinomial.birch"
  libbirch_line_(74);
  #line 74 "src/distribution/Multinomial.birch"
  return birch::Multinomial(birch::box(n), _u0961);
}

#line 80 "src/distribution/Multinomial.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Integer,1>>> birch::Multinomial(const birch::type::Integer& n, const libbirch::DefaultArray<birch::type::Real,1>& _u0961) {
  #line 80 "src/distribution/Multinomial.birch"
  libbirch_function_("Multinomial", "src/distribution/Multinomial.birch", 80);
  #line 81 "src/distribution/Multinomial.birch"
  libbirch_line_(81);
  #line 81 "src/distribution/Multinomial.birch"
  return birch::Multinomial(birch::box(n), birch::box(_u0961));
}

#line 1 "src/distribution/MultivariateGaussian.birch"
birch::type::MultivariateGaussian::MultivariateGaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& _u0931) :
    #line 1 "src/distribution/MultivariateGaussian.birch"
    base_type_(),
    #line 13 "src/distribution/MultivariateGaussian.birch"
    _u0956(std::move(_u0956)),
    #line 18 "src/distribution/MultivariateGaussian.birch"
    _u0931(std::move(_u0931)) {
  //
}

#line 20 "src/distribution/MultivariateGaussian.birch"
birch::type::Integer birch::type::MultivariateGaussian::rows() {
  #line 20 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("rows", "src/distribution/MultivariateGaussian.birch", 20);
  #line 21 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/MultivariateGaussian.birch"
  return this->_u0956->rows();
}

#line 24 "src/distribution/MultivariateGaussian.birch"
birch::type::Boolean birch::type::MultivariateGaussian::supportsLazy() {
  #line 24 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/MultivariateGaussian.birch", 24);
  #line 25 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/MultivariateGaussian.birch"
  return true;
}

#line 28 "src/distribution/MultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateGaussian::simulate() {
  #line 28 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("simulate", "src/distribution/MultivariateGaussian.birch", 28);
  #line 29 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/MultivariateGaussian.birch"
  return birch::simulate_multivariate_gaussian(this->_u0956->value(), this->_u0931->value());
}

#line 32 "src/distribution/MultivariateGaussian.birch"
std::optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::MultivariateGaussian::simulateLazy() {
  #line 32 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/MultivariateGaussian.birch", 32);
  #line 33 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/MultivariateGaussian.birch"
  return birch::simulate_multivariate_gaussian(this->_u0956->get(), this->_u0931->get());
}

#line 36 "src/distribution/MultivariateGaussian.birch"
birch::type::Real birch::type::MultivariateGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 36 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/MultivariateGaussian.birch", 36);
  #line 37 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/MultivariateGaussian.birch"
  return birch::logpdf_multivariate_gaussian(x, this->_u0956->value(), this->_u0931->value());
}

#line 40 "src/distribution/MultivariateGaussian.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::MultivariateGaussian::logpdfLazy(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x) {
  #line 40 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/MultivariateGaussian.birch", 40);
  #line 41 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/MultivariateGaussian.birch"
  return birch::logpdf_lazy_multivariate_gaussian(x, this->_u0956, this->_u0931);
}

#line 44 "src/distribution/MultivariateGaussian.birch"
std::optional<libbirch::Shared<birch::type::MultivariateGaussian>> birch::type::MultivariateGaussian::graftMultivariateGaussian() {
  #line 44 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("graftMultivariateGaussian", "src/distribution/MultivariateGaussian.birch", 44);
  #line 45 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/MultivariateGaussian.birch"
  this->prune();
  #line 46 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/MultivariateGaussian.birch"
  return this->shared_from_this_();
}

#line 49 "src/distribution/MultivariateGaussian.birch"
void birch::type::MultivariateGaussian::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 49 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("write", "src/distribution/MultivariateGaussian.birch", 49);
  #line 50 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/MultivariateGaussian.birch"
  this->prune();
  #line 51 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/MultivariateGaussian.birch"
  buffer->set(birch::type::String("class"), birch::type::String("MultivariateGaussian"));
  #line 52 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/MultivariateGaussian.birch"
  buffer->set(birch::type::String("μ"), this->_u0956);
  #line 53 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/MultivariateGaussian.birch"
  buffer->set(birch::type::String("Σ"), this->_u0931);
}

#line 60 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& _u0931) {
  #line 60 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 60);
  #line 62 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/MultivariateGaussian.birch"
  std::optional<libbirch::Shared<birch::type::InverseWishart>> s1 = libbirch::make<std::optional<libbirch::Shared<birch::type::InverseWishart>>>();
  #line 63 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(63);
  #line 63 "src/distribution/MultivariateGaussian.birch"
  std::optional<libbirch::Shared<birch::type::TransformDotMultivariate<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>> m1 = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformDotMultivariate<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>>>();
  #line 64 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(64);
  #line 64 "src/distribution/MultivariateGaussian.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>>> m2 = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>>>>();
  #line 65 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/MultivariateGaussian.birch"
  std::optional<libbirch::Shared<birch::type::MultivariateGaussian>> m3 = libbirch::make<std::optional<libbirch::Shared<birch::type::MultivariateGaussian>>>();
  #line 66 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/MultivariateGaussian.birch"
  auto compare = _u0931->distribution();
  #line 67 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/MultivariateGaussian.birch"
  if (compare.has_value() && (m1 = _u0956->graftDotMatrixNormalInverseWishart(compare.value())).has_value()) {
    #line 68 "src/distribution/MultivariateGaussian.birch"
    libbirch_line_(68);
    #line 68 "src/distribution/MultivariateGaussian.birch"
    return birch::LinearMatrixNormalInverseWishartMultivariateGaussian(m1.value()->a, m1.value()->X, m1.value()->c);
  } else {
    #line 69 "src/distribution/MultivariateGaussian.birch"
    libbirch_line_(69);
    #line 69 "src/distribution/MultivariateGaussian.birch"
    if ((m2 = _u0956->graftLinearMultivariateGaussian()).has_value()) {
      #line 70 "src/distribution/MultivariateGaussian.birch"
      libbirch_line_(70);
      #line 70 "src/distribution/MultivariateGaussian.birch"
      return birch::LinearMultivariateGaussianMultivariateGaussian(m2.value()->A, m2.value()->x, m2.value()->c, _u0931);
    } else {
      #line 71 "src/distribution/MultivariateGaussian.birch"
      libbirch_line_(71);
      #line 71 "src/distribution/MultivariateGaussian.birch"
      if ((m3 = _u0956->graftMultivariateGaussian()).has_value()) {
        #line 72 "src/distribution/MultivariateGaussian.birch"
        libbirch_line_(72);
        #line 72 "src/distribution/MultivariateGaussian.birch"
        return birch::MultivariateGaussianMultivariateGaussian(m3.value(), _u0931);
      } else {
        #line 74 "src/distribution/MultivariateGaussian.birch"
        libbirch_line_(74);
        #line 74 "src/distribution/MultivariateGaussian.birch"
        return birch::construct<libbirch::Shared<birch::type::MultivariateGaussian>>(_u0956, _u0931);
      }
    }
  }
}

#line 81 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0956, const birch::type::LLT& _u0931) {
  #line 81 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 81);
  #line 82 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(82);
  #line 82 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::box(_u0931));
}

#line 88 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& _u0931) {
  #line 88 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 88);
  #line 89 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(89);
  #line 89 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(birch::box(_u0956), _u0931);
}

#line 95 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const birch::type::LLT& _u0931) {
  #line 95 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 95);
  #line 96 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(96);
  #line 96 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(birch::box(_u0956), birch::box(_u0931));
}

#line 102 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0956, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& _u0931) {
  #line 102 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 102);
  #line 104 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(104);
  #line 104 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931));
}

#line 110 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0956, const libbirch::DefaultArray<birch::type::Real,2>& _u0931) {
  #line 110 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 110);
  #line 112 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(112);
  #line 112 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931));
}

#line 118 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& _u0931) {
  #line 118 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 118);
  #line 120 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(120);
  #line 120 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931));
}

#line 126 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::DefaultArray<birch::type::Real,2>& _u0931) {
  #line 126 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 126);
  #line 127 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(127);
  #line 127 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931));
}

#line 134 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632) {
  #line 134 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 134);
  #line 136 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(136);
  #line 136 "src/distribution/MultivariateGaussian.birch"
  std::optional<libbirch::Shared<birch::type::InverseGamma>> s1 = libbirch::make<std::optional<libbirch::Shared<birch::type::InverseGamma>>>();
  #line 137 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(137);
  #line 137 "src/distribution/MultivariateGaussian.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>> m1 = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>();
  #line 138 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(138);
  #line 138 "src/distribution/MultivariateGaussian.birch"
  std::optional<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>> m2 = libbirch::make<std::optional<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>();
  #line 139 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(139);
  #line 139 "src/distribution/MultivariateGaussian.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>>> m3 = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Shared<birch::type::MultivariateGaussian>>>>>();
  #line 140 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(140);
  #line 140 "src/distribution/MultivariateGaussian.birch"
  std::optional<libbirch::Shared<birch::type::MultivariateGaussian>> m4 = libbirch::make<std::optional<libbirch::Shared<birch::type::MultivariateGaussian>>>();
  #line 141 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(141);
  #line 141 "src/distribution/MultivariateGaussian.birch"
  auto compare = _u09632->distribution();
  #line 142 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(142);
  #line 142 "src/distribution/MultivariateGaussian.birch"
  if (compare.has_value() && (m1 = _u0956->graftLinearMultivariateNormalInverseGamma(compare.value())).has_value()) {
    #line 143 "src/distribution/MultivariateGaussian.birch"
    libbirch_line_(143);
    #line 143 "src/distribution/MultivariateGaussian.birch"
    return birch::LinearMultivariateNormalInverseGammaMultivariateGaussian(m1.value()->A, m1.value()->x, m1.value()->c);
  } else {
    #line 144 "src/distribution/MultivariateGaussian.birch"
    libbirch_line_(144);
    #line 144 "src/distribution/MultivariateGaussian.birch"
    if (compare.has_value() && (m2 = _u0956->graftMultivariateNormalInverseGamma(compare.value())).has_value()) {
      #line 145 "src/distribution/MultivariateGaussian.birch"
      libbirch_line_(145);
      #line 145 "src/distribution/MultivariateGaussian.birch"
      return birch::MultivariateNormalInverseGammaMultivariateGaussian(m2.value());
    } else {
      #line 146 "src/distribution/MultivariateGaussian.birch"
      libbirch_line_(146);
      #line 146 "src/distribution/MultivariateGaussian.birch"
      if ((m3 = _u0956->graftLinearMultivariateGaussian()).has_value()) {
        #line 147 "src/distribution/MultivariateGaussian.birch"
        libbirch_line_(147);
        #line 147 "src/distribution/MultivariateGaussian.birch"
        return birch::LinearMultivariateGaussianMultivariateGaussian(m3.value()->A, m3.value()->x, m3.value()->c, birch::llt(birch::diagonal(_u09632, m3.value()->rows())));
      } else {
        #line 148 "src/distribution/MultivariateGaussian.birch"
        libbirch_line_(148);
        #line 148 "src/distribution/MultivariateGaussian.birch"
        if ((m4 = _u0956->graftMultivariateGaussian()).has_value()) {
          #line 149 "src/distribution/MultivariateGaussian.birch"
          libbirch_line_(149);
          #line 149 "src/distribution/MultivariateGaussian.birch"
          return birch::MultivariateGaussianMultivariateGaussian(m4.value(), birch::llt(birch::diagonal(_u09632, m4.value()->rows())));
        } else {
          #line 150 "src/distribution/MultivariateGaussian.birch"
          libbirch_line_(150);
          #line 150 "src/distribution/MultivariateGaussian.birch"
          if ((s1 = _u09632->graftInverseGamma()).has_value()) {
            #line 151 "src/distribution/MultivariateGaussian.birch"
            libbirch_line_(151);
            #line 151 "src/distribution/MultivariateGaussian.birch"
            return birch::MultivariateNormalInverseGamma(_u0956, birch::box(birch::llt(birch::identity(_u0956->rows()))), s1.value());
          } else {
            #line 153 "src/distribution/MultivariateGaussian.birch"
            libbirch_line_(153);
            #line 153 "src/distribution/MultivariateGaussian.birch"
            return birch::construct<libbirch::Shared<birch::type::MultivariateGaussian>>(_u0956, birch::llt(birch::diagonal(_u09632, _u0956->rows())));
          }
        }
      }
    }
  }
}

#line 161 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0956, const birch::type::Real& _u09632) {
  #line 161 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 161);
  #line 162 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(162);
  #line 162 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::box(_u09632));
}

#line 169 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632) {
  #line 169 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 169);
  #line 170 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(170);
  #line 170 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(birch::box(_u0956), _u09632);
}

#line 177 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const birch::type::Real& _u09632) {
  #line 177 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 177);
  #line 178 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(178);
  #line 178 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(birch::box(_u0956), birch::box(_u09632));
}

#line 187 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& _u0931, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632) {
  #line 187 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 187);
  #line 189 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(189);
  #line 189 "src/distribution/MultivariateGaussian.birch"
  std::optional<libbirch::Shared<birch::type::InverseGamma>> s1 = libbirch::make<std::optional<libbirch::Shared<birch::type::InverseGamma>>>();
  #line 190 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(190);
  #line 190 "src/distribution/MultivariateGaussian.birch"
  if ((s1 = _u09632->graftInverseGamma()).has_value()) {
    #line 191 "src/distribution/MultivariateGaussian.birch"
    libbirch_line_(191);
    #line 191 "src/distribution/MultivariateGaussian.birch"
    return birch::MultivariateNormalInverseGamma(_u0956, _u0931, s1.value());
  } else {
    #line 193 "src/distribution/MultivariateGaussian.birch"
    libbirch_line_(193);
    #line 193 "src/distribution/MultivariateGaussian.birch"
    return birch::construct<libbirch::Shared<birch::type::MultivariateGaussian>>(_u0956, birch::llt(birch::canonical(_u0931) * _u09632));
  }
}

#line 203 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& _u0931, const birch::type::Real& _u09632) {
  #line 203 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 203);
  #line 205 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(205);
  #line 205 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, _u0931, birch::box(_u09632));
}

#line 214 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0956, const birch::type::LLT& _u0931, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632) {
  #line 214 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 214);
  #line 216 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(216);
  #line 216 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::box(_u0931), _u09632);
}

#line 225 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0956, const birch::type::LLT& _u0931, const birch::type::Real& _u09632) {
  #line 225 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 225);
  #line 227 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(227);
  #line 227 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::box(_u0931), birch::box(_u09632));
}

#line 236 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& _u0931, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632) {
  #line 236 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 236);
  #line 238 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(238);
  #line 238 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(birch::box(_u0956), _u0931, _u09632);
}

#line 247 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& _u0931, const birch::type::Real& _u09632) {
  #line 247 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 247);
  #line 249 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(249);
  #line 249 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(birch::box(_u0956), _u0931, birch::box(_u09632));
}

#line 258 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const birch::type::LLT& _u0931, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632) {
  #line 258 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 258);
  #line 260 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(260);
  #line 260 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(birch::box(_u0956), birch::box(_u0931), _u09632);
}

#line 269 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const birch::type::LLT& _u0931, const birch::type::Real& _u09632) {
  #line 269 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 269);
  #line 270 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(270);
  #line 270 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(birch::box(_u0956), birch::box(_u0931), birch::box(_u09632));
}

#line 279 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0956, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& _u0931, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632) {
  #line 279 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 279);
  #line 281 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(281);
  #line 281 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931), _u09632);
}

#line 290 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0956, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& _u0931, const birch::type::Real& _u09632) {
  #line 290 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 290);
  #line 292 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(292);
  #line 292 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931), _u09632);
}

#line 301 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0956, const libbirch::DefaultArray<birch::type::Real,2>& _u0931, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632) {
  #line 301 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 301);
  #line 303 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(303);
  #line 303 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931), _u09632);
}

#line 312 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0956, const libbirch::DefaultArray<birch::type::Real,2>& _u0931, const birch::type::Real& _u09632) {
  #line 312 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 312);
  #line 314 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(314);
  #line 314 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931), _u09632);
}

#line 323 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& _u0931, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632) {
  #line 323 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 323);
  #line 325 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(325);
  #line 325 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931), _u09632);
}

#line 334 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& _u0931, const birch::type::Real& _u09632) {
  #line 334 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 334);
  #line 336 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(336);
  #line 336 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931), _u09632);
}

#line 345 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::DefaultArray<birch::type::Real,2>& _u0931, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632) {
  #line 345 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 345);
  #line 347 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(347);
  #line 347 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931), _u09632);
}

#line 356 "src/distribution/MultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::DefaultArray<birch::type::Real,2>& _u0931, const birch::type::Real& _u09632) {
  #line 356 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 356);
  #line 357 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(357);
  #line 357 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931), _u09632);
}

#line 4 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
birch::type::MultivariateGaussianMultivariateGaussian::MultivariateGaussianMultivariateGaussian(const libbirch::Shared<birch::type::MultivariateGaussian>& m, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& S) :
    #line 4 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
    base_type_(m->_u0956, birch::llt(birch::canonical(m->_u0931) + birch::canonical(S))),
    #line 10 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
    m(m),
    #line 15 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
    S(S) {
  //
}

#line 17 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
void birch::type::MultivariateGaussianMultivariateGaussian::update(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 17 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("update", "src/distribution/MultivariateGaussianMultivariateGaussian.birch", 17);
  #line 18 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(18);
  #line 18 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  std::tie(this->m->_u0956, this->m->_u0931) = birch::box(birch::update_multivariate_gaussian_multivariate_gaussian(x, this->m->_u0956->value(), this->m->_u0931->value(), this->S->value()));
}

#line 21 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
void birch::type::MultivariateGaussianMultivariateGaussian::updateLazy(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x) {
  #line 21 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/MultivariateGaussianMultivariateGaussian.birch", 21);
  #line 22 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(22);
  #line 22 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  std::tie(this->m->_u0956, this->m->_u0931) = birch::update_lazy_multivariate_gaussian_multivariate_gaussian(x, this->m->_u0956, this->m->_u0931, this->S);
}

#line 25 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
void birch::type::MultivariateGaussianMultivariateGaussian::link() {
  #line 25 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("link", "src/distribution/MultivariateGaussianMultivariateGaussian.birch", 25);
  #line 26 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  this->m->setChild(this->shared_from_this_());
}

#line 29 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
void birch::type::MultivariateGaussianMultivariateGaussian::unlink() {
  #line 29 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("unlink", "src/distribution/MultivariateGaussianMultivariateGaussian.birch", 29);
  #line 30 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  this->m->releaseChild(this->shared_from_this_());
}

#line 34 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
libbirch::Shared<birch::type::MultivariateGaussianMultivariateGaussian> birch::MultivariateGaussianMultivariateGaussian(const libbirch::Shared<birch::type::MultivariateGaussian>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& _u0931) {
  #line 34 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("MultivariateGaussianMultivariateGaussian", "src/distribution/MultivariateGaussianMultivariateGaussian.birch", 34);
  #line 36 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch::Shared<birch::type::MultivariateGaussianMultivariateGaussian> m = libbirch::make<libbirch::Shared<birch::type::MultivariateGaussianMultivariateGaussian>>(std::in_place, _u0956, _u0931);
  #line 37 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  m->link();
  #line 38 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  return m;
}

#line 35 "src/distribution/MultivariateNormalInverseGamma.birch"
birch::type::MultivariateNormalInverseGamma::MultivariateNormalInverseGamma(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& _u0931, const libbirch::Shared<birch::type::InverseGamma>& _u09632) :
    #line 35 "src/distribution/MultivariateNormalInverseGamma.birch"
    base_type_(),
    #line 40 "src/distribution/MultivariateNormalInverseGamma.birch"
    _u0923(birch::inv(std::move(_u0931))),
    #line 45 "src/distribution/MultivariateNormalInverseGamma.birch"
    _u0957(birch::canonical(_u0923) * _u0956),
    #line 50 "src/distribution/MultivariateNormalInverseGamma.birch"
    _u0945(_u09632->_u0945),
    #line 55 "src/distribution/MultivariateNormalInverseGamma.birch"
    _u0947(_u09632->_u0946 + 0.5 * birch::dot(_u0956, _u0957)),
    #line 60 "src/distribution/MultivariateNormalInverseGamma.birch"
    _u09632(_u09632) {
  //
}

#line 62 "src/distribution/MultivariateNormalInverseGamma.birch"
birch::type::Integer birch::type::MultivariateNormalInverseGamma::rows() {
  #line 62 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("rows", "src/distribution/MultivariateNormalInverseGamma.birch", 62);
  #line 63 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(63);
  #line 63 "src/distribution/MultivariateNormalInverseGamma.birch"
  return this->_u0957->rows();
}

#line 66 "src/distribution/MultivariateNormalInverseGamma.birch"
birch::type::Boolean birch::type::MultivariateNormalInverseGamma::supportsLazy() {
  #line 66 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("supportsLazy", "src/distribution/MultivariateNormalInverseGamma.birch", 66);
  #line 67 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/MultivariateNormalInverseGamma.birch"
  return true;
}

#line 70 "src/distribution/MultivariateNormalInverseGamma.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateNormalInverseGamma::simulate() {
  #line 70 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("simulate", "src/distribution/MultivariateNormalInverseGamma.birch", 70);
  #line 71 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(71);
  #line 71 "src/distribution/MultivariateNormalInverseGamma.birch"
  return birch::simulate_multivariate_normal_inverse_gamma(this->_u0957->value(), this->_u0923->value(), this->_u0945->value(), birch::gamma_to_beta(this->_u0947->value(), this->_u0957->value(), this->_u0923->value()));
}

#line 75 "src/distribution/MultivariateNormalInverseGamma.birch"
std::optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::MultivariateNormalInverseGamma::simulateLazy() {
  #line 75 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("simulateLazy", "src/distribution/MultivariateNormalInverseGamma.birch", 75);
  #line 76 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(76);
  #line 76 "src/distribution/MultivariateNormalInverseGamma.birch"
  return birch::simulate_multivariate_normal_inverse_gamma(this->_u0957->get(), this->_u0923->get(), this->_u0945->get(), birch::gamma_to_beta(this->_u0947->get(), this->_u0957->get(), this->_u0923->get()));
}

#line 80 "src/distribution/MultivariateNormalInverseGamma.birch"
birch::type::Real birch::type::MultivariateNormalInverseGamma::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 80 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("logpdf", "src/distribution/MultivariateNormalInverseGamma.birch", 80);
  #line 81 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(81);
  #line 81 "src/distribution/MultivariateNormalInverseGamma.birch"
  return birch::logpdf_multivariate_normal_inverse_gamma(x, this->_u0957->value(), this->_u0923->value(), this->_u0945->value(), birch::gamma_to_beta(this->_u0947->value(), this->_u0957->value(), this->_u0923->value()));
}

#line 85 "src/distribution/MultivariateNormalInverseGamma.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::MultivariateNormalInverseGamma::logpdfLazy(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x) {
  #line 85 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("logpdfLazy", "src/distribution/MultivariateNormalInverseGamma.birch", 85);
  #line 86 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(86);
  #line 86 "src/distribution/MultivariateNormalInverseGamma.birch"
  return birch::logpdf_lazy_multivariate_normal_inverse_gamma(x, this->_u0957, this->_u0923, this->_u0945, birch::gamma_to_beta(this->_u0947, this->_u0957, this->_u0923));
}

#line 90 "src/distribution/MultivariateNormalInverseGamma.birch"
void birch::type::MultivariateNormalInverseGamma::update(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 90 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("update", "src/distribution/MultivariateNormalInverseGamma.birch", 90);
  #line 91 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(91);
  #line 91 "src/distribution/MultivariateNormalInverseGamma.birch"
  std::tie(this->_u09632->_u0945, this->_u09632->_u0946) = birch::box(birch::update_multivariate_normal_inverse_gamma(x, this->_u0957->value(), this->_u0923->value(), this->_u0945->value(), birch::gamma_to_beta(this->_u0947->value(), this->_u0957->value(), this->_u0923->value())));
}

#line 95 "src/distribution/MultivariateNormalInverseGamma.birch"
void birch::type::MultivariateNormalInverseGamma::updateLazy(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x) {
  #line 95 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("updateLazy", "src/distribution/MultivariateNormalInverseGamma.birch", 95);
  #line 96 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(96);
  #line 96 "src/distribution/MultivariateNormalInverseGamma.birch"
  std::tie(this->_u09632->_u0945, this->_u09632->_u0946) = birch::update_lazy_multivariate_normal_inverse_gamma(x, this->_u0957, this->_u0923, this->_u0945, birch::gamma_to_beta(this->_u0947, this->_u0957, this->_u0923));
}

#line 100 "src/distribution/MultivariateNormalInverseGamma.birch"
std::optional<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>> birch::type::MultivariateNormalInverseGamma::graftMultivariateNormalInverseGamma(const libbirch::Shared<birch::type::Distribution<birch::type::Real>>& compare) {
  #line 100 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("graftMultivariateNormalInverseGamma", "src/distribution/MultivariateNormalInverseGamma.birch", 100);
  #line 102 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(102);
  #line 102 "src/distribution/MultivariateNormalInverseGamma.birch"
  this->prune();
  #line 103 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(103);
  #line 103 "src/distribution/MultivariateNormalInverseGamma.birch"
  if (this->_u09632 == compare) {
    #line 104 "src/distribution/MultivariateNormalInverseGamma.birch"
    libbirch_line_(104);
    #line 104 "src/distribution/MultivariateNormalInverseGamma.birch"
    return this->shared_from_this_();
  } else {
    #line 106 "src/distribution/MultivariateNormalInverseGamma.birch"
    libbirch_line_(106);
    #line 106 "src/distribution/MultivariateNormalInverseGamma.birch"
    return std::nullopt;
  }
}

#line 110 "src/distribution/MultivariateNormalInverseGamma.birch"
void birch::type::MultivariateNormalInverseGamma::link() {
  #line 110 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("link", "src/distribution/MultivariateNormalInverseGamma.birch", 110);
  #line 111 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(111);
  #line 111 "src/distribution/MultivariateNormalInverseGamma.birch"
  this->_u09632->setChild(this->shared_from_this_());
}

#line 114 "src/distribution/MultivariateNormalInverseGamma.birch"
void birch::type::MultivariateNormalInverseGamma::unlink() {
  #line 114 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("unlink", "src/distribution/MultivariateNormalInverseGamma.birch", 114);
  #line 115 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(115);
  #line 115 "src/distribution/MultivariateNormalInverseGamma.birch"
  this->_u09632->releaseChild(this->shared_from_this_());
}

#line 118 "src/distribution/MultivariateNormalInverseGamma.birch"
void birch::type::MultivariateNormalInverseGamma::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 118 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("write", "src/distribution/MultivariateNormalInverseGamma.birch", 118);
  #line 119 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(119);
  #line 119 "src/distribution/MultivariateNormalInverseGamma.birch"
  this->prune();
  #line 120 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(120);
  #line 120 "src/distribution/MultivariateNormalInverseGamma.birch"
  buffer->set(birch::type::String("class"), birch::type::String("MultivariateNormalInverseGamma"));
  #line 121 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(121);
  #line 121 "src/distribution/MultivariateNormalInverseGamma.birch"
  buffer->set(birch::type::String("μ"), birch::solve(this->_u0923->value(), this->_u0957->value()));
  #line 122 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(122);
  #line 122 "src/distribution/MultivariateNormalInverseGamma.birch"
  buffer->set(birch::type::String("Σ"), birch::inv(this->_u0923->value()));
  #line 123 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(123);
  #line 123 "src/distribution/MultivariateNormalInverseGamma.birch"
  buffer->set(birch::type::String("α"), this->_u0945->value());
  #line 124 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(124);
  #line 124 "src/distribution/MultivariateNormalInverseGamma.birch"
  buffer->set(birch::type::String("β"), birch::gamma_to_beta(this->_u0947->value(), this->_u0957->value(), this->_u0923->value()));
}

#line 128 "src/distribution/MultivariateNormalInverseGamma.birch"
libbirch::Shared<birch::type::MultivariateNormalInverseGamma> birch::MultivariateNormalInverseGamma(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& _u0931, const libbirch::Shared<birch::type::InverseGamma>& _u09632) {
  #line 128 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("MultivariateNormalInverseGamma", "src/distribution/MultivariateNormalInverseGamma.birch", 128);
  #line 130 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(130);
  #line 130 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch::Shared<birch::type::MultivariateNormalInverseGamma> m = libbirch::make<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>(std::in_place, _u0956, _u0931, _u09632);
  #line 131 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(131);
  #line 131 "src/distribution/MultivariateNormalInverseGamma.birch"
  m->link();
  #line 132 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(132);
  #line 132 "src/distribution/MultivariateNormalInverseGamma.birch"
  return m;
}

#line 139 "src/distribution/MultivariateNormalInverseGamma.birch"
birch::type::Real birch::gamma_to_beta(const birch::type::Real& _u0947, const libbirch::DefaultArray<birch::type::Real,1>& _u0957, const birch::type::LLT& _u0923) {
  #line 139 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("gamma_to_beta", "src/distribution/MultivariateNormalInverseGamma.birch", 139);
  #line 140 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(140);
  #line 140 "src/distribution/MultivariateNormalInverseGamma.birch"
  return _u0947 - 0.5 * birch::dot(_u0957, birch::solve(_u0923, _u0957));
}

#line 147 "src/distribution/MultivariateNormalInverseGamma.birch"
libbirch::Shared<birch::type::Expression<birch::type::Real>> birch::gamma_to_beta(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0947, const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& _u0957, const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& _u0923) {
  #line 147 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("gamma_to_beta", "src/distribution/MultivariateNormalInverseGamma.birch", 147);
  #line 149 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(149);
  #line 149 "src/distribution/MultivariateNormalInverseGamma.birch"
  return _u0947 - 0.5 * birch::dot(_u0957, birch::solve(_u0923, _u0957));
}

#line 4 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::MultivariateNormalInverseGammaMultivariateGaussian::MultivariateNormalInverseGammaMultivariateGaussian(const libbirch::Shared<birch::type::MultivariateNormalInverseGamma>& _u0956) :
    #line 4 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
    base_type_(),
    #line 9 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
    _u0956(std::move(_u0956)) {
  //
}

#line 11 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::Integer birch::type::MultivariateNormalInverseGammaMultivariateGaussian::rows() {
  #line 11 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("rows", "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 11);
  #line 12 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(12);
  #line 12 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  return this->_u0956->rows();
}

#line 15 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::Boolean birch::type::MultivariateNormalInverseGammaMultivariateGaussian::supportsLazy() {
  #line 15 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 15);
  #line 16 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  return true;
}

#line 19 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateNormalInverseGammaMultivariateGaussian::simulate() {
  #line 19 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("simulate", "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 19);
  #line 20 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(20);
  #line 20 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  return birch::simulate_multivariate_normal_inverse_gamma_multivariate_gaussian(this->_u0956->_u0957->value(), this->_u0956->_u0923->value(), this->_u0956->_u0945->value(), this->_u0956->_u0947->value());
}

#line 24 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
std::optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::MultivariateNormalInverseGammaMultivariateGaussian::simulateLazy() {
  #line 24 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 24);
  #line 25 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  return birch::simulate_multivariate_normal_inverse_gamma_multivariate_gaussian(this->_u0956->_u0957->get(), this->_u0956->_u0923->get(), this->_u0956->_u0945->get(), this->_u0956->_u0947->get());
}

#line 29 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::Real birch::type::MultivariateNormalInverseGammaMultivariateGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 29 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 29);
  #line 30 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  return birch::logpdf_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this->_u0956->_u0957->value(), this->_u0956->_u0923->value(), this->_u0956->_u0945->value(), this->_u0956->_u0947->value());
}

#line 34 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::MultivariateNormalInverseGammaMultivariateGaussian::logpdfLazy(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x) {
  #line 34 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 34);
  #line 35 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  return birch::logpdf_lazy_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this->_u0956->_u0957, this->_u0956->_u0923, this->_u0956->_u0945, this->_u0956->_u0947);
}

#line 39 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::MultivariateNormalInverseGammaMultivariateGaussian::update(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 39 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("update", "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 39);
  #line 40 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  std::tie(this->_u0956->_u0957, this->_u0956->_u0923, this->_u0956->_u0945, this->_u0956->_u0947) = birch::box(birch::update_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this->_u0956->_u0957->value(), this->_u0956->_u0923->value(), this->_u0956->_u0945->value(), this->_u0956->_u0947->value()));
}

#line 44 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::MultivariateNormalInverseGammaMultivariateGaussian::updateLazy(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x) {
  #line 44 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 44);
  #line 45 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  std::tie(this->_u0956->_u0957, this->_u0956->_u0923, this->_u0956->_u0945, this->_u0956->_u0947) = birch::update_lazy_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this->_u0956->_u0957, this->_u0956->_u0923, this->_u0956->_u0945, this->_u0956->_u0947);
}

#line 49 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::MultivariateNormalInverseGammaMultivariateGaussian::link() {
  #line 49 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("link", "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 49);
  #line 50 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  this->_u0956->setChild(this->shared_from_this_());
}

#line 53 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::MultivariateNormalInverseGammaMultivariateGaussian::unlink() {
  #line 53 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("unlink", "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 53);
  #line 54 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  this->_u0956->releaseChild(this->shared_from_this_());
}

#line 58 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::Shared<birch::type::MultivariateNormalInverseGammaMultivariateGaussian> birch::MultivariateNormalInverseGammaMultivariateGaussian(const libbirch::Shared<birch::type::MultivariateNormalInverseGamma>& _u0956) {
  #line 58 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("MultivariateNormalInverseGammaMultivariateGaussian", "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 58);
  #line 61 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::Shared<birch::type::MultivariateNormalInverseGammaMultivariateGaussian> m = libbirch::make<libbirch::Shared<birch::type::MultivariateNormalInverseGammaMultivariateGaussian>>(std::in_place, _u0956);
  #line 62 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  m->link();
  #line 63 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(63);
  #line 63 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  return m;
}

#line 4 "src/distribution/NegativeBinomial.birch"
birch::type::NegativeBinomial::NegativeBinomial(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& k, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0961) :
    #line 4 "src/distribution/NegativeBinomial.birch"
    base_type_(),
    #line 9 "src/distribution/NegativeBinomial.birch"
    k(std::move(k)),
    #line 14 "src/distribution/NegativeBinomial.birch"
    _u0961(std::move(_u0961)) {
  //
}

#line 16 "src/distribution/NegativeBinomial.birch"
birch::type::Boolean birch::type::NegativeBinomial::supportsLazy() {
  #line 16 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("supportsLazy", "src/distribution/NegativeBinomial.birch", 16);
  #line 17 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/NegativeBinomial.birch"
  return true;
}

#line 20 "src/distribution/NegativeBinomial.birch"
birch::type::Integer birch::type::NegativeBinomial::simulate() {
  #line 20 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("simulate", "src/distribution/NegativeBinomial.birch", 20);
  #line 21 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/NegativeBinomial.birch"
  return birch::simulate_negative_binomial(this->k->value(), this->_u0961->value());
}

#line 24 "src/distribution/NegativeBinomial.birch"
std::optional<birch::type::Integer> birch::type::NegativeBinomial::simulateLazy() {
  #line 24 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("simulateLazy", "src/distribution/NegativeBinomial.birch", 24);
  #line 25 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/NegativeBinomial.birch"
  return birch::simulate_negative_binomial(this->k->get(), this->_u0961->get());
}

#line 28 "src/distribution/NegativeBinomial.birch"
birch::type::Real birch::type::NegativeBinomial::logpdf(const birch::type::Integer& x) {
  #line 28 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("logpdf", "src/distribution/NegativeBinomial.birch", 28);
  #line 29 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/NegativeBinomial.birch"
  return birch::logpdf_negative_binomial(x, this->k->value(), this->_u0961->value());
}

#line 32 "src/distribution/NegativeBinomial.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::NegativeBinomial::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& x) {
  #line 32 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("logpdfLazy", "src/distribution/NegativeBinomial.birch", 32);
  #line 33 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/NegativeBinomial.birch"
  return birch::logpdf_lazy_negative_binomial(x, this->k, this->_u0961);
}

#line 36 "src/distribution/NegativeBinomial.birch"
std::optional<birch::type::Real> birch::type::NegativeBinomial::cdf(const birch::type::Integer& x) {
  #line 36 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("cdf", "src/distribution/NegativeBinomial.birch", 36);
  #line 37 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/NegativeBinomial.birch"
  return birch::cdf_negative_binomial(x, this->k->value(), this->_u0961->value());
}

#line 40 "src/distribution/NegativeBinomial.birch"
std::optional<birch::type::Integer> birch::type::NegativeBinomial::quantile(const birch::type::Real& P) {
  #line 40 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("quantile", "src/distribution/NegativeBinomial.birch", 40);
  #line 41 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/NegativeBinomial.birch"
  return birch::quantile_negative_binomial(P, this->k->value(), this->_u0961->value());
}

#line 44 "src/distribution/NegativeBinomial.birch"
std::optional<birch::type::Integer> birch::type::NegativeBinomial::lower() {
  #line 44 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("lower", "src/distribution/NegativeBinomial.birch", 44);
  #line 45 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/NegativeBinomial.birch"
  return birch::type::Integer(0);
}

#line 48 "src/distribution/NegativeBinomial.birch"
void birch::type::NegativeBinomial::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 48 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("write", "src/distribution/NegativeBinomial.birch", 48);
  #line 49 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/NegativeBinomial.birch"
  this->prune();
  #line 50 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/NegativeBinomial.birch"
  buffer->set(birch::type::String("class"), birch::type::String("NegativeBinomial"));
  #line 51 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/NegativeBinomial.birch"
  buffer->set(birch::type::String("k"), this->k);
  #line 52 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/NegativeBinomial.birch"
  buffer->set(birch::type::String("ρ"), this->_u0961);
}

#line 59 "src/distribution/NegativeBinomial.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Integer>> birch::NegativeBinomial(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& k, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0961) {
  #line 59 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("NegativeBinomial", "src/distribution/NegativeBinomial.birch", 59);
  #line 61 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/NegativeBinomial.birch"
  std::optional<libbirch::Shared<birch::type::Beta>> _u09611 = libbirch::make<std::optional<libbirch::Shared<birch::type::Beta>>>();
  #line 62 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/NegativeBinomial.birch"
  if ((_u09611 = _u0961->graftBeta()).has_value()) {
    #line 63 "src/distribution/NegativeBinomial.birch"
    libbirch_line_(63);
    #line 63 "src/distribution/NegativeBinomial.birch"
    return birch::BetaNegativeBinomial(k, _u09611.value());
  } else {
    #line 65 "src/distribution/NegativeBinomial.birch"
    libbirch_line_(65);
    #line 65 "src/distribution/NegativeBinomial.birch"
    return birch::construct<libbirch::Shared<birch::type::NegativeBinomial>>(k, _u0961);
  }
}

#line 72 "src/distribution/NegativeBinomial.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Integer>> birch::NegativeBinomial(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& k, const birch::type::Real& _u0961) {
  #line 72 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("NegativeBinomial", "src/distribution/NegativeBinomial.birch", 72);
  #line 74 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(74);
  #line 74 "src/distribution/NegativeBinomial.birch"
  return birch::NegativeBinomial(k, birch::box(_u0961));
}

#line 80 "src/distribution/NegativeBinomial.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Integer>> birch::NegativeBinomial(const birch::type::Integer& k, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0961) {
  #line 80 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("NegativeBinomial", "src/distribution/NegativeBinomial.birch", 80);
  #line 82 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(82);
  #line 82 "src/distribution/NegativeBinomial.birch"
  return birch::NegativeBinomial(birch::box(k), _u0961);
}

#line 88 "src/distribution/NegativeBinomial.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Integer>> birch::NegativeBinomial(const birch::type::Integer& k, const birch::type::Real& _u0961) {
  #line 88 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("NegativeBinomial", "src/distribution/NegativeBinomial.birch", 88);
  #line 89 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(89);
  #line 89 "src/distribution/NegativeBinomial.birch"
  return birch::NegativeBinomial(birch::box(k), birch::box(_u0961));
}

#line 28 "src/distribution/NormalInverseGamma.birch"
birch::type::NormalInverseGamma::NormalInverseGamma(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& a2, const libbirch::Shared<birch::type::InverseGamma>& _u09632) :
    #line 28 "src/distribution/NormalInverseGamma.birch"
    base_type_(),
    #line 33 "src/distribution/NormalInverseGamma.birch"
    _u0956(std::move(_u0956)),
    #line 38 "src/distribution/NormalInverseGamma.birch"
    _u0955(1.0 / std::move(a2)),
    #line 43 "src/distribution/NormalInverseGamma.birch"
    _u09632(std::move(_u09632)) {
  //
}

#line 45 "src/distribution/NormalInverseGamma.birch"
birch::type::Boolean birch::type::NormalInverseGamma::supportsLazy() {
  #line 45 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("supportsLazy", "src/distribution/NormalInverseGamma.birch", 45);
  #line 46 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/NormalInverseGamma.birch"
  return true;
}

#line 49 "src/distribution/NormalInverseGamma.birch"
birch::type::Real birch::type::NormalInverseGamma::simulate() {
  #line 49 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("simulate", "src/distribution/NormalInverseGamma.birch", 49);
  #line 50 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/NormalInverseGamma.birch"
  return birch::simulate_normal_inverse_gamma(this->_u0956->value(), 1.0 / this->_u0955->value(), this->_u09632->_u0945->value(), this->_u09632->_u0946->value());
}

#line 53 "src/distribution/NormalInverseGamma.birch"
std::optional<birch::type::Real> birch::type::NormalInverseGamma::simulateLazy() {
  #line 53 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("simulateLazy", "src/distribution/NormalInverseGamma.birch", 53);
  #line 54 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/NormalInverseGamma.birch"
  return birch::simulate_normal_inverse_gamma(this->_u0956->get(), 1.0 / this->_u0955->get(), this->_u09632->_u0945->get(), this->_u09632->_u0946->get());
}

#line 57 "src/distribution/NormalInverseGamma.birch"
birch::type::Real birch::type::NormalInverseGamma::logpdf(const birch::type::Real& x) {
  #line 57 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("logpdf", "src/distribution/NormalInverseGamma.birch", 57);
  #line 58 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(58);
  #line 58 "src/distribution/NormalInverseGamma.birch"
  return birch::logpdf_normal_inverse_gamma(x, this->_u0956->value(), 1.0 / this->_u0955->value(), this->_u09632->_u0945->value(), this->_u09632->_u0946->value());
}

#line 61 "src/distribution/NormalInverseGamma.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::NormalInverseGamma::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 61 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("logpdfLazy", "src/distribution/NormalInverseGamma.birch", 61);
  #line 62 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/NormalInverseGamma.birch"
  return birch::logpdf_lazy_normal_inverse_gamma(x, this->_u0956, 1.0 / this->_u0955, this->_u09632->_u0945, this->_u09632->_u0946);
}

#line 65 "src/distribution/NormalInverseGamma.birch"
void birch::type::NormalInverseGamma::update(const birch::type::Real& x) {
  #line 65 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("update", "src/distribution/NormalInverseGamma.birch", 65);
  #line 66 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/NormalInverseGamma.birch"
  std::tie(this->_u09632->_u0945, this->_u09632->_u0946) = birch::box(birch::update_normal_inverse_gamma(x, this->_u0956->value(), this->_u0955->value(), this->_u09632->_u0945->value(), this->_u09632->_u0946->value()));
}

#line 69 "src/distribution/NormalInverseGamma.birch"
void birch::type::NormalInverseGamma::updateLazy(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 69 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("updateLazy", "src/distribution/NormalInverseGamma.birch", 69);
  #line 70 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(70);
  #line 70 "src/distribution/NormalInverseGamma.birch"
  std::tie(this->_u09632->_u0945, this->_u09632->_u0946) = birch::update_lazy_normal_inverse_gamma(x, this->_u0956, this->_u0955, this->_u09632->_u0945, this->_u09632->_u0946);
}

#line 73 "src/distribution/NormalInverseGamma.birch"
std::optional<birch::type::Real> birch::type::NormalInverseGamma::cdf(const birch::type::Real& x) {
  #line 73 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("cdf", "src/distribution/NormalInverseGamma.birch", 73);
  #line 74 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(74);
  #line 74 "src/distribution/NormalInverseGamma.birch"
  return birch::cdf_normal_inverse_gamma(x, this->_u0956->value(), 1.0 / this->_u0955->value(), this->_u09632->_u0945->value(), this->_u09632->_u0946->value());
}

#line 77 "src/distribution/NormalInverseGamma.birch"
std::optional<birch::type::Real> birch::type::NormalInverseGamma::quantile(const birch::type::Real& P) {
  #line 77 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("quantile", "src/distribution/NormalInverseGamma.birch", 77);
  #line 78 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(78);
  #line 78 "src/distribution/NormalInverseGamma.birch"
  return birch::quantile_normal_inverse_gamma(P, this->_u0956->value(), 1.0 / this->_u0955->value(), this->_u09632->_u0945->value(), this->_u09632->_u0946->value());
}

#line 81 "src/distribution/NormalInverseGamma.birch"
std::optional<libbirch::Shared<birch::type::NormalInverseGamma>> birch::type::NormalInverseGamma::graftNormalInverseGamma(const libbirch::Shared<birch::type::Distribution<birch::type::Real>>& compare) {
  #line 81 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("graftNormalInverseGamma", "src/distribution/NormalInverseGamma.birch", 81);
  #line 83 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(83);
  #line 83 "src/distribution/NormalInverseGamma.birch"
  this->prune();
  #line 84 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(84);
  #line 84 "src/distribution/NormalInverseGamma.birch"
  if (this->_u09632 == compare) {
    #line 85 "src/distribution/NormalInverseGamma.birch"
    libbirch_line_(85);
    #line 85 "src/distribution/NormalInverseGamma.birch"
    return this->shared_from_this_();
  } else {
    #line 87 "src/distribution/NormalInverseGamma.birch"
    libbirch_line_(87);
    #line 87 "src/distribution/NormalInverseGamma.birch"
    return std::nullopt;
  }
}

#line 91 "src/distribution/NormalInverseGamma.birch"
void birch::type::NormalInverseGamma::link() {
  #line 91 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("link", "src/distribution/NormalInverseGamma.birch", 91);
  #line 92 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(92);
  #line 92 "src/distribution/NormalInverseGamma.birch"
  this->_u09632->setChild(this->shared_from_this_());
}

#line 95 "src/distribution/NormalInverseGamma.birch"
void birch::type::NormalInverseGamma::unlink() {
  #line 95 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("unlink", "src/distribution/NormalInverseGamma.birch", 95);
  #line 96 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(96);
  #line 96 "src/distribution/NormalInverseGamma.birch"
  this->_u09632->releaseChild(this->shared_from_this_());
}

#line 99 "src/distribution/NormalInverseGamma.birch"
void birch::type::NormalInverseGamma::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 99 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("write", "src/distribution/NormalInverseGamma.birch", 99);
  #line 100 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(100);
  #line 100 "src/distribution/NormalInverseGamma.birch"
  this->prune();
  #line 101 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(101);
  #line 101 "src/distribution/NormalInverseGamma.birch"
  buffer->set(birch::type::String("class"), birch::type::String("NormalInverseGamma"));
  #line 102 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(102);
  #line 102 "src/distribution/NormalInverseGamma.birch"
  buffer->set(birch::type::String("μ"), this->_u0956);
  #line 103 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(103);
  #line 103 "src/distribution/NormalInverseGamma.birch"
  buffer->set(birch::type::String("a2"), 1.0 / this->_u0955);
  #line 104 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(104);
  #line 104 "src/distribution/NormalInverseGamma.birch"
  buffer->set(birch::type::String("α"), this->_u09632->_u0945);
  #line 105 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(105);
  #line 105 "src/distribution/NormalInverseGamma.birch"
  buffer->set(birch::type::String("β"), this->_u09632->_u0946);
}

#line 109 "src/distribution/NormalInverseGamma.birch"
libbirch::Shared<birch::type::NormalInverseGamma> birch::NormalInverseGamma(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& a2, const libbirch::Shared<birch::type::InverseGamma>& _u09632) {
  #line 109 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("NormalInverseGamma", "src/distribution/NormalInverseGamma.birch", 109);
  #line 111 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(111);
  #line 111 "src/distribution/NormalInverseGamma.birch"
  libbirch::Shared<birch::type::NormalInverseGamma> m = libbirch::make<libbirch::Shared<birch::type::NormalInverseGamma>>(std::in_place, _u0956, a2, _u09632);
  #line 112 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(112);
  #line 112 "src/distribution/NormalInverseGamma.birch"
  m->link();
  #line 113 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(113);
  #line 113 "src/distribution/NormalInverseGamma.birch"
  return m;
}

#line 4 "src/distribution/NormalInverseGammaGaussian.birch"
birch::type::NormalInverseGammaGaussian::NormalInverseGammaGaussian(const libbirch::Shared<birch::type::NormalInverseGamma>& _u0956) :
    #line 4 "src/distribution/NormalInverseGammaGaussian.birch"
    base_type_(),
    #line 9 "src/distribution/NormalInverseGammaGaussian.birch"
    _u0956(std::move(_u0956)) {
  //
}

#line 11 "src/distribution/NormalInverseGammaGaussian.birch"
birch::type::Boolean birch::type::NormalInverseGammaGaussian::supportsLazy() {
  #line 11 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/NormalInverseGammaGaussian.birch", 11);
  #line 12 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(12);
  #line 12 "src/distribution/NormalInverseGammaGaussian.birch"
  return true;
}

#line 15 "src/distribution/NormalInverseGammaGaussian.birch"
birch::type::Real birch::type::NormalInverseGammaGaussian::simulate() {
  #line 15 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("simulate", "src/distribution/NormalInverseGammaGaussian.birch", 15);
  #line 16 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/distribution/NormalInverseGammaGaussian.birch"
  return birch::simulate_normal_inverse_gamma_gaussian(this->_u0956->_u0956->value(), 1.0 / this->_u0956->_u0955->value(), this->_u0956->_u09632->_u0945->value(), this->_u0956->_u09632->_u0946->value());
}

#line 20 "src/distribution/NormalInverseGammaGaussian.birch"
std::optional<birch::type::Real> birch::type::NormalInverseGammaGaussian::simulateLazy() {
  #line 20 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/NormalInverseGammaGaussian.birch", 20);
  #line 21 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/NormalInverseGammaGaussian.birch"
  return birch::simulate_normal_inverse_gamma_gaussian(this->_u0956->_u0956->get(), 1.0 / this->_u0956->_u0955->get(), this->_u0956->_u09632->_u0945->get(), this->_u0956->_u09632->_u0946->get());
}

#line 25 "src/distribution/NormalInverseGammaGaussian.birch"
birch::type::Real birch::type::NormalInverseGammaGaussian::logpdf(const birch::type::Real& x) {
  #line 25 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/NormalInverseGammaGaussian.birch", 25);
  #line 26 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/distribution/NormalInverseGammaGaussian.birch"
  return birch::logpdf_normal_inverse_gamma_gaussian(x, this->_u0956->_u0956->value(), 1.0 / this->_u0956->_u0955->value(), this->_u0956->_u09632->_u0945->value(), this->_u0956->_u09632->_u0946->value());
}

#line 30 "src/distribution/NormalInverseGammaGaussian.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::NormalInverseGammaGaussian::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 30 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/NormalInverseGammaGaussian.birch", 30);
  #line 31 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/NormalInverseGammaGaussian.birch"
  return birch::logpdf_lazy_normal_inverse_gamma_gaussian(x, this->_u0956->_u0956, 1.0 / this->_u0956->_u0955, this->_u0956->_u09632->_u0945, this->_u0956->_u09632->_u0946);
}

#line 35 "src/distribution/NormalInverseGammaGaussian.birch"
void birch::type::NormalInverseGammaGaussian::update(const birch::type::Real& x) {
  #line 35 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("update", "src/distribution/NormalInverseGammaGaussian.birch", 35);
  #line 36 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/NormalInverseGammaGaussian.birch"
  std::tie(this->_u0956->_u0956, this->_u0956->_u0955, this->_u0956->_u09632->_u0945, this->_u0956->_u09632->_u0946) = birch::box(birch::update_normal_inverse_gamma_gaussian(x, this->_u0956->_u0956->value(), this->_u0956->_u0955->value(), this->_u0956->_u09632->_u0945->value(), this->_u0956->_u09632->_u0946->value()));
}

#line 40 "src/distribution/NormalInverseGammaGaussian.birch"
void birch::type::NormalInverseGammaGaussian::updateLazy(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 40 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/NormalInverseGammaGaussian.birch", 40);
  #line 41 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/NormalInverseGammaGaussian.birch"
  std::tie(this->_u0956->_u0956, this->_u0956->_u0955, this->_u0956->_u09632->_u0945, this->_u0956->_u09632->_u0946) = birch::update_lazy_normal_inverse_gamma_gaussian(x, this->_u0956->_u0956, this->_u0956->_u0955, this->_u0956->_u09632->_u0945, this->_u0956->_u09632->_u0946);
}

#line 45 "src/distribution/NormalInverseGammaGaussian.birch"
std::optional<birch::type::Real> birch::type::NormalInverseGammaGaussian::cdf(const birch::type::Real& x) {
  #line 45 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("cdf", "src/distribution/NormalInverseGammaGaussian.birch", 45);
  #line 46 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/NormalInverseGammaGaussian.birch"
  return birch::cdf_normal_inverse_gamma_gaussian(x, this->_u0956->_u0956->value(), 1.0 / this->_u0956->_u0955->value(), this->_u0956->_u09632->_u0945->value(), this->_u0956->_u09632->_u0946->value());
}

#line 50 "src/distribution/NormalInverseGammaGaussian.birch"
std::optional<birch::type::Real> birch::type::NormalInverseGammaGaussian::quantile(const birch::type::Real& P) {
  #line 50 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("quantile", "src/distribution/NormalInverseGammaGaussian.birch", 50);
  #line 51 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/NormalInverseGammaGaussian.birch"
  return birch::quantile_normal_inverse_gamma_gaussian(P, this->_u0956->_u0956->value(), 1.0 / this->_u0956->_u0955->value(), this->_u0956->_u09632->_u0945->value(), this->_u0956->_u09632->_u0946->value());
}

#line 55 "src/distribution/NormalInverseGammaGaussian.birch"
void birch::type::NormalInverseGammaGaussian::link() {
  #line 55 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("link", "src/distribution/NormalInverseGammaGaussian.birch", 55);
  #line 56 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/NormalInverseGammaGaussian.birch"
  this->_u0956->setChild(this->shared_from_this_());
}

#line 59 "src/distribution/NormalInverseGammaGaussian.birch"
void birch::type::NormalInverseGammaGaussian::unlink() {
  #line 59 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("unlink", "src/distribution/NormalInverseGammaGaussian.birch", 59);
  #line 60 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/NormalInverseGammaGaussian.birch"
  this->_u0956->releaseChild(this->shared_from_this_());
}

#line 64 "src/distribution/NormalInverseGammaGaussian.birch"
libbirch::Shared<birch::type::NormalInverseGammaGaussian> birch::NormalInverseGammaGaussian(const libbirch::Shared<birch::type::NormalInverseGamma>& _u0956) {
  #line 64 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("NormalInverseGammaGaussian", "src/distribution/NormalInverseGammaGaussian.birch", 64);
  #line 66 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch::Shared<birch::type::NormalInverseGammaGaussian> m = libbirch::make<libbirch::Shared<birch::type::NormalInverseGammaGaussian>>(std::in_place, _u0956);
  #line 67 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/NormalInverseGammaGaussian.birch"
  m->link();
  #line 68 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(68);
  #line 68 "src/distribution/NormalInverseGammaGaussian.birch"
  return m;
}

#line 4 "src/distribution/Poisson.birch"
birch::type::Poisson::Poisson(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0955) :
    #line 4 "src/distribution/Poisson.birch"
    base_type_(),
    #line 8 "src/distribution/Poisson.birch"
    _u0955(std::move(_u0955)) {
  //
}

#line 10 "src/distribution/Poisson.birch"
birch::type::Boolean birch::type::Poisson::supportsLazy() {
  #line 10 "src/distribution/Poisson.birch"
  libbirch_function_("supportsLazy", "src/distribution/Poisson.birch", 10);
  #line 11 "src/distribution/Poisson.birch"
  libbirch_line_(11);
  #line 11 "src/distribution/Poisson.birch"
  return true;
}

#line 14 "src/distribution/Poisson.birch"
birch::type::Integer birch::type::Poisson::simulate() {
  #line 14 "src/distribution/Poisson.birch"
  libbirch_function_("simulate", "src/distribution/Poisson.birch", 14);
  #line 15 "src/distribution/Poisson.birch"
  libbirch_line_(15);
  #line 15 "src/distribution/Poisson.birch"
  return birch::simulate_poisson(this->_u0955->value());
}

#line 18 "src/distribution/Poisson.birch"
std::optional<birch::type::Integer> birch::type::Poisson::simulateLazy() {
  #line 18 "src/distribution/Poisson.birch"
  libbirch_function_("simulateLazy", "src/distribution/Poisson.birch", 18);
  #line 19 "src/distribution/Poisson.birch"
  libbirch_line_(19);
  #line 19 "src/distribution/Poisson.birch"
  return birch::simulate_poisson(this->_u0955->get());
}

#line 22 "src/distribution/Poisson.birch"
birch::type::Real birch::type::Poisson::logpdf(const birch::type::Integer& x) {
  #line 22 "src/distribution/Poisson.birch"
  libbirch_function_("logpdf", "src/distribution/Poisson.birch", 22);
  #line 23 "src/distribution/Poisson.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/Poisson.birch"
  return birch::logpdf_poisson(x, this->_u0955->value());
}

#line 26 "src/distribution/Poisson.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::Poisson::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& x) {
  #line 26 "src/distribution/Poisson.birch"
  libbirch_function_("logpdfLazy", "src/distribution/Poisson.birch", 26);
  #line 27 "src/distribution/Poisson.birch"
  libbirch_line_(27);
  #line 27 "src/distribution/Poisson.birch"
  return birch::logpdf_lazy_poisson(x, this->_u0955);
}

#line 30 "src/distribution/Poisson.birch"
std::optional<birch::type::Real> birch::type::Poisson::cdf(const birch::type::Integer& x) {
  #line 30 "src/distribution/Poisson.birch"
  libbirch_function_("cdf", "src/distribution/Poisson.birch", 30);
  #line 31 "src/distribution/Poisson.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/Poisson.birch"
  return birch::cdf_poisson(x, this->_u0955->value());
}

#line 34 "src/distribution/Poisson.birch"
std::optional<birch::type::Integer> birch::type::Poisson::quantile(const birch::type::Real& P) {
  #line 34 "src/distribution/Poisson.birch"
  libbirch_function_("quantile", "src/distribution/Poisson.birch", 34);
  #line 35 "src/distribution/Poisson.birch"
  libbirch_line_(35);
  #line 35 "src/distribution/Poisson.birch"
  return birch::quantile_poisson(P, this->_u0955->value());
}

#line 38 "src/distribution/Poisson.birch"
std::optional<birch::type::Integer> birch::type::Poisson::lower() {
  #line 38 "src/distribution/Poisson.birch"
  libbirch_function_("lower", "src/distribution/Poisson.birch", 38);
  #line 39 "src/distribution/Poisson.birch"
  libbirch_line_(39);
  #line 39 "src/distribution/Poisson.birch"
  return birch::type::Integer(0);
}

#line 42 "src/distribution/Poisson.birch"
void birch::type::Poisson::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 42 "src/distribution/Poisson.birch"
  libbirch_function_("write", "src/distribution/Poisson.birch", 42);
  #line 43 "src/distribution/Poisson.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/Poisson.birch"
  this->prune();
  #line 44 "src/distribution/Poisson.birch"
  libbirch_line_(44);
  #line 44 "src/distribution/Poisson.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Poisson"));
  #line 45 "src/distribution/Poisson.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/Poisson.birch"
  buffer->set(birch::type::String("λ"), this->_u0955);
}

#line 52 "src/distribution/Poisson.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Integer>> birch::Poisson(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0955) {
  #line 52 "src/distribution/Poisson.birch"
  libbirch_function_("Poisson", "src/distribution/Poisson.birch", 52);
  #line 53 "src/distribution/Poisson.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/Poisson.birch"
  std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gamma>>>> m1 = libbirch::make<std::optional<libbirch::Shared<birch::type::TransformLinear<libbirch::Shared<birch::type::Gamma>>>>>();
  #line 54 "src/distribution/Poisson.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/Poisson.birch"
  std::optional<libbirch::Shared<birch::type::Gamma>> m2 = libbirch::make<std::optional<libbirch::Shared<birch::type::Gamma>>>();
  #line 55 "src/distribution/Poisson.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/Poisson.birch"
  if ((m1 = _u0955->graftScaledGamma()).has_value()) {
    #line 56 "src/distribution/Poisson.birch"
    libbirch_line_(56);
    #line 56 "src/distribution/Poisson.birch"
    return birch::ScaledGammaPoisson(m1.value()->a, m1.value()->x);
  } else {
    #line 57 "src/distribution/Poisson.birch"
    libbirch_line_(57);
    #line 57 "src/distribution/Poisson.birch"
    if ((m2 = _u0955->graftGamma()).has_value()) {
      #line 58 "src/distribution/Poisson.birch"
      libbirch_line_(58);
      #line 58 "src/distribution/Poisson.birch"
      return birch::GammaPoisson(m2.value());
    } else {
      #line 60 "src/distribution/Poisson.birch"
      libbirch_line_(60);
      #line 60 "src/distribution/Poisson.birch"
      return birch::construct<libbirch::Shared<birch::type::Poisson>>(_u0955);
    }
  }
}

#line 67 "src/distribution/Poisson.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Integer>> birch::Poisson(const birch::type::Real& _u0955) {
  #line 67 "src/distribution/Poisson.birch"
  libbirch_function_("Poisson", "src/distribution/Poisson.birch", 67);
  #line 68 "src/distribution/Poisson.birch"
  libbirch_line_(68);
  #line 68 "src/distribution/Poisson.birch"
  return birch::Poisson(birch::box(_u0955));
}

#line 8 "src/distribution/Restaurant.birch"
birch::type::Restaurant::Restaurant(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0945, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0952) :
    #line 8 "src/distribution/Restaurant.birch"
    base_type_(),
    #line 13 "src/distribution/Restaurant.birch"
    _u0945(std::move(_u0945)),
    #line 18 "src/distribution/Restaurant.birch"
    _u0952(std::move(_u0952)),
    #line 23 "src/distribution/Restaurant.birch"
    n(libbirch::make<libbirch::DefaultArray<birch::type::Integer,1>>()),
    #line 28 "src/distribution/Restaurant.birch"
    K(birch::type::Integer(0)),
    #line 33 "src/distribution/Restaurant.birch"
    N(birch::type::Integer(0)) {
  //
}

#line 35 "src/distribution/Restaurant.birch"
birch::type::Boolean birch::type::Restaurant::supportsLazy() {
  #line 35 "src/distribution/Restaurant.birch"
  libbirch_function_("supportsLazy", "src/distribution/Restaurant.birch", 35);
  #line 36 "src/distribution/Restaurant.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/Restaurant.birch"
  return false;
}

#line 39 "src/distribution/Restaurant.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::Restaurant::simulate() {
  #line 39 "src/distribution/Restaurant.birch"
  libbirch_function_("simulate", "src/distribution/Restaurant.birch", 39);
  #line 40 "src/distribution/Restaurant.birch"
  libbirch_line_(40);
  #line 40 "src/distribution/Restaurant.birch"
  libbirch_assert_(false);
  #line 41 "src/distribution/Restaurant.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/Restaurant.birch"
  return birch::vector(0.0, birch::type::Integer(0));
}

#line 44 "src/distribution/Restaurant.birch"
std::optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::Restaurant::simulateLazy() {
  #line 44 "src/distribution/Restaurant.birch"
  libbirch_function_("simulateLazy", "src/distribution/Restaurant.birch", 44);
  #line 45 "src/distribution/Restaurant.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/Restaurant.birch"
  libbirch_assert_(false);
  #line 46 "src/distribution/Restaurant.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/Restaurant.birch"
  return birch::vector(0.0, birch::type::Integer(0));
}

#line 49 "src/distribution/Restaurant.birch"
birch::type::Real birch::type::Restaurant::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 49 "src/distribution/Restaurant.birch"
  libbirch_function_("logpdf", "src/distribution/Restaurant.birch", 49);
  #line 50 "src/distribution/Restaurant.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/Restaurant.birch"
  libbirch_assert_(false);
  #line 51 "src/distribution/Restaurant.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/Restaurant.birch"
  return 0.0;
}

#line 54 "src/distribution/Restaurant.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::Restaurant::logpdfLazy(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>& x) {
  #line 54 "src/distribution/Restaurant.birch"
  libbirch_function_("logpdfLazy", "src/distribution/Restaurant.birch", 54);
  #line 55 "src/distribution/Restaurant.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/Restaurant.birch"
  libbirch_assert_(false);
  #line 56 "src/distribution/Restaurant.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/Restaurant.birch"
  return birch::box(0.0);
}

#line 59 "src/distribution/Restaurant.birch"
std::optional<libbirch::Shared<birch::type::Restaurant>> birch::type::Restaurant::graftRestaurant() {
  #line 59 "src/distribution/Restaurant.birch"
  libbirch_function_("graftRestaurant", "src/distribution/Restaurant.birch", 59);
  #line 60 "src/distribution/Restaurant.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/Restaurant.birch"
  this->prune();
  #line 61 "src/distribution/Restaurant.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/Restaurant.birch"
  return this->shared_from_this_();
}

#line 64 "src/distribution/Restaurant.birch"
void birch::type::Restaurant::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 64 "src/distribution/Restaurant.birch"
  libbirch_function_("write", "src/distribution/Restaurant.birch", 64);
  #line 65 "src/distribution/Restaurant.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/Restaurant.birch"
  this->prune();
  #line 66 "src/distribution/Restaurant.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/Restaurant.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Restaurant"));
  #line 67 "src/distribution/Restaurant.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/Restaurant.birch"
  buffer->set(birch::type::String("α"), this->_u0945);
  #line 68 "src/distribution/Restaurant.birch"
  libbirch_line_(68);
  #line 68 "src/distribution/Restaurant.birch"
  buffer->set(birch::type::String("θ"), this->_u0952);
  #line 69 "src/distribution/Restaurant.birch"
  libbirch_line_(69);
  #line 69 "src/distribution/Restaurant.birch"
  buffer->set(birch::type::String("n"), this->n);
}

#line 76 "src/distribution/Restaurant.birch"
libbirch::Shared<birch::type::Restaurant> birch::Restaurant(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0945, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0952) {
  #line 76 "src/distribution/Restaurant.birch"
  libbirch_function_("Restaurant", "src/distribution/Restaurant.birch", 76);
  #line 77 "src/distribution/Restaurant.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/Restaurant.birch"
  return birch::construct<libbirch::Shared<birch::type::Restaurant>>(_u0945, _u0952);
}

#line 83 "src/distribution/Restaurant.birch"
libbirch::Shared<birch::type::Restaurant> birch::Restaurant(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0945, const birch::type::Real& _u0952) {
  #line 83 "src/distribution/Restaurant.birch"
  libbirch_function_("Restaurant", "src/distribution/Restaurant.birch", 83);
  #line 84 "src/distribution/Restaurant.birch"
  libbirch_line_(84);
  #line 84 "src/distribution/Restaurant.birch"
  return birch::Restaurant(_u0945, birch::box(_u0952));
}

#line 90 "src/distribution/Restaurant.birch"
libbirch::Shared<birch::type::Restaurant> birch::Restaurant(const birch::type::Real& _u0945, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0952) {
  #line 90 "src/distribution/Restaurant.birch"
  libbirch_function_("Restaurant", "src/distribution/Restaurant.birch", 90);
  #line 91 "src/distribution/Restaurant.birch"
  libbirch_line_(91);
  #line 91 "src/distribution/Restaurant.birch"
  return birch::Restaurant(birch::box(_u0945), _u0952);
}

#line 97 "src/distribution/Restaurant.birch"
libbirch::Shared<birch::type::Restaurant> birch::Restaurant(const birch::type::Real& _u0945, const birch::type::Real& _u0952) {
  #line 97 "src/distribution/Restaurant.birch"
  libbirch_function_("Restaurant", "src/distribution/Restaurant.birch", 97);
  #line 98 "src/distribution/Restaurant.birch"
  libbirch_line_(98);
  #line 98 "src/distribution/Restaurant.birch"
  return birch::Restaurant(birch::box(_u0945), birch::box(_u0952));
}

#line 4 "src/distribution/RestaurantCategorical.birch"
birch::type::RestaurantCategorical::RestaurantCategorical(const libbirch::Shared<birch::type::Restaurant>& _u0961) :
    #line 4 "src/distribution/RestaurantCategorical.birch"
    base_type_(),
    #line 8 "src/distribution/RestaurantCategorical.birch"
    _u0961(std::move(_u0961)) {
  //
}

#line 10 "src/distribution/RestaurantCategorical.birch"
birch::type::Boolean birch::type::RestaurantCategorical::supportsLazy() {
  #line 10 "src/distribution/RestaurantCategorical.birch"
  libbirch_function_("supportsLazy", "src/distribution/RestaurantCategorical.birch", 10);
  #line 11 "src/distribution/RestaurantCategorical.birch"
  libbirch_line_(11);
  #line 11 "src/distribution/RestaurantCategorical.birch"
  return false;
}

#line 14 "src/distribution/RestaurantCategorical.birch"
birch::type::Integer birch::type::RestaurantCategorical::simulate() {
  #line 14 "src/distribution/RestaurantCategorical.birch"
  libbirch_function_("simulate", "src/distribution/RestaurantCategorical.birch", 14);
  #line 15 "src/distribution/RestaurantCategorical.birch"
  libbirch_line_(15);
  #line 15 "src/distribution/RestaurantCategorical.birch"
  return birch::simulate_crp_categorical(this->_u0961->_u0945->value(), this->_u0961->_u0952->value(), this->_u0961->n, this->_u0961->N);
}

#line 22 "src/distribution/RestaurantCategorical.birch"
birch::type::Real birch::type::RestaurantCategorical::logpdf(const birch::type::Integer& x) {
  #line 22 "src/distribution/RestaurantCategorical.birch"
  libbirch_function_("logpdf", "src/distribution/RestaurantCategorical.birch", 22);
  #line 23 "src/distribution/RestaurantCategorical.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/RestaurantCategorical.birch"
  return birch::logpdf_crp_categorical(x, this->_u0961->_u0945->value(), this->_u0961->_u0952->value(), this->_u0961->n, this->_u0961->N);
}

#line 30 "src/distribution/RestaurantCategorical.birch"
void birch::type::RestaurantCategorical::update(const birch::type::Integer& x) {
  #line 30 "src/distribution/RestaurantCategorical.birch"
  libbirch_function_("update", "src/distribution/RestaurantCategorical.birch", 30);
  #line 31 "src/distribution/RestaurantCategorical.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/RestaurantCategorical.birch"
  libbirch_assert_(x <= this->_u0961->K + birch::type::Integer(1));
  #line 32 "src/distribution/RestaurantCategorical.birch"
  libbirch_line_(32);
  #line 32 "src/distribution/RestaurantCategorical.birch"
  if (x == this->_u0961->K + birch::type::Integer(1)) {
    #line 34 "src/distribution/RestaurantCategorical.birch"
    libbirch_line_(34);
    #line 34 "src/distribution/RestaurantCategorical.birch"
    libbirch::DefaultArray<birch::type::Integer,1> n1 = libbirch::make_array<birch::type::Integer>(libbirch::make_shape(this->_u0961->K + birch::type::Integer(1)));
    #line 35 "src/distribution/RestaurantCategorical.birch"
    libbirch_line_(35);
    #line 35 "src/distribution/RestaurantCategorical.birch"
    n1(libbirch::make_range(birch::type::Integer(1), this->_u0961->K)) = this->_u0961->n;
    #line 36 "src/distribution/RestaurantCategorical.birch"
    libbirch_line_(36);
    #line 36 "src/distribution/RestaurantCategorical.birch"
    n1(x) = birch::type::Integer(1);
    #line 37 "src/distribution/RestaurantCategorical.birch"
    libbirch_line_(37);
    #line 37 "src/distribution/RestaurantCategorical.birch"
    this->_u0961->n = n1;
    #line 38 "src/distribution/RestaurantCategorical.birch"
    libbirch_line_(38);
    #line 38 "src/distribution/RestaurantCategorical.birch"
    this->_u0961->K = this->_u0961->K + birch::type::Integer(1);
  } else {
    #line 40 "src/distribution/RestaurantCategorical.birch"
    libbirch_line_(40);
    #line 40 "src/distribution/RestaurantCategorical.birch"
    this->_u0961->n(x) = this->_u0961->n(x) + birch::type::Integer(1);
  }
  #line 42 "src/distribution/RestaurantCategorical.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/RestaurantCategorical.birch"
  this->_u0961->N = this->_u0961->N + birch::type::Integer(1);
}

#line 49 "src/distribution/RestaurantCategorical.birch"
void birch::type::RestaurantCategorical::link() {
  #line 49 "src/distribution/RestaurantCategorical.birch"
  libbirch_function_("link", "src/distribution/RestaurantCategorical.birch", 49);
  #line 50 "src/distribution/RestaurantCategorical.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/RestaurantCategorical.birch"
  this->_u0961->setChild(this->shared_from_this_());
}

#line 53 "src/distribution/RestaurantCategorical.birch"
void birch::type::RestaurantCategorical::unlink() {
  #line 53 "src/distribution/RestaurantCategorical.birch"
  libbirch_function_("unlink", "src/distribution/RestaurantCategorical.birch", 53);
  #line 54 "src/distribution/RestaurantCategorical.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/RestaurantCategorical.birch"
  this->_u0961->releaseChild(this->shared_from_this_());
}

#line 58 "src/distribution/RestaurantCategorical.birch"
libbirch::Shared<birch::type::RestaurantCategorical> birch::RestaurantCategorical(const libbirch::Shared<birch::type::Restaurant>& _u0961) {
  #line 58 "src/distribution/RestaurantCategorical.birch"
  libbirch_function_("RestaurantCategorical", "src/distribution/RestaurantCategorical.birch", 58);
  #line 59 "src/distribution/RestaurantCategorical.birch"
  libbirch_line_(59);
  #line 59 "src/distribution/RestaurantCategorical.birch"
  libbirch::Shared<birch::type::RestaurantCategorical> m = libbirch::make<libbirch::Shared<birch::type::RestaurantCategorical>>(std::in_place, _u0961);
  #line 60 "src/distribution/RestaurantCategorical.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/RestaurantCategorical.birch"
  m->link();
  #line 61 "src/distribution/RestaurantCategorical.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/RestaurantCategorical.birch"
  return m;
}

#line 4 "src/distribution/ScaledGammaExponential.birch"
birch::type::ScaledGammaExponential::ScaledGammaExponential(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& a, const libbirch::Shared<birch::type::Gamma>& _u0955) :
    #line 4 "src/distribution/ScaledGammaExponential.birch"
    base_type_(),
    #line 9 "src/distribution/ScaledGammaExponential.birch"
    a(std::move(a)),
    #line 14 "src/distribution/ScaledGammaExponential.birch"
    _u0955(std::move(_u0955)) {
  //
}

#line 16 "src/distribution/ScaledGammaExponential.birch"
birch::type::Boolean birch::type::ScaledGammaExponential::supportsLazy() {
  #line 16 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("supportsLazy", "src/distribution/ScaledGammaExponential.birch", 16);
  #line 17 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/ScaledGammaExponential.birch"
  return true;
}

#line 20 "src/distribution/ScaledGammaExponential.birch"
birch::type::Real birch::type::ScaledGammaExponential::simulate() {
  #line 20 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("simulate", "src/distribution/ScaledGammaExponential.birch", 20);
  #line 21 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/ScaledGammaExponential.birch"
  return birch::simulate_lomax(1.0 / (this->a->value() * this->_u0955->_u0952->value()), this->_u0955->k->value());
}

#line 24 "src/distribution/ScaledGammaExponential.birch"
std::optional<birch::type::Real> birch::type::ScaledGammaExponential::simulateLazy() {
  #line 24 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("simulateLazy", "src/distribution/ScaledGammaExponential.birch", 24);
  #line 25 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/ScaledGammaExponential.birch"
  return birch::simulate_lomax(1.0 / (this->a->get() * this->_u0955->_u0952->get()), this->_u0955->k->get());
}

#line 28 "src/distribution/ScaledGammaExponential.birch"
birch::type::Real birch::type::ScaledGammaExponential::logpdf(const birch::type::Real& x) {
  #line 28 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("logpdf", "src/distribution/ScaledGammaExponential.birch", 28);
  #line 29 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/ScaledGammaExponential.birch"
  return birch::logpdf_lomax(x, 1.0 / (this->a->value() * this->_u0955->_u0952->value()), this->_u0955->k->value());
}

#line 32 "src/distribution/ScaledGammaExponential.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::ScaledGammaExponential::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 32 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("logpdfLazy", "src/distribution/ScaledGammaExponential.birch", 32);
  #line 33 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/ScaledGammaExponential.birch"
  return birch::logpdf_lazy_lomax(x, 1.0 / (this->a * this->_u0955->_u0952), this->_u0955->k);
}

#line 36 "src/distribution/ScaledGammaExponential.birch"
void birch::type::ScaledGammaExponential::update(const birch::type::Real& x) {
  #line 36 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("update", "src/distribution/ScaledGammaExponential.birch", 36);
  #line 37 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/ScaledGammaExponential.birch"
  std::tie(this->_u0955->k, this->_u0955->_u0952) = birch::box(birch::update_scaled_gamma_exponential(x, this->a->value(), this->_u0955->k->value(), this->_u0955->_u0952->value()));
}

#line 41 "src/distribution/ScaledGammaExponential.birch"
void birch::type::ScaledGammaExponential::updateLazy(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 41 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("updateLazy", "src/distribution/ScaledGammaExponential.birch", 41);
  #line 42 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/ScaledGammaExponential.birch"
  std::tie(this->_u0955->k, this->_u0955->_u0952) = birch::update_lazy_scaled_gamma_exponential(x, this->a, this->_u0955->k, this->_u0955->_u0952);
}

#line 45 "src/distribution/ScaledGammaExponential.birch"
std::optional<birch::type::Real> birch::type::ScaledGammaExponential::cdf(const birch::type::Real& x) {
  #line 45 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("cdf", "src/distribution/ScaledGammaExponential.birch", 45);
  #line 46 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/ScaledGammaExponential.birch"
  return birch::cdf_lomax(x, 1.0 / (this->a->value() * this->_u0955->_u0952->value()), this->_u0955->k->value());
}

#line 49 "src/distribution/ScaledGammaExponential.birch"
std::optional<birch::type::Real> birch::type::ScaledGammaExponential::quantile(const birch::type::Real& P) {
  #line 49 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("quantile", "src/distribution/ScaledGammaExponential.birch", 49);
  #line 50 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/ScaledGammaExponential.birch"
  return birch::quantile_lomax(P, 1.0 / (this->a->value() * this->_u0955->_u0952->value()), this->_u0955->k->value());
}

#line 53 "src/distribution/ScaledGammaExponential.birch"
std::optional<birch::type::Real> birch::type::ScaledGammaExponential::lower() {
  #line 53 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("lower", "src/distribution/ScaledGammaExponential.birch", 53);
  #line 54 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/ScaledGammaExponential.birch"
  return 0.0;
}

#line 57 "src/distribution/ScaledGammaExponential.birch"
void birch::type::ScaledGammaExponential::link() {
  #line 57 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("link", "src/distribution/ScaledGammaExponential.birch", 57);
  #line 58 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(58);
  #line 58 "src/distribution/ScaledGammaExponential.birch"
  this->_u0955->setChild(this->shared_from_this_());
}

#line 61 "src/distribution/ScaledGammaExponential.birch"
void birch::type::ScaledGammaExponential::unlink() {
  #line 61 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("unlink", "src/distribution/ScaledGammaExponential.birch", 61);
  #line 62 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/ScaledGammaExponential.birch"
  this->_u0955->releaseChild(this->shared_from_this_());
}

#line 66 "src/distribution/ScaledGammaExponential.birch"
libbirch::Shared<birch::type::ScaledGammaExponential> birch::ScaledGammaExponential(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& a, const libbirch::Shared<birch::type::Gamma>& _u0955) {
  #line 66 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("ScaledGammaExponential", "src/distribution/ScaledGammaExponential.birch", 66);
  #line 68 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(68);
  #line 68 "src/distribution/ScaledGammaExponential.birch"
  libbirch::Shared<birch::type::ScaledGammaExponential> m = libbirch::make<libbirch::Shared<birch::type::ScaledGammaExponential>>(std::in_place, a, _u0955);
  #line 69 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(69);
  #line 69 "src/distribution/ScaledGammaExponential.birch"
  m->link();
  #line 70 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(70);
  #line 70 "src/distribution/ScaledGammaExponential.birch"
  return m;
}

#line 4 "src/distribution/ScaledGammaPoisson.birch"
birch::type::ScaledGammaPoisson::ScaledGammaPoisson(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& a, const libbirch::Shared<birch::type::Gamma>& _u0955) :
    #line 4 "src/distribution/ScaledGammaPoisson.birch"
    base_type_(),
    #line 8 "src/distribution/ScaledGammaPoisson.birch"
    a(std::move(a)),
    #line 13 "src/distribution/ScaledGammaPoisson.birch"
    _u0955(std::move(_u0955)) {
  //
}

#line 15 "src/distribution/ScaledGammaPoisson.birch"
birch::type::Boolean birch::type::ScaledGammaPoisson::supportsLazy() {
  #line 15 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("supportsLazy", "src/distribution/ScaledGammaPoisson.birch", 15);
  #line 16 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(16);
  #line 16 "src/distribution/ScaledGammaPoisson.birch"
  return true;
}

#line 19 "src/distribution/ScaledGammaPoisson.birch"
birch::type::Integer birch::type::ScaledGammaPoisson::simulate() {
  #line 19 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("simulate", "src/distribution/ScaledGammaPoisson.birch", 19);
  #line 20 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(20);
  #line 20 "src/distribution/ScaledGammaPoisson.birch"
  return birch::simulate_gamma_poisson(this->_u0955->k->value(), this->a->value() * this->_u0955->_u0952->value());
}

#line 23 "src/distribution/ScaledGammaPoisson.birch"
std::optional<birch::type::Integer> birch::type::ScaledGammaPoisson::simulateLazy() {
  #line 23 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("simulateLazy", "src/distribution/ScaledGammaPoisson.birch", 23);
  #line 24 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(24);
  #line 24 "src/distribution/ScaledGammaPoisson.birch"
  return birch::simulate_gamma_poisson(this->_u0955->k->get(), this->a->get() * this->_u0955->_u0952->get());
}

#line 27 "src/distribution/ScaledGammaPoisson.birch"
birch::type::Real birch::type::ScaledGammaPoisson::logpdf(const birch::type::Integer& x) {
  #line 27 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("logpdf", "src/distribution/ScaledGammaPoisson.birch", 27);
  #line 28 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(28);
  #line 28 "src/distribution/ScaledGammaPoisson.birch"
  return birch::logpdf_gamma_poisson(x, this->_u0955->k->value(), this->a->value() * this->_u0955->_u0952->value());
}

#line 31 "src/distribution/ScaledGammaPoisson.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::ScaledGammaPoisson::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& x) {
  #line 31 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("logpdfLazy", "src/distribution/ScaledGammaPoisson.birch", 31);
  #line 32 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(32);
  #line 32 "src/distribution/ScaledGammaPoisson.birch"
  return birch::logpdf_lazy_gamma_poisson(x, this->_u0955->k, this->a * this->_u0955->_u0952);
}

#line 35 "src/distribution/ScaledGammaPoisson.birch"
void birch::type::ScaledGammaPoisson::update(const birch::type::Integer& x) {
  #line 35 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("update", "src/distribution/ScaledGammaPoisson.birch", 35);
  #line 36 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/ScaledGammaPoisson.birch"
  std::tie(this->_u0955->k, this->_u0955->_u0952) = birch::box(birch::update_scaled_gamma_poisson(x, this->a->value(), this->_u0955->k->value(), this->_u0955->_u0952->value()));
}

#line 40 "src/distribution/ScaledGammaPoisson.birch"
void birch::type::ScaledGammaPoisson::updateLazy(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& x) {
  #line 40 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("updateLazy", "src/distribution/ScaledGammaPoisson.birch", 40);
  #line 41 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/ScaledGammaPoisson.birch"
  std::tie(this->_u0955->k, this->_u0955->_u0952) = birch::update_lazy_scaled_gamma_poisson(x, this->a, this->_u0955->k, this->_u0955->_u0952);
}

#line 44 "src/distribution/ScaledGammaPoisson.birch"
std::optional<birch::type::Real> birch::type::ScaledGammaPoisson::cdf(const birch::type::Integer& x) {
  #line 44 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("cdf", "src/distribution/ScaledGammaPoisson.birch", 44);
  #line 45 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/ScaledGammaPoisson.birch"
  return birch::cdf_gamma_poisson(x, this->_u0955->k->value(), this->a->value() * this->_u0955->_u0952->value());
}

#line 48 "src/distribution/ScaledGammaPoisson.birch"
std::optional<birch::type::Integer> birch::type::ScaledGammaPoisson::quantile(const birch::type::Real& P) {
  #line 48 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("quantile", "src/distribution/ScaledGammaPoisson.birch", 48);
  #line 49 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/ScaledGammaPoisson.birch"
  return birch::quantile_gamma_poisson(P, this->_u0955->k->value(), this->a->value() * this->_u0955->_u0952->value());
}

#line 52 "src/distribution/ScaledGammaPoisson.birch"
std::optional<birch::type::Integer> birch::type::ScaledGammaPoisson::lower() {
  #line 52 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("lower", "src/distribution/ScaledGammaPoisson.birch", 52);
  #line 53 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/ScaledGammaPoisson.birch"
  return birch::type::Integer(0);
}

#line 56 "src/distribution/ScaledGammaPoisson.birch"
void birch::type::ScaledGammaPoisson::link() {
  #line 56 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("link", "src/distribution/ScaledGammaPoisson.birch", 56);
  #line 57 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/ScaledGammaPoisson.birch"
  this->_u0955->setChild(this->shared_from_this_());
}

#line 60 "src/distribution/ScaledGammaPoisson.birch"
void birch::type::ScaledGammaPoisson::unlink() {
  #line 60 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("unlink", "src/distribution/ScaledGammaPoisson.birch", 60);
  #line 61 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/ScaledGammaPoisson.birch"
  this->_u0955->releaseChild(this->shared_from_this_());
}

#line 65 "src/distribution/ScaledGammaPoisson.birch"
libbirch::Shared<birch::type::ScaledGammaPoisson> birch::ScaledGammaPoisson(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& a, const libbirch::Shared<birch::type::Gamma>& _u0955) {
  #line 65 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("ScaledGammaPoisson", "src/distribution/ScaledGammaPoisson.birch", 65);
  #line 67 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/ScaledGammaPoisson.birch"
  libbirch::Shared<birch::type::ScaledGammaPoisson> m = libbirch::make<libbirch::Shared<birch::type::ScaledGammaPoisson>>(std::in_place, a, _u0955);
  #line 68 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(68);
  #line 68 "src/distribution/ScaledGammaPoisson.birch"
  m->link();
  #line 69 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(69);
  #line 69 "src/distribution/ScaledGammaPoisson.birch"
  return m;
}

#line 4 "src/distribution/Student.birch"
birch::type::Student::Student(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0957, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632) :
    #line 4 "src/distribution/Student.birch"
    base_type_(),
    #line 9 "src/distribution/Student.birch"
    _u0957(std::move(_u0957)),
    #line 14 "src/distribution/Student.birch"
    _u0956(std::move(_u0956)),
    #line 19 "src/distribution/Student.birch"
    _u09632(std::move(_u09632)) {
  //
}

#line 21 "src/distribution/Student.birch"
birch::type::Boolean birch::type::Student::supportsLazy() {
  #line 21 "src/distribution/Student.birch"
  libbirch_function_("supportsLazy", "src/distribution/Student.birch", 21);
  #line 22 "src/distribution/Student.birch"
  libbirch_line_(22);
  #line 22 "src/distribution/Student.birch"
  return true;
}

#line 25 "src/distribution/Student.birch"
birch::type::Real birch::type::Student::simulate() {
  #line 25 "src/distribution/Student.birch"
  libbirch_function_("simulate", "src/distribution/Student.birch", 25);
  #line 26 "src/distribution/Student.birch"
  libbirch_line_(26);
  #line 26 "src/distribution/Student.birch"
  return birch::simulate_student_t(this->_u0957->value(), this->_u0956->value(), this->_u09632->value());
}

#line 29 "src/distribution/Student.birch"
std::optional<birch::type::Real> birch::type::Student::simulateLazy() {
  #line 29 "src/distribution/Student.birch"
  libbirch_function_("simulateLazy", "src/distribution/Student.birch", 29);
  #line 30 "src/distribution/Student.birch"
  libbirch_line_(30);
  #line 30 "src/distribution/Student.birch"
  return birch::simulate_student_t(this->_u0957->get(), this->_u0956->get(), this->_u09632->get());
}

#line 33 "src/distribution/Student.birch"
birch::type::Real birch::type::Student::logpdf(const birch::type::Real& x) {
  #line 33 "src/distribution/Student.birch"
  libbirch_function_("logpdf", "src/distribution/Student.birch", 33);
  #line 34 "src/distribution/Student.birch"
  libbirch_line_(34);
  #line 34 "src/distribution/Student.birch"
  return birch::logpdf_student_t(x, this->_u0957->value(), this->_u0956->value(), this->_u09632->value());
}

#line 37 "src/distribution/Student.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::Student::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 37 "src/distribution/Student.birch"
  libbirch_function_("logpdfLazy", "src/distribution/Student.birch", 37);
  #line 38 "src/distribution/Student.birch"
  libbirch_line_(38);
  #line 38 "src/distribution/Student.birch"
  return birch::logpdf_lazy_student_t(x, this->_u0957, this->_u0956, this->_u09632);
}

#line 41 "src/distribution/Student.birch"
std::optional<birch::type::Real> birch::type::Student::cdf(const birch::type::Real& x) {
  #line 41 "src/distribution/Student.birch"
  libbirch_function_("cdf", "src/distribution/Student.birch", 41);
  #line 42 "src/distribution/Student.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/Student.birch"
  return birch::cdf_student_t(x, this->_u0957->value(), this->_u0956->value(), this->_u09632->value());
}

#line 45 "src/distribution/Student.birch"
std::optional<birch::type::Real> birch::type::Student::quantile(const birch::type::Real& P) {
  #line 45 "src/distribution/Student.birch"
  libbirch_function_("quantile", "src/distribution/Student.birch", 45);
  #line 46 "src/distribution/Student.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/Student.birch"
  return birch::quantile_student_t(P, this->_u0957->value(), this->_u0956->value(), this->_u09632->value());
}

#line 49 "src/distribution/Student.birch"
void birch::type::Student::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 49 "src/distribution/Student.birch"
  libbirch_function_("write", "src/distribution/Student.birch", 49);
  #line 50 "src/distribution/Student.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/Student.birch"
  this->prune();
  #line 51 "src/distribution/Student.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/Student.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Student"));
  #line 52 "src/distribution/Student.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/Student.birch"
  buffer->set(birch::type::String("ν"), this->_u0957);
  #line 53 "src/distribution/Student.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/Student.birch"
  buffer->set(birch::type::String("μ"), this->_u0956);
  #line 54 "src/distribution/Student.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/Student.birch"
  buffer->set(birch::type::String("σ2"), this->_u09632);
}

#line 61 "src/distribution/Student.birch"
libbirch::Shared<birch::type::Student> birch::Student(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0957, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632) {
  #line 61 "src/distribution/Student.birch"
  libbirch_function_("Student", "src/distribution/Student.birch", 61);
  #line 63 "src/distribution/Student.birch"
  libbirch_line_(63);
  #line 63 "src/distribution/Student.birch"
  return birch::construct<libbirch::Shared<birch::type::Student>>(_u0957, _u0956, _u09632);
}

#line 69 "src/distribution/Student.birch"
libbirch::Shared<birch::type::Student> birch::Student(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0957) {
  #line 69 "src/distribution/Student.birch"
  libbirch_function_("Student", "src/distribution/Student.birch", 69);
  #line 70 "src/distribution/Student.birch"
  libbirch_line_(70);
  #line 70 "src/distribution/Student.birch"
  return birch::Student(_u0957, birch::box(0.0), birch::box(1.0));
}

#line 76 "src/distribution/Student.birch"
libbirch::Shared<birch::type::Student> birch::Student(const birch::type::Real& _u0957) {
  #line 76 "src/distribution/Student.birch"
  libbirch_function_("Student", "src/distribution/Student.birch", 76);
  #line 77 "src/distribution/Student.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/Student.birch"
  return birch::Student(birch::box(_u0957), birch::box(0.0), birch::box(1.0));
}

#line 83 "src/distribution/Student.birch"
libbirch::Shared<birch::type::Student> birch::Student(const birch::type::Real& _u0957, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632) {
  #line 83 "src/distribution/Student.birch"
  libbirch_function_("Student", "src/distribution/Student.birch", 83);
  #line 84 "src/distribution/Student.birch"
  libbirch_line_(84);
  #line 84 "src/distribution/Student.birch"
  return birch::Student(birch::box(_u0957), _u0956, _u09632);
}

#line 90 "src/distribution/Student.birch"
libbirch::Shared<birch::type::Student> birch::Student(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0957, const birch::type::Real& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632) {
  #line 90 "src/distribution/Student.birch"
  libbirch_function_("Student", "src/distribution/Student.birch", 90);
  #line 91 "src/distribution/Student.birch"
  libbirch_line_(91);
  #line 91 "src/distribution/Student.birch"
  return birch::Student(_u0957, birch::box(_u0956), _u09632);
}

#line 97 "src/distribution/Student.birch"
libbirch::Shared<birch::type::Student> birch::Student(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0957, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0956, const birch::type::Real& _u09632) {
  #line 97 "src/distribution/Student.birch"
  libbirch_function_("Student", "src/distribution/Student.birch", 97);
  #line 98 "src/distribution/Student.birch"
  libbirch_line_(98);
  #line 98 "src/distribution/Student.birch"
  return birch::Student(_u0957, _u0956, birch::box(_u09632));
}

#line 104 "src/distribution/Student.birch"
libbirch::Shared<birch::type::Student> birch::Student(const birch::type::Real& _u0957, const birch::type::Real& _u0956, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u09632) {
  #line 104 "src/distribution/Student.birch"
  libbirch_function_("Student", "src/distribution/Student.birch", 104);
  #line 105 "src/distribution/Student.birch"
  libbirch_line_(105);
  #line 105 "src/distribution/Student.birch"
  return birch::Student(birch::box(_u0957), birch::box(_u0956), _u09632);
}

#line 111 "src/distribution/Student.birch"
libbirch::Shared<birch::type::Student> birch::Student(const birch::type::Real& _u0957, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0956, const birch::type::Real& _u09632) {
  #line 111 "src/distribution/Student.birch"
  libbirch_function_("Student", "src/distribution/Student.birch", 111);
  #line 112 "src/distribution/Student.birch"
  libbirch_line_(112);
  #line 112 "src/distribution/Student.birch"
  return birch::Student(birch::box(_u0957), _u0956, birch::box(_u09632));
}

#line 118 "src/distribution/Student.birch"
libbirch::Shared<birch::type::Student> birch::Student(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0957, const birch::type::Real& _u0956, const birch::type::Real& _u09632) {
  #line 118 "src/distribution/Student.birch"
  libbirch_function_("Student", "src/distribution/Student.birch", 118);
  #line 119 "src/distribution/Student.birch"
  libbirch_line_(119);
  #line 119 "src/distribution/Student.birch"
  return birch::Student(_u0957, birch::box(_u0956), birch::box(_u09632));
}

#line 125 "src/distribution/Student.birch"
libbirch::Shared<birch::type::Student> birch::Student(const birch::type::Real& _u0957, const birch::type::Real& _u0956, const birch::type::Real& _u09632) {
  #line 125 "src/distribution/Student.birch"
  libbirch_function_("Student", "src/distribution/Student.birch", 125);
  #line 126 "src/distribution/Student.birch"
  libbirch_line_(126);
  #line 126 "src/distribution/Student.birch"
  return birch::Student(birch::box(_u0957), birch::box(_u0956), birch::box(_u09632));
}

#line 5 "src/distribution/SubtractBoundedDiscrete.birch"
birch::type::SubtractBoundedDiscrete::SubtractBoundedDiscrete(const libbirch::Shared<birch::type::BoundedDiscrete>& x1, const libbirch::Shared<birch::type::BoundedDiscrete>& x2) :
    #line 5 "src/distribution/SubtractBoundedDiscrete.birch"
    base_type_(),
    #line 10 "src/distribution/SubtractBoundedDiscrete.birch"
    x1(std::move(x1)),
    #line 15 "src/distribution/SubtractBoundedDiscrete.birch"
    x2(std::move(x2)),
    #line 20 "src/distribution/SubtractBoundedDiscrete.birch"
    x(libbirch::make<std::optional<birch::type::Integer>>()),
    #line 25 "src/distribution/SubtractBoundedDiscrete.birch"
    x0(libbirch::make<birch::type::Integer>()),
    #line 30 "src/distribution/SubtractBoundedDiscrete.birch"
    z(libbirch::make<libbirch::DefaultArray<birch::type::Real,1>>()),
    #line 35 "src/distribution/SubtractBoundedDiscrete.birch"
    Z(libbirch::make<birch::type::Real>()) {
  //
}

#line 37 "src/distribution/SubtractBoundedDiscrete.birch"
void birch::type::SubtractBoundedDiscrete::enumerate(const birch::type::Integer& x) {
  #line 37 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("enumerate", "src/distribution/SubtractBoundedDiscrete.birch", 37);
  #line 38 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(38);
  #line 38 "src/distribution/SubtractBoundedDiscrete.birch"
  if (!(this->x.has_value()) || this->x.value() != x) {
    #line 39 "src/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(39);
    #line 39 "src/distribution/SubtractBoundedDiscrete.birch"
    auto l = birch::max(this->x1->lower().value(), this->x2->lower().value() + x);
    #line 40 "src/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(40);
    #line 40 "src/distribution/SubtractBoundedDiscrete.birch"
    auto u = birch::min(this->x1->upper().value(), this->x2->upper().value() + x);
    #line 42 "src/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(42);
    #line 42 "src/distribution/SubtractBoundedDiscrete.birch"
    this->x0 = l;
    #line 43 "src/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(43);
    #line 43 "src/distribution/SubtractBoundedDiscrete.birch"
    this->Z = 0.0;
    #line 44 "src/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(44);
    #line 44 "src/distribution/SubtractBoundedDiscrete.birch"
    if (l <= u) {
      #line 46 "src/distribution/SubtractBoundedDiscrete.birch"
      libbirch_line_(46);
      #line 46 "src/distribution/SubtractBoundedDiscrete.birch"
      this->z = birch::vector(0.0, u - l + birch::type::Integer(1));
      #line 47 "src/distribution/SubtractBoundedDiscrete.birch"
      libbirch_line_(47);
      #line 47 "src/distribution/SubtractBoundedDiscrete.birch"
      for (auto n = l; n <= u; ++n) {
        #line 48 "src/distribution/SubtractBoundedDiscrete.birch"
        libbirch_line_(48);
        #line 48 "src/distribution/SubtractBoundedDiscrete.birch"
        this->z(n - l + birch::type::Integer(1)) = this->x1->pdf(n) * this->x2->pdf(n - x);
        #line 49 "src/distribution/SubtractBoundedDiscrete.birch"
        libbirch_line_(49);
        #line 49 "src/distribution/SubtractBoundedDiscrete.birch"
        this->Z = this->Z + this->z(n - l + birch::type::Integer(1));
      }
    }
    #line 52 "src/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(52);
    #line 52 "src/distribution/SubtractBoundedDiscrete.birch"
    this->x = x;
  }
}

#line 56 "src/distribution/SubtractBoundedDiscrete.birch"
birch::type::Boolean birch::type::SubtractBoundedDiscrete::supportsLazy() {
  #line 56 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("supportsLazy", "src/distribution/SubtractBoundedDiscrete.birch", 56);
  #line 57 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/SubtractBoundedDiscrete.birch"
  return false;
}

#line 60 "src/distribution/SubtractBoundedDiscrete.birch"
birch::type::Integer birch::type::SubtractBoundedDiscrete::simulate() {
  #line 60 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("simulate", "src/distribution/SubtractBoundedDiscrete.birch", 60);
  #line 61 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/SubtractBoundedDiscrete.birch"
  return birch::simulate_delta(this->x1->simulate() - this->x2->simulate());
}

#line 68 "src/distribution/SubtractBoundedDiscrete.birch"
birch::type::Real birch::type::SubtractBoundedDiscrete::logpdf(const birch::type::Integer& x) {
  #line 68 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("logpdf", "src/distribution/SubtractBoundedDiscrete.birch", 68);
  #line 69 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(69);
  #line 69 "src/distribution/SubtractBoundedDiscrete.birch"
  this->enumerate(x);
  #line 70 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(70);
  #line 70 "src/distribution/SubtractBoundedDiscrete.birch"
  return birch::log(this->Z);
}

#line 78 "src/distribution/SubtractBoundedDiscrete.birch"
void birch::type::SubtractBoundedDiscrete::update(const birch::type::Integer& x) {
  #line 78 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("update", "src/distribution/SubtractBoundedDiscrete.birch", 78);
  #line 80 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(80);
  #line 80 "src/distribution/SubtractBoundedDiscrete.birch"
  this->enumerate(x);
  #line 81 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(81);
  #line 81 "src/distribution/SubtractBoundedDiscrete.birch"
  auto n = birch::simulate_categorical(this->z, this->Z) + this->x0 - birch::type::Integer(1);
  #line 82 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(82);
  #line 82 "src/distribution/SubtractBoundedDiscrete.birch"
  this->x1->clamp(n);
  #line 83 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(83);
  #line 83 "src/distribution/SubtractBoundedDiscrete.birch"
  this->x2->clamp(n - x);
}

#line 90 "src/distribution/SubtractBoundedDiscrete.birch"
std::optional<birch::type::Real> birch::type::SubtractBoundedDiscrete::cdf(const birch::type::Integer& x) {
  #line 90 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("cdf", "src/distribution/SubtractBoundedDiscrete.birch", 90);
  #line 91 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(91);
  #line 91 "src/distribution/SubtractBoundedDiscrete.birch"
  auto P = 0.0;
  #line 92 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(92);
  #line 92 "src/distribution/SubtractBoundedDiscrete.birch"
  for (auto n = this->lower().value(); n <= x; ++n) {
    #line 93 "src/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(93);
    #line 93 "src/distribution/SubtractBoundedDiscrete.birch"
    P = P + this->pdf(n);
  }
  #line 95 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(95);
  #line 95 "src/distribution/SubtractBoundedDiscrete.birch"
  return P;
}

#line 98 "src/distribution/SubtractBoundedDiscrete.birch"
std::optional<birch::type::Integer> birch::type::SubtractBoundedDiscrete::lower() {
  #line 98 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("lower", "src/distribution/SubtractBoundedDiscrete.birch", 98);
  #line 99 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(99);
  #line 99 "src/distribution/SubtractBoundedDiscrete.birch"
  return this->x1->lower().value() - this->x2->upper().value();
}

#line 102 "src/distribution/SubtractBoundedDiscrete.birch"
std::optional<birch::type::Integer> birch::type::SubtractBoundedDiscrete::upper() {
  #line 102 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("upper", "src/distribution/SubtractBoundedDiscrete.birch", 102);
  #line 103 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(103);
  #line 103 "src/distribution/SubtractBoundedDiscrete.birch"
  return this->x1->upper().value() - this->x2->lower().value();
}

#line 106 "src/distribution/SubtractBoundedDiscrete.birch"
void birch::type::SubtractBoundedDiscrete::link() {
  #line 106 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("link", "src/distribution/SubtractBoundedDiscrete.birch", 106);
  #line 107 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(107);
  #line 107 "src/distribution/SubtractBoundedDiscrete.birch"
  this->x1->setChild(this->shared_from_this_());
  #line 108 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(108);
  #line 108 "src/distribution/SubtractBoundedDiscrete.birch"
  this->x2->setChild(this->shared_from_this_());
}

#line 111 "src/distribution/SubtractBoundedDiscrete.birch"
void birch::type::SubtractBoundedDiscrete::unlink() {
  #line 111 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("unlink", "src/distribution/SubtractBoundedDiscrete.birch", 111);
  #line 112 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(112);
  #line 112 "src/distribution/SubtractBoundedDiscrete.birch"
  this->x1->releaseChild(this->shared_from_this_());
  #line 113 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(113);
  #line 113 "src/distribution/SubtractBoundedDiscrete.birch"
  this->x2->releaseChild(this->shared_from_this_());
}

#line 117 "src/distribution/SubtractBoundedDiscrete.birch"
libbirch::Shared<birch::type::SubtractBoundedDiscrete> birch::SubtractBoundedDiscrete(const libbirch::Shared<birch::type::BoundedDiscrete>& x1, const libbirch::Shared<birch::type::BoundedDiscrete>& x2) {
  #line 117 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("SubtractBoundedDiscrete", "src/distribution/SubtractBoundedDiscrete.birch", 117);
  #line 119 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(119);
  #line 119 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch::Shared<birch::type::SubtractBoundedDiscrete> m = libbirch::make<libbirch::Shared<birch::type::SubtractBoundedDiscrete>>(std::in_place, x1, x2);
  #line 120 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(120);
  #line 120 "src/distribution/SubtractBoundedDiscrete.birch"
  m->link();
  #line 121 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(121);
  #line 121 "src/distribution/SubtractBoundedDiscrete.birch"
  return m;
}

#line 4 "src/distribution/Uniform.birch"
birch::type::Uniform::Uniform(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& l, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& u) :
    #line 4 "src/distribution/Uniform.birch"
    base_type_(),
    #line 9 "src/distribution/Uniform.birch"
    l(std::move(l)),
    #line 14 "src/distribution/Uniform.birch"
    u(std::move(u)) {
  //
}

#line 16 "src/distribution/Uniform.birch"
birch::type::Boolean birch::type::Uniform::supportsLazy() {
  #line 16 "src/distribution/Uniform.birch"
  libbirch_function_("supportsLazy", "src/distribution/Uniform.birch", 16);
  #line 17 "src/distribution/Uniform.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/Uniform.birch"
  return false;
}

#line 20 "src/distribution/Uniform.birch"
birch::type::Real birch::type::Uniform::simulate() {
  #line 20 "src/distribution/Uniform.birch"
  libbirch_function_("simulate", "src/distribution/Uniform.birch", 20);
  #line 21 "src/distribution/Uniform.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/Uniform.birch"
  return birch::simulate_uniform(this->l->value(), this->u->value());
}

#line 28 "src/distribution/Uniform.birch"
birch::type::Real birch::type::Uniform::logpdf(const birch::type::Real& x) {
  #line 28 "src/distribution/Uniform.birch"
  libbirch_function_("logpdf", "src/distribution/Uniform.birch", 28);
  #line 29 "src/distribution/Uniform.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/Uniform.birch"
  return birch::logpdf_uniform(x, this->l->value(), this->u->value());
}

#line 36 "src/distribution/Uniform.birch"
std::optional<birch::type::Real> birch::type::Uniform::cdf(const birch::type::Real& x) {
  #line 36 "src/distribution/Uniform.birch"
  libbirch_function_("cdf", "src/distribution/Uniform.birch", 36);
  #line 37 "src/distribution/Uniform.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/Uniform.birch"
  return birch::cdf_uniform(x, this->l->value(), this->u->value());
}

#line 40 "src/distribution/Uniform.birch"
std::optional<birch::type::Real> birch::type::Uniform::quantile(const birch::type::Real& P) {
  #line 40 "src/distribution/Uniform.birch"
  libbirch_function_("quantile", "src/distribution/Uniform.birch", 40);
  #line 41 "src/distribution/Uniform.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/Uniform.birch"
  return birch::quantile_uniform(P, this->l->value(), this->u->value());
}

#line 44 "src/distribution/Uniform.birch"
std::optional<birch::type::Real> birch::type::Uniform::lower() {
  #line 44 "src/distribution/Uniform.birch"
  libbirch_function_("lower", "src/distribution/Uniform.birch", 44);
  #line 45 "src/distribution/Uniform.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/Uniform.birch"
  return this->l->value();
}

#line 48 "src/distribution/Uniform.birch"
std::optional<birch::type::Real> birch::type::Uniform::upper() {
  #line 48 "src/distribution/Uniform.birch"
  libbirch_function_("upper", "src/distribution/Uniform.birch", 48);
  #line 49 "src/distribution/Uniform.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/Uniform.birch"
  return this->u->value();
}

#line 52 "src/distribution/Uniform.birch"
void birch::type::Uniform::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 52 "src/distribution/Uniform.birch"
  libbirch_function_("write", "src/distribution/Uniform.birch", 52);
  #line 53 "src/distribution/Uniform.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/Uniform.birch"
  this->prune();
  #line 54 "src/distribution/Uniform.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/Uniform.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Uniform"));
  #line 55 "src/distribution/Uniform.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/Uniform.birch"
  buffer->set(birch::type::String("l"), this->l);
  #line 56 "src/distribution/Uniform.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/Uniform.birch"
  buffer->set(birch::type::String("u"), this->u);
}

#line 63 "src/distribution/Uniform.birch"
libbirch::Shared<birch::type::Uniform> birch::Uniform(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& l, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& u) {
  #line 63 "src/distribution/Uniform.birch"
  libbirch_function_("Uniform", "src/distribution/Uniform.birch", 63);
  #line 64 "src/distribution/Uniform.birch"
  libbirch_line_(64);
  #line 64 "src/distribution/Uniform.birch"
  return birch::construct<libbirch::Shared<birch::type::Uniform>>(l, u);
}

#line 70 "src/distribution/Uniform.birch"
libbirch::Shared<birch::type::Uniform> birch::Uniform(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& l, const birch::type::Real& u) {
  #line 70 "src/distribution/Uniform.birch"
  libbirch_function_("Uniform", "src/distribution/Uniform.birch", 70);
  #line 71 "src/distribution/Uniform.birch"
  libbirch_line_(71);
  #line 71 "src/distribution/Uniform.birch"
  return birch::Uniform(l, birch::box(u));
}

#line 77 "src/distribution/Uniform.birch"
libbirch::Shared<birch::type::Uniform> birch::Uniform(const birch::type::Real& l, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& u) {
  #line 77 "src/distribution/Uniform.birch"
  libbirch_function_("Uniform", "src/distribution/Uniform.birch", 77);
  #line 78 "src/distribution/Uniform.birch"
  libbirch_line_(78);
  #line 78 "src/distribution/Uniform.birch"
  return birch::Uniform(birch::box(l), u);
}

#line 84 "src/distribution/Uniform.birch"
libbirch::Shared<birch::type::Uniform> birch::Uniform(const birch::type::Real& l, const birch::type::Real& u) {
  #line 84 "src/distribution/Uniform.birch"
  libbirch_function_("Uniform", "src/distribution/Uniform.birch", 84);
  #line 85 "src/distribution/Uniform.birch"
  libbirch_line_(85);
  #line 85 "src/distribution/Uniform.birch"
  return birch::Uniform(birch::box(l), birch::box(u));
}

#line 4 "src/distribution/UniformInteger.birch"
birch::type::UniformInteger::UniformInteger(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& l, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& u) :
    #line 4 "src/distribution/UniformInteger.birch"
    base_type_(),
    #line 9 "src/distribution/UniformInteger.birch"
    l(std::move(l)),
    #line 14 "src/distribution/UniformInteger.birch"
    u(std::move(u)) {
  //
}

#line 16 "src/distribution/UniformInteger.birch"
birch::type::Boolean birch::type::UniformInteger::supportsLazy() {
  #line 16 "src/distribution/UniformInteger.birch"
  libbirch_function_("supportsLazy", "src/distribution/UniformInteger.birch", 16);
  #line 17 "src/distribution/UniformInteger.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/UniformInteger.birch"
  return false;
}

#line 20 "src/distribution/UniformInteger.birch"
birch::type::Integer birch::type::UniformInteger::simulate() {
  #line 20 "src/distribution/UniformInteger.birch"
  libbirch_function_("simulate", "src/distribution/UniformInteger.birch", 20);
  #line 21 "src/distribution/UniformInteger.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/UniformInteger.birch"
  return birch::simulate_uniform_int(this->l->value(), this->u->value());
}

#line 28 "src/distribution/UniformInteger.birch"
birch::type::Real birch::type::UniformInteger::logpdf(const birch::type::Integer& x) {
  #line 28 "src/distribution/UniformInteger.birch"
  libbirch_function_("logpdf", "src/distribution/UniformInteger.birch", 28);
  #line 29 "src/distribution/UniformInteger.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/UniformInteger.birch"
  return birch::logpdf_uniform_int(x, this->l->value(), this->u->value());
}

#line 36 "src/distribution/UniformInteger.birch"
std::optional<birch::type::Real> birch::type::UniformInteger::cdf(const birch::type::Integer& x) {
  #line 36 "src/distribution/UniformInteger.birch"
  libbirch_function_("cdf", "src/distribution/UniformInteger.birch", 36);
  #line 37 "src/distribution/UniformInteger.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/UniformInteger.birch"
  return birch::cdf_uniform_int(x, this->l->value(), this->u->value());
}

#line 40 "src/distribution/UniformInteger.birch"
std::optional<birch::type::Integer> birch::type::UniformInteger::quantile(const birch::type::Real& P) {
  #line 40 "src/distribution/UniformInteger.birch"
  libbirch_function_("quantile", "src/distribution/UniformInteger.birch", 40);
  #line 41 "src/distribution/UniformInteger.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/UniformInteger.birch"
  return birch::quantile_uniform_int(P, this->l->value(), this->u->value());
}

#line 44 "src/distribution/UniformInteger.birch"
std::optional<birch::type::Integer> birch::type::UniformInteger::lower() {
  #line 44 "src/distribution/UniformInteger.birch"
  libbirch_function_("lower", "src/distribution/UniformInteger.birch", 44);
  #line 45 "src/distribution/UniformInteger.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/UniformInteger.birch"
  return this->l->value();
}

#line 48 "src/distribution/UniformInteger.birch"
std::optional<birch::type::Integer> birch::type::UniformInteger::upper() {
  #line 48 "src/distribution/UniformInteger.birch"
  libbirch_function_("upper", "src/distribution/UniformInteger.birch", 48);
  #line 49 "src/distribution/UniformInteger.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/UniformInteger.birch"
  return this->u->value();
}

#line 52 "src/distribution/UniformInteger.birch"
void birch::type::UniformInteger::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 52 "src/distribution/UniformInteger.birch"
  libbirch_function_("write", "src/distribution/UniformInteger.birch", 52);
  #line 53 "src/distribution/UniformInteger.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/UniformInteger.birch"
  this->prune();
  #line 54 "src/distribution/UniformInteger.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/UniformInteger.birch"
  buffer->set(birch::type::String("class"), birch::type::String("UniformInteger"));
  #line 55 "src/distribution/UniformInteger.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/UniformInteger.birch"
  buffer->set(birch::type::String("l"), this->l);
  #line 56 "src/distribution/UniformInteger.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/UniformInteger.birch"
  buffer->set(birch::type::String("u"), this->u);
}

#line 63 "src/distribution/UniformInteger.birch"
libbirch::Shared<birch::type::UniformInteger> birch::Uniform(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& l, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& u) {
  #line 63 "src/distribution/UniformInteger.birch"
  libbirch_function_("Uniform", "src/distribution/UniformInteger.birch", 63);
  #line 65 "src/distribution/UniformInteger.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/UniformInteger.birch"
  return birch::construct<libbirch::Shared<birch::type::UniformInteger>>(l, u);
}

#line 71 "src/distribution/UniformInteger.birch"
libbirch::Shared<birch::type::UniformInteger> birch::Uniform(const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& l, const birch::type::Integer& u) {
  #line 71 "src/distribution/UniformInteger.birch"
  libbirch_function_("Uniform", "src/distribution/UniformInteger.birch", 71);
  #line 72 "src/distribution/UniformInteger.birch"
  libbirch_line_(72);
  #line 72 "src/distribution/UniformInteger.birch"
  return birch::Uniform(l, birch::box(u));
}

#line 78 "src/distribution/UniformInteger.birch"
libbirch::Shared<birch::type::UniformInteger> birch::Uniform(const birch::type::Integer& l, const libbirch::Shared<birch::type::Expression<birch::type::Integer>>& u) {
  #line 78 "src/distribution/UniformInteger.birch"
  libbirch_function_("Uniform", "src/distribution/UniformInteger.birch", 78);
  #line 79 "src/distribution/UniformInteger.birch"
  libbirch_line_(79);
  #line 79 "src/distribution/UniformInteger.birch"
  return birch::Uniform(birch::box(l), u);
}

#line 85 "src/distribution/UniformInteger.birch"
libbirch::Shared<birch::type::UniformInteger> birch::Uniform(const birch::type::Integer& l, const birch::type::Integer& u) {
  #line 85 "src/distribution/UniformInteger.birch"
  libbirch_function_("Uniform", "src/distribution/UniformInteger.birch", 85);
  #line 86 "src/distribution/UniformInteger.birch"
  libbirch_line_(86);
  #line 86 "src/distribution/UniformInteger.birch"
  return birch::Uniform(birch::box(l), birch::box(u));
}

#line 4 "src/distribution/Weibull.birch"
birch::type::Weibull::Weibull(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0955) :
    #line 4 "src/distribution/Weibull.birch"
    base_type_(),
    #line 9 "src/distribution/Weibull.birch"
    k(std::move(k)),
    #line 14 "src/distribution/Weibull.birch"
    _u0955(std::move(_u0955)) {
  //
}

#line 16 "src/distribution/Weibull.birch"
birch::type::Boolean birch::type::Weibull::supportsLazy() {
  #line 16 "src/distribution/Weibull.birch"
  libbirch_function_("supportsLazy", "src/distribution/Weibull.birch", 16);
  #line 17 "src/distribution/Weibull.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/Weibull.birch"
  return true;
}

#line 20 "src/distribution/Weibull.birch"
birch::type::Real birch::type::Weibull::simulate() {
  #line 20 "src/distribution/Weibull.birch"
  libbirch_function_("simulate", "src/distribution/Weibull.birch", 20);
  #line 21 "src/distribution/Weibull.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/Weibull.birch"
  return birch::simulate_weibull(this->k->value(), this->_u0955->value());
}

#line 24 "src/distribution/Weibull.birch"
std::optional<birch::type::Real> birch::type::Weibull::simulateLazy() {
  #line 24 "src/distribution/Weibull.birch"
  libbirch_function_("simulateLazy", "src/distribution/Weibull.birch", 24);
  #line 25 "src/distribution/Weibull.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/Weibull.birch"
  return birch::simulate_weibull(this->k->get(), this->_u0955->get());
}

#line 28 "src/distribution/Weibull.birch"
birch::type::Real birch::type::Weibull::logpdf(const birch::type::Real& x) {
  #line 28 "src/distribution/Weibull.birch"
  libbirch_function_("logpdf", "src/distribution/Weibull.birch", 28);
  #line 29 "src/distribution/Weibull.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/Weibull.birch"
  return birch::logpdf_weibull(x, this->k->value(), this->_u0955->value());
}

#line 32 "src/distribution/Weibull.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::Weibull::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& x) {
  #line 32 "src/distribution/Weibull.birch"
  libbirch_function_("logpdfLazy", "src/distribution/Weibull.birch", 32);
  #line 33 "src/distribution/Weibull.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/Weibull.birch"
  return birch::logpdf_lazy_weibull(x, this->k, this->_u0955);
}

#line 36 "src/distribution/Weibull.birch"
std::optional<birch::type::Real> birch::type::Weibull::cdf(const birch::type::Real& x) {
  #line 36 "src/distribution/Weibull.birch"
  libbirch_function_("cdf", "src/distribution/Weibull.birch", 36);
  #line 37 "src/distribution/Weibull.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/Weibull.birch"
  return birch::cdf_weibull(x, this->k->value(), this->_u0955->value());
}

#line 40 "src/distribution/Weibull.birch"
std::optional<birch::type::Real> birch::type::Weibull::quantile(const birch::type::Real& P) {
  #line 40 "src/distribution/Weibull.birch"
  libbirch_function_("quantile", "src/distribution/Weibull.birch", 40);
  #line 41 "src/distribution/Weibull.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/Weibull.birch"
  return birch::quantile_weibull(P, this->k->value(), this->_u0955->value());
}

#line 44 "src/distribution/Weibull.birch"
std::optional<birch::type::Real> birch::type::Weibull::lower() {
  #line 44 "src/distribution/Weibull.birch"
  libbirch_function_("lower", "src/distribution/Weibull.birch", 44);
  #line 45 "src/distribution/Weibull.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/Weibull.birch"
  return 0.0;
}

#line 48 "src/distribution/Weibull.birch"
void birch::type::Weibull::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 48 "src/distribution/Weibull.birch"
  libbirch_function_("write", "src/distribution/Weibull.birch", 48);
  #line 49 "src/distribution/Weibull.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/Weibull.birch"
  this->prune();
  #line 50 "src/distribution/Weibull.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/Weibull.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Weibull"));
  #line 51 "src/distribution/Weibull.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/Weibull.birch"
  buffer->set(birch::type::String("k"), this->k);
  #line 52 "src/distribution/Weibull.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/Weibull.birch"
  buffer->set(birch::type::String("λ"), this->_u0955);
}

#line 59 "src/distribution/Weibull.birch"
libbirch::Shared<birch::type::Weibull> birch::Weibull(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0955) {
  #line 59 "src/distribution/Weibull.birch"
  libbirch_function_("Weibull", "src/distribution/Weibull.birch", 59);
  #line 60 "src/distribution/Weibull.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/Weibull.birch"
  return birch::construct<libbirch::Shared<birch::type::Weibull>>(k, _u0955);
}

#line 66 "src/distribution/Weibull.birch"
libbirch::Shared<birch::type::Weibull> birch::Weibull(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k, const birch::type::Real& _u0955) {
  #line 66 "src/distribution/Weibull.birch"
  libbirch_function_("Weibull", "src/distribution/Weibull.birch", 66);
  #line 67 "src/distribution/Weibull.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/Weibull.birch"
  return birch::Weibull(k, birch::box(_u0955));
}

#line 73 "src/distribution/Weibull.birch"
libbirch::Shared<birch::type::Weibull> birch::Weibull(const birch::type::Real& k, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& _u0955) {
  #line 73 "src/distribution/Weibull.birch"
  libbirch_function_("Weibull", "src/distribution/Weibull.birch", 73);
  #line 74 "src/distribution/Weibull.birch"
  libbirch_line_(74);
  #line 74 "src/distribution/Weibull.birch"
  return birch::Weibull(birch::box(k), _u0955);
}

#line 80 "src/distribution/Weibull.birch"
libbirch::Shared<birch::type::Weibull> birch::Weibull(const birch::type::Real& k, const birch::type::Real& _u0955) {
  #line 80 "src/distribution/Weibull.birch"
  libbirch_function_("Weibull", "src/distribution/Weibull.birch", 80);
  #line 81 "src/distribution/Weibull.birch"
  libbirch_line_(81);
  #line 81 "src/distribution/Weibull.birch"
  return birch::Weibull(birch::box(k), birch::box(_u0955));
}

#line 4 "src/distribution/Wishart.birch"
birch::type::Wishart::Wishart(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& _u0936, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k) :
    #line 4 "src/distribution/Wishart.birch"
    base_type_(),
    #line 9 "src/distribution/Wishart.birch"
    _u0936(std::move(_u0936)),
    #line 14 "src/distribution/Wishart.birch"
    k(std::move(k)) {
  //
}

#line 16 "src/distribution/Wishart.birch"
birch::type::Integer birch::type::Wishart::rows() {
  #line 16 "src/distribution/Wishart.birch"
  libbirch_function_("rows", "src/distribution/Wishart.birch", 16);
  #line 17 "src/distribution/Wishart.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/Wishart.birch"
  return this->_u0936->rows();
}

#line 20 "src/distribution/Wishart.birch"
birch::type::Integer birch::type::Wishart::columns() {
  #line 20 "src/distribution/Wishart.birch"
  libbirch_function_("columns", "src/distribution/Wishart.birch", 20);
  #line 21 "src/distribution/Wishart.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/Wishart.birch"
  return this->_u0936->columns();
}

#line 24 "src/distribution/Wishart.birch"
birch::type::Boolean birch::type::Wishart::supportsLazy() {
  #line 24 "src/distribution/Wishart.birch"
  libbirch_function_("supportsLazy", "src/distribution/Wishart.birch", 24);
  #line 25 "src/distribution/Wishart.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/Wishart.birch"
  return true;
}

#line 28 "src/distribution/Wishart.birch"
birch::type::LLT birch::type::Wishart::simulate() {
  #line 28 "src/distribution/Wishart.birch"
  libbirch_function_("simulate", "src/distribution/Wishart.birch", 28);
  #line 29 "src/distribution/Wishart.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/Wishart.birch"
  return birch::simulate_wishart(this->_u0936->value(), this->k->value());
}

#line 32 "src/distribution/Wishart.birch"
std::optional<birch::type::LLT> birch::type::Wishart::simulateLazy() {
  #line 32 "src/distribution/Wishart.birch"
  libbirch_function_("simulateLazy", "src/distribution/Wishart.birch", 32);
  #line 33 "src/distribution/Wishart.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/Wishart.birch"
  return birch::simulate_wishart(this->_u0936->get(), this->k->get());
}

#line 36 "src/distribution/Wishart.birch"
birch::type::Real birch::type::Wishart::logpdf(const birch::type::LLT& X) {
  #line 36 "src/distribution/Wishart.birch"
  libbirch_function_("logpdf", "src/distribution/Wishart.birch", 36);
  #line 37 "src/distribution/Wishart.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/Wishart.birch"
  return birch::logpdf_wishart(X, this->_u0936->value(), this->k->value());
}

#line 40 "src/distribution/Wishart.birch"
std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::type::Wishart::logpdfLazy(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& X) {
  #line 40 "src/distribution/Wishart.birch"
  libbirch_function_("logpdfLazy", "src/distribution/Wishart.birch", 40);
  #line 41 "src/distribution/Wishart.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/Wishart.birch"
  return birch::logpdf_lazy_wishart(X, this->_u0936, this->k);
}

#line 44 "src/distribution/Wishart.birch"
std::optional<libbirch::Shared<birch::type::Wishart>> birch::type::Wishart::graftWishart() {
  #line 44 "src/distribution/Wishart.birch"
  libbirch_function_("graftWishart", "src/distribution/Wishart.birch", 44);
  #line 45 "src/distribution/Wishart.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/Wishart.birch"
  this->prune();
  #line 46 "src/distribution/Wishart.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/Wishart.birch"
  return this->shared_from_this_();
}

#line 49 "src/distribution/Wishart.birch"
void birch::type::Wishart::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 49 "src/distribution/Wishart.birch"
  libbirch_function_("write", "src/distribution/Wishart.birch", 49);
  #line 50 "src/distribution/Wishart.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/Wishart.birch"
  this->prune();
  #line 51 "src/distribution/Wishart.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/Wishart.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Wishart"));
  #line 52 "src/distribution/Wishart.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/Wishart.birch"
  buffer->set(birch::type::String("Ψ"), this->_u0936);
  #line 53 "src/distribution/Wishart.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/Wishart.birch"
  buffer->set(birch::type::String("k"), this->k);
}

#line 60 "src/distribution/Wishart.birch"
libbirch::Shared<birch::type::Wishart> birch::Wishart(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& _u0936, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k) {
  #line 60 "src/distribution/Wishart.birch"
  libbirch_function_("Wishart", "src/distribution/Wishart.birch", 60);
  #line 61 "src/distribution/Wishart.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/Wishart.birch"
  return birch::construct<libbirch::Shared<birch::type::Wishart>>(_u0936, k);
}

#line 67 "src/distribution/Wishart.birch"
libbirch::Shared<birch::type::Wishart> birch::Wishart(const libbirch::Shared<birch::type::Expression<birch::type::LLT>>& _u0936, const birch::type::Real& k) {
  #line 67 "src/distribution/Wishart.birch"
  libbirch_function_("Wishart", "src/distribution/Wishart.birch", 67);
  #line 68 "src/distribution/Wishart.birch"
  libbirch_line_(68);
  #line 68 "src/distribution/Wishart.birch"
  return birch::Wishart(_u0936, birch::box(k));
}

#line 74 "src/distribution/Wishart.birch"
libbirch::Shared<birch::type::Wishart> birch::Wishart(const birch::type::LLT& _u0936, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k) {
  #line 74 "src/distribution/Wishart.birch"
  libbirch_function_("Wishart", "src/distribution/Wishart.birch", 74);
  #line 75 "src/distribution/Wishart.birch"
  libbirch_line_(75);
  #line 75 "src/distribution/Wishart.birch"
  return birch::Wishart(birch::box(_u0936), k);
}

#line 81 "src/distribution/Wishart.birch"
libbirch::Shared<birch::type::Wishart> birch::Wishart(const birch::type::LLT& _u0936, const birch::type::Real& k) {
  #line 81 "src/distribution/Wishart.birch"
  libbirch_function_("Wishart", "src/distribution/Wishart.birch", 81);
  #line 82 "src/distribution/Wishart.birch"
  libbirch_line_(82);
  #line 82 "src/distribution/Wishart.birch"
  return birch::Wishart(birch::box(_u0936), birch::box(k));
}

#line 88 "src/distribution/Wishart.birch"
libbirch::Shared<birch::type::Wishart> birch::Wishart(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& _u0936, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k) {
  #line 88 "src/distribution/Wishart.birch"
  libbirch_function_("Wishart", "src/distribution/Wishart.birch", 88);
  #line 89 "src/distribution/Wishart.birch"
  libbirch_line_(89);
  #line 89 "src/distribution/Wishart.birch"
  return birch::Wishart(birch::llt(_u0936), k);
}

#line 95 "src/distribution/Wishart.birch"
libbirch::Shared<birch::type::Wishart> birch::Wishart(const libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>& _u0936, const birch::type::Real& k) {
  #line 95 "src/distribution/Wishart.birch"
  libbirch_function_("Wishart", "src/distribution/Wishart.birch", 95);
  #line 96 "src/distribution/Wishart.birch"
  libbirch_line_(96);
  #line 96 "src/distribution/Wishart.birch"
  return birch::Wishart(birch::llt(_u0936), k);
}

#line 102 "src/distribution/Wishart.birch"
libbirch::Shared<birch::type::Wishart> birch::Wishart(const libbirch::DefaultArray<birch::type::Real,2>& _u0936, const libbirch::Shared<birch::type::Expression<birch::type::Real>>& k) {
  #line 102 "src/distribution/Wishart.birch"
  libbirch_function_("Wishart", "src/distribution/Wishart.birch", 102);
  #line 103 "src/distribution/Wishart.birch"
  libbirch_line_(103);
  #line 103 "src/distribution/Wishart.birch"
  return birch::Wishart(birch::llt(_u0936), k);
}

#line 109 "src/distribution/Wishart.birch"
libbirch::Shared<birch::type::Wishart> birch::Wishart(const libbirch::DefaultArray<birch::type::Real,2>& _u0936, const birch::type::Real& k) {
  #line 109 "src/distribution/Wishart.birch"
  libbirch_function_("Wishart", "src/distribution/Wishart.birch", 109);
  #line 110 "src/distribution/Wishart.birch"
  libbirch_line_(110);
  #line 110 "src/distribution/Wishart.birch"
  return birch::Wishart(birch::llt(_u0936), k);
}

