#line 4 "src/distribution/AddBoundedDiscrete.birch"
birch::type::AddBoundedDiscrete::AddBoundedDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>& x1, const libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>& x2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/AddBoundedDiscrete.birch"
    super_type_(),
    #line 9 "src/distribution/AddBoundedDiscrete.birch"
    x1(x1),
    #line 14 "src/distribution/AddBoundedDiscrete.birch"
    x2(x2),
    #line 19 "src/distribution/AddBoundedDiscrete.birch"
    x(),
    #line 24 "src/distribution/AddBoundedDiscrete.birch"
    x0(),
    #line 30 "src/distribution/AddBoundedDiscrete.birch"
    z(),
    #line 35 "src/distribution/AddBoundedDiscrete.birch"
    Z(),
    #line 43 "src/distribution/AddBoundedDiscrete.birch"
    alreadyUpdated(false) {
  //
}

#line 45 "src/distribution/AddBoundedDiscrete.birch"
void birch::type::AddBoundedDiscrete::enumerate(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("enumerate", "src/distribution/AddBoundedDiscrete.birch", 45);
  #line 46 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/AddBoundedDiscrete.birch"
  if (!this_()->x.query() || this_()->x.get() != x) {
    #line 47 "src/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(47);
    #line 47 "src/distribution/AddBoundedDiscrete.birch"
    auto l = birch::max(this_()->x1->lower(handler_).get(), x - this_()->x2->upper(handler_).get(), handler_);
    #line 48 "src/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(48);
    #line 48 "src/distribution/AddBoundedDiscrete.birch"
    auto u = birch::min(this_()->x1->upper(handler_).get(), x - this_()->x2->lower(handler_).get(), handler_);
    #line 50 "src/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(50);
    #line 50 "src/distribution/AddBoundedDiscrete.birch"
    this_()->x0 = l;
    #line 51 "src/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(51);
    #line 51 "src/distribution/AddBoundedDiscrete.birch"
    this_()->Z = 0.0;
    #line 52 "src/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(52);
    #line 52 "src/distribution/AddBoundedDiscrete.birch"
    if (l <= u) {
      #line 54 "src/distribution/AddBoundedDiscrete.birch"
      libbirch_line_(54);
      #line 54 "src/distribution/AddBoundedDiscrete.birch"
      this_()->z = birch::vector(0.0, u - l + birch::type::Integer(1), handler_);
      #line 55 "src/distribution/AddBoundedDiscrete.birch"
      libbirch_line_(55);
      #line 55 "src/distribution/AddBoundedDiscrete.birch"
      for (auto n = l; n <= u; ++n) {
        #line 56 "src/distribution/AddBoundedDiscrete.birch"
        libbirch_line_(56);
        #line 56 "src/distribution/AddBoundedDiscrete.birch"
        this_()->z.set(libbirch::make_slice(n - l + birch::type::Integer(1) - 1), birch::exp(this_()->x1->logpdf(n, handler_) + this_()->x2->logpdf(x - n, handler_), handler_));
        #line 57 "src/distribution/AddBoundedDiscrete.birch"
        libbirch_line_(57);
        #line 57 "src/distribution/AddBoundedDiscrete.birch"
        this_()->Z = this_()->Z + this_()->z.get(libbirch::make_slice(n - l + birch::type::Integer(1) - 1));
      }
    }
    #line 60 "src/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(60);
    #line 60 "src/distribution/AddBoundedDiscrete.birch"
    this_()->x = x;
  }
}

#line 68 "src/distribution/AddBoundedDiscrete.birch"
birch::type::Integer birch::type::AddBoundedDiscrete::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 68 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("simulate", "src/distribution/AddBoundedDiscrete.birch", 68);
  #line 69 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(69);
  #line 69 "src/distribution/AddBoundedDiscrete.birch"
  if (this_()->value.query()) {
    #line 70 "src/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(70);
    #line 70 "src/distribution/AddBoundedDiscrete.birch"
    return birch::simulate_delta(this_()->value.get(), handler_);
  } else {
    #line 72 "src/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(72);
    #line 72 "src/distribution/AddBoundedDiscrete.birch"
    return birch::simulate_delta(this_()->x1->simulate(handler_) + this_()->x2->simulate(handler_), handler_);
  }
}

#line 84 "src/distribution/AddBoundedDiscrete.birch"
birch::type::Real birch::type::AddBoundedDiscrete::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 84 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("logpdf", "src/distribution/AddBoundedDiscrete.birch", 84);
  #line 85 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(85);
  #line 85 "src/distribution/AddBoundedDiscrete.birch"
  if (this_()->value.query()) {
    #line 86 "src/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(86);
    #line 86 "src/distribution/AddBoundedDiscrete.birch"
    return birch::logpdf_delta(x, this_()->value.get(), handler_);
  } else {
    #line 88 "src/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(88);
    #line 88 "src/distribution/AddBoundedDiscrete.birch"
    this_()->enumerate(x, handler_);
    #line 89 "src/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(89);
    #line 89 "src/distribution/AddBoundedDiscrete.birch"
    return birch::log(this_()->Z, handler_);
  }
}

#line 102 "src/distribution/AddBoundedDiscrete.birch"
void birch::type::AddBoundedDiscrete::update(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 102 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("update", "src/distribution/AddBoundedDiscrete.birch", 102);
  #line 103 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(103);
  #line 103 "src/distribution/AddBoundedDiscrete.birch"
  if (!this_()->alreadyUpdated) {
    #line 105 "src/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(105);
    #line 105 "src/distribution/AddBoundedDiscrete.birch"
    this_()->enumerate(x, handler_);
    #line 106 "src/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(106);
    #line 106 "src/distribution/AddBoundedDiscrete.birch"
    auto n = birch::simulate_categorical(this_()->z, this_()->Z, handler_) + this_()->x0 - birch::type::Integer(1);
    #line 107 "src/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(107);
    #line 107 "src/distribution/AddBoundedDiscrete.birch"
    this_()->x1->clamp(n, handler_);
    #line 108 "src/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(108);
    #line 108 "src/distribution/AddBoundedDiscrete.birch"
    this_()->x2->clamp(x - n, handler_);
    #line 109 "src/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(109);
    #line 109 "src/distribution/AddBoundedDiscrete.birch"
    this_()->alreadyUpdated = true;
  }
}

#line 117 "src/distribution/AddBoundedDiscrete.birch"
libbirch::Optional<birch::type::Real> birch::type::AddBoundedDiscrete::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 117 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("cdf", "src/distribution/AddBoundedDiscrete.birch", 117);
  #line 118 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(118);
  #line 118 "src/distribution/AddBoundedDiscrete.birch"
  auto P = 0.0;
  #line 119 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(119);
  #line 119 "src/distribution/AddBoundedDiscrete.birch"
  for (auto n = this_()->lower(handler_).get(); n <= x; ++n) {
    #line 120 "src/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(120);
    #line 120 "src/distribution/AddBoundedDiscrete.birch"
    P = P + this_()->pdf(n, handler_);
  }
  #line 122 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(122);
  #line 122 "src/distribution/AddBoundedDiscrete.birch"
  return P;
}

#line 125 "src/distribution/AddBoundedDiscrete.birch"
libbirch::Optional<birch::type::Integer> birch::type::AddBoundedDiscrete::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 125 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("lower", "src/distribution/AddBoundedDiscrete.birch", 125);
  #line 126 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(126);
  #line 126 "src/distribution/AddBoundedDiscrete.birch"
  return this_()->x1->lower(handler_).get() + this_()->x2->lower(handler_).get();
}

#line 129 "src/distribution/AddBoundedDiscrete.birch"
libbirch::Optional<birch::type::Integer> birch::type::AddBoundedDiscrete::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 129 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("upper", "src/distribution/AddBoundedDiscrete.birch", 129);
  #line 130 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(130);
  #line 130 "src/distribution/AddBoundedDiscrete.birch"
  return this_()->x1->upper(handler_).get() + this_()->x2->upper(handler_).get();
}

#line 133 "src/distribution/AddBoundedDiscrete.birch"
void birch::type::AddBoundedDiscrete::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 133 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("link", "src/distribution/AddBoundedDiscrete.birch", 133);
}

#line 139 "src/distribution/AddBoundedDiscrete.birch"
void birch::type::AddBoundedDiscrete::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 139 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("unlink", "src/distribution/AddBoundedDiscrete.birch", 139);
}

#line 146 "src/distribution/AddBoundedDiscrete.birch"
libbirch::Lazy<libbirch::Shared<birch::type::AddBoundedDiscrete>> birch::AddBoundedDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>& x1, const libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>& x2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 146 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("AddBoundedDiscrete", "src/distribution/AddBoundedDiscrete.birch", 146);
  #line 148 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(148);
  #line 148 "src/distribution/AddBoundedDiscrete.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::AddBoundedDiscrete>> m(x1, x2);
  #line 149 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(149);
  #line 149 "src/distribution/AddBoundedDiscrete.birch"
  m->link(handler_);
  #line 150 "src/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(150);
  #line 150 "src/distribution/AddBoundedDiscrete.birch"
  return m;
}

#line 1 "src/distribution/Bernoulli.birch"
birch::type::Bernoulli::Bernoulli(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/distribution/Bernoulli.birch"
    super_type_(),
    #line 8 "src/distribution/Bernoulli.birch"
    _u0961(_u0961) {
  //
}

#line 10 "src/distribution/Bernoulli.birch"
birch::type::Boolean birch::type::Bernoulli::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/distribution/Bernoulli.birch"
  libbirch_function_("supportsLazy", "src/distribution/Bernoulli.birch", 10);
  #line 11 "src/distribution/Bernoulli.birch"
  libbirch_line_(11);
  #line 11 "src/distribution/Bernoulli.birch"
  return true;
}

#line 14 "src/distribution/Bernoulli.birch"
birch::type::Boolean birch::type::Bernoulli::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/distribution/Bernoulli.birch"
  libbirch_function_("simulate", "src/distribution/Bernoulli.birch", 14);
  #line 15 "src/distribution/Bernoulli.birch"
  libbirch_line_(15);
  #line 15 "src/distribution/Bernoulli.birch"
  return birch::simulate_bernoulli(this_()->_u0961->value(handler_), handler_);
}

#line 18 "src/distribution/Bernoulli.birch"
libbirch::Optional<birch::type::Boolean> birch::type::Bernoulli::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/distribution/Bernoulli.birch"
  libbirch_function_("simulateLazy", "src/distribution/Bernoulli.birch", 18);
  #line 19 "src/distribution/Bernoulli.birch"
  libbirch_line_(19);
  #line 19 "src/distribution/Bernoulli.birch"
  return birch::simulate_bernoulli(this_()->_u0961->get(handler_), handler_);
}

#line 22 "src/distribution/Bernoulli.birch"
birch::type::Real birch::type::Bernoulli::logpdf(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/distribution/Bernoulli.birch"
  libbirch_function_("logpdf", "src/distribution/Bernoulli.birch", 22);
  #line 23 "src/distribution/Bernoulli.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/Bernoulli.birch"
  return birch::logpdf_bernoulli(x, this_()->_u0961->value(handler_), handler_);
}

#line 26 "src/distribution/Bernoulli.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::Bernoulli::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Boolean>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/distribution/Bernoulli.birch"
  libbirch_function_("logpdfLazy", "src/distribution/Bernoulli.birch", 26);
  #line 27 "src/distribution/Bernoulli.birch"
  libbirch_line_(27);
  #line 27 "src/distribution/Bernoulli.birch"
  return birch::logpdf_lazy_bernoulli(x, this_()->_u0961, handler_);
}

#line 30 "src/distribution/Bernoulli.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Boolean>>> birch::type::Bernoulli::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/distribution/Bernoulli.birch"
  libbirch_function_("graft", "src/distribution/Bernoulli.birch", 30);
  #line 31 "src/distribution/Bernoulli.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/Bernoulli.birch"
  this_()->prune(handler_);
  #line 32 "src/distribution/Bernoulli.birch"
  libbirch_line_(32);
  #line 32 "src/distribution/Bernoulli.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Beta>>> m;
  #line 33 "src/distribution/Bernoulli.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/Bernoulli.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Boolean>>> r = shared_from_this_();
  #line 36 "src/distribution/Bernoulli.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/Bernoulli.birch"
  if ((m = this_()->_u0961->graftBeta(handler_)).query()) {
    #line 37 "src/distribution/Bernoulli.birch"
    libbirch_line_(37);
    #line 37 "src/distribution/Bernoulli.birch"
    r = birch::BetaBernoulli(m.get(), handler_);
  }
  #line 40 "src/distribution/Bernoulli.birch"
  libbirch_line_(40);
  #line 40 "src/distribution/Bernoulli.birch"
  return r;
}

#line 43 "src/distribution/Bernoulli.birch"
void birch::type::Bernoulli::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "src/distribution/Bernoulli.birch"
  libbirch_function_("write", "src/distribution/Bernoulli.birch", 43);
  #line 44 "src/distribution/Bernoulli.birch"
  libbirch_line_(44);
  #line 44 "src/distribution/Bernoulli.birch"
  this_()->prune(handler_);
  #line 45 "src/distribution/Bernoulli.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/Bernoulli.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Bernoulli"), handler_);
  #line 46 "src/distribution/Bernoulli.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/Bernoulli.birch"
  buffer->set(birch::type::String("ρ"), this_()->_u0961, handler_);
}

#line 53 "src/distribution/Bernoulli.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Bernoulli>> birch::Bernoulli(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "src/distribution/Bernoulli.birch"
  libbirch_function_("Bernoulli", "src/distribution/Bernoulli.birch", 53);
  #line 54 "src/distribution/Bernoulli.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/Bernoulli.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Bernoulli>>>(_u0961, handler_);
}

#line 60 "src/distribution/Bernoulli.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Bernoulli>> birch::Bernoulli(const birch::type::Real& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "src/distribution/Bernoulli.birch"
  libbirch_function_("Bernoulli", "src/distribution/Bernoulli.birch", 60);
  #line 61 "src/distribution/Bernoulli.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/Bernoulli.birch"
  return birch::Bernoulli(birch::box(_u0961, handler_), handler_);
}

#line 4 "src/distribution/Beta.birch"
birch::type::Beta::Beta(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/Beta.birch"
    super_type_(),
    #line 9 "src/distribution/Beta.birch"
    _u0945(_u0945),
    #line 14 "src/distribution/Beta.birch"
    _u0946(_u0946) {
  //
}

#line 16 "src/distribution/Beta.birch"
birch::type::Boolean birch::type::Beta::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/distribution/Beta.birch"
  libbirch_function_("supportsLazy", "src/distribution/Beta.birch", 16);
  #line 17 "src/distribution/Beta.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/Beta.birch"
  return true;
}

#line 20 "src/distribution/Beta.birch"
birch::type::Real birch::type::Beta::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/distribution/Beta.birch"
  libbirch_function_("simulate", "src/distribution/Beta.birch", 20);
  #line 21 "src/distribution/Beta.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/Beta.birch"
  return birch::simulate_beta(this_()->_u0945->value(handler_), this_()->_u0946->value(handler_), handler_);
}

#line 24 "src/distribution/Beta.birch"
libbirch::Optional<birch::type::Real> birch::type::Beta::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/distribution/Beta.birch"
  libbirch_function_("simulateLazy", "src/distribution/Beta.birch", 24);
  #line 25 "src/distribution/Beta.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/Beta.birch"
  return birch::simulate_beta(this_()->_u0945->get(handler_), this_()->_u0946->get(handler_), handler_);
}

#line 28 "src/distribution/Beta.birch"
birch::type::Real birch::type::Beta::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/distribution/Beta.birch"
  libbirch_function_("logpdf", "src/distribution/Beta.birch", 28);
  #line 29 "src/distribution/Beta.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/Beta.birch"
  return birch::logpdf_beta(x, this_()->_u0945->value(handler_), this_()->_u0946->value(handler_), handler_);
}

#line 32 "src/distribution/Beta.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::Beta::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/distribution/Beta.birch"
  libbirch_function_("logpdfLazy", "src/distribution/Beta.birch", 32);
  #line 33 "src/distribution/Beta.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/Beta.birch"
  return birch::logpdf_lazy_beta(x, this_()->_u0945, this_()->_u0946, handler_);
}

#line 36 "src/distribution/Beta.birch"
libbirch::Optional<birch::type::Real> birch::type::Beta::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/distribution/Beta.birch"
  libbirch_function_("cdf", "src/distribution/Beta.birch", 36);
  #line 37 "src/distribution/Beta.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/Beta.birch"
  return birch::cdf_beta(x, this_()->_u0945->value(handler_), this_()->_u0946->value(handler_), handler_);
}

#line 40 "src/distribution/Beta.birch"
libbirch::Optional<birch::type::Real> birch::type::Beta::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "src/distribution/Beta.birch"
  libbirch_function_("quantile", "src/distribution/Beta.birch", 40);
  #line 41 "src/distribution/Beta.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/Beta.birch"
  return birch::quantile_beta(P, this_()->_u0945->value(handler_), this_()->_u0946->value(handler_), handler_);
}

#line 44 "src/distribution/Beta.birch"
libbirch::Optional<birch::type::Real> birch::type::Beta::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/distribution/Beta.birch"
  libbirch_function_("lower", "src/distribution/Beta.birch", 44);
  #line 45 "src/distribution/Beta.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/Beta.birch"
  return 0.0;
}

#line 48 "src/distribution/Beta.birch"
libbirch::Optional<birch::type::Real> birch::type::Beta::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "src/distribution/Beta.birch"
  libbirch_function_("upper", "src/distribution/Beta.birch", 48);
  #line 49 "src/distribution/Beta.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/Beta.birch"
  return 1.0;
}

#line 52 "src/distribution/Beta.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Beta>>> birch::type::Beta::graftBeta(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "src/distribution/Beta.birch"
  libbirch_function_("graftBeta", "src/distribution/Beta.birch", 52);
  #line 53 "src/distribution/Beta.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/Beta.birch"
  this_()->prune(handler_);
  #line 54 "src/distribution/Beta.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/Beta.birch"
  return shared_from_this_();
}

#line 57 "src/distribution/Beta.birch"
void birch::type::Beta::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 57 "src/distribution/Beta.birch"
  libbirch_function_("write", "src/distribution/Beta.birch", 57);
  #line 58 "src/distribution/Beta.birch"
  libbirch_line_(58);
  #line 58 "src/distribution/Beta.birch"
  this_()->prune(handler_);
  #line 59 "src/distribution/Beta.birch"
  libbirch_line_(59);
  #line 59 "src/distribution/Beta.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Beta"), handler_);
  #line 60 "src/distribution/Beta.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/Beta.birch"
  buffer->set(birch::type::String("α"), this_()->_u0945, handler_);
  #line 61 "src/distribution/Beta.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/Beta.birch"
  buffer->set(birch::type::String("β"), this_()->_u0946, handler_);
}

#line 68 "src/distribution/Beta.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Beta>> birch::Beta(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 68 "src/distribution/Beta.birch"
  libbirch_function_("Beta", "src/distribution/Beta.birch", 68);
  #line 69 "src/distribution/Beta.birch"
  libbirch_line_(69);
  #line 69 "src/distribution/Beta.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Beta>>>(_u0945, _u0946, handler_);
}

#line 75 "src/distribution/Beta.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Beta>> birch::Beta(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 75 "src/distribution/Beta.birch"
  libbirch_function_("Beta", "src/distribution/Beta.birch", 75);
  #line 76 "src/distribution/Beta.birch"
  libbirch_line_(76);
  #line 76 "src/distribution/Beta.birch"
  return birch::Beta(_u0945, birch::box(_u0946, handler_), handler_);
}

#line 82 "src/distribution/Beta.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Beta>> birch::Beta(const birch::type::Real& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 82 "src/distribution/Beta.birch"
  libbirch_function_("Beta", "src/distribution/Beta.birch", 82);
  #line 83 "src/distribution/Beta.birch"
  libbirch_line_(83);
  #line 83 "src/distribution/Beta.birch"
  return birch::Beta(birch::box(_u0945, handler_), _u0946, handler_);
}

#line 89 "src/distribution/Beta.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Beta>> birch::Beta(const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 89 "src/distribution/Beta.birch"
  libbirch_function_("Beta", "src/distribution/Beta.birch", 89);
  #line 90 "src/distribution/Beta.birch"
  libbirch_line_(90);
  #line 90 "src/distribution/Beta.birch"
  return birch::Beta(birch::box(_u0945, handler_), birch::box(_u0946, handler_), handler_);
}

#line 4 "src/distribution/BetaBernoulli.birch"
birch::type::BetaBernoulli::BetaBernoulli(const libbirch::Lazy<libbirch::Shared<birch::type::Beta>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/BetaBernoulli.birch"
    super_type_(),
    #line 8 "src/distribution/BetaBernoulli.birch"
    _u0961(_u0961) {
  //
}

#line 10 "src/distribution/BetaBernoulli.birch"
birch::type::Boolean birch::type::BetaBernoulli::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/distribution/BetaBernoulli.birch"
  libbirch_function_("supportsLazy", "src/distribution/BetaBernoulli.birch", 10);
  #line 11 "src/distribution/BetaBernoulli.birch"
  libbirch_line_(11);
  #line 11 "src/distribution/BetaBernoulli.birch"
  return true;
}

#line 14 "src/distribution/BetaBernoulli.birch"
birch::type::Boolean birch::type::BetaBernoulli::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/distribution/BetaBernoulli.birch"
  libbirch_function_("simulate", "src/distribution/BetaBernoulli.birch", 14);
  #line 15 "src/distribution/BetaBernoulli.birch"
  libbirch_line_(15);
  #line 15 "src/distribution/BetaBernoulli.birch"
  return birch::simulate_beta_bernoulli(this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0946->value(handler_), handler_);
}

#line 18 "src/distribution/BetaBernoulli.birch"
libbirch::Optional<birch::type::Boolean> birch::type::BetaBernoulli::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/distribution/BetaBernoulli.birch"
  libbirch_function_("simulateLazy", "src/distribution/BetaBernoulli.birch", 18);
  #line 19 "src/distribution/BetaBernoulli.birch"
  libbirch_line_(19);
  #line 19 "src/distribution/BetaBernoulli.birch"
  return birch::simulate_beta_bernoulli(this_()->_u0961->_u0945->get(handler_), this_()->_u0961->_u0946->get(handler_), handler_);
}

#line 22 "src/distribution/BetaBernoulli.birch"
birch::type::Real birch::type::BetaBernoulli::logpdf(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/distribution/BetaBernoulli.birch"
  libbirch_function_("logpdf", "src/distribution/BetaBernoulli.birch", 22);
  #line 23 "src/distribution/BetaBernoulli.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/BetaBernoulli.birch"
  return birch::logpdf_beta_bernoulli(x, this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0946->value(handler_), handler_);
}

#line 26 "src/distribution/BetaBernoulli.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::BetaBernoulli::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Boolean>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/distribution/BetaBernoulli.birch"
  libbirch_function_("logpdfLazy", "src/distribution/BetaBernoulli.birch", 26);
  #line 27 "src/distribution/BetaBernoulli.birch"
  libbirch_line_(27);
  #line 27 "src/distribution/BetaBernoulli.birch"
  return birch::logpdf_lazy_beta_bernoulli(x, this_()->_u0961->_u0945, this_()->_u0961->_u0946, handler_);
}

#line 30 "src/distribution/BetaBernoulli.birch"
void birch::type::BetaBernoulli::update(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/distribution/BetaBernoulli.birch"
  libbirch_function_("update", "src/distribution/BetaBernoulli.birch", 30);
  #line 31 "src/distribution/BetaBernoulli.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/BetaBernoulli.birch"
  libbirch::tie(this_()->_u0961->_u0945, this_()->_u0961->_u0946) = birch::box(birch::update_beta_bernoulli(x, this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0946->value(handler_), handler_), handler_);
}

#line 34 "src/distribution/BetaBernoulli.birch"
void birch::type::BetaBernoulli::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Boolean>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/distribution/BetaBernoulli.birch"
  libbirch_function_("updateLazy", "src/distribution/BetaBernoulli.birch", 34);
  #line 35 "src/distribution/BetaBernoulli.birch"
  libbirch_line_(35);
  #line 35 "src/distribution/BetaBernoulli.birch"
  libbirch::tie(this_()->_u0961->_u0945, this_()->_u0961->_u0946) = birch::update_lazy_beta_bernoulli(x, this_()->_u0961->_u0945, this_()->_u0961->_u0946, handler_);
}

#line 38 "src/distribution/BetaBernoulli.birch"
void birch::type::BetaBernoulli::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "src/distribution/BetaBernoulli.birch"
  libbirch_function_("link", "src/distribution/BetaBernoulli.birch", 38);
  #line 39 "src/distribution/BetaBernoulli.birch"
  libbirch_line_(39);
  #line 39 "src/distribution/BetaBernoulli.birch"
  this_()->_u0961->setChild(shared_from_this_(), handler_);
}

#line 42 "src/distribution/BetaBernoulli.birch"
void birch::type::BetaBernoulli::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/distribution/BetaBernoulli.birch"
  libbirch_function_("unlink", "src/distribution/BetaBernoulli.birch", 42);
  #line 43 "src/distribution/BetaBernoulli.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/BetaBernoulli.birch"
  this_()->_u0961->releaseChild(shared_from_this_(), handler_);
}

#line 47 "src/distribution/BetaBernoulli.birch"
libbirch::Lazy<libbirch::Shared<birch::type::BetaBernoulli>> birch::BetaBernoulli(const libbirch::Lazy<libbirch::Shared<birch::type::Beta>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "src/distribution/BetaBernoulli.birch"
  libbirch_function_("BetaBernoulli", "src/distribution/BetaBernoulli.birch", 47);
  #line 48 "src/distribution/BetaBernoulli.birch"
  libbirch_line_(48);
  #line 48 "src/distribution/BetaBernoulli.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::BetaBernoulli>> m(_u0961);
  #line 49 "src/distribution/BetaBernoulli.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/BetaBernoulli.birch"
  m->link(handler_);
  #line 50 "src/distribution/BetaBernoulli.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/BetaBernoulli.birch"
  return m;
}

#line 4 "src/distribution/BetaBinomial.birch"
birch::type::BetaBinomial::BetaBinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& n, const libbirch::Lazy<libbirch::Shared<birch::type::Beta>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/BetaBinomial.birch"
    super_type_(),
    #line 8 "src/distribution/BetaBinomial.birch"
    n(n),
    #line 13 "src/distribution/BetaBinomial.birch"
    _u0961(_u0961) {
  //
}

#line 15 "src/distribution/BetaBinomial.birch"
birch::type::Boolean birch::type::BetaBinomial::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/distribution/BetaBinomial.birch"
  libbirch_function_("supportsLazy", "src/distribution/BetaBinomial.birch", 15);
  #line 16 "src/distribution/BetaBinomial.birch"
  libbirch_line_(16);
  #line 16 "src/distribution/BetaBinomial.birch"
  return true;
}

#line 19 "src/distribution/BetaBinomial.birch"
birch::type::Integer birch::type::BetaBinomial::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/distribution/BetaBinomial.birch"
  libbirch_function_("simulate", "src/distribution/BetaBinomial.birch", 19);
  #line 20 "src/distribution/BetaBinomial.birch"
  libbirch_line_(20);
  #line 20 "src/distribution/BetaBinomial.birch"
  if (this_()->value.query()) {
    #line 21 "src/distribution/BetaBinomial.birch"
    libbirch_line_(21);
    #line 21 "src/distribution/BetaBinomial.birch"
    return this_()->value.get();
  } else {
    #line 23 "src/distribution/BetaBinomial.birch"
    libbirch_line_(23);
    #line 23 "src/distribution/BetaBinomial.birch"
    return birch::simulate_beta_binomial(this_()->n->value(handler_), this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0946->value(handler_), handler_);
  }
}

#line 27 "src/distribution/BetaBinomial.birch"
libbirch::Optional<birch::type::Integer> birch::type::BetaBinomial::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/distribution/BetaBinomial.birch"
  libbirch_function_("simulateLazy", "src/distribution/BetaBinomial.birch", 27);
  #line 28 "src/distribution/BetaBinomial.birch"
  libbirch_line_(28);
  #line 28 "src/distribution/BetaBinomial.birch"
  if (this_()->value.query()) {
    #line 29 "src/distribution/BetaBinomial.birch"
    libbirch_line_(29);
    #line 29 "src/distribution/BetaBinomial.birch"
    return this_()->value.get();
  } else {
    #line 31 "src/distribution/BetaBinomial.birch"
    libbirch_line_(31);
    #line 31 "src/distribution/BetaBinomial.birch"
    return birch::simulate_beta_binomial(this_()->n->get(handler_), this_()->_u0961->_u0945->get(handler_), this_()->_u0961->_u0946->get(handler_), handler_);
  }
}

#line 35 "src/distribution/BetaBinomial.birch"
birch::type::Real birch::type::BetaBinomial::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "src/distribution/BetaBinomial.birch"
  libbirch_function_("logpdf", "src/distribution/BetaBinomial.birch", 35);
  #line 36 "src/distribution/BetaBinomial.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/BetaBinomial.birch"
  return birch::logpdf_beta_binomial(x, this_()->n->value(handler_), this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0946->value(handler_), handler_);
}

#line 39 "src/distribution/BetaBinomial.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::BetaBinomial::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/distribution/BetaBinomial.birch"
  libbirch_function_("logpdfLazy", "src/distribution/BetaBinomial.birch", 39);
  #line 40 "src/distribution/BetaBinomial.birch"
  libbirch_line_(40);
  #line 40 "src/distribution/BetaBinomial.birch"
  return birch::logpdf_lazy_beta_binomial(x, this_()->n, this_()->_u0961->_u0945, this_()->_u0961->_u0946, handler_);
}

#line 43 "src/distribution/BetaBinomial.birch"
void birch::type::BetaBinomial::update(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "src/distribution/BetaBinomial.birch"
  libbirch_function_("update", "src/distribution/BetaBinomial.birch", 43);
  #line 44 "src/distribution/BetaBinomial.birch"
  libbirch_line_(44);
  #line 44 "src/distribution/BetaBinomial.birch"
  libbirch::tie(this_()->_u0961->_u0945, this_()->_u0961->_u0946) = birch::box(birch::update_beta_binomial(x, this_()->n->value(handler_), this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0946->value(handler_), handler_), handler_);
}

#line 47 "src/distribution/BetaBinomial.birch"
void birch::type::BetaBinomial::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "src/distribution/BetaBinomial.birch"
  libbirch_function_("updateLazy", "src/distribution/BetaBinomial.birch", 47);
  #line 48 "src/distribution/BetaBinomial.birch"
  libbirch_line_(48);
  #line 48 "src/distribution/BetaBinomial.birch"
  libbirch::tie(this_()->_u0961->_u0945, this_()->_u0961->_u0946) = birch::update_lazy_beta_binomial(x, this_()->n, this_()->_u0961->_u0945, this_()->_u0961->_u0946, handler_);
}

#line 51 "src/distribution/BetaBinomial.birch"
libbirch::Optional<birch::type::Real> birch::type::BetaBinomial::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 51 "src/distribution/BetaBinomial.birch"
  libbirch_function_("cdf", "src/distribution/BetaBinomial.birch", 51);
  #line 52 "src/distribution/BetaBinomial.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/BetaBinomial.birch"
  return birch::cdf_beta_binomial(x, this_()->n->value(handler_), this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0946->value(handler_), handler_);
}

#line 55 "src/distribution/BetaBinomial.birch"
libbirch::Optional<birch::type::Integer> birch::type::BetaBinomial::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 55 "src/distribution/BetaBinomial.birch"
  libbirch_function_("lower", "src/distribution/BetaBinomial.birch", 55);
  #line 56 "src/distribution/BetaBinomial.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/BetaBinomial.birch"
  return birch::type::Integer(0);
}

#line 59 "src/distribution/BetaBinomial.birch"
libbirch::Optional<birch::type::Integer> birch::type::BetaBinomial::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/distribution/BetaBinomial.birch"
  libbirch_function_("upper", "src/distribution/BetaBinomial.birch", 59);
  #line 60 "src/distribution/BetaBinomial.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/BetaBinomial.birch"
  return this_()->n->value(handler_);
}

#line 63 "src/distribution/BetaBinomial.birch"
void birch::type::BetaBinomial::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 63 "src/distribution/BetaBinomial.birch"
  libbirch_function_("link", "src/distribution/BetaBinomial.birch", 63);
  #line 64 "src/distribution/BetaBinomial.birch"
  libbirch_line_(64);
  #line 64 "src/distribution/BetaBinomial.birch"
  this_()->_u0961->setChild(shared_from_this_(), handler_);
}

#line 67 "src/distribution/BetaBinomial.birch"
void birch::type::BetaBinomial::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 67 "src/distribution/BetaBinomial.birch"
  libbirch_function_("unlink", "src/distribution/BetaBinomial.birch", 67);
  #line 68 "src/distribution/BetaBinomial.birch"
  libbirch_line_(68);
  #line 68 "src/distribution/BetaBinomial.birch"
  this_()->_u0961->releaseChild(shared_from_this_(), handler_);
}

#line 72 "src/distribution/BetaBinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::BetaBinomial>> birch::BetaBinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& n, const libbirch::Lazy<libbirch::Shared<birch::type::Beta>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "src/distribution/BetaBinomial.birch"
  libbirch_function_("BetaBinomial", "src/distribution/BetaBinomial.birch", 72);
  #line 73 "src/distribution/BetaBinomial.birch"
  libbirch_line_(73);
  #line 73 "src/distribution/BetaBinomial.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::BetaBinomial>> m(n, _u0961);
  #line 74 "src/distribution/BetaBinomial.birch"
  libbirch_line_(74);
  #line 74 "src/distribution/BetaBinomial.birch"
  m->link(handler_);
  #line 75 "src/distribution/BetaBinomial.birch"
  libbirch_line_(75);
  #line 75 "src/distribution/BetaBinomial.birch"
  return m;
}

#line 4 "src/distribution/BetaNegativeBinomial.birch"
birch::type::BetaNegativeBinomial::BetaNegativeBinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Beta>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/BetaNegativeBinomial.birch"
    super_type_(),
    #line 8 "src/distribution/BetaNegativeBinomial.birch"
    k(k),
    #line 13 "src/distribution/BetaNegativeBinomial.birch"
    _u0961(_u0961) {
  //
}

#line 15 "src/distribution/BetaNegativeBinomial.birch"
birch::type::Boolean birch::type::BetaNegativeBinomial::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("supportsLazy", "src/distribution/BetaNegativeBinomial.birch", 15);
  #line 16 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(16);
  #line 16 "src/distribution/BetaNegativeBinomial.birch"
  return true;
}

#line 19 "src/distribution/BetaNegativeBinomial.birch"
birch::type::Integer birch::type::BetaNegativeBinomial::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("simulate", "src/distribution/BetaNegativeBinomial.birch", 19);
  #line 20 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(20);
  #line 20 "src/distribution/BetaNegativeBinomial.birch"
  if (this_()->value.query()) {
    #line 21 "src/distribution/BetaNegativeBinomial.birch"
    libbirch_line_(21);
    #line 21 "src/distribution/BetaNegativeBinomial.birch"
    return this_()->value.get();
  } else {
    #line 23 "src/distribution/BetaNegativeBinomial.birch"
    libbirch_line_(23);
    #line 23 "src/distribution/BetaNegativeBinomial.birch"
    return birch::simulate_beta_negative_binomial(this_()->k->value(handler_), this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0946->value(handler_), handler_);
  }
}

#line 27 "src/distribution/BetaNegativeBinomial.birch"
libbirch::Optional<birch::type::Integer> birch::type::BetaNegativeBinomial::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("simulateLazy", "src/distribution/BetaNegativeBinomial.birch", 27);
  #line 28 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(28);
  #line 28 "src/distribution/BetaNegativeBinomial.birch"
  if (this_()->value.query()) {
    #line 29 "src/distribution/BetaNegativeBinomial.birch"
    libbirch_line_(29);
    #line 29 "src/distribution/BetaNegativeBinomial.birch"
    return this_()->value.get();
  } else {
    #line 31 "src/distribution/BetaNegativeBinomial.birch"
    libbirch_line_(31);
    #line 31 "src/distribution/BetaNegativeBinomial.birch"
    return birch::simulate_beta_negative_binomial(this_()->k->get(handler_), this_()->_u0961->_u0945->get(handler_), this_()->_u0961->_u0946->get(handler_), handler_);
  }
}

#line 35 "src/distribution/BetaNegativeBinomial.birch"
birch::type::Real birch::type::BetaNegativeBinomial::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("logpdf", "src/distribution/BetaNegativeBinomial.birch", 35);
  #line 36 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/BetaNegativeBinomial.birch"
  return birch::logpdf_beta_negative_binomial(x, this_()->k->value(handler_), this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0946->value(handler_), handler_);
}

#line 39 "src/distribution/BetaNegativeBinomial.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::BetaNegativeBinomial::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("logpdfLazy", "src/distribution/BetaNegativeBinomial.birch", 39);
  #line 40 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(40);
  #line 40 "src/distribution/BetaNegativeBinomial.birch"
  return birch::logpdf_lazy_beta_negative_binomial(x, this_()->k, this_()->_u0961->_u0945, this_()->_u0961->_u0946, handler_);
}

#line 43 "src/distribution/BetaNegativeBinomial.birch"
void birch::type::BetaNegativeBinomial::update(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("update", "src/distribution/BetaNegativeBinomial.birch", 43);
  #line 44 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(44);
  #line 44 "src/distribution/BetaNegativeBinomial.birch"
  libbirch::tie(this_()->_u0961->_u0945, this_()->_u0961->_u0946) = birch::box(birch::update_beta_negative_binomial(x, this_()->k->value(handler_), this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0946->value(handler_), handler_), handler_);
}

#line 47 "src/distribution/BetaNegativeBinomial.birch"
void birch::type::BetaNegativeBinomial::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("updateLazy", "src/distribution/BetaNegativeBinomial.birch", 47);
  #line 48 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(48);
  #line 48 "src/distribution/BetaNegativeBinomial.birch"
  libbirch::tie(this_()->_u0961->_u0945, this_()->_u0961->_u0946) = birch::update_lazy_beta_negative_binomial(x, this_()->k, this_()->_u0961->_u0945, this_()->_u0961->_u0946, handler_);
}

#line 51 "src/distribution/BetaNegativeBinomial.birch"
libbirch::Optional<birch::type::Integer> birch::type::BetaNegativeBinomial::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 51 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("lower", "src/distribution/BetaNegativeBinomial.birch", 51);
  #line 52 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/BetaNegativeBinomial.birch"
  return birch::type::Integer(0);
}

#line 55 "src/distribution/BetaNegativeBinomial.birch"
void birch::type::BetaNegativeBinomial::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 55 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("link", "src/distribution/BetaNegativeBinomial.birch", 55);
  #line 56 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/BetaNegativeBinomial.birch"
  this_()->_u0961->setChild(shared_from_this_(), handler_);
}

#line 59 "src/distribution/BetaNegativeBinomial.birch"
void birch::type::BetaNegativeBinomial::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("unlink", "src/distribution/BetaNegativeBinomial.birch", 59);
  #line 60 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/BetaNegativeBinomial.birch"
  this_()->_u0961->releaseChild(shared_from_this_(), handler_);
}

#line 64 "src/distribution/BetaNegativeBinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::BetaNegativeBinomial>> birch::BetaNegativeBinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Beta>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("BetaNegativeBinomial", "src/distribution/BetaNegativeBinomial.birch", 64);
  #line 66 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/BetaNegativeBinomial.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::BetaNegativeBinomial>> m(k, _u0961);
  #line 67 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/BetaNegativeBinomial.birch"
  m->link(handler_);
  #line 68 "src/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(68);
  #line 68 "src/distribution/BetaNegativeBinomial.birch"
  return m;
}

#line 1 "src/distribution/Binomial.birch"
birch::type::Binomial::Binomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& n, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/distribution/Binomial.birch"
    super_type_(),
    #line 8 "src/distribution/Binomial.birch"
    n(n),
    #line 13 "src/distribution/Binomial.birch"
    _u0961(_u0961) {
  //
}

#line 15 "src/distribution/Binomial.birch"
birch::type::Boolean birch::type::Binomial::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/distribution/Binomial.birch"
  libbirch_function_("supportsLazy", "src/distribution/Binomial.birch", 15);
  #line 16 "src/distribution/Binomial.birch"
  libbirch_line_(16);
  #line 16 "src/distribution/Binomial.birch"
  return true;
}

#line 19 "src/distribution/Binomial.birch"
birch::type::Integer birch::type::Binomial::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/distribution/Binomial.birch"
  libbirch_function_("simulate", "src/distribution/Binomial.birch", 19);
  #line 20 "src/distribution/Binomial.birch"
  libbirch_line_(20);
  #line 20 "src/distribution/Binomial.birch"
  if (this_()->value.query()) {
    #line 21 "src/distribution/Binomial.birch"
    libbirch_line_(21);
    #line 21 "src/distribution/Binomial.birch"
    return this_()->value.get();
  } else {
    #line 23 "src/distribution/Binomial.birch"
    libbirch_line_(23);
    #line 23 "src/distribution/Binomial.birch"
    return birch::simulate_binomial(this_()->n->value(handler_), this_()->_u0961->value(handler_), handler_);
  }
}

#line 27 "src/distribution/Binomial.birch"
libbirch::Optional<birch::type::Integer> birch::type::Binomial::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/distribution/Binomial.birch"
  libbirch_function_("simulateLazy", "src/distribution/Binomial.birch", 27);
  #line 28 "src/distribution/Binomial.birch"
  libbirch_line_(28);
  #line 28 "src/distribution/Binomial.birch"
  if (this_()->value.query()) {
    #line 29 "src/distribution/Binomial.birch"
    libbirch_line_(29);
    #line 29 "src/distribution/Binomial.birch"
    return this_()->value.get();
  } else {
    #line 31 "src/distribution/Binomial.birch"
    libbirch_line_(31);
    #line 31 "src/distribution/Binomial.birch"
    return birch::simulate_binomial(this_()->n->get(handler_), this_()->_u0961->get(handler_), handler_);
  }
}

#line 35 "src/distribution/Binomial.birch"
birch::type::Real birch::type::Binomial::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "src/distribution/Binomial.birch"
  libbirch_function_("logpdf", "src/distribution/Binomial.birch", 35);
  #line 36 "src/distribution/Binomial.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/Binomial.birch"
  return birch::logpdf_binomial(x, this_()->n->value(handler_), this_()->_u0961->value(handler_), handler_);
}

#line 39 "src/distribution/Binomial.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::Binomial::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/distribution/Binomial.birch"
  libbirch_function_("logpdfLazy", "src/distribution/Binomial.birch", 39);
  #line 40 "src/distribution/Binomial.birch"
  libbirch_line_(40);
  #line 40 "src/distribution/Binomial.birch"
  return birch::logpdf_lazy_binomial(x, this_()->n, this_()->_u0961, handler_);
}

#line 43 "src/distribution/Binomial.birch"
libbirch::Optional<birch::type::Real> birch::type::Binomial::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "src/distribution/Binomial.birch"
  libbirch_function_("cdf", "src/distribution/Binomial.birch", 43);
  #line 44 "src/distribution/Binomial.birch"
  libbirch_line_(44);
  #line 44 "src/distribution/Binomial.birch"
  return birch::cdf_binomial(x, this_()->n->value(handler_), this_()->_u0961->value(handler_), handler_);
}

#line 47 "src/distribution/Binomial.birch"
libbirch::Optional<birch::type::Integer> birch::type::Binomial::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "src/distribution/Binomial.birch"
  libbirch_function_("quantile", "src/distribution/Binomial.birch", 47);
  #line 48 "src/distribution/Binomial.birch"
  libbirch_line_(48);
  #line 48 "src/distribution/Binomial.birch"
  return birch::quantile_binomial(P, this_()->n->value(handler_), this_()->_u0961->value(handler_), handler_);
}

#line 51 "src/distribution/Binomial.birch"
libbirch::Optional<birch::type::Integer> birch::type::Binomial::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 51 "src/distribution/Binomial.birch"
  libbirch_function_("lower", "src/distribution/Binomial.birch", 51);
  #line 52 "src/distribution/Binomial.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/Binomial.birch"
  return birch::type::Integer(0);
}

#line 55 "src/distribution/Binomial.birch"
libbirch::Optional<birch::type::Integer> birch::type::Binomial::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 55 "src/distribution/Binomial.birch"
  libbirch_function_("upper", "src/distribution/Binomial.birch", 55);
  #line 56 "src/distribution/Binomial.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/Binomial.birch"
  return this_()->n->value(handler_);
}

#line 59 "src/distribution/Binomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> birch::type::Binomial::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/distribution/Binomial.birch"
  libbirch_function_("graft", "src/distribution/Binomial.birch", 59);
  #line 60 "src/distribution/Binomial.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/Binomial.birch"
  this_()->prune(handler_);
  #line 61 "src/distribution/Binomial.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/Binomial.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Beta>>> m;
  #line 62 "src/distribution/Binomial.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/Binomial.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> r = shared_from_this_();
  #line 65 "src/distribution/Binomial.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/Binomial.birch"
  if ((m = this_()->_u0961->graftBeta(handler_)).query()) {
    #line 66 "src/distribution/Binomial.birch"
    libbirch_line_(66);
    #line 66 "src/distribution/Binomial.birch"
    r = birch::BetaBinomial(this_()->n, m.get(), handler_);
  }
  #line 69 "src/distribution/Binomial.birch"
  libbirch_line_(69);
  #line 69 "src/distribution/Binomial.birch"
  return r;
}

#line 72 "src/distribution/Binomial.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>> birch::type::Binomial::graftDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "src/distribution/Binomial.birch"
  libbirch_function_("graftDiscrete", "src/distribution/Binomial.birch", 72);
  #line 73 "src/distribution/Binomial.birch"
  libbirch_line_(73);
  #line 73 "src/distribution/Binomial.birch"
  return libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>>(this_()->graft(handler_));
}

#line 76 "src/distribution/Binomial.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>> birch::type::Binomial::graftBoundedDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "src/distribution/Binomial.birch"
  libbirch_function_("graftBoundedDiscrete", "src/distribution/Binomial.birch", 76);
  #line 77 "src/distribution/Binomial.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/Binomial.birch"
  return libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>>(this_()->graft(handler_));
}

#line 80 "src/distribution/Binomial.birch"
void birch::type::Binomial::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 80 "src/distribution/Binomial.birch"
  libbirch_function_("write", "src/distribution/Binomial.birch", 80);
  #line 81 "src/distribution/Binomial.birch"
  libbirch_line_(81);
  #line 81 "src/distribution/Binomial.birch"
  this_()->prune(handler_);
  #line 82 "src/distribution/Binomial.birch"
  libbirch_line_(82);
  #line 82 "src/distribution/Binomial.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Binomial"), handler_);
  #line 83 "src/distribution/Binomial.birch"
  libbirch_line_(83);
  #line 83 "src/distribution/Binomial.birch"
  buffer->set(birch::type::String("n"), this_()->n, handler_);
  #line 84 "src/distribution/Binomial.birch"
  libbirch_line_(84);
  #line 84 "src/distribution/Binomial.birch"
  buffer->set(birch::type::String("ρ"), this_()->_u0961, handler_);
}

#line 91 "src/distribution/Binomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Binomial>> birch::Binomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& n, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 91 "src/distribution/Binomial.birch"
  libbirch_function_("Binomial", "src/distribution/Binomial.birch", 91);
  #line 92 "src/distribution/Binomial.birch"
  libbirch_line_(92);
  #line 92 "src/distribution/Binomial.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Binomial>>>(n, _u0961, handler_);
}

#line 98 "src/distribution/Binomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Binomial>> birch::Binomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& n, const birch::type::Real& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 98 "src/distribution/Binomial.birch"
  libbirch_function_("Binomial", "src/distribution/Binomial.birch", 98);
  #line 99 "src/distribution/Binomial.birch"
  libbirch_line_(99);
  #line 99 "src/distribution/Binomial.birch"
  return birch::Binomial(n, birch::box(_u0961, handler_), handler_);
}

#line 105 "src/distribution/Binomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Binomial>> birch::Binomial(const birch::type::Integer& n, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 105 "src/distribution/Binomial.birch"
  libbirch_function_("Binomial", "src/distribution/Binomial.birch", 105);
  #line 106 "src/distribution/Binomial.birch"
  libbirch_line_(106);
  #line 106 "src/distribution/Binomial.birch"
  return birch::Binomial(birch::box(n, handler_), _u0961, handler_);
}

#line 112 "src/distribution/Binomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Binomial>> birch::Binomial(const birch::type::Integer& n, const birch::type::Real& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 112 "src/distribution/Binomial.birch"
  libbirch_function_("Binomial", "src/distribution/Binomial.birch", 112);
  #line 113 "src/distribution/Binomial.birch"
  libbirch_line_(113);
  #line 113 "src/distribution/Binomial.birch"
  return birch::Binomial(birch::box(n, handler_), birch::box(_u0961, handler_), handler_);
}

#line 4 "src/distribution/BoundedDiscrete.birch"
birch::type::BoundedDiscrete::BoundedDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/BoundedDiscrete.birch"
    super_type_() {
  //
}

#line 8 "src/distribution/BoundedDiscrete.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>> birch::type::BoundedDiscrete::graftBoundedDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 8 "src/distribution/BoundedDiscrete.birch"
  libbirch_function_("graftBoundedDiscrete", "src/distribution/BoundedDiscrete.birch", 8);
  #line 9 "src/distribution/BoundedDiscrete.birch"
  libbirch_line_(9);
  #line 9 "src/distribution/BoundedDiscrete.birch"
  this_()->prune(handler_);
  #line 10 "src/distribution/BoundedDiscrete.birch"
  libbirch_line_(10);
  #line 10 "src/distribution/BoundedDiscrete.birch"
  return shared_from_this_();
}

#line 1 "src/distribution/Categorical.birch"
birch::type::Categorical::Categorical(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/distribution/Categorical.birch"
    super_type_(),
    #line 8 "src/distribution/Categorical.birch"
    _u0961(_u0961) {
  //
}

#line 10 "src/distribution/Categorical.birch"
birch::type::Boolean birch::type::Categorical::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/distribution/Categorical.birch"
  libbirch_function_("supportsLazy", "src/distribution/Categorical.birch", 10);
  #line 11 "src/distribution/Categorical.birch"
  libbirch_line_(11);
  #line 11 "src/distribution/Categorical.birch"
  return false;
}

#line 14 "src/distribution/Categorical.birch"
birch::type::Integer birch::type::Categorical::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/distribution/Categorical.birch"
  libbirch_function_("simulate", "src/distribution/Categorical.birch", 14);
  #line 15 "src/distribution/Categorical.birch"
  libbirch_line_(15);
  #line 15 "src/distribution/Categorical.birch"
  return birch::simulate_categorical(this_()->_u0961->value(handler_), handler_);
}

#line 22 "src/distribution/Categorical.birch"
birch::type::Real birch::type::Categorical::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/distribution/Categorical.birch"
  libbirch_function_("logpdf", "src/distribution/Categorical.birch", 22);
  #line 23 "src/distribution/Categorical.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/Categorical.birch"
  return birch::logpdf_categorical(x, this_()->_u0961->value(handler_), handler_);
}

#line 30 "src/distribution/Categorical.birch"
libbirch::Optional<birch::type::Real> birch::type::Categorical::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/distribution/Categorical.birch"
  libbirch_function_("cdf", "src/distribution/Categorical.birch", 30);
  #line 31 "src/distribution/Categorical.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/Categorical.birch"
  return birch::cdf_categorical(x, this_()->_u0961->value(handler_), handler_);
}

#line 34 "src/distribution/Categorical.birch"
libbirch::Optional<birch::type::Integer> birch::type::Categorical::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/distribution/Categorical.birch"
  libbirch_function_("quantile", "src/distribution/Categorical.birch", 34);
  #line 35 "src/distribution/Categorical.birch"
  libbirch_line_(35);
  #line 35 "src/distribution/Categorical.birch"
  return birch::quantile_categorical(P, this_()->_u0961->value(handler_), handler_);
}

#line 38 "src/distribution/Categorical.birch"
libbirch::Optional<birch::type::Integer> birch::type::Categorical::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "src/distribution/Categorical.birch"
  libbirch_function_("lower", "src/distribution/Categorical.birch", 38);
  #line 39 "src/distribution/Categorical.birch"
  libbirch_line_(39);
  #line 39 "src/distribution/Categorical.birch"
  return birch::type::Integer(1);
}

#line 42 "src/distribution/Categorical.birch"
libbirch::Optional<birch::type::Integer> birch::type::Categorical::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/distribution/Categorical.birch"
  libbirch_function_("upper", "src/distribution/Categorical.birch", 42);
  #line 43 "src/distribution/Categorical.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/Categorical.birch"
  return this_()->_u0961->rows(handler_);
}

#line 46 "src/distribution/Categorical.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> birch::type::Categorical::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/distribution/Categorical.birch"
  libbirch_function_("graft", "src/distribution/Categorical.birch", 46);
  #line 47 "src/distribution/Categorical.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/Categorical.birch"
  this_()->prune(handler_);
  #line 48 "src/distribution/Categorical.birch"
  libbirch_line_(48);
  #line 48 "src/distribution/Categorical.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Dirichlet>>> m1;
  #line 49 "src/distribution/Categorical.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/Categorical.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Restaurant>>> m2;
  #line 50 "src/distribution/Categorical.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/Categorical.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> r = shared_from_this_();
  #line 53 "src/distribution/Categorical.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/Categorical.birch"
  if ((m1 = this_()->_u0961->graftDirichlet(handler_)).query()) {
    #line 54 "src/distribution/Categorical.birch"
    libbirch_line_(54);
    #line 54 "src/distribution/Categorical.birch"
    r = birch::DirichletCategorical(m1.get(), handler_);
  } else {
    #line 55 "src/distribution/Categorical.birch"
    libbirch_line_(55);
    #line 55 "src/distribution/Categorical.birch"
    if ((m2 = this_()->_u0961->graftRestaurant(handler_)).query()) {
      #line 56 "src/distribution/Categorical.birch"
      libbirch_line_(56);
      #line 56 "src/distribution/Categorical.birch"
      r = birch::RestaurantCategorical(m2.get(), handler_);
    }
  }
  #line 59 "src/distribution/Categorical.birch"
  libbirch_line_(59);
  #line 59 "src/distribution/Categorical.birch"
  return r;
}

#line 62 "src/distribution/Categorical.birch"
void birch::type::Categorical::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 62 "src/distribution/Categorical.birch"
  libbirch_function_("write", "src/distribution/Categorical.birch", 62);
  #line 63 "src/distribution/Categorical.birch"
  libbirch_line_(63);
  #line 63 "src/distribution/Categorical.birch"
  this_()->prune(handler_);
  #line 64 "src/distribution/Categorical.birch"
  libbirch_line_(64);
  #line 64 "src/distribution/Categorical.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Categorical"), handler_);
  #line 65 "src/distribution/Categorical.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/Categorical.birch"
  buffer->set(birch::type::String("ρ"), this_()->_u0961, handler_);
}

#line 72 "src/distribution/Categorical.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Categorical>> birch::Categorical(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "src/distribution/Categorical.birch"
  libbirch_function_("Categorical", "src/distribution/Categorical.birch", 72);
  #line 73 "src/distribution/Categorical.birch"
  libbirch_line_(73);
  #line 73 "src/distribution/Categorical.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Categorical>>>(_u0961, handler_);
}

#line 79 "src/distribution/Categorical.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Categorical>> birch::Categorical(const libbirch::DefaultArray<birch::type::Real,1>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 79 "src/distribution/Categorical.birch"
  libbirch_function_("Categorical", "src/distribution/Categorical.birch", 79);
  #line 80 "src/distribution/Categorical.birch"
  libbirch_line_(80);
  #line 80 "src/distribution/Categorical.birch"
  return birch::Categorical(birch::box(_u0961, handler_), handler_);
}

#line 7 "src/distribution/DelayDistribution.birch"
birch::type::DelayDistribution::DelayDistribution(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 7 "src/distribution/DelayDistribution.birch"
    super_type_(),
    #line 11 "src/distribution/DelayDistribution.birch"
    child() {
  //
}

#line 21 "src/distribution/DelayDistribution.birch"
void birch::type::DelayDistribution::prune(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "src/distribution/DelayDistribution.birch"
  libbirch_function_("prune", "src/distribution/DelayDistribution.birch", 21);
  #line 22 "src/distribution/DelayDistribution.birch"
  libbirch_line_(22);
  #line 22 "src/distribution/DelayDistribution.birch"
  if (this_()->child.query()) {
    #line 23 "src/distribution/DelayDistribution.birch"
    libbirch_line_(23);
    #line 23 "src/distribution/DelayDistribution.birch"
    this_()->child.get()->realize(handler_);
  }
}

#line 34 "src/distribution/DelayDistribution.birch"
void birch::type::DelayDistribution::setChild(const libbirch::Lazy<libbirch::Shared<birch::type::DelayDistribution>>& child, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/distribution/DelayDistribution.birch"
  libbirch_function_("setChild", "src/distribution/DelayDistribution.birch", 34);
  #line 35 "src/distribution/DelayDistribution.birch"
  libbirch_line_(35);
  #line 35 "src/distribution/DelayDistribution.birch"
  libbirch_assert_(!this_()->child.query() || this_()->child.get() == child);
  #line 36 "src/distribution/DelayDistribution.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/DelayDistribution.birch"
  this_()->child = child;
}

#line 46 "src/distribution/DelayDistribution.birch"
void birch::type::DelayDistribution::releaseChild(const libbirch::Lazy<libbirch::Shared<birch::type::DelayDistribution>>& child, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/distribution/DelayDistribution.birch"
  libbirch_function_("releaseChild", "src/distribution/DelayDistribution.birch", 46);
  #line 47 "src/distribution/DelayDistribution.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/DelayDistribution.birch"
  libbirch_assert_(!this_()->child.query() || this_()->child.get() == child);
  #line 48 "src/distribution/DelayDistribution.birch"
  libbirch_line_(48);
  #line 48 "src/distribution/DelayDistribution.birch"
  this_()->child = libbirch::nil;
}

#line 54 "src/distribution/DelayDistribution.birch"
void birch::type::DelayDistribution::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "src/distribution/DelayDistribution.birch"
  libbirch_function_("link", "src/distribution/DelayDistribution.birch", 54);
}

#line 61 "src/distribution/DelayDistribution.birch"
void birch::type::DelayDistribution::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "src/distribution/DelayDistribution.birch"
  libbirch_function_("unlink", "src/distribution/DelayDistribution.birch", 61);
}

#line 1 "src/distribution/Delta.birch"
birch::type::Delta::Delta(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/distribution/Delta.birch"
    super_type_(),
    #line 9 "src/distribution/Delta.birch"
    _u0956(_u0956) {
  //
}

#line 11 "src/distribution/Delta.birch"
birch::type::Boolean birch::type::Delta::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/distribution/Delta.birch"
  libbirch_function_("supportsLazy", "src/distribution/Delta.birch", 11);
  #line 12 "src/distribution/Delta.birch"
  libbirch_line_(12);
  #line 12 "src/distribution/Delta.birch"
  return false;
}

#line 15 "src/distribution/Delta.birch"
birch::type::Integer birch::type::Delta::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/distribution/Delta.birch"
  libbirch_function_("simulate", "src/distribution/Delta.birch", 15);
  #line 16 "src/distribution/Delta.birch"
  libbirch_line_(16);
  #line 16 "src/distribution/Delta.birch"
  if (this_()->value.query()) {
    #line 17 "src/distribution/Delta.birch"
    libbirch_line_(17);
    #line 17 "src/distribution/Delta.birch"
    return this_()->value.get();
  } else {
    #line 19 "src/distribution/Delta.birch"
    libbirch_line_(19);
    #line 19 "src/distribution/Delta.birch"
    return birch::simulate_delta(this_()->_u0956->value(handler_), handler_);
  }
}

#line 31 "src/distribution/Delta.birch"
birch::type::Real birch::type::Delta::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "src/distribution/Delta.birch"
  libbirch_function_("logpdf", "src/distribution/Delta.birch", 31);
  #line 32 "src/distribution/Delta.birch"
  libbirch_line_(32);
  #line 32 "src/distribution/Delta.birch"
  return birch::logpdf_delta(x, this_()->_u0956->value(handler_), handler_);
}

#line 39 "src/distribution/Delta.birch"
libbirch::Optional<birch::type::Integer> birch::type::Delta::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/distribution/Delta.birch"
  libbirch_function_("lower", "src/distribution/Delta.birch", 39);
  #line 40 "src/distribution/Delta.birch"
  libbirch_line_(40);
  #line 40 "src/distribution/Delta.birch"
  return this_()->_u0956->value(handler_);
}

#line 43 "src/distribution/Delta.birch"
libbirch::Optional<birch::type::Integer> birch::type::Delta::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "src/distribution/Delta.birch"
  libbirch_function_("upper", "src/distribution/Delta.birch", 43);
  #line 44 "src/distribution/Delta.birch"
  libbirch_line_(44);
  #line 44 "src/distribution/Delta.birch"
  return this_()->_u0956->value(handler_);
}

#line 47 "src/distribution/Delta.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> birch::type::Delta::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "src/distribution/Delta.birch"
  libbirch_function_("graft", "src/distribution/Delta.birch", 47);
  #line 48 "src/distribution/Delta.birch"
  libbirch_line_(48);
  #line 48 "src/distribution/Delta.birch"
  this_()->prune(handler_);
  #line 49 "src/distribution/Delta.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/Delta.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>> m;
  #line 50 "src/distribution/Delta.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/Delta.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> r = shared_from_this_();
  #line 53 "src/distribution/Delta.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/Delta.birch"
  if ((m = this_()->_u0956->graftDiscrete(handler_)).query()) {
    #line 54 "src/distribution/Delta.birch"
    libbirch_line_(54);
    #line 54 "src/distribution/Delta.birch"
    r = birch::DiscreteDelta(m.get(), handler_);
  }
  #line 57 "src/distribution/Delta.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/Delta.birch"
  return r;
}

#line 60 "src/distribution/Delta.birch"
void birch::type::Delta::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "src/distribution/Delta.birch"
  libbirch_function_("write", "src/distribution/Delta.birch", 60);
  #line 61 "src/distribution/Delta.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/Delta.birch"
  this_()->prune(handler_);
  #line 62 "src/distribution/Delta.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/Delta.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Delta"), handler_);
  #line 63 "src/distribution/Delta.birch"
  libbirch_line_(63);
  #line 63 "src/distribution/Delta.birch"
  buffer->set(birch::type::String("μ"), this_()->_u0956, handler_);
}

#line 72 "src/distribution/Delta.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Delta>> birch::Delta(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "src/distribution/Delta.birch"
  libbirch_function_("Delta", "src/distribution/Delta.birch", 72);
  #line 73 "src/distribution/Delta.birch"
  libbirch_line_(73);
  #line 73 "src/distribution/Delta.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Delta>>>(_u0956, handler_);
}

#line 81 "src/distribution/Delta.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Delta>> birch::Delta(const birch::type::Integer& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "src/distribution/Delta.birch"
  libbirch_function_("Delta", "src/distribution/Delta.birch", 81);
  #line 82 "src/distribution/Delta.birch"
  libbirch_line_(82);
  #line 82 "src/distribution/Delta.birch"
  return birch::Delta(birch::box(_u0956, handler_), handler_);
}

#line 4 "src/distribution/Dirichlet.birch"
birch::type::Dirichlet::Dirichlet(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/Dirichlet.birch"
    super_type_(),
    #line 8 "src/distribution/Dirichlet.birch"
    _u0945(_u0945) {
  //
}

#line 10 "src/distribution/Dirichlet.birch"
birch::type::Boolean birch::type::Dirichlet::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/distribution/Dirichlet.birch"
  libbirch_function_("supportsLazy", "src/distribution/Dirichlet.birch", 10);
  #line 11 "src/distribution/Dirichlet.birch"
  libbirch_line_(11);
  #line 11 "src/distribution/Dirichlet.birch"
  return false;
}

#line 14 "src/distribution/Dirichlet.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::Dirichlet::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/distribution/Dirichlet.birch"
  libbirch_function_("simulate", "src/distribution/Dirichlet.birch", 14);
  #line 15 "src/distribution/Dirichlet.birch"
  libbirch_line_(15);
  #line 15 "src/distribution/Dirichlet.birch"
  return birch::simulate_dirichlet(this_()->_u0945->value(handler_), handler_);
}

#line 22 "src/distribution/Dirichlet.birch"
birch::type::Real birch::type::Dirichlet::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/distribution/Dirichlet.birch"
  libbirch_function_("logpdf", "src/distribution/Dirichlet.birch", 22);
  #line 23 "src/distribution/Dirichlet.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/Dirichlet.birch"
  return birch::logpdf_dirichlet(x, this_()->_u0945->value(handler_), handler_);
}

#line 30 "src/distribution/Dirichlet.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Dirichlet>>> birch::type::Dirichlet::graftDirichlet(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/distribution/Dirichlet.birch"
  libbirch_function_("graftDirichlet", "src/distribution/Dirichlet.birch", 30);
  #line 31 "src/distribution/Dirichlet.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/Dirichlet.birch"
  this_()->prune(handler_);
  #line 32 "src/distribution/Dirichlet.birch"
  libbirch_line_(32);
  #line 32 "src/distribution/Dirichlet.birch"
  return shared_from_this_();
}

#line 35 "src/distribution/Dirichlet.birch"
void birch::type::Dirichlet::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "src/distribution/Dirichlet.birch"
  libbirch_function_("write", "src/distribution/Dirichlet.birch", 35);
  #line 36 "src/distribution/Dirichlet.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/Dirichlet.birch"
  this_()->prune(handler_);
  #line 37 "src/distribution/Dirichlet.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/Dirichlet.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Dirichlet"), handler_);
  #line 38 "src/distribution/Dirichlet.birch"
  libbirch_line_(38);
  #line 38 "src/distribution/Dirichlet.birch"
  buffer->set(birch::type::String("α"), this_()->_u0945, handler_);
}

#line 45 "src/distribution/Dirichlet.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Dirichlet>> birch::Dirichlet(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "src/distribution/Dirichlet.birch"
  libbirch_function_("Dirichlet", "src/distribution/Dirichlet.birch", 45);
  #line 46 "src/distribution/Dirichlet.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/Dirichlet.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Dirichlet>>>(_u0945, handler_);
}

#line 52 "src/distribution/Dirichlet.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Dirichlet>> birch::Dirichlet(const libbirch::DefaultArray<birch::type::Real,1>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "src/distribution/Dirichlet.birch"
  libbirch_function_("Dirichlet", "src/distribution/Dirichlet.birch", 52);
  #line 53 "src/distribution/Dirichlet.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/Dirichlet.birch"
  return birch::Dirichlet(birch::box(_u0945, handler_), handler_);
}

#line 4 "src/distribution/DirichletCategorical.birch"
birch::type::DirichletCategorical::DirichletCategorical(const libbirch::Lazy<libbirch::Shared<birch::type::Dirichlet>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/DirichletCategorical.birch"
    super_type_(),
    #line 8 "src/distribution/DirichletCategorical.birch"
    _u0961(_u0961) {
  //
}

#line 10 "src/distribution/DirichletCategorical.birch"
birch::type::Boolean birch::type::DirichletCategorical::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/distribution/DirichletCategorical.birch"
  libbirch_function_("supportsLazy", "src/distribution/DirichletCategorical.birch", 10);
  #line 11 "src/distribution/DirichletCategorical.birch"
  libbirch_line_(11);
  #line 11 "src/distribution/DirichletCategorical.birch"
  return false;
}

#line 14 "src/distribution/DirichletCategorical.birch"
birch::type::Integer birch::type::DirichletCategorical::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/distribution/DirichletCategorical.birch"
  libbirch_function_("simulate", "src/distribution/DirichletCategorical.birch", 14);
  #line 15 "src/distribution/DirichletCategorical.birch"
  libbirch_line_(15);
  #line 15 "src/distribution/DirichletCategorical.birch"
  return birch::simulate_dirichlet_categorical(this_()->_u0961->_u0945->value(handler_), handler_);
}

#line 22 "src/distribution/DirichletCategorical.birch"
birch::type::Real birch::type::DirichletCategorical::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/distribution/DirichletCategorical.birch"
  libbirch_function_("logpdf", "src/distribution/DirichletCategorical.birch", 22);
  #line 23 "src/distribution/DirichletCategorical.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/DirichletCategorical.birch"
  return birch::logpdf_dirichlet_categorical(x, this_()->_u0961->_u0945->value(handler_), handler_);
}

#line 30 "src/distribution/DirichletCategorical.birch"
void birch::type::DirichletCategorical::update(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/distribution/DirichletCategorical.birch"
  libbirch_function_("update", "src/distribution/DirichletCategorical.birch", 30);
  #line 31 "src/distribution/DirichletCategorical.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/DirichletCategorical.birch"
  this_()->_u0961->_u0945 = birch::box(birch::update_dirichlet_categorical(x, this_()->_u0961->_u0945->value(handler_), handler_), handler_);
}

#line 38 "src/distribution/DirichletCategorical.birch"
libbirch::Optional<birch::type::Integer> birch::type::DirichletCategorical::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "src/distribution/DirichletCategorical.birch"
  libbirch_function_("lower", "src/distribution/DirichletCategorical.birch", 38);
  #line 39 "src/distribution/DirichletCategorical.birch"
  libbirch_line_(39);
  #line 39 "src/distribution/DirichletCategorical.birch"
  return birch::type::Integer(1);
}

#line 42 "src/distribution/DirichletCategorical.birch"
libbirch::Optional<birch::type::Integer> birch::type::DirichletCategorical::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/distribution/DirichletCategorical.birch"
  libbirch_function_("upper", "src/distribution/DirichletCategorical.birch", 42);
  #line 43 "src/distribution/DirichletCategorical.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/DirichletCategorical.birch"
  return this_()->_u0961->_u0945->rows(handler_);
}

#line 46 "src/distribution/DirichletCategorical.birch"
void birch::type::DirichletCategorical::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/distribution/DirichletCategorical.birch"
  libbirch_function_("link", "src/distribution/DirichletCategorical.birch", 46);
  #line 47 "src/distribution/DirichletCategorical.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/DirichletCategorical.birch"
  this_()->_u0961->setChild(shared_from_this_(), handler_);
}

#line 50 "src/distribution/DirichletCategorical.birch"
void birch::type::DirichletCategorical::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "src/distribution/DirichletCategorical.birch"
  libbirch_function_("unlink", "src/distribution/DirichletCategorical.birch", 50);
  #line 51 "src/distribution/DirichletCategorical.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/DirichletCategorical.birch"
  this_()->_u0961->releaseChild(shared_from_this_(), handler_);
}

#line 55 "src/distribution/DirichletCategorical.birch"
libbirch::Lazy<libbirch::Shared<birch::type::DirichletCategorical>> birch::DirichletCategorical(const libbirch::Lazy<libbirch::Shared<birch::type::Dirichlet>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 55 "src/distribution/DirichletCategorical.birch"
  libbirch_function_("DirichletCategorical", "src/distribution/DirichletCategorical.birch", 55);
  #line 56 "src/distribution/DirichletCategorical.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/DirichletCategorical.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::DirichletCategorical>> m(_u0961);
  #line 57 "src/distribution/DirichletCategorical.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/DirichletCategorical.birch"
  m->link(handler_);
  #line 58 "src/distribution/DirichletCategorical.birch"
  libbirch_line_(58);
  #line 58 "src/distribution/DirichletCategorical.birch"
  return m;
}

#line 4 "src/distribution/DirichletMultinomial.birch"
birch::type::DirichletMultinomial::DirichletMultinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& n, const libbirch::Lazy<libbirch::Shared<birch::type::Dirichlet>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/DirichletMultinomial.birch"
    super_type_(),
    #line 9 "src/distribution/DirichletMultinomial.birch"
    n(n),
    #line 14 "src/distribution/DirichletMultinomial.birch"
    _u0961(_u0961) {
  //
}

#line 16 "src/distribution/DirichletMultinomial.birch"
birch::type::Boolean birch::type::DirichletMultinomial::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/distribution/DirichletMultinomial.birch"
  libbirch_function_("supportsLazy", "src/distribution/DirichletMultinomial.birch", 16);
  #line 17 "src/distribution/DirichletMultinomial.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/DirichletMultinomial.birch"
  return false;
}

#line 20 "src/distribution/DirichletMultinomial.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::type::DirichletMultinomial::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/distribution/DirichletMultinomial.birch"
  libbirch_function_("simulate", "src/distribution/DirichletMultinomial.birch", 20);
  #line 21 "src/distribution/DirichletMultinomial.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/DirichletMultinomial.birch"
  return birch::simulate_dirichlet_multinomial(this_()->n->value(handler_), this_()->_u0961->_u0945->value(handler_), handler_);
}

#line 28 "src/distribution/DirichletMultinomial.birch"
birch::type::Real birch::type::DirichletMultinomial::logpdf(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/distribution/DirichletMultinomial.birch"
  libbirch_function_("logpdf", "src/distribution/DirichletMultinomial.birch", 28);
  #line 29 "src/distribution/DirichletMultinomial.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/DirichletMultinomial.birch"
  return birch::logpdf_dirichlet_multinomial(x, this_()->n->value(handler_), this_()->_u0961->_u0945->value(handler_), handler_);
}

#line 36 "src/distribution/DirichletMultinomial.birch"
void birch::type::DirichletMultinomial::update(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/distribution/DirichletMultinomial.birch"
  libbirch_function_("update", "src/distribution/DirichletMultinomial.birch", 36);
  #line 37 "src/distribution/DirichletMultinomial.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/DirichletMultinomial.birch"
  this_()->_u0961->_u0945 = birch::box(birch::update_dirichlet_multinomial(x, this_()->n->value(handler_), this_()->_u0961->_u0945->value(handler_), handler_), handler_);
}

#line 44 "src/distribution/DirichletMultinomial.birch"
void birch::type::DirichletMultinomial::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/distribution/DirichletMultinomial.birch"
  libbirch_function_("link", "src/distribution/DirichletMultinomial.birch", 44);
  #line 45 "src/distribution/DirichletMultinomial.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/DirichletMultinomial.birch"
  this_()->_u0961->setChild(shared_from_this_(), handler_);
}

#line 48 "src/distribution/DirichletMultinomial.birch"
void birch::type::DirichletMultinomial::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "src/distribution/DirichletMultinomial.birch"
  libbirch_function_("unlink", "src/distribution/DirichletMultinomial.birch", 48);
  #line 49 "src/distribution/DirichletMultinomial.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/DirichletMultinomial.birch"
  this_()->_u0961->releaseChild(shared_from_this_(), handler_);
}

#line 53 "src/distribution/DirichletMultinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::DirichletMultinomial>> birch::DirichletMultinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& n, const libbirch::Lazy<libbirch::Shared<birch::type::Dirichlet>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "src/distribution/DirichletMultinomial.birch"
  libbirch_function_("DirichletMultinomial", "src/distribution/DirichletMultinomial.birch", 53);
  #line 55 "src/distribution/DirichletMultinomial.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/DirichletMultinomial.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::DirichletMultinomial>> m(n, _u0961);
  #line 56 "src/distribution/DirichletMultinomial.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/DirichletMultinomial.birch"
  m->link(handler_);
  #line 57 "src/distribution/DirichletMultinomial.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/DirichletMultinomial.birch"
  return m;
}

#line 4 "src/distribution/Discrete.birch"
birch::type::Discrete::Discrete(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/Discrete.birch"
    super_type_(),
    #line 8 "src/distribution/Discrete.birch"
    value() {
  //
}

#line 15 "src/distribution/Discrete.birch"
void birch::type::Discrete::clamp(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/distribution/Discrete.birch"
  libbirch_function_("clamp", "src/distribution/Discrete.birch", 15);
  #line 16 "src/distribution/Discrete.birch"
  libbirch_line_(16);
  #line 16 "src/distribution/Discrete.birch"
  libbirch_assert_(!this_()->value.query() || this_()->value.get() == x);
  #line 17 "src/distribution/Discrete.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/Discrete.birch"
  this_()->value = x;
}

#line 20 "src/distribution/Discrete.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>> birch::type::Discrete::graftDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/distribution/Discrete.birch"
  libbirch_function_("graftDiscrete", "src/distribution/Discrete.birch", 20);
  #line 21 "src/distribution/Discrete.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/Discrete.birch"
  this_()->prune(handler_);
  #line 22 "src/distribution/Discrete.birch"
  libbirch_line_(22);
  #line 22 "src/distribution/Discrete.birch"
  return shared_from_this_();
}

#line 4 "src/distribution/DiscreteDelta.birch"
birch::type::DiscreteDelta::DiscreteDelta(const libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/DiscreteDelta.birch"
    super_type_(),
    #line 8 "src/distribution/DiscreteDelta.birch"
    _u0956(_u0956) {
  //
}

#line 10 "src/distribution/DiscreteDelta.birch"
birch::type::Boolean birch::type::DiscreteDelta::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/distribution/DiscreteDelta.birch"
  libbirch_function_("supportsLazy", "src/distribution/DiscreteDelta.birch", 10);
  #line 11 "src/distribution/DiscreteDelta.birch"
  libbirch_line_(11);
  #line 11 "src/distribution/DiscreteDelta.birch"
  return false;
}

#line 14 "src/distribution/DiscreteDelta.birch"
birch::type::Integer birch::type::DiscreteDelta::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/distribution/DiscreteDelta.birch"
  libbirch_function_("simulate", "src/distribution/DiscreteDelta.birch", 14);
  #line 15 "src/distribution/DiscreteDelta.birch"
  libbirch_line_(15);
  #line 15 "src/distribution/DiscreteDelta.birch"
  if (this_()->value.query()) {
    #line 16 "src/distribution/DiscreteDelta.birch"
    libbirch_line_(16);
    #line 16 "src/distribution/DiscreteDelta.birch"
    return birch::simulate_delta(this_()->value.get(), handler_);
  } else {
    #line 18 "src/distribution/DiscreteDelta.birch"
    libbirch_line_(18);
    #line 18 "src/distribution/DiscreteDelta.birch"
    return birch::simulate_delta(this_()->_u0956->simulate(handler_), handler_);
  }
}

#line 30 "src/distribution/DiscreteDelta.birch"
birch::type::Real birch::type::DiscreteDelta::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/distribution/DiscreteDelta.birch"
  libbirch_function_("logpdf", "src/distribution/DiscreteDelta.birch", 30);
  #line 31 "src/distribution/DiscreteDelta.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/DiscreteDelta.birch"
  if (this_()->value.query()) {
    #line 32 "src/distribution/DiscreteDelta.birch"
    libbirch_line_(32);
    #line 32 "src/distribution/DiscreteDelta.birch"
    return birch::logpdf_delta(x, this_()->value.get(), handler_);
  } else {
    #line 34 "src/distribution/DiscreteDelta.birch"
    libbirch_line_(34);
    #line 34 "src/distribution/DiscreteDelta.birch"
    return this_()->_u0956->logpdf(x, handler_);
  }
}

#line 46 "src/distribution/DiscreteDelta.birch"
void birch::type::DiscreteDelta::update(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/distribution/DiscreteDelta.birch"
  libbirch_function_("update", "src/distribution/DiscreteDelta.birch", 46);
  #line 47 "src/distribution/DiscreteDelta.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/DiscreteDelta.birch"
  this_()->_u0956->clamp(x, handler_);
}

#line 54 "src/distribution/DiscreteDelta.birch"
libbirch::Optional<birch::type::Real> birch::type::DiscreteDelta::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "src/distribution/DiscreteDelta.birch"
  libbirch_function_("cdf", "src/distribution/DiscreteDelta.birch", 54);
  #line 55 "src/distribution/DiscreteDelta.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/DiscreteDelta.birch"
  return this_()->_u0956->cdf(x, handler_);
}

#line 58 "src/distribution/DiscreteDelta.birch"
libbirch::Optional<birch::type::Integer> birch::type::DiscreteDelta::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "src/distribution/DiscreteDelta.birch"
  libbirch_function_("lower", "src/distribution/DiscreteDelta.birch", 58);
  #line 59 "src/distribution/DiscreteDelta.birch"
  libbirch_line_(59);
  #line 59 "src/distribution/DiscreteDelta.birch"
  return this_()->_u0956->lower(handler_);
}

#line 62 "src/distribution/DiscreteDelta.birch"
libbirch::Optional<birch::type::Integer> birch::type::DiscreteDelta::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 62 "src/distribution/DiscreteDelta.birch"
  libbirch_function_("upper", "src/distribution/DiscreteDelta.birch", 62);
  #line 63 "src/distribution/DiscreteDelta.birch"
  libbirch_line_(63);
  #line 63 "src/distribution/DiscreteDelta.birch"
  return this_()->_u0956->upper(handler_);
}

#line 66 "src/distribution/DiscreteDelta.birch"
void birch::type::DiscreteDelta::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "src/distribution/DiscreteDelta.birch"
  libbirch_function_("link", "src/distribution/DiscreteDelta.birch", 66);
}

#line 71 "src/distribution/DiscreteDelta.birch"
void birch::type::DiscreteDelta::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 71 "src/distribution/DiscreteDelta.birch"
  libbirch_function_("unlink", "src/distribution/DiscreteDelta.birch", 71);
}

#line 77 "src/distribution/DiscreteDelta.birch"
libbirch::Lazy<libbirch::Shared<birch::type::DiscreteDelta>> birch::DiscreteDelta(const libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 77 "src/distribution/DiscreteDelta.birch"
  libbirch_function_("DiscreteDelta", "src/distribution/DiscreteDelta.birch", 77);
  #line 78 "src/distribution/DiscreteDelta.birch"
  libbirch_line_(78);
  #line 78 "src/distribution/DiscreteDelta.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::DiscreteDelta>> m(_u0956);
  #line 79 "src/distribution/DiscreteDelta.birch"
  libbirch_line_(79);
  #line 79 "src/distribution/DiscreteDelta.birch"
  m->link(handler_);
  #line 80 "src/distribution/DiscreteDelta.birch"
  libbirch_line_(80);
  #line 80 "src/distribution/DiscreteDelta.birch"
  return m;
}

#line 1 "src/distribution/Exponential.birch"
birch::type::Exponential::Exponential(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/distribution/Exponential.birch"
    super_type_(),
    #line 8 "src/distribution/Exponential.birch"
    _u0955(_u0955) {
  //
}

#line 10 "src/distribution/Exponential.birch"
birch::type::Boolean birch::type::Exponential::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/distribution/Exponential.birch"
  libbirch_function_("supportsLazy", "src/distribution/Exponential.birch", 10);
  #line 11 "src/distribution/Exponential.birch"
  libbirch_line_(11);
  #line 11 "src/distribution/Exponential.birch"
  return true;
}

#line 14 "src/distribution/Exponential.birch"
birch::type::Real birch::type::Exponential::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/distribution/Exponential.birch"
  libbirch_function_("simulate", "src/distribution/Exponential.birch", 14);
  #line 15 "src/distribution/Exponential.birch"
  libbirch_line_(15);
  #line 15 "src/distribution/Exponential.birch"
  return birch::simulate_exponential(this_()->_u0955->value(handler_), handler_);
}

#line 18 "src/distribution/Exponential.birch"
libbirch::Optional<birch::type::Real> birch::type::Exponential::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/distribution/Exponential.birch"
  libbirch_function_("simulateLazy", "src/distribution/Exponential.birch", 18);
  #line 19 "src/distribution/Exponential.birch"
  libbirch_line_(19);
  #line 19 "src/distribution/Exponential.birch"
  return birch::simulate_exponential(this_()->_u0955->get(handler_), handler_);
}

#line 22 "src/distribution/Exponential.birch"
birch::type::Real birch::type::Exponential::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/distribution/Exponential.birch"
  libbirch_function_("logpdf", "src/distribution/Exponential.birch", 22);
  #line 23 "src/distribution/Exponential.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/Exponential.birch"
  return birch::logpdf_exponential(x, this_()->_u0955->value(handler_), handler_);
}

#line 26 "src/distribution/Exponential.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::Exponential::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/distribution/Exponential.birch"
  libbirch_function_("logpdfLazy", "src/distribution/Exponential.birch", 26);
  #line 27 "src/distribution/Exponential.birch"
  libbirch_line_(27);
  #line 27 "src/distribution/Exponential.birch"
  return birch::logpdf_lazy_exponential(x, this_()->_u0955, handler_);
}

#line 30 "src/distribution/Exponential.birch"
libbirch::Optional<birch::type::Real> birch::type::Exponential::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/distribution/Exponential.birch"
  libbirch_function_("cdf", "src/distribution/Exponential.birch", 30);
  #line 31 "src/distribution/Exponential.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/Exponential.birch"
  return birch::cdf_exponential(x, this_()->_u0955->value(handler_), handler_);
}

#line 34 "src/distribution/Exponential.birch"
libbirch::Optional<birch::type::Real> birch::type::Exponential::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/distribution/Exponential.birch"
  libbirch_function_("quantile", "src/distribution/Exponential.birch", 34);
  #line 35 "src/distribution/Exponential.birch"
  libbirch_line_(35);
  #line 35 "src/distribution/Exponential.birch"
  return birch::quantile_exponential(P, this_()->_u0955->value(handler_), handler_);
}

#line 38 "src/distribution/Exponential.birch"
libbirch::Optional<birch::type::Real> birch::type::Exponential::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "src/distribution/Exponential.birch"
  libbirch_function_("lower", "src/distribution/Exponential.birch", 38);
  #line 39 "src/distribution/Exponential.birch"
  libbirch_line_(39);
  #line 39 "src/distribution/Exponential.birch"
  return 0.0;
}

#line 42 "src/distribution/Exponential.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> birch::type::Exponential::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/distribution/Exponential.birch"
  libbirch_function_("graft", "src/distribution/Exponential.birch", 42);
  #line 43 "src/distribution/Exponential.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/Exponential.birch"
  this_()->prune(handler_);
  #line 44 "src/distribution/Exponential.birch"
  libbirch_line_(44);
  #line 44 "src/distribution/Exponential.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>>>>> m1;
  #line 45 "src/distribution/Exponential.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/Exponential.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>> m2;
  #line 46 "src/distribution/Exponential.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/Exponential.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> r = shared_from_this_();
  #line 49 "src/distribution/Exponential.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/Exponential.birch"
  if ((m1 = this_()->_u0955->graftScaledGamma(handler_)).query()) {
    #line 50 "src/distribution/Exponential.birch"
    libbirch_line_(50);
    #line 50 "src/distribution/Exponential.birch"
    r = birch::ScaledGammaExponential(m1.get()->a, m1.get()->x, handler_);
  } else {
    #line 51 "src/distribution/Exponential.birch"
    libbirch_line_(51);
    #line 51 "src/distribution/Exponential.birch"
    if ((m2 = this_()->_u0955->graftGamma(handler_)).query()) {
      #line 52 "src/distribution/Exponential.birch"
      libbirch_line_(52);
      #line 52 "src/distribution/Exponential.birch"
      r = birch::GammaExponential(m2.get(), handler_);
    }
  }
  #line 55 "src/distribution/Exponential.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/Exponential.birch"
  return r;
}

#line 58 "src/distribution/Exponential.birch"
void birch::type::Exponential::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "src/distribution/Exponential.birch"
  libbirch_function_("write", "src/distribution/Exponential.birch", 58);
  #line 59 "src/distribution/Exponential.birch"
  libbirch_line_(59);
  #line 59 "src/distribution/Exponential.birch"
  this_()->prune(handler_);
  #line 60 "src/distribution/Exponential.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/Exponential.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Exponential"), handler_);
  #line 61 "src/distribution/Exponential.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/Exponential.birch"
  buffer->set(birch::type::String("λ"), this_()->_u0955, handler_);
}

#line 68 "src/distribution/Exponential.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Exponential>> birch::Exponential(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 68 "src/distribution/Exponential.birch"
  libbirch_function_("Exponential", "src/distribution/Exponential.birch", 68);
  #line 69 "src/distribution/Exponential.birch"
  libbirch_line_(69);
  #line 69 "src/distribution/Exponential.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Exponential>>>(_u0955, handler_);
}

#line 75 "src/distribution/Exponential.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Exponential>> birch::Exponential(const birch::type::Real& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 75 "src/distribution/Exponential.birch"
  libbirch_function_("Exponential", "src/distribution/Exponential.birch", 75);
  #line 76 "src/distribution/Exponential.birch"
  libbirch_line_(76);
  #line 76 "src/distribution/Exponential.birch"
  return birch::Exponential(birch::box(_u0955, handler_), handler_);
}

#line 1 "src/distribution/Gamma.birch"
birch::type::Gamma::Gamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/distribution/Gamma.birch"
    super_type_(),
    #line 8 "src/distribution/Gamma.birch"
    k(k),
    #line 13 "src/distribution/Gamma.birch"
    _u0952(_u0952) {
  //
}

#line 15 "src/distribution/Gamma.birch"
birch::type::Boolean birch::type::Gamma::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/distribution/Gamma.birch"
  libbirch_function_("supportsLazy", "src/distribution/Gamma.birch", 15);
  #line 16 "src/distribution/Gamma.birch"
  libbirch_line_(16);
  #line 16 "src/distribution/Gamma.birch"
  return true;
}

#line 19 "src/distribution/Gamma.birch"
birch::type::Real birch::type::Gamma::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/distribution/Gamma.birch"
  libbirch_function_("simulate", "src/distribution/Gamma.birch", 19);
  #line 20 "src/distribution/Gamma.birch"
  libbirch_line_(20);
  #line 20 "src/distribution/Gamma.birch"
  return birch::simulate_gamma(this_()->k->value(handler_), this_()->_u0952->value(handler_), handler_);
}

#line 23 "src/distribution/Gamma.birch"
libbirch::Optional<birch::type::Real> birch::type::Gamma::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "src/distribution/Gamma.birch"
  libbirch_function_("simulateLazy", "src/distribution/Gamma.birch", 23);
  #line 24 "src/distribution/Gamma.birch"
  libbirch_line_(24);
  #line 24 "src/distribution/Gamma.birch"
  return birch::simulate_gamma(this_()->k->get(handler_), this_()->_u0952->get(handler_), handler_);
}

#line 27 "src/distribution/Gamma.birch"
birch::type::Real birch::type::Gamma::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/distribution/Gamma.birch"
  libbirch_function_("logpdf", "src/distribution/Gamma.birch", 27);
  #line 28 "src/distribution/Gamma.birch"
  libbirch_line_(28);
  #line 28 "src/distribution/Gamma.birch"
  return birch::logpdf_gamma(x, this_()->k->value(handler_), this_()->_u0952->value(handler_), handler_);
}

#line 31 "src/distribution/Gamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::Gamma::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "src/distribution/Gamma.birch"
  libbirch_function_("logpdfLazy", "src/distribution/Gamma.birch", 31);
  #line 32 "src/distribution/Gamma.birch"
  libbirch_line_(32);
  #line 32 "src/distribution/Gamma.birch"
  return birch::logpdf_lazy_gamma(x, this_()->k, this_()->_u0952, handler_);
}

#line 35 "src/distribution/Gamma.birch"
libbirch::Optional<birch::type::Real> birch::type::Gamma::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "src/distribution/Gamma.birch"
  libbirch_function_("cdf", "src/distribution/Gamma.birch", 35);
  #line 36 "src/distribution/Gamma.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/Gamma.birch"
  return birch::cdf_gamma(x, this_()->k->value(handler_), this_()->_u0952->value(handler_), handler_);
}

#line 39 "src/distribution/Gamma.birch"
libbirch::Optional<birch::type::Real> birch::type::Gamma::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/distribution/Gamma.birch"
  libbirch_function_("quantile", "src/distribution/Gamma.birch", 39);
  #line 40 "src/distribution/Gamma.birch"
  libbirch_line_(40);
  #line 40 "src/distribution/Gamma.birch"
  return birch::quantile_gamma(P, this_()->k->value(handler_), this_()->_u0952->value(handler_), handler_);
}

#line 43 "src/distribution/Gamma.birch"
libbirch::Optional<birch::type::Real> birch::type::Gamma::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "src/distribution/Gamma.birch"
  libbirch_function_("lower", "src/distribution/Gamma.birch", 43);
  #line 44 "src/distribution/Gamma.birch"
  libbirch_line_(44);
  #line 44 "src/distribution/Gamma.birch"
  return 0.0;
}

#line 47 "src/distribution/Gamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> birch::type::Gamma::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "src/distribution/Gamma.birch"
  libbirch_function_("graft", "src/distribution/Gamma.birch", 47);
  #line 48 "src/distribution/Gamma.birch"
  libbirch_line_(48);
  #line 48 "src/distribution/Gamma.birch"
  this_()->prune(handler_);
  #line 49 "src/distribution/Gamma.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/Gamma.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>> _u09521;
  #line 50 "src/distribution/Gamma.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/Gamma.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> r = shared_from_this_();
  #line 53 "src/distribution/Gamma.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/Gamma.birch"
  if ((_u09521 = this_()->_u0952->graftInverseGamma(handler_)).query()) {
    #line 54 "src/distribution/Gamma.birch"
    libbirch_line_(54);
    #line 54 "src/distribution/Gamma.birch"
    r = birch::InverseGammaGamma(this_()->k, _u09521.get(), handler_);
  }
  #line 57 "src/distribution/Gamma.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/Gamma.birch"
  return r;
}

#line 60 "src/distribution/Gamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>> birch::type::Gamma::graftGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "src/distribution/Gamma.birch"
  libbirch_function_("graftGamma", "src/distribution/Gamma.birch", 60);
  #line 61 "src/distribution/Gamma.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/Gamma.birch"
  this_()->prune(handler_);
  #line 62 "src/distribution/Gamma.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/Gamma.birch"
  return shared_from_this_();
}

#line 65 "src/distribution/Gamma.birch"
void birch::type::Gamma::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "src/distribution/Gamma.birch"
  libbirch_function_("write", "src/distribution/Gamma.birch", 65);
  #line 66 "src/distribution/Gamma.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/Gamma.birch"
  this_()->prune(handler_);
  #line 67 "src/distribution/Gamma.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/Gamma.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Gamma"), handler_);
  #line 68 "src/distribution/Gamma.birch"
  libbirch_line_(68);
  #line 68 "src/distribution/Gamma.birch"
  buffer->set(birch::type::String("k"), this_()->k, handler_);
  #line 69 "src/distribution/Gamma.birch"
  libbirch_line_(69);
  #line 69 "src/distribution/Gamma.birch"
  buffer->set(birch::type::String("θ"), this_()->_u0952, handler_);
}

#line 76 "src/distribution/Gamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Gamma>> birch::Gamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "src/distribution/Gamma.birch"
  libbirch_function_("Gamma", "src/distribution/Gamma.birch", 76);
  #line 77 "src/distribution/Gamma.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/Gamma.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>>(k, _u0952, handler_);
}

#line 83 "src/distribution/Gamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Gamma>> birch::Gamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const birch::type::Real& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 83 "src/distribution/Gamma.birch"
  libbirch_function_("Gamma", "src/distribution/Gamma.birch", 83);
  #line 84 "src/distribution/Gamma.birch"
  libbirch_line_(84);
  #line 84 "src/distribution/Gamma.birch"
  return birch::Gamma(k, birch::box(_u0952, handler_), handler_);
}

#line 90 "src/distribution/Gamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Gamma>> birch::Gamma(const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 90 "src/distribution/Gamma.birch"
  libbirch_function_("Gamma", "src/distribution/Gamma.birch", 90);
  #line 91 "src/distribution/Gamma.birch"
  libbirch_line_(91);
  #line 91 "src/distribution/Gamma.birch"
  return birch::Gamma(birch::box(k, handler_), _u0952, handler_);
}

#line 97 "src/distribution/Gamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Gamma>> birch::Gamma(const birch::type::Real& k, const birch::type::Real& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 97 "src/distribution/Gamma.birch"
  libbirch_function_("Gamma", "src/distribution/Gamma.birch", 97);
  #line 98 "src/distribution/Gamma.birch"
  libbirch_line_(98);
  #line 98 "src/distribution/Gamma.birch"
  return birch::Gamma(birch::box(k, handler_), birch::box(_u0952, handler_), handler_);
}

#line 4 "src/distribution/GammaExponential.birch"
birch::type::GammaExponential::GammaExponential(const libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/GammaExponential.birch"
    super_type_(),
    #line 8 "src/distribution/GammaExponential.birch"
    _u0955(_u0955) {
  //
}

#line 10 "src/distribution/GammaExponential.birch"
birch::type::Boolean birch::type::GammaExponential::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/distribution/GammaExponential.birch"
  libbirch_function_("supportsLazy", "src/distribution/GammaExponential.birch", 10);
  #line 11 "src/distribution/GammaExponential.birch"
  libbirch_line_(11);
  #line 11 "src/distribution/GammaExponential.birch"
  return true;
}

#line 14 "src/distribution/GammaExponential.birch"
birch::type::Real birch::type::GammaExponential::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/distribution/GammaExponential.birch"
  libbirch_function_("simulate", "src/distribution/GammaExponential.birch", 14);
  #line 15 "src/distribution/GammaExponential.birch"
  libbirch_line_(15);
  #line 15 "src/distribution/GammaExponential.birch"
  return birch::simulate_lomax(1.0 / this_()->_u0955->_u0952->value(handler_), this_()->_u0955->k->value(handler_), handler_);
}

#line 18 "src/distribution/GammaExponential.birch"
libbirch::Optional<birch::type::Real> birch::type::GammaExponential::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/distribution/GammaExponential.birch"
  libbirch_function_("simulateLazy", "src/distribution/GammaExponential.birch", 18);
  #line 19 "src/distribution/GammaExponential.birch"
  libbirch_line_(19);
  #line 19 "src/distribution/GammaExponential.birch"
  return birch::simulate_lomax(1.0 / this_()->_u0955->_u0952->get(handler_), this_()->_u0955->k->get(handler_), handler_);
}

#line 22 "src/distribution/GammaExponential.birch"
birch::type::Real birch::type::GammaExponential::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/distribution/GammaExponential.birch"
  libbirch_function_("logpdf", "src/distribution/GammaExponential.birch", 22);
  #line 23 "src/distribution/GammaExponential.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/GammaExponential.birch"
  return birch::logpdf_lomax(x, 1.0 / this_()->_u0955->_u0952->value(handler_), this_()->_u0955->k->value(handler_), handler_);
}

#line 26 "src/distribution/GammaExponential.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::GammaExponential::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/distribution/GammaExponential.birch"
  libbirch_function_("logpdfLazy", "src/distribution/GammaExponential.birch", 26);
  #line 27 "src/distribution/GammaExponential.birch"
  libbirch_line_(27);
  #line 27 "src/distribution/GammaExponential.birch"
  return birch::logpdf_lazy_lomax(x, 1.0 / this_()->_u0955->_u0952, this_()->_u0955->k, handler_);
}

#line 30 "src/distribution/GammaExponential.birch"
void birch::type::GammaExponential::update(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/distribution/GammaExponential.birch"
  libbirch_function_("update", "src/distribution/GammaExponential.birch", 30);
  #line 31 "src/distribution/GammaExponential.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/GammaExponential.birch"
  libbirch::tie(this_()->_u0955->k, this_()->_u0955->_u0952) = birch::box(birch::update_gamma_exponential(x, this_()->_u0955->k->value(handler_), this_()->_u0955->_u0952->value(handler_), handler_), handler_);
}

#line 34 "src/distribution/GammaExponential.birch"
void birch::type::GammaExponential::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/distribution/GammaExponential.birch"
  libbirch_function_("updateLazy", "src/distribution/GammaExponential.birch", 34);
  #line 35 "src/distribution/GammaExponential.birch"
  libbirch_line_(35);
  #line 35 "src/distribution/GammaExponential.birch"
  libbirch::tie(this_()->_u0955->k, this_()->_u0955->_u0952) = birch::update_lazy_gamma_exponential(x, this_()->_u0955->k, this_()->_u0955->_u0952, handler_);
}

#line 38 "src/distribution/GammaExponential.birch"
libbirch::Optional<birch::type::Real> birch::type::GammaExponential::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "src/distribution/GammaExponential.birch"
  libbirch_function_("cdf", "src/distribution/GammaExponential.birch", 38);
  #line 39 "src/distribution/GammaExponential.birch"
  libbirch_line_(39);
  #line 39 "src/distribution/GammaExponential.birch"
  return birch::cdf_lomax(x, 1.0 / this_()->_u0955->_u0952->value(handler_), this_()->_u0955->k->value(handler_), handler_);
}

#line 42 "src/distribution/GammaExponential.birch"
libbirch::Optional<birch::type::Real> birch::type::GammaExponential::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/distribution/GammaExponential.birch"
  libbirch_function_("quantile", "src/distribution/GammaExponential.birch", 42);
  #line 43 "src/distribution/GammaExponential.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/GammaExponential.birch"
  return birch::quantile_lomax(P, 1.0 / this_()->_u0955->_u0952->value(handler_), this_()->_u0955->k->value(handler_), handler_);
}

#line 46 "src/distribution/GammaExponential.birch"
libbirch::Optional<birch::type::Real> birch::type::GammaExponential::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/distribution/GammaExponential.birch"
  libbirch_function_("lower", "src/distribution/GammaExponential.birch", 46);
  #line 47 "src/distribution/GammaExponential.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/GammaExponential.birch"
  return 0.0;
}

#line 50 "src/distribution/GammaExponential.birch"
void birch::type::GammaExponential::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "src/distribution/GammaExponential.birch"
  libbirch_function_("link", "src/distribution/GammaExponential.birch", 50);
  #line 51 "src/distribution/GammaExponential.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/GammaExponential.birch"
  this_()->_u0955->setChild(shared_from_this_(), handler_);
}

#line 54 "src/distribution/GammaExponential.birch"
void birch::type::GammaExponential::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "src/distribution/GammaExponential.birch"
  libbirch_function_("unlink", "src/distribution/GammaExponential.birch", 54);
  #line 55 "src/distribution/GammaExponential.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/GammaExponential.birch"
  this_()->_u0955->releaseChild(shared_from_this_(), handler_);
}

#line 59 "src/distribution/GammaExponential.birch"
libbirch::Lazy<libbirch::Shared<birch::type::GammaExponential>> birch::GammaExponential(const libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/distribution/GammaExponential.birch"
  libbirch_function_("GammaExponential", "src/distribution/GammaExponential.birch", 59);
  #line 60 "src/distribution/GammaExponential.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/GammaExponential.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::GammaExponential>> m(_u0955);
  #line 61 "src/distribution/GammaExponential.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/GammaExponential.birch"
  m->link(handler_);
  #line 62 "src/distribution/GammaExponential.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/GammaExponential.birch"
  return m;
}

#line 4 "src/distribution/GammaPoisson.birch"
birch::type::GammaPoisson::GammaPoisson(const libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/GammaPoisson.birch"
    super_type_(),
    #line 8 "src/distribution/GammaPoisson.birch"
    _u0955(_u0955) {
  //
}

#line 10 "src/distribution/GammaPoisson.birch"
birch::type::Boolean birch::type::GammaPoisson::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/distribution/GammaPoisson.birch"
  libbirch_function_("supportsLazy", "src/distribution/GammaPoisson.birch", 10);
  #line 11 "src/distribution/GammaPoisson.birch"
  libbirch_line_(11);
  #line 11 "src/distribution/GammaPoisson.birch"
  return true;
}

#line 14 "src/distribution/GammaPoisson.birch"
birch::type::Integer birch::type::GammaPoisson::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/distribution/GammaPoisson.birch"
  libbirch_function_("simulate", "src/distribution/GammaPoisson.birch", 14);
  #line 15 "src/distribution/GammaPoisson.birch"
  libbirch_line_(15);
  #line 15 "src/distribution/GammaPoisson.birch"
  if (this_()->value.query()) {
    #line 16 "src/distribution/GammaPoisson.birch"
    libbirch_line_(16);
    #line 16 "src/distribution/GammaPoisson.birch"
    return this_()->value.get();
  } else {
    #line 18 "src/distribution/GammaPoisson.birch"
    libbirch_line_(18);
    #line 18 "src/distribution/GammaPoisson.birch"
    return birch::simulate_gamma_poisson(this_()->_u0955->k->value(handler_), this_()->_u0955->_u0952->value(handler_), handler_);
  }
}

#line 22 "src/distribution/GammaPoisson.birch"
libbirch::Optional<birch::type::Integer> birch::type::GammaPoisson::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/distribution/GammaPoisson.birch"
  libbirch_function_("simulateLazy", "src/distribution/GammaPoisson.birch", 22);
  #line 23 "src/distribution/GammaPoisson.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/GammaPoisson.birch"
  if (this_()->value.query()) {
    #line 24 "src/distribution/GammaPoisson.birch"
    libbirch_line_(24);
    #line 24 "src/distribution/GammaPoisson.birch"
    return this_()->value.get();
  } else {
    #line 26 "src/distribution/GammaPoisson.birch"
    libbirch_line_(26);
    #line 26 "src/distribution/GammaPoisson.birch"
    return birch::simulate_gamma_poisson(this_()->_u0955->k->get(handler_), this_()->_u0955->_u0952->get(handler_), handler_);
  }
}

#line 30 "src/distribution/GammaPoisson.birch"
birch::type::Real birch::type::GammaPoisson::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/distribution/GammaPoisson.birch"
  libbirch_function_("logpdf", "src/distribution/GammaPoisson.birch", 30);
  #line 31 "src/distribution/GammaPoisson.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/GammaPoisson.birch"
  return birch::logpdf_gamma_poisson(x, this_()->_u0955->k->value(handler_), this_()->_u0955->_u0952->value(handler_), handler_);
}

#line 34 "src/distribution/GammaPoisson.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::GammaPoisson::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/distribution/GammaPoisson.birch"
  libbirch_function_("logpdfLazy", "src/distribution/GammaPoisson.birch", 34);
  #line 35 "src/distribution/GammaPoisson.birch"
  libbirch_line_(35);
  #line 35 "src/distribution/GammaPoisson.birch"
  return birch::logpdf_lazy_gamma_poisson(x, this_()->_u0955->k, this_()->_u0955->_u0952, handler_);
}

#line 38 "src/distribution/GammaPoisson.birch"
void birch::type::GammaPoisson::update(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "src/distribution/GammaPoisson.birch"
  libbirch_function_("update", "src/distribution/GammaPoisson.birch", 38);
  #line 39 "src/distribution/GammaPoisson.birch"
  libbirch_line_(39);
  #line 39 "src/distribution/GammaPoisson.birch"
  libbirch::tie(this_()->_u0955->k, this_()->_u0955->_u0952) = birch::box(birch::update_gamma_poisson(x, this_()->_u0955->k->value(handler_), this_()->_u0955->_u0952->value(handler_), handler_), handler_);
}

#line 42 "src/distribution/GammaPoisson.birch"
void birch::type::GammaPoisson::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/distribution/GammaPoisson.birch"
  libbirch_function_("updateLazy", "src/distribution/GammaPoisson.birch", 42);
  #line 43 "src/distribution/GammaPoisson.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/GammaPoisson.birch"
  libbirch::tie(this_()->_u0955->k, this_()->_u0955->_u0952) = birch::update_lazy_gamma_poisson(x, this_()->_u0955->k, this_()->_u0955->_u0952, handler_);
}

#line 46 "src/distribution/GammaPoisson.birch"
libbirch::Optional<birch::type::Real> birch::type::GammaPoisson::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/distribution/GammaPoisson.birch"
  libbirch_function_("cdf", "src/distribution/GammaPoisson.birch", 46);
  #line 47 "src/distribution/GammaPoisson.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/GammaPoisson.birch"
  return birch::cdf_gamma_poisson(x, this_()->_u0955->k->value(handler_), this_()->_u0955->_u0952->value(handler_), handler_);
}

#line 50 "src/distribution/GammaPoisson.birch"
libbirch::Optional<birch::type::Integer> birch::type::GammaPoisson::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "src/distribution/GammaPoisson.birch"
  libbirch_function_("quantile", "src/distribution/GammaPoisson.birch", 50);
  #line 51 "src/distribution/GammaPoisson.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/GammaPoisson.birch"
  return birch::quantile_gamma_poisson(P, this_()->_u0955->k->value(handler_), this_()->_u0955->_u0952->value(handler_), handler_);
}

#line 54 "src/distribution/GammaPoisson.birch"
libbirch::Optional<birch::type::Integer> birch::type::GammaPoisson::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "src/distribution/GammaPoisson.birch"
  libbirch_function_("lower", "src/distribution/GammaPoisson.birch", 54);
  #line 55 "src/distribution/GammaPoisson.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/GammaPoisson.birch"
  return birch::type::Integer(0);
}

#line 58 "src/distribution/GammaPoisson.birch"
void birch::type::GammaPoisson::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "src/distribution/GammaPoisson.birch"
  libbirch_function_("link", "src/distribution/GammaPoisson.birch", 58);
  #line 59 "src/distribution/GammaPoisson.birch"
  libbirch_line_(59);
  #line 59 "src/distribution/GammaPoisson.birch"
  this_()->_u0955->setChild(shared_from_this_(), handler_);
}

#line 62 "src/distribution/GammaPoisson.birch"
void birch::type::GammaPoisson::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 62 "src/distribution/GammaPoisson.birch"
  libbirch_function_("unlink", "src/distribution/GammaPoisson.birch", 62);
  #line 63 "src/distribution/GammaPoisson.birch"
  libbirch_line_(63);
  #line 63 "src/distribution/GammaPoisson.birch"
  this_()->_u0955->releaseChild(shared_from_this_(), handler_);
}

#line 67 "src/distribution/GammaPoisson.birch"
libbirch::Lazy<libbirch::Shared<birch::type::GammaPoisson>> birch::GammaPoisson(const libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 67 "src/distribution/GammaPoisson.birch"
  libbirch_function_("GammaPoisson", "src/distribution/GammaPoisson.birch", 67);
  #line 68 "src/distribution/GammaPoisson.birch"
  libbirch_line_(68);
  #line 68 "src/distribution/GammaPoisson.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::GammaPoisson>> m(_u0955);
  #line 69 "src/distribution/GammaPoisson.birch"
  libbirch_line_(69);
  #line 69 "src/distribution/GammaPoisson.birch"
  m->link(handler_);
  #line 70 "src/distribution/GammaPoisson.birch"
  libbirch_line_(70);
  #line 70 "src/distribution/GammaPoisson.birch"
  return m;
}

#line 1 "src/distribution/Gaussian.birch"
birch::type::Gaussian::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/distribution/Gaussian.birch"
    super_type_(),
    #line 9 "src/distribution/Gaussian.birch"
    _u0956(_u0956),
    #line 14 "src/distribution/Gaussian.birch"
    _u09632(_u09632) {
  //
}

#line 16 "src/distribution/Gaussian.birch"
birch::type::Boolean birch::type::Gaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/distribution/Gaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/Gaussian.birch", 16);
  #line 17 "src/distribution/Gaussian.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/Gaussian.birch"
  return true;
}

#line 20 "src/distribution/Gaussian.birch"
birch::type::Real birch::type::Gaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/distribution/Gaussian.birch"
  libbirch_function_("simulate", "src/distribution/Gaussian.birch", 20);
  #line 21 "src/distribution/Gaussian.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/Gaussian.birch"
  return birch::simulate_gaussian(this_()->_u0956->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 24 "src/distribution/Gaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::Gaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/distribution/Gaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/Gaussian.birch", 24);
  #line 25 "src/distribution/Gaussian.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/Gaussian.birch"
  return birch::simulate_gaussian(this_()->_u0956->get(handler_), this_()->_u09632->get(handler_), handler_);
}

#line 28 "src/distribution/Gaussian.birch"
birch::type::Real birch::type::Gaussian::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/distribution/Gaussian.birch"
  libbirch_function_("logpdf", "src/distribution/Gaussian.birch", 28);
  #line 29 "src/distribution/Gaussian.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/Gaussian.birch"
  return birch::logpdf_gaussian(x, this_()->_u0956->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 32 "src/distribution/Gaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::Gaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/distribution/Gaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/Gaussian.birch", 32);
  #line 33 "src/distribution/Gaussian.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/Gaussian.birch"
  return birch::logpdf_lazy_gaussian(x, this_()->_u0956, this_()->_u09632, handler_);
}

#line 36 "src/distribution/Gaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::Gaussian::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/distribution/Gaussian.birch"
  libbirch_function_("cdf", "src/distribution/Gaussian.birch", 36);
  #line 37 "src/distribution/Gaussian.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/Gaussian.birch"
  return birch::cdf_gaussian(x, this_()->_u0956->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 40 "src/distribution/Gaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::Gaussian::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "src/distribution/Gaussian.birch"
  libbirch_function_("quantile", "src/distribution/Gaussian.birch", 40);
  #line 41 "src/distribution/Gaussian.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/Gaussian.birch"
  return birch::quantile_gaussian(P, this_()->_u0956->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 44 "src/distribution/Gaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> birch::type::Gaussian::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/distribution/Gaussian.birch"
  libbirch_function_("graft", "src/distribution/Gaussian.birch", 44);
  #line 45 "src/distribution/Gaussian.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/Gaussian.birch"
  this_()->prune(handler_);
  #line 46 "src/distribution/Gaussian.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/Gaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>>>>> m1;
  #line 47 "src/distribution/Gaussian.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/Gaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> m2;
  #line 48 "src/distribution/Gaussian.birch"
  libbirch_line_(48);
  #line 48 "src/distribution/Gaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>> m3;
  #line 49 "src/distribution/Gaussian.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/Gaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>>>>> m4;
  #line 50 "src/distribution/Gaussian.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/Gaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> m5;
  #line 51 "src/distribution/Gaussian.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/Gaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>> m6;
  #line 52 "src/distribution/Gaussian.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/Gaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>> s2;
  #line 53 "src/distribution/Gaussian.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/Gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> r = shared_from_this_();
  #line 56 "src/distribution/Gaussian.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/Gaussian.birch"
  auto compare = this_()->_u09632->distribution(handler_);
  #line 57 "src/distribution/Gaussian.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/Gaussian.birch"
  if (compare.query() && (m1 = this_()->_u0956->graftLinearNormalInverseGamma(compare.get(), handler_)).query()) {
    #line 58 "src/distribution/Gaussian.birch"
    libbirch_line_(58);
    #line 58 "src/distribution/Gaussian.birch"
    r = birch::LinearNormalInverseGammaGaussian(m1.get()->a, m1.get()->x, m1.get()->c, handler_);
  } else {
    #line 59 "src/distribution/Gaussian.birch"
    libbirch_line_(59);
    #line 59 "src/distribution/Gaussian.birch"
    if (compare.query() && (m2 = this_()->_u0956->graftDotNormalInverseGamma(compare.get(), handler_)).query()) {
      #line 60 "src/distribution/Gaussian.birch"
      libbirch_line_(60);
      #line 60 "src/distribution/Gaussian.birch"
      r = birch::LinearMultivariateNormalInverseGammaGaussian(m2.get()->a, m2.get()->x, m2.get()->c, handler_);
    } else {
      #line 61 "src/distribution/Gaussian.birch"
      libbirch_line_(61);
      #line 61 "src/distribution/Gaussian.birch"
      if (compare.query() && (m3 = this_()->_u0956->graftNormalInverseGamma(compare.get(), handler_)).query()) {
        #line 62 "src/distribution/Gaussian.birch"
        libbirch_line_(62);
        #line 62 "src/distribution/Gaussian.birch"
        r = birch::NormalInverseGammaGaussian(m3.get(), handler_);
      } else {
        #line 63 "src/distribution/Gaussian.birch"
        libbirch_line_(63);
        #line 63 "src/distribution/Gaussian.birch"
        if ((m4 = this_()->_u0956->graftLinearGaussian(handler_)).query()) {
          #line 64 "src/distribution/Gaussian.birch"
          libbirch_line_(64);
          #line 64 "src/distribution/Gaussian.birch"
          r = birch::LinearGaussianGaussian(m4.get()->a, m4.get()->x, m4.get()->c, this_()->_u09632, handler_);
        } else {
          #line 65 "src/distribution/Gaussian.birch"
          libbirch_line_(65);
          #line 65 "src/distribution/Gaussian.birch"
          if ((m5 = this_()->_u0956->graftDotGaussian(handler_)).query()) {
            #line 66 "src/distribution/Gaussian.birch"
            libbirch_line_(66);
            #line 66 "src/distribution/Gaussian.birch"
            r = birch::LinearMultivariateGaussianGaussian(m5.get()->a, m5.get()->x, m5.get()->c, this_()->_u09632, handler_);
          } else {
            #line 67 "src/distribution/Gaussian.birch"
            libbirch_line_(67);
            #line 67 "src/distribution/Gaussian.birch"
            if ((m6 = this_()->_u0956->graftGaussian(handler_)).query()) {
              #line 68 "src/distribution/Gaussian.birch"
              libbirch_line_(68);
              #line 68 "src/distribution/Gaussian.birch"
              r = birch::GaussianGaussian(m6.get(), this_()->_u09632, handler_);
            } else {
              #line 69 "src/distribution/Gaussian.birch"
              libbirch_line_(69);
              #line 69 "src/distribution/Gaussian.birch"
              if ((s2 = this_()->_u09632->graftInverseGamma(handler_)).query()) {
                #line 70 "src/distribution/Gaussian.birch"
                libbirch_line_(70);
                #line 70 "src/distribution/Gaussian.birch"
                r = birch::NormalInverseGamma(this_()->_u0956, birch::box(1.0, handler_), s2.get(), handler_);
              }
            }
          }
        }
      }
    }
  }
  #line 73 "src/distribution/Gaussian.birch"
  libbirch_line_(73);
  #line 73 "src/distribution/Gaussian.birch"
  return r;
}

#line 76 "src/distribution/Gaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>> birch::type::Gaussian::graftGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "src/distribution/Gaussian.birch"
  libbirch_function_("graftGaussian", "src/distribution/Gaussian.birch", 76);
  #line 77 "src/distribution/Gaussian.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/Gaussian.birch"
  this_()->prune(handler_);
  #line 78 "src/distribution/Gaussian.birch"
  libbirch_line_(78);
  #line 78 "src/distribution/Gaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>>>>> m1;
  #line 79 "src/distribution/Gaussian.birch"
  libbirch_line_(79);
  #line 79 "src/distribution/Gaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> m2;
  #line 80 "src/distribution/Gaussian.birch"
  libbirch_line_(80);
  #line 80 "src/distribution/Gaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>> m3;
  #line 81 "src/distribution/Gaussian.birch"
  libbirch_line_(81);
  #line 81 "src/distribution/Gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>> r = shared_from_this_();
  #line 84 "src/distribution/Gaussian.birch"
  libbirch_line_(84);
  #line 84 "src/distribution/Gaussian.birch"
  if ((m1 = this_()->_u0956->graftLinearGaussian(handler_)).query()) {
    #line 85 "src/distribution/Gaussian.birch"
    libbirch_line_(85);
    #line 85 "src/distribution/Gaussian.birch"
    r = birch::LinearGaussianGaussian(m1.get()->a, m1.get()->x, m1.get()->c, this_()->_u09632, handler_);
  } else {
    #line 86 "src/distribution/Gaussian.birch"
    libbirch_line_(86);
    #line 86 "src/distribution/Gaussian.birch"
    if ((m2 = this_()->_u0956->graftDotGaussian(handler_)).query()) {
      #line 87 "src/distribution/Gaussian.birch"
      libbirch_line_(87);
      #line 87 "src/distribution/Gaussian.birch"
      r = birch::LinearMultivariateGaussianGaussian(m2.get()->a, m2.get()->x, m2.get()->c, this_()->_u09632, handler_);
    } else {
      #line 88 "src/distribution/Gaussian.birch"
      libbirch_line_(88);
      #line 88 "src/distribution/Gaussian.birch"
      if ((m3 = this_()->_u0956->graftGaussian(handler_)).query()) {
        #line 89 "src/distribution/Gaussian.birch"
        libbirch_line_(89);
        #line 89 "src/distribution/Gaussian.birch"
        r = birch::GaussianGaussian(m3.get(), this_()->_u09632, handler_);
      }
    }
  }
  #line 92 "src/distribution/Gaussian.birch"
  libbirch_line_(92);
  #line 92 "src/distribution/Gaussian.birch"
  return r;
}

#line 95 "src/distribution/Gaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>> birch::type::Gaussian::graftNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "src/distribution/Gaussian.birch"
  libbirch_function_("graftNormalInverseGamma", "src/distribution/Gaussian.birch", 95);
  #line 97 "src/distribution/Gaussian.birch"
  libbirch_line_(97);
  #line 97 "src/distribution/Gaussian.birch"
  this_()->prune(handler_);
  #line 98 "src/distribution/Gaussian.birch"
  libbirch_line_(98);
  #line 98 "src/distribution/Gaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>> s1;
  #line 99 "src/distribution/Gaussian.birch"
  libbirch_line_(99);
  #line 99 "src/distribution/Gaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>> r;
  #line 102 "src/distribution/Gaussian.birch"
  libbirch_line_(102);
  #line 102 "src/distribution/Gaussian.birch"
  if ((s1 = this_()->_u09632->graftInverseGamma(handler_)).query() && s1.get() == compare) {
    #line 103 "src/distribution/Gaussian.birch"
    libbirch_line_(103);
    #line 103 "src/distribution/Gaussian.birch"
    r = birch::NormalInverseGamma(this_()->_u0956, birch::box(1.0, handler_), s1.get(), handler_);
  }
  #line 106 "src/distribution/Gaussian.birch"
  libbirch_line_(106);
  #line 106 "src/distribution/Gaussian.birch"
  return r;
}

#line 109 "src/distribution/Gaussian.birch"
void birch::type::Gaussian::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 109 "src/distribution/Gaussian.birch"
  libbirch_function_("write", "src/distribution/Gaussian.birch", 109);
  #line 110 "src/distribution/Gaussian.birch"
  libbirch_line_(110);
  #line 110 "src/distribution/Gaussian.birch"
  this_()->prune(handler_);
  #line 111 "src/distribution/Gaussian.birch"
  libbirch_line_(111);
  #line 111 "src/distribution/Gaussian.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Gaussian"), handler_);
  #line 112 "src/distribution/Gaussian.birch"
  libbirch_line_(112);
  #line 112 "src/distribution/Gaussian.birch"
  buffer->set(birch::type::String("μ"), this_()->_u0956->value(handler_), handler_);
  #line 113 "src/distribution/Gaussian.birch"
  libbirch_line_(113);
  #line 113 "src/distribution/Gaussian.birch"
  buffer->set(birch::type::String("σ2"), this_()->_u09632->value(handler_), handler_);
}

#line 120 "src/distribution/Gaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 120 "src/distribution/Gaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/Gaussian.birch", 120);
  #line 121 "src/distribution/Gaussian.birch"
  libbirch_line_(121);
  #line 121 "src/distribution/Gaussian.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>>(_u0956, _u09632, handler_);
}

#line 127 "src/distribution/Gaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 127 "src/distribution/Gaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/Gaussian.birch", 127);
  #line 128 "src/distribution/Gaussian.birch"
  libbirch_line_(128);
  #line 128 "src/distribution/Gaussian.birch"
  return birch::Gaussian(_u0956, birch::box(_u09632, handler_), handler_);
}

#line 134 "src/distribution/Gaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>> birch::Gaussian(const birch::type::Real& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 134 "src/distribution/Gaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/Gaussian.birch", 134);
  #line 135 "src/distribution/Gaussian.birch"
  libbirch_line_(135);
  #line 135 "src/distribution/Gaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), _u09632, handler_);
}

#line 141 "src/distribution/Gaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>> birch::Gaussian(const birch::type::Real& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 141 "src/distribution/Gaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/Gaussian.birch", 141);
  #line 142 "src/distribution/Gaussian.birch"
  libbirch_line_(142);
  #line 142 "src/distribution/Gaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), birch::box(_u09632, handler_), handler_);
}

#line 4 "src/distribution/GaussianGaussian.birch"
birch::type::GaussianGaussian::GaussianGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>& m, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& s2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/GaussianGaussian.birch"
    super_type_(m->_u0956, m->_u09632 + s2),
    #line 9 "src/distribution/GaussianGaussian.birch"
    m(m),
    #line 14 "src/distribution/GaussianGaussian.birch"
    s2(s2) {
  //
}

#line 16 "src/distribution/GaussianGaussian.birch"
void birch::type::GaussianGaussian::update(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/distribution/GaussianGaussian.birch"
  libbirch_function_("update", "src/distribution/GaussianGaussian.birch", 16);
  #line 17 "src/distribution/GaussianGaussian.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/GaussianGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u09632) = birch::box(birch::update_gaussian_gaussian(x, this_()->m->_u0956->value(handler_), this_()->m->_u09632->value(handler_), this_()->s2->value(handler_), handler_), handler_);
}

#line 20 "src/distribution/GaussianGaussian.birch"
void birch::type::GaussianGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/distribution/GaussianGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/GaussianGaussian.birch", 20);
  #line 21 "src/distribution/GaussianGaussian.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/GaussianGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u09632) = birch::update_lazy_gaussian_gaussian(x, this_()->m->_u0956, this_()->m->_u09632, this_()->s2, handler_);
}

#line 24 "src/distribution/GaussianGaussian.birch"
void birch::type::GaussianGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/distribution/GaussianGaussian.birch"
  libbirch_function_("link", "src/distribution/GaussianGaussian.birch", 24);
  #line 25 "src/distribution/GaussianGaussian.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/GaussianGaussian.birch"
  this_()->m->setChild(shared_from_this_(), handler_);
}

#line 28 "src/distribution/GaussianGaussian.birch"
void birch::type::GaussianGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/distribution/GaussianGaussian.birch"
  libbirch_function_("unlink", "src/distribution/GaussianGaussian.birch", 28);
  #line 29 "src/distribution/GaussianGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/GaussianGaussian.birch"
  this_()->m->releaseChild(shared_from_this_(), handler_);
}

#line 33 "src/distribution/GaussianGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::GaussianGaussian>> birch::GaussianGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/distribution/GaussianGaussian.birch"
  libbirch_function_("GaussianGaussian", "src/distribution/GaussianGaussian.birch", 33);
  #line 34 "src/distribution/GaussianGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/distribution/GaussianGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::GaussianGaussian>> m(_u0956, _u09632);
  #line 35 "src/distribution/GaussianGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/distribution/GaussianGaussian.birch"
  m->link(handler_);
  #line 36 "src/distribution/GaussianGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/GaussianGaussian.birch"
  return m;
}

#line 4 "src/distribution/Geometric.birch"
libbirch::Lazy<libbirch::Shared<birch::type::NegativeBinomial>> birch::Geometric(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 4 "src/distribution/Geometric.birch"
  libbirch_function_("Geometric", "src/distribution/Geometric.birch", 4);
  #line 5 "src/distribution/Geometric.birch"
  libbirch_line_(5);
  #line 5 "src/distribution/Geometric.birch"
  return birch::NegativeBinomial(birch::box(birch::type::Integer(1), handler_), _u0961, handler_);
}

#line 11 "src/distribution/Geometric.birch"
libbirch::Lazy<libbirch::Shared<birch::type::NegativeBinomial>> birch::Geometric(const birch::type::Real& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/distribution/Geometric.birch"
  libbirch_function_("Geometric", "src/distribution/Geometric.birch", 11);
  #line 12 "src/distribution/Geometric.birch"
  libbirch_line_(12);
  #line 12 "src/distribution/Geometric.birch"
  return birch::Geometric(birch::box(_u0961, handler_), handler_);
}

#line 5 "src/distribution/IdenticalGaussian.birch"
birch::type::IdenticalGaussian::IdenticalGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 5 "src/distribution/IdenticalGaussian.birch"
    super_type_(),
    #line 10 "src/distribution/IdenticalGaussian.birch"
    _u0956(_u0956),
    #line 15 "src/distribution/IdenticalGaussian.birch"
    _u09632(_u09632) {
  //
}

#line 17 "src/distribution/IdenticalGaussian.birch"
birch::type::Integer birch::type::IdenticalGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 17 "src/distribution/IdenticalGaussian.birch"
  libbirch_function_("rows", "src/distribution/IdenticalGaussian.birch", 17);
  #line 18 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(18);
  #line 18 "src/distribution/IdenticalGaussian.birch"
  return this_()->_u0956->rows(handler_);
}

#line 21 "src/distribution/IdenticalGaussian.birch"
birch::type::Boolean birch::type::IdenticalGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "src/distribution/IdenticalGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/IdenticalGaussian.birch", 21);
  #line 22 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(22);
  #line 22 "src/distribution/IdenticalGaussian.birch"
  return true;
}

#line 25 "src/distribution/IdenticalGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::IdenticalGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/distribution/IdenticalGaussian.birch"
  libbirch_function_("simulate", "src/distribution/IdenticalGaussian.birch", 25);
  #line 26 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/distribution/IdenticalGaussian.birch"
  return birch::simulate_multivariate_gaussian(this_()->_u0956->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 29 "src/distribution/IdenticalGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::IdenticalGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "src/distribution/IdenticalGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/IdenticalGaussian.birch", 29);
  #line 30 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/distribution/IdenticalGaussian.birch"
  return birch::simulate_multivariate_gaussian(this_()->_u0956->get(handler_), this_()->_u09632->get(handler_), handler_);
}

#line 33 "src/distribution/IdenticalGaussian.birch"
birch::type::Real birch::type::IdenticalGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/distribution/IdenticalGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/IdenticalGaussian.birch", 33);
  #line 34 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/distribution/IdenticalGaussian.birch"
  return birch::logpdf_multivariate_gaussian(x, this_()->_u0956->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 37 "src/distribution/IdenticalGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::IdenticalGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/distribution/IdenticalGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/IdenticalGaussian.birch", 37);
  #line 38 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/distribution/IdenticalGaussian.birch"
  return birch::logpdf_lazy_multivariate_gaussian(x, this_()->_u0956, this_()->_u09632, handler_);
}

#line 41 "src/distribution/IdenticalGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>> birch::type::IdenticalGaussian::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "src/distribution/IdenticalGaussian.birch"
  libbirch_function_("graft", "src/distribution/IdenticalGaussian.birch", 41);
  #line 42 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/IdenticalGaussian.birch"
  this_()->prune(handler_);
  #line 43 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/IdenticalGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>> s1;
  #line 44 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(44);
  #line 44 "src/distribution/IdenticalGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> m1;
  #line 45 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/IdenticalGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>> m2;
  #line 46 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/IdenticalGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> m3;
  #line 47 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/IdenticalGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>> m4;
  #line 48 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/distribution/IdenticalGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>> r = shared_from_this_();
  #line 51 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/IdenticalGaussian.birch"
  auto compare = this_()->_u09632->distribution(handler_);
  #line 52 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/IdenticalGaussian.birch"
  if (compare.query() && (m1 = this_()->_u0956->graftLinearMultivariateNormalInverseGamma(compare.get(), handler_)).query()) {
    #line 53 "src/distribution/IdenticalGaussian.birch"
    libbirch_line_(53);
    #line 53 "src/distribution/IdenticalGaussian.birch"
    r = birch::LinearMultivariateNormalInverseGammaMultivariateGaussian(m1.get()->A, m1.get()->x, m1.get()->c, handler_);
  } else {
    #line 54 "src/distribution/IdenticalGaussian.birch"
    libbirch_line_(54);
    #line 54 "src/distribution/IdenticalGaussian.birch"
    if (compare.query() && (m2 = this_()->_u0956->graftMultivariateNormalInverseGamma(compare.get(), handler_)).query()) {
      #line 55 "src/distribution/IdenticalGaussian.birch"
      libbirch_line_(55);
      #line 55 "src/distribution/IdenticalGaussian.birch"
      r = birch::MultivariateNormalInverseGammaMultivariateGaussian(m2.get(), handler_);
    } else {
      #line 56 "src/distribution/IdenticalGaussian.birch"
      libbirch_line_(56);
      #line 56 "src/distribution/IdenticalGaussian.birch"
      if ((m3 = this_()->_u0956->graftLinearMultivariateGaussian(handler_)).query()) {
        #line 57 "src/distribution/IdenticalGaussian.birch"
        libbirch_line_(57);
        #line 57 "src/distribution/IdenticalGaussian.birch"
        r = birch::LinearMultivariateGaussianMultivariateGaussian(m3.get()->A, m3.get()->x, m3.get()->c, birch::llt(birch::diagonal(this_()->_u09632, m3.get()->rows(handler_), handler_), handler_), handler_);
      } else {
        #line 59 "src/distribution/IdenticalGaussian.birch"
        libbirch_line_(59);
        #line 59 "src/distribution/IdenticalGaussian.birch"
        if ((m4 = this_()->_u0956->graftMultivariateGaussian(handler_)).query()) {
          #line 60 "src/distribution/IdenticalGaussian.birch"
          libbirch_line_(60);
          #line 60 "src/distribution/IdenticalGaussian.birch"
          r = birch::MultivariateGaussianMultivariateGaussian(m4.get(), birch::llt(birch::diagonal(this_()->_u09632, m4.get()->rows(handler_), handler_), handler_), handler_);
        } else {
          #line 62 "src/distribution/IdenticalGaussian.birch"
          libbirch_line_(62);
          #line 62 "src/distribution/IdenticalGaussian.birch"
          if ((s1 = this_()->_u09632->graftInverseGamma(handler_)).query()) {
            #line 63 "src/distribution/IdenticalGaussian.birch"
            libbirch_line_(63);
            #line 63 "src/distribution/IdenticalGaussian.birch"
            r = birch::MultivariateNormalInverseGamma(this_()->_u0956, birch::box(birch::llt(birch::identity(this_()->_u0956->rows(handler_), handler_), handler_), handler_), s1.get(), handler_);
          }
        }
      }
    }
  }
  #line 66 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/IdenticalGaussian.birch"
  return r;
}

#line 69 "src/distribution/IdenticalGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>> birch::type::IdenticalGaussian::graftMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "src/distribution/IdenticalGaussian.birch"
  libbirch_function_("graftMultivariateGaussian", "src/distribution/IdenticalGaussian.birch", 69);
  #line 70 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(70);
  #line 70 "src/distribution/IdenticalGaussian.birch"
  this_()->prune(handler_);
  #line 71 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(71);
  #line 71 "src/distribution/IdenticalGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> m1;
  #line 72 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(72);
  #line 72 "src/distribution/IdenticalGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>> m2;
  #line 73 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(73);
  #line 73 "src/distribution/IdenticalGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>> r;
  #line 76 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(76);
  #line 76 "src/distribution/IdenticalGaussian.birch"
  if ((m1 = this_()->_u0956->graftLinearMultivariateGaussian(handler_)).query()) {
    #line 77 "src/distribution/IdenticalGaussian.birch"
    libbirch_line_(77);
    #line 77 "src/distribution/IdenticalGaussian.birch"
    r = birch::LinearMultivariateGaussianMultivariateGaussian(m1.get()->A, m1.get()->x, m1.get()->c, birch::llt(birch::diagonal(this_()->_u09632, m1.get()->c->rows(handler_), handler_), handler_), handler_);
  } else {
    #line 79 "src/distribution/IdenticalGaussian.birch"
    libbirch_line_(79);
    #line 79 "src/distribution/IdenticalGaussian.birch"
    if ((m2 = this_()->_u0956->graftMultivariateGaussian(handler_)).query()) {
      #line 80 "src/distribution/IdenticalGaussian.birch"
      libbirch_line_(80);
      #line 80 "src/distribution/IdenticalGaussian.birch"
      r = birch::MultivariateGaussianMultivariateGaussian(m2.get(), birch::llt(birch::diagonal(this_()->_u09632, m2.get()->rows(handler_), handler_), handler_), handler_);
    } else {
      #line 83 "src/distribution/IdenticalGaussian.birch"
      libbirch_line_(83);
      #line 83 "src/distribution/IdenticalGaussian.birch"
      r = birch::Gaussian(this_()->_u0956, birch::diagonal(this_()->_u09632, this_()->_u0956->rows(handler_), handler_), handler_);
    }
  }
  #line 86 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(86);
  #line 86 "src/distribution/IdenticalGaussian.birch"
  return r;
}

#line 89 "src/distribution/IdenticalGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>> birch::type::IdenticalGaussian::graftMultivariateNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 89 "src/distribution/IdenticalGaussian.birch"
  libbirch_function_("graftMultivariateNormalInverseGamma", "src/distribution/IdenticalGaussian.birch", 89);
  #line 91 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(91);
  #line 91 "src/distribution/IdenticalGaussian.birch"
  this_()->prune(handler_);
  #line 92 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(92);
  #line 92 "src/distribution/IdenticalGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>> s1;
  #line 93 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(93);
  #line 93 "src/distribution/IdenticalGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>> r;
  #line 95 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(95);
  #line 95 "src/distribution/IdenticalGaussian.birch"
  if ((s1 = this_()->_u09632->graftInverseGamma(handler_)).query() && s1.get() == compare) {
    #line 96 "src/distribution/IdenticalGaussian.birch"
    libbirch_line_(96);
    #line 96 "src/distribution/IdenticalGaussian.birch"
    r = birch::MultivariateNormalInverseGamma(this_()->_u0956, birch::box(birch::llt(birch::identity(this_()->_u0956->rows(handler_), handler_), handler_), handler_), s1.get(), handler_);
  }
  #line 99 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(99);
  #line 99 "src/distribution/IdenticalGaussian.birch"
  return r;
}

#line 107 "src/distribution/IdenticalGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IdenticalGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 107 "src/distribution/IdenticalGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IdenticalGaussian.birch", 107);
  #line 109 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(109);
  #line 109 "src/distribution/IdenticalGaussian.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::IdenticalGaussian>>>(_u0956, _u09632, handler_);
}

#line 116 "src/distribution/IdenticalGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IdenticalGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 116 "src/distribution/IdenticalGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IdenticalGaussian.birch", 116);
  #line 117 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(117);
  #line 117 "src/distribution/IdenticalGaussian.birch"
  return birch::Gaussian(_u0956, birch::box(_u09632, handler_), handler_);
}

#line 124 "src/distribution/IdenticalGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IdenticalGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 124 "src/distribution/IdenticalGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IdenticalGaussian.birch", 124);
  #line 125 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(125);
  #line 125 "src/distribution/IdenticalGaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), _u09632, handler_);
}

#line 132 "src/distribution/IdenticalGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IdenticalGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 132 "src/distribution/IdenticalGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IdenticalGaussian.birch", 132);
  #line 133 "src/distribution/IdenticalGaussian.birch"
  libbirch_line_(133);
  #line 133 "src/distribution/IdenticalGaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), birch::box(_u09632, handler_), handler_);
}

#line 4 "src/distribution/IndependentColumnMatrixGaussian.birch"
birch::type::IndependentColumnMatrixGaussian::IndependentColumnMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& v, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/IndependentColumnMatrixGaussian.birch"
    super_type_(),
    #line 9 "src/distribution/IndependentColumnMatrixGaussian.birch"
    M(M),
    #line 14 "src/distribution/IndependentColumnMatrixGaussian.birch"
    U(U),
    #line 19 "src/distribution/IndependentColumnMatrixGaussian.birch"
    _u09632(v) {
  //
}

#line 21 "src/distribution/IndependentColumnMatrixGaussian.birch"
birch::type::Integer birch::type::IndependentColumnMatrixGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("rows", "src/distribution/IndependentColumnMatrixGaussian.birch", 21);
  #line 22 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(22);
  #line 22 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return this_()->M->rows(handler_);
}

#line 25 "src/distribution/IndependentColumnMatrixGaussian.birch"
birch::type::Integer birch::type::IndependentColumnMatrixGaussian::columns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("columns", "src/distribution/IndependentColumnMatrixGaussian.birch", 25);
  #line 26 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return this_()->M->columns(handler_);
}

#line 29 "src/distribution/IndependentColumnMatrixGaussian.birch"
birch::type::Boolean birch::type::IndependentColumnMatrixGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/IndependentColumnMatrixGaussian.birch", 29);
  #line 30 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return true;
}

#line 33 "src/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::IndependentColumnMatrixGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("simulate", "src/distribution/IndependentColumnMatrixGaussian.birch", 33);
  #line 34 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::simulate_matrix_gaussian(this_()->M->value(handler_), this_()->U->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 37 "src/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::IndependentColumnMatrixGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/IndependentColumnMatrixGaussian.birch", 37);
  #line 38 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::simulate_matrix_gaussian(this_()->M->get(handler_), this_()->U->get(handler_), this_()->_u09632->get(handler_), handler_);
}

#line 41 "src/distribution/IndependentColumnMatrixGaussian.birch"
birch::type::Real birch::type::IndependentColumnMatrixGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/IndependentColumnMatrixGaussian.birch", 41);
  #line 42 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::logpdf_matrix_gaussian(x, this_()->M->value(handler_), this_()->U->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 45 "src/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::IndependentColumnMatrixGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/IndependentColumnMatrixGaussian.birch", 45);
  #line 46 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::logpdf_lazy_matrix_gaussian(x, this_()->M, this_()->U, this_()->_u09632, handler_);
}

#line 49 "src/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>> birch::type::IndependentColumnMatrixGaussian::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("graft", "src/distribution/IndependentColumnMatrixGaussian.birch", 49);
  #line 50 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/IndependentColumnMatrixGaussian.birch"
  this_()->prune(handler_);
  #line 51 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::IndependentInverseGamma>>> s1;
  #line 52 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>> r = shared_from_this_();
  #line 55 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/IndependentColumnMatrixGaussian.birch"
  if ((s1 = this_()->_u09632->graftIndependentInverseGamma(handler_)).query()) {
    #line 56 "src/distribution/IndependentColumnMatrixGaussian.birch"
    libbirch_line_(56);
    #line 56 "src/distribution/IndependentColumnMatrixGaussian.birch"
    r = birch::MatrixNormalInverseGamma(this_()->M, this_()->U, s1.get(), handler_);
  } else {
    #line 58 "src/distribution/IndependentColumnMatrixGaussian.birch"
    libbirch_line_(58);
    #line 58 "src/distribution/IndependentColumnMatrixGaussian.birch"
    r = birch::Gaussian(this_()->M, this_()->U, birch::diagonal(this_()->_u09632, handler_), handler_);
  }
  #line 61 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return r;
}

#line 64 "src/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>> birch::type::IndependentColumnMatrixGaussian::graftMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("graftMatrixGaussian", "src/distribution/IndependentColumnMatrixGaussian.birch", 64);
  #line 65 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/IndependentColumnMatrixGaussian.birch"
  this_()->prune(handler_);
  #line 66 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(this_()->M, this_()->U, birch::diagonal(this_()->_u09632, handler_), handler_);
}

#line 69 "src/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>> birch::type::IndependentColumnMatrixGaussian::graftMatrixNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("graftMatrixNormalInverseGamma", "src/distribution/IndependentColumnMatrixGaussian.birch", 69);
  #line 71 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(71);
  #line 71 "src/distribution/IndependentColumnMatrixGaussian.birch"
  this_()->prune(handler_);
  #line 72 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(72);
  #line 72 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::IndependentInverseGamma>>> s1;
  #line 73 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(73);
  #line 73 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>> r;
  #line 76 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(76);
  #line 76 "src/distribution/IndependentColumnMatrixGaussian.birch"
  if ((s1 = this_()->_u09632->graftIndependentInverseGamma(handler_)).query() && s1.get() == compare) {
    #line 77 "src/distribution/IndependentColumnMatrixGaussian.birch"
    libbirch_line_(77);
    #line 77 "src/distribution/IndependentColumnMatrixGaussian.birch"
    r = birch::MatrixNormalInverseGamma(this_()->M, this_()->U, s1.get(), handler_);
  }
  #line 80 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(80);
  #line 80 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return r;
}

#line 87 "src/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 87 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentColumnMatrixGaussian.birch", 87);
  #line 89 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(89);
  #line 89 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>>>(M, U, _u09632, handler_);
}

#line 95 "src/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentColumnMatrixGaussian.birch", 95);
  #line 97 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(97);
  #line 97 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::box(_u09632, handler_), handler_);
}

#line 103 "src/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const birch::type::LLT& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 103 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentColumnMatrixGaussian.birch", 103);
  #line 105 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(105);
  #line 105 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(M, birch::box(U, handler_), _u09632, handler_);
}

#line 111 "src/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const birch::type::LLT& U, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 111 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentColumnMatrixGaussian.birch", 111);
  #line 113 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(113);
  #line 113 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(M, birch::box(U, handler_), birch::box(_u09632, handler_), handler_);
}

#line 119 "src/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 119 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentColumnMatrixGaussian.birch", 119);
  #line 121 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(121);
  #line 121 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(birch::box(M, handler_), U, _u09632, handler_);
}

#line 127 "src/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 127 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentColumnMatrixGaussian.birch", 127);
  #line 129 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(129);
  #line 129 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(birch::box(M, handler_), U, birch::box(_u09632, handler_), handler_);
}

#line 135 "src/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 135 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentColumnMatrixGaussian.birch", 135);
  #line 137 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(137);
  #line 137 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(birch::box(M, handler_), birch::box(U, handler_), _u09632, handler_);
}

#line 143 "src/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 143 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentColumnMatrixGaussian.birch", 143);
  #line 145 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(145);
  #line 145 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(birch::box(M, handler_), birch::box(U, handler_), birch::box(_u09632, handler_), handler_);
}

#line 154 "src/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 154 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentColumnMatrixGaussian.birch", 154);
  #line 156 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(156);
  #line 156 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), _u09632, handler_);
}

#line 162 "src/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& U, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 162 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentColumnMatrixGaussian.birch", 162);
  #line 164 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(164);
  #line 164 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), _u09632, handler_);
}

#line 170 "src/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 170 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentColumnMatrixGaussian.birch", 170);
  #line 172 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(172);
  #line 172 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), _u09632, handler_);
}

#line 178 "src/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 178 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentColumnMatrixGaussian.birch", 178);
  #line 180 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(180);
  #line 180 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), _u09632, handler_);
}

#line 186 "src/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 186 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentColumnMatrixGaussian.birch", 186);
  #line 188 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(188);
  #line 188 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), _u09632, handler_);
}

#line 194 "src/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& U, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 194 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentColumnMatrixGaussian.birch", 194);
  #line 196 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(196);
  #line 196 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), _u09632, handler_);
}

#line 202 "src/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 202 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentColumnMatrixGaussian.birch", 202);
  #line 204 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(204);
  #line 204 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), _u09632, handler_);
}

#line 210 "src/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 210 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentColumnMatrixGaussian.birch", 210);
  #line 212 "src/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(212);
  #line 212 "src/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), _u09632, handler_);
}

#line 36 "src/distribution/IndependentInverseGamma.birch"
birch::type::IndependentInverseGamma::IndependentInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 36 "src/distribution/IndependentInverseGamma.birch"
    super_type_(),
    #line 41 "src/distribution/IndependentInverseGamma.birch"
    _u0945(_u0945),
    #line 46 "src/distribution/IndependentInverseGamma.birch"
    _u0946(_u0946) {
  //
}

#line 48 "src/distribution/IndependentInverseGamma.birch"
birch::type::Integer birch::type::IndependentInverseGamma::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "src/distribution/IndependentInverseGamma.birch"
  libbirch_function_("rows", "src/distribution/IndependentInverseGamma.birch", 48);
  #line 49 "src/distribution/IndependentInverseGamma.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/IndependentInverseGamma.birch"
  return this_()->_u0946->rows(handler_);
}

#line 52 "src/distribution/IndependentInverseGamma.birch"
birch::type::Boolean birch::type::IndependentInverseGamma::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "src/distribution/IndependentInverseGamma.birch"
  libbirch_function_("supportsLazy", "src/distribution/IndependentInverseGamma.birch", 52);
  #line 53 "src/distribution/IndependentInverseGamma.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/IndependentInverseGamma.birch"
  return false;
}

#line 56 "src/distribution/IndependentInverseGamma.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::IndependentInverseGamma::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 56 "src/distribution/IndependentInverseGamma.birch"
  libbirch_function_("simulate", "src/distribution/IndependentInverseGamma.birch", 56);
  #line 57 "src/distribution/IndependentInverseGamma.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/IndependentInverseGamma.birch"
  return birch::transform(this_()->_u0946->value(handler_), std::function<birch::type::Real(birch::type::Real,const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_
)>([=](const birch::type::Real& b, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr) {
    #line 59 "src/distribution/IndependentInverseGamma.birch"
    libbirch_line_(59);
    #line 59 "src/distribution/IndependentInverseGamma.birch"
    return birch::simulate_inverse_gamma(this_()->_u0945->value(handler_), b, handler_);
  }), handler_);
}

#line 63 "src/distribution/IndependentInverseGamma.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::IndependentInverseGamma::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 63 "src/distribution/IndependentInverseGamma.birch"
  libbirch_function_("simulateLazy", "src/distribution/IndependentInverseGamma.birch", 63);
  #line 64 "src/distribution/IndependentInverseGamma.birch"
  libbirch_line_(64);
  #line 64 "src/distribution/IndependentInverseGamma.birch"
  return birch::transform(this_()->_u0946->get(handler_), std::function<birch::type::Real(birch::type::Real,const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_
)>([=](const birch::type::Real& b, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr) {
    #line 66 "src/distribution/IndependentInverseGamma.birch"
    libbirch_line_(66);
    #line 66 "src/distribution/IndependentInverseGamma.birch"
    return birch::simulate_inverse_gamma(this_()->_u0945->get(handler_), b, handler_);
  }), handler_);
}

#line 70 "src/distribution/IndependentInverseGamma.birch"
birch::type::Real birch::type::IndependentInverseGamma::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "src/distribution/IndependentInverseGamma.birch"
  libbirch_function_("logpdf", "src/distribution/IndependentInverseGamma.birch", 70);
  #line 71 "src/distribution/IndependentInverseGamma.birch"
  libbirch_line_(71);
  #line 71 "src/distribution/IndependentInverseGamma.birch"
  return birch::transform_reduce(x, this_()->_u0946->value(handler_), 0.0, std::function<birch::type::Real(birch::type::Real,birch::type::Real,const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_
)>([=](const birch::type::Real& a, const birch::type::Real& b, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr) {
    #line 73 "src/distribution/IndependentInverseGamma.birch"
    libbirch_line_(73);
    #line 73 "src/distribution/IndependentInverseGamma.birch"
    return a + b;
  }), std::function<birch::type::Real(birch::type::Real,birch::type::Real,const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_
)>([=](const birch::type::Real& x, const birch::type::Real& b, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr) {
    #line 76 "src/distribution/IndependentInverseGamma.birch"
    libbirch_line_(76);
    #line 76 "src/distribution/IndependentInverseGamma.birch"
    return birch::logpdf_inverse_gamma(x, this_()->_u0945->value(handler_), b, handler_);
  }), handler_);
}

#line 80 "src/distribution/IndependentInverseGamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::IndependentInverseGamma::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 80 "src/distribution/IndependentInverseGamma.birch"
  libbirch_function_("logpdfLazy", "src/distribution/IndependentInverseGamma.birch", 80);
  #line 81 "src/distribution/IndependentInverseGamma.birch"
  libbirch_line_(81);
  #line 81 "src/distribution/IndependentInverseGamma.birch"
  return birch::transform_reduce(birch::split(x, handler_), birch::split(this_()->_u0946, handler_), birch::box(0.0, handler_), std::function<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>(libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>,libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>,const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_
)>([=](const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& b, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr) {
    #line 83 "src/distribution/IndependentInverseGamma.birch"
    libbirch_line_(83);
    #line 83 "src/distribution/IndependentInverseGamma.birch"
    return a + b;
  }), std::function<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>(libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>,libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>,const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_
)>([=](const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& b, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr) {
    #line 86 "src/distribution/IndependentInverseGamma.birch"
    libbirch_line_(86);
    #line 86 "src/distribution/IndependentInverseGamma.birch"
    return birch::logpdf_lazy_inverse_gamma(x, this_()->_u0945, b, handler_);
  }), handler_);
}

#line 90 "src/distribution/IndependentInverseGamma.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::IndependentInverseGamma::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 90 "src/distribution/IndependentInverseGamma.birch"
  libbirch_function_("lower", "src/distribution/IndependentInverseGamma.birch", 90);
  #line 91 "src/distribution/IndependentInverseGamma.birch"
  libbirch_line_(91);
  #line 91 "src/distribution/IndependentInverseGamma.birch"
  return birch::vector(0.0, this_()->_u0946->rows(handler_), handler_);
}

#line 94 "src/distribution/IndependentInverseGamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::IndependentInverseGamma>>> birch::type::IndependentInverseGamma::graftIndependentInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 94 "src/distribution/IndependentInverseGamma.birch"
  libbirch_function_("graftIndependentInverseGamma", "src/distribution/IndependentInverseGamma.birch", 94);
  #line 95 "src/distribution/IndependentInverseGamma.birch"
  libbirch_line_(95);
  #line 95 "src/distribution/IndependentInverseGamma.birch"
  this_()->prune(handler_);
  #line 96 "src/distribution/IndependentInverseGamma.birch"
  libbirch_line_(96);
  #line 96 "src/distribution/IndependentInverseGamma.birch"
  return shared_from_this_();
}

#line 99 "src/distribution/IndependentInverseGamma.birch"
void birch::type::IndependentInverseGamma::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 99 "src/distribution/IndependentInverseGamma.birch"
  libbirch_function_("write", "src/distribution/IndependentInverseGamma.birch", 99);
  #line 100 "src/distribution/IndependentInverseGamma.birch"
  libbirch_line_(100);
  #line 100 "src/distribution/IndependentInverseGamma.birch"
  this_()->prune(handler_);
  #line 101 "src/distribution/IndependentInverseGamma.birch"
  libbirch_line_(101);
  #line 101 "src/distribution/IndependentInverseGamma.birch"
  buffer->set(birch::type::String("class"), birch::type::String("IndependentInverseGamma"), handler_);
  #line 102 "src/distribution/IndependentInverseGamma.birch"
  libbirch_line_(102);
  #line 102 "src/distribution/IndependentInverseGamma.birch"
  buffer->set(birch::type::String("α"), this_()->_u0945, handler_);
  #line 103 "src/distribution/IndependentInverseGamma.birch"
  libbirch_line_(103);
  #line 103 "src/distribution/IndependentInverseGamma.birch"
  buffer->set(birch::type::String("β"), this_()->_u0946, handler_);
}

#line 110 "src/distribution/IndependentInverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentInverseGamma>> birch::InverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 110 "src/distribution/IndependentInverseGamma.birch"
  libbirch_function_("InverseGamma", "src/distribution/IndependentInverseGamma.birch", 110);
  #line 112 "src/distribution/IndependentInverseGamma.birch"
  libbirch_line_(112);
  #line 112 "src/distribution/IndependentInverseGamma.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::IndependentInverseGamma>>>(_u0945, _u0946, handler_);
}

#line 118 "src/distribution/IndependentInverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentInverseGamma>> birch::InverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::DefaultArray<birch::type::Real,1>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 118 "src/distribution/IndependentInverseGamma.birch"
  libbirch_function_("InverseGamma", "src/distribution/IndependentInverseGamma.birch", 118);
  #line 120 "src/distribution/IndependentInverseGamma.birch"
  libbirch_line_(120);
  #line 120 "src/distribution/IndependentInverseGamma.birch"
  return birch::InverseGamma(_u0945, birch::box(_u0946, handler_), handler_);
}

#line 126 "src/distribution/IndependentInverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentInverseGamma>> birch::InverseGamma(const birch::type::Real& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 126 "src/distribution/IndependentInverseGamma.birch"
  libbirch_function_("InverseGamma", "src/distribution/IndependentInverseGamma.birch", 126);
  #line 128 "src/distribution/IndependentInverseGamma.birch"
  libbirch_line_(128);
  #line 128 "src/distribution/IndependentInverseGamma.birch"
  return birch::InverseGamma(birch::box(_u0945, handler_), _u0946, handler_);
}

#line 134 "src/distribution/IndependentInverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentInverseGamma>> birch::InverseGamma(const birch::type::Real& _u0945, const libbirch::DefaultArray<birch::type::Real,1>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 134 "src/distribution/IndependentInverseGamma.birch"
  libbirch_function_("InverseGamma", "src/distribution/IndependentInverseGamma.birch", 134);
  #line 135 "src/distribution/IndependentInverseGamma.birch"
  libbirch_line_(135);
  #line 135 "src/distribution/IndependentInverseGamma.birch"
  return birch::InverseGamma(birch::box(_u0945, handler_), birch::box(_u0946, handler_), handler_);
}

#line 4 "src/distribution/IndependentMatrixGaussian.birch"
birch::type::IndependentMatrixGaussian::IndependentMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& v, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/IndependentMatrixGaussian.birch"
    super_type_(),
    #line 9 "src/distribution/IndependentMatrixGaussian.birch"
    M(M),
    #line 14 "src/distribution/IndependentMatrixGaussian.birch"
    _u09632(v) {
  //
}

#line 16 "src/distribution/IndependentMatrixGaussian.birch"
birch::type::Integer birch::type::IndependentMatrixGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("rows", "src/distribution/IndependentMatrixGaussian.birch", 16);
  #line 17 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/IndependentMatrixGaussian.birch"
  return this_()->M->rows(handler_);
}

#line 20 "src/distribution/IndependentMatrixGaussian.birch"
birch::type::Integer birch::type::IndependentMatrixGaussian::columns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("columns", "src/distribution/IndependentMatrixGaussian.birch", 20);
  #line 21 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/IndependentMatrixGaussian.birch"
  return this_()->M->columns(handler_);
}

#line 24 "src/distribution/IndependentMatrixGaussian.birch"
birch::type::Boolean birch::type::IndependentMatrixGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/IndependentMatrixGaussian.birch", 24);
  #line 25 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/IndependentMatrixGaussian.birch"
  return true;
}

#line 28 "src/distribution/IndependentMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::IndependentMatrixGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("simulate", "src/distribution/IndependentMatrixGaussian.birch", 28);
  #line 29 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/IndependentMatrixGaussian.birch"
  return birch::simulate_matrix_gaussian(this_()->M->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 32 "src/distribution/IndependentMatrixGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::IndependentMatrixGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/IndependentMatrixGaussian.birch", 32);
  #line 33 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/IndependentMatrixGaussian.birch"
  return birch::simulate_matrix_gaussian(this_()->M->get(handler_), this_()->_u09632->get(handler_), handler_);
}

#line 36 "src/distribution/IndependentMatrixGaussian.birch"
birch::type::Real birch::type::IndependentMatrixGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/IndependentMatrixGaussian.birch", 36);
  #line 37 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/IndependentMatrixGaussian.birch"
  return birch::logpdf_matrix_gaussian(x, this_()->M->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 40 "src/distribution/IndependentMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::IndependentMatrixGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/IndependentMatrixGaussian.birch", 40);
  #line 41 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/IndependentMatrixGaussian.birch"
  return birch::logpdf_lazy_matrix_gaussian(x, this_()->M, this_()->_u09632, handler_);
}

#line 44 "src/distribution/IndependentMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>> birch::type::IndependentMatrixGaussian::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("graft", "src/distribution/IndependentMatrixGaussian.birch", 44);
  #line 45 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/IndependentMatrixGaussian.birch"
  this_()->prune(handler_);
  #line 46 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::IndependentInverseGamma>>> s1;
  #line 47 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>>>>> m1;
  #line 48 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>> m2;
  #line 49 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>> r = shared_from_this_();
  #line 52 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/IndependentMatrixGaussian.birch"
  auto compare = this_()->_u09632->distribution(handler_);
  #line 53 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/IndependentMatrixGaussian.birch"
  if (compare.query() && (m1 = this_()->M->graftLinearMatrixNormalInverseGamma(compare.get(), handler_)).query()) {
    #line 54 "src/distribution/IndependentMatrixGaussian.birch"
    libbirch_line_(54);
    #line 54 "src/distribution/IndependentMatrixGaussian.birch"
    r = birch::LinearMatrixNormalInverseGammaMatrixGaussian(m1.get()->A, m1.get()->X, m1.get()->C, handler_);
  } else {
    #line 55 "src/distribution/IndependentMatrixGaussian.birch"
    libbirch_line_(55);
    #line 55 "src/distribution/IndependentMatrixGaussian.birch"
    if (compare.query() && (m2 = this_()->M->graftMatrixNormalInverseGamma(compare.get(), handler_)).query()) {
      #line 56 "src/distribution/IndependentMatrixGaussian.birch"
      libbirch_line_(56);
      #line 56 "src/distribution/IndependentMatrixGaussian.birch"
      r = birch::MatrixNormalInverseGammaMatrixGaussian(m2.get(), handler_);
    } else {
      #line 57 "src/distribution/IndependentMatrixGaussian.birch"
      libbirch_line_(57);
      #line 57 "src/distribution/IndependentMatrixGaussian.birch"
      if ((s1 = this_()->_u09632->graftIndependentInverseGamma(handler_)).query()) {
        #line 58 "src/distribution/IndependentMatrixGaussian.birch"
        libbirch_line_(58);
        #line 58 "src/distribution/IndependentMatrixGaussian.birch"
        r = birch::MatrixNormalInverseGamma(this_()->M, birch::box(birch::llt(birch::identity(this_()->M->rows(handler_), handler_), handler_), handler_), s1.get(), handler_);
      }
    }
  }
  #line 61 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/IndependentMatrixGaussian.birch"
  return r;
}

#line 64 "src/distribution/IndependentMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>> birch::type::IndependentMatrixGaussian::graftMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("graftMatrixGaussian", "src/distribution/IndependentMatrixGaussian.birch", 64);
  #line 65 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/IndependentMatrixGaussian.birch"
  this_()->prune(handler_);
  #line 66 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/IndependentMatrixGaussian.birch"
  return birch::Gaussian(this_()->M, birch::box(birch::llt(birch::identity(this_()->M->rows(handler_), handler_), handler_), handler_), birch::diagonal(this_()->_u09632, handler_), handler_);
}

#line 69 "src/distribution/IndependentMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>> birch::type::IndependentMatrixGaussian::graftMatrixNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("graftMatrixNormalInverseGamma", "src/distribution/IndependentMatrixGaussian.birch", 69);
  #line 71 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(71);
  #line 71 "src/distribution/IndependentMatrixGaussian.birch"
  this_()->prune(handler_);
  #line 72 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(72);
  #line 72 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::IndependentInverseGamma>>> s1;
  #line 73 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(73);
  #line 73 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>> r;
  #line 76 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(76);
  #line 76 "src/distribution/IndependentMatrixGaussian.birch"
  if ((s1 = this_()->_u09632->graftIndependentInverseGamma(handler_)).query() && s1.get() == compare) {
    #line 77 "src/distribution/IndependentMatrixGaussian.birch"
    libbirch_line_(77);
    #line 77 "src/distribution/IndependentMatrixGaussian.birch"
    r = birch::MatrixNormalInverseGamma(this_()->M, birch::box(birch::llt(birch::identity(this_()->M->rows(handler_), handler_), handler_), handler_), s1.get(), handler_);
  }
  #line 80 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(80);
  #line 80 "src/distribution/IndependentMatrixGaussian.birch"
  return r;
}

#line 87 "src/distribution/IndependentMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 87 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentMatrixGaussian.birch", 87);
  #line 89 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(89);
  #line 89 "src/distribution/IndependentMatrixGaussian.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::IndependentMatrixGaussian>>>(M, _u09632, handler_);
}

#line 95 "src/distribution/IndependentMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentMatrixGaussian.birch", 95);
  #line 97 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(97);
  #line 97 "src/distribution/IndependentMatrixGaussian.birch"
  return birch::Gaussian(M, birch::box(_u09632, handler_), handler_);
}

#line 103 "src/distribution/IndependentMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentMatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 103 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentMatrixGaussian.birch", 103);
  #line 105 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(105);
  #line 105 "src/distribution/IndependentMatrixGaussian.birch"
  return birch::Gaussian(birch::box(M, handler_), _u09632, handler_);
}

#line 111 "src/distribution/IndependentMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentMatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 111 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentMatrixGaussian.birch", 111);
  #line 112 "src/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(112);
  #line 112 "src/distribution/IndependentMatrixGaussian.birch"
  return birch::Gaussian(birch::box(M, handler_), birch::box(_u09632, handler_), handler_);
}

#line 4 "src/distribution/IndependentRowMatrixGaussian.birch"
birch::type::IndependentRowMatrixGaussian::IndependentRowMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/IndependentRowMatrixGaussian.birch"
    super_type_(),
    #line 9 "src/distribution/IndependentRowMatrixGaussian.birch"
    M(M),
    #line 14 "src/distribution/IndependentRowMatrixGaussian.birch"
    V(V) {
  //
}

#line 16 "src/distribution/IndependentRowMatrixGaussian.birch"
birch::type::Integer birch::type::IndependentRowMatrixGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("rows", "src/distribution/IndependentRowMatrixGaussian.birch", 16);
  #line 17 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/IndependentRowMatrixGaussian.birch"
  return this_()->M->rows(handler_);
}

#line 20 "src/distribution/IndependentRowMatrixGaussian.birch"
birch::type::Integer birch::type::IndependentRowMatrixGaussian::columns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("columns", "src/distribution/IndependentRowMatrixGaussian.birch", 20);
  #line 21 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/IndependentRowMatrixGaussian.birch"
  return this_()->M->columns(handler_);
}

#line 24 "src/distribution/IndependentRowMatrixGaussian.birch"
birch::type::Boolean birch::type::IndependentRowMatrixGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/IndependentRowMatrixGaussian.birch", 24);
  #line 25 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/IndependentRowMatrixGaussian.birch"
  return true;
}

#line 28 "src/distribution/IndependentRowMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::IndependentRowMatrixGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("simulate", "src/distribution/IndependentRowMatrixGaussian.birch", 28);
  #line 29 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/IndependentRowMatrixGaussian.birch"
  return birch::simulate_matrix_gaussian(this_()->M->value(handler_), this_()->V->value(handler_), handler_);
}

#line 32 "src/distribution/IndependentRowMatrixGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::IndependentRowMatrixGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/IndependentRowMatrixGaussian.birch", 32);
  #line 33 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/IndependentRowMatrixGaussian.birch"
  return birch::simulate_matrix_gaussian(this_()->M->get(handler_), this_()->V->get(handler_), handler_);
}

#line 36 "src/distribution/IndependentRowMatrixGaussian.birch"
birch::type::Real birch::type::IndependentRowMatrixGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/IndependentRowMatrixGaussian.birch", 36);
  #line 37 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/IndependentRowMatrixGaussian.birch"
  return birch::logpdf_matrix_gaussian(x, this_()->M->value(handler_), this_()->V->value(handler_), handler_);
}

#line 40 "src/distribution/IndependentRowMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::IndependentRowMatrixGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/IndependentRowMatrixGaussian.birch", 40);
  #line 41 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/IndependentRowMatrixGaussian.birch"
  return birch::logpdf_lazy_matrix_gaussian(x, this_()->M, this_()->V, handler_);
}

#line 44 "src/distribution/IndependentRowMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>> birch::type::IndependentRowMatrixGaussian::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("graft", "src/distribution/IndependentRowMatrixGaussian.birch", 44);
  #line 45 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/IndependentRowMatrixGaussian.birch"
  this_()->prune(handler_);
  #line 46 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>>> s1;
  #line 47 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>>>> m1;
  #line 48 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>> m2;
  #line 49 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>> r = shared_from_this_();
  #line 52 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/IndependentRowMatrixGaussian.birch"
  auto compare = this_()->V->distribution(handler_);
  #line 53 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/IndependentRowMatrixGaussian.birch"
  if (compare.query() && (m1 = this_()->M->graftLinearMatrixNormalInverseWishart(compare.get(), handler_)).query()) {
    #line 54 "src/distribution/IndependentRowMatrixGaussian.birch"
    libbirch_line_(54);
    #line 54 "src/distribution/IndependentRowMatrixGaussian.birch"
    r = birch::LinearMatrixNormalInverseWishartMatrixGaussian(m1.get()->A, m1.get()->X, m1.get()->C, handler_);
  } else {
    #line 55 "src/distribution/IndependentRowMatrixGaussian.birch"
    libbirch_line_(55);
    #line 55 "src/distribution/IndependentRowMatrixGaussian.birch"
    if (compare.query() && (m2 = this_()->M->graftMatrixNormalInverseWishart(compare.get(), handler_)).query()) {
      #line 56 "src/distribution/IndependentRowMatrixGaussian.birch"
      libbirch_line_(56);
      #line 56 "src/distribution/IndependentRowMatrixGaussian.birch"
      r = birch::MatrixNormalInverseWishartMatrixGaussian(m2.get(), handler_);
    } else {
      #line 57 "src/distribution/IndependentRowMatrixGaussian.birch"
      libbirch_line_(57);
      #line 57 "src/distribution/IndependentRowMatrixGaussian.birch"
      if ((s1 = this_()->V->graftInverseWishart(handler_)).query()) {
        #line 58 "src/distribution/IndependentRowMatrixGaussian.birch"
        libbirch_line_(58);
        #line 58 "src/distribution/IndependentRowMatrixGaussian.birch"
        r = birch::MatrixNormalInverseWishart(this_()->M, birch::box(birch::llt(birch::identity(this_()->M->rows(handler_), handler_), handler_), handler_), s1.get(), handler_);
      }
    }
  }
  #line 61 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/IndependentRowMatrixGaussian.birch"
  return r;
}

#line 64 "src/distribution/IndependentRowMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>> birch::type::IndependentRowMatrixGaussian::graftMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("graftMatrixGaussian", "src/distribution/IndependentRowMatrixGaussian.birch", 64);
  #line 65 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/IndependentRowMatrixGaussian.birch"
  this_()->prune(handler_);
  #line 66 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/IndependentRowMatrixGaussian.birch"
  return birch::Gaussian(this_()->M, birch::box(birch::llt(birch::identity(this_()->M->rows(handler_), handler_), handler_), handler_), this_()->V, handler_);
}

#line 69 "src/distribution/IndependentRowMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>> birch::type::IndependentRowMatrixGaussian::graftMatrixNormalInverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::LLT>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("graftMatrixNormalInverseWishart", "src/distribution/IndependentRowMatrixGaussian.birch", 69);
  #line 71 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(71);
  #line 71 "src/distribution/IndependentRowMatrixGaussian.birch"
  this_()->prune(handler_);
  #line 72 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(72);
  #line 72 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>>> s1;
  #line 73 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(73);
  #line 73 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>> r;
  #line 76 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(76);
  #line 76 "src/distribution/IndependentRowMatrixGaussian.birch"
  if ((s1 = this_()->V->graftInverseWishart(handler_)).query() && s1.get() == compare) {
    #line 77 "src/distribution/IndependentRowMatrixGaussian.birch"
    libbirch_line_(77);
    #line 77 "src/distribution/IndependentRowMatrixGaussian.birch"
    r = birch::MatrixNormalInverseWishart(this_()->M, birch::box(birch::llt(birch::identity(this_()->M->rows(handler_), handler_), handler_), handler_), s1.get(), handler_);
  }
  #line 80 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(80);
  #line 80 "src/distribution/IndependentRowMatrixGaussian.birch"
  return r;
}

#line 87 "src/distribution/IndependentRowMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentRowMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 87 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentRowMatrixGaussian.birch", 87);
  #line 89 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(89);
  #line 89 "src/distribution/IndependentRowMatrixGaussian.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::IndependentRowMatrixGaussian>>>(M, V, handler_);
}

#line 95 "src/distribution/IndependentRowMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentRowMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const birch::type::LLT& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentRowMatrixGaussian.birch", 95);
  #line 97 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(97);
  #line 97 "src/distribution/IndependentRowMatrixGaussian.birch"
  return birch::Gaussian(M, birch::box(V, handler_), handler_);
}

#line 103 "src/distribution/IndependentRowMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentRowMatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 103 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentRowMatrixGaussian.birch", 103);
  #line 105 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(105);
  #line 105 "src/distribution/IndependentRowMatrixGaussian.birch"
  return birch::Gaussian(birch::box(M, handler_), V, handler_);
}

#line 111 "src/distribution/IndependentRowMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentRowMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 111 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentRowMatrixGaussian.birch", 111);
  #line 113 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(113);
  #line 113 "src/distribution/IndependentRowMatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(V, handler_), handler_);
}

#line 119 "src/distribution/IndependentRowMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentRowMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::DefaultArray<birch::type::Real,2>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 119 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentRowMatrixGaussian.birch", 119);
  #line 121 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(121);
  #line 121 "src/distribution/IndependentRowMatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(V, handler_), handler_);
}

#line 127 "src/distribution/IndependentRowMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentRowMatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 127 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/IndependentRowMatrixGaussian.birch", 127);
  #line 129 "src/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(129);
  #line 129 "src/distribution/IndependentRowMatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(V, handler_), handler_);
}

#line 4 "src/distribution/IndependentUniform.birch"
birch::type::IndependentUniform::IndependentUniform(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& l, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/IndependentUniform.birch"
    super_type_(),
    #line 9 "src/distribution/IndependentUniform.birch"
    l(l),
    #line 14 "src/distribution/IndependentUniform.birch"
    u(u) {
  //
}

#line 16 "src/distribution/IndependentUniform.birch"
birch::type::Integer birch::type::IndependentUniform::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/distribution/IndependentUniform.birch"
  libbirch_function_("rows", "src/distribution/IndependentUniform.birch", 16);
  #line 17 "src/distribution/IndependentUniform.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/IndependentUniform.birch"
  return this_()->l->rows(handler_);
}

#line 20 "src/distribution/IndependentUniform.birch"
birch::type::Boolean birch::type::IndependentUniform::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/distribution/IndependentUniform.birch"
  libbirch_function_("supportsLazy", "src/distribution/IndependentUniform.birch", 20);
  #line 21 "src/distribution/IndependentUniform.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/IndependentUniform.birch"
  return false;
}

#line 24 "src/distribution/IndependentUniform.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::IndependentUniform::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/distribution/IndependentUniform.birch"
  libbirch_function_("simulate", "src/distribution/IndependentUniform.birch", 24);
  #line 25 "src/distribution/IndependentUniform.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/IndependentUniform.birch"
  return birch::simulate_independent_uniform(this_()->l->value(handler_), this_()->u->value(handler_), handler_);
}

#line 32 "src/distribution/IndependentUniform.birch"
birch::type::Real birch::type::IndependentUniform::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/distribution/IndependentUniform.birch"
  libbirch_function_("logpdf", "src/distribution/IndependentUniform.birch", 32);
  #line 33 "src/distribution/IndependentUniform.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/IndependentUniform.birch"
  return birch::logpdf_independent_uniform(x, this_()->l->value(handler_), this_()->u->value(handler_), handler_);
}

#line 40 "src/distribution/IndependentUniform.birch"
void birch::type::IndependentUniform::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "src/distribution/IndependentUniform.birch"
  libbirch_function_("write", "src/distribution/IndependentUniform.birch", 40);
  #line 41 "src/distribution/IndependentUniform.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/IndependentUniform.birch"
  this_()->prune(handler_);
  #line 42 "src/distribution/IndependentUniform.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/IndependentUniform.birch"
  buffer->set(birch::type::String("class"), birch::type::String("IndependentUniform"), handler_);
  #line 43 "src/distribution/IndependentUniform.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/IndependentUniform.birch"
  buffer->set(birch::type::String("l"), this_()->l, handler_);
  #line 44 "src/distribution/IndependentUniform.birch"
  libbirch_line_(44);
  #line 44 "src/distribution/IndependentUniform.birch"
  buffer->set(birch::type::String("u"), this_()->u, handler_);
}

#line 52 "src/distribution/IndependentUniform.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentUniform>> birch::Uniform(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& l, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "src/distribution/IndependentUniform.birch"
  libbirch_function_("Uniform", "src/distribution/IndependentUniform.birch", 52);
  #line 54 "src/distribution/IndependentUniform.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/IndependentUniform.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::IndependentUniform>>>(l, u, handler_);
}

#line 61 "src/distribution/IndependentUniform.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentUniform>> birch::Uniform(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& l, const libbirch::DefaultArray<birch::type::Real,1>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "src/distribution/IndependentUniform.birch"
  libbirch_function_("Uniform", "src/distribution/IndependentUniform.birch", 61);
  #line 62 "src/distribution/IndependentUniform.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/IndependentUniform.birch"
  return birch::Uniform(l, birch::box(u, handler_), handler_);
}

#line 69 "src/distribution/IndependentUniform.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentUniform>> birch::Uniform(const libbirch::DefaultArray<birch::type::Real,1>& l, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "src/distribution/IndependentUniform.birch"
  libbirch_function_("Uniform", "src/distribution/IndependentUniform.birch", 69);
  #line 70 "src/distribution/IndependentUniform.birch"
  libbirch_line_(70);
  #line 70 "src/distribution/IndependentUniform.birch"
  return birch::Uniform(birch::box(l, handler_), u, handler_);
}

#line 77 "src/distribution/IndependentUniform.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentUniform>> birch::Uniform(const libbirch::DefaultArray<birch::type::Real,1>& l, const libbirch::DefaultArray<birch::type::Real,1>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 77 "src/distribution/IndependentUniform.birch"
  libbirch_function_("Uniform", "src/distribution/IndependentUniform.birch", 77);
  #line 78 "src/distribution/IndependentUniform.birch"
  libbirch_line_(78);
  #line 78 "src/distribution/IndependentUniform.birch"
  return birch::Uniform(birch::box(l, handler_), birch::box(u, handler_), handler_);
}

#line 5 "src/distribution/IndependentUniformInteger.birch"
birch::type::IndependentUniformInteger::IndependentUniformInteger(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Integer,1>>>>& l, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Integer,1>>>>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 5 "src/distribution/IndependentUniformInteger.birch"
    super_type_(),
    #line 10 "src/distribution/IndependentUniformInteger.birch"
    l(l),
    #line 15 "src/distribution/IndependentUniformInteger.birch"
    u(u) {
  //
}

#line 17 "src/distribution/IndependentUniformInteger.birch"
birch::type::Integer birch::type::IndependentUniformInteger::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 17 "src/distribution/IndependentUniformInteger.birch"
  libbirch_function_("rows", "src/distribution/IndependentUniformInteger.birch", 17);
  #line 18 "src/distribution/IndependentUniformInteger.birch"
  libbirch_line_(18);
  #line 18 "src/distribution/IndependentUniformInteger.birch"
  return this_()->l->rows(handler_);
}

#line 21 "src/distribution/IndependentUniformInteger.birch"
birch::type::Boolean birch::type::IndependentUniformInteger::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "src/distribution/IndependentUniformInteger.birch"
  libbirch_function_("supportsLazy", "src/distribution/IndependentUniformInteger.birch", 21);
  #line 22 "src/distribution/IndependentUniformInteger.birch"
  libbirch_line_(22);
  #line 22 "src/distribution/IndependentUniformInteger.birch"
  return false;
}

#line 25 "src/distribution/IndependentUniformInteger.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::type::IndependentUniformInteger::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/distribution/IndependentUniformInteger.birch"
  libbirch_function_("simulate", "src/distribution/IndependentUniformInteger.birch", 25);
  #line 26 "src/distribution/IndependentUniformInteger.birch"
  libbirch_line_(26);
  #line 26 "src/distribution/IndependentUniformInteger.birch"
  return birch::simulate_independent_uniform_int(this_()->l->value(handler_), this_()->u->value(handler_), handler_);
}

#line 33 "src/distribution/IndependentUniformInteger.birch"
birch::type::Real birch::type::IndependentUniformInteger::logpdf(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/distribution/IndependentUniformInteger.birch"
  libbirch_function_("logpdf", "src/distribution/IndependentUniformInteger.birch", 33);
  #line 34 "src/distribution/IndependentUniformInteger.birch"
  libbirch_line_(34);
  #line 34 "src/distribution/IndependentUniformInteger.birch"
  return birch::logpdf_independent_uniform_int(x, this_()->l->value(handler_), this_()->u->value(handler_), handler_);
}

#line 41 "src/distribution/IndependentUniformInteger.birch"
void birch::type::IndependentUniformInteger::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "src/distribution/IndependentUniformInteger.birch"
  libbirch_function_("write", "src/distribution/IndependentUniformInteger.birch", 41);
  #line 42 "src/distribution/IndependentUniformInteger.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/IndependentUniformInteger.birch"
  this_()->prune(handler_);
  #line 43 "src/distribution/IndependentUniformInteger.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/IndependentUniformInteger.birch"
  buffer->set(birch::type::String("class"), birch::type::String("IndependentUniformInteger"), handler_);
  #line 44 "src/distribution/IndependentUniformInteger.birch"
  libbirch_line_(44);
  #line 44 "src/distribution/IndependentUniformInteger.birch"
  buffer->set(birch::type::String("l"), this_()->l, handler_);
  #line 45 "src/distribution/IndependentUniformInteger.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/IndependentUniformInteger.birch"
  buffer->set(birch::type::String("u"), this_()->u, handler_);
}

#line 53 "src/distribution/IndependentUniformInteger.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentUniformInteger>> birch::Uniform(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Integer,1>>>>& l, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Integer,1>>>>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "src/distribution/IndependentUniformInteger.birch"
  libbirch_function_("Uniform", "src/distribution/IndependentUniformInteger.birch", 53);
  #line 55 "src/distribution/IndependentUniformInteger.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/IndependentUniformInteger.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::IndependentUniformInteger>>>(l, u, handler_);
}

#line 62 "src/distribution/IndependentUniformInteger.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentUniformInteger>> birch::Uniform(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Integer,1>>>>& l, const libbirch::DefaultArray<birch::type::Integer,1>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 62 "src/distribution/IndependentUniformInteger.birch"
  libbirch_function_("Uniform", "src/distribution/IndependentUniformInteger.birch", 62);
  #line 64 "src/distribution/IndependentUniformInteger.birch"
  libbirch_line_(64);
  #line 64 "src/distribution/IndependentUniformInteger.birch"
  return birch::Uniform(l, birch::box(u, handler_), handler_);
}

#line 71 "src/distribution/IndependentUniformInteger.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentUniformInteger>> birch::Uniform(const libbirch::DefaultArray<birch::type::Integer,1>& l, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Integer,1>>>>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 71 "src/distribution/IndependentUniformInteger.birch"
  libbirch_function_("Uniform", "src/distribution/IndependentUniformInteger.birch", 71);
  #line 73 "src/distribution/IndependentUniformInteger.birch"
  libbirch_line_(73);
  #line 73 "src/distribution/IndependentUniformInteger.birch"
  return birch::Uniform(birch::box(l, handler_), u, handler_);
}

#line 80 "src/distribution/IndependentUniformInteger.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentUniformInteger>> birch::Uniform(const libbirch::DefaultArray<birch::type::Integer,1>& l, const libbirch::DefaultArray<birch::type::Integer,1>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 80 "src/distribution/IndependentUniformInteger.birch"
  libbirch_function_("Uniform", "src/distribution/IndependentUniformInteger.birch", 80);
  #line 81 "src/distribution/IndependentUniformInteger.birch"
  libbirch_line_(81);
  #line 81 "src/distribution/IndependentUniformInteger.birch"
  return birch::Uniform(birch::box(l, handler_), birch::box(u, handler_), handler_);
}

#line 4 "src/distribution/InverseGamma.birch"
birch::type::InverseGamma::InverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/InverseGamma.birch"
    super_type_(),
    #line 9 "src/distribution/InverseGamma.birch"
    _u0945(_u0945),
    #line 14 "src/distribution/InverseGamma.birch"
    _u0946(_u0946) {
  //
}

#line 16 "src/distribution/InverseGamma.birch"
birch::type::Boolean birch::type::InverseGamma::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/distribution/InverseGamma.birch"
  libbirch_function_("supportsLazy", "src/distribution/InverseGamma.birch", 16);
  #line 17 "src/distribution/InverseGamma.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/InverseGamma.birch"
  return true;
}

#line 20 "src/distribution/InverseGamma.birch"
birch::type::Real birch::type::InverseGamma::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/distribution/InverseGamma.birch"
  libbirch_function_("simulate", "src/distribution/InverseGamma.birch", 20);
  #line 21 "src/distribution/InverseGamma.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/InverseGamma.birch"
  return birch::simulate_inverse_gamma(this_()->_u0945->value(handler_), this_()->_u0946->value(handler_), handler_);
}

#line 24 "src/distribution/InverseGamma.birch"
libbirch::Optional<birch::type::Real> birch::type::InverseGamma::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/distribution/InverseGamma.birch"
  libbirch_function_("simulateLazy", "src/distribution/InverseGamma.birch", 24);
  #line 25 "src/distribution/InverseGamma.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/InverseGamma.birch"
  return birch::simulate_inverse_gamma(this_()->_u0945->get(handler_), this_()->_u0946->get(handler_), handler_);
}

#line 28 "src/distribution/InverseGamma.birch"
birch::type::Real birch::type::InverseGamma::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/distribution/InverseGamma.birch"
  libbirch_function_("logpdf", "src/distribution/InverseGamma.birch", 28);
  #line 29 "src/distribution/InverseGamma.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/InverseGamma.birch"
  return birch::logpdf_inverse_gamma(x, this_()->_u0945->value(handler_), this_()->_u0946->value(handler_), handler_);
}

#line 32 "src/distribution/InverseGamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::InverseGamma::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/distribution/InverseGamma.birch"
  libbirch_function_("logpdfLazy", "src/distribution/InverseGamma.birch", 32);
  #line 33 "src/distribution/InverseGamma.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/InverseGamma.birch"
  return birch::logpdf_lazy_inverse_gamma(x, this_()->_u0945, this_()->_u0946, handler_);
}

#line 36 "src/distribution/InverseGamma.birch"
libbirch::Optional<birch::type::Real> birch::type::InverseGamma::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/distribution/InverseGamma.birch"
  libbirch_function_("cdf", "src/distribution/InverseGamma.birch", 36);
  #line 37 "src/distribution/InverseGamma.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/InverseGamma.birch"
  return birch::cdf_inverse_gamma(x, this_()->_u0945->value(handler_), this_()->_u0946->value(handler_), handler_);
}

#line 40 "src/distribution/InverseGamma.birch"
libbirch::Optional<birch::type::Real> birch::type::InverseGamma::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "src/distribution/InverseGamma.birch"
  libbirch_function_("quantile", "src/distribution/InverseGamma.birch", 40);
  #line 41 "src/distribution/InverseGamma.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/InverseGamma.birch"
  return birch::quantile_inverse_gamma(P, this_()->_u0945->value(handler_), this_()->_u0946->value(handler_), handler_);
}

#line 44 "src/distribution/InverseGamma.birch"
libbirch::Optional<birch::type::Real> birch::type::InverseGamma::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/distribution/InverseGamma.birch"
  libbirch_function_("lower", "src/distribution/InverseGamma.birch", 44);
  #line 45 "src/distribution/InverseGamma.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/InverseGamma.birch"
  return 0.0;
}

#line 48 "src/distribution/InverseGamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>> birch::type::InverseGamma::graftInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "src/distribution/InverseGamma.birch"
  libbirch_function_("graftInverseGamma", "src/distribution/InverseGamma.birch", 48);
  #line 49 "src/distribution/InverseGamma.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/InverseGamma.birch"
  this_()->prune(handler_);
  #line 50 "src/distribution/InverseGamma.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/InverseGamma.birch"
  return shared_from_this_();
}

#line 53 "src/distribution/InverseGamma.birch"
void birch::type::InverseGamma::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "src/distribution/InverseGamma.birch"
  libbirch_function_("write", "src/distribution/InverseGamma.birch", 53);
  #line 54 "src/distribution/InverseGamma.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/InverseGamma.birch"
  this_()->prune(handler_);
  #line 55 "src/distribution/InverseGamma.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/InverseGamma.birch"
  buffer->set(birch::type::String("class"), birch::type::String("InverseGamma"), handler_);
  #line 56 "src/distribution/InverseGamma.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/InverseGamma.birch"
  buffer->set(birch::type::String("α"), this_()->_u0945, handler_);
  #line 57 "src/distribution/InverseGamma.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/InverseGamma.birch"
  buffer->set(birch::type::String("β"), this_()->_u0946, handler_);
}

#line 64 "src/distribution/InverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>> birch::InverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "src/distribution/InverseGamma.birch"
  libbirch_function_("InverseGamma", "src/distribution/InverseGamma.birch", 64);
  #line 66 "src/distribution/InverseGamma.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/InverseGamma.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>>(_u0945, _u0946, handler_);
}

#line 72 "src/distribution/InverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>> birch::InverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "src/distribution/InverseGamma.birch"
  libbirch_function_("InverseGamma", "src/distribution/InverseGamma.birch", 72);
  #line 73 "src/distribution/InverseGamma.birch"
  libbirch_line_(73);
  #line 73 "src/distribution/InverseGamma.birch"
  return birch::InverseGamma(_u0945, birch::box(_u0946, handler_), handler_);
}

#line 79 "src/distribution/InverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>> birch::InverseGamma(const birch::type::Real& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 79 "src/distribution/InverseGamma.birch"
  libbirch_function_("InverseGamma", "src/distribution/InverseGamma.birch", 79);
  #line 80 "src/distribution/InverseGamma.birch"
  libbirch_line_(80);
  #line 80 "src/distribution/InverseGamma.birch"
  return birch::InverseGamma(birch::box(_u0945, handler_), _u0946, handler_);
}

#line 86 "src/distribution/InverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>> birch::InverseGamma(const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 86 "src/distribution/InverseGamma.birch"
  libbirch_function_("InverseGamma", "src/distribution/InverseGamma.birch", 86);
  #line 87 "src/distribution/InverseGamma.birch"
  libbirch_line_(87);
  #line 87 "src/distribution/InverseGamma.birch"
  return birch::InverseGamma(birch::box(_u0945, handler_), birch::box(_u0946, handler_), handler_);
}

#line 4 "src/distribution/InverseGammaGamma.birch"
birch::type::InverseGammaGamma::InverseGammaGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/InverseGammaGamma.birch"
    super_type_(),
    #line 9 "src/distribution/InverseGammaGamma.birch"
    k(k),
    #line 14 "src/distribution/InverseGammaGamma.birch"
    _u0952(_u0952) {
  //
}

#line 16 "src/distribution/InverseGammaGamma.birch"
birch::type::Boolean birch::type::InverseGammaGamma::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/distribution/InverseGammaGamma.birch"
  libbirch_function_("supportsLazy", "src/distribution/InverseGammaGamma.birch", 16);
  #line 17 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/InverseGammaGamma.birch"
  return true;
}

#line 20 "src/distribution/InverseGammaGamma.birch"
birch::type::Real birch::type::InverseGammaGamma::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/distribution/InverseGammaGamma.birch"
  libbirch_function_("simulate", "src/distribution/InverseGammaGamma.birch", 20);
  #line 21 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/InverseGammaGamma.birch"
  return birch::simulate_inverse_gamma_gamma(this_()->k->value(handler_), this_()->_u0952->_u0945->value(handler_), this_()->_u0952->_u0946->value(handler_), handler_);
}

#line 24 "src/distribution/InverseGammaGamma.birch"
libbirch::Optional<birch::type::Real> birch::type::InverseGammaGamma::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/distribution/InverseGammaGamma.birch"
  libbirch_function_("simulateLazy", "src/distribution/InverseGammaGamma.birch", 24);
  #line 25 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/InverseGammaGamma.birch"
  return birch::simulate_inverse_gamma_gamma(this_()->k->get(handler_), this_()->_u0952->_u0945->get(handler_), this_()->_u0952->_u0946->get(handler_), handler_);
}

#line 28 "src/distribution/InverseGammaGamma.birch"
birch::type::Real birch::type::InverseGammaGamma::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/distribution/InverseGammaGamma.birch"
  libbirch_function_("logpdf", "src/distribution/InverseGammaGamma.birch", 28);
  #line 29 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/InverseGammaGamma.birch"
  return birch::logpdf_inverse_gamma_gamma(x, this_()->k->value(handler_), this_()->_u0952->_u0945->value(handler_), this_()->_u0952->_u0946->value(handler_), handler_);
}

#line 32 "src/distribution/InverseGammaGamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::InverseGammaGamma::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/distribution/InverseGammaGamma.birch"
  libbirch_function_("logpdfLazy", "src/distribution/InverseGammaGamma.birch", 32);
  #line 33 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/InverseGammaGamma.birch"
  return birch::logpdf_lazy_inverse_gamma_gamma(x, this_()->k, this_()->_u0952->_u0945, this_()->_u0952->_u0946, handler_);
}

#line 36 "src/distribution/InverseGammaGamma.birch"
void birch::type::InverseGammaGamma::update(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/distribution/InverseGammaGamma.birch"
  libbirch_function_("update", "src/distribution/InverseGammaGamma.birch", 36);
  #line 37 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/InverseGammaGamma.birch"
  libbirch::tie(this_()->_u0952->_u0945, this_()->_u0952->_u0946) = birch::box(birch::update_inverse_gamma_gamma(x, this_()->k->value(handler_), this_()->_u0952->_u0945->value(handler_), this_()->_u0952->_u0946->value(handler_), handler_), handler_);
}

#line 40 "src/distribution/InverseGammaGamma.birch"
void birch::type::InverseGammaGamma::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "src/distribution/InverseGammaGamma.birch"
  libbirch_function_("updateLazy", "src/distribution/InverseGammaGamma.birch", 40);
  #line 41 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/InverseGammaGamma.birch"
  libbirch::tie(this_()->_u0952->_u0945, this_()->_u0952->_u0946) = birch::update_lazy_inverse_gamma_gamma(x, this_()->k, this_()->_u0952->_u0945, this_()->_u0952->_u0946, handler_);
}

#line 44 "src/distribution/InverseGammaGamma.birch"
libbirch::Optional<birch::type::Real> birch::type::InverseGammaGamma::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/distribution/InverseGammaGamma.birch"
  libbirch_function_("cdf", "src/distribution/InverseGammaGamma.birch", 44);
  #line 45 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/InverseGammaGamma.birch"
  return birch::cdf_inverse_gamma_gamma(x, this_()->k->value(handler_), this_()->_u0952->_u0945->value(handler_), this_()->_u0952->_u0946->value(handler_), handler_);
}

#line 48 "src/distribution/InverseGammaGamma.birch"
libbirch::Optional<birch::type::Real> birch::type::InverseGammaGamma::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "src/distribution/InverseGammaGamma.birch"
  libbirch_function_("lower", "src/distribution/InverseGammaGamma.birch", 48);
  #line 49 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/InverseGammaGamma.birch"
  return 0.0;
}

#line 52 "src/distribution/InverseGammaGamma.birch"
void birch::type::InverseGammaGamma::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "src/distribution/InverseGammaGamma.birch"
  libbirch_function_("link", "src/distribution/InverseGammaGamma.birch", 52);
  #line 53 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/InverseGammaGamma.birch"
  this_()->_u0952->setChild(shared_from_this_(), handler_);
}

#line 56 "src/distribution/InverseGammaGamma.birch"
void birch::type::InverseGammaGamma::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 56 "src/distribution/InverseGammaGamma.birch"
  libbirch_function_("unlink", "src/distribution/InverseGammaGamma.birch", 56);
  #line 57 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/InverseGammaGamma.birch"
  this_()->_u0952->releaseChild(shared_from_this_(), handler_);
}

#line 61 "src/distribution/InverseGammaGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseGammaGamma>> birch::InverseGammaGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "src/distribution/InverseGammaGamma.birch"
  libbirch_function_("InverseGammaGamma", "src/distribution/InverseGammaGamma.birch", 61);
  #line 63 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(63);
  #line 63 "src/distribution/InverseGammaGamma.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::InverseGammaGamma>> m(k, _u0952);
  #line 64 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(64);
  #line 64 "src/distribution/InverseGammaGamma.birch"
  m->link(handler_);
  #line 65 "src/distribution/InverseGammaGamma.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/InverseGammaGamma.birch"
  return m;
}

#line 30 "src/distribution/InverseWishart.birch"
birch::type::InverseWishart::InverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 30 "src/distribution/InverseWishart.birch"
    super_type_(),
    #line 35 "src/distribution/InverseWishart.birch"
    _u0936(_u0936),
    #line 40 "src/distribution/InverseWishart.birch"
    k(k) {
  //
}

#line 42 "src/distribution/InverseWishart.birch"
birch::type::Integer birch::type::InverseWishart::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/distribution/InverseWishart.birch"
  libbirch_function_("rows", "src/distribution/InverseWishart.birch", 42);
  #line 43 "src/distribution/InverseWishart.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/InverseWishart.birch"
  return this_()->_u0936->rows(handler_);
}

#line 46 "src/distribution/InverseWishart.birch"
birch::type::Integer birch::type::InverseWishart::columns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/distribution/InverseWishart.birch"
  libbirch_function_("columns", "src/distribution/InverseWishart.birch", 46);
  #line 47 "src/distribution/InverseWishart.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/InverseWishart.birch"
  return this_()->_u0936->columns(handler_);
}

#line 50 "src/distribution/InverseWishart.birch"
birch::type::Boolean birch::type::InverseWishart::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "src/distribution/InverseWishart.birch"
  libbirch_function_("supportsLazy", "src/distribution/InverseWishart.birch", 50);
  #line 51 "src/distribution/InverseWishart.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/InverseWishart.birch"
  return true;
}

#line 54 "src/distribution/InverseWishart.birch"
birch::type::LLT birch::type::InverseWishart::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "src/distribution/InverseWishart.birch"
  libbirch_function_("simulate", "src/distribution/InverseWishart.birch", 54);
  #line 55 "src/distribution/InverseWishart.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/InverseWishart.birch"
  return birch::simulate_inverse_wishart(this_()->_u0936->value(handler_), this_()->k->value(handler_), handler_);
}

#line 58 "src/distribution/InverseWishart.birch"
libbirch::Optional<birch::type::LLT> birch::type::InverseWishart::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "src/distribution/InverseWishart.birch"
  libbirch_function_("simulateLazy", "src/distribution/InverseWishart.birch", 58);
  #line 59 "src/distribution/InverseWishart.birch"
  libbirch_line_(59);
  #line 59 "src/distribution/InverseWishart.birch"
  return birch::simulate_inverse_wishart(this_()->_u0936->get(handler_), this_()->k->get(handler_), handler_);
}

#line 62 "src/distribution/InverseWishart.birch"
birch::type::Real birch::type::InverseWishart::logpdf(const birch::type::LLT& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 62 "src/distribution/InverseWishart.birch"
  libbirch_function_("logpdf", "src/distribution/InverseWishart.birch", 62);
  #line 63 "src/distribution/InverseWishart.birch"
  libbirch_line_(63);
  #line 63 "src/distribution/InverseWishart.birch"
  return birch::logpdf_inverse_wishart(X, this_()->_u0936->value(handler_), this_()->k->value(handler_), handler_);
}

#line 66 "src/distribution/InverseWishart.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::InverseWishart::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "src/distribution/InverseWishart.birch"
  libbirch_function_("logpdfLazy", "src/distribution/InverseWishart.birch", 66);
  #line 67 "src/distribution/InverseWishart.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/InverseWishart.birch"
  return birch::logpdf_lazy_inverse_wishart(X, this_()->_u0936, this_()->k, handler_);
}

#line 70 "src/distribution/InverseWishart.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>>> birch::type::InverseWishart::graftInverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "src/distribution/InverseWishart.birch"
  libbirch_function_("graftInverseWishart", "src/distribution/InverseWishart.birch", 70);
  #line 71 "src/distribution/InverseWishart.birch"
  libbirch_line_(71);
  #line 71 "src/distribution/InverseWishart.birch"
  this_()->prune(handler_);
  #line 72 "src/distribution/InverseWishart.birch"
  libbirch_line_(72);
  #line 72 "src/distribution/InverseWishart.birch"
  return shared_from_this_();
}

#line 75 "src/distribution/InverseWishart.birch"
void birch::type::InverseWishart::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 75 "src/distribution/InverseWishart.birch"
  libbirch_function_("write", "src/distribution/InverseWishart.birch", 75);
  #line 76 "src/distribution/InverseWishart.birch"
  libbirch_line_(76);
  #line 76 "src/distribution/InverseWishart.birch"
  this_()->prune(handler_);
  #line 77 "src/distribution/InverseWishart.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/InverseWishart.birch"
  buffer->set(birch::type::String("class"), birch::type::String("InverseWishart"), handler_);
  #line 78 "src/distribution/InverseWishart.birch"
  libbirch_line_(78);
  #line 78 "src/distribution/InverseWishart.birch"
  buffer->set(birch::type::String("Ψ"), this_()->_u0936, handler_);
  #line 79 "src/distribution/InverseWishart.birch"
  libbirch_line_(79);
  #line 79 "src/distribution/InverseWishart.birch"
  buffer->set(birch::type::String("k"), this_()->k, handler_);
}

#line 86 "src/distribution/InverseWishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>> birch::InverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 86 "src/distribution/InverseWishart.birch"
  libbirch_function_("InverseWishart", "src/distribution/InverseWishart.birch", 86);
  #line 88 "src/distribution/InverseWishart.birch"
  libbirch_line_(88);
  #line 88 "src/distribution/InverseWishart.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>>>(_u0936, k, handler_);
}

#line 94 "src/distribution/InverseWishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>> birch::InverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 94 "src/distribution/InverseWishart.birch"
  libbirch_function_("InverseWishart", "src/distribution/InverseWishart.birch", 94);
  #line 95 "src/distribution/InverseWishart.birch"
  libbirch_line_(95);
  #line 95 "src/distribution/InverseWishart.birch"
  return birch::InverseWishart(_u0936, birch::box(k, handler_), handler_);
}

#line 101 "src/distribution/InverseWishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>> birch::InverseWishart(const birch::type::LLT& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 101 "src/distribution/InverseWishart.birch"
  libbirch_function_("InverseWishart", "src/distribution/InverseWishart.birch", 101);
  #line 102 "src/distribution/InverseWishart.birch"
  libbirch_line_(102);
  #line 102 "src/distribution/InverseWishart.birch"
  return birch::InverseWishart(birch::box(_u0936, handler_), k, handler_);
}

#line 108 "src/distribution/InverseWishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>> birch::InverseWishart(const birch::type::LLT& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 108 "src/distribution/InverseWishart.birch"
  libbirch_function_("InverseWishart", "src/distribution/InverseWishart.birch", 108);
  #line 109 "src/distribution/InverseWishart.birch"
  libbirch_line_(109);
  #line 109 "src/distribution/InverseWishart.birch"
  return birch::InverseWishart(birch::box(_u0936, handler_), birch::box(k, handler_), handler_);
}

#line 115 "src/distribution/InverseWishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>> birch::InverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 115 "src/distribution/InverseWishart.birch"
  libbirch_function_("InverseWishart", "src/distribution/InverseWishart.birch", 115);
  #line 117 "src/distribution/InverseWishart.birch"
  libbirch_line_(117);
  #line 117 "src/distribution/InverseWishart.birch"
  return birch::InverseWishart(birch::llt(_u0936, handler_), k, handler_);
}

#line 123 "src/distribution/InverseWishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>> birch::InverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 123 "src/distribution/InverseWishart.birch"
  libbirch_function_("InverseWishart", "src/distribution/InverseWishart.birch", 123);
  #line 124 "src/distribution/InverseWishart.birch"
  libbirch_line_(124);
  #line 124 "src/distribution/InverseWishart.birch"
  return birch::InverseWishart(birch::llt(_u0936, handler_), k, handler_);
}

#line 130 "src/distribution/InverseWishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>> birch::InverseWishart(const libbirch::DefaultArray<birch::type::Real,2>& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 130 "src/distribution/InverseWishart.birch"
  libbirch_function_("InverseWishart", "src/distribution/InverseWishart.birch", 130);
  #line 131 "src/distribution/InverseWishart.birch"
  libbirch_line_(131);
  #line 131 "src/distribution/InverseWishart.birch"
  return birch::InverseWishart(birch::llt(_u0936, handler_), k, handler_);
}

#line 137 "src/distribution/InverseWishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>> birch::InverseWishart(const libbirch::DefaultArray<birch::type::Real,2>& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 137 "src/distribution/InverseWishart.birch"
  libbirch_function_("InverseWishart", "src/distribution/InverseWishart.birch", 137);
  #line 138 "src/distribution/InverseWishart.birch"
  libbirch_line_(138);
  #line 138 "src/distribution/InverseWishart.birch"
  return birch::InverseWishart(birch::llt(_u0936, handler_), k, handler_);
}

#line 5 "src/distribution/LinearBoundedDiscrete.birch"
birch::type::LinearBoundedDiscrete::LinearBoundedDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 5 "src/distribution/LinearBoundedDiscrete.birch"
    super_type_(),
    #line 10 "src/distribution/LinearBoundedDiscrete.birch"
    a(a),
    #line 15 "src/distribution/LinearBoundedDiscrete.birch"
    _u0956(_u0956),
    #line 20 "src/distribution/LinearBoundedDiscrete.birch"
    c(c) {
  //
}

#line 22 "src/distribution/LinearBoundedDiscrete.birch"
birch::type::Boolean birch::type::LinearBoundedDiscrete::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("supportsLazy", "src/distribution/LinearBoundedDiscrete.birch", 22);
  #line 23 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/LinearBoundedDiscrete.birch"
  return false;
}

#line 26 "src/distribution/LinearBoundedDiscrete.birch"
birch::type::Integer birch::type::LinearBoundedDiscrete::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("simulate", "src/distribution/LinearBoundedDiscrete.birch", 26);
  #line 27 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(27);
  #line 27 "src/distribution/LinearBoundedDiscrete.birch"
  if (this_()->value.query()) {
    #line 28 "src/distribution/LinearBoundedDiscrete.birch"
    libbirch_line_(28);
    #line 28 "src/distribution/LinearBoundedDiscrete.birch"
    return birch::simulate_delta(this_()->value.get(), handler_);
  } else {
    #line 30 "src/distribution/LinearBoundedDiscrete.birch"
    libbirch_line_(30);
    #line 30 "src/distribution/LinearBoundedDiscrete.birch"
    return birch::simulate_delta(this_()->a->value(handler_) * this_()->_u0956->simulate(handler_) + this_()->c->value(handler_), handler_);
  }
}

#line 42 "src/distribution/LinearBoundedDiscrete.birch"
birch::type::Real birch::type::LinearBoundedDiscrete::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("logpdf", "src/distribution/LinearBoundedDiscrete.birch", 42);
  #line 43 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/LinearBoundedDiscrete.birch"
  if (this_()->value.query()) {
    #line 44 "src/distribution/LinearBoundedDiscrete.birch"
    libbirch_line_(44);
    #line 44 "src/distribution/LinearBoundedDiscrete.birch"
    return birch::logpdf_delta(x, this_()->value.get(), handler_);
  } else {
    #line 46 "src/distribution/LinearBoundedDiscrete.birch"
    libbirch_line_(46);
    #line 46 "src/distribution/LinearBoundedDiscrete.birch"
    return this_()->_u0956->logpdf((x - this_()->c->value(handler_)) / this_()->a->value(handler_), handler_) - birch::log(birch::abs(birch::Real(this_()->a->value(handler_), handler_), handler_), handler_);
  }
}

#line 58 "src/distribution/LinearBoundedDiscrete.birch"
void birch::type::LinearBoundedDiscrete::update(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("update", "src/distribution/LinearBoundedDiscrete.birch", 58);
  #line 59 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(59);
  #line 59 "src/distribution/LinearBoundedDiscrete.birch"
  this_()->_u0956->clamp((x - this_()->c->value(handler_)) / this_()->a->value(handler_), handler_);
}

#line 66 "src/distribution/LinearBoundedDiscrete.birch"
libbirch::Optional<birch::type::Real> birch::type::LinearBoundedDiscrete::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("cdf", "src/distribution/LinearBoundedDiscrete.birch", 66);
  #line 67 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/LinearBoundedDiscrete.birch"
  return this_()->_u0956->cdf((x - this_()->c->value(handler_)) / this_()->a->value(handler_), handler_);
}

#line 70 "src/distribution/LinearBoundedDiscrete.birch"
libbirch::Optional<birch::type::Integer> birch::type::LinearBoundedDiscrete::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("lower", "src/distribution/LinearBoundedDiscrete.birch", 70);
  #line 71 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(71);
  #line 71 "src/distribution/LinearBoundedDiscrete.birch"
  auto a = this_()->a->value(handler_);
  #line 72 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(72);
  #line 72 "src/distribution/LinearBoundedDiscrete.birch"
  if (a > birch::type::Integer(0)) {
    #line 73 "src/distribution/LinearBoundedDiscrete.birch"
    libbirch_line_(73);
    #line 73 "src/distribution/LinearBoundedDiscrete.birch"
    return a * this_()->_u0956->lower(handler_).get() + this_()->c->value(handler_);
  } else {
    #line 75 "src/distribution/LinearBoundedDiscrete.birch"
    libbirch_line_(75);
    #line 75 "src/distribution/LinearBoundedDiscrete.birch"
    return a * this_()->_u0956->upper(handler_).get() + this_()->c->value(handler_);
  }
}

#line 79 "src/distribution/LinearBoundedDiscrete.birch"
libbirch::Optional<birch::type::Integer> birch::type::LinearBoundedDiscrete::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 79 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("upper", "src/distribution/LinearBoundedDiscrete.birch", 79);
  #line 80 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(80);
  #line 80 "src/distribution/LinearBoundedDiscrete.birch"
  auto a = this_()->a->value(handler_);
  #line 81 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(81);
  #line 81 "src/distribution/LinearBoundedDiscrete.birch"
  if (a > birch::type::Integer(0)) {
    #line 82 "src/distribution/LinearBoundedDiscrete.birch"
    libbirch_line_(82);
    #line 82 "src/distribution/LinearBoundedDiscrete.birch"
    return a * this_()->_u0956->upper(handler_).get() + this_()->c->value(handler_);
  } else {
    #line 84 "src/distribution/LinearBoundedDiscrete.birch"
    libbirch_line_(84);
    #line 84 "src/distribution/LinearBoundedDiscrete.birch"
    return a * this_()->_u0956->lower(handler_).get() + this_()->c->value(handler_);
  }
}

#line 88 "src/distribution/LinearBoundedDiscrete.birch"
void birch::type::LinearBoundedDiscrete::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 88 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("link", "src/distribution/LinearBoundedDiscrete.birch", 88);
}

#line 93 "src/distribution/LinearBoundedDiscrete.birch"
void birch::type::LinearBoundedDiscrete::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 93 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("unlink", "src/distribution/LinearBoundedDiscrete.birch", 93);
}

#line 99 "src/distribution/LinearBoundedDiscrete.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LinearBoundedDiscrete>> birch::LinearBoundedDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 99 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("LinearBoundedDiscrete", "src/distribution/LinearBoundedDiscrete.birch", 99);
  #line 101 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(101);
  #line 101 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::LinearBoundedDiscrete>> m(a, _u0956, c);
  #line 102 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(102);
  #line 102 "src/distribution/LinearBoundedDiscrete.birch"
  m->link(handler_);
  #line 103 "src/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(103);
  #line 103 "src/distribution/LinearBoundedDiscrete.birch"
  return m;
}

#line 5 "src/distribution/LinearDiscrete.birch"
birch::type::LinearDiscrete::LinearDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 5 "src/distribution/LinearDiscrete.birch"
    super_type_(),
    #line 10 "src/distribution/LinearDiscrete.birch"
    a(a),
    #line 15 "src/distribution/LinearDiscrete.birch"
    _u0956(_u0956),
    #line 20 "src/distribution/LinearDiscrete.birch"
    c(c) {
  //
}

#line 22 "src/distribution/LinearDiscrete.birch"
birch::type::Boolean birch::type::LinearDiscrete::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/distribution/LinearDiscrete.birch"
  libbirch_function_("supportsLazy", "src/distribution/LinearDiscrete.birch", 22);
  #line 23 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/LinearDiscrete.birch"
  return false;
}

#line 26 "src/distribution/LinearDiscrete.birch"
birch::type::Integer birch::type::LinearDiscrete::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/distribution/LinearDiscrete.birch"
  libbirch_function_("simulate", "src/distribution/LinearDiscrete.birch", 26);
  #line 27 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(27);
  #line 27 "src/distribution/LinearDiscrete.birch"
  if (this_()->value.query()) {
    #line 28 "src/distribution/LinearDiscrete.birch"
    libbirch_line_(28);
    #line 28 "src/distribution/LinearDiscrete.birch"
    return birch::simulate_delta(this_()->value.get(), handler_);
  } else {
    #line 30 "src/distribution/LinearDiscrete.birch"
    libbirch_line_(30);
    #line 30 "src/distribution/LinearDiscrete.birch"
    return birch::simulate_delta(this_()->a->value(handler_) * this_()->_u0956->simulate(handler_) + this_()->c->value(handler_), handler_);
  }
}

#line 42 "src/distribution/LinearDiscrete.birch"
birch::type::Real birch::type::LinearDiscrete::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/distribution/LinearDiscrete.birch"
  libbirch_function_("logpdf", "src/distribution/LinearDiscrete.birch", 42);
  #line 43 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/LinearDiscrete.birch"
  if (this_()->value.query()) {
    #line 44 "src/distribution/LinearDiscrete.birch"
    libbirch_line_(44);
    #line 44 "src/distribution/LinearDiscrete.birch"
    return birch::logpdf_delta(x, this_()->value.get(), handler_);
  } else {
    #line 46 "src/distribution/LinearDiscrete.birch"
    libbirch_line_(46);
    #line 46 "src/distribution/LinearDiscrete.birch"
    return this_()->_u0956->logpdf((x - this_()->c->value(handler_)) / this_()->a->value(handler_), handler_) - birch::log(birch::abs(birch::Real(this_()->a->value(handler_), handler_), handler_), handler_);
  }
}

#line 58 "src/distribution/LinearDiscrete.birch"
void birch::type::LinearDiscrete::update(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "src/distribution/LinearDiscrete.birch"
  libbirch_function_("update", "src/distribution/LinearDiscrete.birch", 58);
  #line 59 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(59);
  #line 59 "src/distribution/LinearDiscrete.birch"
  this_()->_u0956->clamp((x - this_()->c->value(handler_)) / this_()->a->value(handler_), handler_);
}

#line 66 "src/distribution/LinearDiscrete.birch"
libbirch::Optional<birch::type::Real> birch::type::LinearDiscrete::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "src/distribution/LinearDiscrete.birch"
  libbirch_function_("cdf", "src/distribution/LinearDiscrete.birch", 66);
  #line 67 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/LinearDiscrete.birch"
  return this_()->_u0956->cdf((x - this_()->c->value(handler_)) / this_()->a->value(handler_), handler_);
}

#line 70 "src/distribution/LinearDiscrete.birch"
libbirch::Optional<birch::type::Integer> birch::type::LinearDiscrete::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "src/distribution/LinearDiscrete.birch"
  libbirch_function_("lower", "src/distribution/LinearDiscrete.birch", 70);
  #line 71 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(71);
  #line 71 "src/distribution/LinearDiscrete.birch"
  auto l = this_()->_u0956->lower(handler_);
  #line 72 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(72);
  #line 72 "src/distribution/LinearDiscrete.birch"
  if (l.query()) {
    #line 73 "src/distribution/LinearDiscrete.birch"
    libbirch_line_(73);
    #line 73 "src/distribution/LinearDiscrete.birch"
    l = this_()->a->value(handler_) * l.get() + this_()->c->value(handler_);
  }
  #line 75 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(75);
  #line 75 "src/distribution/LinearDiscrete.birch"
  return l;
}

#line 78 "src/distribution/LinearDiscrete.birch"
libbirch::Optional<birch::type::Integer> birch::type::LinearDiscrete::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 78 "src/distribution/LinearDiscrete.birch"
  libbirch_function_("upper", "src/distribution/LinearDiscrete.birch", 78);
  #line 79 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(79);
  #line 79 "src/distribution/LinearDiscrete.birch"
  auto u = this_()->_u0956->upper(handler_);
  #line 80 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(80);
  #line 80 "src/distribution/LinearDiscrete.birch"
  if (u.query()) {
    #line 81 "src/distribution/LinearDiscrete.birch"
    libbirch_line_(81);
    #line 81 "src/distribution/LinearDiscrete.birch"
    u = this_()->a->value(handler_) * u.get() + this_()->c->value(handler_);
  }
  #line 83 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(83);
  #line 83 "src/distribution/LinearDiscrete.birch"
  return u;
}

#line 86 "src/distribution/LinearDiscrete.birch"
void birch::type::LinearDiscrete::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 86 "src/distribution/LinearDiscrete.birch"
  libbirch_function_("link", "src/distribution/LinearDiscrete.birch", 86);
}

#line 91 "src/distribution/LinearDiscrete.birch"
void birch::type::LinearDiscrete::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 91 "src/distribution/LinearDiscrete.birch"
  libbirch_function_("unlink", "src/distribution/LinearDiscrete.birch", 91);
}

#line 97 "src/distribution/LinearDiscrete.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LinearDiscrete>> birch::LinearDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 97 "src/distribution/LinearDiscrete.birch"
  libbirch_function_("LinearDiscrete", "src/distribution/LinearDiscrete.birch", 97);
  #line 99 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(99);
  #line 99 "src/distribution/LinearDiscrete.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::LinearDiscrete>> m(a, _u0956, c);
  #line 100 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(100);
  #line 100 "src/distribution/LinearDiscrete.birch"
  m->link(handler_);
  #line 101 "src/distribution/LinearDiscrete.birch"
  libbirch_line_(101);
  #line 101 "src/distribution/LinearDiscrete.birch"
  return m;
}

#line 4 "src/distribution/LinearGaussianGaussian.birch"
birch::type::LinearGaussianGaussian::LinearGaussianGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>& m, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& s2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/LinearGaussianGaussian.birch"
    super_type_(a * m->_u0956 + c, a * a * m->_u09632 + s2),
    #line 10 "src/distribution/LinearGaussianGaussian.birch"
    a(a),
    #line 15 "src/distribution/LinearGaussianGaussian.birch"
    m(m),
    #line 20 "src/distribution/LinearGaussianGaussian.birch"
    c(c),
    #line 25 "src/distribution/LinearGaussianGaussian.birch"
    s2(s2) {
  //
}

#line 27 "src/distribution/LinearGaussianGaussian.birch"
void birch::type::LinearGaussianGaussian::update(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/distribution/LinearGaussianGaussian.birch"
  libbirch_function_("update", "src/distribution/LinearGaussianGaussian.birch", 27);
  #line 28 "src/distribution/LinearGaussianGaussian.birch"
  libbirch_line_(28);
  #line 28 "src/distribution/LinearGaussianGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u09632) = birch::box(birch::update_linear_gaussian_gaussian(x, this_()->a->value(handler_), this_()->m->_u0956->value(handler_), this_()->m->_u09632->value(handler_), this_()->c->value(handler_), this_()->s2->value(handler_), handler_), handler_);
}

#line 31 "src/distribution/LinearGaussianGaussian.birch"
void birch::type::LinearGaussianGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "src/distribution/LinearGaussianGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/LinearGaussianGaussian.birch", 31);
  #line 32 "src/distribution/LinearGaussianGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/distribution/LinearGaussianGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u09632) = birch::update_lazy_linear_gaussian_gaussian(x, this_()->a, this_()->m->_u0956, this_()->m->_u09632, this_()->c, this_()->s2, handler_);
}

#line 35 "src/distribution/LinearGaussianGaussian.birch"
void birch::type::LinearGaussianGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "src/distribution/LinearGaussianGaussian.birch"
  libbirch_function_("link", "src/distribution/LinearGaussianGaussian.birch", 35);
  #line 36 "src/distribution/LinearGaussianGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/LinearGaussianGaussian.birch"
  this_()->m->setChild(shared_from_this_(), handler_);
}

#line 39 "src/distribution/LinearGaussianGaussian.birch"
void birch::type::LinearGaussianGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/distribution/LinearGaussianGaussian.birch"
  libbirch_function_("unlink", "src/distribution/LinearGaussianGaussian.birch", 39);
  #line 40 "src/distribution/LinearGaussianGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/distribution/LinearGaussianGaussian.birch"
  this_()->m->releaseChild(shared_from_this_(), handler_);
}

#line 44 "src/distribution/LinearGaussianGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LinearGaussianGaussian>> birch::LinearGaussianGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/distribution/LinearGaussianGaussian.birch"
  libbirch_function_("LinearGaussianGaussian", "src/distribution/LinearGaussianGaussian.birch", 44);
  #line 46 "src/distribution/LinearGaussianGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/LinearGaussianGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::LinearGaussianGaussian>> m(a, _u0956, c, _u09632);
  #line 47 "src/distribution/LinearGaussianGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/LinearGaussianGaussian.birch"
  m->link(handler_);
  #line 48 "src/distribution/LinearGaussianGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/distribution/LinearGaussianGaussian.birch"
  return m;
}

#line 5 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::LinearMatrixNormalInverseGammaMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& A, const libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& C, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 5 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
    super_type_(),
    #line 11 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
    A(A),
    #line 16 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
    M(M),
    #line 21 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
    C(C) {
  //
}

#line 23 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::Integer birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("rows", "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 23);
  #line 24 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(24);
  #line 24 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return this_()->C->rows(handler_);
}

#line 27 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::Integer birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::columns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("columns", "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 27);
  #line 28 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(28);
  #line 28 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return this_()->C->columns(handler_);
}

#line 31 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::Boolean birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 31);
  #line 32 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return true;
}

#line 35 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("simulate", "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 35);
  #line 36 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return birch::simulate_linear_matrix_normal_inverse_gamma_matrix_gaussian(this_()->A->value(handler_), this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->C->value(handler_), this_()->M->_u0945->value(handler_), this_()->M->_u0947->value(handler_), handler_);
}

#line 40 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 40);
  #line 41 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return birch::simulate_linear_matrix_normal_inverse_gamma_matrix_gaussian(this_()->A->get(handler_), this_()->M->N->get(handler_), this_()->M->_u0923->get(handler_), this_()->C->get(handler_), this_()->M->_u0945->get(handler_), this_()->M->_u0947->get(handler_), handler_);
}

#line 45 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::Real birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 45);
  #line 46 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return birch::logpdf_linear_matrix_normal_inverse_gamma_matrix_gaussian(X, this_()->A->value(handler_), this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->C->value(handler_), this_()->M->_u0945->value(handler_), this_()->M->_u0947->value(handler_), handler_);
}

#line 50 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 50);
  #line 51 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return birch::logpdf_lazy_linear_matrix_normal_inverse_gamma_matrix_gaussian(X, this_()->A, this_()->M->N, this_()->M->_u0923, this_()->C, this_()->M->_u0945, this_()->M->_u0947, handler_);
}

#line 55 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
void birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::update(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 55 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("update", "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 55);
  #line 56 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::tie(this_()->M->N, this_()->M->_u0923, this_()->M->_u0945, this_()->M->_u0947) = birch::box(birch::update_linear_matrix_normal_inverse_gamma_matrix_gaussian(X, this_()->A->value(handler_), this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->C->value(handler_), this_()->M->_u0945->value(handler_), this_()->M->_u0947->value(handler_), handler_), handler_);
}

#line 60 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
void birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 60);
  #line 61 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::tie(this_()->M->N, this_()->M->_u0923, this_()->M->_u0945, this_()->M->_u0947) = birch::update_lazy_linear_matrix_normal_inverse_gamma_matrix_gaussian(X, this_()->A, this_()->M->N, this_()->M->_u0923, this_()->C, this_()->M->_u0945, this_()->M->_u0947, handler_);
}

#line 65 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
void birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("link", "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 65);
  #line 66 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->M->setChild(shared_from_this_(), handler_);
}

#line 69 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
void birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("unlink", "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 69);
  #line 70 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(70);
  #line 70 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->M->releaseChild(shared_from_this_(), handler_);
}

#line 74 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LinearMatrixNormalInverseGammaMatrixGaussian>> birch::LinearMatrixNormalInverseGammaMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& A, const libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& C, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 74 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("LinearMatrixNormalInverseGammaMatrixGaussian", "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 74);
  #line 77 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::LinearMatrixNormalInverseGammaMatrixGaussian>> m(A, M, C);
  #line 78 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(78);
  #line 78 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  m->link(handler_);
  #line 79 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(79);
  #line 79 "src/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return m;
}

#line 5 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::LinearMatrixNormalInverseWishartMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& A, const libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& C, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 5 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
    super_type_(),
    #line 11 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
    A(A),
    #line 16 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
    M(M),
    #line 21 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
    C(C) {
  //
}

#line 23 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Integer birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("rows", "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 23);
  #line 24 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(24);
  #line 24 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return this_()->C->rows(handler_);
}

#line 27 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Integer birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::columns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("columns", "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 27);
  #line 28 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(28);
  #line 28 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return this_()->C->columns(handler_);
}

#line 31 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Boolean birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 31);
  #line 32 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return true;
}

#line 35 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("simulate", "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 35);
  #line 36 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return birch::simulate_linear_matrix_normal_inverse_wishart_matrix_gaussian(this_()->A->value(handler_), this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->C->value(handler_), this_()->M->V->_u0936->value(handler_), this_()->M->V->k->value(handler_), handler_);
}

#line 40 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 40);
  #line 41 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return birch::simulate_linear_matrix_normal_inverse_wishart_matrix_gaussian(this_()->A->get(handler_), this_()->M->N->get(handler_), this_()->M->_u0923->get(handler_), this_()->C->get(handler_), this_()->M->V->_u0936->get(handler_), this_()->M->V->k->get(handler_), handler_);
}

#line 45 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Real birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 45);
  #line 46 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return birch::logpdf_linear_matrix_normal_inverse_wishart_matrix_gaussian(X, this_()->A->value(handler_), this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->C->value(handler_), this_()->M->V->_u0936->value(handler_), this_()->M->V->k->value(handler_), handler_);
}

#line 50 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 50);
  #line 51 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return birch::logpdf_lazy_linear_matrix_normal_inverse_wishart_matrix_gaussian(X, this_()->A, this_()->M->N, this_()->M->_u0923, this_()->C, this_()->M->V->_u0936, this_()->M->V->k, handler_);
}

#line 55 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::update(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 55 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("update", "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 55);
  #line 56 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::tie(this_()->M->N, this_()->M->_u0923, this_()->M->V->_u0936, this_()->M->V->k) = birch::box(birch::update_linear_matrix_normal_inverse_wishart_matrix_gaussian(X, this_()->A->value(handler_), this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->C->value(handler_), this_()->M->V->_u0936->value(handler_), this_()->M->V->k->value(handler_), handler_), handler_);
}

#line 60 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 60);
  #line 61 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::tie(this_()->M->N, this_()->M->_u0923, this_()->M->V->_u0936, this_()->M->V->k) = birch::update_lazy_linear_matrix_normal_inverse_wishart_matrix_gaussian(X, this_()->A, this_()->M->N, this_()->M->_u0923, this_()->C, this_()->M->V->_u0936, this_()->M->V->k, handler_);
}

#line 65 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("link", "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 65);
  #line 66 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->M->setChild(shared_from_this_(), handler_);
}

#line 69 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("unlink", "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 69);
  #line 70 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(70);
  #line 70 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->M->releaseChild(shared_from_this_(), handler_);
}

#line 74 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LinearMatrixNormalInverseWishartMatrixGaussian>> birch::LinearMatrixNormalInverseWishartMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& A, const libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& C, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 74 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("LinearMatrixNormalInverseWishartMatrixGaussian", "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 74);
  #line 77 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::LinearMatrixNormalInverseWishartMatrixGaussian>> m(A, M, C);
  #line 78 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(78);
  #line 78 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  m->link(handler_);
  #line 79 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(79);
  #line 79 "src/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return m;
}

#line 4 "src/distribution/LinearMultivariateGaussianGaussian.birch"
birch::type::LinearMultivariateGaussianGaussian::LinearMultivariateGaussianGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>& m, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& s2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/LinearMultivariateGaussianGaussian.birch"
    super_type_(birch::dot(a, m->_u0956, handler_) + c, birch::dot(a, birch::canonical(m->_u0931, handler_) * a, handler_) + s2),
    #line 10 "src/distribution/LinearMultivariateGaussianGaussian.birch"
    a(a),
    #line 15 "src/distribution/LinearMultivariateGaussianGaussian.birch"
    m(m),
    #line 20 "src/distribution/LinearMultivariateGaussianGaussian.birch"
    c(c),
    #line 25 "src/distribution/LinearMultivariateGaussianGaussian.birch"
    s2(s2) {
  //
}

#line 27 "src/distribution/LinearMultivariateGaussianGaussian.birch"
void birch::type::LinearMultivariateGaussianGaussian::update(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_function_("update", "src/distribution/LinearMultivariateGaussianGaussian.birch", 27);
  #line 28 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_line_(28);
  #line 28 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u0931) = birch::box(birch::update_linear_multivariate_gaussian_gaussian(x, this_()->a->value(handler_), this_()->m->_u0956->value(handler_), this_()->m->_u0931->value(handler_), this_()->c->value(handler_), this_()->s2->value(handler_), handler_), handler_);
}

#line 32 "src/distribution/LinearMultivariateGaussianGaussian.birch"
void birch::type::LinearMultivariateGaussianGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/LinearMultivariateGaussianGaussian.birch", 32);
  #line 33 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u0931) = birch::update_lazy_linear_multivariate_gaussian_gaussian(x, this_()->a, this_()->m->_u0956, this_()->m->_u0931, this_()->c, this_()->s2, handler_);
}

#line 37 "src/distribution/LinearMultivariateGaussianGaussian.birch"
void birch::type::LinearMultivariateGaussianGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_function_("link", "src/distribution/LinearMultivariateGaussianGaussian.birch", 37);
  #line 38 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  this_()->m->setChild(shared_from_this_(), handler_);
}

#line 41 "src/distribution/LinearMultivariateGaussianGaussian.birch"
void birch::type::LinearMultivariateGaussianGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_function_("unlink", "src/distribution/LinearMultivariateGaussianGaussian.birch", 41);
  #line 42 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  this_()->m->releaseChild(shared_from_this_(), handler_);
}

#line 46 "src/distribution/LinearMultivariateGaussianGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LinearMultivariateGaussianGaussian>> birch::LinearMultivariateGaussianGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_function_("LinearMultivariateGaussianGaussian", "src/distribution/LinearMultivariateGaussianGaussian.birch", 46);
  #line 49 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::LinearMultivariateGaussianGaussian>> m(a, _u0956, c, _u09632);
  #line 50 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  m->link(handler_);
  #line 51 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/LinearMultivariateGaussianGaussian.birch"
  return m;
}

#line 4 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
birch::type::LinearMultivariateGaussianMultivariateGaussian::LinearMultivariateGaussianMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& A, const libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>& m, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& S, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
    super_type_(A * m->_u0956 + c, birch::llt(A * birch::canonical(m->_u0931, handler_) * birch::transpose(A, handler_) + birch::canonical(S, handler_), handler_)),
    #line 11 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
    A(A),
    #line 16 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
    m(m),
    #line 21 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
    c(c),
    #line 26 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
    S(S) {
  //
}

#line 28 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
void birch::type::LinearMultivariateGaussianMultivariateGaussian::update(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("update", "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch", 28);
  #line 29 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u0931) = birch::box(birch::update_linear_multivariate_gaussian_multivariate_gaussian(x, this_()->A->value(handler_), this_()->m->_u0956->value(handler_), this_()->m->_u0931->value(handler_), this_()->c->value(handler_), this_()->S->value(handler_), handler_), handler_);
}

#line 33 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
void birch::type::LinearMultivariateGaussianMultivariateGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch", 33);
  #line 34 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u0931) = birch::update_lazy_linear_multivariate_gaussian_multivariate_gaussian(x, this_()->A, this_()->m->_u0956, this_()->m->_u0931, this_()->c, this_()->S, handler_);
}

#line 38 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
void birch::type::LinearMultivariateGaussianMultivariateGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("link", "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch", 38);
  #line 39 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  this_()->m->setChild(shared_from_this_(), handler_);
}

#line 42 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
void birch::type::LinearMultivariateGaussianMultivariateGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("unlink", "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch", 42);
  #line 43 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  this_()->m->releaseChild(shared_from_this_(), handler_);
}

#line 47 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LinearMultivariateGaussianMultivariateGaussian>> birch::LinearMultivariateGaussianMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& A, const libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("LinearMultivariateGaussianMultivariateGaussian", "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch", 47);
  #line 51 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::LinearMultivariateGaussianMultivariateGaussian>> m(A, _u0956, c, _u0931);
  #line 52 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  m->link(handler_);
  #line 53 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  return m;
}

#line 4 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
birch::type::LinearMultivariateNormalInverseGammaGaussian::LinearMultivariateNormalInverseGammaGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
    super_type_(),
    #line 10 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
    a(a),
    #line 15 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
    _u0956(_u0956),
    #line 20 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
    c(c) {
  //
}

#line 22 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
birch::type::Integer birch::type::LinearMultivariateNormalInverseGammaGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("rows", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 22);
  #line 23 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return this_()->c->rows(handler_);
}

#line 26 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
birch::type::Boolean birch::type::LinearMultivariateNormalInverseGammaGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 26);
  #line 27 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(27);
  #line 27 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return true;
}

#line 30 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
birch::type::Real birch::type::LinearMultivariateNormalInverseGammaGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("simulate", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 30);
  #line 31 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return birch::simulate_linear_multivariate_normal_inverse_gamma_gaussian(this_()->a->value(handler_), this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_);
}

#line 36 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::LinearMultivariateNormalInverseGammaGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 36);
  #line 37 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return birch::simulate_linear_multivariate_normal_inverse_gamma_gaussian(this_()->a->get(handler_), this_()->_u0956->_u0957->get(handler_), this_()->_u0956->_u0923->get(handler_), this_()->c->get(handler_), this_()->_u0956->_u0945->get(handler_), this_()->_u0956->_u0947->get(handler_), handler_);
}

#line 42 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
birch::type::Real birch::type::LinearMultivariateNormalInverseGammaGaussian::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 42);
  #line 43 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return birch::logpdf_linear_multivariate_normal_inverse_gamma_gaussian(x, this_()->a->value(handler_), this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_);
}

#line 48 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::LinearMultivariateNormalInverseGammaGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 48);
  #line 49 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return birch::logpdf_lazy_linear_multivariate_normal_inverse_gamma_gaussian(x, this_()->a, this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->c, this_()->_u0956->_u0945, this_()->_u0956->_u0947, handler_);
}

#line 53 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaGaussian::update(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("update", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 53);
  #line 54 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->_u0956->_u0945, this_()->_u0956->_u0947) = birch::box(birch::update_linear_multivariate_normal_inverse_gamma_gaussian(x, this_()->a->value(handler_), this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_), handler_);
}

#line 59 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 59);
  #line 60 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->_u0956->_u0945, this_()->_u0956->_u0947) = birch::update_lazy_linear_multivariate_normal_inverse_gamma_gaussian(x, this_()->a, this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->c, this_()->_u0956->_u0945, this_()->_u0956->_u0947, handler_);
}

#line 64 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::LinearMultivariateNormalInverseGammaGaussian::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("cdf", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 64);
  #line 65 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return birch::cdf_linear_multivariate_normal_inverse_gamma_gaussian(x, this_()->a->value(handler_), this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_);
}

#line 70 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::LinearMultivariateNormalInverseGammaGaussian::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("quantile", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 70);
  #line 71 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(71);
  #line 71 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return birch::quantile_linear_multivariate_normal_inverse_gamma_gaussian(P, this_()->a->value(handler_), this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_);
}

#line 76 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("link", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 76);
  #line 77 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  this_()->_u0956->setChild(shared_from_this_(), handler_);
}

#line 80 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 80 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("unlink", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 80);
  #line 81 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(81);
  #line 81 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  this_()->_u0956->releaseChild(shared_from_this_(), handler_);
}

#line 85 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LinearMultivariateNormalInverseGammaGaussian>> birch::LinearMultivariateNormalInverseGammaGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 85 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("LinearMultivariateNormalInverseGammaGaussian", "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 85);
  #line 88 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(88);
  #line 88 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::LinearMultivariateNormalInverseGammaGaussian>> m(a, _u0956, c);
  #line 89 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(89);
  #line 89 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  m->link(handler_);
  #line 90 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(90);
  #line 90 "src/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return m;
}

#line 5 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::LinearMultivariateNormalInverseGammaMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& A, const libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 5 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    super_type_(),
    #line 11 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    A(A),
    #line 16 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    _u0956(_u0956),
    #line 21 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    c(c) {
  //
}

#line 23 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::Integer birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("rows", "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 23);
  #line 24 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(24);
  #line 24 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return this_()->c->rows(handler_);
}

#line 27 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::Boolean birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 27);
  #line 28 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(28);
  #line 28 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return true;
}

#line 31 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("simulate", "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 31);
  #line 32 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return birch::simulate_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(this_()->A->value(handler_), this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_);
}

#line 36 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 36);
  #line 37 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return birch::simulate_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(this_()->A->get(handler_), this_()->_u0956->_u0957->get(handler_), this_()->_u0956->_u0923->get(handler_), this_()->c->get(handler_), this_()->_u0956->_u0945->get(handler_), this_()->_u0956->_u0947->get(handler_), handler_);
}

#line 41 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::Real birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 41);
  #line 42 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return birch::logpdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this_()->A->value(handler_), this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_);
}

#line 46 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 46);
  #line 47 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return birch::logpdf_lazy_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this_()->A, this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->c, this_()->_u0956->_u0945, this_()->_u0956->_u0947, handler_);
}

#line 51 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::update(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 51 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("update", "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 51);
  #line 52 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->_u0956->_u0945, this_()->_u0956->_u0947) = birch::box(birch::update_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this_()->A->value(handler_), this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_), handler_);
}

#line 56 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 56 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 56);
  #line 57 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->_u0956->_u0945, this_()->_u0956->_u0947) = birch::update_lazy_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this_()->A, this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->c, this_()->_u0956->_u0945, this_()->_u0956->_u0947, handler_);
}

#line 61 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("link", "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 61);
  #line 62 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  this_()->_u0956->setChild(shared_from_this_(), handler_);
}

#line 65 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("unlink", "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 65);
  #line 66 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  this_()->_u0956->releaseChild(shared_from_this_(), handler_);
}

#line 70 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian>> birch::LinearMultivariateNormalInverseGammaMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& A, const libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("LinearMultivariateNormalInverseGammaMultivariateGaussian", "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 70);
  #line 74 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(74);
  #line 74 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian>> m(A, _u0956, c);
  #line 75 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(75);
  #line 75 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  m->link(handler_);
  #line 76 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(76);
  #line 76 "src/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return m;
}

#line 4 "src/distribution/LinearNormalInverseGammaGaussian.birch"
birch::type::LinearNormalInverseGammaGaussian::LinearNormalInverseGammaGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/LinearNormalInverseGammaGaussian.birch"
    super_type_(),
    #line 9 "src/distribution/LinearNormalInverseGammaGaussian.birch"
    a(a),
    #line 14 "src/distribution/LinearNormalInverseGammaGaussian.birch"
    _u0956(_u0956),
    #line 19 "src/distribution/LinearNormalInverseGammaGaussian.birch"
    c(c) {
  //
}

#line 21 "src/distribution/LinearNormalInverseGammaGaussian.birch"
birch::type::Boolean birch::type::LinearNormalInverseGammaGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/LinearNormalInverseGammaGaussian.birch", 21);
  #line 22 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(22);
  #line 22 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  return true;
}

#line 25 "src/distribution/LinearNormalInverseGammaGaussian.birch"
birch::type::Real birch::type::LinearNormalInverseGammaGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("simulate", "src/distribution/LinearNormalInverseGammaGaussian.birch", 25);
  #line 26 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  return birch::simulate_linear_normal_inverse_gamma_gaussian(this_()->a->value(handler_), this_()->_u0956->_u0956->value(handler_), 1.0 / this_()->_u0956->_u0955->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u09632->_u0945->value(handler_), this_()->_u0956->_u09632->_u0946->value(handler_), handler_);
}

#line 31 "src/distribution/LinearNormalInverseGammaGaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::LinearNormalInverseGammaGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/LinearNormalInverseGammaGaussian.birch", 31);
  #line 32 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  return birch::simulate_linear_normal_inverse_gamma_gaussian(this_()->a->get(handler_), this_()->_u0956->_u0956->get(handler_), 1.0 / this_()->_u0956->_u0955->get(handler_), this_()->c->get(handler_), this_()->_u0956->_u09632->_u0945->get(handler_), this_()->_u0956->_u09632->_u0946->get(handler_), handler_);
}

#line 36 "src/distribution/LinearNormalInverseGammaGaussian.birch"
birch::type::Real birch::type::LinearNormalInverseGammaGaussian::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/LinearNormalInverseGammaGaussian.birch", 36);
  #line 37 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  return birch::logpdf_linear_normal_inverse_gamma_gaussian(x, this_()->a->value(handler_), this_()->_u0956->_u0956->value(handler_), 1.0 / this_()->_u0956->_u0955->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u09632->_u0945->value(handler_), this_()->_u0956->_u09632->_u0946->value(handler_), handler_);
}

#line 42 "src/distribution/LinearNormalInverseGammaGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::LinearNormalInverseGammaGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/LinearNormalInverseGammaGaussian.birch", 42);
  #line 43 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  return birch::logpdf_lazy_linear_normal_inverse_gamma_gaussian(x, this_()->a, this_()->_u0956->_u0956, 1.0 / this_()->_u0956->_u0955, this_()->c, this_()->_u0956->_u09632->_u0945, this_()->_u0956->_u09632->_u0946, handler_);
}

#line 47 "src/distribution/LinearNormalInverseGammaGaussian.birch"
void birch::type::LinearNormalInverseGammaGaussian::update(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("update", "src/distribution/LinearNormalInverseGammaGaussian.birch", 47);
  #line 48 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0956, this_()->_u0956->_u0955, this_()->_u0956->_u09632->_u0945, this_()->_u0956->_u09632->_u0946) = birch::box(birch::update_linear_normal_inverse_gamma_gaussian(x, this_()->a->value(handler_), this_()->_u0956->_u0956->value(handler_), this_()->_u0956->_u0955->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u09632->_u0945->value(handler_), this_()->_u0956->_u09632->_u0946->value(handler_), handler_), handler_);
}

#line 53 "src/distribution/LinearNormalInverseGammaGaussian.birch"
void birch::type::LinearNormalInverseGammaGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/LinearNormalInverseGammaGaussian.birch", 53);
  #line 54 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0956, this_()->_u0956->_u0955, this_()->_u0956->_u09632->_u0945, this_()->_u0956->_u09632->_u0946) = birch::update_lazy_linear_normal_inverse_gamma_gaussian(x, this_()->a, this_()->_u0956->_u0956, this_()->_u0956->_u0955, this_()->c, this_()->_u0956->_u09632->_u0945, this_()->_u0956->_u09632->_u0946, handler_);
}

#line 58 "src/distribution/LinearNormalInverseGammaGaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::LinearNormalInverseGammaGaussian::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("cdf", "src/distribution/LinearNormalInverseGammaGaussian.birch", 58);
  #line 59 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(59);
  #line 59 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  return birch::cdf_linear_normal_inverse_gamma_gaussian(x, this_()->a->value(handler_), this_()->_u0956->_u0956->value(handler_), 1.0 / this_()->_u0956->_u0955->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u09632->_u0945->value(handler_), this_()->_u0956->_u09632->_u0946->value(handler_), handler_);
}

#line 64 "src/distribution/LinearNormalInverseGammaGaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::LinearNormalInverseGammaGaussian::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("quantile", "src/distribution/LinearNormalInverseGammaGaussian.birch", 64);
  #line 65 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  return birch::quantile_linear_normal_inverse_gamma_gaussian(P, this_()->a->value(handler_), this_()->_u0956->_u0956->value(handler_), 1.0 / this_()->_u0956->_u0955->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u09632->_u0945->value(handler_), this_()->_u0956->_u09632->_u0946->value(handler_), handler_);
}

#line 70 "src/distribution/LinearNormalInverseGammaGaussian.birch"
void birch::type::LinearNormalInverseGammaGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("link", "src/distribution/LinearNormalInverseGammaGaussian.birch", 70);
  #line 71 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(71);
  #line 71 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  this_()->_u0956->setChild(shared_from_this_(), handler_);
}

#line 74 "src/distribution/LinearNormalInverseGammaGaussian.birch"
void birch::type::LinearNormalInverseGammaGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 74 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("unlink", "src/distribution/LinearNormalInverseGammaGaussian.birch", 74);
  #line 75 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(75);
  #line 75 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  this_()->_u0956->releaseChild(shared_from_this_(), handler_);
}

#line 79 "src/distribution/LinearNormalInverseGammaGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LinearNormalInverseGammaGaussian>> birch::LinearNormalInverseGammaGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 79 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("LinearNormalInverseGammaGaussian", "src/distribution/LinearNormalInverseGammaGaussian.birch", 79);
  #line 82 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(82);
  #line 82 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::LinearNormalInverseGammaGaussian>> m(a, _u0956, c);
  #line 83 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(83);
  #line 83 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  m->link(handler_);
  #line 84 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(84);
  #line 84 "src/distribution/LinearNormalInverseGammaGaussian.birch"
  return m;
}

#line 1 "src/distribution/MatrixGaussian.birch"
birch::type::MatrixGaussian::MatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/distribution/MatrixGaussian.birch"
    super_type_(),
    #line 13 "src/distribution/MatrixGaussian.birch"
    M(M),
    #line 18 "src/distribution/MatrixGaussian.birch"
    U(U),
    #line 23 "src/distribution/MatrixGaussian.birch"
    V(V) {
  //
}

#line 25 "src/distribution/MatrixGaussian.birch"
birch::type::Integer birch::type::MatrixGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("rows", "src/distribution/MatrixGaussian.birch", 25);
  #line 26 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/distribution/MatrixGaussian.birch"
  return this_()->M->rows(handler_);
}

#line 29 "src/distribution/MatrixGaussian.birch"
birch::type::Integer birch::type::MatrixGaussian::columns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("columns", "src/distribution/MatrixGaussian.birch", 29);
  #line 30 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/distribution/MatrixGaussian.birch"
  return this_()->M->columns(handler_);
}

#line 33 "src/distribution/MatrixGaussian.birch"
birch::type::Boolean birch::type::MatrixGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/MatrixGaussian.birch", 33);
  #line 34 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/distribution/MatrixGaussian.birch"
  return true;
}

#line 37 "src/distribution/MatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("simulate", "src/distribution/MatrixGaussian.birch", 37);
  #line 38 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/distribution/MatrixGaussian.birch"
  return birch::simulate_matrix_gaussian(this_()->M->value(handler_), this_()->U->value(handler_), this_()->V->value(handler_), handler_);
}

#line 41 "src/distribution/MatrixGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::MatrixGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/MatrixGaussian.birch", 41);
  #line 42 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/MatrixGaussian.birch"
  return birch::simulate_matrix_gaussian(this_()->M->get(handler_), this_()->U->get(handler_), this_()->V->get(handler_), handler_);
}

#line 45 "src/distribution/MatrixGaussian.birch"
birch::type::Real birch::type::MatrixGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/MatrixGaussian.birch", 45);
  #line 46 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/MatrixGaussian.birch"
  return birch::logpdf_matrix_gaussian(X, this_()->M->value(handler_), this_()->U->value(handler_), this_()->V->value(handler_), handler_);
}

#line 49 "src/distribution/MatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::MatrixGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/MatrixGaussian.birch", 49);
  #line 50 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/MatrixGaussian.birch"
  return birch::logpdf_lazy_matrix_gaussian(X, this_()->M, this_()->U, this_()->V, handler_);
}

#line 53 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>> birch::type::MatrixGaussian::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("graft", "src/distribution/MatrixGaussian.birch", 53);
  #line 54 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/MatrixGaussian.birch"
  this_()->prune(handler_);
  #line 55 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/MatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>>> s1;
  #line 56 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/MatrixGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>> r = shared_from_this_();
  #line 59 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(59);
  #line 59 "src/distribution/MatrixGaussian.birch"
  if ((s1 = this_()->V->graftInverseWishart(handler_)).query()) {
    #line 60 "src/distribution/MatrixGaussian.birch"
    libbirch_line_(60);
    #line 60 "src/distribution/MatrixGaussian.birch"
    r = birch::MatrixNormalInverseWishart(this_()->M, this_()->U, s1.get(), handler_);
  }
  #line 63 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(63);
  #line 63 "src/distribution/MatrixGaussian.birch"
  return r;
}

#line 66 "src/distribution/MatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>> birch::type::MatrixGaussian::graftMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("graftMatrixGaussian", "src/distribution/MatrixGaussian.birch", 66);
  #line 67 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/MatrixGaussian.birch"
  this_()->prune(handler_);
  #line 68 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(68);
  #line 68 "src/distribution/MatrixGaussian.birch"
  return shared_from_this_();
}

#line 71 "src/distribution/MatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>> birch::type::MatrixGaussian::graftMatrixNormalInverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::LLT>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 71 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("graftMatrixNormalInverseWishart", "src/distribution/MatrixGaussian.birch", 71);
  #line 73 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(73);
  #line 73 "src/distribution/MatrixGaussian.birch"
  this_()->prune(handler_);
  #line 74 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(74);
  #line 74 "src/distribution/MatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>>> s1;
  #line 75 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(75);
  #line 75 "src/distribution/MatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>> r;
  #line 78 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(78);
  #line 78 "src/distribution/MatrixGaussian.birch"
  if ((s1 = this_()->V->graftInverseWishart(handler_)).query() && s1.get() == compare) {
    #line 79 "src/distribution/MatrixGaussian.birch"
    libbirch_line_(79);
    #line 79 "src/distribution/MatrixGaussian.birch"
    r = birch::MatrixNormalInverseWishart(this_()->M, this_()->U, s1.get(), handler_);
  }
  #line 82 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(82);
  #line 82 "src/distribution/MatrixGaussian.birch"
  return r;
}

#line 85 "src/distribution/MatrixGaussian.birch"
void birch::type::MatrixGaussian::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 85 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("write", "src/distribution/MatrixGaussian.birch", 85);
  #line 86 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(86);
  #line 86 "src/distribution/MatrixGaussian.birch"
  this_()->prune(handler_);
  #line 87 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(87);
  #line 87 "src/distribution/MatrixGaussian.birch"
  buffer->set(birch::type::String("class"), birch::type::String("MatrixGaussian"), handler_);
  #line 88 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(88);
  #line 88 "src/distribution/MatrixGaussian.birch"
  buffer->set(birch::type::String("M"), this_()->M, handler_);
  #line 89 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(89);
  #line 89 "src/distribution/MatrixGaussian.birch"
  buffer->set(birch::type::String("U"), this_()->U, handler_);
  #line 90 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(90);
  #line 90 "src/distribution/MatrixGaussian.birch"
  buffer->set(birch::type::String("V"), this_()->V, handler_);
}

#line 97 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 97 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 97);
  #line 99 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(99);
  #line 99 "src/distribution/MatrixGaussian.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>>(M, U, V, handler_);
}

#line 105 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const birch::type::LLT& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 105 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 105);
  #line 107 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(107);
  #line 107 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::box(V, handler_), handler_);
}

#line 113 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const birch::type::LLT& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 113 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 113);
  #line 115 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(115);
  #line 115 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::box(U, handler_), V, handler_);
}

#line 121 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const birch::type::LLT& U, const birch::type::LLT& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 121 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 121);
  #line 123 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(123);
  #line 123 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::box(U, handler_), birch::box(V, handler_), handler_);
}

#line 129 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 129 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 129);
  #line 131 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(131);
  #line 131 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(birch::box(M, handler_), U, V, handler_);
}

#line 137 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const birch::type::LLT& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 137 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 137);
  #line 138 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(138);
  #line 138 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(birch::box(M, handler_), U, birch::box(V, handler_), handler_);
}

#line 144 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 144 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 144);
  #line 145 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(145);
  #line 145 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(birch::box(M, handler_), birch::box(U, handler_), V, handler_);
}

#line 151 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const birch::type::LLT& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 151 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 151);
  #line 152 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(152);
  #line 152 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(birch::box(M, handler_), birch::box(U, handler_), birch::box(V, handler_), handler_);
}

#line 158 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 158 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 158);
  #line 160 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(160);
  #line 160 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), V, handler_);
}

#line 166 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& U, const birch::type::LLT& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 166 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 166);
  #line 168 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(168);
  #line 168 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), V, handler_);
}

#line 174 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 174 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 174);
  #line 176 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(176);
  #line 176 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), V, handler_);
}

#line 182 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const birch::type::LLT& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 182 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 182);
  #line 184 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(184);
  #line 184 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), V, handler_);
}

#line 190 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 190 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 190);
  #line 192 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(192);
  #line 192 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), V, handler_);
}

#line 198 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& U, const birch::type::LLT& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 198 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 198);
  #line 199 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(199);
  #line 199 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), V, handler_);
}

#line 205 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 205 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 205);
  #line 206 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(206);
  #line 206 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), V, handler_);
}

#line 212 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const birch::type::LLT& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 212 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 212);
  #line 213 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(213);
  #line 213 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), V, handler_);
}

#line 219 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 219 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 219);
  #line 221 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(221);
  #line 221 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::llt(V, handler_), handler_);
}

#line 227 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::DefaultArray<birch::type::Real,2>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 227 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 227);
  #line 229 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(229);
  #line 229 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::llt(V, handler_), handler_);
}

#line 235 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const birch::type::LLT& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 235 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 235);
  #line 237 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(237);
  #line 237 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::llt(V, handler_), handler_);
}

#line 243 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const birch::type::LLT& U, const libbirch::DefaultArray<birch::type::Real,2>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 243 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 243);
  #line 245 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(245);
  #line 245 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::llt(V, handler_), handler_);
}

#line 251 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 251 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 251);
  #line 253 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(253);
  #line 253 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::llt(V, handler_), handler_);
}

#line 259 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::DefaultArray<birch::type::Real,2>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 259 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 259);
  #line 261 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(261);
  #line 261 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::llt(V, handler_), handler_);
}

#line 267 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 267 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 267);
  #line 269 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(269);
  #line 269 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::llt(V, handler_), handler_);
}

#line 275 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const libbirch::DefaultArray<birch::type::Real,2>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 275 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 275);
  #line 276 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(276);
  #line 276 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::llt(V, handler_), handler_);
}

#line 282 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 282 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 282);
  #line 284 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(284);
  #line 284 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), birch::llt(V, handler_), handler_);
}

#line 290 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& U, const libbirch::DefaultArray<birch::type::Real,2>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 290 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 290);
  #line 292 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(292);
  #line 292 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), birch::llt(V, handler_), handler_);
}

#line 298 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 298 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 298);
  #line 300 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(300);
  #line 300 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), birch::llt(V, handler_), handler_);
}

#line 306 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::DefaultArray<birch::type::Real,2>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 306 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 306);
  #line 308 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(308);
  #line 308 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), birch::llt(V, handler_), handler_);
}

#line 314 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 314 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 314);
  #line 316 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(316);
  #line 316 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), birch::llt(V, handler_), handler_);
}

#line 322 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& U, const libbirch::DefaultArray<birch::type::Real,2>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 322 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 322);
  #line 324 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(324);
  #line 324 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), birch::llt(V, handler_), handler_);
}

#line 330 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 330 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 330);
  #line 332 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(332);
  #line 332 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), birch::llt(V, handler_), handler_);
}

#line 338 "src/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::DefaultArray<birch::type::Real,2>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 338 "src/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MatrixGaussian.birch", 338);
  #line 339 "src/distribution/MatrixGaussian.birch"
  libbirch_line_(339);
  #line 339 "src/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), birch::llt(V, handler_), handler_);
}

#line 4 "src/distribution/MatrixNormalInverseGamma.birch"
birch::type::MatrixNormalInverseGamma::MatrixNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::IndependentInverseGamma>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/MatrixNormalInverseGamma.birch"
    super_type_(),
    #line 10 "src/distribution/MatrixNormalInverseGamma.birch"
    _u0923(birch::inv(_u0931, handler_)),
    #line 15 "src/distribution/MatrixNormalInverseGamma.birch"
    N(birch::canonical(_u0923, handler_) * M),
    #line 20 "src/distribution/MatrixNormalInverseGamma.birch"
    _u0945(_u09632->_u0945),
    #line 25 "src/distribution/MatrixNormalInverseGamma.birch"
    _u0947(_u09632->_u0946 + 0.5 * birch::diagonal(birch::transpose(N, handler_) * M, handler_)),
    #line 30 "src/distribution/MatrixNormalInverseGamma.birch"
    _u09632(_u09632) {
  //
}

#line 32 "src/distribution/MatrixNormalInverseGamma.birch"
birch::type::Integer birch::type::MatrixNormalInverseGamma::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("rows", "src/distribution/MatrixNormalInverseGamma.birch", 32);
  #line 33 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/MatrixNormalInverseGamma.birch"
  return this_()->N->rows(handler_);
}

#line 36 "src/distribution/MatrixNormalInverseGamma.birch"
birch::type::Integer birch::type::MatrixNormalInverseGamma::columns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("columns", "src/distribution/MatrixNormalInverseGamma.birch", 36);
  #line 37 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/MatrixNormalInverseGamma.birch"
  return this_()->N->columns(handler_);
}

#line 40 "src/distribution/MatrixNormalInverseGamma.birch"
birch::type::Boolean birch::type::MatrixNormalInverseGamma::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("supportsLazy", "src/distribution/MatrixNormalInverseGamma.birch", 40);
  #line 41 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/MatrixNormalInverseGamma.birch"
  return true;
}

#line 44 "src/distribution/MatrixNormalInverseGamma.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixNormalInverseGamma::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("simulate", "src/distribution/MatrixNormalInverseGamma.birch", 44);
  #line 45 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/MatrixNormalInverseGamma.birch"
  return birch::simulate_matrix_normal_inverse_gamma(this_()->N->value(handler_), this_()->_u0923->value(handler_), this_()->_u0945->value(handler_), birch::gamma_to_beta(this_()->_u0947->value(handler_), this_()->N->value(handler_), this_()->_u0923->value(handler_), handler_), handler_);
}

#line 49 "src/distribution/MatrixNormalInverseGamma.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::MatrixNormalInverseGamma::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("simulateLazy", "src/distribution/MatrixNormalInverseGamma.birch", 49);
  #line 50 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/MatrixNormalInverseGamma.birch"
  return birch::simulate_matrix_normal_inverse_gamma(this_()->N->get(handler_), this_()->_u0923->get(handler_), this_()->_u0945->get(handler_), birch::gamma_to_beta(this_()->_u0947->get(handler_), this_()->N->get(handler_), this_()->_u0923->get(handler_), handler_), handler_);
}

#line 54 "src/distribution/MatrixNormalInverseGamma.birch"
birch::type::Real birch::type::MatrixNormalInverseGamma::logpdf(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("logpdf", "src/distribution/MatrixNormalInverseGamma.birch", 54);
  #line 55 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/MatrixNormalInverseGamma.birch"
  return birch::logpdf_matrix_normal_inverse_gamma(X, this_()->N->value(handler_), this_()->_u0923->value(handler_), this_()->_u0945->value(handler_), birch::gamma_to_beta(this_()->_u0947->value(handler_), this_()->N->value(handler_), this_()->_u0923->value(handler_), handler_), handler_);
}

#line 59 "src/distribution/MatrixNormalInverseGamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::MatrixNormalInverseGamma::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("logpdfLazy", "src/distribution/MatrixNormalInverseGamma.birch", 59);
  #line 60 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/MatrixNormalInverseGamma.birch"
  return birch::logpdf_lazy_matrix_normal_inverse_gamma(X, this_()->N, this_()->_u0923, this_()->_u0945, birch::gamma_to_beta(this_()->_u0947, this_()->N, this_()->_u0923, handler_), handler_);
}

#line 64 "src/distribution/MatrixNormalInverseGamma.birch"
void birch::type::MatrixNormalInverseGamma::update(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("update", "src/distribution/MatrixNormalInverseGamma.birch", 64);
  #line 65 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch::tie(this_()->_u09632->_u0945, this_()->_u09632->_u0946) = birch::box(birch::update_matrix_normal_inverse_gamma(X, this_()->N->value(handler_), this_()->_u0923->value(handler_), this_()->_u0945->value(handler_), birch::gamma_to_beta(this_()->_u0947->value(handler_), this_()->N->value(handler_), this_()->_u0923->value(handler_), handler_), handler_), handler_);
}

#line 70 "src/distribution/MatrixNormalInverseGamma.birch"
void birch::type::MatrixNormalInverseGamma::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("updateLazy", "src/distribution/MatrixNormalInverseGamma.birch", 70);
  #line 71 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(71);
  #line 71 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch::tie(this_()->_u09632->_u0945, this_()->_u09632->_u0946) = birch::update_lazy_matrix_normal_inverse_gamma(X, this_()->N, this_()->_u0923, this_()->_u0945, birch::gamma_to_beta(this_()->_u0947, this_()->N, this_()->_u0923, handler_), handler_);
}

#line 75 "src/distribution/MatrixNormalInverseGamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>> birch::type::MatrixNormalInverseGamma::graftMatrixNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 75 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("graftMatrixNormalInverseGamma", "src/distribution/MatrixNormalInverseGamma.birch", 75);
  #line 77 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/MatrixNormalInverseGamma.birch"
  this_()->prune(handler_);
  #line 78 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(78);
  #line 78 "src/distribution/MatrixNormalInverseGamma.birch"
  if (this_()->_u09632 == compare) {
    #line 79 "src/distribution/MatrixNormalInverseGamma.birch"
    libbirch_line_(79);
    #line 79 "src/distribution/MatrixNormalInverseGamma.birch"
    return shared_from_this_();
  } else {
    #line 81 "src/distribution/MatrixNormalInverseGamma.birch"
    libbirch_line_(81);
    #line 81 "src/distribution/MatrixNormalInverseGamma.birch"
    return libbirch::nil;
  }
}

#line 85 "src/distribution/MatrixNormalInverseGamma.birch"
void birch::type::MatrixNormalInverseGamma::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 85 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("link", "src/distribution/MatrixNormalInverseGamma.birch", 85);
  #line 86 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(86);
  #line 86 "src/distribution/MatrixNormalInverseGamma.birch"
  this_()->_u09632->setChild(shared_from_this_(), handler_);
}

#line 89 "src/distribution/MatrixNormalInverseGamma.birch"
void birch::type::MatrixNormalInverseGamma::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 89 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("unlink", "src/distribution/MatrixNormalInverseGamma.birch", 89);
  #line 90 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(90);
  #line 90 "src/distribution/MatrixNormalInverseGamma.birch"
  this_()->_u09632->releaseChild(shared_from_this_(), handler_);
}

#line 93 "src/distribution/MatrixNormalInverseGamma.birch"
void birch::type::MatrixNormalInverseGamma::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 93 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("write", "src/distribution/MatrixNormalInverseGamma.birch", 93);
  #line 94 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(94);
  #line 94 "src/distribution/MatrixNormalInverseGamma.birch"
  this_()->prune(handler_);
  #line 95 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(95);
  #line 95 "src/distribution/MatrixNormalInverseGamma.birch"
  buffer->set(birch::type::String("class"), birch::type::String("MatrixNormalInverseGamma"), handler_);
  #line 96 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(96);
  #line 96 "src/distribution/MatrixNormalInverseGamma.birch"
  buffer->set(birch::type::String("M"), birch::solve(this_()->_u0923->value(handler_), this_()->N->value(handler_), handler_), handler_);
  #line 97 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(97);
  #line 97 "src/distribution/MatrixNormalInverseGamma.birch"
  buffer->set(birch::type::String("Σ"), birch::inv(this_()->_u0923->value(handler_), handler_), handler_);
  #line 98 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(98);
  #line 98 "src/distribution/MatrixNormalInverseGamma.birch"
  buffer->set(birch::type::String("α"), this_()->_u0945, handler_);
  #line 99 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(99);
  #line 99 "src/distribution/MatrixNormalInverseGamma.birch"
  buffer->set(birch::type::String("β"), birch::gamma_to_beta(this_()->_u0947->value(handler_), this_()->N->value(handler_), this_()->_u0923->value(handler_), handler_), handler_);
}

#line 103 "src/distribution/MatrixNormalInverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>> birch::MatrixNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::IndependentInverseGamma>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 103 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("MatrixNormalInverseGamma", "src/distribution/MatrixNormalInverseGamma.birch", 103);
  #line 105 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(105);
  #line 105 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>> m(M, _u0931, _u09632);
  #line 106 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(106);
  #line 106 "src/distribution/MatrixNormalInverseGamma.birch"
  m->link(handler_);
  #line 107 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(107);
  #line 107 "src/distribution/MatrixNormalInverseGamma.birch"
  return m;
}

#line 114 "src/distribution/MatrixNormalInverseGamma.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::gamma_to_beta(const libbirch::DefaultArray<birch::type::Real,1>& _u0947, const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& _u0923, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 114 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("gamma_to_beta", "src/distribution/MatrixNormalInverseGamma.birch", 114);
  #line 115 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(115);
  #line 115 "src/distribution/MatrixNormalInverseGamma.birch"
  return _u0947 - 0.5 * birch::diagonal(birch::transpose(N, handler_) * birch::solve(_u0923, N, handler_), handler_);
}

#line 118 "src/distribution/MatrixNormalInverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>> birch::gamma_to_beta(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0947, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& N, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0923, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 118 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("gamma_to_beta", "src/distribution/MatrixNormalInverseGamma.birch", 118);
  #line 120 "src/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(120);
  #line 120 "src/distribution/MatrixNormalInverseGamma.birch"
  return _u0947 - 0.5 * birch::diagonal(birch::transpose(N, handler_) * birch::solve(_u0923, N, handler_), handler_);
}

#line 4 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::MatrixNormalInverseGammaMatrixGaussian::MatrixNormalInverseGammaMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
    super_type_(),
    #line 9 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
    M(M) {
  //
}

#line 11 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::Integer birch::type::MatrixNormalInverseGammaMatrixGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("rows", "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 11);
  #line 12 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(12);
  #line 12 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  auto M = this_()->M;
  #line 13 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(13);
  #line 13 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  return M->rows(handler_);
}

#line 16 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::Integer birch::type::MatrixNormalInverseGammaMatrixGaussian::columns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("columns", "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 16);
  #line 17 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  auto M = this_()->M;
  #line 18 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(18);
  #line 18 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  return M->columns(handler_);
}

#line 21 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::Boolean birch::type::MatrixNormalInverseGammaMatrixGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 21);
  #line 22 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(22);
  #line 22 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  return true;
}

#line 25 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixNormalInverseGammaMatrixGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("simulate", "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 25);
  #line 26 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  return birch::simulate_matrix_normal_inverse_gamma_matrix_gaussian(this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->M->_u0945->value(handler_), this_()->M->_u0947->value(handler_), handler_);
}

#line 30 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::MatrixNormalInverseGammaMatrixGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 30);
  #line 31 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  return birch::simulate_matrix_normal_inverse_gamma_matrix_gaussian(this_()->M->N->get(handler_), this_()->M->_u0923->get(handler_), this_()->M->_u0945->get(handler_), this_()->M->_u0947->get(handler_), handler_);
}

#line 35 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::Real birch::type::MatrixNormalInverseGammaMatrixGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 35);
  #line 36 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  return birch::logpdf_matrix_normal_inverse_gamma_matrix_gaussian(X, this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->M->_u0945->value(handler_), this_()->M->_u0947->value(handler_), handler_);
}

#line 40 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::MatrixNormalInverseGammaMatrixGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 40);
  #line 41 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  return birch::logpdf_lazy_matrix_normal_inverse_gamma_matrix_gaussian(X, this_()->M->N, this_()->M->_u0923, this_()->M->_u0945, this_()->M->_u0947, handler_);
}

#line 45 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
void birch::type::MatrixNormalInverseGammaMatrixGaussian::update(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("update", "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 45);
  #line 46 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::tie(this_()->M->N, this_()->M->_u0923, this_()->M->_u0945, this_()->M->_u0947) = birch::box(birch::update_matrix_normal_inverse_gamma_matrix_gaussian(X, this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->M->_u0945->value(handler_), this_()->M->_u0947->value(handler_), handler_), handler_);
}

#line 50 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
void birch::type::MatrixNormalInverseGammaMatrixGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 50);
  #line 51 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::tie(this_()->M->N, this_()->M->_u0923, this_()->M->_u0945, this_()->M->_u0947) = birch::update_lazy_matrix_normal_inverse_gamma_matrix_gaussian(X, this_()->M->N, this_()->M->_u0923, this_()->M->_u0945, this_()->M->_u0947, handler_);
}

#line 55 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
void birch::type::MatrixNormalInverseGammaMatrixGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 55 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("link", "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 55);
  #line 56 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->M->setChild(shared_from_this_(), handler_);
}

#line 59 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
void birch::type::MatrixNormalInverseGammaMatrixGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("unlink", "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 59);
  #line 60 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->M->releaseChild(shared_from_this_(), handler_);
}

#line 64 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGammaMatrixGaussian>> birch::MatrixNormalInverseGammaMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("MatrixNormalInverseGammaMatrixGaussian", "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 64);
  #line 66 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGammaMatrixGaussian>> m(M);
  #line 67 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  m->link(handler_);
  #line 68 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(68);
  #line 68 "src/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  return m;
}

#line 4 "src/distribution/MatrixNormalInverseWishart.birch"
birch::type::MatrixNormalInverseWishart::MatrixNormalInverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/MatrixNormalInverseWishart.birch"
    super_type_(),
    #line 9 "src/distribution/MatrixNormalInverseWishart.birch"
    _u0923(birch::inv(U, handler_)),
    #line 14 "src/distribution/MatrixNormalInverseWishart.birch"
    N(birch::canonical(_u0923, handler_) * M),
    #line 19 "src/distribution/MatrixNormalInverseWishart.birch"
    V(V) {
  //
}

#line 21 "src/distribution/MatrixNormalInverseWishart.birch"
birch::type::Integer birch::type::MatrixNormalInverseWishart::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("rows", "src/distribution/MatrixNormalInverseWishart.birch", 21);
  #line 22 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(22);
  #line 22 "src/distribution/MatrixNormalInverseWishart.birch"
  return this_()->N->rows(handler_);
}

#line 25 "src/distribution/MatrixNormalInverseWishart.birch"
birch::type::Integer birch::type::MatrixNormalInverseWishart::columns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("columns", "src/distribution/MatrixNormalInverseWishart.birch", 25);
  #line 26 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(26);
  #line 26 "src/distribution/MatrixNormalInverseWishart.birch"
  return this_()->N->columns(handler_);
}

#line 29 "src/distribution/MatrixNormalInverseWishart.birch"
birch::type::Boolean birch::type::MatrixNormalInverseWishart::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("supportsLazy", "src/distribution/MatrixNormalInverseWishart.birch", 29);
  #line 30 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(30);
  #line 30 "src/distribution/MatrixNormalInverseWishart.birch"
  return true;
}

#line 33 "src/distribution/MatrixNormalInverseWishart.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixNormalInverseWishart::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("simulate", "src/distribution/MatrixNormalInverseWishart.birch", 33);
  #line 34 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(34);
  #line 34 "src/distribution/MatrixNormalInverseWishart.birch"
  return birch::simulate_matrix_normal_inverse_wishart(this_()->N->value(handler_), this_()->_u0923->value(handler_), this_()->V->_u0936->value(handler_), this_()->V->k->value(handler_), handler_);
}

#line 37 "src/distribution/MatrixNormalInverseWishart.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::MatrixNormalInverseWishart::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("simulateLazy", "src/distribution/MatrixNormalInverseWishart.birch", 37);
  #line 38 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(38);
  #line 38 "src/distribution/MatrixNormalInverseWishart.birch"
  return birch::simulate_matrix_normal_inverse_wishart(this_()->N->get(handler_), this_()->_u0923->get(handler_), this_()->V->_u0936->get(handler_), this_()->V->k->get(handler_), handler_);
}

#line 41 "src/distribution/MatrixNormalInverseWishart.birch"
birch::type::Real birch::type::MatrixNormalInverseWishart::logpdf(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("logpdf", "src/distribution/MatrixNormalInverseWishart.birch", 41);
  #line 42 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/MatrixNormalInverseWishart.birch"
  return birch::logpdf_matrix_normal_inverse_wishart(X, this_()->N->value(handler_), this_()->_u0923->value(handler_), this_()->V->_u0936->value(handler_), this_()->V->k->value(handler_), handler_);
}

#line 45 "src/distribution/MatrixNormalInverseWishart.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::MatrixNormalInverseWishart::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("logpdfLazy", "src/distribution/MatrixNormalInverseWishart.birch", 45);
  #line 46 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/MatrixNormalInverseWishart.birch"
  return birch::logpdf_lazy_matrix_normal_inverse_wishart(X, this_()->N, this_()->_u0923, this_()->V->_u0936, this_()->V->k, handler_);
}

#line 49 "src/distribution/MatrixNormalInverseWishart.birch"
void birch::type::MatrixNormalInverseWishart::update(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("update", "src/distribution/MatrixNormalInverseWishart.birch", 49);
  #line 50 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch::tie(this_()->V->_u0936, this_()->V->k) = birch::box(birch::update_matrix_normal_inverse_wishart(X, this_()->N->value(handler_), this_()->_u0923->value(handler_), this_()->V->_u0936->value(handler_), this_()->V->k->value(handler_), handler_), handler_);
}

#line 53 "src/distribution/MatrixNormalInverseWishart.birch"
void birch::type::MatrixNormalInverseWishart::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("updateLazy", "src/distribution/MatrixNormalInverseWishart.birch", 53);
  #line 54 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch::tie(this_()->V->_u0936, this_()->V->k) = birch::update_lazy_matrix_normal_inverse_wishart(X, this_()->N, this_()->_u0923, this_()->V->_u0936, this_()->V->k, handler_);
}

#line 57 "src/distribution/MatrixNormalInverseWishart.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>> birch::type::MatrixNormalInverseWishart::graftMatrixNormalInverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::LLT>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 57 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("graftMatrixNormalInverseWishart", "src/distribution/MatrixNormalInverseWishart.birch", 57);
  #line 59 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(59);
  #line 59 "src/distribution/MatrixNormalInverseWishart.birch"
  this_()->prune(handler_);
  #line 60 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/MatrixNormalInverseWishart.birch"
  if (this_()->V == compare) {
    #line 61 "src/distribution/MatrixNormalInverseWishart.birch"
    libbirch_line_(61);
    #line 61 "src/distribution/MatrixNormalInverseWishart.birch"
    return shared_from_this_();
  } else {
    #line 63 "src/distribution/MatrixNormalInverseWishart.birch"
    libbirch_line_(63);
    #line 63 "src/distribution/MatrixNormalInverseWishart.birch"
    return libbirch::nil;
  }
}

#line 67 "src/distribution/MatrixNormalInverseWishart.birch"
void birch::type::MatrixNormalInverseWishart::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 67 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("link", "src/distribution/MatrixNormalInverseWishart.birch", 67);
  #line 68 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(68);
  #line 68 "src/distribution/MatrixNormalInverseWishart.birch"
  this_()->V->setChild(shared_from_this_(), handler_);
}

#line 71 "src/distribution/MatrixNormalInverseWishart.birch"
void birch::type::MatrixNormalInverseWishart::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 71 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("unlink", "src/distribution/MatrixNormalInverseWishart.birch", 71);
  #line 72 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(72);
  #line 72 "src/distribution/MatrixNormalInverseWishart.birch"
  this_()->V->releaseChild(shared_from_this_(), handler_);
}

#line 75 "src/distribution/MatrixNormalInverseWishart.birch"
void birch::type::MatrixNormalInverseWishart::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 75 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("write", "src/distribution/MatrixNormalInverseWishart.birch", 75);
  #line 76 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(76);
  #line 76 "src/distribution/MatrixNormalInverseWishart.birch"
  this_()->prune(handler_);
  #line 77 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/MatrixNormalInverseWishart.birch"
  buffer->set(birch::type::String("class"), birch::type::String("MatrixNormalInverseWishart"), handler_);
  #line 78 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(78);
  #line 78 "src/distribution/MatrixNormalInverseWishart.birch"
  buffer->set(birch::type::String("M"), birch::solve(this_()->_u0923->value(handler_), this_()->N->value(handler_), handler_), handler_);
  #line 79 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(79);
  #line 79 "src/distribution/MatrixNormalInverseWishart.birch"
  buffer->set(birch::type::String("Σ"), birch::inv(this_()->_u0923->value(handler_), handler_), handler_);
  #line 80 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(80);
  #line 80 "src/distribution/MatrixNormalInverseWishart.birch"
  buffer->set(birch::type::String("Ψ"), this_()->V->_u0936->value(handler_), handler_);
  #line 81 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(81);
  #line 81 "src/distribution/MatrixNormalInverseWishart.birch"
  buffer->set(birch::type::String("k"), this_()->V->k->value(handler_), handler_);
}

#line 85 "src/distribution/MatrixNormalInverseWishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>> birch::MatrixNormalInverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 85 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("MatrixNormalInverseWishart", "src/distribution/MatrixNormalInverseWishart.birch", 85);
  #line 87 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(87);
  #line 87 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>> m(M, U, V);
  #line 88 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(88);
  #line 88 "src/distribution/MatrixNormalInverseWishart.birch"
  m->link(handler_);
  #line 89 "src/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(89);
  #line 89 "src/distribution/MatrixNormalInverseWishart.birch"
  return m;
}

#line 4 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::MatrixNormalInverseWishartMatrixGaussian::MatrixNormalInverseWishartMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
    super_type_(),
    #line 9 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
    M(M) {
  //
}

#line 11 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Integer birch::type::MatrixNormalInverseWishartMatrixGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("rows", "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 11);
  #line 12 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(12);
  #line 12 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  return this_()->M->rows(handler_);
}

#line 15 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Integer birch::type::MatrixNormalInverseWishartMatrixGaussian::columns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("columns", "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 15);
  #line 16 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  return this_()->M->columns(handler_);
}

#line 19 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Boolean birch::type::MatrixNormalInverseWishartMatrixGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 19);
  #line 20 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(20);
  #line 20 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  return true;
}

#line 23 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixNormalInverseWishartMatrixGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("simulate", "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 23);
  #line 24 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(24);
  #line 24 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  return birch::simulate_matrix_normal_inverse_wishart_matrix_gaussian(this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->M->V->_u0936->value(handler_), this_()->M->V->k->value(handler_), handler_);
}

#line 28 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::MatrixNormalInverseWishartMatrixGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 28);
  #line 29 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  return birch::simulate_matrix_normal_inverse_wishart_matrix_gaussian(this_()->M->N->get(handler_), this_()->M->_u0923->get(handler_), this_()->M->V->_u0936->get(handler_), this_()->M->V->k->get(handler_), handler_);
}

#line 33 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Real birch::type::MatrixNormalInverseWishartMatrixGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 33);
  #line 34 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  return birch::logpdf_matrix_normal_inverse_wishart_matrix_gaussian(X, this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->M->V->_u0936->value(handler_), this_()->M->V->k->value(handler_), handler_);
}

#line 38 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::MatrixNormalInverseWishartMatrixGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 38);
  #line 39 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  return birch::logpdf_lazy_matrix_normal_inverse_wishart_matrix_gaussian(X, this_()->M->N, this_()->M->_u0923, this_()->M->V->_u0936, this_()->M->V->k, handler_);
}

#line 43 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::MatrixNormalInverseWishartMatrixGaussian::update(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("update", "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 43);
  #line 44 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(44);
  #line 44 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::tie(this_()->M->N, this_()->M->_u0923, this_()->M->V->_u0936, this_()->M->V->k) = birch::box(birch::update_matrix_normal_inverse_wishart_matrix_gaussian(X, this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->M->V->_u0936->value(handler_), this_()->M->V->k->value(handler_), handler_), handler_);
}

#line 48 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::MatrixNormalInverseWishartMatrixGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 48);
  #line 49 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::tie(this_()->M->N, this_()->M->_u0923, this_()->M->V->_u0936, this_()->M->V->k) = birch::update_lazy_matrix_normal_inverse_wishart_matrix_gaussian(X, this_()->M->N, this_()->M->_u0923, this_()->M->V->_u0936, this_()->M->V->k, handler_);
}

#line 53 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::MatrixNormalInverseWishartMatrixGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("link", "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 53);
  #line 54 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->M->setChild(shared_from_this_(), handler_);
}

#line 57 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::MatrixNormalInverseWishartMatrixGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 57 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("unlink", "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 57);
  #line 58 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(58);
  #line 58 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->M->releaseChild(shared_from_this_(), handler_);
}

#line 62 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishartMatrixGaussian>> birch::MatrixNormalInverseWishartMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 62 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("MatrixNormalInverseWishartMatrixGaussian", "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 62);
  #line 65 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishartMatrixGaussian>> m(M);
  #line 66 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  m->link(handler_);
  #line 67 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  return m;
}

#line 1 "src/distribution/Multinomial.birch"
birch::type::Multinomial::Multinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& n, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/distribution/Multinomial.birch"
    super_type_(),
    #line 9 "src/distribution/Multinomial.birch"
    n(n),
    #line 14 "src/distribution/Multinomial.birch"
    _u0961(_u0961) {
  //
}

#line 16 "src/distribution/Multinomial.birch"
birch::type::Integer birch::type::Multinomial::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/distribution/Multinomial.birch"
  libbirch_function_("rows", "src/distribution/Multinomial.birch", 16);
  #line 17 "src/distribution/Multinomial.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/Multinomial.birch"
  return this_()->_u0961->rows(handler_);
}

#line 20 "src/distribution/Multinomial.birch"
birch::type::Boolean birch::type::Multinomial::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/distribution/Multinomial.birch"
  libbirch_function_("supportsLazy", "src/distribution/Multinomial.birch", 20);
  #line 21 "src/distribution/Multinomial.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/Multinomial.birch"
  return false;
}

#line 24 "src/distribution/Multinomial.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::type::Multinomial::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/distribution/Multinomial.birch"
  libbirch_function_("simulate", "src/distribution/Multinomial.birch", 24);
  #line 25 "src/distribution/Multinomial.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/Multinomial.birch"
  return birch::simulate_multinomial(this_()->n->value(handler_), this_()->_u0961->value(handler_), handler_);
}

#line 32 "src/distribution/Multinomial.birch"
birch::type::Real birch::type::Multinomial::logpdf(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/distribution/Multinomial.birch"
  libbirch_function_("logpdf", "src/distribution/Multinomial.birch", 32);
  #line 33 "src/distribution/Multinomial.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/Multinomial.birch"
  return birch::logpdf_multinomial(x, this_()->n->value(handler_), this_()->_u0961->value(handler_), handler_);
}

#line 40 "src/distribution/Multinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Integer,1>>>> birch::type::Multinomial::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "src/distribution/Multinomial.birch"
  libbirch_function_("graft", "src/distribution/Multinomial.birch", 40);
  #line 41 "src/distribution/Multinomial.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/Multinomial.birch"
  this_()->prune(handler_);
  #line 42 "src/distribution/Multinomial.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/Multinomial.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Dirichlet>>> m;
  #line 43 "src/distribution/Multinomial.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/Multinomial.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Integer,1>>>> r = shared_from_this_();
  #line 46 "src/distribution/Multinomial.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/Multinomial.birch"
  if ((m = this_()->_u0961->graftDirichlet(handler_)).query()) {
    #line 47 "src/distribution/Multinomial.birch"
    libbirch_line_(47);
    #line 47 "src/distribution/Multinomial.birch"
    r = birch::DirichletMultinomial(this_()->n, m.get(), handler_);
  }
  #line 50 "src/distribution/Multinomial.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/Multinomial.birch"
  return r;
}

#line 53 "src/distribution/Multinomial.birch"
void birch::type::Multinomial::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "src/distribution/Multinomial.birch"
  libbirch_function_("write", "src/distribution/Multinomial.birch", 53);
  #line 54 "src/distribution/Multinomial.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/Multinomial.birch"
  this_()->prune(handler_);
  #line 55 "src/distribution/Multinomial.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/Multinomial.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Multinomial"), handler_);
  #line 56 "src/distribution/Multinomial.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/Multinomial.birch"
  buffer->set(birch::type::String("n"), this_()->n, handler_);
  #line 57 "src/distribution/Multinomial.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/Multinomial.birch"
  buffer->set(birch::type::String("ρ"), this_()->_u0961, handler_);
}

#line 64 "src/distribution/Multinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Multinomial>> birch::Multinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& n, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "src/distribution/Multinomial.birch"
  libbirch_function_("Multinomial", "src/distribution/Multinomial.birch", 64);
  #line 66 "src/distribution/Multinomial.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/Multinomial.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Multinomial>>>(n, _u0961, handler_);
}

#line 72 "src/distribution/Multinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Multinomial>> birch::Multinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& n, const libbirch::DefaultArray<birch::type::Real,1>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "src/distribution/Multinomial.birch"
  libbirch_function_("Multinomial", "src/distribution/Multinomial.birch", 72);
  #line 73 "src/distribution/Multinomial.birch"
  libbirch_line_(73);
  #line 73 "src/distribution/Multinomial.birch"
  return birch::Multinomial(n, birch::box(_u0961, handler_), handler_);
}

#line 79 "src/distribution/Multinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Multinomial>> birch::Multinomial(const birch::type::Integer& n, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 79 "src/distribution/Multinomial.birch"
  libbirch_function_("Multinomial", "src/distribution/Multinomial.birch", 79);
  #line 80 "src/distribution/Multinomial.birch"
  libbirch_line_(80);
  #line 80 "src/distribution/Multinomial.birch"
  return birch::Multinomial(birch::box(n, handler_), _u0961, handler_);
}

#line 86 "src/distribution/Multinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Multinomial>> birch::Multinomial(const birch::type::Integer& n, const libbirch::DefaultArray<birch::type::Real,1>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 86 "src/distribution/Multinomial.birch"
  libbirch_function_("Multinomial", "src/distribution/Multinomial.birch", 86);
  #line 87 "src/distribution/Multinomial.birch"
  libbirch_line_(87);
  #line 87 "src/distribution/Multinomial.birch"
  return birch::Multinomial(birch::box(n, handler_), birch::box(_u0961, handler_), handler_);
}

#line 1 "src/distribution/MultivariateGaussian.birch"
birch::type::MultivariateGaussian::MultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/distribution/MultivariateGaussian.birch"
    super_type_(),
    #line 13 "src/distribution/MultivariateGaussian.birch"
    _u0956(_u0956),
    #line 18 "src/distribution/MultivariateGaussian.birch"
    _u0931(_u0931) {
  //
}

#line 20 "src/distribution/MultivariateGaussian.birch"
birch::type::Integer birch::type::MultivariateGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("rows", "src/distribution/MultivariateGaussian.birch", 20);
  #line 21 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/MultivariateGaussian.birch"
  return this_()->_u0956->rows(handler_);
}

#line 24 "src/distribution/MultivariateGaussian.birch"
birch::type::Boolean birch::type::MultivariateGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/MultivariateGaussian.birch", 24);
  #line 25 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/MultivariateGaussian.birch"
  return true;
}

#line 28 "src/distribution/MultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("simulate", "src/distribution/MultivariateGaussian.birch", 28);
  #line 29 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/MultivariateGaussian.birch"
  return birch::simulate_multivariate_gaussian(this_()->_u0956->value(handler_), this_()->_u0931->value(handler_), handler_);
}

#line 32 "src/distribution/MultivariateGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::MultivariateGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/MultivariateGaussian.birch", 32);
  #line 33 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/MultivariateGaussian.birch"
  return birch::simulate_multivariate_gaussian(this_()->_u0956->get(handler_), this_()->_u0931->get(handler_), handler_);
}

#line 36 "src/distribution/MultivariateGaussian.birch"
birch::type::Real birch::type::MultivariateGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/MultivariateGaussian.birch", 36);
  #line 37 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/MultivariateGaussian.birch"
  return birch::logpdf_multivariate_gaussian(x, this_()->_u0956->value(handler_), this_()->_u0931->value(handler_), handler_);
}

#line 40 "src/distribution/MultivariateGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::MultivariateGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/MultivariateGaussian.birch", 40);
  #line 41 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/MultivariateGaussian.birch"
  return birch::logpdf_lazy_multivariate_gaussian(x, this_()->_u0956, this_()->_u0931, handler_);
}

#line 44 "src/distribution/MultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>> birch::type::MultivariateGaussian::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("graft", "src/distribution/MultivariateGaussian.birch", 44);
  #line 45 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/MultivariateGaussian.birch"
  this_()->prune(handler_);
  #line 46 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/MultivariateGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> m1;
  #line 47 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/MultivariateGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>> m2;
  #line 48 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/distribution/MultivariateGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>> r = shared_from_this_();
  #line 51 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/MultivariateGaussian.birch"
  if ((m1 = this_()->_u0956->graftLinearMultivariateGaussian(handler_)).query()) {
    #line 52 "src/distribution/MultivariateGaussian.birch"
    libbirch_line_(52);
    #line 52 "src/distribution/MultivariateGaussian.birch"
    r = birch::LinearMultivariateGaussianMultivariateGaussian(m1.get()->A, m1.get()->x, m1.get()->c, this_()->_u0931, handler_);
  } else {
    #line 53 "src/distribution/MultivariateGaussian.birch"
    libbirch_line_(53);
    #line 53 "src/distribution/MultivariateGaussian.birch"
    if ((m2 = this_()->_u0956->graftMultivariateGaussian(handler_)).query()) {
      #line 54 "src/distribution/MultivariateGaussian.birch"
      libbirch_line_(54);
      #line 54 "src/distribution/MultivariateGaussian.birch"
      r = birch::MultivariateGaussianMultivariateGaussian(m2.get(), this_()->_u0931, handler_);
    }
  }
  #line 57 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/MultivariateGaussian.birch"
  return r;
}

#line 60 "src/distribution/MultivariateGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>> birch::type::MultivariateGaussian::graftMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("graftMultivariateGaussian", "src/distribution/MultivariateGaussian.birch", 60);
  #line 61 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/MultivariateGaussian.birch"
  this_()->prune(handler_);
  #line 62 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/MultivariateGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> m1;
  #line 63 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(63);
  #line 63 "src/distribution/MultivariateGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>> m2;
  #line 64 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(64);
  #line 64 "src/distribution/MultivariateGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>> r = shared_from_this_();
  #line 67 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/MultivariateGaussian.birch"
  if ((m1 = this_()->_u0956->graftLinearMultivariateGaussian(handler_)).query()) {
    #line 68 "src/distribution/MultivariateGaussian.birch"
    libbirch_line_(68);
    #line 68 "src/distribution/MultivariateGaussian.birch"
    r = birch::LinearMultivariateGaussianMultivariateGaussian(m1.get()->A, m1.get()->x, m1.get()->c, this_()->_u0931, handler_);
  } else {
    #line 69 "src/distribution/MultivariateGaussian.birch"
    libbirch_line_(69);
    #line 69 "src/distribution/MultivariateGaussian.birch"
    if ((m2 = this_()->_u0956->graftMultivariateGaussian(handler_)).query()) {
      #line 70 "src/distribution/MultivariateGaussian.birch"
      libbirch_line_(70);
      #line 70 "src/distribution/MultivariateGaussian.birch"
      r = birch::MultivariateGaussianMultivariateGaussian(m2.get(), this_()->_u0931, handler_);
    }
  }
  #line 73 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(73);
  #line 73 "src/distribution/MultivariateGaussian.birch"
  return r;
}

#line 76 "src/distribution/MultivariateGaussian.birch"
void birch::type::MultivariateGaussian::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("write", "src/distribution/MultivariateGaussian.birch", 76);
  #line 77 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/MultivariateGaussian.birch"
  this_()->prune(handler_);
  #line 78 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(78);
  #line 78 "src/distribution/MultivariateGaussian.birch"
  buffer->set(birch::type::String("class"), birch::type::String("MultivariateGaussian"), handler_);
  #line 79 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(79);
  #line 79 "src/distribution/MultivariateGaussian.birch"
  buffer->set(birch::type::String("μ"), this_()->_u0956, handler_);
  #line 80 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(80);
  #line 80 "src/distribution/MultivariateGaussian.birch"
  buffer->set(birch::type::String("Σ"), this_()->_u0931, handler_);
}

#line 87 "src/distribution/MultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 87 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 87);
  #line 89 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(89);
  #line 89 "src/distribution/MultivariateGaussian.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>(_u0956, _u0931, handler_);
}

#line 95 "src/distribution/MultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const birch::type::LLT& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 95);
  #line 96 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(96);
  #line 96 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::box(_u0931, handler_), handler_);
}

#line 102 "src/distribution/MultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 102 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 102);
  #line 103 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(103);
  #line 103 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), _u0931, handler_);
}

#line 109 "src/distribution/MultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const birch::type::LLT& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 109 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 109);
  #line 110 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(110);
  #line 110 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), birch::box(_u0931, handler_), handler_);
}

#line 116 "src/distribution/MultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 116 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 116);
  #line 118 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(118);
  #line 118 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931, handler_), handler_);
}

#line 124 "src/distribution/MultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::DefaultArray<birch::type::Real,2>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 124 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 124);
  #line 126 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(126);
  #line 126 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931, handler_), handler_);
}

#line 132 "src/distribution/MultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 132 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 132);
  #line 134 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(134);
  #line 134 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931, handler_), handler_);
}

#line 140 "src/distribution/MultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::DefaultArray<birch::type::Real,2>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 140 "src/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/MultivariateGaussian.birch", 140);
  #line 141 "src/distribution/MultivariateGaussian.birch"
  libbirch_line_(141);
  #line 141 "src/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931, handler_), handler_);
}

#line 4 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
birch::type::MultivariateGaussianMultivariateGaussian::MultivariateGaussianMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>& m, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& S, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
    super_type_(m->_u0956, birch::llt(birch::canonical(m->_u0931, handler_) + birch::canonical(S, handler_), handler_)),
    #line 10 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
    m(m),
    #line 15 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
    S(S) {
  //
}

#line 17 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
void birch::type::MultivariateGaussianMultivariateGaussian::update(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 17 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("update", "src/distribution/MultivariateGaussianMultivariateGaussian.birch", 17);
  #line 18 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(18);
  #line 18 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u0931) = birch::box(birch::update_multivariate_gaussian_multivariate_gaussian(x, this_()->m->_u0956->value(handler_), this_()->m->_u0931->value(handler_), this_()->S->value(handler_), handler_), handler_);
}

#line 21 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
void birch::type::MultivariateGaussianMultivariateGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/MultivariateGaussianMultivariateGaussian.birch", 21);
  #line 22 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(22);
  #line 22 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u0931) = birch::update_lazy_multivariate_gaussian_multivariate_gaussian(x, this_()->m->_u0956, this_()->m->_u0931, this_()->S, handler_);
}

#line 25 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
void birch::type::MultivariateGaussianMultivariateGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("link", "src/distribution/MultivariateGaussianMultivariateGaussian.birch", 25);
  #line 26 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  this_()->m->setChild(shared_from_this_(), handler_);
}

#line 29 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
void birch::type::MultivariateGaussianMultivariateGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("unlink", "src/distribution/MultivariateGaussianMultivariateGaussian.birch", 29);
  #line 30 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  this_()->m->releaseChild(shared_from_this_(), handler_);
}

#line 34 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussianMultivariateGaussian>> birch::MultivariateGaussianMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("MultivariateGaussianMultivariateGaussian", "src/distribution/MultivariateGaussianMultivariateGaussian.birch", 34);
  #line 36 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussianMultivariateGaussian>> m(_u0956, _u0931);
  #line 37 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  m->link(handler_);
  #line 38 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/distribution/MultivariateGaussianMultivariateGaussian.birch"
  return m;
}

#line 29 "src/distribution/MultivariateNormalInverseGamma.birch"
birch::type::MultivariateNormalInverseGamma::MultivariateNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 29 "src/distribution/MultivariateNormalInverseGamma.birch"
    super_type_(),
    #line 34 "src/distribution/MultivariateNormalInverseGamma.birch"
    _u0923(birch::inv(_u0931, handler_)),
    #line 39 "src/distribution/MultivariateNormalInverseGamma.birch"
    _u0957(birch::canonical(_u0923, handler_) * _u0956),
    #line 44 "src/distribution/MultivariateNormalInverseGamma.birch"
    _u0945(_u09632->_u0945),
    #line 49 "src/distribution/MultivariateNormalInverseGamma.birch"
    _u0947(_u09632->_u0946 + 0.5 * birch::dot(_u0956, _u0957, handler_)),
    #line 54 "src/distribution/MultivariateNormalInverseGamma.birch"
    _u09632(_u09632) {
  //
}

#line 56 "src/distribution/MultivariateNormalInverseGamma.birch"
birch::type::Integer birch::type::MultivariateNormalInverseGamma::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 56 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("rows", "src/distribution/MultivariateNormalInverseGamma.birch", 56);
  #line 57 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/MultivariateNormalInverseGamma.birch"
  return this_()->_u0957->rows(handler_);
}

#line 60 "src/distribution/MultivariateNormalInverseGamma.birch"
birch::type::Boolean birch::type::MultivariateNormalInverseGamma::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("supportsLazy", "src/distribution/MultivariateNormalInverseGamma.birch", 60);
  #line 61 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/MultivariateNormalInverseGamma.birch"
  return true;
}

#line 64 "src/distribution/MultivariateNormalInverseGamma.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateNormalInverseGamma::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("simulate", "src/distribution/MultivariateNormalInverseGamma.birch", 64);
  #line 65 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/MultivariateNormalInverseGamma.birch"
  return birch::simulate_multivariate_normal_inverse_gamma(this_()->_u0957->value(handler_), this_()->_u0923->value(handler_), this_()->_u0945->value(handler_), birch::gamma_to_beta(this_()->_u0947->value(handler_), this_()->_u0957->value(handler_), this_()->_u0923->value(handler_), handler_), handler_);
}

#line 69 "src/distribution/MultivariateNormalInverseGamma.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::MultivariateNormalInverseGamma::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("simulateLazy", "src/distribution/MultivariateNormalInverseGamma.birch", 69);
  #line 70 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(70);
  #line 70 "src/distribution/MultivariateNormalInverseGamma.birch"
  return birch::simulate_multivariate_normal_inverse_gamma(this_()->_u0957->get(handler_), this_()->_u0923->get(handler_), this_()->_u0945->get(handler_), birch::gamma_to_beta(this_()->_u0947->get(handler_), this_()->_u0957->get(handler_), this_()->_u0923->get(handler_), handler_), handler_);
}

#line 74 "src/distribution/MultivariateNormalInverseGamma.birch"
birch::type::Real birch::type::MultivariateNormalInverseGamma::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 74 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("logpdf", "src/distribution/MultivariateNormalInverseGamma.birch", 74);
  #line 75 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(75);
  #line 75 "src/distribution/MultivariateNormalInverseGamma.birch"
  return birch::logpdf_multivariate_normal_inverse_gamma(x, this_()->_u0957->value(handler_), this_()->_u0923->value(handler_), this_()->_u0945->value(handler_), birch::gamma_to_beta(this_()->_u0947->value(handler_), this_()->_u0957->value(handler_), this_()->_u0923->value(handler_), handler_), handler_);
}

#line 79 "src/distribution/MultivariateNormalInverseGamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::MultivariateNormalInverseGamma::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 79 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("logpdfLazy", "src/distribution/MultivariateNormalInverseGamma.birch", 79);
  #line 80 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(80);
  #line 80 "src/distribution/MultivariateNormalInverseGamma.birch"
  return birch::logpdf_lazy_multivariate_normal_inverse_gamma(x, this_()->_u0957, this_()->_u0923, this_()->_u0945, birch::gamma_to_beta(this_()->_u0947, this_()->_u0957, this_()->_u0923, handler_), handler_);
}

#line 84 "src/distribution/MultivariateNormalInverseGamma.birch"
void birch::type::MultivariateNormalInverseGamma::update(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 84 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("update", "src/distribution/MultivariateNormalInverseGamma.birch", 84);
  #line 85 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(85);
  #line 85 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch::tie(this_()->_u09632->_u0945, this_()->_u09632->_u0946) = birch::box(birch::update_multivariate_normal_inverse_gamma(x, this_()->_u0957->value(handler_), this_()->_u0923->value(handler_), this_()->_u0945->value(handler_), birch::gamma_to_beta(this_()->_u0947->value(handler_), this_()->_u0957->value(handler_), this_()->_u0923->value(handler_), handler_), handler_), handler_);
}

#line 89 "src/distribution/MultivariateNormalInverseGamma.birch"
void birch::type::MultivariateNormalInverseGamma::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 89 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("updateLazy", "src/distribution/MultivariateNormalInverseGamma.birch", 89);
  #line 90 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(90);
  #line 90 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch::tie(this_()->_u09632->_u0945, this_()->_u09632->_u0946) = birch::update_lazy_multivariate_normal_inverse_gamma(x, this_()->_u0957, this_()->_u0923, this_()->_u0945, birch::gamma_to_beta(this_()->_u0947, this_()->_u0957, this_()->_u0923, handler_), handler_);
}

#line 94 "src/distribution/MultivariateNormalInverseGamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>> birch::type::MultivariateNormalInverseGamma::graftMultivariateNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 94 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("graftMultivariateNormalInverseGamma", "src/distribution/MultivariateNormalInverseGamma.birch", 94);
  #line 96 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(96);
  #line 96 "src/distribution/MultivariateNormalInverseGamma.birch"
  this_()->prune(handler_);
  #line 97 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(97);
  #line 97 "src/distribution/MultivariateNormalInverseGamma.birch"
  if (this_()->_u09632 == compare) {
    #line 98 "src/distribution/MultivariateNormalInverseGamma.birch"
    libbirch_line_(98);
    #line 98 "src/distribution/MultivariateNormalInverseGamma.birch"
    return shared_from_this_();
  } else {
    #line 100 "src/distribution/MultivariateNormalInverseGamma.birch"
    libbirch_line_(100);
    #line 100 "src/distribution/MultivariateNormalInverseGamma.birch"
    return libbirch::nil;
  }
}

#line 104 "src/distribution/MultivariateNormalInverseGamma.birch"
void birch::type::MultivariateNormalInverseGamma::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 104 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("link", "src/distribution/MultivariateNormalInverseGamma.birch", 104);
  #line 105 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(105);
  #line 105 "src/distribution/MultivariateNormalInverseGamma.birch"
  this_()->_u09632->setChild(shared_from_this_(), handler_);
}

#line 108 "src/distribution/MultivariateNormalInverseGamma.birch"
void birch::type::MultivariateNormalInverseGamma::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 108 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("unlink", "src/distribution/MultivariateNormalInverseGamma.birch", 108);
  #line 109 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(109);
  #line 109 "src/distribution/MultivariateNormalInverseGamma.birch"
  this_()->_u09632->releaseChild(shared_from_this_(), handler_);
}

#line 112 "src/distribution/MultivariateNormalInverseGamma.birch"
void birch::type::MultivariateNormalInverseGamma::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 112 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("write", "src/distribution/MultivariateNormalInverseGamma.birch", 112);
  #line 113 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(113);
  #line 113 "src/distribution/MultivariateNormalInverseGamma.birch"
  this_()->prune(handler_);
  #line 114 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(114);
  #line 114 "src/distribution/MultivariateNormalInverseGamma.birch"
  buffer->set(birch::type::String("class"), birch::type::String("MultivariateNormalInverseGamma"), handler_);
  #line 115 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(115);
  #line 115 "src/distribution/MultivariateNormalInverseGamma.birch"
  buffer->set(birch::type::String("μ"), birch::solve(this_()->_u0923->value(handler_), this_()->_u0957->value(handler_), handler_), handler_);
  #line 116 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(116);
  #line 116 "src/distribution/MultivariateNormalInverseGamma.birch"
  buffer->set(birch::type::String("Σ"), birch::inv(this_()->_u0923->value(handler_), handler_), handler_);
  #line 117 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(117);
  #line 117 "src/distribution/MultivariateNormalInverseGamma.birch"
  buffer->set(birch::type::String("α"), this_()->_u0945->value(handler_), handler_);
  #line 118 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(118);
  #line 118 "src/distribution/MultivariateNormalInverseGamma.birch"
  buffer->set(birch::type::String("β"), birch::gamma_to_beta(this_()->_u0947->value(handler_), this_()->_u0957->value(handler_), this_()->_u0923->value(handler_), handler_), handler_);
}

#line 122 "src/distribution/MultivariateNormalInverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>> birch::MultivariateNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 122 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("MultivariateNormalInverseGamma", "src/distribution/MultivariateNormalInverseGamma.birch", 122);
  #line 124 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(124);
  #line 124 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>> m(_u0956, _u0931, _u09632);
  #line 125 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(125);
  #line 125 "src/distribution/MultivariateNormalInverseGamma.birch"
  m->link(handler_);
  #line 126 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(126);
  #line 126 "src/distribution/MultivariateNormalInverseGamma.birch"
  return m;
}

#line 133 "src/distribution/MultivariateNormalInverseGamma.birch"
birch::type::Real birch::gamma_to_beta(const birch::type::Real& _u0947, const libbirch::DefaultArray<birch::type::Real,1>& _u0957, const birch::type::LLT& _u0923, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 133 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("gamma_to_beta", "src/distribution/MultivariateNormalInverseGamma.birch", 133);
  #line 134 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(134);
  #line 134 "src/distribution/MultivariateNormalInverseGamma.birch"
  return _u0947 - 0.5 * birch::dot(_u0957, birch::solve(_u0923, _u0957, handler_), handler_);
}

#line 141 "src/distribution/MultivariateNormalInverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::gamma_to_beta(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0947, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0923, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 141 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("gamma_to_beta", "src/distribution/MultivariateNormalInverseGamma.birch", 141);
  #line 143 "src/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(143);
  #line 143 "src/distribution/MultivariateNormalInverseGamma.birch"
  return _u0947 - 0.5 * birch::dot(_u0957, birch::solve(_u0923, _u0957, handler_), handler_);
}

#line 4 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::MultivariateNormalInverseGammaMultivariateGaussian::MultivariateNormalInverseGammaMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
    super_type_(),
    #line 9 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
    _u0956(_u0956) {
  //
}

#line 11 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::Integer birch::type::MultivariateNormalInverseGammaMultivariateGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("rows", "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 11);
  #line 12 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(12);
  #line 12 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  return this_()->_u0956->rows(handler_);
}

#line 15 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::Boolean birch::type::MultivariateNormalInverseGammaMultivariateGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 15);
  #line 16 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  return true;
}

#line 19 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateNormalInverseGammaMultivariateGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("simulate", "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 19);
  #line 20 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(20);
  #line 20 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  return birch::simulate_multivariate_normal_inverse_gamma_multivariate_gaussian(this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_);
}

#line 24 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::MultivariateNormalInverseGammaMultivariateGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 24);
  #line 25 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  return birch::simulate_multivariate_normal_inverse_gamma_multivariate_gaussian(this_()->_u0956->_u0957->get(handler_), this_()->_u0956->_u0923->get(handler_), this_()->_u0956->_u0945->get(handler_), this_()->_u0956->_u0947->get(handler_), handler_);
}

#line 29 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::Real birch::type::MultivariateNormalInverseGammaMultivariateGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 29);
  #line 30 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  return birch::logpdf_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_);
}

#line 34 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::MultivariateNormalInverseGammaMultivariateGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 34);
  #line 35 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  return birch::logpdf_lazy_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->_u0956->_u0945, this_()->_u0956->_u0947, handler_);
}

#line 39 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::MultivariateNormalInverseGammaMultivariateGaussian::update(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("update", "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 39);
  #line 40 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->_u0956->_u0945, this_()->_u0956->_u0947) = birch::box(birch::update_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_), handler_);
}

#line 44 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::MultivariateNormalInverseGammaMultivariateGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 44);
  #line 45 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->_u0956->_u0945, this_()->_u0956->_u0947) = birch::update_lazy_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->_u0956->_u0945, this_()->_u0956->_u0947, handler_);
}

#line 49 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::MultivariateNormalInverseGammaMultivariateGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("link", "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 49);
  #line 50 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  this_()->_u0956->setChild(shared_from_this_(), handler_);
}

#line 53 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::MultivariateNormalInverseGammaMultivariateGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("unlink", "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 53);
  #line 54 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  this_()->_u0956->releaseChild(shared_from_this_(), handler_);
}

#line 58 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGammaMultivariateGaussian>> birch::MultivariateNormalInverseGammaMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("MultivariateNormalInverseGammaMultivariateGaussian", "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 58);
  #line 61 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGammaMultivariateGaussian>> m(_u0956);
  #line 62 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  m->link(handler_);
  #line 63 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(63);
  #line 63 "src/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  return m;
}

#line 1 "src/distribution/NegativeBinomial.birch"
birch::type::NegativeBinomial::NegativeBinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/distribution/NegativeBinomial.birch"
    super_type_(),
    #line 9 "src/distribution/NegativeBinomial.birch"
    k(k),
    #line 14 "src/distribution/NegativeBinomial.birch"
    _u0961(_u0961) {
  //
}

#line 16 "src/distribution/NegativeBinomial.birch"
birch::type::Boolean birch::type::NegativeBinomial::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("supportsLazy", "src/distribution/NegativeBinomial.birch", 16);
  #line 17 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/NegativeBinomial.birch"
  return true;
}

#line 20 "src/distribution/NegativeBinomial.birch"
birch::type::Integer birch::type::NegativeBinomial::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("simulate", "src/distribution/NegativeBinomial.birch", 20);
  #line 21 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/NegativeBinomial.birch"
  if (this_()->value.query()) {
    #line 22 "src/distribution/NegativeBinomial.birch"
    libbirch_line_(22);
    #line 22 "src/distribution/NegativeBinomial.birch"
    return this_()->value.get();
  } else {
    #line 24 "src/distribution/NegativeBinomial.birch"
    libbirch_line_(24);
    #line 24 "src/distribution/NegativeBinomial.birch"
    return birch::simulate_negative_binomial(this_()->k->value(handler_), this_()->_u0961->value(handler_), handler_);
  }
}

#line 28 "src/distribution/NegativeBinomial.birch"
libbirch::Optional<birch::type::Integer> birch::type::NegativeBinomial::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("simulateLazy", "src/distribution/NegativeBinomial.birch", 28);
  #line 29 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/NegativeBinomial.birch"
  if (this_()->value.query()) {
    #line 30 "src/distribution/NegativeBinomial.birch"
    libbirch_line_(30);
    #line 30 "src/distribution/NegativeBinomial.birch"
    return this_()->value.get();
  } else {
    #line 32 "src/distribution/NegativeBinomial.birch"
    libbirch_line_(32);
    #line 32 "src/distribution/NegativeBinomial.birch"
    return birch::simulate_negative_binomial(this_()->k->get(handler_), this_()->_u0961->get(handler_), handler_);
  }
}

#line 36 "src/distribution/NegativeBinomial.birch"
birch::type::Real birch::type::NegativeBinomial::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("logpdf", "src/distribution/NegativeBinomial.birch", 36);
  #line 37 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/NegativeBinomial.birch"
  return birch::logpdf_negative_binomial(x, this_()->k->value(handler_), this_()->_u0961->value(handler_), handler_);
}

#line 40 "src/distribution/NegativeBinomial.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::NegativeBinomial::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("logpdfLazy", "src/distribution/NegativeBinomial.birch", 40);
  #line 41 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/NegativeBinomial.birch"
  return birch::logpdf_lazy_negative_binomial(x, this_()->k, this_()->_u0961, handler_);
}

#line 44 "src/distribution/NegativeBinomial.birch"
libbirch::Optional<birch::type::Real> birch::type::NegativeBinomial::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("cdf", "src/distribution/NegativeBinomial.birch", 44);
  #line 45 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/NegativeBinomial.birch"
  return birch::cdf_negative_binomial(x, this_()->k->value(handler_), this_()->_u0961->value(handler_), handler_);
}

#line 48 "src/distribution/NegativeBinomial.birch"
libbirch::Optional<birch::type::Integer> birch::type::NegativeBinomial::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("quantile", "src/distribution/NegativeBinomial.birch", 48);
  #line 49 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/NegativeBinomial.birch"
  return birch::quantile_negative_binomial(P, this_()->k->value(handler_), this_()->_u0961->value(handler_), handler_);
}

#line 52 "src/distribution/NegativeBinomial.birch"
libbirch::Optional<birch::type::Integer> birch::type::NegativeBinomial::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("lower", "src/distribution/NegativeBinomial.birch", 52);
  #line 53 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/NegativeBinomial.birch"
  return birch::type::Integer(0);
}

#line 56 "src/distribution/NegativeBinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> birch::type::NegativeBinomial::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 56 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("graft", "src/distribution/NegativeBinomial.birch", 56);
  #line 57 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/NegativeBinomial.birch"
  this_()->prune(handler_);
  #line 58 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(58);
  #line 58 "src/distribution/NegativeBinomial.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Beta>>> _u09611;
  #line 59 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(59);
  #line 59 "src/distribution/NegativeBinomial.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> r = shared_from_this_();
  #line 62 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/NegativeBinomial.birch"
  if ((_u09611 = this_()->_u0961->graftBeta(handler_)).query()) {
    #line 63 "src/distribution/NegativeBinomial.birch"
    libbirch_line_(63);
    #line 63 "src/distribution/NegativeBinomial.birch"
    r = birch::BetaNegativeBinomial(this_()->k, _u09611.get(), handler_);
  }
  #line 66 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/NegativeBinomial.birch"
  return r;
}

#line 69 "src/distribution/NegativeBinomial.birch"
void birch::type::NegativeBinomial::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("write", "src/distribution/NegativeBinomial.birch", 69);
  #line 70 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(70);
  #line 70 "src/distribution/NegativeBinomial.birch"
  this_()->prune(handler_);
  #line 71 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(71);
  #line 71 "src/distribution/NegativeBinomial.birch"
  buffer->set(birch::type::String("class"), birch::type::String("NegativeBinomial"), handler_);
  #line 72 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(72);
  #line 72 "src/distribution/NegativeBinomial.birch"
  buffer->set(birch::type::String("k"), this_()->k, handler_);
  #line 73 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(73);
  #line 73 "src/distribution/NegativeBinomial.birch"
  buffer->set(birch::type::String("ρ"), this_()->_u0961, handler_);
}

#line 80 "src/distribution/NegativeBinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::NegativeBinomial>> birch::NegativeBinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 80 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("NegativeBinomial", "src/distribution/NegativeBinomial.birch", 80);
  #line 82 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(82);
  #line 82 "src/distribution/NegativeBinomial.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::NegativeBinomial>>>(k, _u0961, handler_);
}

#line 88 "src/distribution/NegativeBinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::NegativeBinomial>> birch::NegativeBinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& k, const birch::type::Real& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 88 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("NegativeBinomial", "src/distribution/NegativeBinomial.birch", 88);
  #line 89 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(89);
  #line 89 "src/distribution/NegativeBinomial.birch"
  return birch::NegativeBinomial(k, birch::box(_u0961, handler_), handler_);
}

#line 95 "src/distribution/NegativeBinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::NegativeBinomial>> birch::NegativeBinomial(const birch::type::Integer& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("NegativeBinomial", "src/distribution/NegativeBinomial.birch", 95);
  #line 96 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(96);
  #line 96 "src/distribution/NegativeBinomial.birch"
  return birch::NegativeBinomial(birch::box(k, handler_), _u0961, handler_);
}

#line 102 "src/distribution/NegativeBinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::NegativeBinomial>> birch::NegativeBinomial(const birch::type::Integer& k, const birch::type::Real& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 102 "src/distribution/NegativeBinomial.birch"
  libbirch_function_("NegativeBinomial", "src/distribution/NegativeBinomial.birch", 102);
  #line 103 "src/distribution/NegativeBinomial.birch"
  libbirch_line_(103);
  #line 103 "src/distribution/NegativeBinomial.birch"
  return birch::NegativeBinomial(birch::box(k, handler_), birch::box(_u0961, handler_), handler_);
}

#line 28 "src/distribution/NormalInverseGamma.birch"
birch::type::NormalInverseGamma::NormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a2, const libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 28 "src/distribution/NormalInverseGamma.birch"
    super_type_(),
    #line 33 "src/distribution/NormalInverseGamma.birch"
    _u0956(_u0956),
    #line 38 "src/distribution/NormalInverseGamma.birch"
    _u0955(1.0 / a2),
    #line 43 "src/distribution/NormalInverseGamma.birch"
    _u09632(_u09632) {
  //
}

#line 45 "src/distribution/NormalInverseGamma.birch"
birch::type::Boolean birch::type::NormalInverseGamma::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("supportsLazy", "src/distribution/NormalInverseGamma.birch", 45);
  #line 46 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/NormalInverseGamma.birch"
  return true;
}

#line 49 "src/distribution/NormalInverseGamma.birch"
birch::type::Real birch::type::NormalInverseGamma::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("simulate", "src/distribution/NormalInverseGamma.birch", 49);
  #line 50 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/NormalInverseGamma.birch"
  return birch::simulate_normal_inverse_gamma(this_()->_u0956->value(handler_), 1.0 / this_()->_u0955->value(handler_), this_()->_u09632->_u0945->value(handler_), this_()->_u09632->_u0946->value(handler_), handler_);
}

#line 53 "src/distribution/NormalInverseGamma.birch"
libbirch::Optional<birch::type::Real> birch::type::NormalInverseGamma::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("simulateLazy", "src/distribution/NormalInverseGamma.birch", 53);
  #line 54 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/NormalInverseGamma.birch"
  return birch::simulate_normal_inverse_gamma(this_()->_u0956->get(handler_), 1.0 / this_()->_u0955->get(handler_), this_()->_u09632->_u0945->get(handler_), this_()->_u09632->_u0946->get(handler_), handler_);
}

#line 57 "src/distribution/NormalInverseGamma.birch"
birch::type::Real birch::type::NormalInverseGamma::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 57 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("logpdf", "src/distribution/NormalInverseGamma.birch", 57);
  #line 58 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(58);
  #line 58 "src/distribution/NormalInverseGamma.birch"
  return birch::logpdf_normal_inverse_gamma(x, this_()->_u0956->value(handler_), 1.0 / this_()->_u0955->value(handler_), this_()->_u09632->_u0945->value(handler_), this_()->_u09632->_u0946->value(handler_), handler_);
}

#line 61 "src/distribution/NormalInverseGamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::NormalInverseGamma::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("logpdfLazy", "src/distribution/NormalInverseGamma.birch", 61);
  #line 62 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/NormalInverseGamma.birch"
  return birch::logpdf_lazy_normal_inverse_gamma(x, this_()->_u0956, 1.0 / this_()->_u0955, this_()->_u09632->_u0945, this_()->_u09632->_u0946, handler_);
}

#line 65 "src/distribution/NormalInverseGamma.birch"
void birch::type::NormalInverseGamma::update(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("update", "src/distribution/NormalInverseGamma.birch", 65);
  #line 66 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/NormalInverseGamma.birch"
  libbirch::tie(this_()->_u09632->_u0945, this_()->_u09632->_u0946) = birch::box(birch::update_normal_inverse_gamma(x, this_()->_u0956->value(handler_), this_()->_u0955->value(handler_), this_()->_u09632->_u0945->value(handler_), this_()->_u09632->_u0946->value(handler_), handler_), handler_);
}

#line 69 "src/distribution/NormalInverseGamma.birch"
void birch::type::NormalInverseGamma::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("updateLazy", "src/distribution/NormalInverseGamma.birch", 69);
  #line 70 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(70);
  #line 70 "src/distribution/NormalInverseGamma.birch"
  libbirch::tie(this_()->_u09632->_u0945, this_()->_u09632->_u0946) = birch::update_lazy_normal_inverse_gamma(x, this_()->_u0956, this_()->_u0955, this_()->_u09632->_u0945, this_()->_u09632->_u0946, handler_);
}

#line 73 "src/distribution/NormalInverseGamma.birch"
libbirch::Optional<birch::type::Real> birch::type::NormalInverseGamma::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 73 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("cdf", "src/distribution/NormalInverseGamma.birch", 73);
  #line 74 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(74);
  #line 74 "src/distribution/NormalInverseGamma.birch"
  return birch::cdf_normal_inverse_gamma(x, this_()->_u0956->value(handler_), 1.0 / this_()->_u0955->value(handler_), this_()->_u09632->_u0945->value(handler_), this_()->_u09632->_u0946->value(handler_), handler_);
}

#line 77 "src/distribution/NormalInverseGamma.birch"
libbirch::Optional<birch::type::Real> birch::type::NormalInverseGamma::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 77 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("quantile", "src/distribution/NormalInverseGamma.birch", 77);
  #line 78 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(78);
  #line 78 "src/distribution/NormalInverseGamma.birch"
  return birch::quantile_normal_inverse_gamma(P, this_()->_u0956->value(handler_), 1.0 / this_()->_u0955->value(handler_), this_()->_u09632->_u0945->value(handler_), this_()->_u09632->_u0946->value(handler_), handler_);
}

#line 81 "src/distribution/NormalInverseGamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>> birch::type::NormalInverseGamma::graftNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("graftNormalInverseGamma", "src/distribution/NormalInverseGamma.birch", 81);
  #line 83 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(83);
  #line 83 "src/distribution/NormalInverseGamma.birch"
  this_()->prune(handler_);
  #line 84 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(84);
  #line 84 "src/distribution/NormalInverseGamma.birch"
  if (this_()->_u09632 == compare) {
    #line 85 "src/distribution/NormalInverseGamma.birch"
    libbirch_line_(85);
    #line 85 "src/distribution/NormalInverseGamma.birch"
    return shared_from_this_();
  } else {
    #line 87 "src/distribution/NormalInverseGamma.birch"
    libbirch_line_(87);
    #line 87 "src/distribution/NormalInverseGamma.birch"
    return libbirch::nil;
  }
}

#line 91 "src/distribution/NormalInverseGamma.birch"
void birch::type::NormalInverseGamma::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 91 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("link", "src/distribution/NormalInverseGamma.birch", 91);
  #line 92 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(92);
  #line 92 "src/distribution/NormalInverseGamma.birch"
  this_()->_u09632->setChild(shared_from_this_(), handler_);
}

#line 95 "src/distribution/NormalInverseGamma.birch"
void birch::type::NormalInverseGamma::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("unlink", "src/distribution/NormalInverseGamma.birch", 95);
  #line 96 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(96);
  #line 96 "src/distribution/NormalInverseGamma.birch"
  this_()->_u09632->releaseChild(shared_from_this_(), handler_);
}

#line 99 "src/distribution/NormalInverseGamma.birch"
void birch::type::NormalInverseGamma::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 99 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("write", "src/distribution/NormalInverseGamma.birch", 99);
  #line 100 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(100);
  #line 100 "src/distribution/NormalInverseGamma.birch"
  this_()->prune(handler_);
  #line 101 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(101);
  #line 101 "src/distribution/NormalInverseGamma.birch"
  buffer->set(birch::type::String("class"), birch::type::String("NormalInverseGamma"), handler_);
  #line 102 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(102);
  #line 102 "src/distribution/NormalInverseGamma.birch"
  buffer->set(birch::type::String("μ"), this_()->_u0956, handler_);
  #line 103 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(103);
  #line 103 "src/distribution/NormalInverseGamma.birch"
  buffer->set(birch::type::String("a2"), 1.0 / this_()->_u0955, handler_);
  #line 104 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(104);
  #line 104 "src/distribution/NormalInverseGamma.birch"
  buffer->set(birch::type::String("α"), this_()->_u09632->_u0945, handler_);
  #line 105 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(105);
  #line 105 "src/distribution/NormalInverseGamma.birch"
  buffer->set(birch::type::String("β"), this_()->_u09632->_u0946, handler_);
}

#line 109 "src/distribution/NormalInverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>> birch::NormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a2, const libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 109 "src/distribution/NormalInverseGamma.birch"
  libbirch_function_("NormalInverseGamma", "src/distribution/NormalInverseGamma.birch", 109);
  #line 111 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(111);
  #line 111 "src/distribution/NormalInverseGamma.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>> m(_u0956, a2, _u09632);
  #line 112 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(112);
  #line 112 "src/distribution/NormalInverseGamma.birch"
  m->link(handler_);
  #line 113 "src/distribution/NormalInverseGamma.birch"
  libbirch_line_(113);
  #line 113 "src/distribution/NormalInverseGamma.birch"
  return m;
}

#line 4 "src/distribution/NormalInverseGammaGaussian.birch"
birch::type::NormalInverseGammaGaussian::NormalInverseGammaGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/NormalInverseGammaGaussian.birch"
    super_type_(),
    #line 9 "src/distribution/NormalInverseGammaGaussian.birch"
    _u0956(_u0956) {
  //
}

#line 11 "src/distribution/NormalInverseGammaGaussian.birch"
birch::type::Boolean birch::type::NormalInverseGammaGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/NormalInverseGammaGaussian.birch", 11);
  #line 12 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(12);
  #line 12 "src/distribution/NormalInverseGammaGaussian.birch"
  return true;
}

#line 15 "src/distribution/NormalInverseGammaGaussian.birch"
birch::type::Real birch::type::NormalInverseGammaGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("simulate", "src/distribution/NormalInverseGammaGaussian.birch", 15);
  #line 16 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/distribution/NormalInverseGammaGaussian.birch"
  return birch::simulate_normal_inverse_gamma_gaussian(this_()->_u0956->_u0956->value(handler_), 1.0 / this_()->_u0956->_u0955->value(handler_), this_()->_u0956->_u09632->_u0945->value(handler_), this_()->_u0956->_u09632->_u0946->value(handler_), handler_);
}

#line 20 "src/distribution/NormalInverseGammaGaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::NormalInverseGammaGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/NormalInverseGammaGaussian.birch", 20);
  #line 21 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/NormalInverseGammaGaussian.birch"
  return birch::simulate_normal_inverse_gamma_gaussian(this_()->_u0956->_u0956->get(handler_), 1.0 / this_()->_u0956->_u0955->get(handler_), this_()->_u0956->_u09632->_u0945->get(handler_), this_()->_u0956->_u09632->_u0946->get(handler_), handler_);
}

#line 25 "src/distribution/NormalInverseGammaGaussian.birch"
birch::type::Real birch::type::NormalInverseGammaGaussian::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/NormalInverseGammaGaussian.birch", 25);
  #line 26 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/distribution/NormalInverseGammaGaussian.birch"
  return birch::logpdf_normal_inverse_gamma_gaussian(x, this_()->_u0956->_u0956->value(handler_), 1.0 / this_()->_u0956->_u0955->value(handler_), this_()->_u0956->_u09632->_u0945->value(handler_), this_()->_u0956->_u09632->_u0946->value(handler_), handler_);
}

#line 30 "src/distribution/NormalInverseGammaGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::NormalInverseGammaGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/NormalInverseGammaGaussian.birch", 30);
  #line 31 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/NormalInverseGammaGaussian.birch"
  return birch::logpdf_lazy_normal_inverse_gamma_gaussian(x, this_()->_u0956->_u0956, 1.0 / this_()->_u0956->_u0955, this_()->_u0956->_u09632->_u0945, this_()->_u0956->_u09632->_u0946, handler_);
}

#line 35 "src/distribution/NormalInverseGammaGaussian.birch"
void birch::type::NormalInverseGammaGaussian::update(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("update", "src/distribution/NormalInverseGammaGaussian.birch", 35);
  #line 36 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0956, this_()->_u0956->_u0955, this_()->_u0956->_u09632->_u0945, this_()->_u0956->_u09632->_u0946) = birch::box(birch::update_normal_inverse_gamma_gaussian(x, this_()->_u0956->_u0956->value(handler_), this_()->_u0956->_u0955->value(handler_), this_()->_u0956->_u09632->_u0945->value(handler_), this_()->_u0956->_u09632->_u0946->value(handler_), handler_), handler_);
}

#line 40 "src/distribution/NormalInverseGammaGaussian.birch"
void birch::type::NormalInverseGammaGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("updateLazy", "src/distribution/NormalInverseGammaGaussian.birch", 40);
  #line 41 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0956, this_()->_u0956->_u0955, this_()->_u0956->_u09632->_u0945, this_()->_u0956->_u09632->_u0946) = birch::update_lazy_normal_inverse_gamma_gaussian(x, this_()->_u0956->_u0956, this_()->_u0956->_u0955, this_()->_u0956->_u09632->_u0945, this_()->_u0956->_u09632->_u0946, handler_);
}

#line 45 "src/distribution/NormalInverseGammaGaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::NormalInverseGammaGaussian::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("cdf", "src/distribution/NormalInverseGammaGaussian.birch", 45);
  #line 46 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/NormalInverseGammaGaussian.birch"
  return birch::cdf_normal_inverse_gamma_gaussian(x, this_()->_u0956->_u0956->value(handler_), 1.0 / this_()->_u0956->_u0955->value(handler_), this_()->_u0956->_u09632->_u0945->value(handler_), this_()->_u0956->_u09632->_u0946->value(handler_), handler_);
}

#line 50 "src/distribution/NormalInverseGammaGaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::NormalInverseGammaGaussian::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("quantile", "src/distribution/NormalInverseGammaGaussian.birch", 50);
  #line 51 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/NormalInverseGammaGaussian.birch"
  return birch::quantile_normal_inverse_gamma_gaussian(P, this_()->_u0956->_u0956->value(handler_), 1.0 / this_()->_u0956->_u0955->value(handler_), this_()->_u0956->_u09632->_u0945->value(handler_), this_()->_u0956->_u09632->_u0946->value(handler_), handler_);
}

#line 55 "src/distribution/NormalInverseGammaGaussian.birch"
void birch::type::NormalInverseGammaGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 55 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("link", "src/distribution/NormalInverseGammaGaussian.birch", 55);
  #line 56 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/NormalInverseGammaGaussian.birch"
  this_()->_u0956->setChild(shared_from_this_(), handler_);
}

#line 59 "src/distribution/NormalInverseGammaGaussian.birch"
void birch::type::NormalInverseGammaGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("unlink", "src/distribution/NormalInverseGammaGaussian.birch", 59);
  #line 60 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/NormalInverseGammaGaussian.birch"
  this_()->_u0956->releaseChild(shared_from_this_(), handler_);
}

#line 64 "src/distribution/NormalInverseGammaGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGammaGaussian>> birch::NormalInverseGammaGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("NormalInverseGammaGaussian", "src/distribution/NormalInverseGammaGaussian.birch", 64);
  #line 66 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGammaGaussian>> m(_u0956);
  #line 67 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/NormalInverseGammaGaussian.birch"
  m->link(handler_);
  #line 68 "src/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(68);
  #line 68 "src/distribution/NormalInverseGammaGaussian.birch"
  return m;
}

#line 1 "src/distribution/Poisson.birch"
birch::type::Poisson::Poisson(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/distribution/Poisson.birch"
    super_type_(),
    #line 8 "src/distribution/Poisson.birch"
    _u0955(_u0955) {
  //
}

#line 10 "src/distribution/Poisson.birch"
birch::type::Boolean birch::type::Poisson::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/distribution/Poisson.birch"
  libbirch_function_("supportsLazy", "src/distribution/Poisson.birch", 10);
  #line 11 "src/distribution/Poisson.birch"
  libbirch_line_(11);
  #line 11 "src/distribution/Poisson.birch"
  return true;
}

#line 14 "src/distribution/Poisson.birch"
birch::type::Integer birch::type::Poisson::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/distribution/Poisson.birch"
  libbirch_function_("simulate", "src/distribution/Poisson.birch", 14);
  #line 15 "src/distribution/Poisson.birch"
  libbirch_line_(15);
  #line 15 "src/distribution/Poisson.birch"
  if (this_()->value.query()) {
    #line 16 "src/distribution/Poisson.birch"
    libbirch_line_(16);
    #line 16 "src/distribution/Poisson.birch"
    return this_()->value.get();
  } else {
    #line 18 "src/distribution/Poisson.birch"
    libbirch_line_(18);
    #line 18 "src/distribution/Poisson.birch"
    return birch::simulate_poisson(this_()->_u0955->value(handler_), handler_);
  }
}

#line 22 "src/distribution/Poisson.birch"
libbirch::Optional<birch::type::Integer> birch::type::Poisson::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/distribution/Poisson.birch"
  libbirch_function_("simulateLazy", "src/distribution/Poisson.birch", 22);
  #line 23 "src/distribution/Poisson.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/Poisson.birch"
  if (this_()->value.query()) {
    #line 24 "src/distribution/Poisson.birch"
    libbirch_line_(24);
    #line 24 "src/distribution/Poisson.birch"
    return this_()->value.get();
  } else {
    #line 26 "src/distribution/Poisson.birch"
    libbirch_line_(26);
    #line 26 "src/distribution/Poisson.birch"
    return birch::simulate_poisson(this_()->_u0955->get(handler_), handler_);
  }
}

#line 30 "src/distribution/Poisson.birch"
birch::type::Real birch::type::Poisson::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/distribution/Poisson.birch"
  libbirch_function_("logpdf", "src/distribution/Poisson.birch", 30);
  #line 31 "src/distribution/Poisson.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/Poisson.birch"
  return birch::logpdf_poisson(x, this_()->_u0955->value(handler_), handler_);
}

#line 34 "src/distribution/Poisson.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::Poisson::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/distribution/Poisson.birch"
  libbirch_function_("logpdfLazy", "src/distribution/Poisson.birch", 34);
  #line 35 "src/distribution/Poisson.birch"
  libbirch_line_(35);
  #line 35 "src/distribution/Poisson.birch"
  return birch::logpdf_lazy_poisson(x, this_()->_u0955, handler_);
}

#line 38 "src/distribution/Poisson.birch"
libbirch::Optional<birch::type::Real> birch::type::Poisson::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "src/distribution/Poisson.birch"
  libbirch_function_("cdf", "src/distribution/Poisson.birch", 38);
  #line 39 "src/distribution/Poisson.birch"
  libbirch_line_(39);
  #line 39 "src/distribution/Poisson.birch"
  return birch::cdf_poisson(x, this_()->_u0955->value(handler_), handler_);
}

#line 42 "src/distribution/Poisson.birch"
libbirch::Optional<birch::type::Integer> birch::type::Poisson::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/distribution/Poisson.birch"
  libbirch_function_("quantile", "src/distribution/Poisson.birch", 42);
  #line 43 "src/distribution/Poisson.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/Poisson.birch"
  return birch::quantile_poisson(P, this_()->_u0955->value(handler_), handler_);
}

#line 46 "src/distribution/Poisson.birch"
libbirch::Optional<birch::type::Integer> birch::type::Poisson::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/distribution/Poisson.birch"
  libbirch_function_("lower", "src/distribution/Poisson.birch", 46);
  #line 47 "src/distribution/Poisson.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/Poisson.birch"
  return birch::type::Integer(0);
}

#line 50 "src/distribution/Poisson.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> birch::type::Poisson::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "src/distribution/Poisson.birch"
  libbirch_function_("graft", "src/distribution/Poisson.birch", 50);
  #line 51 "src/distribution/Poisson.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/Poisson.birch"
  this_()->prune(handler_);
  #line 52 "src/distribution/Poisson.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/Poisson.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>>>>> m1;
  #line 53 "src/distribution/Poisson.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/Poisson.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>> m2;
  #line 54 "src/distribution/Poisson.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/Poisson.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> r = shared_from_this_();
  #line 57 "src/distribution/Poisson.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/Poisson.birch"
  if ((m1 = this_()->_u0955->graftScaledGamma(handler_)).query()) {
    #line 58 "src/distribution/Poisson.birch"
    libbirch_line_(58);
    #line 58 "src/distribution/Poisson.birch"
    r = birch::ScaledGammaPoisson(m1.get()->a, m1.get()->x, handler_);
  } else {
    #line 59 "src/distribution/Poisson.birch"
    libbirch_line_(59);
    #line 59 "src/distribution/Poisson.birch"
    if ((m2 = this_()->_u0955->graftGamma(handler_)).query()) {
      #line 60 "src/distribution/Poisson.birch"
      libbirch_line_(60);
      #line 60 "src/distribution/Poisson.birch"
      r = birch::GammaPoisson(m2.get(), handler_);
    }
  }
  #line 63 "src/distribution/Poisson.birch"
  libbirch_line_(63);
  #line 63 "src/distribution/Poisson.birch"
  return r;
}

#line 66 "src/distribution/Poisson.birch"
void birch::type::Poisson::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "src/distribution/Poisson.birch"
  libbirch_function_("write", "src/distribution/Poisson.birch", 66);
  #line 67 "src/distribution/Poisson.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/Poisson.birch"
  this_()->prune(handler_);
  #line 68 "src/distribution/Poisson.birch"
  libbirch_line_(68);
  #line 68 "src/distribution/Poisson.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Poisson"), handler_);
  #line 69 "src/distribution/Poisson.birch"
  libbirch_line_(69);
  #line 69 "src/distribution/Poisson.birch"
  buffer->set(birch::type::String("λ"), this_()->_u0955->value(handler_), handler_);
}

#line 76 "src/distribution/Poisson.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Poisson>> birch::Poisson(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "src/distribution/Poisson.birch"
  libbirch_function_("Poisson", "src/distribution/Poisson.birch", 76);
  #line 77 "src/distribution/Poisson.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/Poisson.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Poisson>>>(_u0955, handler_);
}

#line 83 "src/distribution/Poisson.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Poisson>> birch::Poisson(const birch::type::Real& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 83 "src/distribution/Poisson.birch"
  libbirch_function_("Poisson", "src/distribution/Poisson.birch", 83);
  #line 84 "src/distribution/Poisson.birch"
  libbirch_line_(84);
  #line 84 "src/distribution/Poisson.birch"
  return birch::Poisson(birch::box(_u0955, handler_), handler_);
}

#line 8 "src/distribution/Restaurant.birch"
birch::type::Restaurant::Restaurant(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 8 "src/distribution/Restaurant.birch"
    super_type_(),
    #line 13 "src/distribution/Restaurant.birch"
    _u0945(_u0945),
    #line 18 "src/distribution/Restaurant.birch"
    _u0952(_u0952),
    #line 23 "src/distribution/Restaurant.birch"
    n(),
    #line 28 "src/distribution/Restaurant.birch"
    K(birch::type::Integer(0)),
    #line 33 "src/distribution/Restaurant.birch"
    N(birch::type::Integer(0)) {
  //
}

#line 35 "src/distribution/Restaurant.birch"
birch::type::Boolean birch::type::Restaurant::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "src/distribution/Restaurant.birch"
  libbirch_function_("supportsLazy", "src/distribution/Restaurant.birch", 35);
  #line 36 "src/distribution/Restaurant.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/Restaurant.birch"
  return false;
}

#line 39 "src/distribution/Restaurant.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::Restaurant::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/distribution/Restaurant.birch"
  libbirch_function_("simulate", "src/distribution/Restaurant.birch", 39);
  #line 40 "src/distribution/Restaurant.birch"
  libbirch_line_(40);
  #line 40 "src/distribution/Restaurant.birch"
  libbirch_assert_(false);
  #line 41 "src/distribution/Restaurant.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/Restaurant.birch"
  return birch::vector(0.0, birch::type::Integer(0), handler_);
}

#line 44 "src/distribution/Restaurant.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::Restaurant::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/distribution/Restaurant.birch"
  libbirch_function_("simulateLazy", "src/distribution/Restaurant.birch", 44);
  #line 45 "src/distribution/Restaurant.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/Restaurant.birch"
  libbirch_assert_(false);
  #line 46 "src/distribution/Restaurant.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/Restaurant.birch"
  return birch::vector(0.0, birch::type::Integer(0), handler_);
}

#line 49 "src/distribution/Restaurant.birch"
birch::type::Real birch::type::Restaurant::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/distribution/Restaurant.birch"
  libbirch_function_("logpdf", "src/distribution/Restaurant.birch", 49);
  #line 50 "src/distribution/Restaurant.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/Restaurant.birch"
  libbirch_assert_(false);
  #line 51 "src/distribution/Restaurant.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/Restaurant.birch"
  return 0.0;
}

#line 54 "src/distribution/Restaurant.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::Restaurant::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "src/distribution/Restaurant.birch"
  libbirch_function_("logpdfLazy", "src/distribution/Restaurant.birch", 54);
  #line 55 "src/distribution/Restaurant.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/Restaurant.birch"
  libbirch_assert_(false);
  #line 56 "src/distribution/Restaurant.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/Restaurant.birch"
  return birch::box(0.0, handler_);
}

#line 59 "src/distribution/Restaurant.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Restaurant>>> birch::type::Restaurant::graftRestaurant(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/distribution/Restaurant.birch"
  libbirch_function_("graftRestaurant", "src/distribution/Restaurant.birch", 59);
  #line 60 "src/distribution/Restaurant.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/Restaurant.birch"
  this_()->prune(handler_);
  #line 61 "src/distribution/Restaurant.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/Restaurant.birch"
  return shared_from_this_();
}

#line 64 "src/distribution/Restaurant.birch"
void birch::type::Restaurant::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "src/distribution/Restaurant.birch"
  libbirch_function_("write", "src/distribution/Restaurant.birch", 64);
  #line 65 "src/distribution/Restaurant.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/Restaurant.birch"
  this_()->prune(handler_);
  #line 66 "src/distribution/Restaurant.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/Restaurant.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Restaurant"), handler_);
  #line 67 "src/distribution/Restaurant.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/Restaurant.birch"
  buffer->set(birch::type::String("α"), this_()->_u0945, handler_);
  #line 68 "src/distribution/Restaurant.birch"
  libbirch_line_(68);
  #line 68 "src/distribution/Restaurant.birch"
  buffer->set(birch::type::String("θ"), this_()->_u0952, handler_);
  #line 69 "src/distribution/Restaurant.birch"
  libbirch_line_(69);
  #line 69 "src/distribution/Restaurant.birch"
  buffer->set(birch::type::String("n"), this_()->n, handler_);
}

#line 76 "src/distribution/Restaurant.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Restaurant>> birch::Restaurant(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "src/distribution/Restaurant.birch"
  libbirch_function_("Restaurant", "src/distribution/Restaurant.birch", 76);
  #line 77 "src/distribution/Restaurant.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/Restaurant.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Restaurant>>>(_u0945, _u0952, handler_);
}

#line 83 "src/distribution/Restaurant.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Restaurant>> birch::Restaurant(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const birch::type::Real& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 83 "src/distribution/Restaurant.birch"
  libbirch_function_("Restaurant", "src/distribution/Restaurant.birch", 83);
  #line 84 "src/distribution/Restaurant.birch"
  libbirch_line_(84);
  #line 84 "src/distribution/Restaurant.birch"
  return birch::Restaurant(_u0945, birch::box(_u0952, handler_), handler_);
}

#line 90 "src/distribution/Restaurant.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Restaurant>> birch::Restaurant(const birch::type::Real& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 90 "src/distribution/Restaurant.birch"
  libbirch_function_("Restaurant", "src/distribution/Restaurant.birch", 90);
  #line 91 "src/distribution/Restaurant.birch"
  libbirch_line_(91);
  #line 91 "src/distribution/Restaurant.birch"
  return birch::Restaurant(birch::box(_u0945, handler_), _u0952, handler_);
}

#line 97 "src/distribution/Restaurant.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Restaurant>> birch::Restaurant(const birch::type::Real& _u0945, const birch::type::Real& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 97 "src/distribution/Restaurant.birch"
  libbirch_function_("Restaurant", "src/distribution/Restaurant.birch", 97);
  #line 98 "src/distribution/Restaurant.birch"
  libbirch_line_(98);
  #line 98 "src/distribution/Restaurant.birch"
  return birch::Restaurant(birch::box(_u0945, handler_), birch::box(_u0952, handler_), handler_);
}

#line 4 "src/distribution/RestaurantCategorical.birch"
birch::type::RestaurantCategorical::RestaurantCategorical(const libbirch::Lazy<libbirch::Shared<birch::type::Restaurant>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/RestaurantCategorical.birch"
    super_type_(),
    #line 8 "src/distribution/RestaurantCategorical.birch"
    _u0961(_u0961) {
  //
}

#line 10 "src/distribution/RestaurantCategorical.birch"
birch::type::Boolean birch::type::RestaurantCategorical::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/distribution/RestaurantCategorical.birch"
  libbirch_function_("supportsLazy", "src/distribution/RestaurantCategorical.birch", 10);
  #line 11 "src/distribution/RestaurantCategorical.birch"
  libbirch_line_(11);
  #line 11 "src/distribution/RestaurantCategorical.birch"
  return false;
}

#line 14 "src/distribution/RestaurantCategorical.birch"
birch::type::Integer birch::type::RestaurantCategorical::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/distribution/RestaurantCategorical.birch"
  libbirch_function_("simulate", "src/distribution/RestaurantCategorical.birch", 14);
  #line 15 "src/distribution/RestaurantCategorical.birch"
  libbirch_line_(15);
  #line 15 "src/distribution/RestaurantCategorical.birch"
  return birch::simulate_crp_categorical(this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0952->value(handler_), this_()->_u0961->n, this_()->_u0961->N, handler_);
}

#line 22 "src/distribution/RestaurantCategorical.birch"
birch::type::Real birch::type::RestaurantCategorical::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/distribution/RestaurantCategorical.birch"
  libbirch_function_("logpdf", "src/distribution/RestaurantCategorical.birch", 22);
  #line 23 "src/distribution/RestaurantCategorical.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/RestaurantCategorical.birch"
  return birch::logpdf_crp_categorical(x, this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0952->value(handler_), this_()->_u0961->n, this_()->_u0961->N, handler_);
}

#line 30 "src/distribution/RestaurantCategorical.birch"
void birch::type::RestaurantCategorical::update(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/distribution/RestaurantCategorical.birch"
  libbirch_function_("update", "src/distribution/RestaurantCategorical.birch", 30);
  #line 32 "src/distribution/RestaurantCategorical.birch"
  libbirch_line_(32);
  #line 32 "src/distribution/RestaurantCategorical.birch"
  libbirch_assert_(x <= this_()->_u0961->K + birch::type::Integer(1));
  #line 33 "src/distribution/RestaurantCategorical.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/RestaurantCategorical.birch"
  if (x == this_()->_u0961->K + birch::type::Integer(1)) {
    #line 34 "src/distribution/RestaurantCategorical.birch"
    libbirch_line_(34);
    #line 34 "src/distribution/RestaurantCategorical.birch"
    libbirch::DefaultArray<birch::type::Integer,1> n1(libbirch::make_shape(this_()->_u0961->K + birch::type::Integer(1)));
    #line 35 "src/distribution/RestaurantCategorical.birch"
    libbirch_line_(35);
    #line 35 "src/distribution/RestaurantCategorical.birch"
    n1.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, this_()->_u0961->K - 1)), this_()->_u0961->n);
    #line 36 "src/distribution/RestaurantCategorical.birch"
    libbirch_line_(36);
    #line 36 "src/distribution/RestaurantCategorical.birch"
    n1.set(libbirch::make_slice(x - 1), birch::type::Integer(1));
    #line 37 "src/distribution/RestaurantCategorical.birch"
    libbirch_line_(37);
    #line 37 "src/distribution/RestaurantCategorical.birch"
    this_()->_u0961->n = n1;
    #line 38 "src/distribution/RestaurantCategorical.birch"
    libbirch_line_(38);
    #line 38 "src/distribution/RestaurantCategorical.birch"
    this_()->_u0961->K = this_()->_u0961->K + birch::type::Integer(1);
  } else {
    #line 40 "src/distribution/RestaurantCategorical.birch"
    libbirch_line_(40);
    #line 40 "src/distribution/RestaurantCategorical.birch"
    this_()->_u0961->n.set(libbirch::make_slice(x - 1), this_()->_u0961->n.get(libbirch::make_slice(x - 1)) + birch::type::Integer(1));
  }
  #line 42 "src/distribution/RestaurantCategorical.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/RestaurantCategorical.birch"
  this_()->_u0961->N = this_()->_u0961->N + birch::type::Integer(1);
}

#line 49 "src/distribution/RestaurantCategorical.birch"
void birch::type::RestaurantCategorical::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/distribution/RestaurantCategorical.birch"
  libbirch_function_("link", "src/distribution/RestaurantCategorical.birch", 49);
  #line 50 "src/distribution/RestaurantCategorical.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/RestaurantCategorical.birch"
  this_()->_u0961->setChild(shared_from_this_(), handler_);
}

#line 53 "src/distribution/RestaurantCategorical.birch"
void birch::type::RestaurantCategorical::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "src/distribution/RestaurantCategorical.birch"
  libbirch_function_("unlink", "src/distribution/RestaurantCategorical.birch", 53);
  #line 54 "src/distribution/RestaurantCategorical.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/RestaurantCategorical.birch"
  this_()->_u0961->releaseChild(shared_from_this_(), handler_);
}

#line 58 "src/distribution/RestaurantCategorical.birch"
libbirch::Lazy<libbirch::Shared<birch::type::RestaurantCategorical>> birch::RestaurantCategorical(const libbirch::Lazy<libbirch::Shared<birch::type::Restaurant>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "src/distribution/RestaurantCategorical.birch"
  libbirch_function_("RestaurantCategorical", "src/distribution/RestaurantCategorical.birch", 58);
  #line 59 "src/distribution/RestaurantCategorical.birch"
  libbirch_line_(59);
  #line 59 "src/distribution/RestaurantCategorical.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::RestaurantCategorical>> m(_u0961);
  #line 60 "src/distribution/RestaurantCategorical.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/RestaurantCategorical.birch"
  m->link(handler_);
  #line 61 "src/distribution/RestaurantCategorical.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/RestaurantCategorical.birch"
  return m;
}

#line 5 "src/distribution/ScalarGaussian.birch"
birch::type::ScalarGaussian::ScalarGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09642, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 5 "src/distribution/ScalarGaussian.birch"
    super_type_(),
    #line 10 "src/distribution/ScalarGaussian.birch"
    _u0956(_u0956),
    #line 15 "src/distribution/ScalarGaussian.birch"
    _u09632(_u09632),
    #line 20 "src/distribution/ScalarGaussian.birch"
    _u09642(_u09642) {
  //
}

#line 22 "src/distribution/ScalarGaussian.birch"
birch::type::Boolean birch::type::ScalarGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/distribution/ScalarGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/ScalarGaussian.birch", 22);
  #line 23 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/ScalarGaussian.birch"
  return true;
}

#line 26 "src/distribution/ScalarGaussian.birch"
birch::type::Real birch::type::ScalarGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/distribution/ScalarGaussian.birch"
  libbirch_function_("simulate", "src/distribution/ScalarGaussian.birch", 26);
  #line 27 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(27);
  #line 27 "src/distribution/ScalarGaussian.birch"
  return birch::simulate_gaussian(this_()->_u0956->value(handler_), this_()->_u09632->value(handler_) * this_()->_u09642->value(handler_), handler_);
}

#line 30 "src/distribution/ScalarGaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::ScalarGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/distribution/ScalarGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/ScalarGaussian.birch", 30);
  #line 31 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/ScalarGaussian.birch"
  return birch::simulate_gaussian(this_()->_u0956->get(handler_), this_()->_u09632->get(handler_) * this_()->_u09642->get(handler_), handler_);
}

#line 34 "src/distribution/ScalarGaussian.birch"
birch::type::Real birch::type::ScalarGaussian::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/distribution/ScalarGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/ScalarGaussian.birch", 34);
  #line 35 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/distribution/ScalarGaussian.birch"
  return birch::logpdf_gaussian(x, this_()->_u0956->value(handler_), this_()->_u09632->value(handler_) * this_()->_u09642->value(handler_), handler_);
}

#line 38 "src/distribution/ScalarGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::ScalarGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "src/distribution/ScalarGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/ScalarGaussian.birch", 38);
  #line 39 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/distribution/ScalarGaussian.birch"
  return birch::logpdf_lazy_gaussian(x, this_()->_u0956, this_()->_u09632 * this_()->_u09642, handler_);
}

#line 42 "src/distribution/ScalarGaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::ScalarGaussian::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/distribution/ScalarGaussian.birch"
  libbirch_function_("cdf", "src/distribution/ScalarGaussian.birch", 42);
  #line 43 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/ScalarGaussian.birch"
  return birch::cdf_gaussian(x, this_()->_u0956->value(handler_), this_()->_u09632->value(handler_) * this_()->_u09642->value(handler_), handler_);
}

#line 46 "src/distribution/ScalarGaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::ScalarGaussian::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/distribution/ScalarGaussian.birch"
  libbirch_function_("quantile", "src/distribution/ScalarGaussian.birch", 46);
  #line 47 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/ScalarGaussian.birch"
  return birch::quantile_gaussian(P, this_()->_u0956->value(handler_), this_()->_u09632->value(handler_) * this_()->_u09642->value(handler_), handler_);
}

#line 50 "src/distribution/ScalarGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> birch::type::ScalarGaussian::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "src/distribution/ScalarGaussian.birch"
  libbirch_function_("graft", "src/distribution/ScalarGaussian.birch", 50);
  #line 51 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/ScalarGaussian.birch"
  this_()->prune(handler_);
  #line 52 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/ScalarGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>> s1;
  #line 53 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/ScalarGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> r = shared_from_this_();
  #line 56 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/ScalarGaussian.birch"
  if ((s1 = this_()->_u09632->graftInverseGamma(handler_)).query()) {
    #line 57 "src/distribution/ScalarGaussian.birch"
    libbirch_line_(57);
    #line 57 "src/distribution/ScalarGaussian.birch"
    r = birch::NormalInverseGamma(this_()->_u0956, this_()->_u09642, s1.get(), handler_);
  } else {
    #line 58 "src/distribution/ScalarGaussian.birch"
    libbirch_line_(58);
    #line 58 "src/distribution/ScalarGaussian.birch"
    if ((s1 = this_()->_u09642->graftInverseGamma(handler_)).query()) {
      #line 59 "src/distribution/ScalarGaussian.birch"
      libbirch_line_(59);
      #line 59 "src/distribution/ScalarGaussian.birch"
      r = birch::NormalInverseGamma(this_()->_u0956, this_()->_u09632, s1.get(), handler_);
    }
  }
  #line 62 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/ScalarGaussian.birch"
  return r;
}

#line 65 "src/distribution/ScalarGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>> birch::type::ScalarGaussian::graftGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "src/distribution/ScalarGaussian.birch"
  libbirch_function_("graftGaussian", "src/distribution/ScalarGaussian.birch", 65);
  #line 66 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/ScalarGaussian.birch"
  this_()->prune(handler_);
  #line 67 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/ScalarGaussian.birch"
  return birch::Gaussian(this_()->_u0956, this_()->_u09632 * this_()->_u09642, handler_);
}

#line 70 "src/distribution/ScalarGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>> birch::type::ScalarGaussian::graftNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "src/distribution/ScalarGaussian.birch"
  libbirch_function_("graftNormalInverseGamma", "src/distribution/ScalarGaussian.birch", 70);
  #line 72 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(72);
  #line 72 "src/distribution/ScalarGaussian.birch"
  this_()->prune(handler_);
  #line 73 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(73);
  #line 73 "src/distribution/ScalarGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>> s1;
  #line 74 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(74);
  #line 74 "src/distribution/ScalarGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>> r;
  #line 77 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/ScalarGaussian.birch"
  if ((s1 = this_()->_u09632->graftInverseGamma(handler_)).query() && s1.get() == compare) {
    #line 78 "src/distribution/ScalarGaussian.birch"
    libbirch_line_(78);
    #line 78 "src/distribution/ScalarGaussian.birch"
    r = birch::NormalInverseGamma(this_()->_u0956, this_()->_u09642, s1.get(), handler_);
  } else {
    #line 79 "src/distribution/ScalarGaussian.birch"
    libbirch_line_(79);
    #line 79 "src/distribution/ScalarGaussian.birch"
    if ((s1 = this_()->_u09642->graftInverseGamma(handler_)).query() && s1.get() == compare) {
      #line 80 "src/distribution/ScalarGaussian.birch"
      libbirch_line_(80);
      #line 80 "src/distribution/ScalarGaussian.birch"
      r = birch::NormalInverseGamma(this_()->_u0956, this_()->_u09632, s1.get(), handler_);
    }
  }
  #line 83 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(83);
  #line 83 "src/distribution/ScalarGaussian.birch"
  return r;
}

#line 92 "src/distribution/ScalarGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09642, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 92 "src/distribution/ScalarGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/ScalarGaussian.birch", 92);
  #line 94 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(94);
  #line 94 "src/distribution/ScalarGaussian.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::ScalarGaussian>>>(_u0956, _u09632, _u09642, handler_);
}

#line 102 "src/distribution/ScalarGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const birch::type::Real& _u09642, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 102 "src/distribution/ScalarGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/ScalarGaussian.birch", 102);
  #line 104 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(104);
  #line 104 "src/distribution/ScalarGaussian.birch"
  return birch::Gaussian(_u0956, _u09632, birch::box(_u09642, handler_), handler_);
}

#line 112 "src/distribution/ScalarGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09642, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 112 "src/distribution/ScalarGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/ScalarGaussian.birch", 112);
  #line 114 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(114);
  #line 114 "src/distribution/ScalarGaussian.birch"
  return birch::Gaussian(_u0956, birch::box(_u09632, handler_), _u09642, handler_);
}

#line 122 "src/distribution/ScalarGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const birch::type::Real& _u09632, const birch::type::Real& _u09642, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 122 "src/distribution/ScalarGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/ScalarGaussian.birch", 122);
  #line 124 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(124);
  #line 124 "src/distribution/ScalarGaussian.birch"
  return birch::Gaussian(_u0956, birch::box(_u09632, handler_), birch::box(_u09642, handler_), handler_);
}

#line 132 "src/distribution/ScalarGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarGaussian>> birch::Gaussian(const birch::type::Real& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09642, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 132 "src/distribution/ScalarGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/ScalarGaussian.birch", 132);
  #line 134 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(134);
  #line 134 "src/distribution/ScalarGaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), _u09632, _u09642, handler_);
}

#line 142 "src/distribution/ScalarGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarGaussian>> birch::Gaussian(const birch::type::Real& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const birch::type::Real& _u09642, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 142 "src/distribution/ScalarGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/ScalarGaussian.birch", 142);
  #line 144 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(144);
  #line 144 "src/distribution/ScalarGaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), _u09632, birch::box(_u09642, handler_), handler_);
}

#line 152 "src/distribution/ScalarGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarGaussian>> birch::Gaussian(const birch::type::Real& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09642, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 152 "src/distribution/ScalarGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/ScalarGaussian.birch", 152);
  #line 154 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(154);
  #line 154 "src/distribution/ScalarGaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), birch::box(_u09632, handler_), _u09642, handler_);
}

#line 162 "src/distribution/ScalarGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarGaussian>> birch::Gaussian(const birch::type::Real& _u0956, const birch::type::Real& _u09632, const birch::type::Real& _u09642, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 162 "src/distribution/ScalarGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/ScalarGaussian.birch", 162);
  #line 163 "src/distribution/ScalarGaussian.birch"
  libbirch_line_(163);
  #line 163 "src/distribution/ScalarGaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), birch::box(_u09632, handler_), birch::box(_u09642, handler_), handler_);
}

#line 5 "src/distribution/ScalarMultivariateGaussian.birch"
birch::type::ScalarMultivariateGaussian::ScalarMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 5 "src/distribution/ScalarMultivariateGaussian.birch"
    super_type_(),
    #line 10 "src/distribution/ScalarMultivariateGaussian.birch"
    _u0956(_u0956),
    #line 15 "src/distribution/ScalarMultivariateGaussian.birch"
    _u0931(_u0931),
    #line 20 "src/distribution/ScalarMultivariateGaussian.birch"
    _u09632(_u09632) {
  //
}

#line 22 "src/distribution/ScalarMultivariateGaussian.birch"
birch::type::Integer birch::type::ScalarMultivariateGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("rows", "src/distribution/ScalarMultivariateGaussian.birch", 22);
  #line 23 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(23);
  #line 23 "src/distribution/ScalarMultivariateGaussian.birch"
  return this_()->_u0956->rows(handler_);
}

#line 26 "src/distribution/ScalarMultivariateGaussian.birch"
birch::type::Boolean birch::type::ScalarMultivariateGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("supportsLazy", "src/distribution/ScalarMultivariateGaussian.birch", 26);
  #line 27 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(27);
  #line 27 "src/distribution/ScalarMultivariateGaussian.birch"
  return true;
}

#line 30 "src/distribution/ScalarMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::ScalarMultivariateGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("simulate", "src/distribution/ScalarMultivariateGaussian.birch", 30);
  #line 31 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(31);
  #line 31 "src/distribution/ScalarMultivariateGaussian.birch"
  return birch::simulate_multivariate_gaussian(this_()->_u0956->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 34 "src/distribution/ScalarMultivariateGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::ScalarMultivariateGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("simulateLazy", "src/distribution/ScalarMultivariateGaussian.birch", 34);
  #line 35 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/distribution/ScalarMultivariateGaussian.birch"
  return birch::simulate_multivariate_gaussian(this_()->_u0956->get(handler_), this_()->_u09632->get(handler_), handler_);
}

#line 38 "src/distribution/ScalarMultivariateGaussian.birch"
birch::type::Real birch::type::ScalarMultivariateGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("logpdf", "src/distribution/ScalarMultivariateGaussian.birch", 38);
  #line 39 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/distribution/ScalarMultivariateGaussian.birch"
  return birch::logpdf_multivariate_gaussian(x, this_()->_u0956->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 42 "src/distribution/ScalarMultivariateGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::ScalarMultivariateGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("logpdfLazy", "src/distribution/ScalarMultivariateGaussian.birch", 42);
  #line 43 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/distribution/ScalarMultivariateGaussian.birch"
  return birch::logpdf_lazy_multivariate_gaussian(x, this_()->_u0956, this_()->_u09632, handler_);
}

#line 46 "src/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>> birch::type::ScalarMultivariateGaussian::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("graft", "src/distribution/ScalarMultivariateGaussian.birch", 46);
  #line 47 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/distribution/ScalarMultivariateGaussian.birch"
  this_()->prune(handler_);
  #line 48 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>> s1;
  #line 49 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>> r = shared_from_this_();
  #line 52 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/ScalarMultivariateGaussian.birch"
  if ((s1 = this_()->_u09632->graftInverseGamma(handler_)).query()) {
    #line 53 "src/distribution/ScalarMultivariateGaussian.birch"
    libbirch_line_(53);
    #line 53 "src/distribution/ScalarMultivariateGaussian.birch"
    r = birch::MultivariateNormalInverseGamma(this_()->_u0956, this_()->_u0931, s1.get(), handler_);
  }
  #line 56 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/ScalarMultivariateGaussian.birch"
  return r;
}

#line 59 "src/distribution/ScalarMultivariateGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>> birch::type::ScalarMultivariateGaussian::graftMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("graftMultivariateGaussian", "src/distribution/ScalarMultivariateGaussian.birch", 59);
  #line 60 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/ScalarMultivariateGaussian.birch"
  this_()->prune(handler_);
  #line 61 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(this_()->_u0956, birch::canonical(this_()->_u0931, handler_) * this_()->_u09632, handler_);
}

#line 64 "src/distribution/ScalarMultivariateGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>> birch::type::ScalarMultivariateGaussian::graftMultivariateNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("graftMultivariateNormalInverseGamma", "src/distribution/ScalarMultivariateGaussian.birch", 64);
  #line 66 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/distribution/ScalarMultivariateGaussian.birch"
  this_()->prune(handler_);
  #line 67 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>> s1;
  #line 68 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(68);
  #line 68 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>> r;
  #line 71 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(71);
  #line 71 "src/distribution/ScalarMultivariateGaussian.birch"
  if ((s1 = this_()->_u09632->graftInverseGamma(handler_)).query() && s1.get() == compare) {
    #line 72 "src/distribution/ScalarMultivariateGaussian.birch"
    libbirch_line_(72);
    #line 72 "src/distribution/ScalarMultivariateGaussian.birch"
    r = birch::MultivariateNormalInverseGamma(this_()->_u0956, this_()->_u0931, s1.get(), handler_);
  }
  #line 75 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(75);
  #line 75 "src/distribution/ScalarMultivariateGaussian.birch"
  return r;
}

#line 85 "src/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 85 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/ScalarMultivariateGaussian.birch", 85);
  #line 87 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(87);
  #line 87 "src/distribution/ScalarMultivariateGaussian.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>>>(_u0956, _u0931, _u09632, handler_);
}

#line 96 "src/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 96 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/ScalarMultivariateGaussian.birch", 96);
  #line 98 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(98);
  #line 98 "src/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(_u0956, _u0931, birch::box(_u09632, handler_), handler_);
}

#line 107 "src/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const birch::type::LLT& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 107 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/ScalarMultivariateGaussian.birch", 107);
  #line 109 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(109);
  #line 109 "src/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::box(_u0931, handler_), _u09632, handler_);
}

#line 118 "src/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const birch::type::LLT& _u0931, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 118 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/ScalarMultivariateGaussian.birch", 118);
  #line 120 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(120);
  #line 120 "src/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::box(_u0931, handler_), birch::box(_u09632, handler_), handler_);
}

#line 129 "src/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 129 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/ScalarMultivariateGaussian.birch", 129);
  #line 131 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(131);
  #line 131 "src/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), _u0931, _u09632, handler_);
}

#line 140 "src/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 140 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/ScalarMultivariateGaussian.birch", 140);
  #line 142 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(142);
  #line 142 "src/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), _u0931, birch::box(_u09632, handler_), handler_);
}

#line 151 "src/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const birch::type::LLT& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 151 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/ScalarMultivariateGaussian.birch", 151);
  #line 153 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(153);
  #line 153 "src/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), birch::box(_u0931, handler_), _u09632, handler_);
}

#line 162 "src/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const birch::type::LLT& _u0931, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 162 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/ScalarMultivariateGaussian.birch", 162);
  #line 163 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(163);
  #line 163 "src/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), birch::box(_u0931, handler_), birch::box(_u09632, handler_), handler_);
}

#line 172 "src/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 172 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/ScalarMultivariateGaussian.birch", 172);
  #line 174 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(174);
  #line 174 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> m(_u0956, birch::llt(_u0931, handler_), _u09632);
  #line 175 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(175);
  #line 175 "src/distribution/ScalarMultivariateGaussian.birch"
  return m;
}

#line 184 "src/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& _u0931, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 184 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/ScalarMultivariateGaussian.birch", 184);
  #line 186 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(186);
  #line 186 "src/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931, handler_), _u09632, handler_);
}

#line 195 "src/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::DefaultArray<birch::type::Real,2>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 195 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/ScalarMultivariateGaussian.birch", 195);
  #line 197 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(197);
  #line 197 "src/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931, handler_), _u09632, handler_);
}

#line 206 "src/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::DefaultArray<birch::type::Real,2>& _u0931, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 206 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/ScalarMultivariateGaussian.birch", 206);
  #line 208 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(208);
  #line 208 "src/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931, handler_), _u09632, handler_);
}

#line 217 "src/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 217 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/ScalarMultivariateGaussian.birch", 217);
  #line 219 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(219);
  #line 219 "src/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931, handler_), _u09632, handler_);
}

#line 228 "src/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& _u0931, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 228 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/ScalarMultivariateGaussian.birch", 228);
  #line 230 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(230);
  #line 230 "src/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931, handler_), _u09632, handler_);
}

#line 239 "src/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::DefaultArray<birch::type::Real,2>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 239 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/ScalarMultivariateGaussian.birch", 239);
  #line 241 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(241);
  #line 241 "src/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931, handler_), _u09632, handler_);
}

#line 250 "src/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::DefaultArray<birch::type::Real,2>& _u0931, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 250 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "src/distribution/ScalarMultivariateGaussian.birch", 250);
  #line 252 "src/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(252);
  #line 252 "src/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931, handler_), _u09632, handler_);
}

#line 1 "src/distribution/ScaledGammaExponential.birch"
birch::type::ScaledGammaExponential::ScaledGammaExponential(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/distribution/ScaledGammaExponential.birch"
    super_type_(),
    #line 9 "src/distribution/ScaledGammaExponential.birch"
    a(a),
    #line 14 "src/distribution/ScaledGammaExponential.birch"
    _u0955(_u0955) {
  //
}

#line 16 "src/distribution/ScaledGammaExponential.birch"
birch::type::Boolean birch::type::ScaledGammaExponential::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("supportsLazy", "src/distribution/ScaledGammaExponential.birch", 16);
  #line 17 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/ScaledGammaExponential.birch"
  return true;
}

#line 20 "src/distribution/ScaledGammaExponential.birch"
birch::type::Real birch::type::ScaledGammaExponential::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("simulate", "src/distribution/ScaledGammaExponential.birch", 20);
  #line 21 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/ScaledGammaExponential.birch"
  return birch::simulate_lomax(1.0 / (this_()->a->value(handler_) * this_()->_u0955->_u0952->value(handler_)), this_()->_u0955->k->value(handler_), handler_);
}

#line 24 "src/distribution/ScaledGammaExponential.birch"
libbirch::Optional<birch::type::Real> birch::type::ScaledGammaExponential::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("simulateLazy", "src/distribution/ScaledGammaExponential.birch", 24);
  #line 25 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/ScaledGammaExponential.birch"
  return birch::simulate_lomax(1.0 / (this_()->a->get(handler_) * this_()->_u0955->_u0952->get(handler_)), this_()->_u0955->k->get(handler_), handler_);
}

#line 28 "src/distribution/ScaledGammaExponential.birch"
birch::type::Real birch::type::ScaledGammaExponential::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("logpdf", "src/distribution/ScaledGammaExponential.birch", 28);
  #line 29 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/ScaledGammaExponential.birch"
  return birch::logpdf_lomax(x, 1.0 / (this_()->a->value(handler_) * this_()->_u0955->_u0952->value(handler_)), this_()->_u0955->k->value(handler_), handler_);
}

#line 32 "src/distribution/ScaledGammaExponential.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::ScaledGammaExponential::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("logpdfLazy", "src/distribution/ScaledGammaExponential.birch", 32);
  #line 33 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/ScaledGammaExponential.birch"
  return birch::logpdf_lazy_lomax(x, 1.0 / (this_()->a * this_()->_u0955->_u0952), this_()->_u0955->k, handler_);
}

#line 36 "src/distribution/ScaledGammaExponential.birch"
void birch::type::ScaledGammaExponential::update(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("update", "src/distribution/ScaledGammaExponential.birch", 36);
  #line 37 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/ScaledGammaExponential.birch"
  libbirch::tie(this_()->_u0955->k, this_()->_u0955->_u0952) = birch::box(birch::update_scaled_gamma_exponential(x, this_()->a->value(handler_), this_()->_u0955->k->value(handler_), this_()->_u0955->_u0952->value(handler_), handler_), handler_);
}

#line 41 "src/distribution/ScaledGammaExponential.birch"
void birch::type::ScaledGammaExponential::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("updateLazy", "src/distribution/ScaledGammaExponential.birch", 41);
  #line 42 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/ScaledGammaExponential.birch"
  libbirch::tie(this_()->_u0955->k, this_()->_u0955->_u0952) = birch::update_lazy_scaled_gamma_exponential(x, this_()->a, this_()->_u0955->k, this_()->_u0955->_u0952, handler_);
}

#line 45 "src/distribution/ScaledGammaExponential.birch"
libbirch::Optional<birch::type::Real> birch::type::ScaledGammaExponential::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("cdf", "src/distribution/ScaledGammaExponential.birch", 45);
  #line 46 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/ScaledGammaExponential.birch"
  return birch::cdf_lomax(x, 1.0 / (this_()->a->value(handler_) * this_()->_u0955->_u0952->value(handler_)), this_()->_u0955->k->value(handler_), handler_);
}

#line 49 "src/distribution/ScaledGammaExponential.birch"
libbirch::Optional<birch::type::Real> birch::type::ScaledGammaExponential::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("quantile", "src/distribution/ScaledGammaExponential.birch", 49);
  #line 50 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/ScaledGammaExponential.birch"
  return birch::quantile_lomax(P, 1.0 / (this_()->a->value(handler_) * this_()->_u0955->_u0952->value(handler_)), this_()->_u0955->k->value(handler_), handler_);
}

#line 53 "src/distribution/ScaledGammaExponential.birch"
libbirch::Optional<birch::type::Real> birch::type::ScaledGammaExponential::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("lower", "src/distribution/ScaledGammaExponential.birch", 53);
  #line 54 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/ScaledGammaExponential.birch"
  return 0.0;
}

#line 57 "src/distribution/ScaledGammaExponential.birch"
void birch::type::ScaledGammaExponential::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 57 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("link", "src/distribution/ScaledGammaExponential.birch", 57);
  #line 58 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(58);
  #line 58 "src/distribution/ScaledGammaExponential.birch"
  this_()->_u0955->setChild(shared_from_this_(), handler_);
}

#line 61 "src/distribution/ScaledGammaExponential.birch"
void birch::type::ScaledGammaExponential::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("unlink", "src/distribution/ScaledGammaExponential.birch", 61);
  #line 62 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/ScaledGammaExponential.birch"
  this_()->_u0955->releaseChild(shared_from_this_(), handler_);
}

#line 66 "src/distribution/ScaledGammaExponential.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScaledGammaExponential>> birch::ScaledGammaExponential(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "src/distribution/ScaledGammaExponential.birch"
  libbirch_function_("ScaledGammaExponential", "src/distribution/ScaledGammaExponential.birch", 66);
  #line 68 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(68);
  #line 68 "src/distribution/ScaledGammaExponential.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::ScaledGammaExponential>> m(a, _u0955);
  #line 69 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(69);
  #line 69 "src/distribution/ScaledGammaExponential.birch"
  m->link(handler_);
  #line 70 "src/distribution/ScaledGammaExponential.birch"
  libbirch_line_(70);
  #line 70 "src/distribution/ScaledGammaExponential.birch"
  return m;
}

#line 4 "src/distribution/ScaledGammaPoisson.birch"
birch::type::ScaledGammaPoisson::ScaledGammaPoisson(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/ScaledGammaPoisson.birch"
    super_type_(),
    #line 8 "src/distribution/ScaledGammaPoisson.birch"
    a(a),
    #line 13 "src/distribution/ScaledGammaPoisson.birch"
    _u0955(_u0955) {
  //
}

#line 15 "src/distribution/ScaledGammaPoisson.birch"
birch::type::Boolean birch::type::ScaledGammaPoisson::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("supportsLazy", "src/distribution/ScaledGammaPoisson.birch", 15);
  #line 16 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(16);
  #line 16 "src/distribution/ScaledGammaPoisson.birch"
  return true;
}

#line 19 "src/distribution/ScaledGammaPoisson.birch"
birch::type::Integer birch::type::ScaledGammaPoisson::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("simulate", "src/distribution/ScaledGammaPoisson.birch", 19);
  #line 20 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(20);
  #line 20 "src/distribution/ScaledGammaPoisson.birch"
  if (this_()->value.query()) {
    #line 21 "src/distribution/ScaledGammaPoisson.birch"
    libbirch_line_(21);
    #line 21 "src/distribution/ScaledGammaPoisson.birch"
    return this_()->value.get();
  } else {
    #line 23 "src/distribution/ScaledGammaPoisson.birch"
    libbirch_line_(23);
    #line 23 "src/distribution/ScaledGammaPoisson.birch"
    return birch::simulate_gamma_poisson(this_()->_u0955->k->value(handler_), this_()->a->value(handler_) * this_()->_u0955->_u0952->value(handler_), handler_);
  }
}

#line 27 "src/distribution/ScaledGammaPoisson.birch"
libbirch::Optional<birch::type::Integer> birch::type::ScaledGammaPoisson::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("simulateLazy", "src/distribution/ScaledGammaPoisson.birch", 27);
  #line 28 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(28);
  #line 28 "src/distribution/ScaledGammaPoisson.birch"
  if (this_()->value.query()) {
    #line 29 "src/distribution/ScaledGammaPoisson.birch"
    libbirch_line_(29);
    #line 29 "src/distribution/ScaledGammaPoisson.birch"
    return this_()->value.get();
  } else {
    #line 31 "src/distribution/ScaledGammaPoisson.birch"
    libbirch_line_(31);
    #line 31 "src/distribution/ScaledGammaPoisson.birch"
    return birch::simulate_gamma_poisson(this_()->_u0955->k->get(handler_), this_()->a->get(handler_) * this_()->_u0955->_u0952->get(handler_), handler_);
  }
}

#line 35 "src/distribution/ScaledGammaPoisson.birch"
birch::type::Real birch::type::ScaledGammaPoisson::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("logpdf", "src/distribution/ScaledGammaPoisson.birch", 35);
  #line 36 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(36);
  #line 36 "src/distribution/ScaledGammaPoisson.birch"
  return birch::logpdf_gamma_poisson(x, this_()->_u0955->k->value(handler_), this_()->a->value(handler_) * this_()->_u0955->_u0952->value(handler_), handler_);
}

#line 39 "src/distribution/ScaledGammaPoisson.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::ScaledGammaPoisson::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("logpdfLazy", "src/distribution/ScaledGammaPoisson.birch", 39);
  #line 40 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(40);
  #line 40 "src/distribution/ScaledGammaPoisson.birch"
  return birch::logpdf_lazy_gamma_poisson(x, this_()->_u0955->k, this_()->a * this_()->_u0955->_u0952, handler_);
}

#line 43 "src/distribution/ScaledGammaPoisson.birch"
void birch::type::ScaledGammaPoisson::update(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("update", "src/distribution/ScaledGammaPoisson.birch", 43);
  #line 44 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(44);
  #line 44 "src/distribution/ScaledGammaPoisson.birch"
  libbirch::tie(this_()->_u0955->k, this_()->_u0955->_u0952) = birch::box(birch::update_scaled_gamma_poisson(x, this_()->a->value(handler_), this_()->_u0955->k->value(handler_), this_()->_u0955->_u0952->value(handler_), handler_), handler_);
}

#line 48 "src/distribution/ScaledGammaPoisson.birch"
void birch::type::ScaledGammaPoisson::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("updateLazy", "src/distribution/ScaledGammaPoisson.birch", 48);
  #line 49 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/ScaledGammaPoisson.birch"
  libbirch::tie(this_()->_u0955->k, this_()->_u0955->_u0952) = birch::update_lazy_scaled_gamma_poisson(x, this_()->a, this_()->_u0955->k, this_()->_u0955->_u0952, handler_);
}

#line 52 "src/distribution/ScaledGammaPoisson.birch"
libbirch::Optional<birch::type::Real> birch::type::ScaledGammaPoisson::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("cdf", "src/distribution/ScaledGammaPoisson.birch", 52);
  #line 53 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/ScaledGammaPoisson.birch"
  return birch::cdf_gamma_poisson(x, this_()->_u0955->k->value(handler_), this_()->a->value(handler_) * this_()->_u0955->_u0952->value(handler_), handler_);
}

#line 56 "src/distribution/ScaledGammaPoisson.birch"
libbirch::Optional<birch::type::Integer> birch::type::ScaledGammaPoisson::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 56 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("quantile", "src/distribution/ScaledGammaPoisson.birch", 56);
  #line 57 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/ScaledGammaPoisson.birch"
  return birch::quantile_gamma_poisson(P, this_()->_u0955->k->value(handler_), this_()->a->value(handler_) * this_()->_u0955->_u0952->value(handler_), handler_);
}

#line 60 "src/distribution/ScaledGammaPoisson.birch"
libbirch::Optional<birch::type::Integer> birch::type::ScaledGammaPoisson::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("lower", "src/distribution/ScaledGammaPoisson.birch", 60);
  #line 61 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/ScaledGammaPoisson.birch"
  return birch::type::Integer(0);
}

#line 64 "src/distribution/ScaledGammaPoisson.birch"
void birch::type::ScaledGammaPoisson::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("link", "src/distribution/ScaledGammaPoisson.birch", 64);
  #line 65 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/ScaledGammaPoisson.birch"
  this_()->_u0955->setChild(shared_from_this_(), handler_);
}

#line 68 "src/distribution/ScaledGammaPoisson.birch"
void birch::type::ScaledGammaPoisson::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 68 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("unlink", "src/distribution/ScaledGammaPoisson.birch", 68);
  #line 69 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(69);
  #line 69 "src/distribution/ScaledGammaPoisson.birch"
  this_()->_u0955->releaseChild(shared_from_this_(), handler_);
}

#line 73 "src/distribution/ScaledGammaPoisson.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScaledGammaPoisson>> birch::ScaledGammaPoisson(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 73 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("ScaledGammaPoisson", "src/distribution/ScaledGammaPoisson.birch", 73);
  #line 75 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(75);
  #line 75 "src/distribution/ScaledGammaPoisson.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::ScaledGammaPoisson>> m(a, _u0955);
  #line 76 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(76);
  #line 76 "src/distribution/ScaledGammaPoisson.birch"
  m->link(handler_);
  #line 77 "src/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/ScaledGammaPoisson.birch"
  return m;
}

#line 4 "src/distribution/Student.birch"
birch::type::Student::Student(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/Student.birch"
    super_type_(),
    #line 9 "src/distribution/Student.birch"
    _u0957(_u0957),
    #line 14 "src/distribution/Student.birch"
    _u0956(_u0956),
    #line 19 "src/distribution/Student.birch"
    _u09632(_u09632) {
  //
}

#line 21 "src/distribution/Student.birch"
birch::type::Boolean birch::type::Student::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "src/distribution/Student.birch"
  libbirch_function_("supportsLazy", "src/distribution/Student.birch", 21);
  #line 22 "src/distribution/Student.birch"
  libbirch_line_(22);
  #line 22 "src/distribution/Student.birch"
  return true;
}

#line 25 "src/distribution/Student.birch"
birch::type::Real birch::type::Student::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/distribution/Student.birch"
  libbirch_function_("simulate", "src/distribution/Student.birch", 25);
  #line 26 "src/distribution/Student.birch"
  libbirch_line_(26);
  #line 26 "src/distribution/Student.birch"
  return birch::simulate_student_t(this_()->_u0957->value(handler_), this_()->_u0956->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 29 "src/distribution/Student.birch"
libbirch::Optional<birch::type::Real> birch::type::Student::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "src/distribution/Student.birch"
  libbirch_function_("simulateLazy", "src/distribution/Student.birch", 29);
  #line 30 "src/distribution/Student.birch"
  libbirch_line_(30);
  #line 30 "src/distribution/Student.birch"
  return birch::simulate_student_t(this_()->_u0957->get(handler_), this_()->_u0956->get(handler_), this_()->_u09632->get(handler_), handler_);
}

#line 33 "src/distribution/Student.birch"
birch::type::Real birch::type::Student::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/distribution/Student.birch"
  libbirch_function_("logpdf", "src/distribution/Student.birch", 33);
  #line 34 "src/distribution/Student.birch"
  libbirch_line_(34);
  #line 34 "src/distribution/Student.birch"
  return birch::logpdf_student_t(x, this_()->_u0957->value(handler_), this_()->_u0956->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 37 "src/distribution/Student.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::Student::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/distribution/Student.birch"
  libbirch_function_("logpdfLazy", "src/distribution/Student.birch", 37);
  #line 38 "src/distribution/Student.birch"
  libbirch_line_(38);
  #line 38 "src/distribution/Student.birch"
  return birch::logpdf_lazy_student_t(x, this_()->_u0957, this_()->_u0956, this_()->_u09632, handler_);
}

#line 41 "src/distribution/Student.birch"
libbirch::Optional<birch::type::Real> birch::type::Student::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "src/distribution/Student.birch"
  libbirch_function_("cdf", "src/distribution/Student.birch", 41);
  #line 42 "src/distribution/Student.birch"
  libbirch_line_(42);
  #line 42 "src/distribution/Student.birch"
  return birch::cdf_student_t(x, this_()->_u0957->value(handler_), this_()->_u0956->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 45 "src/distribution/Student.birch"
libbirch::Optional<birch::type::Real> birch::type::Student::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "src/distribution/Student.birch"
  libbirch_function_("quantile", "src/distribution/Student.birch", 45);
  #line 46 "src/distribution/Student.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/Student.birch"
  return birch::quantile_student_t(P, this_()->_u0957->value(handler_), this_()->_u0956->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 49 "src/distribution/Student.birch"
void birch::type::Student::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/distribution/Student.birch"
  libbirch_function_("write", "src/distribution/Student.birch", 49);
  #line 50 "src/distribution/Student.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/Student.birch"
  this_()->prune(handler_);
  #line 51 "src/distribution/Student.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/Student.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Student"), handler_);
  #line 52 "src/distribution/Student.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/Student.birch"
  buffer->set(birch::type::String("ν"), this_()->_u0957, handler_);
  #line 53 "src/distribution/Student.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/Student.birch"
  buffer->set(birch::type::String("μ"), this_()->_u0956, handler_);
  #line 54 "src/distribution/Student.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/Student.birch"
  buffer->set(birch::type::String("σ2"), this_()->_u09632, handler_);
}

#line 61 "src/distribution/Student.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Student>> birch::Student(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "src/distribution/Student.birch"
  libbirch_function_("Student", "src/distribution/Student.birch", 61);
  #line 63 "src/distribution/Student.birch"
  libbirch_line_(63);
  #line 63 "src/distribution/Student.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Student>>>(_u0957, _u0956, _u09632, handler_);
}

#line 69 "src/distribution/Student.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Student>> birch::Student(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "src/distribution/Student.birch"
  libbirch_function_("Student", "src/distribution/Student.birch", 69);
  #line 70 "src/distribution/Student.birch"
  libbirch_line_(70);
  #line 70 "src/distribution/Student.birch"
  return birch::Student(_u0957, birch::box(0.0, handler_), birch::box(1.0, handler_), handler_);
}

#line 76 "src/distribution/Student.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Student>> birch::Student(const birch::type::Real& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "src/distribution/Student.birch"
  libbirch_function_("Student", "src/distribution/Student.birch", 76);
  #line 77 "src/distribution/Student.birch"
  libbirch_line_(77);
  #line 77 "src/distribution/Student.birch"
  return birch::Student(birch::box(_u0957, handler_), birch::box(0.0, handler_), birch::box(1.0, handler_), handler_);
}

#line 83 "src/distribution/Student.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Student>> birch::Student(const birch::type::Real& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 83 "src/distribution/Student.birch"
  libbirch_function_("Student", "src/distribution/Student.birch", 83);
  #line 84 "src/distribution/Student.birch"
  libbirch_line_(84);
  #line 84 "src/distribution/Student.birch"
  return birch::Student(birch::box(_u0957, handler_), _u0956, _u09632, handler_);
}

#line 90 "src/distribution/Student.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Student>> birch::Student(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0957, const birch::type::Real& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 90 "src/distribution/Student.birch"
  libbirch_function_("Student", "src/distribution/Student.birch", 90);
  #line 91 "src/distribution/Student.birch"
  libbirch_line_(91);
  #line 91 "src/distribution/Student.birch"
  return birch::Student(_u0957, birch::box(_u0956, handler_), _u09632, handler_);
}

#line 97 "src/distribution/Student.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Student>> birch::Student(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 97 "src/distribution/Student.birch"
  libbirch_function_("Student", "src/distribution/Student.birch", 97);
  #line 98 "src/distribution/Student.birch"
  libbirch_line_(98);
  #line 98 "src/distribution/Student.birch"
  return birch::Student(_u0957, _u0956, birch::box(_u09632, handler_), handler_);
}

#line 104 "src/distribution/Student.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Student>> birch::Student(const birch::type::Real& _u0957, const birch::type::Real& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 104 "src/distribution/Student.birch"
  libbirch_function_("Student", "src/distribution/Student.birch", 104);
  #line 105 "src/distribution/Student.birch"
  libbirch_line_(105);
  #line 105 "src/distribution/Student.birch"
  return birch::Student(birch::box(_u0957, handler_), birch::box(_u0956, handler_), _u09632, handler_);
}

#line 111 "src/distribution/Student.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Student>> birch::Student(const birch::type::Real& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 111 "src/distribution/Student.birch"
  libbirch_function_("Student", "src/distribution/Student.birch", 111);
  #line 112 "src/distribution/Student.birch"
  libbirch_line_(112);
  #line 112 "src/distribution/Student.birch"
  return birch::Student(birch::box(_u0957, handler_), _u0956, birch::box(_u09632, handler_), handler_);
}

#line 118 "src/distribution/Student.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Student>> birch::Student(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0957, const birch::type::Real& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 118 "src/distribution/Student.birch"
  libbirch_function_("Student", "src/distribution/Student.birch", 118);
  #line 119 "src/distribution/Student.birch"
  libbirch_line_(119);
  #line 119 "src/distribution/Student.birch"
  return birch::Student(_u0957, birch::box(_u0956, handler_), birch::box(_u09632, handler_), handler_);
}

#line 125 "src/distribution/Student.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Student>> birch::Student(const birch::type::Real& _u0957, const birch::type::Real& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 125 "src/distribution/Student.birch"
  libbirch_function_("Student", "src/distribution/Student.birch", 125);
  #line 126 "src/distribution/Student.birch"
  libbirch_line_(126);
  #line 126 "src/distribution/Student.birch"
  return birch::Student(birch::box(_u0957, handler_), birch::box(_u0956, handler_), birch::box(_u09632, handler_), handler_);
}

#line 5 "src/distribution/SubtractBoundedDiscrete.birch"
birch::type::SubtractBoundedDiscrete::SubtractBoundedDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>& x1, const libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>& x2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 5 "src/distribution/SubtractBoundedDiscrete.birch"
    super_type_(),
    #line 10 "src/distribution/SubtractBoundedDiscrete.birch"
    x1(x1),
    #line 15 "src/distribution/SubtractBoundedDiscrete.birch"
    x2(x2),
    #line 20 "src/distribution/SubtractBoundedDiscrete.birch"
    x(),
    #line 25 "src/distribution/SubtractBoundedDiscrete.birch"
    x0(),
    #line 30 "src/distribution/SubtractBoundedDiscrete.birch"
    z(),
    #line 35 "src/distribution/SubtractBoundedDiscrete.birch"
    Z(),
    #line 43 "src/distribution/SubtractBoundedDiscrete.birch"
    alreadyUpdated(false) {
  //
}

#line 45 "src/distribution/SubtractBoundedDiscrete.birch"
void birch::type::SubtractBoundedDiscrete::enumerate(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("enumerate", "src/distribution/SubtractBoundedDiscrete.birch", 45);
  #line 46 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/SubtractBoundedDiscrete.birch"
  if (!this_()->x.query() || this_()->x.get() != x) {
    #line 47 "src/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(47);
    #line 47 "src/distribution/SubtractBoundedDiscrete.birch"
    auto l = birch::max(this_()->x1->lower(handler_).get(), this_()->x2->lower(handler_).get() + x, handler_);
    #line 48 "src/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(48);
    #line 48 "src/distribution/SubtractBoundedDiscrete.birch"
    auto u = birch::min(this_()->x1->upper(handler_).get(), this_()->x2->upper(handler_).get() + x, handler_);
    #line 50 "src/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(50);
    #line 50 "src/distribution/SubtractBoundedDiscrete.birch"
    this_()->x0 = l;
    #line 51 "src/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(51);
    #line 51 "src/distribution/SubtractBoundedDiscrete.birch"
    this_()->Z = 0.0;
    #line 52 "src/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(52);
    #line 52 "src/distribution/SubtractBoundedDiscrete.birch"
    if (l <= u) {
      #line 54 "src/distribution/SubtractBoundedDiscrete.birch"
      libbirch_line_(54);
      #line 54 "src/distribution/SubtractBoundedDiscrete.birch"
      this_()->z = birch::vector(0.0, u - l + birch::type::Integer(1), handler_);
      #line 55 "src/distribution/SubtractBoundedDiscrete.birch"
      libbirch_line_(55);
      #line 55 "src/distribution/SubtractBoundedDiscrete.birch"
      for (auto n = l; n <= u; ++n) {
        #line 56 "src/distribution/SubtractBoundedDiscrete.birch"
        libbirch_line_(56);
        #line 56 "src/distribution/SubtractBoundedDiscrete.birch"
        this_()->z.set(libbirch::make_slice(n - l + birch::type::Integer(1) - 1), this_()->x1->pdf(n, handler_) * this_()->x2->pdf(n - x, handler_));
        #line 57 "src/distribution/SubtractBoundedDiscrete.birch"
        libbirch_line_(57);
        #line 57 "src/distribution/SubtractBoundedDiscrete.birch"
        this_()->Z = this_()->Z + this_()->z.get(libbirch::make_slice(n - l + birch::type::Integer(1) - 1));
      }
    }
    #line 60 "src/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(60);
    #line 60 "src/distribution/SubtractBoundedDiscrete.birch"
    this_()->x = x;
  }
}

#line 64 "src/distribution/SubtractBoundedDiscrete.birch"
birch::type::Boolean birch::type::SubtractBoundedDiscrete::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("supportsLazy", "src/distribution/SubtractBoundedDiscrete.birch", 64);
  #line 65 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(65);
  #line 65 "src/distribution/SubtractBoundedDiscrete.birch"
  return false;
}

#line 68 "src/distribution/SubtractBoundedDiscrete.birch"
birch::type::Integer birch::type::SubtractBoundedDiscrete::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 68 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("simulate", "src/distribution/SubtractBoundedDiscrete.birch", 68);
  #line 69 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(69);
  #line 69 "src/distribution/SubtractBoundedDiscrete.birch"
  if (this_()->value.query()) {
    #line 70 "src/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(70);
    #line 70 "src/distribution/SubtractBoundedDiscrete.birch"
    return birch::simulate_delta(this_()->value.get(), handler_);
  } else {
    #line 72 "src/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(72);
    #line 72 "src/distribution/SubtractBoundedDiscrete.birch"
    return birch::simulate_delta(this_()->x1->simulate(handler_) - this_()->x2->simulate(handler_), handler_);
  }
}

#line 84 "src/distribution/SubtractBoundedDiscrete.birch"
birch::type::Real birch::type::SubtractBoundedDiscrete::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 84 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("logpdf", "src/distribution/SubtractBoundedDiscrete.birch", 84);
  #line 85 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(85);
  #line 85 "src/distribution/SubtractBoundedDiscrete.birch"
  if (this_()->value.query()) {
    #line 86 "src/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(86);
    #line 86 "src/distribution/SubtractBoundedDiscrete.birch"
    return birch::logpdf_delta(x, this_()->value.get(), handler_);
  } else {
    #line 88 "src/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(88);
    #line 88 "src/distribution/SubtractBoundedDiscrete.birch"
    this_()->enumerate(x, handler_);
    #line 89 "src/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(89);
    #line 89 "src/distribution/SubtractBoundedDiscrete.birch"
    return birch::log(this_()->Z, handler_);
  }
}

#line 102 "src/distribution/SubtractBoundedDiscrete.birch"
void birch::type::SubtractBoundedDiscrete::update(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 102 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("update", "src/distribution/SubtractBoundedDiscrete.birch", 102);
  #line 103 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(103);
  #line 103 "src/distribution/SubtractBoundedDiscrete.birch"
  if (!this_()->alreadyUpdated) {
    #line 105 "src/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(105);
    #line 105 "src/distribution/SubtractBoundedDiscrete.birch"
    this_()->enumerate(x, handler_);
    #line 106 "src/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(106);
    #line 106 "src/distribution/SubtractBoundedDiscrete.birch"
    auto n = birch::simulate_categorical(this_()->z, this_()->Z, handler_) + this_()->x0 - birch::type::Integer(1);
    #line 107 "src/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(107);
    #line 107 "src/distribution/SubtractBoundedDiscrete.birch"
    this_()->x1->clamp(n, handler_);
    #line 108 "src/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(108);
    #line 108 "src/distribution/SubtractBoundedDiscrete.birch"
    this_()->x2->clamp(n - x, handler_);
    #line 109 "src/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(109);
    #line 109 "src/distribution/SubtractBoundedDiscrete.birch"
    this_()->alreadyUpdated = true;
  }
}

#line 117 "src/distribution/SubtractBoundedDiscrete.birch"
libbirch::Optional<birch::type::Real> birch::type::SubtractBoundedDiscrete::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 117 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("cdf", "src/distribution/SubtractBoundedDiscrete.birch", 117);
  #line 118 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(118);
  #line 118 "src/distribution/SubtractBoundedDiscrete.birch"
  auto P = 0.0;
  #line 119 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(119);
  #line 119 "src/distribution/SubtractBoundedDiscrete.birch"
  for (auto n = this_()->lower(handler_).get(); n <= x; ++n) {
    #line 120 "src/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(120);
    #line 120 "src/distribution/SubtractBoundedDiscrete.birch"
    P = P + this_()->pdf(n, handler_);
  }
  #line 122 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(122);
  #line 122 "src/distribution/SubtractBoundedDiscrete.birch"
  return P;
}

#line 125 "src/distribution/SubtractBoundedDiscrete.birch"
libbirch::Optional<birch::type::Integer> birch::type::SubtractBoundedDiscrete::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 125 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("lower", "src/distribution/SubtractBoundedDiscrete.birch", 125);
  #line 126 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(126);
  #line 126 "src/distribution/SubtractBoundedDiscrete.birch"
  return this_()->x1->lower(handler_).get() - this_()->x2->upper(handler_).get();
}

#line 129 "src/distribution/SubtractBoundedDiscrete.birch"
libbirch::Optional<birch::type::Integer> birch::type::SubtractBoundedDiscrete::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 129 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("upper", "src/distribution/SubtractBoundedDiscrete.birch", 129);
  #line 130 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(130);
  #line 130 "src/distribution/SubtractBoundedDiscrete.birch"
  return this_()->x1->upper(handler_).get() - this_()->x2->lower(handler_).get();
}

#line 133 "src/distribution/SubtractBoundedDiscrete.birch"
void birch::type::SubtractBoundedDiscrete::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 133 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("link", "src/distribution/SubtractBoundedDiscrete.birch", 133);
}

#line 139 "src/distribution/SubtractBoundedDiscrete.birch"
void birch::type::SubtractBoundedDiscrete::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 139 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("unlink", "src/distribution/SubtractBoundedDiscrete.birch", 139);
}

#line 146 "src/distribution/SubtractBoundedDiscrete.birch"
libbirch::Lazy<libbirch::Shared<birch::type::SubtractBoundedDiscrete>> birch::SubtractBoundedDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>& x1, const libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>& x2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 146 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("SubtractBoundedDiscrete", "src/distribution/SubtractBoundedDiscrete.birch", 146);
  #line 148 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(148);
  #line 148 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::SubtractBoundedDiscrete>> m(x1, x2);
  #line 149 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(149);
  #line 149 "src/distribution/SubtractBoundedDiscrete.birch"
  m->link(handler_);
  #line 150 "src/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(150);
  #line 150 "src/distribution/SubtractBoundedDiscrete.birch"
  return m;
}

#line 4 "src/distribution/Uniform.birch"
birch::type::Uniform::Uniform(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& l, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/Uniform.birch"
    super_type_(),
    #line 9 "src/distribution/Uniform.birch"
    l(l),
    #line 14 "src/distribution/Uniform.birch"
    u(u) {
  //
}

#line 16 "src/distribution/Uniform.birch"
birch::type::Boolean birch::type::Uniform::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/distribution/Uniform.birch"
  libbirch_function_("supportsLazy", "src/distribution/Uniform.birch", 16);
  #line 17 "src/distribution/Uniform.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/Uniform.birch"
  return false;
}

#line 20 "src/distribution/Uniform.birch"
birch::type::Real birch::type::Uniform::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/distribution/Uniform.birch"
  libbirch_function_("simulate", "src/distribution/Uniform.birch", 20);
  #line 21 "src/distribution/Uniform.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/Uniform.birch"
  return birch::simulate_uniform(this_()->l->value(handler_), this_()->u->value(handler_), handler_);
}

#line 28 "src/distribution/Uniform.birch"
birch::type::Real birch::type::Uniform::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/distribution/Uniform.birch"
  libbirch_function_("logpdf", "src/distribution/Uniform.birch", 28);
  #line 29 "src/distribution/Uniform.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/Uniform.birch"
  return birch::logpdf_uniform(x, this_()->l->value(handler_), this_()->u->value(handler_), handler_);
}

#line 36 "src/distribution/Uniform.birch"
libbirch::Optional<birch::type::Real> birch::type::Uniform::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/distribution/Uniform.birch"
  libbirch_function_("cdf", "src/distribution/Uniform.birch", 36);
  #line 37 "src/distribution/Uniform.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/Uniform.birch"
  return birch::cdf_uniform(x, this_()->l->value(handler_), this_()->u->value(handler_), handler_);
}

#line 40 "src/distribution/Uniform.birch"
libbirch::Optional<birch::type::Real> birch::type::Uniform::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "src/distribution/Uniform.birch"
  libbirch_function_("quantile", "src/distribution/Uniform.birch", 40);
  #line 41 "src/distribution/Uniform.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/Uniform.birch"
  return birch::quantile_uniform(P, this_()->l->value(handler_), this_()->u->value(handler_), handler_);
}

#line 44 "src/distribution/Uniform.birch"
libbirch::Optional<birch::type::Real> birch::type::Uniform::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/distribution/Uniform.birch"
  libbirch_function_("lower", "src/distribution/Uniform.birch", 44);
  #line 45 "src/distribution/Uniform.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/Uniform.birch"
  return this_()->l->value(handler_);
}

#line 48 "src/distribution/Uniform.birch"
libbirch::Optional<birch::type::Real> birch::type::Uniform::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "src/distribution/Uniform.birch"
  libbirch_function_("upper", "src/distribution/Uniform.birch", 48);
  #line 49 "src/distribution/Uniform.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/Uniform.birch"
  return this_()->u->value(handler_);
}

#line 52 "src/distribution/Uniform.birch"
void birch::type::Uniform::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "src/distribution/Uniform.birch"
  libbirch_function_("write", "src/distribution/Uniform.birch", 52);
  #line 53 "src/distribution/Uniform.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/Uniform.birch"
  this_()->prune(handler_);
  #line 54 "src/distribution/Uniform.birch"
  libbirch_line_(54);
  #line 54 "src/distribution/Uniform.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Uniform"), handler_);
  #line 55 "src/distribution/Uniform.birch"
  libbirch_line_(55);
  #line 55 "src/distribution/Uniform.birch"
  buffer->set(birch::type::String("l"), this_()->l, handler_);
  #line 56 "src/distribution/Uniform.birch"
  libbirch_line_(56);
  #line 56 "src/distribution/Uniform.birch"
  buffer->set(birch::type::String("u"), this_()->u, handler_);
}

#line 63 "src/distribution/Uniform.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Uniform>> birch::Uniform(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& l, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 63 "src/distribution/Uniform.birch"
  libbirch_function_("Uniform", "src/distribution/Uniform.birch", 63);
  #line 64 "src/distribution/Uniform.birch"
  libbirch_line_(64);
  #line 64 "src/distribution/Uniform.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Uniform>>>(l, u, handler_);
}

#line 70 "src/distribution/Uniform.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Uniform>> birch::Uniform(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& l, const birch::type::Real& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "src/distribution/Uniform.birch"
  libbirch_function_("Uniform", "src/distribution/Uniform.birch", 70);
  #line 71 "src/distribution/Uniform.birch"
  libbirch_line_(71);
  #line 71 "src/distribution/Uniform.birch"
  return birch::Uniform(l, birch::box(u, handler_), handler_);
}

#line 77 "src/distribution/Uniform.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Uniform>> birch::Uniform(const birch::type::Real& l, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 77 "src/distribution/Uniform.birch"
  libbirch_function_("Uniform", "src/distribution/Uniform.birch", 77);
  #line 78 "src/distribution/Uniform.birch"
  libbirch_line_(78);
  #line 78 "src/distribution/Uniform.birch"
  return birch::Uniform(birch::box(l, handler_), u, handler_);
}

#line 84 "src/distribution/Uniform.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Uniform>> birch::Uniform(const birch::type::Real& l, const birch::type::Real& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 84 "src/distribution/Uniform.birch"
  libbirch_function_("Uniform", "src/distribution/Uniform.birch", 84);
  #line 85 "src/distribution/Uniform.birch"
  libbirch_line_(85);
  #line 85 "src/distribution/Uniform.birch"
  return birch::Uniform(birch::box(l, handler_), birch::box(u, handler_), handler_);
}

#line 4 "src/distribution/UniformInteger.birch"
birch::type::UniformInteger::UniformInteger(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& l, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/UniformInteger.birch"
    super_type_(),
    #line 9 "src/distribution/UniformInteger.birch"
    l(l),
    #line 14 "src/distribution/UniformInteger.birch"
    u(u) {
  //
}

#line 16 "src/distribution/UniformInteger.birch"
birch::type::Boolean birch::type::UniformInteger::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/distribution/UniformInteger.birch"
  libbirch_function_("supportsLazy", "src/distribution/UniformInteger.birch", 16);
  #line 17 "src/distribution/UniformInteger.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/UniformInteger.birch"
  return false;
}

#line 20 "src/distribution/UniformInteger.birch"
birch::type::Integer birch::type::UniformInteger::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/distribution/UniformInteger.birch"
  libbirch_function_("simulate", "src/distribution/UniformInteger.birch", 20);
  #line 21 "src/distribution/UniformInteger.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/UniformInteger.birch"
  if (this_()->value.query()) {
    #line 22 "src/distribution/UniformInteger.birch"
    libbirch_line_(22);
    #line 22 "src/distribution/UniformInteger.birch"
    return this_()->value.get();
  } else {
    #line 24 "src/distribution/UniformInteger.birch"
    libbirch_line_(24);
    #line 24 "src/distribution/UniformInteger.birch"
    return birch::simulate_uniform_int(this_()->l->value(handler_), this_()->u->value(handler_), handler_);
  }
}

#line 36 "src/distribution/UniformInteger.birch"
birch::type::Real birch::type::UniformInteger::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/distribution/UniformInteger.birch"
  libbirch_function_("logpdf", "src/distribution/UniformInteger.birch", 36);
  #line 37 "src/distribution/UniformInteger.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/UniformInteger.birch"
  return birch::logpdf_uniform_int(x, this_()->l->value(handler_), this_()->u->value(handler_), handler_);
}

#line 44 "src/distribution/UniformInteger.birch"
libbirch::Optional<birch::type::Real> birch::type::UniformInteger::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/distribution/UniformInteger.birch"
  libbirch_function_("cdf", "src/distribution/UniformInteger.birch", 44);
  #line 45 "src/distribution/UniformInteger.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/UniformInteger.birch"
  return birch::cdf_uniform_int(x, this_()->l->value(handler_), this_()->u->value(handler_), handler_);
}

#line 48 "src/distribution/UniformInteger.birch"
libbirch::Optional<birch::type::Integer> birch::type::UniformInteger::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "src/distribution/UniformInteger.birch"
  libbirch_function_("quantile", "src/distribution/UniformInteger.birch", 48);
  #line 49 "src/distribution/UniformInteger.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/UniformInteger.birch"
  return birch::quantile_uniform_int(P, this_()->l->value(handler_), this_()->u->value(handler_), handler_);
}

#line 52 "src/distribution/UniformInteger.birch"
libbirch::Optional<birch::type::Integer> birch::type::UniformInteger::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "src/distribution/UniformInteger.birch"
  libbirch_function_("lower", "src/distribution/UniformInteger.birch", 52);
  #line 53 "src/distribution/UniformInteger.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/UniformInteger.birch"
  return this_()->l->value(handler_);
}

#line 56 "src/distribution/UniformInteger.birch"
libbirch::Optional<birch::type::Integer> birch::type::UniformInteger::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 56 "src/distribution/UniformInteger.birch"
  libbirch_function_("upper", "src/distribution/UniformInteger.birch", 56);
  #line 57 "src/distribution/UniformInteger.birch"
  libbirch_line_(57);
  #line 57 "src/distribution/UniformInteger.birch"
  return this_()->u->value(handler_);
}

#line 60 "src/distribution/UniformInteger.birch"
void birch::type::UniformInteger::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "src/distribution/UniformInteger.birch"
  libbirch_function_("write", "src/distribution/UniformInteger.birch", 60);
  #line 61 "src/distribution/UniformInteger.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/UniformInteger.birch"
  this_()->prune(handler_);
  #line 62 "src/distribution/UniformInteger.birch"
  libbirch_line_(62);
  #line 62 "src/distribution/UniformInteger.birch"
  buffer->set(birch::type::String("class"), birch::type::String("UniformInteger"), handler_);
  #line 63 "src/distribution/UniformInteger.birch"
  libbirch_line_(63);
  #line 63 "src/distribution/UniformInteger.birch"
  buffer->set(birch::type::String("l"), this_()->l, handler_);
  #line 64 "src/distribution/UniformInteger.birch"
  libbirch_line_(64);
  #line 64 "src/distribution/UniformInteger.birch"
  buffer->set(birch::type::String("u"), this_()->u, handler_);
}

#line 71 "src/distribution/UniformInteger.birch"
libbirch::Lazy<libbirch::Shared<birch::type::UniformInteger>> birch::Uniform(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& l, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 71 "src/distribution/UniformInteger.birch"
  libbirch_function_("Uniform", "src/distribution/UniformInteger.birch", 71);
  #line 73 "src/distribution/UniformInteger.birch"
  libbirch_line_(73);
  #line 73 "src/distribution/UniformInteger.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::UniformInteger>>>(l, u, handler_);
}

#line 79 "src/distribution/UniformInteger.birch"
libbirch::Lazy<libbirch::Shared<birch::type::UniformInteger>> birch::Uniform(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& l, const birch::type::Integer& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 79 "src/distribution/UniformInteger.birch"
  libbirch_function_("Uniform", "src/distribution/UniformInteger.birch", 79);
  #line 80 "src/distribution/UniformInteger.birch"
  libbirch_line_(80);
  #line 80 "src/distribution/UniformInteger.birch"
  return birch::Uniform(l, birch::box(u, handler_), handler_);
}

#line 86 "src/distribution/UniformInteger.birch"
libbirch::Lazy<libbirch::Shared<birch::type::UniformInteger>> birch::Uniform(const birch::type::Integer& l, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 86 "src/distribution/UniformInteger.birch"
  libbirch_function_("Uniform", "src/distribution/UniformInteger.birch", 86);
  #line 87 "src/distribution/UniformInteger.birch"
  libbirch_line_(87);
  #line 87 "src/distribution/UniformInteger.birch"
  return birch::Uniform(birch::box(l, handler_), u, handler_);
}

#line 93 "src/distribution/UniformInteger.birch"
libbirch::Lazy<libbirch::Shared<birch::type::UniformInteger>> birch::Uniform(const birch::type::Integer& l, const birch::type::Integer& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 93 "src/distribution/UniformInteger.birch"
  libbirch_function_("Uniform", "src/distribution/UniformInteger.birch", 93);
  #line 94 "src/distribution/UniformInteger.birch"
  libbirch_line_(94);
  #line 94 "src/distribution/UniformInteger.birch"
  return birch::Uniform(birch::box(l, handler_), birch::box(u, handler_), handler_);
}

#line 4 "src/distribution/Weibull.birch"
birch::type::Weibull::Weibull(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/Weibull.birch"
    super_type_(),
    #line 9 "src/distribution/Weibull.birch"
    k(k),
    #line 14 "src/distribution/Weibull.birch"
    _u0955(_u0955) {
  //
}

#line 16 "src/distribution/Weibull.birch"
birch::type::Boolean birch::type::Weibull::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/distribution/Weibull.birch"
  libbirch_function_("supportsLazy", "src/distribution/Weibull.birch", 16);
  #line 17 "src/distribution/Weibull.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/Weibull.birch"
  return true;
}

#line 20 "src/distribution/Weibull.birch"
birch::type::Real birch::type::Weibull::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/distribution/Weibull.birch"
  libbirch_function_("simulate", "src/distribution/Weibull.birch", 20);
  #line 21 "src/distribution/Weibull.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/Weibull.birch"
  return birch::simulate_weibull(this_()->k->value(handler_), this_()->_u0955->value(handler_), handler_);
}

#line 24 "src/distribution/Weibull.birch"
libbirch::Optional<birch::type::Real> birch::type::Weibull::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/distribution/Weibull.birch"
  libbirch_function_("simulateLazy", "src/distribution/Weibull.birch", 24);
  #line 25 "src/distribution/Weibull.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/Weibull.birch"
  return birch::simulate_weibull(this_()->k->get(handler_), this_()->_u0955->get(handler_), handler_);
}

#line 28 "src/distribution/Weibull.birch"
birch::type::Real birch::type::Weibull::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/distribution/Weibull.birch"
  libbirch_function_("logpdf", "src/distribution/Weibull.birch", 28);
  #line 29 "src/distribution/Weibull.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/Weibull.birch"
  return birch::logpdf_weibull(x, this_()->k->value(handler_), this_()->_u0955->value(handler_), handler_);
}

#line 32 "src/distribution/Weibull.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::Weibull::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/distribution/Weibull.birch"
  libbirch_function_("logpdfLazy", "src/distribution/Weibull.birch", 32);
  #line 33 "src/distribution/Weibull.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/Weibull.birch"
  return birch::logpdf_lazy_weibull(x, this_()->k, this_()->_u0955, handler_);
}

#line 36 "src/distribution/Weibull.birch"
libbirch::Optional<birch::type::Real> birch::type::Weibull::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/distribution/Weibull.birch"
  libbirch_function_("cdf", "src/distribution/Weibull.birch", 36);
  #line 37 "src/distribution/Weibull.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/Weibull.birch"
  return birch::cdf_weibull(x, this_()->k->value(handler_), this_()->_u0955->value(handler_), handler_);
}

#line 40 "src/distribution/Weibull.birch"
libbirch::Optional<birch::type::Real> birch::type::Weibull::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "src/distribution/Weibull.birch"
  libbirch_function_("quantile", "src/distribution/Weibull.birch", 40);
  #line 41 "src/distribution/Weibull.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/Weibull.birch"
  return birch::quantile_weibull(P, this_()->k->value(handler_), this_()->_u0955->value(handler_), handler_);
}

#line 44 "src/distribution/Weibull.birch"
libbirch::Optional<birch::type::Real> birch::type::Weibull::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/distribution/Weibull.birch"
  libbirch_function_("lower", "src/distribution/Weibull.birch", 44);
  #line 45 "src/distribution/Weibull.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/Weibull.birch"
  return 0.0;
}

#line 48 "src/distribution/Weibull.birch"
void birch::type::Weibull::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "src/distribution/Weibull.birch"
  libbirch_function_("write", "src/distribution/Weibull.birch", 48);
  #line 49 "src/distribution/Weibull.birch"
  libbirch_line_(49);
  #line 49 "src/distribution/Weibull.birch"
  this_()->prune(handler_);
  #line 50 "src/distribution/Weibull.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/Weibull.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Weibull"), handler_);
  #line 51 "src/distribution/Weibull.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/Weibull.birch"
  buffer->set(birch::type::String("k"), this_()->k, handler_);
  #line 52 "src/distribution/Weibull.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/Weibull.birch"
  buffer->set(birch::type::String("λ"), this_()->_u0955, handler_);
}

#line 59 "src/distribution/Weibull.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Weibull>> birch::Weibull(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/distribution/Weibull.birch"
  libbirch_function_("Weibull", "src/distribution/Weibull.birch", 59);
  #line 60 "src/distribution/Weibull.birch"
  libbirch_line_(60);
  #line 60 "src/distribution/Weibull.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Weibull>>>(k, _u0955, handler_);
}

#line 66 "src/distribution/Weibull.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Weibull>> birch::Weibull(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const birch::type::Real& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "src/distribution/Weibull.birch"
  libbirch_function_("Weibull", "src/distribution/Weibull.birch", 66);
  #line 67 "src/distribution/Weibull.birch"
  libbirch_line_(67);
  #line 67 "src/distribution/Weibull.birch"
  return birch::Weibull(k, birch::box(_u0955, handler_), handler_);
}

#line 73 "src/distribution/Weibull.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Weibull>> birch::Weibull(const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 73 "src/distribution/Weibull.birch"
  libbirch_function_("Weibull", "src/distribution/Weibull.birch", 73);
  #line 74 "src/distribution/Weibull.birch"
  libbirch_line_(74);
  #line 74 "src/distribution/Weibull.birch"
  return birch::Weibull(birch::box(k, handler_), _u0955, handler_);
}

#line 80 "src/distribution/Weibull.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Weibull>> birch::Weibull(const birch::type::Real& k, const birch::type::Real& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 80 "src/distribution/Weibull.birch"
  libbirch_function_("Weibull", "src/distribution/Weibull.birch", 80);
  #line 81 "src/distribution/Weibull.birch"
  libbirch_line_(81);
  #line 81 "src/distribution/Weibull.birch"
  return birch::Weibull(birch::box(k, handler_), birch::box(_u0955, handler_), handler_);
}

#line 4 "src/distribution/Wishart.birch"
birch::type::Wishart::Wishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/distribution/Wishart.birch"
    super_type_(),
    #line 9 "src/distribution/Wishart.birch"
    _u0936(_u0936),
    #line 14 "src/distribution/Wishart.birch"
    k(k) {
  //
}

#line 16 "src/distribution/Wishart.birch"
birch::type::Integer birch::type::Wishart::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/distribution/Wishart.birch"
  libbirch_function_("rows", "src/distribution/Wishart.birch", 16);
  #line 17 "src/distribution/Wishart.birch"
  libbirch_line_(17);
  #line 17 "src/distribution/Wishart.birch"
  return this_()->_u0936->rows(handler_);
}

#line 20 "src/distribution/Wishart.birch"
birch::type::Integer birch::type::Wishart::columns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/distribution/Wishart.birch"
  libbirch_function_("columns", "src/distribution/Wishart.birch", 20);
  #line 21 "src/distribution/Wishart.birch"
  libbirch_line_(21);
  #line 21 "src/distribution/Wishart.birch"
  return this_()->_u0936->columns(handler_);
}

#line 24 "src/distribution/Wishart.birch"
birch::type::Boolean birch::type::Wishart::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/distribution/Wishart.birch"
  libbirch_function_("supportsLazy", "src/distribution/Wishart.birch", 24);
  #line 25 "src/distribution/Wishart.birch"
  libbirch_line_(25);
  #line 25 "src/distribution/Wishart.birch"
  return true;
}

#line 28 "src/distribution/Wishart.birch"
birch::type::LLT birch::type::Wishart::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/distribution/Wishart.birch"
  libbirch_function_("simulate", "src/distribution/Wishart.birch", 28);
  #line 29 "src/distribution/Wishart.birch"
  libbirch_line_(29);
  #line 29 "src/distribution/Wishart.birch"
  return birch::simulate_wishart(this_()->_u0936->value(handler_), this_()->k->value(handler_), handler_);
}

#line 32 "src/distribution/Wishart.birch"
libbirch::Optional<birch::type::LLT> birch::type::Wishart::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/distribution/Wishart.birch"
  libbirch_function_("simulateLazy", "src/distribution/Wishart.birch", 32);
  #line 33 "src/distribution/Wishart.birch"
  libbirch_line_(33);
  #line 33 "src/distribution/Wishart.birch"
  return birch::simulate_wishart(this_()->_u0936->get(handler_), this_()->k->get(handler_), handler_);
}

#line 36 "src/distribution/Wishart.birch"
birch::type::Real birch::type::Wishart::logpdf(const birch::type::LLT& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/distribution/Wishart.birch"
  libbirch_function_("logpdf", "src/distribution/Wishart.birch", 36);
  #line 37 "src/distribution/Wishart.birch"
  libbirch_line_(37);
  #line 37 "src/distribution/Wishart.birch"
  return birch::logpdf_wishart(X, this_()->_u0936->value(handler_), this_()->k->value(handler_), handler_);
}

#line 40 "src/distribution/Wishart.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::Wishart::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "src/distribution/Wishart.birch"
  libbirch_function_("logpdfLazy", "src/distribution/Wishart.birch", 40);
  #line 41 "src/distribution/Wishart.birch"
  libbirch_line_(41);
  #line 41 "src/distribution/Wishart.birch"
  return birch::logpdf_lazy_wishart(X, this_()->_u0936, this_()->k, handler_);
}

#line 44 "src/distribution/Wishart.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Wishart>>> birch::type::Wishart::graftWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/distribution/Wishart.birch"
  libbirch_function_("graftWishart", "src/distribution/Wishart.birch", 44);
  #line 45 "src/distribution/Wishart.birch"
  libbirch_line_(45);
  #line 45 "src/distribution/Wishart.birch"
  this_()->prune(handler_);
  #line 46 "src/distribution/Wishart.birch"
  libbirch_line_(46);
  #line 46 "src/distribution/Wishart.birch"
  return shared_from_this_();
}

#line 49 "src/distribution/Wishart.birch"
void birch::type::Wishart::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/distribution/Wishart.birch"
  libbirch_function_("write", "src/distribution/Wishart.birch", 49);
  #line 50 "src/distribution/Wishart.birch"
  libbirch_line_(50);
  #line 50 "src/distribution/Wishart.birch"
  this_()->prune(handler_);
  #line 51 "src/distribution/Wishart.birch"
  libbirch_line_(51);
  #line 51 "src/distribution/Wishart.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Wishart"), handler_);
  #line 52 "src/distribution/Wishart.birch"
  libbirch_line_(52);
  #line 52 "src/distribution/Wishart.birch"
  buffer->set(birch::type::String("Ψ"), this_()->_u0936, handler_);
  #line 53 "src/distribution/Wishart.birch"
  libbirch_line_(53);
  #line 53 "src/distribution/Wishart.birch"
  buffer->set(birch::type::String("k"), this_()->k, handler_);
}

#line 60 "src/distribution/Wishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Wishart>> birch::Wishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "src/distribution/Wishart.birch"
  libbirch_function_("Wishart", "src/distribution/Wishart.birch", 60);
  #line 61 "src/distribution/Wishart.birch"
  libbirch_line_(61);
  #line 61 "src/distribution/Wishart.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Wishart>>>(_u0936, k, handler_);
}

#line 67 "src/distribution/Wishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Wishart>> birch::Wishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 67 "src/distribution/Wishart.birch"
  libbirch_function_("Wishart", "src/distribution/Wishart.birch", 67);
  #line 68 "src/distribution/Wishart.birch"
  libbirch_line_(68);
  #line 68 "src/distribution/Wishart.birch"
  return birch::Wishart(_u0936, birch::box(k, handler_), handler_);
}

#line 74 "src/distribution/Wishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Wishart>> birch::Wishart(const birch::type::LLT& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 74 "src/distribution/Wishart.birch"
  libbirch_function_("Wishart", "src/distribution/Wishart.birch", 74);
  #line 75 "src/distribution/Wishart.birch"
  libbirch_line_(75);
  #line 75 "src/distribution/Wishart.birch"
  return birch::Wishart(birch::box(_u0936, handler_), k, handler_);
}

#line 81 "src/distribution/Wishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Wishart>> birch::Wishart(const birch::type::LLT& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "src/distribution/Wishart.birch"
  libbirch_function_("Wishart", "src/distribution/Wishart.birch", 81);
  #line 82 "src/distribution/Wishart.birch"
  libbirch_line_(82);
  #line 82 "src/distribution/Wishart.birch"
  return birch::Wishart(birch::box(_u0936, handler_), birch::box(k, handler_), handler_);
}

#line 88 "src/distribution/Wishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Wishart>> birch::Wishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 88 "src/distribution/Wishart.birch"
  libbirch_function_("Wishart", "src/distribution/Wishart.birch", 88);
  #line 89 "src/distribution/Wishart.birch"
  libbirch_line_(89);
  #line 89 "src/distribution/Wishart.birch"
  return birch::Wishart(birch::llt(_u0936, handler_), k, handler_);
}

#line 95 "src/distribution/Wishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Wishart>> birch::Wishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "src/distribution/Wishart.birch"
  libbirch_function_("Wishart", "src/distribution/Wishart.birch", 95);
  #line 96 "src/distribution/Wishart.birch"
  libbirch_line_(96);
  #line 96 "src/distribution/Wishart.birch"
  return birch::Wishart(birch::llt(_u0936, handler_), k, handler_);
}

#line 102 "src/distribution/Wishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Wishart>> birch::Wishart(const libbirch::DefaultArray<birch::type::Real,2>& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 102 "src/distribution/Wishart.birch"
  libbirch_function_("Wishart", "src/distribution/Wishart.birch", 102);
  #line 103 "src/distribution/Wishart.birch"
  libbirch_line_(103);
  #line 103 "src/distribution/Wishart.birch"
  return birch::Wishart(birch::llt(_u0936, handler_), k, handler_);
}

#line 109 "src/distribution/Wishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Wishart>> birch::Wishart(const libbirch::DefaultArray<birch::type::Real,2>& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 109 "src/distribution/Wishart.birch"
  libbirch_function_("Wishart", "src/distribution/Wishart.birch", 109);
  #line 110 "src/distribution/Wishart.birch"
  libbirch_line_(110);
  #line 110 "src/distribution/Wishart.birch"
  return birch::Wishart(birch::llt(_u0936, handler_), k, handler_);
}

