#line 1 "src/particle/ConditionalParticle.birch"
birch::type::ConditionalParticle::ConditionalParticle(const libbirch::Shared<birch::type::Model>& m) :
    #line 1 "src/particle/ConditionalParticle.birch"
    base_type_(m),
    #line 20 "src/particle/ConditionalParticle.birch"
    trace(libbirch::make<libbirch::Shared<birch::type::Tape<libbirch::Shared<birch::type::Record>>>>()) {
  //
}

#line 26 "src/particle/ConditionalParticle.birch"
libbirch::Shared<birch::type::ConditionalParticle> birch::ConditionalParticle(const libbirch::Shared<birch::type::Model>& m) {
  #line 26 "src/particle/ConditionalParticle.birch"
  libbirch_function_("ConditionalParticle", "src/particle/ConditionalParticle.birch", 26);
  #line 27 "src/particle/ConditionalParticle.birch"
  libbirch_line_(27);
  #line 27 "src/particle/ConditionalParticle.birch"
  return birch::construct<libbirch::Shared<birch::type::ConditionalParticle>>(m);
}

#line 1 "src/particle/MoveParticle.birch"
birch::type::MoveParticle::MoveParticle(const libbirch::Shared<birch::type::Model>& m) :
    #line 1 "src/particle/MoveParticle.birch"
    base_type_(m),
    #line 20 "src/particle/MoveParticle.birch"
    zs(libbirch::make<libbirch::Shared<birch::type::Array<libbirch::Shared<birch::type::Expression<birch::type::Real>>>>>()),
    #line 26 "src/particle/MoveParticle.birch"
    ps(libbirch::make<libbirch::Shared<birch::type::Array<libbirch::Shared<birch::type::Expression<birch::type::Real>>>>>()),
    #line 31 "src/particle/MoveParticle.birch"
    π(0.0) {
  //
}

#line 36 "src/particle/MoveParticle.birch"
birch::type::Integer birch::type::MoveParticle::size() {
  #line 36 "src/particle/MoveParticle.birch"
  libbirch_function_("size", "src/particle/MoveParticle.birch", 36);
  #line 37 "src/particle/MoveParticle.birch"
  libbirch_line_(37);
  #line 37 "src/particle/MoveParticle.birch"
  return this->zs->size();
}

#line 48 "src/particle/MoveParticle.birch"
birch::type::Real birch::type::MoveParticle::augment(const birch::type::Integer& t, const std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& z) {
  #line 48 "src/particle/MoveParticle.birch"
  libbirch_function_("augment", "src/particle/MoveParticle.birch", 48);
  #line 50 "src/particle/MoveParticle.birch"
  libbirch_line_(50);
  #line 50 "src/particle/MoveParticle.birch"
  auto z_prime_ = z;
  #line 51 "src/particle/MoveParticle.birch"
  libbirch_line_(51);
  #line 51 "src/particle/MoveParticle.birch"
  if (!(z_prime_.has_value())) {
    #line 52 "src/particle/MoveParticle.birch"
    libbirch_line_(52);
    #line 52 "src/particle/MoveParticle.birch"
    z_prime_ = birch::box(0.0);
  }
  #line 54 "src/particle/MoveParticle.birch"
  libbirch_line_(54);
  #line 54 "src/particle/MoveParticle.birch"
  auto w = z_prime_.value()->pilot(t);
  #line 55 "src/particle/MoveParticle.birch"
  libbirch_line_(55);
  #line 55 "src/particle/MoveParticle.birch"
  this->π = this->π + w;
  #line 56 "src/particle/MoveParticle.birch"
  libbirch_line_(56);
  #line 56 "src/particle/MoveParticle.birch"
  this->zs->pushBack(z_prime_.value());
  #line 59 "src/particle/MoveParticle.birch"
  libbirch_line_(59);
  #line 59 "src/particle/MoveParticle.birch"
  auto p = z_prime_.value()->prior();
  #line 60 "src/particle/MoveParticle.birch"
  libbirch_line_(60);
  #line 60 "src/particle/MoveParticle.birch"
  if (!(p.has_value())) {
    #line 61 "src/particle/MoveParticle.birch"
    libbirch_line_(61);
    #line 61 "src/particle/MoveParticle.birch"
    p = birch::box(0.0);
  }
  #line 63 "src/particle/MoveParticle.birch"
  libbirch_line_(63);
  #line 63 "src/particle/MoveParticle.birch"
  this->π = this->π + p.value()->pilot(t);
  #line 64 "src/particle/MoveParticle.birch"
  libbirch_line_(64);
  #line 64 "src/particle/MoveParticle.birch"
  this->ps->pushBack(p.value());
  #line 66 "src/particle/MoveParticle.birch"
  libbirch_line_(66);
  #line 66 "src/particle/MoveParticle.birch"
  return w;
}

#line 72 "src/particle/MoveParticle.birch"
void birch::type::MoveParticle::truncate() {
  #line 72 "src/particle/MoveParticle.birch"
  libbirch_function_("truncate", "src/particle/MoveParticle.birch", 72);
  #line 76 "src/particle/MoveParticle.birch"
  libbirch_line_(76);
  #line 76 "src/particle/MoveParticle.birch"
  if (!(this->zs->empty())) {
    #line 77 "src/particle/MoveParticle.birch"
    libbirch_line_(77);
    #line 77 "src/particle/MoveParticle.birch"
    this->π = this->π - this->zs->front()->get();
    #line 78 "src/particle/MoveParticle.birch"
    libbirch_line_(78);
    #line 78 "src/particle/MoveParticle.birch"
    this->zs->popFront();
  }
  #line 80 "src/particle/MoveParticle.birch"
  libbirch_line_(80);
  #line 80 "src/particle/MoveParticle.birch"
  if (!(this->ps->empty())) {
    #line 81 "src/particle/MoveParticle.birch"
    libbirch_line_(81);
    #line 81 "src/particle/MoveParticle.birch"
    this->π = this->π - this->ps->front()->get();
    #line 82 "src/particle/MoveParticle.birch"
    libbirch_line_(82);
    #line 82 "src/particle/MoveParticle.birch"
    this->ps->popFront();
  }
}

#line 89 "src/particle/MoveParticle.birch"
void birch::type::MoveParticle::grad(const birch::type::Integer& gen) {
  #line 89 "src/particle/MoveParticle.birch"
  libbirch_function_("grad", "src/particle/MoveParticle.birch", 89);
  #line 90 "src/particle/MoveParticle.birch"
  libbirch_line_(90);
  #line 90 "src/particle/MoveParticle.birch"
  auto L = this->size();
  #line 91 "src/particle/MoveParticle.birch"
  libbirch_line_(91);
  #line 91 "src/particle/MoveParticle.birch"
  for (auto l = birch::type::Integer(1); l <= L; ++l) {
    #line 92 "src/particle/MoveParticle.birch"
    libbirch_line_(92);
    #line 92 "src/particle/MoveParticle.birch"
    this->zs->get(l)->grad(gen, 1.0);
    #line 93 "src/particle/MoveParticle.birch"
    libbirch_line_(93);
    #line 93 "src/particle/MoveParticle.birch"
    this->ps->get(l)->grad(gen, 1.0);
  }
}

#line 103 "src/particle/MoveParticle.birch"
void birch::type::MoveParticle::move(const birch::type::Integer& gen, const libbirch::Shared<birch::type::Kernel>& κ) {
  #line 103 "src/particle/MoveParticle.birch"
  libbirch_function_("move", "src/particle/MoveParticle.birch", 103);
  #line 104 "src/particle/MoveParticle.birch"
  libbirch_line_(104);
  #line 104 "src/particle/MoveParticle.birch"
  auto L = this->size();
  #line 105 "src/particle/MoveParticle.birch"
  libbirch_line_(105);
  #line 105 "src/particle/MoveParticle.birch"
  auto π = 0.0;
  #line 106 "src/particle/MoveParticle.birch"
  libbirch_line_(106);
  #line 106 "src/particle/MoveParticle.birch"
  for (auto l = birch::type::Integer(1); l <= L; ++l) {
    #line 107 "src/particle/MoveParticle.birch"
    libbirch_line_(107);
    #line 107 "src/particle/MoveParticle.birch"
    π = π + this->zs->get(l)->move(gen, κ);
    #line 108 "src/particle/MoveParticle.birch"
    libbirch_line_(108);
    #line 108 "src/particle/MoveParticle.birch"
    π = π + this->ps->get(l)->move(gen, κ);
  }
  #line 110 "src/particle/MoveParticle.birch"
  libbirch_line_(110);
  #line 110 "src/particle/MoveParticle.birch"
  this->π = π;
}

#line 122 "src/particle/MoveParticle.birch"
birch::type::Real birch::type::MoveParticle::compare(const birch::type::Integer& gen, const libbirch::Shared<birch::type::MoveParticle>& x, const libbirch::Shared<birch::type::Kernel>& κ) {
  #line 122 "src/particle/MoveParticle.birch"
  libbirch_function_("compare", "src/particle/MoveParticle.birch", 122);
  #line 123 "src/particle/MoveParticle.birch"
  libbirch_line_(123);
  #line 123 "src/particle/MoveParticle.birch"
  libbirch_assert_(this->size() == x->size());
  #line 124 "src/particle/MoveParticle.birch"
  libbirch_line_(124);
  #line 124 "src/particle/MoveParticle.birch"
  auto L = this->size();
  #line 125 "src/particle/MoveParticle.birch"
  libbirch_line_(125);
  #line 125 "src/particle/MoveParticle.birch"
  auto w = 0.0;
  #line 126 "src/particle/MoveParticle.birch"
  libbirch_line_(126);
  #line 126 "src/particle/MoveParticle.birch"
  for (auto l = birch::type::Integer(1); l <= L; ++l) {
    #line 127 "src/particle/MoveParticle.birch"
    libbirch_line_(127);
    #line 127 "src/particle/MoveParticle.birch"
    w = w + this->zs->get(l)->compare(gen, x->zs->get(l), κ);
    #line 128 "src/particle/MoveParticle.birch"
    libbirch_line_(128);
    #line 128 "src/particle/MoveParticle.birch"
    w = w + this->ps->get(l)->compare(gen, x->ps->get(l), κ);
  }
  #line 130 "src/particle/MoveParticle.birch"
  libbirch_line_(130);
  #line 130 "src/particle/MoveParticle.birch"
  return w;
}

#line 137 "src/particle/MoveParticle.birch"
libbirch::Shared<birch::type::MoveParticle> birch::MoveParticle(const libbirch::Shared<birch::type::Model>& m) {
  #line 137 "src/particle/MoveParticle.birch"
  libbirch_function_("MoveParticle", "src/particle/MoveParticle.birch", 137);
  #line 138 "src/particle/MoveParticle.birch"
  libbirch_line_(138);
  #line 138 "src/particle/MoveParticle.birch"
  return birch::construct<libbirch::Shared<birch::type::MoveParticle>>(m);
}

#line 1 "src/particle/Particle.birch"
birch::type::Particle::Particle(const libbirch::Shared<birch::type::Model>& m) :
    #line 1 "src/particle/Particle.birch"
    base_type_(),
    #line 19 "src/particle/Particle.birch"
    m(std::move(m)) {
  //
}

#line 21 "src/particle/Particle.birch"
void birch::type::Particle::read(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 21 "src/particle/Particle.birch"
  libbirch_function_("read", "src/particle/Particle.birch", 21);
  #line 22 "src/particle/Particle.birch"
  libbirch_line_(22);
  #line 22 "src/particle/Particle.birch"
  this->m->read(buffer);
}

#line 25 "src/particle/Particle.birch"
void birch::type::Particle::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 25 "src/particle/Particle.birch"
  libbirch_function_("write", "src/particle/Particle.birch", 25);
  #line 26 "src/particle/Particle.birch"
  libbirch_line_(26);
  #line 26 "src/particle/Particle.birch"
  this->m->write(buffer);
}

#line 29 "src/particle/Particle.birch"
void birch::type::Particle::read(const birch::type::Integer& t, const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 29 "src/particle/Particle.birch"
  libbirch_function_("read", "src/particle/Particle.birch", 29);
  #line 30 "src/particle/Particle.birch"
  libbirch_line_(30);
  #line 30 "src/particle/Particle.birch"
  this->m->read(t, buffer);
}

#line 33 "src/particle/Particle.birch"
void birch::type::Particle::write(const birch::type::Integer& t, const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 33 "src/particle/Particle.birch"
  libbirch_function_("write", "src/particle/Particle.birch", 33);
  #line 34 "src/particle/Particle.birch"
  libbirch_line_(34);
  #line 34 "src/particle/Particle.birch"
  this->m->write(t, buffer);
}

#line 41 "src/particle/Particle.birch"
libbirch::Shared<birch::type::Particle> birch::Particle(const libbirch::Shared<birch::type::Model>& m) {
  #line 41 "src/particle/Particle.birch"
  libbirch_function_("Particle", "src/particle/Particle.birch", 41);
  #line 42 "src/particle/Particle.birch"
  libbirch_line_(42);
  #line 42 "src/particle/Particle.birch"
  return birch::construct<libbirch::Shared<birch::type::Particle>>(m);
}

