#line 13 "src/handler/Handler.birch"
birch::type::Handler::Handler(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 13 "src/handler/Handler.birch"
    super_type_(),
    #line 17 "src/handler/Handler.birch"
    input(),
    #line 22 "src/handler/Handler.birch"
    output(),
    #line 27 "src/handler/Handler.birch"
    w(0.0) {
  //
}

#line 37 "src/handler/Handler.birch"
void birch::type::Handler::handle(const libbirch::Lazy<libbirch::Shared<birch::type::Event>>& event, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/handler/Handler.birch"
  libbirch_function_("handle", "src/handler/Handler.birch", 37);
  #line 38 "src/handler/Handler.birch"
  libbirch_line_(38);
  #line 38 "src/handler/Handler.birch"
  if (this_()->input.query()) {
    #line 39 "src/handler/Handler.birch"
    libbirch_line_(39);
    #line 39 "src/handler/Handler.birch"
    this_()->doHandle(this_()->input.get()->current(handler_), event, handler_);
    #line 40 "src/handler/Handler.birch"
    libbirch_line_(40);
    #line 40 "src/handler/Handler.birch"
    this_()->input.get()->next(handler_);
  } else {
    #line 42 "src/handler/Handler.birch"
    libbirch_line_(42);
    #line 42 "src/handler/Handler.birch"
    this_()->doHandle(event, handler_);
  }
  #line 44 "src/handler/Handler.birch"
  libbirch_line_(44);
  #line 44 "src/handler/Handler.birch"
  if (this_()->output.query()) {
    #line 45 "src/handler/Handler.birch"
    libbirch_line_(45);
    #line 45 "src/handler/Handler.birch"
    this_()->output.get()->pushBack(event->record(handler_), handler_);
  }
}

#line 1 "src/handler/MoveHandler.birch"
birch::type::MoveHandler::MoveHandler(const birch::type::Boolean& delayed, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/handler/MoveHandler.birch"
    super_type_(),
    #line 19 "src/handler/MoveHandler.birch"
    delayed(delayed),
    #line 24 "src/handler/MoveHandler.birch"
    z() {
  //
}

#line 26 "src/handler/MoveHandler.birch"
void birch::type::MoveHandler::doHandle(const libbirch::Lazy<libbirch::Shared<birch::type::Event>>& event, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/handler/MoveHandler.birch"
  libbirch_function_("doHandle", "src/handler/MoveHandler.birch", 26);
  #line 28 "src/handler/MoveHandler.birch"
  libbirch_line_(28);
  #line 28 "src/handler/MoveHandler.birch"
  event->accept(shared_from_this_(), handler_);
}

#line 31 "src/handler/MoveHandler.birch"
void birch::type::MoveHandler::doHandle(const libbirch::Lazy<libbirch::Shared<birch::type::Record>>& record, const libbirch::Lazy<libbirch::Shared<birch::type::Event>>& event, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "src/handler/MoveHandler.birch"
  libbirch_function_("doHandle", "src/handler/MoveHandler.birch", 31);
  #line 33 "src/handler/MoveHandler.birch"
  libbirch_line_(33);
  #line 33 "src/handler/MoveHandler.birch"
  event->accept(record, shared_from_this_(), handler_);
}

#line 81 "src/handler/MoveHandler.birch"
void birch::type::MoveHandler::doHandle(const libbirch::Lazy<libbirch::Shared<birch::type::FactorEvent>>& event, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "src/handler/MoveHandler.birch"
  libbirch_function_("doHandle", "src/handler/MoveHandler.birch", 81);
  #line 82 "src/handler/MoveHandler.birch"
  libbirch_line_(82);
  #line 82 "src/handler/MoveHandler.birch"
  if (this_()->z.query()) {
    #line 83 "src/handler/MoveHandler.birch"
    libbirch_line_(83);
    #line 83 "src/handler/MoveHandler.birch"
    this_()->z = this_()->z.get() + event->w;
  } else {
    #line 85 "src/handler/MoveHandler.birch"
    libbirch_line_(85);
    #line 85 "src/handler/MoveHandler.birch"
    this_()->z = event->w;
  }
}

#line 137 "src/handler/MoveHandler.birch"
void birch::type::MoveHandler::doHandle(const libbirch::Lazy<libbirch::Shared<birch::type::FactorRecord>>& record, const libbirch::Lazy<libbirch::Shared<birch::type::FactorEvent>>& event, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 137 "src/handler/MoveHandler.birch"
  libbirch_function_("doHandle", "src/handler/MoveHandler.birch", 137);
  #line 139 "src/handler/MoveHandler.birch"
  libbirch_line_(139);
  #line 139 "src/handler/MoveHandler.birch"
  this_()->doHandle(event, handler_);
}

#line 146 "src/handler/MoveHandler.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MoveHandler>> birch::MoveHandler(const birch::type::Boolean& delayed, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 146 "src/handler/MoveHandler.birch"
  libbirch_function_("MoveHandler", "src/handler/MoveHandler.birch", 146);
  #line 147 "src/handler/MoveHandler.birch"
  libbirch_line_(147);
  #line 147 "src/handler/MoveHandler.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MoveHandler>>>(delayed, handler_);
}

#line 1 "src/handler/PlayHandler.birch"
birch::type::PlayHandler::PlayHandler(const birch::type::Boolean& delayed, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/handler/PlayHandler.birch"
    super_type_(),
    #line 19 "src/handler/PlayHandler.birch"
    delayed(delayed) {
  //
}

#line 21 "src/handler/PlayHandler.birch"
void birch::type::PlayHandler::doHandle(const libbirch::Lazy<libbirch::Shared<birch::type::Event>>& event, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "src/handler/PlayHandler.birch"
  libbirch_function_("doHandle", "src/handler/PlayHandler.birch", 21);
  #line 23 "src/handler/PlayHandler.birch"
  libbirch_line_(23);
  #line 23 "src/handler/PlayHandler.birch"
  event->accept(shared_from_this_(), handler_);
}

#line 26 "src/handler/PlayHandler.birch"
void birch::type::PlayHandler::doHandle(const libbirch::Lazy<libbirch::Shared<birch::type::Record>>& record, const libbirch::Lazy<libbirch::Shared<birch::type::Event>>& event, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/handler/PlayHandler.birch"
  libbirch_function_("doHandle", "src/handler/PlayHandler.birch", 26);
  #line 28 "src/handler/PlayHandler.birch"
  libbirch_line_(28);
  #line 28 "src/handler/PlayHandler.birch"
  event->accept(record, shared_from_this_(), handler_);
}

#line 56 "src/handler/PlayHandler.birch"
void birch::type::PlayHandler::doHandle(const libbirch::Lazy<libbirch::Shared<birch::type::FactorEvent>>& event, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 56 "src/handler/PlayHandler.birch"
  libbirch_function_("doHandle", "src/handler/PlayHandler.birch", 56);
  #line 57 "src/handler/PlayHandler.birch"
  libbirch_line_(57);
  #line 57 "src/handler/PlayHandler.birch"
  this_()->w = this_()->w + event->w->value(handler_);
}

#line 98 "src/handler/PlayHandler.birch"
void birch::type::PlayHandler::doHandle(const libbirch::Lazy<libbirch::Shared<birch::type::FactorRecord>>& record, const libbirch::Lazy<libbirch::Shared<birch::type::FactorEvent>>& event, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 98 "src/handler/PlayHandler.birch"
  libbirch_function_("doHandle", "src/handler/PlayHandler.birch", 98);
  #line 100 "src/handler/PlayHandler.birch"
  libbirch_line_(100);
  #line 100 "src/handler/PlayHandler.birch"
  this_()->w = this_()->w + event->w->value(handler_);
}

#line 107 "src/handler/PlayHandler.birch"
libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> birch::PlayHandler(const birch::type::Boolean& delayed, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 107 "src/handler/PlayHandler.birch"
  libbirch_function_("PlayHandler", "src/handler/PlayHandler.birch", 107);
  #line 108 "src/handler/PlayHandler.birch"
  libbirch_line_(108);
  #line 108 "src/handler/PlayHandler.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>>>(delayed, handler_);
}

