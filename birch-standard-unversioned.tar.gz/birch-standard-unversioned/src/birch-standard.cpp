#line 22 "src/filter.birch"
int birch::filter(int argc_, char** argv_) {
  #line 22 "src/filter.birch"
  libbirch_function_("filter", "src/filter.birch", 22);
  #line 22 "src/filter.birch"
  libbirch::Optional<birch::type::String> config;
  #line 22 "src/filter.birch"
  libbirch::Optional<birch::type::String> input;
  #line 22 "src/filter.birch"
  libbirch::Optional<birch::type::String> output;
  #line 22 "src/filter.birch"
  libbirch::Optional<birch::type::String> model;
  #line 22 "src/filter.birch"
  libbirch::Optional<birch::type::Integer> seed;
  #line 22 "src/filter.birch"
  birch::type::Boolean quiet = false;
  
  enum {
    configFLAG_,
    inputFLAG_,
    outputFLAG_,
    modelFLAG_,
    seedFLAG_,
    quietFLAG_,
  };
  #line 22 "src/filter.birch"
  int c_, option_index_;
  #line 22 "src/filter.birch"
  option long_options_[] = {
    #line 22 "src/filter.birch"
    {"config", required_argument, 0, configFLAG_ },
    #line 22 "src/filter.birch"
    {"input", required_argument, 0, inputFLAG_ },
    #line 22 "src/filter.birch"
    {"output", required_argument, 0, outputFLAG_ },
    #line 22 "src/filter.birch"
    {"model", required_argument, 0, modelFLAG_ },
    #line 22 "src/filter.birch"
    {"seed", required_argument, 0, seedFLAG_ },
    #line 22 "src/filter.birch"
    {"quiet", required_argument, 0, quietFLAG_ },
    #line 22 "src/filter.birch"
    {0, 0, 0, 0}
  #line 22 "src/filter.birch"
  };
  #line 22 "src/filter.birch"
  const char* short_options_ = ":";
  #line 22 "src/filter.birch"
  ::opterr = 0;
  #line 22 "src/filter.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 22 "src/filter.birch"
  while (c_ != -1) {
    #line 22 "src/filter.birch"
    switch (c_) {
      #line 23 "src/filter.birch"
      case configFLAG_:
        #line 23 "src/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 23 "src/filter.birch"
        config = birch::String(std::string(::optarg));
        break;
      #line 24 "src/filter.birch"
      case inputFLAG_:
        #line 24 "src/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 24 "src/filter.birch"
        input = birch::String(std::string(::optarg));
        break;
      #line 25 "src/filter.birch"
      case outputFLAG_:
        #line 25 "src/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 25 "src/filter.birch"
        output = birch::String(std::string(::optarg));
        break;
      #line 26 "src/filter.birch"
      case modelFLAG_:
        #line 26 "src/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 26 "src/filter.birch"
        model = birch::String(std::string(::optarg));
        break;
      #line 27 "src/filter.birch"
      case seedFLAG_:
        #line 27 "src/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 27 "src/filter.birch"
        seed = birch::Integer(std::string(::optarg));
        break;
      #line 28 "src/filter.birch"
      case quietFLAG_:
        #line 28 "src/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 28 "src/filter.birch"
        quiet = birch::Boolean(std::string(::optarg));
        break;
      #line 22 "src/filter.birch"
      case '?':
        #line 22 "src/filter.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 22 "src/filter.birch"
      case ':':
        #line 22 "src/filter.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 22 "src/filter.birch"
      default:
        #line 22 "src/filter.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 22 "src/filter.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 30 "src/filter.birch"
  libbirch_line_(30);
  #line 30 "src/filter.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> configBuffer;
  #line 31 "src/filter.birch"
  libbirch_line_(31);
  #line 31 "src/filter.birch"
  if (config.query()) {
    #line 32 "src/filter.birch"
    libbirch_line_(32);
    #line 32 "src/filter.birch"
    auto reader = birch::Reader(config.get(), handler_);
    #line 33 "src/filter.birch"
    libbirch_line_(33);
    #line 33 "src/filter.birch"
    configBuffer = reader->slurp(handler_);
    #line 34 "src/filter.birch"
    libbirch_line_(34);
    #line 34 "src/filter.birch"
    reader->close(handler_);
  }
  #line 38 "src/filter.birch"
  libbirch_line_(38);
  #line 38 "src/filter.birch"
  if (seed.query()) {
    #line 39 "src/filter.birch"
    libbirch_line_(39);
    #line 39 "src/filter.birch"
    birch::seed(seed.get(), handler_);
  } else {
    #line 40 "src/filter.birch"
    libbirch_line_(40);
    #line 40 "src/filter.birch"
    if (config.query()) {
      #line 41 "src/filter.birch"
      libbirch_line_(41);
      #line 41 "src/filter.birch"
      auto buffer = configBuffer->getInteger(birch::type::String("seed"), handler_);
      #line 42 "src/filter.birch"
      libbirch_line_(42);
      #line 42 "src/filter.birch"
      if (buffer.query()) {
        #line 43 "src/filter.birch"
        libbirch_line_(43);
        #line 43 "src/filter.birch"
        birch::seed(buffer.get(), handler_);
      }
    } else {
      #line 46 "src/filter.birch"
      libbirch_line_(46);
      #line 46 "src/filter.birch"
      birch::seed(handler_);
    }
  }
  #line 50 "src/filter.birch"
  libbirch_line_(50);
  #line 50 "src/filter.birch"
  auto buffer = configBuffer->find(birch::type::String("model"), handler_);
  #line 51 "src/filter.birch"
  libbirch_line_(51);
  #line 51 "src/filter.birch"
  if (!buffer.query()) {
    #line 52 "src/filter.birch"
    libbirch_line_(52);
    #line 52 "src/filter.birch"
    buffer = birch::Buffer(handler_);
  }
  #line 54 "src/filter.birch"
  libbirch_line_(54);
  #line 54 "src/filter.birch"
  if (!buffer.get()->getString(birch::type::String("class"), handler_).query() && model.query()) {
    #line 55 "src/filter.birch"
    libbirch_line_(55);
    #line 55 "src/filter.birch"
    buffer.get()->set(birch::type::String("class"), model.get(), handler_);
  }
  #line 57 "src/filter.birch"
  libbirch_line_(57);
  #line 57 "src/filter.birch"
  auto archetype = libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::Model>>>(birch::make(buffer, handler_));
  #line 58 "src/filter.birch"
  libbirch_line_(58);
  #line 58 "src/filter.birch"
  if (!archetype.query()) {
    #line 59 "src/filter.birch"
    libbirch_line_(59);
    #line 59 "src/filter.birch"
    birch::error(birch::type::String("could not create model; the model class should be given as ") + birch::type::String("model.class in the config file, and should derive from Model."), handler_);
  }
  #line 64 "src/filter.birch"
  libbirch_line_(64);
  #line 64 "src/filter.birch"
  buffer = configBuffer->find(birch::type::String("filter"), handler_);
  #line 65 "src/filter.birch"
  libbirch_line_(65);
  #line 65 "src/filter.birch"
  if (!buffer.query()) {
    #line 66 "src/filter.birch"
    libbirch_line_(66);
    #line 66 "src/filter.birch"
    buffer = birch::Buffer(handler_);
  }
  #line 68 "src/filter.birch"
  libbirch_line_(68);
  #line 68 "src/filter.birch"
  if (!buffer.get()->getString(birch::type::String("class"), handler_).query()) {
    #line 69 "src/filter.birch"
    libbirch_line_(69);
    #line 69 "src/filter.birch"
    buffer.get()->set(birch::type::String("class"), birch::type::String("ParticleFilter"), handler_);
  }
  #line 71 "src/filter.birch"
  libbirch_line_(71);
  #line 71 "src/filter.birch"
  auto filter = libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::ParticleFilter>>>(birch::make(buffer, handler_));
  #line 72 "src/filter.birch"
  libbirch_line_(72);
  #line 72 "src/filter.birch"
  if (!filter.query()) {
    #line 73 "src/filter.birch"
    libbirch_line_(73);
    #line 73 "src/filter.birch"
    birch::error(birch::type::String("could not create filter; the filter class should be given as ") + birch::type::String("filter.class in the config file, and should derive from ParticleFilter."), handler_);
  }
  #line 78 "src/filter.birch"
  libbirch_line_(78);
  #line 78 "src/filter.birch"
  auto inputPath = input;
  #line 79 "src/filter.birch"
  libbirch_line_(79);
  #line 79 "src/filter.birch"
  if (!inputPath.query()) {
    #line 80 "src/filter.birch"
    libbirch_line_(80);
    #line 80 "src/filter.birch"
    libbirch::optional_assign(inputPath, configBuffer->getString(birch::type::String("input"), handler_));
  }
  #line 82 "src/filter.birch"
  libbirch_line_(82);
  #line 82 "src/filter.birch"
  if (inputPath.query() && inputPath.get() != birch::type::String("")) {
    #line 83 "src/filter.birch"
    libbirch_line_(83);
    #line 83 "src/filter.birch"
    auto reader = birch::Reader(inputPath.get(), handler_);
    #line 84 "src/filter.birch"
    libbirch_line_(84);
    #line 84 "src/filter.birch"
    auto inputBuffer = reader->slurp(handler_);
    #line 85 "src/filter.birch"
    libbirch_line_(85);
    #line 85 "src/filter.birch"
    reader->close(handler_);
    #line 86 "src/filter.birch"
    libbirch_line_(86);
    #line 86 "src/filter.birch"
    inputBuffer->get(archetype.get(), handler_);
  }
  #line 90 "src/filter.birch"
  libbirch_line_(90);
  #line 90 "src/filter.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Writer>>> outputWriter;
  #line 91 "src/filter.birch"
  libbirch_line_(91);
  #line 91 "src/filter.birch"
  libbirch::Optional<birch::type::String> outputPath = output;
  #line 92 "src/filter.birch"
  libbirch_line_(92);
  #line 92 "src/filter.birch"
  if (!outputPath.query()) {
    #line 93 "src/filter.birch"
    libbirch_line_(93);
    #line 93 "src/filter.birch"
    libbirch::optional_assign(outputPath, configBuffer->getString(birch::type::String("output"), handler_));
  }
  #line 95 "src/filter.birch"
  libbirch_line_(95);
  #line 95 "src/filter.birch"
  if (outputPath.query() && outputPath.get() != birch::type::String("")) {
    #line 96 "src/filter.birch"
    libbirch_line_(96);
    #line 96 "src/filter.birch"
    outputWriter = birch::Writer(outputPath.get(), handler_);
  }
  #line 100 "src/filter.birch"
  libbirch_line_(100);
  #line 100 "src/filter.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::ProgressBar>> bar;
  #line 101 "src/filter.birch"
  libbirch_line_(101);
  #line 101 "src/filter.birch"
  if (!quiet) {
    #line 102 "src/filter.birch"
    libbirch_line_(102);
    #line 102 "src/filter.birch"
    bar->update(0.0, handler_);
  }
  #line 106 "src/filter.birch"
  libbirch_line_(106);
  #line 106 "src/filter.birch"
  filter.get()->initialize(archetype.get(), handler_);
  #line 107 "src/filter.birch"
  libbirch_line_(107);
  #line 107 "src/filter.birch"
  for (auto t = birch::type::Integer(0); t <= filter.get()->size(handler_); ++t) {
    #line 108 "src/filter.birch"
    libbirch_line_(108);
    #line 108 "src/filter.birch"
    if (t == birch::type::Integer(0)) {
      #line 109 "src/filter.birch"
      libbirch_line_(109);
      #line 109 "src/filter.birch"
      filter.get()->filter(handler_);
    } else {
      #line 111 "src/filter.birch"
      libbirch_line_(111);
      #line 111 "src/filter.birch"
      filter.get()->filter(t, handler_);
    }
    #line 115 "src/filter.birch"
    libbirch_line_(115);
    #line 115 "src/filter.birch"
    libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> buffer;
    #line 116 "src/filter.birch"
    libbirch_line_(116);
    #line 116 "src/filter.birch"
    if (outputWriter.query()) {
      #line 117 "src/filter.birch"
      libbirch_line_(117);
      #line 117 "src/filter.birch"
      filter.get()->write(buffer, t, handler_);
    }
    #line 121 "src/filter.birch"
    libbirch_line_(121);
    #line 121 "src/filter.birch"
    if (filter.get()->nforecasts > birch::type::Integer(0)) {
      #line 123 "src/filter.birch"
      libbirch_line_(123);
      #line 123 "src/filter.birch"
      auto filter_prime_ = birch::clone(filter.get(), handler_);
      #line 126 "src/filter.birch"
      libbirch_line_(126);
      #line 126 "src/filter.birch"
      filter_prime_->resample(t, handler_);
      #line 127 "src/filter.birch"
      libbirch_line_(127);
      #line 127 "src/filter.birch"
      auto w_prime_ = filter_prime_->w;
      #line 131 "src/filter.birch"
      libbirch_line_(131);
      #line 131 "src/filter.birch"
      filter_prime_->delayed = false;
      #line 134 "src/filter.birch"
      libbirch_line_(134);
      #line 134 "src/filter.birch"
      auto forecast = birch::Buffer(handler_);
      #line 135 "src/filter.birch"
      libbirch_line_(135);
      #line 135 "src/filter.birch"
      buffer->set(birch::type::String("forecast"), forecast, handler_);
      #line 136 "src/filter.birch"
      libbirch_line_(136);
      #line 136 "src/filter.birch"
      for (auto s = (t + birch::type::Integer(1)); s <= (t + filter_prime_->nforecasts); ++s) {
        #line 137 "src/filter.birch"
        libbirch_line_(137);
        #line 137 "src/filter.birch"
        filter_prime_->forecast(s, handler_);
        #line 138 "src/filter.birch"
        libbirch_line_(138);
        #line 138 "src/filter.birch"
        filter_prime_->reduce(handler_);
        #line 139 "src/filter.birch"
        libbirch_line_(139);
        #line 139 "src/filter.birch"
        if (outputWriter.query()) {
          #line 140 "src/filter.birch"
          libbirch_line_(140);
          #line 140 "src/filter.birch"
          auto state = birch::Buffer(handler_);
          #line 141 "src/filter.birch"
          libbirch_line_(141);
          #line 141 "src/filter.birch"
          state->set(birch::type::String("sample"), filter_prime_->x, handler_);
          #line 142 "src/filter.birch"
          libbirch_line_(142);
          #line 142 "src/filter.birch"
          state->set(birch::type::String("lweight"), w_prime_, handler_);
          #line 143 "src/filter.birch"
          libbirch_line_(143);
          #line 143 "src/filter.birch"
          state->set(birch::type::String("lnormalize"), filter_prime_->lnormalize, handler_);
          #line 144 "src/filter.birch"
          libbirch_line_(144);
          #line 144 "src/filter.birch"
          forecast->push(state, handler_);
        }
      }
      #line 147 "src/filter.birch"
      libbirch_line_(147);
      #line 147 "src/filter.birch"
      birch::collect(handler_);
    }
    #line 149 "src/filter.birch"
    libbirch_line_(149);
    #line 149 "src/filter.birch"
    if (outputWriter.query()) {
      #line 150 "src/filter.birch"
      libbirch_line_(150);
      #line 150 "src/filter.birch"
      outputWriter.get()->push(buffer, handler_);
      #line 151 "src/filter.birch"
      libbirch_line_(151);
      #line 151 "src/filter.birch"
      outputWriter.get()->flush(handler_);
    }
    #line 153 "src/filter.birch"
    libbirch_line_(153);
    #line 153 "src/filter.birch"
    if (!quiet) {
      #line 154 "src/filter.birch"
      libbirch_line_(154);
      #line 154 "src/filter.birch"
      bar->update((t + 1.0) / (filter.get()->size(handler_) + 1.0), handler_);
    }
  }
  #line 159 "src/filter.birch"
  libbirch_line_(159);
  #line 159 "src/filter.birch"
  if (outputWriter.query()) {
    #line 160 "src/filter.birch"
    libbirch_line_(160);
    #line 160 "src/filter.birch"
    outputWriter.get()->close(handler_);
  }
  #line 22 "src/filter.birch"
  libbirch_line_(22);
  #line 22 "src/filter.birch"
  return 0;
}

#line 22 "src/sample.birch"
int birch::sample(int argc_, char** argv_) {
  #line 22 "src/sample.birch"
  libbirch_function_("sample", "src/sample.birch", 22);
  #line 22 "src/sample.birch"
  libbirch::Optional<birch::type::String> config;
  #line 22 "src/sample.birch"
  libbirch::Optional<birch::type::String> input;
  #line 22 "src/sample.birch"
  libbirch::Optional<birch::type::String> output;
  #line 22 "src/sample.birch"
  libbirch::Optional<birch::type::String> model;
  #line 22 "src/sample.birch"
  libbirch::Optional<birch::type::Integer> seed;
  #line 22 "src/sample.birch"
  birch::type::Boolean quiet = false;
  
  enum {
    configFLAG_,
    inputFLAG_,
    outputFLAG_,
    modelFLAG_,
    seedFLAG_,
    quietFLAG_,
  };
  #line 22 "src/sample.birch"
  int c_, option_index_;
  #line 22 "src/sample.birch"
  option long_options_[] = {
    #line 22 "src/sample.birch"
    {"config", required_argument, 0, configFLAG_ },
    #line 22 "src/sample.birch"
    {"input", required_argument, 0, inputFLAG_ },
    #line 22 "src/sample.birch"
    {"output", required_argument, 0, outputFLAG_ },
    #line 22 "src/sample.birch"
    {"model", required_argument, 0, modelFLAG_ },
    #line 22 "src/sample.birch"
    {"seed", required_argument, 0, seedFLAG_ },
    #line 22 "src/sample.birch"
    {"quiet", required_argument, 0, quietFLAG_ },
    #line 22 "src/sample.birch"
    {0, 0, 0, 0}
  #line 22 "src/sample.birch"
  };
  #line 22 "src/sample.birch"
  const char* short_options_ = ":";
  #line 22 "src/sample.birch"
  ::opterr = 0;
  #line 22 "src/sample.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 22 "src/sample.birch"
  while (c_ != -1) {
    #line 22 "src/sample.birch"
    switch (c_) {
      #line 23 "src/sample.birch"
      case configFLAG_:
        #line 23 "src/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 23 "src/sample.birch"
        config = birch::String(std::string(::optarg));
        break;
      #line 24 "src/sample.birch"
      case inputFLAG_:
        #line 24 "src/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 24 "src/sample.birch"
        input = birch::String(std::string(::optarg));
        break;
      #line 25 "src/sample.birch"
      case outputFLAG_:
        #line 25 "src/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 25 "src/sample.birch"
        output = birch::String(std::string(::optarg));
        break;
      #line 26 "src/sample.birch"
      case modelFLAG_:
        #line 26 "src/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 26 "src/sample.birch"
        model = birch::String(std::string(::optarg));
        break;
      #line 27 "src/sample.birch"
      case seedFLAG_:
        #line 27 "src/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 27 "src/sample.birch"
        seed = birch::Integer(std::string(::optarg));
        break;
      #line 28 "src/sample.birch"
      case quietFLAG_:
        #line 28 "src/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 28 "src/sample.birch"
        quiet = birch::Boolean(std::string(::optarg));
        break;
      #line 22 "src/sample.birch"
      case '?':
        #line 22 "src/sample.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 22 "src/sample.birch"
      case ':':
        #line 22 "src/sample.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 22 "src/sample.birch"
      default:
        #line 22 "src/sample.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 22 "src/sample.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 30 "src/sample.birch"
  libbirch_line_(30);
  #line 30 "src/sample.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> configBuffer;
  #line 31 "src/sample.birch"
  libbirch_line_(31);
  #line 31 "src/sample.birch"
  if (config.query()) {
    #line 32 "src/sample.birch"
    libbirch_line_(32);
    #line 32 "src/sample.birch"
    auto reader = birch::Reader(config.get(), handler_);
    #line 33 "src/sample.birch"
    libbirch_line_(33);
    #line 33 "src/sample.birch"
    configBuffer = reader->slurp(handler_);
    #line 34 "src/sample.birch"
    libbirch_line_(34);
    #line 34 "src/sample.birch"
    reader->close(handler_);
  }
  #line 38 "src/sample.birch"
  libbirch_line_(38);
  #line 38 "src/sample.birch"
  if (seed.query()) {
    #line 39 "src/sample.birch"
    libbirch_line_(39);
    #line 39 "src/sample.birch"
    birch::seed(seed.get(), handler_);
  } else {
    #line 40 "src/sample.birch"
    libbirch_line_(40);
    #line 40 "src/sample.birch"
    if (config.query()) {
      #line 41 "src/sample.birch"
      libbirch_line_(41);
      #line 41 "src/sample.birch"
      auto buffer = configBuffer->getInteger(birch::type::String("seed"), handler_);
      #line 42 "src/sample.birch"
      libbirch_line_(42);
      #line 42 "src/sample.birch"
      if (buffer.query()) {
        #line 43 "src/sample.birch"
        libbirch_line_(43);
        #line 43 "src/sample.birch"
        birch::seed(buffer.get(), handler_);
      }
    } else {
      #line 46 "src/sample.birch"
      libbirch_line_(46);
      #line 46 "src/sample.birch"
      birch::seed(handler_);
    }
  }
  #line 50 "src/sample.birch"
  libbirch_line_(50);
  #line 50 "src/sample.birch"
  auto buffer = configBuffer->find(birch::type::String("model"), handler_);
  #line 51 "src/sample.birch"
  libbirch_line_(51);
  #line 51 "src/sample.birch"
  if (!buffer.query()) {
    #line 52 "src/sample.birch"
    libbirch_line_(52);
    #line 52 "src/sample.birch"
    buffer = birch::Buffer(handler_);
  }
  #line 54 "src/sample.birch"
  libbirch_line_(54);
  #line 54 "src/sample.birch"
  if (!buffer.get()->getString(birch::type::String("class"), handler_).query() && model.query()) {
    #line 55 "src/sample.birch"
    libbirch_line_(55);
    #line 55 "src/sample.birch"
    buffer.get()->set(birch::type::String("class"), model.get(), handler_);
  }
  #line 57 "src/sample.birch"
  libbirch_line_(57);
  #line 57 "src/sample.birch"
  auto archetype = libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::Model>>>(birch::make(buffer, handler_));
  #line 58 "src/sample.birch"
  libbirch_line_(58);
  #line 58 "src/sample.birch"
  if (!archetype.query()) {
    #line 59 "src/sample.birch"
    libbirch_line_(59);
    #line 59 "src/sample.birch"
    birch::error(birch::type::String("could not create model; the model class should be given as ") + birch::type::String("model.class in the config file, and should derive from Model."), handler_);
  }
  #line 64 "src/sample.birch"
  libbirch_line_(64);
  #line 64 "src/sample.birch"
  buffer = configBuffer->find(birch::type::String("sampler"), handler_);
  #line 65 "src/sample.birch"
  libbirch_line_(65);
  #line 65 "src/sample.birch"
  if (!buffer.query()) {
    #line 66 "src/sample.birch"
    libbirch_line_(66);
    #line 66 "src/sample.birch"
    buffer = birch::Buffer(handler_);
  }
  #line 68 "src/sample.birch"
  libbirch_line_(68);
  #line 68 "src/sample.birch"
  if (!buffer.get()->getString(birch::type::String("class"), handler_).query()) {
    #line 69 "src/sample.birch"
    libbirch_line_(69);
    #line 69 "src/sample.birch"
    buffer.get()->set(birch::type::String("class"), birch::type::String("MarginalizedParticleImportanceSampler"), handler_);
  }
  #line 71 "src/sample.birch"
  libbirch_line_(71);
  #line 71 "src/sample.birch"
  auto sampler = libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::ParticleSampler>>>(birch::make(buffer, handler_));
  #line 72 "src/sample.birch"
  libbirch_line_(72);
  #line 72 "src/sample.birch"
  if (!sampler.query()) {
    #line 73 "src/sample.birch"
    libbirch_line_(73);
    #line 73 "src/sample.birch"
    birch::error(birch::type::String("could not create sampler; the sampler class should be given as ") + birch::type::String("sampler.class in the config file, and should derive from ParticleSampler."), handler_);
  }
  #line 78 "src/sample.birch"
  libbirch_line_(78);
  #line 78 "src/sample.birch"
  buffer = configBuffer->find(birch::type::String("filter"), handler_);
  #line 79 "src/sample.birch"
  libbirch_line_(79);
  #line 79 "src/sample.birch"
  if (!buffer.query()) {
    #line 80 "src/sample.birch"
    libbirch_line_(80);
    #line 80 "src/sample.birch"
    buffer = birch::Buffer(handler_);
  }
  #line 82 "src/sample.birch"
  libbirch_line_(82);
  #line 82 "src/sample.birch"
  if (!buffer.get()->getString(birch::type::String("class"), handler_).query()) {
    #line 83 "src/sample.birch"
    libbirch_line_(83);
    #line 83 "src/sample.birch"
    if (libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::ConditionalParticleSampler>>>(sampler).query()) {
      #line 84 "src/sample.birch"
      libbirch_line_(84);
      #line 84 "src/sample.birch"
      buffer.get()->set(birch::type::String("class"), birch::type::String("ConditionalParticleFilter"), handler_);
    } else {
      #line 86 "src/sample.birch"
      libbirch_line_(86);
      #line 86 "src/sample.birch"
      buffer.get()->set(birch::type::String("class"), birch::type::String("ParticleFilter"), handler_);
    }
  }
  #line 89 "src/sample.birch"
  libbirch_line_(89);
  #line 89 "src/sample.birch"
  auto filter = libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::ParticleFilter>>>(birch::make(buffer, handler_));
  #line 90 "src/sample.birch"
  libbirch_line_(90);
  #line 90 "src/sample.birch"
  if (!filter.query()) {
    #line 91 "src/sample.birch"
    libbirch_line_(91);
    #line 91 "src/sample.birch"
    birch::error(birch::type::String("could not create filter; the filter class should be given as ") + birch::type::String("filter.class in the config file, and should derive from ParticleFilter."), handler_);
  }
  #line 96 "src/sample.birch"
  libbirch_line_(96);
  #line 96 "src/sample.birch"
  auto inputPath = input;
  #line 97 "src/sample.birch"
  libbirch_line_(97);
  #line 97 "src/sample.birch"
  if (!inputPath.query()) {
    #line 98 "src/sample.birch"
    libbirch_line_(98);
    #line 98 "src/sample.birch"
    libbirch::optional_assign(inputPath, configBuffer->getString(birch::type::String("input"), handler_));
  }
  #line 100 "src/sample.birch"
  libbirch_line_(100);
  #line 100 "src/sample.birch"
  if (inputPath.query() && inputPath.get() != birch::type::String("")) {
    #line 101 "src/sample.birch"
    libbirch_line_(101);
    #line 101 "src/sample.birch"
    auto reader = birch::Reader(inputPath.get(), handler_);
    #line 102 "src/sample.birch"
    libbirch_line_(102);
    #line 102 "src/sample.birch"
    auto inputBuffer = reader->slurp(handler_);
    #line 103 "src/sample.birch"
    libbirch_line_(103);
    #line 103 "src/sample.birch"
    reader->close(handler_);
    #line 104 "src/sample.birch"
    libbirch_line_(104);
    #line 104 "src/sample.birch"
    inputBuffer->get(archetype.get(), handler_);
  }
  #line 108 "src/sample.birch"
  libbirch_line_(108);
  #line 108 "src/sample.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Writer>>> outputWriter;
  #line 109 "src/sample.birch"
  libbirch_line_(109);
  #line 109 "src/sample.birch"
  libbirch::Optional<birch::type::String> outputPath = output;
  #line 110 "src/sample.birch"
  libbirch_line_(110);
  #line 110 "src/sample.birch"
  if (!outputPath.query()) {
    #line 111 "src/sample.birch"
    libbirch_line_(111);
    #line 111 "src/sample.birch"
    libbirch::optional_assign(outputPath, configBuffer->getString(birch::type::String("output"), handler_));
  }
  #line 113 "src/sample.birch"
  libbirch_line_(113);
  #line 113 "src/sample.birch"
  if (outputPath.query() && outputPath.get() != birch::type::String("")) {
    #line 114 "src/sample.birch"
    libbirch_line_(114);
    #line 114 "src/sample.birch"
    outputWriter = birch::Writer(outputPath.get(), handler_);
  }
  #line 118 "src/sample.birch"
  libbirch_line_(118);
  #line 118 "src/sample.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::ProgressBar>> bar;
  #line 119 "src/sample.birch"
  libbirch_line_(119);
  #line 119 "src/sample.birch"
  if (!quiet) {
    #line 120 "src/sample.birch"
    libbirch_line_(120);
    #line 120 "src/sample.birch"
    bar->update(0.0, handler_);
  }
  #line 124 "src/sample.birch"
  libbirch_line_(124);
  #line 124 "src/sample.birch"
  sampler.get()->sample(filter.get(), archetype.get(), handler_);
  #line 125 "src/sample.birch"
  libbirch_line_(125);
  #line 125 "src/sample.birch"
  for (auto n = birch::type::Integer(1); n <= sampler.get()->size(handler_); ++n) {
    #line 126 "src/sample.birch"
    libbirch_line_(126);
    #line 126 "src/sample.birch"
    sampler.get()->sample(filter.get(), archetype.get(), n, handler_);
    #line 128 "src/sample.birch"
    libbirch_line_(128);
    #line 128 "src/sample.birch"
    if (outputWriter.query()) {
      #line 129 "src/sample.birch"
      libbirch_line_(129);
      #line 129 "src/sample.birch"
      libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> buffer;
      #line 130 "src/sample.birch"
      libbirch_line_(130);
      #line 130 "src/sample.birch"
      sampler.get()->write(buffer, n, handler_);
      #line 131 "src/sample.birch"
      libbirch_line_(131);
      #line 131 "src/sample.birch"
      outputWriter.get()->push(buffer, handler_);
      #line 132 "src/sample.birch"
      libbirch_line_(132);
      #line 132 "src/sample.birch"
      outputWriter.get()->flush(handler_);
    }
    #line 134 "src/sample.birch"
    libbirch_line_(134);
    #line 134 "src/sample.birch"
    if (!quiet) {
      #line 135 "src/sample.birch"
      libbirch_line_(135);
      #line 135 "src/sample.birch"
      bar->update(birch::Real(n, handler_) / sampler.get()->nsamples, handler_);
    }
  }
  #line 140 "src/sample.birch"
  libbirch_line_(140);
  #line 140 "src/sample.birch"
  if (outputWriter.query()) {
    #line 141 "src/sample.birch"
    libbirch_line_(141);
    #line 141 "src/sample.birch"
    outputWriter.get()->close(handler_);
  }
  #line 22 "src/sample.birch"
  libbirch_line_(22);
  #line 22 "src/sample.birch"
  return 0;
}

