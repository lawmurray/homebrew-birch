#line 20 "src/filter.birch"
int birch::filter(int argc_, char** argv_) {
  #line 20 "src/filter.birch"
  libbirch_function_("filter", "src/filter.birch", 20);
  #line 20 "src/filter.birch"
  libbirch::Optional<birch::type::String> input;
  #line 20 "src/filter.birch"
  libbirch::Optional<birch::type::String> output;
  #line 20 "src/filter.birch"
  libbirch::Optional<birch::type::String> config;
  #line 20 "src/filter.birch"
  libbirch::Optional<birch::type::String> model;
  #line 20 "src/filter.birch"
  libbirch::Optional<birch::type::Integer> seed;
  #line 20 "src/filter.birch"
  birch::type::Boolean quiet = false;
  
  enum {
    inputFLAG_,
    outputFLAG_,
    configFLAG_,
    modelFLAG_,
    seedFLAG_,
    quietFLAG_,
  };
  #line 20 "src/filter.birch"
  int c_, option_index_;
  #line 20 "src/filter.birch"
  option long_options_[] = {
    #line 20 "src/filter.birch"
    {"input", required_argument, 0, inputFLAG_ },
    #line 20 "src/filter.birch"
    {"output", required_argument, 0, outputFLAG_ },
    #line 20 "src/filter.birch"
    {"config", required_argument, 0, configFLAG_ },
    #line 20 "src/filter.birch"
    {"model", required_argument, 0, modelFLAG_ },
    #line 20 "src/filter.birch"
    {"seed", required_argument, 0, seedFLAG_ },
    #line 20 "src/filter.birch"
    {"quiet", required_argument, 0, quietFLAG_ },
    #line 20 "src/filter.birch"
    {0, 0, 0, 0}
  #line 20 "src/filter.birch"
  };
  #line 20 "src/filter.birch"
  const char* short_options_ = ":";
  #line 20 "src/filter.birch"
  ::opterr = 0;
  #line 20 "src/filter.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 20 "src/filter.birch"
  while (c_ != -1) {
    #line 20 "src/filter.birch"
    switch (c_) {
      #line 21 "src/filter.birch"
      case inputFLAG_:
        #line 21 "src/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 21 "src/filter.birch"
        input = birch::String(std::string(::optarg));
        break;
      #line 22 "src/filter.birch"
      case outputFLAG_:
        #line 22 "src/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 22 "src/filter.birch"
        output = birch::String(std::string(::optarg));
        break;
      #line 23 "src/filter.birch"
      case configFLAG_:
        #line 23 "src/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 23 "src/filter.birch"
        config = birch::String(std::string(::optarg));
        break;
      #line 24 "src/filter.birch"
      case modelFLAG_:
        #line 24 "src/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 24 "src/filter.birch"
        model = birch::String(std::string(::optarg));
        break;
      #line 25 "src/filter.birch"
      case seedFLAG_:
        #line 25 "src/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 25 "src/filter.birch"
        seed = birch::Integer(std::string(::optarg));
        break;
      #line 26 "src/filter.birch"
      case quietFLAG_:
        #line 26 "src/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 26 "src/filter.birch"
        quiet = birch::Boolean(std::string(::optarg));
        break;
      #line 20 "src/filter.birch"
      case '?':
        #line 20 "src/filter.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 20 "src/filter.birch"
      case ':':
        #line 20 "src/filter.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 20 "src/filter.birch"
      default:
        #line 20 "src/filter.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 20 "src/filter.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 28 "src/filter.birch"
  libbirch_line_(28);
  #line 28 "src/filter.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> configBuffer;
  #line 29 "src/filter.birch"
  libbirch_line_(29);
  #line 29 "src/filter.birch"
  if (config.query()) {
    #line 30 "src/filter.birch"
    libbirch_line_(30);
    #line 30 "src/filter.birch"
    auto reader = birch::Reader(config.get(), handler_);
    #line 31 "src/filter.birch"
    libbirch_line_(31);
    #line 31 "src/filter.birch"
    configBuffer = reader->scan(handler_);
    #line 32 "src/filter.birch"
    libbirch_line_(32);
    #line 32 "src/filter.birch"
    reader->close(handler_);
  }
  #line 36 "src/filter.birch"
  libbirch_line_(36);
  #line 36 "src/filter.birch"
  if (seed.query()) {
    #line 37 "src/filter.birch"
    libbirch_line_(37);
    #line 37 "src/filter.birch"
    birch::seed(seed.get(), handler_);
  } else {
    #line 38 "src/filter.birch"
    libbirch_line_(38);
    #line 38 "src/filter.birch"
    if (config.query()) {
      #line 39 "src/filter.birch"
      libbirch_line_(39);
      #line 39 "src/filter.birch"
      auto buffer = configBuffer->getInteger(birch::type::String("seed"), handler_);
      #line 40 "src/filter.birch"
      libbirch_line_(40);
      #line 40 "src/filter.birch"
      if (buffer.query()) {
        #line 41 "src/filter.birch"
        libbirch_line_(41);
        #line 41 "src/filter.birch"
        birch::seed(buffer.get(), handler_);
      }
    } else {
      #line 44 "src/filter.birch"
      libbirch_line_(44);
      #line 44 "src/filter.birch"
      birch::seed(handler_);
    }
  }
  #line 48 "src/filter.birch"
  libbirch_line_(48);
  #line 48 "src/filter.birch"
  auto buffer = configBuffer->getObject(birch::type::String("model"), handler_);
  #line 49 "src/filter.birch"
  libbirch_line_(49);
  #line 49 "src/filter.birch"
  if (!buffer.query()) {
    #line 50 "src/filter.birch"
    libbirch_line_(50);
    #line 50 "src/filter.birch"
    buffer = configBuffer->setObject(birch::type::String("model"), handler_);
  }
  #line 52 "src/filter.birch"
  libbirch_line_(52);
  #line 52 "src/filter.birch"
  if (!buffer.get()->getString(birch::type::String("class"), handler_).query() && model.query()) {
    #line 53 "src/filter.birch"
    libbirch_line_(53);
    #line 53 "src/filter.birch"
    buffer.get()->setString(birch::type::String("class"), model.get(), handler_);
  }
  #line 55 "src/filter.birch"
  libbirch_line_(55);
  #line 55 "src/filter.birch"
  auto archetype = libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::Model>>>(birch::make(buffer, handler_));
  #line 56 "src/filter.birch"
  libbirch_line_(56);
  #line 56 "src/filter.birch"
  if (!archetype.query()) {
    #line 57 "src/filter.birch"
    libbirch_line_(57);
    #line 57 "src/filter.birch"
    birch::error(birch::type::String("could not create model; the model class should be given as ") + birch::type::String("model.class in the config file, and should derive from Model."), handler_);
  }
  #line 62 "src/filter.birch"
  libbirch_line_(62);
  #line 62 "src/filter.birch"
  buffer = configBuffer->getObject(birch::type::String("filter"), handler_);
  #line 63 "src/filter.birch"
  libbirch_line_(63);
  #line 63 "src/filter.birch"
  if (!buffer.query()) {
    #line 64 "src/filter.birch"
    libbirch_line_(64);
    #line 64 "src/filter.birch"
    buffer = configBuffer->setObject(birch::type::String("filter"), handler_);
  }
  #line 66 "src/filter.birch"
  libbirch_line_(66);
  #line 66 "src/filter.birch"
  if (!buffer.get()->getString(birch::type::String("class"), handler_).query()) {
    #line 67 "src/filter.birch"
    libbirch_line_(67);
    #line 67 "src/filter.birch"
    buffer.get()->setString(birch::type::String("class"), birch::type::String("ParticleFilter"), handler_);
  }
  #line 69 "src/filter.birch"
  libbirch_line_(69);
  #line 69 "src/filter.birch"
  auto filter = libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::ParticleFilter>>>(birch::make(buffer, handler_));
  #line 70 "src/filter.birch"
  libbirch_line_(70);
  #line 70 "src/filter.birch"
  if (!filter.query()) {
    #line 71 "src/filter.birch"
    libbirch_line_(71);
    #line 71 "src/filter.birch"
    birch::error(birch::type::String("could not create filter; the filter class should be given as ") + birch::type::String("filter.class in the config file, and should derive from ParticleFilter."), handler_);
  }
  #line 76 "src/filter.birch"
  libbirch_line_(76);
  #line 76 "src/filter.birch"
  auto inputPath = input;
  #line 77 "src/filter.birch"
  libbirch_line_(77);
  #line 77 "src/filter.birch"
  if (!inputPath.query()) {
    #line 78 "src/filter.birch"
    libbirch_line_(78);
    #line 78 "src/filter.birch"
    libbirch::optional_assign(inputPath, configBuffer->getString(birch::type::String("input"), handler_));
  }
  #line 80 "src/filter.birch"
  libbirch_line_(80);
  #line 80 "src/filter.birch"
  if (inputPath.query() && inputPath.get() != birch::type::String("")) {
    #line 81 "src/filter.birch"
    libbirch_line_(81);
    #line 81 "src/filter.birch"
    auto reader = birch::Reader(inputPath.get(), handler_);
    #line 82 "src/filter.birch"
    libbirch_line_(82);
    #line 82 "src/filter.birch"
    auto inputBuffer = reader->scan(handler_);
    #line 83 "src/filter.birch"
    libbirch_line_(83);
    #line 83 "src/filter.birch"
    reader->close(handler_);
    #line 84 "src/filter.birch"
    libbirch_line_(84);
    #line 84 "src/filter.birch"
    inputBuffer->get(archetype.get(), handler_);
  }
  #line 88 "src/filter.birch"
  libbirch_line_(88);
  #line 88 "src/filter.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Writer>>> outputWriter;
  #line 89 "src/filter.birch"
  libbirch_line_(89);
  #line 89 "src/filter.birch"
  libbirch::Optional<birch::type::String> outputPath = output;
  #line 90 "src/filter.birch"
  libbirch_line_(90);
  #line 90 "src/filter.birch"
  if (!outputPath.query()) {
    #line 91 "src/filter.birch"
    libbirch_line_(91);
    #line 91 "src/filter.birch"
    libbirch::optional_assign(outputPath, configBuffer->getString(birch::type::String("output"), handler_));
  }
  #line 93 "src/filter.birch"
  libbirch_line_(93);
  #line 93 "src/filter.birch"
  if (outputPath.query() && outputPath.get() != birch::type::String("")) {
    #line 94 "src/filter.birch"
    libbirch_line_(94);
    #line 94 "src/filter.birch"
    outputWriter = birch::Writer(outputPath.get(), handler_);
    #line 95 "src/filter.birch"
    libbirch_line_(95);
    #line 95 "src/filter.birch"
    outputWriter.get()->startSequence(handler_);
  }
  #line 99 "src/filter.birch"
  libbirch_line_(99);
  #line 99 "src/filter.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::ProgressBar>> bar;
  #line 100 "src/filter.birch"
  libbirch_line_(100);
  #line 100 "src/filter.birch"
  if (!quiet) {
    #line 101 "src/filter.birch"
    libbirch_line_(101);
    #line 101 "src/filter.birch"
    bar->update(0.0, handler_);
  }
  #line 105 "src/filter.birch"
  libbirch_line_(105);
  #line 105 "src/filter.birch"
  filter.get()->initialize(archetype.get(), handler_);
  #line 106 "src/filter.birch"
  libbirch_line_(106);
  #line 106 "src/filter.birch"
  for (auto t = birch::type::Integer(0); t <= filter.get()->size(handler_); ++t) {
    #line 107 "src/filter.birch"
    libbirch_line_(107);
    #line 107 "src/filter.birch"
    if (t == birch::type::Integer(0)) {
      #line 108 "src/filter.birch"
      libbirch_line_(108);
      #line 108 "src/filter.birch"
      filter.get()->filter(handler_);
    } else {
      #line 110 "src/filter.birch"
      libbirch_line_(110);
      #line 110 "src/filter.birch"
      filter.get()->filter(t, handler_);
    }
    #line 114 "src/filter.birch"
    libbirch_line_(114);
    #line 114 "src/filter.birch"
    libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> buffer;
    #line 115 "src/filter.birch"
    libbirch_line_(115);
    #line 115 "src/filter.birch"
    if (outputWriter.query()) {
      #line 116 "src/filter.birch"
      libbirch_line_(116);
      #line 116 "src/filter.birch"
      filter.get()->write(buffer, t, handler_);
    }
    #line 120 "src/filter.birch"
    libbirch_line_(120);
    #line 120 "src/filter.birch"
    if (filter.get()->nforecasts > birch::type::Integer(0)) {
      #line 122 "src/filter.birch"
      libbirch_line_(122);
      #line 122 "src/filter.birch"
      auto filter_prime_ = birch::clone(filter.get(), handler_);
      #line 125 "src/filter.birch"
      libbirch_line_(125);
      #line 125 "src/filter.birch"
      filter_prime_->resample(t, handler_);
      #line 126 "src/filter.birch"
      libbirch_line_(126);
      #line 126 "src/filter.birch"
      auto w_prime_ = filter_prime_->w;
      #line 130 "src/filter.birch"
      libbirch_line_(130);
      #line 130 "src/filter.birch"
      filter_prime_->delayed = false;
      #line 133 "src/filter.birch"
      libbirch_line_(133);
      #line 133 "src/filter.birch"
      auto forecast = buffer->setArray(birch::type::String("forecast"), handler_);
      #line 134 "src/filter.birch"
      libbirch_line_(134);
      #line 134 "src/filter.birch"
      for (auto s = (t + birch::type::Integer(1)); s <= (t + filter_prime_->nforecasts); ++s) {
        #line 135 "src/filter.birch"
        libbirch_line_(135);
        #line 135 "src/filter.birch"
        filter_prime_->forecast(s, handler_);
        #line 136 "src/filter.birch"
        libbirch_line_(136);
        #line 136 "src/filter.birch"
        filter_prime_->reduce(handler_);
        #line 137 "src/filter.birch"
        libbirch_line_(137);
        #line 137 "src/filter.birch"
        if (outputWriter.query()) {
          #line 138 "src/filter.birch"
          libbirch_line_(138);
          #line 138 "src/filter.birch"
          auto state = forecast->push(handler_);
          #line 139 "src/filter.birch"
          libbirch_line_(139);
          #line 139 "src/filter.birch"
          state->set(birch::type::String("sample"), filter_prime_->x, handler_);
          #line 140 "src/filter.birch"
          libbirch_line_(140);
          #line 140 "src/filter.birch"
          state->set(birch::type::String("lweight"), w_prime_, handler_);
          #line 141 "src/filter.birch"
          libbirch_line_(141);
          #line 141 "src/filter.birch"
          state->set(birch::type::String("lnormalize"), filter_prime_->lnormalize, handler_);
        }
      }
      #line 144 "src/filter.birch"
      libbirch_line_(144);
      #line 144 "src/filter.birch"
      birch::collect(handler_);
    }
    #line 146 "src/filter.birch"
    libbirch_line_(146);
    #line 146 "src/filter.birch"
    if (outputWriter.query()) {
      #line 147 "src/filter.birch"
      libbirch_line_(147);
      #line 147 "src/filter.birch"
      outputWriter.get()->print(buffer, handler_);
      #line 148 "src/filter.birch"
      libbirch_line_(148);
      #line 148 "src/filter.birch"
      outputWriter.get()->flush(handler_);
    }
    #line 150 "src/filter.birch"
    libbirch_line_(150);
    #line 150 "src/filter.birch"
    if (!quiet) {
      #line 151 "src/filter.birch"
      libbirch_line_(151);
      #line 151 "src/filter.birch"
      bar->update((t + 1.0) / (filter.get()->size(handler_) + 1.0), handler_);
    }
  }
  #line 156 "src/filter.birch"
  libbirch_line_(156);
  #line 156 "src/filter.birch"
  if (outputWriter.query()) {
    #line 157 "src/filter.birch"
    libbirch_line_(157);
    #line 157 "src/filter.birch"
    outputWriter.get()->endSequence(handler_);
    #line 158 "src/filter.birch"
    libbirch_line_(158);
    #line 158 "src/filter.birch"
    outputWriter.get()->close(handler_);
  }
  #line 20 "src/filter.birch"
  libbirch_line_(20);
  #line 20 "src/filter.birch"
  return 0;
}

#line 20 "src/sample.birch"
int birch::sample(int argc_, char** argv_) {
  #line 20 "src/sample.birch"
  libbirch_function_("sample", "src/sample.birch", 20);
  #line 20 "src/sample.birch"
  libbirch::Optional<birch::type::String> input;
  #line 20 "src/sample.birch"
  libbirch::Optional<birch::type::String> output;
  #line 20 "src/sample.birch"
  libbirch::Optional<birch::type::String> config;
  #line 20 "src/sample.birch"
  libbirch::Optional<birch::type::String> model;
  #line 20 "src/sample.birch"
  libbirch::Optional<birch::type::Integer> seed;
  #line 20 "src/sample.birch"
  birch::type::Boolean quiet = false;
  
  enum {
    inputFLAG_,
    outputFLAG_,
    configFLAG_,
    modelFLAG_,
    seedFLAG_,
    quietFLAG_,
  };
  #line 20 "src/sample.birch"
  int c_, option_index_;
  #line 20 "src/sample.birch"
  option long_options_[] = {
    #line 20 "src/sample.birch"
    {"input", required_argument, 0, inputFLAG_ },
    #line 20 "src/sample.birch"
    {"output", required_argument, 0, outputFLAG_ },
    #line 20 "src/sample.birch"
    {"config", required_argument, 0, configFLAG_ },
    #line 20 "src/sample.birch"
    {"model", required_argument, 0, modelFLAG_ },
    #line 20 "src/sample.birch"
    {"seed", required_argument, 0, seedFLAG_ },
    #line 20 "src/sample.birch"
    {"quiet", required_argument, 0, quietFLAG_ },
    #line 20 "src/sample.birch"
    {0, 0, 0, 0}
  #line 20 "src/sample.birch"
  };
  #line 20 "src/sample.birch"
  const char* short_options_ = ":";
  #line 20 "src/sample.birch"
  ::opterr = 0;
  #line 20 "src/sample.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 20 "src/sample.birch"
  while (c_ != -1) {
    #line 20 "src/sample.birch"
    switch (c_) {
      #line 21 "src/sample.birch"
      case inputFLAG_:
        #line 21 "src/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 21 "src/sample.birch"
        input = birch::String(std::string(::optarg));
        break;
      #line 22 "src/sample.birch"
      case outputFLAG_:
        #line 22 "src/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 22 "src/sample.birch"
        output = birch::String(std::string(::optarg));
        break;
      #line 23 "src/sample.birch"
      case configFLAG_:
        #line 23 "src/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 23 "src/sample.birch"
        config = birch::String(std::string(::optarg));
        break;
      #line 24 "src/sample.birch"
      case modelFLAG_:
        #line 24 "src/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 24 "src/sample.birch"
        model = birch::String(std::string(::optarg));
        break;
      #line 25 "src/sample.birch"
      case seedFLAG_:
        #line 25 "src/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 25 "src/sample.birch"
        seed = birch::Integer(std::string(::optarg));
        break;
      #line 26 "src/sample.birch"
      case quietFLAG_:
        #line 26 "src/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 26 "src/sample.birch"
        quiet = birch::Boolean(std::string(::optarg));
        break;
      #line 20 "src/sample.birch"
      case '?':
        #line 20 "src/sample.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 20 "src/sample.birch"
      case ':':
        #line 20 "src/sample.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 20 "src/sample.birch"
      default:
        #line 20 "src/sample.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 20 "src/sample.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 28 "src/sample.birch"
  libbirch_line_(28);
  #line 28 "src/sample.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> configBuffer;
  #line 29 "src/sample.birch"
  libbirch_line_(29);
  #line 29 "src/sample.birch"
  if (config.query()) {
    #line 30 "src/sample.birch"
    libbirch_line_(30);
    #line 30 "src/sample.birch"
    auto reader = birch::Reader(config.get(), handler_);
    #line 31 "src/sample.birch"
    libbirch_line_(31);
    #line 31 "src/sample.birch"
    configBuffer = reader->scan(handler_);
    #line 32 "src/sample.birch"
    libbirch_line_(32);
    #line 32 "src/sample.birch"
    reader->close(handler_);
  }
  #line 36 "src/sample.birch"
  libbirch_line_(36);
  #line 36 "src/sample.birch"
  if (seed.query()) {
    #line 37 "src/sample.birch"
    libbirch_line_(37);
    #line 37 "src/sample.birch"
    birch::seed(seed.get(), handler_);
  } else {
    #line 38 "src/sample.birch"
    libbirch_line_(38);
    #line 38 "src/sample.birch"
    if (config.query()) {
      #line 39 "src/sample.birch"
      libbirch_line_(39);
      #line 39 "src/sample.birch"
      auto buffer = configBuffer->getInteger(birch::type::String("seed"), handler_);
      #line 40 "src/sample.birch"
      libbirch_line_(40);
      #line 40 "src/sample.birch"
      if (buffer.query()) {
        #line 41 "src/sample.birch"
        libbirch_line_(41);
        #line 41 "src/sample.birch"
        birch::seed(buffer.get(), handler_);
      }
    } else {
      #line 44 "src/sample.birch"
      libbirch_line_(44);
      #line 44 "src/sample.birch"
      birch::seed(handler_);
    }
  }
  #line 48 "src/sample.birch"
  libbirch_line_(48);
  #line 48 "src/sample.birch"
  auto buffer = configBuffer->getObject(birch::type::String("model"), handler_);
  #line 49 "src/sample.birch"
  libbirch_line_(49);
  #line 49 "src/sample.birch"
  if (!buffer.query()) {
    #line 50 "src/sample.birch"
    libbirch_line_(50);
    #line 50 "src/sample.birch"
    buffer = configBuffer->setObject(birch::type::String("model"), handler_);
  }
  #line 52 "src/sample.birch"
  libbirch_line_(52);
  #line 52 "src/sample.birch"
  if (!buffer.get()->getString(birch::type::String("class"), handler_).query() && model.query()) {
    #line 53 "src/sample.birch"
    libbirch_line_(53);
    #line 53 "src/sample.birch"
    buffer.get()->setString(birch::type::String("class"), model.get(), handler_);
  }
  #line 55 "src/sample.birch"
  libbirch_line_(55);
  #line 55 "src/sample.birch"
  auto archetype = libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::Model>>>(birch::make(buffer, handler_));
  #line 56 "src/sample.birch"
  libbirch_line_(56);
  #line 56 "src/sample.birch"
  if (!archetype.query()) {
    #line 57 "src/sample.birch"
    libbirch_line_(57);
    #line 57 "src/sample.birch"
    birch::error(birch::type::String("could not create model; the model class should be given as ") + birch::type::String("model.class in the config file, and should derive from Model."), handler_);
  }
  #line 62 "src/sample.birch"
  libbirch_line_(62);
  #line 62 "src/sample.birch"
  buffer = configBuffer->getObject(birch::type::String("sampler"), handler_);
  #line 63 "src/sample.birch"
  libbirch_line_(63);
  #line 63 "src/sample.birch"
  if (!buffer.query()) {
    #line 64 "src/sample.birch"
    libbirch_line_(64);
    #line 64 "src/sample.birch"
    buffer = configBuffer->setObject(birch::type::String("sampler"), handler_);
  }
  #line 66 "src/sample.birch"
  libbirch_line_(66);
  #line 66 "src/sample.birch"
  if (!buffer.get()->getString(birch::type::String("class"), handler_).query()) {
    #line 67 "src/sample.birch"
    libbirch_line_(67);
    #line 67 "src/sample.birch"
    buffer.get()->setString(birch::type::String("class"), birch::type::String("MarginalizedParticleImportanceSampler"), handler_);
  }
  #line 69 "src/sample.birch"
  libbirch_line_(69);
  #line 69 "src/sample.birch"
  auto sampler = libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::ParticleSampler>>>(birch::make(buffer, handler_));
  #line 70 "src/sample.birch"
  libbirch_line_(70);
  #line 70 "src/sample.birch"
  if (!sampler.query()) {
    #line 71 "src/sample.birch"
    libbirch_line_(71);
    #line 71 "src/sample.birch"
    birch::error(birch::type::String("could not create sampler; the sampler class should be given as ") + birch::type::String("sampler.class in the config file, and should derive from ParticleSampler."), handler_);
  }
  #line 76 "src/sample.birch"
  libbirch_line_(76);
  #line 76 "src/sample.birch"
  buffer = configBuffer->getObject(birch::type::String("filter"), handler_);
  #line 77 "src/sample.birch"
  libbirch_line_(77);
  #line 77 "src/sample.birch"
  if (!buffer.query()) {
    #line 78 "src/sample.birch"
    libbirch_line_(78);
    #line 78 "src/sample.birch"
    buffer = configBuffer->setObject(birch::type::String("filter"), handler_);
  }
  #line 80 "src/sample.birch"
  libbirch_line_(80);
  #line 80 "src/sample.birch"
  if (!buffer.get()->getString(birch::type::String("class"), handler_).query()) {
    #line 81 "src/sample.birch"
    libbirch_line_(81);
    #line 81 "src/sample.birch"
    if (libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::ConditionalParticleSampler>>>(sampler).query()) {
      #line 82 "src/sample.birch"
      libbirch_line_(82);
      #line 82 "src/sample.birch"
      buffer.get()->setString(birch::type::String("class"), birch::type::String("ConditionalParticleFilter"), handler_);
    } else {
      #line 84 "src/sample.birch"
      libbirch_line_(84);
      #line 84 "src/sample.birch"
      buffer.get()->setString(birch::type::String("class"), birch::type::String("ParticleFilter"), handler_);
    }
  }
  #line 87 "src/sample.birch"
  libbirch_line_(87);
  #line 87 "src/sample.birch"
  auto filter = libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::ParticleFilter>>>(birch::make(buffer, handler_));
  #line 88 "src/sample.birch"
  libbirch_line_(88);
  #line 88 "src/sample.birch"
  if (!filter.query()) {
    #line 89 "src/sample.birch"
    libbirch_line_(89);
    #line 89 "src/sample.birch"
    birch::error(birch::type::String("could not create filter; the filter class should be given as ") + birch::type::String("filter.class in the config file, and should derive from ParticleFilter."), handler_);
  }
  #line 94 "src/sample.birch"
  libbirch_line_(94);
  #line 94 "src/sample.birch"
  auto inputPath = input;
  #line 95 "src/sample.birch"
  libbirch_line_(95);
  #line 95 "src/sample.birch"
  if (!inputPath.query()) {
    #line 96 "src/sample.birch"
    libbirch_line_(96);
    #line 96 "src/sample.birch"
    libbirch::optional_assign(inputPath, configBuffer->getString(birch::type::String("input"), handler_));
  }
  #line 98 "src/sample.birch"
  libbirch_line_(98);
  #line 98 "src/sample.birch"
  if (inputPath.query() && inputPath.get() != birch::type::String("")) {
    #line 99 "src/sample.birch"
    libbirch_line_(99);
    #line 99 "src/sample.birch"
    auto reader = birch::Reader(inputPath.get(), handler_);
    #line 100 "src/sample.birch"
    libbirch_line_(100);
    #line 100 "src/sample.birch"
    auto inputBuffer = reader->scan(handler_);
    #line 101 "src/sample.birch"
    libbirch_line_(101);
    #line 101 "src/sample.birch"
    reader->close(handler_);
    #line 102 "src/sample.birch"
    libbirch_line_(102);
    #line 102 "src/sample.birch"
    inputBuffer->get(archetype.get(), handler_);
  }
  #line 106 "src/sample.birch"
  libbirch_line_(106);
  #line 106 "src/sample.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Writer>>> outputWriter;
  #line 107 "src/sample.birch"
  libbirch_line_(107);
  #line 107 "src/sample.birch"
  libbirch::Optional<birch::type::String> outputPath = output;
  #line 108 "src/sample.birch"
  libbirch_line_(108);
  #line 108 "src/sample.birch"
  if (!outputPath.query()) {
    #line 109 "src/sample.birch"
    libbirch_line_(109);
    #line 109 "src/sample.birch"
    libbirch::optional_assign(outputPath, configBuffer->getString(birch::type::String("output"), handler_));
  }
  #line 111 "src/sample.birch"
  libbirch_line_(111);
  #line 111 "src/sample.birch"
  if (outputPath.query() && outputPath.get() != birch::type::String("")) {
    #line 112 "src/sample.birch"
    libbirch_line_(112);
    #line 112 "src/sample.birch"
    outputWriter = birch::Writer(outputPath.get(), handler_);
    #line 113 "src/sample.birch"
    libbirch_line_(113);
    #line 113 "src/sample.birch"
    outputWriter.get()->startSequence(handler_);
  }
  #line 117 "src/sample.birch"
  libbirch_line_(117);
  #line 117 "src/sample.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::ProgressBar>> bar;
  #line 118 "src/sample.birch"
  libbirch_line_(118);
  #line 118 "src/sample.birch"
  if (!quiet) {
    #line 119 "src/sample.birch"
    libbirch_line_(119);
    #line 119 "src/sample.birch"
    bar->update(0.0, handler_);
  }
  #line 123 "src/sample.birch"
  libbirch_line_(123);
  #line 123 "src/sample.birch"
  sampler.get()->sample(filter.get(), archetype.get(), handler_);
  #line 124 "src/sample.birch"
  libbirch_line_(124);
  #line 124 "src/sample.birch"
  for (auto n = birch::type::Integer(1); n <= sampler.get()->size(handler_); ++n) {
    #line 125 "src/sample.birch"
    libbirch_line_(125);
    #line 125 "src/sample.birch"
    sampler.get()->sample(filter.get(), archetype.get(), n, handler_);
    #line 127 "src/sample.birch"
    libbirch_line_(127);
    #line 127 "src/sample.birch"
    if (outputWriter.query()) {
      #line 128 "src/sample.birch"
      libbirch_line_(128);
      #line 128 "src/sample.birch"
      libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> buffer;
      #line 129 "src/sample.birch"
      libbirch_line_(129);
      #line 129 "src/sample.birch"
      sampler.get()->write(buffer, n, handler_);
      #line 130 "src/sample.birch"
      libbirch_line_(130);
      #line 130 "src/sample.birch"
      outputWriter.get()->print(buffer, handler_);
      #line 131 "src/sample.birch"
      libbirch_line_(131);
      #line 131 "src/sample.birch"
      outputWriter.get()->flush(handler_);
    }
    #line 133 "src/sample.birch"
    libbirch_line_(133);
    #line 133 "src/sample.birch"
    if (!quiet) {
      #line 134 "src/sample.birch"
      libbirch_line_(134);
      #line 134 "src/sample.birch"
      bar->update(birch::Real(n, handler_) / sampler.get()->nsamples, handler_);
    }
  }
  #line 139 "src/sample.birch"
  libbirch_line_(139);
  #line 139 "src/sample.birch"
  if (outputWriter.query()) {
    #line 140 "src/sample.birch"
    libbirch_line_(140);
    #line 140 "src/sample.birch"
    outputWriter.get()->endSequence(handler_);
    #line 141 "src/sample.birch"
    libbirch_line_(141);
    #line 141 "src/sample.birch"
    outputWriter.get()->close(handler_);
  }
  #line 20 "src/sample.birch"
  libbirch_line_(20);
  #line 20 "src/sample.birch"
  return 0;
}

