#line 15 "src/model/Model.birch"
birch::type::Model::Model() :
    #line 15 "src/model/Model.birch"
    base_type_() {
  //
}

#line 19 "src/model/Model.birch"
void birch::type::Model::simulate() {
  #line 19 "src/model/Model.birch"
  libbirch_function_("simulate", "src/model/Model.birch", 19);
}

#line 28 "src/model/Model.birch"
void birch::type::Model::simulate(const birch::type::Integer& t) {
  #line 28 "src/model/Model.birch"
  libbirch_function_("simulate", "src/model/Model.birch", 28);
}

#line 35 "src/model/Model.birch"
void birch::type::Model::read(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 35 "src/model/Model.birch"
  libbirch_function_("read", "src/model/Model.birch", 35);
  #line 36 "src/model/Model.birch"
  libbirch_line_(36);
  #line 36 "src/model/Model.birch"
  this->base_type_::read(buffer);
}

#line 42 "src/model/Model.birch"
void birch::type::Model::read(const birch::type::Integer& t, const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 42 "src/model/Model.birch"
  libbirch_function_("read", "src/model/Model.birch", 42);
}

#line 49 "src/model/Model.birch"
void birch::type::Model::write(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 49 "src/model/Model.birch"
  libbirch_function_("write", "src/model/Model.birch", 49);
  #line 50 "src/model/Model.birch"
  libbirch_line_(50);
  #line 50 "src/model/Model.birch"
  this->base_type_::write(buffer);
}

#line 56 "src/model/Model.birch"
void birch::type::Model::write(const birch::type::Integer& t, const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 56 "src/model/Model.birch"
  libbirch_function_("write", "src/model/Model.birch", 56);
}

