#line 17 "src/event/Event.birch"
birch::type::Event::Event(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 17 "src/event/Event.birch"
    super_type_() {
  //
}

#line 19 "src/event/FactorEvent.birch"
birch::type::FactorEvent::FactorEvent(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& w, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 19 "src/event/FactorEvent.birch"
    super_type_(),
    #line 23 "src/event/FactorEvent.birch"
    w(w) {
  //
}

#line 25 "src/event/FactorEvent.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Record>> birch::type::FactorEvent::record(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/event/FactorEvent.birch"
  libbirch_function_("record", "src/event/FactorEvent.birch", 25);
  #line 26 "src/event/FactorEvent.birch"
  libbirch_line_(26);
  #line 26 "src/event/FactorEvent.birch"
  return birch::FactorRecord(handler_);
}

#line 29 "src/event/FactorEvent.birch"
libbirch::Lazy<libbirch::Shared<birch::type::FactorRecord>> birch::type::FactorEvent::coerce(const libbirch::Lazy<libbirch::Shared<birch::type::Record>>& record, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "src/event/FactorEvent.birch"
  libbirch_function_("coerce", "src/event/FactorEvent.birch", 29);
  #line 30 "src/event/FactorEvent.birch"
  libbirch_line_(30);
  #line 30 "src/event/FactorEvent.birch"
  auto r = libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::FactorRecord>>>(record);
  #line 31 "src/event/FactorEvent.birch"
  libbirch_line_(31);
  #line 31 "src/event/FactorEvent.birch"
  if (!r.query()) {
    #line 32 "src/event/FactorEvent.birch"
    libbirch_line_(32);
    #line 32 "src/event/FactorEvent.birch"
    birch::error(birch::type::String("incompatible trace"), handler_);
  }
  #line 34 "src/event/FactorEvent.birch"
  libbirch_line_(34);
  #line 34 "src/event/FactorEvent.birch"
  return r.get();
}

#line 37 "src/event/FactorEvent.birch"
void birch::type::FactorEvent::accept(const libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>>& handler, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/event/FactorEvent.birch"
  libbirch_function_("accept", "src/event/FactorEvent.birch", 37);
  #line 38 "src/event/FactorEvent.birch"
  libbirch_line_(38);
  #line 38 "src/event/FactorEvent.birch"
  handler->doHandle(shared_from_this_(), handler_);
}

#line 41 "src/event/FactorEvent.birch"
void birch::type::FactorEvent::accept(const libbirch::Lazy<libbirch::Shared<birch::type::MoveHandler>>& handler, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "src/event/FactorEvent.birch"
  libbirch_function_("accept", "src/event/FactorEvent.birch", 41);
  #line 42 "src/event/FactorEvent.birch"
  libbirch_line_(42);
  #line 42 "src/event/FactorEvent.birch"
  handler->doHandle(shared_from_this_(), handler_);
}

#line 45 "src/event/FactorEvent.birch"
void birch::type::FactorEvent::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Record>>& record, const libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>>& handler, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "src/event/FactorEvent.birch"
  libbirch_function_("accept", "src/event/FactorEvent.birch", 45);
  #line 46 "src/event/FactorEvent.birch"
  libbirch_line_(46);
  #line 46 "src/event/FactorEvent.birch"
  handler->doHandle(this_()->coerce(record, handler_), shared_from_this_(), handler_);
}

#line 49 "src/event/FactorEvent.birch"
void birch::type::FactorEvent::accept(const libbirch::Lazy<libbirch::Shared<birch::type::Record>>& record, const libbirch::Lazy<libbirch::Shared<birch::type::MoveHandler>>& handler, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/event/FactorEvent.birch"
  libbirch_function_("accept", "src/event/FactorEvent.birch", 49);
  #line 50 "src/event/FactorEvent.birch"
  libbirch_line_(50);
  #line 50 "src/event/FactorEvent.birch"
  handler->doHandle(this_()->coerce(record, handler_), shared_from_this_(), handler_);
}

#line 57 "src/event/FactorEvent.birch"
libbirch::Lazy<libbirch::Shared<birch::type::FactorEvent>> birch::FactorEvent(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& w, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 57 "src/event/FactorEvent.birch"
  libbirch_function_("FactorEvent", "src/event/FactorEvent.birch", 57);
  #line 58 "src/event/FactorEvent.birch"
  libbirch_line_(58);
  #line 58 "src/event/FactorEvent.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::FactorEvent>>>(w, handler_);
}

#line 64 "src/event/FactorEvent.birch"
libbirch::Lazy<libbirch::Shared<birch::type::FactorEvent>> birch::FactorEvent(const birch::type::Real& w, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "src/event/FactorEvent.birch"
  libbirch_function_("FactorEvent", "src/event/FactorEvent.birch", 64);
  #line 65 "src/event/FactorEvent.birch"
  libbirch_line_(65);
  #line 65 "src/event/FactorEvent.birch"
  return birch::FactorEvent(birch::box(w, handler_), handler_);
}

