#line 17 "src/event/Event.birch"
birch::type::Event::Event() :
    #line 17 "src/event/Event.birch"
    base_type_() {
  //
}

#line 19 "src/event/FactorEvent.birch"
birch::type::FactorEvent::FactorEvent(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& w) :
    #line 19 "src/event/FactorEvent.birch"
    base_type_(),
    #line 23 "src/event/FactorEvent.birch"
    w(std::move(w)) {
  //
}

#line 25 "src/event/FactorEvent.birch"
libbirch::Shared<birch::type::Record> birch::type::FactorEvent::record() {
  #line 25 "src/event/FactorEvent.birch"
  libbirch_function_("record", "src/event/FactorEvent.birch", 25);
  #line 26 "src/event/FactorEvent.birch"
  libbirch_line_(26);
  #line 26 "src/event/FactorEvent.birch"
  return birch::FactorRecord();
}

#line 29 "src/event/FactorEvent.birch"
libbirch::Shared<birch::type::FactorRecord> birch::type::FactorEvent::coerce(const libbirch::Shared<birch::type::Record>& record) {
  #line 29 "src/event/FactorEvent.birch"
  libbirch_function_("coerce", "src/event/FactorEvent.birch", 29);
  #line 30 "src/event/FactorEvent.birch"
  libbirch_line_(30);
  #line 30 "src/event/FactorEvent.birch"
  auto r = libbirch::cast<libbirch::Shared<birch::type::FactorRecord>>(record);
  #line 31 "src/event/FactorEvent.birch"
  libbirch_line_(31);
  #line 31 "src/event/FactorEvent.birch"
  if (!(r.has_value())) {
    #line 32 "src/event/FactorEvent.birch"
    libbirch_line_(32);
    #line 32 "src/event/FactorEvent.birch"
    birch::error(birch::type::String("incompatible trace"));
  }
  #line 34 "src/event/FactorEvent.birch"
  libbirch_line_(34);
  #line 34 "src/event/FactorEvent.birch"
  return r.value();
}

#line 37 "src/event/FactorEvent.birch"
void birch::type::FactorEvent::accept(const libbirch::Shared<birch::type::PlayHandler>& handler) {
  #line 37 "src/event/FactorEvent.birch"
  libbirch_function_("accept", "src/event/FactorEvent.birch", 37);
  #line 38 "src/event/FactorEvent.birch"
  libbirch_line_(38);
  #line 38 "src/event/FactorEvent.birch"
  handler->doHandle(this->shared_from_this_());
}

#line 41 "src/event/FactorEvent.birch"
void birch::type::FactorEvent::accept(const libbirch::Shared<birch::type::MoveHandler>& handler) {
  #line 41 "src/event/FactorEvent.birch"
  libbirch_function_("accept", "src/event/FactorEvent.birch", 41);
  #line 42 "src/event/FactorEvent.birch"
  libbirch_line_(42);
  #line 42 "src/event/FactorEvent.birch"
  handler->doHandle(this->shared_from_this_());
}

#line 45 "src/event/FactorEvent.birch"
void birch::type::FactorEvent::accept(const libbirch::Shared<birch::type::Record>& record, const libbirch::Shared<birch::type::PlayHandler>& handler) {
  #line 45 "src/event/FactorEvent.birch"
  libbirch_function_("accept", "src/event/FactorEvent.birch", 45);
  #line 46 "src/event/FactorEvent.birch"
  libbirch_line_(46);
  #line 46 "src/event/FactorEvent.birch"
  handler->doHandle(this->coerce(record), this->shared_from_this_());
}

#line 49 "src/event/FactorEvent.birch"
void birch::type::FactorEvent::accept(const libbirch::Shared<birch::type::Record>& record, const libbirch::Shared<birch::type::MoveHandler>& handler) {
  #line 49 "src/event/FactorEvent.birch"
  libbirch_function_("accept", "src/event/FactorEvent.birch", 49);
  #line 50 "src/event/FactorEvent.birch"
  libbirch_line_(50);
  #line 50 "src/event/FactorEvent.birch"
  handler->doHandle(this->coerce(record), this->shared_from_this_());
}

#line 57 "src/event/FactorEvent.birch"
libbirch::Shared<birch::type::FactorEvent> birch::FactorEvent(const libbirch::Shared<birch::type::Expression<birch::type::Real>>& w) {
  #line 57 "src/event/FactorEvent.birch"
  libbirch_function_("FactorEvent", "src/event/FactorEvent.birch", 57);
  #line 58 "src/event/FactorEvent.birch"
  libbirch_line_(58);
  #line 58 "src/event/FactorEvent.birch"
  return birch::construct<libbirch::Shared<birch::type::FactorEvent>>(w);
}

#line 64 "src/event/FactorEvent.birch"
libbirch::Shared<birch::type::FactorEvent> birch::FactorEvent(const birch::type::Real& w) {
  #line 64 "src/event/FactorEvent.birch"
  libbirch_function_("FactorEvent", "src/event/FactorEvent.birch", 64);
  #line 65 "src/event/FactorEvent.birch"
  libbirch_line_(65);
  #line 65 "src/event/FactorEvent.birch"
  return birch::FactorEvent(birch::box(w));
}

