#line 1 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian::TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    super_type_(),
    #line 2 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    _u09632(),
    #line 3 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    X(),
    #line 4 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    Y(),
    #line 6 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    n(birch::type::Integer(5)),
    #line 7 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    p(birch::type::Integer(2)),
    #line 8 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    A(libbirch::make_shape(n, n)),
    #line 9 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    M(libbirch::make_shape(n, p)),
    #line 10 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    _u0931(libbirch::make_shape(n, n)),
    #line 11 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    C(libbirch::make_shape(n, p)),
    #line 12 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    _u0945(),
    #line 13 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    _u0946(libbirch::make_shape(p)) {
  //
}

#line 15 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
void birch::type::TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch", 15);
  #line 16 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->_u0945 = birch::simulate_uniform(2.0, 10.0, handler_);
  #line 17 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= this_()->n; ++i) {
    #line 18 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    libbirch_line_(18);
    #line 18 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= this_()->n; ++j) {
      #line 19 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
      libbirch_line_(19);
      #line 19 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
      this_()->A.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
      #line 20 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
      libbirch_line_(20);
      #line 20 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
      this_()->_u0931.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
    }
    #line 22 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    libbirch_line_(22);
    #line 22 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= this_()->p; ++j) {
      #line 23 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
      libbirch_line_(23);
      #line 23 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
      this_()->M.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
      #line 24 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
      libbirch_line_(24);
      #line 24 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
      this_()->C.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    }
  }
  #line 27 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= this_()->p; ++i) {
    #line 28 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    libbirch_line_(28);
    #line 28 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    this_()->_u0946.set(libbirch::make_slice(i - 1), birch::simulate_uniform(0.0, 10.0, handler_));
  }
  #line 30 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->_u0931 = this_()->_u0931 * birch::transpose(this_()->_u0931, handler_);
}

#line 33 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
void birch::type::TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch", 33);
  #line 34 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u09632, (birch::InverseGamma(this_()->_u0945, this_()->_u0946, handler_))->distribution(), handler_), handler_);
  #line 35 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->X, (birch::Gaussian(this_()->M, this_()->_u0931, this_()->_u09632, handler_))->distribution(), handler_), handler_);
  #line 36 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->Y, (birch::Gaussian(this_()->A * this_()->X - this_()->C, this_()->_u09632, handler_))->distribution(), handler_), handler_);
}

#line 39 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch", 39);
  #line 40 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_assert_(!this_()->_u09632->hasValue(handler_));
  #line 41 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->_u09632->value(handler_);
  #line 42 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_assert_(!this_()->X->hasValue(handler_));
  #line 43 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->X->value(handler_);
  #line 44 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_assert_(!this_()->Y->hasValue(handler_));
  #line 45 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->Y->value(handler_);
  #line 46 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return this_()->vectorize(handler_);
}

#line 49 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch", 49);
  #line 50 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(50);
  #line 50 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_assert_(!this_()->Y->hasValue(handler_));
  #line 51 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->Y->value(handler_);
  #line 52 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_assert_(!this_()->X->hasValue(handler_));
  #line 53 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(53);
  #line 53 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->X->value(handler_);
  #line 54 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_assert_(!this_()->_u09632->hasValue(handler_));
  #line 55 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(55);
  #line 55 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->_u09632->value(handler_);
  #line 56 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return this_()->vectorize(handler_);
}

#line 59 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>> birch::type::TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch", 59);
  #line 60 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(60);
  #line 60 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return this_()->Y->distribution(handler_).get();
}

#line 63 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian::vectorize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 63 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("vectorize", "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch", 63);
  #line 64 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(64);
  #line 64 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(this_()->size(handler_)));
  #line 65 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(65);
  #line 65 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, birch::length(this_()->_u09632, handler_) - 1)), this_()->_u09632->value(handler_));
  #line 66 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  auto k = birch::length(this_()->_u09632, handler_);
  #line 67 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(67);
  #line 67 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(this_()->X, handler_); ++i) {
    #line 68 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    libbirch_line_(68);
    #line 68 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    y.set(libbirch::make_slice(libbirch::make_range(k + birch::type::Integer(1) - 1, k + birch::columns(this_()->X, handler_) - 1)), this_()->X->value(handler_).get(libbirch::make_slice(i - 1, libbirch::make_range(birch::type::Integer(1) - 1, birch::columns(this_()->X, handler_) - 1))));
    #line 69 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    libbirch_line_(69);
    #line 69 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    k = k + birch::columns(this_()->X, handler_);
  }
  #line 71 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(71);
  #line 71 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(this_()->Y, handler_); ++i) {
    #line 72 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    libbirch_line_(72);
    #line 72 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    y.set(libbirch::make_slice(libbirch::make_range(k + birch::type::Integer(1) - 1, k + birch::columns(this_()->Y, handler_) - 1)), this_()->Y->value(handler_).get(libbirch::make_slice(i - 1, libbirch::make_range(birch::type::Integer(1) - 1, birch::columns(this_()->Y, handler_) - 1))));
    #line 73 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    libbirch_line_(73);
    #line 73 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    k = k + birch::columns(this_()->Y, handler_);
  }
  #line 75 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(75);
  #line 75 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return y;
}

#line 78 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::Integer birch::type::TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian::size(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 78 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("size", "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch", 78);
  #line 79 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(79);
  #line 79 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return this_()->p + birch::type::Integer(2) * this_()->n * this_()->p;
}

#line 1 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian* birch::type::make_TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian_() {
  #line 1 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return new birch::type::TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian();
  #line 1 "src/test/model/TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian.birch"
}

#line 1 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
birch::type::TestMultivariateGaussianMultivariateGaussian::TestMultivariateGaussianMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
    super_type_(),
    #line 2 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
    _u0956_1(),
    #line 3 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
    x(),
    #line 5 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
    _u0956_0(libbirch::make_shape(birch::type::Integer(5))),
    #line 6 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
    _u0931_0(libbirch::make_shape(birch::type::Integer(5), birch::type::Integer(5))),
    #line 7 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
    _u0931_1(libbirch::make_shape(birch::type::Integer(5), birch::type::Integer(5))) {
  //
}

#line 9 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
void birch::type::TestMultivariateGaussianMultivariateGaussian::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch", 9);
  #line 10 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(10);
  #line 10 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(5); ++i) {
    #line 11 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
    libbirch_line_(11);
    #line 11 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
    this_()->_u0956_0.set(libbirch::make_slice(i - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    #line 12 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
    libbirch_line_(12);
    #line 12 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= birch::type::Integer(5); ++j) {
      #line 13 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
      libbirch_line_(13);
      #line 13 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
      this_()->_u0931_0.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
      #line 14 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
      libbirch_line_(14);
      #line 14 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
      this_()->_u0931_1.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
    }
  }
  #line 17 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  this_()->_u0931_0 = this_()->_u0931_0 * birch::transpose(this_()->_u0931_0, handler_);
  #line 18 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  this_()->_u0931_1 = this_()->_u0931_1 * birch::transpose(this_()->_u0931_1, handler_);
}

#line 21 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
void birch::type::TestMultivariateGaussianMultivariateGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch", 21);
  #line 22 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0956_1, (birch::Gaussian(this_()->_u0956_0, this_()->_u0931_0, handler_))->distribution(), handler_), handler_);
  #line 23 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Gaussian(this_()->_u0956_1, this_()->_u0931_1, handler_))->distribution(), handler_), handler_);
}

#line 26 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestMultivariateGaussianMultivariateGaussian::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch", 26);
  #line 27 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(10)));
  #line 28 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, birch::type::Integer(5) - 1)), this_()->_u0956_1->value(handler_));
  #line 29 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 30 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(6) - 1, birch::type::Integer(10) - 1)), this_()->x->value(handler_));
  #line 31 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  return y;
}

#line 34 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestMultivariateGaussianMultivariateGaussian::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch", 34);
  #line 35 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(10)));
  #line 36 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(6) - 1, birch::type::Integer(10) - 1)), this_()->x->value(handler_));
  #line 37 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_assert_(!this_()->_u0956_1->hasValue(handler_));
  #line 38 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, birch::type::Integer(5) - 1)), this_()->_u0956_1->value(handler_));
  #line 39 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  return y;
}

#line 42 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>> birch::type::TestMultivariateGaussianMultivariateGaussian::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch", 42);
  #line 43 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
birch::type::TestMultivariateGaussianMultivariateGaussian* birch::type::make_TestMultivariateGaussianMultivariateGaussian_() {
  #line 1 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  return new birch::type::TestMultivariateGaussianMultivariateGaussian();
  #line 1 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
}

#line 1 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::TestMultivariateNormalInverseGammaMultivariateGaussian::TestMultivariateNormalInverseGammaMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    super_type_(),
    #line 2 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    _u09632(),
    #line 3 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    _u0956(),
    #line 4 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    x(),
    #line 6 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    _u0956_0(libbirch::make_shape(birch::type::Integer(5))),
    #line 7 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    A(libbirch::make_shape(birch::type::Integer(5), birch::type::Integer(5))),
    #line 8 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    _u0945(),
    #line 9 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    _u0946() {
  //
}

#line 11 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::TestMultivariateNormalInverseGammaMultivariateGaussian::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch", 11);
  #line 12 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  this_()->_u0945 = birch::simulate_uniform(2.0, 10.0, handler_);
  #line 13 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  this_()->_u0946 = birch::simulate_uniform(0.0, 10.0, handler_);
  #line 14 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(5); ++i) {
    #line 15 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    libbirch_line_(15);
    #line 15 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    this_()->_u0956_0.set(libbirch::make_slice(i - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    #line 16 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    libbirch_line_(16);
    #line 16 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= birch::type::Integer(5); ++j) {
      #line 17 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
      libbirch_line_(17);
      #line 17 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
      this_()->A.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
    }
  }
  #line 20 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  this_()->A = this_()->A * birch::transpose(this_()->A, handler_);
}

#line 23 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::TestMultivariateNormalInverseGammaMultivariateGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch", 23);
  #line 24 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u09632, (birch::InverseGamma(this_()->_u0945, this_()->_u0946, handler_))->distribution(), handler_), handler_);
  #line 25 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0956, (birch::Gaussian(this_()->_u0956_0, this_()->A, this_()->_u09632, handler_))->distribution(), handler_), handler_);
  #line 26 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Gaussian(this_()->_u0956, this_()->_u09632, handler_))->distribution(), handler_), handler_);
}

#line 29 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestMultivariateNormalInverseGammaMultivariateGaussian::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch", 29);
  #line 30 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(11)));
  #line 31 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u09632->value(handler_));
  #line 32 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_assert_(!this_()->_u0956->hasValue(handler_));
  #line 33 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(2) - 1, birch::type::Integer(6) - 1)), this_()->_u0956->value(handler_));
  #line 34 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 35 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(7) - 1, birch::type::Integer(11) - 1)), this_()->x->value(handler_));
  #line 36 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return y;
}

#line 39 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestMultivariateNormalInverseGammaMultivariateGaussian::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch", 39);
  #line 40 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(11)));
  #line 41 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(7) - 1, birch::type::Integer(11) - 1)), this_()->x->value(handler_));
  #line 42 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_assert_(!this_()->_u0956->hasValue(handler_));
  #line 43 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(2) - 1, birch::type::Integer(6) - 1)), this_()->_u0956->value(handler_));
  #line 44 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_assert_(!this_()->_u09632->hasValue(handler_));
  #line 45 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u09632->value(handler_));
  #line 46 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return y;
}

#line 49 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>> birch::type::TestMultivariateNormalInverseGammaMultivariateGaussian::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch", 49);
  #line 50 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(50);
  #line 50 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::TestMultivariateNormalInverseGammaMultivariateGaussian* birch::type::make_TestMultivariateNormalInverseGammaMultivariateGaussian_() {
  #line 1 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return new birch::type::TestMultivariateNormalInverseGammaMultivariateGaussian();
  #line 1 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
}

#line 1 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian::TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    super_type_(),
    #line 2 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    V(),
    #line 3 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    X(),
    #line 4 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    Y(),
    #line 6 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    n(birch::type::Integer(5)),
    #line 7 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    p(birch::type::Integer(2)),
    #line 8 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    A(libbirch::make_shape(n, n)),
    #line 9 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    M(libbirch::make_shape(n, p)),
    #line 10 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    U(libbirch::make_shape(n, n)),
    #line 11 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    C(libbirch::make_shape(n, p)),
    #line 12 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    k(),
    #line 13 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    _u0936(libbirch::make_shape(p, p)) {
  //
}

#line 15 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch", 15);
  #line 16 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->k = birch::simulate_uniform(this_()->p - 1.0, this_()->p + 9.0, handler_);
  #line 17 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= this_()->n; ++i) {
    #line 18 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(18);
    #line 18 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= this_()->n; ++j) {
      #line 19 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      libbirch_line_(19);
      #line 19 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      this_()->A.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
      #line 20 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      libbirch_line_(20);
      #line 20 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      this_()->U.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
    }
    #line 22 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(22);
    #line 22 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= this_()->p; ++j) {
      #line 23 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      libbirch_line_(23);
      #line 23 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      this_()->M.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
      #line 24 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      libbirch_line_(24);
      #line 24 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      this_()->C.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    }
  }
  #line 27 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= this_()->p; ++i) {
    #line 28 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(28);
    #line 28 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= this_()->p; ++j) {
      #line 29 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      libbirch_line_(29);
      #line 29 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      this_()->_u0936.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    }
  }
  #line 32 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->U = this_()->U * birch::transpose(this_()->U, handler_);
  #line 33 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->_u0936 = this_()->_u0936 * birch::transpose(this_()->_u0936, handler_);
}

#line 36 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch", 36);
  #line 37 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->V, (birch::InverseWishart(this_()->_u0936, this_()->k, handler_))->distribution(), handler_), handler_);
  #line 38 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->X, (birch::Gaussian(this_()->M, this_()->U, this_()->V, handler_))->distribution(), handler_), handler_);
  #line 39 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->Y, (birch::Gaussian(this_()->A * this_()->X - this_()->C, this_()->V, handler_))->distribution(), handler_), handler_);
}

#line 42 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch", 42);
  #line 43 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!this_()->V->hasValue(handler_));
  #line 44 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->V->value(handler_);
  #line 45 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!this_()->X->hasValue(handler_));
  #line 46 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->X->value(handler_);
  #line 47 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!this_()->Y->hasValue(handler_));
  #line 48 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->Y->value(handler_);
  #line 49 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(49);
  #line 49 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return this_()->vectorize(handler_);
}

#line 52 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch", 52);
  #line 53 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(53);
  #line 53 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!this_()->Y->hasValue(handler_));
  #line 54 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->Y->value(handler_);
  #line 55 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(55);
  #line 55 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!this_()->X->hasValue(handler_));
  #line 56 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->X->value(handler_);
  #line 57 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(57);
  #line 57 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!this_()->V->hasValue(handler_));
  #line 58 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(58);
  #line 58 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->V->value(handler_);
  #line 59 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(59);
  #line 59 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return this_()->vectorize(handler_);
}

#line 62 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>> birch::type::TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 62 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch", 62);
  #line 63 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(63);
  #line 63 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return this_()->Y->distribution(handler_).get();
}

#line 66 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian::vectorize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("vectorize", "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch", 66);
  #line 67 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(67);
  #line 67 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(this_()->size(handler_)));
  #line 68 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(68);
  #line 68 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  auto k = birch::type::Integer(0);
  #line 69 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(69);
  #line 69 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(this_()->V, handler_); ++i) {
    #line 70 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(70);
    #line 70 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    y.set(libbirch::make_slice(libbirch::make_range(k + birch::type::Integer(1) - 1, k + birch::columns(this_()->V, handler_) - 1)), birch::canonical(this_()->V->value(handler_), handler_).get(libbirch::make_slice(i - 1, libbirch::make_range(birch::type::Integer(1) - 1, birch::columns(this_()->V, handler_) - 1))));
    #line 71 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(71);
    #line 71 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    k = k + birch::columns(this_()->V, handler_);
  }
  #line 73 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(73);
  #line 73 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(this_()->X, handler_); ++i) {
    #line 74 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(74);
    #line 74 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    y.set(libbirch::make_slice(libbirch::make_range(k + birch::type::Integer(1) - 1, k + birch::columns(this_()->X, handler_) - 1)), this_()->X->value(handler_).get(libbirch::make_slice(i - 1, libbirch::make_range(birch::type::Integer(1) - 1, birch::columns(this_()->X, handler_) - 1))));
    #line 75 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(75);
    #line 75 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    k = k + birch::columns(this_()->X, handler_);
  }
  #line 77 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(77);
  #line 77 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(this_()->Y, handler_); ++i) {
    #line 78 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(78);
    #line 78 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    y.set(libbirch::make_slice(libbirch::make_range(k + birch::type::Integer(1) - 1, k + birch::columns(this_()->Y, handler_) - 1)), this_()->Y->value(handler_).get(libbirch::make_slice(i - 1, libbirch::make_range(birch::type::Integer(1) - 1, birch::columns(this_()->Y, handler_) - 1))));
    #line 79 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(79);
    #line 79 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    k = k + birch::columns(this_()->Y, handler_);
  }
  #line 81 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(81);
  #line 81 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return y;
}

#line 84 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Integer birch::type::TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian::size(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 84 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("size", "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch", 84);
  #line 85 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(85);
  #line 85 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return this_()->p * this_()->p + birch::type::Integer(2) * this_()->n * this_()->p;
}

#line 1 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian* birch::type::make_TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian_() {
  #line 1 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return new birch::type::TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian();
  #line 1 "src/test/model/TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian.birch"
}

#line 1 "src/test/model/TestBetaBinomial.birch"
birch::type::TestBetaBinomial::TestBetaBinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestBetaBinomial.birch"
    super_type_(),
    #line 2 "src/test/model/TestBetaBinomial.birch"
    _u0961(),
    #line 3 "src/test/model/TestBetaBinomial.birch"
    x(),
    #line 4 "src/test/model/TestBetaBinomial.birch"
    n(),
    #line 5 "src/test/model/TestBetaBinomial.birch"
    _u0945(),
    #line 6 "src/test/model/TestBetaBinomial.birch"
    _u0946() {
  //
}

#line 8 "src/test/model/TestBetaBinomial.birch"
void birch::type::TestBetaBinomial::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 8 "src/test/model/TestBetaBinomial.birch"
  libbirch_function_("initialize", "src/test/model/TestBetaBinomial.birch", 8);
  #line 9 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(9);
  #line 9 "src/test/model/TestBetaBinomial.birch"
  this_()->n = birch::simulate_uniform_int(birch::type::Integer(1), birch::type::Integer(100), handler_);
  #line 10 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(10);
  #line 10 "src/test/model/TestBetaBinomial.birch"
  this_()->_u0945 = birch::simulate_uniform(1.0, 10.0, handler_);
  #line 11 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(11);
  #line 11 "src/test/model/TestBetaBinomial.birch"
  this_()->_u0946 = birch::simulate_uniform(1.0, 10.0, handler_);
}

#line 14 "src/test/model/TestBetaBinomial.birch"
void birch::type::TestBetaBinomial::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/test/model/TestBetaBinomial.birch"
  libbirch_function_("simulate", "src/test/model/TestBetaBinomial.birch", 14);
  #line 15 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestBetaBinomial.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0961, (birch::Beta(this_()->_u0945, this_()->_u0946, handler_))->distribution(), handler_), handler_);
  #line 16 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestBetaBinomial.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Binomial(this_()->n, this_()->_u0961, handler_))->distribution(), handler_), handler_);
}

#line 19 "src/test/model/TestBetaBinomial.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestBetaBinomial::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/test/model/TestBetaBinomial.birch"
  libbirch_function_("forward", "src/test/model/TestBetaBinomial.birch", 19);
  #line 20 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestBetaBinomial.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 21 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestBetaBinomial.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0961->value(handler_));
  #line 22 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestBetaBinomial.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 23 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestBetaBinomial.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 24 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestBetaBinomial.birch"
  return y;
}

#line 27 "src/test/model/TestBetaBinomial.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestBetaBinomial::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/test/model/TestBetaBinomial.birch"
  libbirch_function_("backward", "src/test/model/TestBetaBinomial.birch", 27);
  #line 28 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestBetaBinomial.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 29 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestBetaBinomial.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 30 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestBetaBinomial.birch"
  libbirch_assert_(!this_()->_u0961->hasValue(handler_));
  #line 31 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestBetaBinomial.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0961->value(handler_));
  #line 32 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestBetaBinomial.birch"
  return y;
}

#line 35 "src/test/model/TestBetaBinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> birch::type::TestBetaBinomial::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "src/test/model/TestBetaBinomial.birch"
  libbirch_function_("marginal", "src/test/model/TestBetaBinomial.birch", 35);
  #line 36 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestBetaBinomial.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestBetaBinomial.birch"
birch::type::TestBetaBinomial* birch::type::make_TestBetaBinomial_() {
  #line 1 "src/test/model/TestBetaBinomial.birch"
  return new birch::type::TestBetaBinomial();
  #line 1 "src/test/model/TestBetaBinomial.birch"
}

#line 1 "src/test/model/TestChainMultivariateGaussian.birch"
birch::type::TestChainMultivariateGaussian::TestChainMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestChainMultivariateGaussian.birch"
    super_type_(),
    #line 2 "src/test/model/TestChainMultivariateGaussian.birch"
    x(libbirch::make_shape(birch::type::Integer(5))),
    #line 3 "src/test/model/TestChainMultivariateGaussian.birch"
    _u0956(libbirch::make_shape(birch::type::Integer(3))),
    #line 4 "src/test/model/TestChainMultivariateGaussian.birch"
    _u0931(libbirch::make_shape(birch::type::Integer(3), birch::type::Integer(3))) {
  //
}

#line 6 "src/test/model/TestChainMultivariateGaussian.birch"
void birch::type::TestChainMultivariateGaussian::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 6 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestChainMultivariateGaussian.birch", 6);
  #line 7 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/model/TestChainMultivariateGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(3); ++i) {
    #line 8 "src/test/model/TestChainMultivariateGaussian.birch"
    libbirch_line_(8);
    #line 8 "src/test/model/TestChainMultivariateGaussian.birch"
    this_()->_u0956.set(libbirch::make_slice(i - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    #line 9 "src/test/model/TestChainMultivariateGaussian.birch"
    libbirch_line_(9);
    #line 9 "src/test/model/TestChainMultivariateGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= birch::type::Integer(3); ++j) {
      #line 10 "src/test/model/TestChainMultivariateGaussian.birch"
      libbirch_line_(10);
      #line 10 "src/test/model/TestChainMultivariateGaussian.birch"
      this_()->_u0931.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
    }
  }
  #line 13 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestChainMultivariateGaussian.birch"
  this_()->_u0931 = this_()->_u0931 * birch::transpose(this_()->_u0931, handler_);
}

#line 16 "src/test/model/TestChainMultivariateGaussian.birch"
void birch::type::TestChainMultivariateGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestChainMultivariateGaussian.birch", 16);
  #line 17 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x.get(libbirch::make_slice(birch::type::Integer(1) - 1)), (birch::Gaussian(this_()->_u0956, this_()->_u0931, handler_))->distribution(), handler_), handler_);
  #line 18 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x.get(libbirch::make_slice(birch::type::Integer(2) - 1)), (birch::Gaussian(this_()->x.get(libbirch::make_slice(birch::type::Integer(1) - 1)), this_()->_u0931, handler_))->distribution(), handler_), handler_);
  #line 19 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x.get(libbirch::make_slice(birch::type::Integer(3) - 1)), (birch::Gaussian(this_()->x.get(libbirch::make_slice(birch::type::Integer(2) - 1)), this_()->_u0931, handler_))->distribution(), handler_), handler_);
  #line 20 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x.get(libbirch::make_slice(birch::type::Integer(4) - 1)), (birch::Gaussian(this_()->x.get(libbirch::make_slice(birch::type::Integer(3) - 1)), this_()->_u0931, handler_))->distribution(), handler_), handler_);
  #line 21 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x.get(libbirch::make_slice(birch::type::Integer(5) - 1)), (birch::Gaussian(this_()->x.get(libbirch::make_slice(birch::type::Integer(4) - 1)), this_()->_u0931, handler_))->distribution(), handler_), handler_);
}

#line 24 "src/test/model/TestChainMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestChainMultivariateGaussian::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestChainMultivariateGaussian.birch", 24);
  #line 25 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(15)));
  #line 26 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestChainMultivariateGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(5); ++i) {
    #line 27 "src/test/model/TestChainMultivariateGaussian.birch"
    libbirch_line_(27);
    #line 27 "src/test/model/TestChainMultivariateGaussian.birch"
    libbirch_assert_(!this_()->x.get(libbirch::make_slice(i - 1))->hasValue(handler_));
    #line 28 "src/test/model/TestChainMultivariateGaussian.birch"
    libbirch_line_(28);
    #line 28 "src/test/model/TestChainMultivariateGaussian.birch"
    y.set(libbirch::make_slice(libbirch::make_range((i - birch::type::Integer(1)) * birch::type::Integer(3) + birch::type::Integer(1) - 1, i * birch::type::Integer(3) - 1)), this_()->x.get(libbirch::make_slice(i - 1))->value(handler_));
  }
  #line 30 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestChainMultivariateGaussian.birch"
  return y;
}

#line 33 "src/test/model/TestChainMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestChainMultivariateGaussian::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestChainMultivariateGaussian.birch", 33);
  #line 34 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(15)));
  #line 35 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestChainMultivariateGaussian.birch"
  for (auto i = birch::type::Integer(0); i <= birch::type::Integer(4); ++i) {
    #line 36 "src/test/model/TestChainMultivariateGaussian.birch"
    libbirch_line_(36);
    #line 36 "src/test/model/TestChainMultivariateGaussian.birch"
    libbirch_assert_(!this_()->x.get(libbirch::make_slice(birch::type::Integer(5) - i - 1))->hasValue(handler_));
    #line 37 "src/test/model/TestChainMultivariateGaussian.birch"
    libbirch_line_(37);
    #line 37 "src/test/model/TestChainMultivariateGaussian.birch"
    y.set(libbirch::make_slice(libbirch::make_range((birch::type::Integer(4) - i) * birch::type::Integer(3) + birch::type::Integer(1) - 1, (birch::type::Integer(5) - i) * birch::type::Integer(3) - 1)), this_()->x.get(libbirch::make_slice(birch::type::Integer(5) - i - 1))->value(handler_));
  }
  #line 39 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestChainMultivariateGaussian.birch"
  return y;
}

#line 1 "src/test/model/TestChainMultivariateGaussian.birch"
birch::type::TestChainMultivariateGaussian* birch::type::make_TestChainMultivariateGaussian_() {
  #line 1 "src/test/model/TestChainMultivariateGaussian.birch"
  return new birch::type::TestChainMultivariateGaussian();
  #line 1 "src/test/model/TestChainMultivariateGaussian.birch"
}

#line 1 "src/test/model/TestChainGaussian.birch"
birch::type::TestChainGaussian::TestChainGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestChainGaussian.birch"
    super_type_(),
    #line 2 "src/test/model/TestChainGaussian.birch"
    x(libbirch::make_shape(birch::type::Integer(5))),
    #line 3 "src/test/model/TestChainGaussian.birch"
    _u0956(),
    #line 4 "src/test/model/TestChainGaussian.birch"
    _u09632() {
  //
}

#line 6 "src/test/model/TestChainGaussian.birch"
void birch::type::TestChainGaussian::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 6 "src/test/model/TestChainGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestChainGaussian.birch", 6);
  #line 7 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/model/TestChainGaussian.birch"
  this_()->_u0956 = birch::simulate_uniform(-10.0, 10.0, handler_);
  #line 8 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(8);
  #line 8 "src/test/model/TestChainGaussian.birch"
  this_()->_u09632 = libbirch::make_array({ birch::simulate_uniform(0.0, 10.0, handler_), birch::simulate_uniform(0.0, 10.0, handler_), birch::simulate_uniform(0.0, 10.0, handler_), birch::simulate_uniform(0.0, 10.0, handler_), birch::simulate_uniform(0.0, 10.0, handler_) });
}

#line 17 "src/test/model/TestChainGaussian.birch"
void birch::type::TestChainGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 17 "src/test/model/TestChainGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestChainGaussian.birch", 17);
  #line 18 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestChainGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x.get(libbirch::make_slice(birch::type::Integer(1) - 1)), (birch::Gaussian(this_()->_u0956, this_()->_u09632.get(libbirch::make_slice(birch::type::Integer(1) - 1)), handler_))->distribution(), handler_), handler_);
  #line 19 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestChainGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x.get(libbirch::make_slice(birch::type::Integer(2) - 1)), (birch::Gaussian(this_()->x.get(libbirch::make_slice(birch::type::Integer(1) - 1)), this_()->_u09632.get(libbirch::make_slice(birch::type::Integer(2) - 1)), handler_))->distribution(), handler_), handler_);
  #line 20 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestChainGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x.get(libbirch::make_slice(birch::type::Integer(3) - 1)), (birch::Gaussian(this_()->x.get(libbirch::make_slice(birch::type::Integer(2) - 1)), this_()->_u09632.get(libbirch::make_slice(birch::type::Integer(3) - 1)), handler_))->distribution(), handler_), handler_);
  #line 21 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestChainGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x.get(libbirch::make_slice(birch::type::Integer(4) - 1)), (birch::Gaussian(this_()->x.get(libbirch::make_slice(birch::type::Integer(3) - 1)), this_()->_u09632.get(libbirch::make_slice(birch::type::Integer(4) - 1)), handler_))->distribution(), handler_), handler_);
  #line 22 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestChainGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x.get(libbirch::make_slice(birch::type::Integer(5) - 1)), (birch::Gaussian(this_()->x.get(libbirch::make_slice(birch::type::Integer(4) - 1)), this_()->_u09632.get(libbirch::make_slice(birch::type::Integer(5) - 1)), handler_))->distribution(), handler_), handler_);
}

#line 25 "src/test/model/TestChainGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestChainGaussian::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/test/model/TestChainGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestChainGaussian.birch", 25);
  #line 26 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestChainGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(5)));
  #line 27 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestChainGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(5); ++i) {
    #line 28 "src/test/model/TestChainGaussian.birch"
    libbirch_line_(28);
    #line 28 "src/test/model/TestChainGaussian.birch"
    libbirch_assert_(!this_()->x.get(libbirch::make_slice(i - 1))->hasValue(handler_));
    #line 29 "src/test/model/TestChainGaussian.birch"
    libbirch_line_(29);
    #line 29 "src/test/model/TestChainGaussian.birch"
    y.set(libbirch::make_slice(i - 1), this_()->x.get(libbirch::make_slice(i - 1))->value(handler_));
  }
  #line 31 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestChainGaussian.birch"
  return y;
}

#line 34 "src/test/model/TestChainGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestChainGaussian::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/test/model/TestChainGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestChainGaussian.birch", 34);
  #line 35 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestChainGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(5)));
  #line 36 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestChainGaussian.birch"
  for (auto i = birch::type::Integer(0); i <= birch::type::Integer(4); ++i) {
    #line 37 "src/test/model/TestChainGaussian.birch"
    libbirch_line_(37);
    #line 37 "src/test/model/TestChainGaussian.birch"
    libbirch_assert_(!this_()->x.get(libbirch::make_slice(birch::type::Integer(5) - i - 1))->hasValue(handler_));
    #line 38 "src/test/model/TestChainGaussian.birch"
    libbirch_line_(38);
    #line 38 "src/test/model/TestChainGaussian.birch"
    y.set(libbirch::make_slice(birch::type::Integer(5) - i - 1), this_()->x.get(libbirch::make_slice(birch::type::Integer(5) - i - 1))->value(handler_));
  }
  #line 40 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestChainGaussian.birch"
  return y;
}

#line 1 "src/test/model/TestChainGaussian.birch"
birch::type::TestChainGaussian* birch::type::make_TestChainGaussian_() {
  #line 1 "src/test/model/TestChainGaussian.birch"
  return new birch::type::TestChainGaussian();
  #line 1 "src/test/model/TestChainGaussian.birch"
}

#line 1 "src/test/model/TestNegativeScaledGammaExponential.birch"
birch::type::TestNegativeScaledGammaExponential::TestNegativeScaledGammaExponential(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestNegativeScaledGammaExponential.birch"
    super_type_(),
    #line 2 "src/test/model/TestNegativeScaledGammaExponential.birch"
    _u0955(),
    #line 3 "src/test/model/TestNegativeScaledGammaExponential.birch"
    x(),
    #line 5 "src/test/model/TestNegativeScaledGammaExponential.birch"
    a(),
    #line 6 "src/test/model/TestNegativeScaledGammaExponential.birch"
    k(),
    #line 7 "src/test/model/TestNegativeScaledGammaExponential.birch"
    _u0952() {
  //
}

#line 9 "src/test/model/TestNegativeScaledGammaExponential.birch"
void birch::type::TestNegativeScaledGammaExponential::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch_function_("initialize", "src/test/model/TestNegativeScaledGammaExponential.birch", 9);
  #line 10 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch_line_(10);
  #line 10 "src/test/model/TestNegativeScaledGammaExponential.birch"
  this_()->a = birch::simulate_uniform(1.0, 10.0, handler_);
  #line 11 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch_line_(11);
  #line 11 "src/test/model/TestNegativeScaledGammaExponential.birch"
  this_()->k = birch::simulate_uniform(1.0, 10.0, handler_);
  #line 12 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestNegativeScaledGammaExponential.birch"
  this_()->_u0952 = birch::simulate_uniform(0.0, 10.0, handler_);
}

#line 15 "src/test/model/TestNegativeScaledGammaExponential.birch"
void birch::type::TestNegativeScaledGammaExponential::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch_function_("simulate", "src/test/model/TestNegativeScaledGammaExponential.birch", 15);
  #line 16 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0955, (birch::Gamma(this_()->k, this_()->_u0952, handler_))->distribution(), handler_), handler_);
  #line 17 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Exponential(this_()->_u0955 / this_()->a, handler_))->distribution(), handler_), handler_);
}

#line 20 "src/test/model/TestNegativeScaledGammaExponential.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNegativeScaledGammaExponential::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch_function_("forward", "src/test/model/TestNegativeScaledGammaExponential.birch", 20);
  #line 21 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 22 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestNegativeScaledGammaExponential.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0955->value(handler_));
  #line 23 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 24 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestNegativeScaledGammaExponential.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 25 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestNegativeScaledGammaExponential.birch"
  return y;
}

#line 28 "src/test/model/TestNegativeScaledGammaExponential.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNegativeScaledGammaExponential::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch_function_("backward", "src/test/model/TestNegativeScaledGammaExponential.birch", 28);
  #line 29 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 30 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestNegativeScaledGammaExponential.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 31 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch_assert_(!this_()->_u0955->hasValue(handler_));
  #line 32 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestNegativeScaledGammaExponential.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0955->value(handler_));
  #line 33 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestNegativeScaledGammaExponential.birch"
  return y;
}

#line 36 "src/test/model/TestNegativeScaledGammaExponential.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> birch::type::TestNegativeScaledGammaExponential::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch_function_("marginal", "src/test/model/TestNegativeScaledGammaExponential.birch", 36);
  #line 37 "src/test/model/TestNegativeScaledGammaExponential.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestNegativeScaledGammaExponential.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestNegativeScaledGammaExponential.birch"
birch::type::TestNegativeScaledGammaExponential* birch::type::make_TestNegativeScaledGammaExponential_() {
  #line 1 "src/test/model/TestNegativeScaledGammaExponential.birch"
  return new birch::type::TestNegativeScaledGammaExponential();
  #line 1 "src/test/model/TestNegativeScaledGammaExponential.birch"
}

#line 1 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
birch::type::TestNegativeLinearDiscreteDelta::TestNegativeLinearDiscreteDelta(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
    super_type_(),
    #line 2 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
    _u0961(),
    #line 3 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
    x(),
    #line 4 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
    y(),
    #line 6 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
    a(),
    #line 7 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
    n(),
    #line 8 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
    _u0945(),
    #line 9 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
    _u0946(),
    #line 10 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
    c() {
  //
}

#line 12 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
void birch::type::TestNegativeLinearDiscreteDelta::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 12 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_function_("initialize", "src/test/model/TestNegativeLinearDiscreteDelta.birch", 12);
  #line 13 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  this_()->a = birch::type::Integer(2) * birch::simulate_uniform_int(birch::type::Integer(0), birch::type::Integer(1), handler_) - birch::type::Integer(1);
  #line 14 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  this_()->n = birch::simulate_uniform_int(birch::type::Integer(1), birch::type::Integer(100), handler_);
  #line 15 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  this_()->_u0945 = birch::simulate_uniform(0.0, 10.0, handler_);
  #line 16 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  this_()->_u0946 = birch::simulate_uniform(0.0, 10.0, handler_);
  #line 17 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  this_()->c = birch::simulate_uniform_int(birch::type::Integer(0), birch::type::Integer(100), handler_);
}

#line 20 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
void birch::type::TestNegativeLinearDiscreteDelta::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_function_("simulate", "src/test/model/TestNegativeLinearDiscreteDelta.birch", 20);
  #line 21 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0961, (birch::Beta(this_()->_u0945, this_()->_u0946, handler_))->distribution(), handler_), handler_);
  #line 22 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Binomial(this_()->n, this_()->_u0961, handler_))->distribution(), handler_), handler_);
  #line 23 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch::assume(birch::AssumeEvent(this_()->y, (birch::Delta(this_()->a * this_()->x - this_()->c, handler_))->distribution(), handler_), handler_);
}

#line 26 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNegativeLinearDiscreteDelta::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_function_("forward", "src/test/model/TestNegativeLinearDiscreteDelta.birch", 26);
  #line 27 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch::DefaultArray<birch::type::Real,1> z(libbirch::make_shape(birch::type::Integer(2)));
  #line 28 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_assert_(!this_()->_u0961->hasValue(handler_));
  #line 29 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  z.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0961->value(handler_));
  #line 30 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 31 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  z.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 32 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  return z;
}

#line 35 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNegativeLinearDiscreteDelta::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_function_("backward", "src/test/model/TestNegativeLinearDiscreteDelta.birch", 35);
  #line 36 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch::DefaultArray<birch::type::Real,1> z(libbirch::make_shape(birch::type::Integer(2)));
  #line 37 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 38 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  z.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 39 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_assert_(!this_()->_u0961->hasValue(handler_));
  #line 40 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  z.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0961->value(handler_));
  #line 41 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  return z;
}

#line 44 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> birch::type::TestNegativeLinearDiscreteDelta::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_function_("marginal", "src/test/model/TestNegativeLinearDiscreteDelta.birch", 44);
  #line 45 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  return this_()->y->distribution(handler_).get();
}

#line 1 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
birch::type::TestNegativeLinearDiscreteDelta* birch::type::make_TestNegativeLinearDiscreteDelta_() {
  #line 1 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
  return new birch::type::TestNegativeLinearDiscreteDelta();
  #line 1 "src/test/model/TestNegativeLinearDiscreteDelta.birch"
}

#line 1 "src/test/model/TestGaussianGaussian.birch"
birch::type::TestGaussianGaussian::TestGaussianGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestGaussianGaussian.birch"
    super_type_(),
    #line 2 "src/test/model/TestGaussianGaussian.birch"
    _u0956_1(),
    #line 3 "src/test/model/TestGaussianGaussian.birch"
    x(),
    #line 4 "src/test/model/TestGaussianGaussian.birch"
    _u0956_0(),
    #line 5 "src/test/model/TestGaussianGaussian.birch"
    _u09632_0(),
    #line 6 "src/test/model/TestGaussianGaussian.birch"
    _u09632_1() {
  //
}

#line 8 "src/test/model/TestGaussianGaussian.birch"
void birch::type::TestGaussianGaussian::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 8 "src/test/model/TestGaussianGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestGaussianGaussian.birch", 8);
  #line 9 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(9);
  #line 9 "src/test/model/TestGaussianGaussian.birch"
  this_()->_u0956_0 = birch::simulate_uniform(-10.0, 10.0, handler_);
  #line 10 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(10);
  #line 10 "src/test/model/TestGaussianGaussian.birch"
  this_()->_u09632_0 = birch::simulate_uniform(0.0, 10.0, handler_);
  #line 11 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(11);
  #line 11 "src/test/model/TestGaussianGaussian.birch"
  this_()->_u09632_1 = birch::simulate_uniform(0.0, 10.0, handler_);
}

#line 14 "src/test/model/TestGaussianGaussian.birch"
void birch::type::TestGaussianGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/test/model/TestGaussianGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestGaussianGaussian.birch", 14);
  #line 15 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestGaussianGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0956_1, (birch::Gaussian(this_()->_u0956_0, this_()->_u09632_0, handler_))->distribution(), handler_), handler_);
  #line 16 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestGaussianGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Gaussian(this_()->_u0956_1, this_()->_u09632_1, handler_))->distribution(), handler_), handler_);
}

#line 19 "src/test/model/TestGaussianGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestGaussianGaussian::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/test/model/TestGaussianGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestGaussianGaussian.birch", 19);
  #line 20 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestGaussianGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 21 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestGaussianGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0956_1->value(handler_));
  #line 22 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestGaussianGaussian.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 23 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestGaussianGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 24 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestGaussianGaussian.birch"
  return y;
}

#line 27 "src/test/model/TestGaussianGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestGaussianGaussian::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/test/model/TestGaussianGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestGaussianGaussian.birch", 27);
  #line 28 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestGaussianGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 29 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestGaussianGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 30 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestGaussianGaussian.birch"
  libbirch_assert_(!this_()->_u0956_1->hasValue(handler_));
  #line 31 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestGaussianGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0956_1->value(handler_));
  #line 32 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestGaussianGaussian.birch"
  return y;
}

#line 1 "src/test/model/TestGaussianGaussian.birch"
birch::type::TestGaussianGaussian* birch::type::make_TestGaussianGaussian_() {
  #line 1 "src/test/model/TestGaussianGaussian.birch"
  return new birch::type::TestGaussianGaussian();
  #line 1 "src/test/model/TestGaussianGaussian.birch"
}

#line 1 "src/test/model/TestBetaNegativeBinomial.birch"
birch::type::TestBetaNegativeBinomial::TestBetaNegativeBinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestBetaNegativeBinomial.birch"
    super_type_(),
    #line 2 "src/test/model/TestBetaNegativeBinomial.birch"
    k(),
    #line 3 "src/test/model/TestBetaNegativeBinomial.birch"
    _u0945(),
    #line 4 "src/test/model/TestBetaNegativeBinomial.birch"
    _u0946(),
    #line 5 "src/test/model/TestBetaNegativeBinomial.birch"
    _u0961(),
    #line 6 "src/test/model/TestBetaNegativeBinomial.birch"
    x() {
  //
}

#line 8 "src/test/model/TestBetaNegativeBinomial.birch"
void birch::type::TestBetaNegativeBinomial::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 8 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_function_("initialize", "src/test/model/TestBetaNegativeBinomial.birch", 8);
  #line 9 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(9);
  #line 9 "src/test/model/TestBetaNegativeBinomial.birch"
  this_()->k = birch::simulate_uniform_int(birch::type::Integer(1), birch::type::Integer(100), handler_);
  #line 10 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(10);
  #line 10 "src/test/model/TestBetaNegativeBinomial.birch"
  this_()->_u0945 = birch::simulate_uniform(1.0, 100.0, handler_);
  #line 11 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(11);
  #line 11 "src/test/model/TestBetaNegativeBinomial.birch"
  this_()->_u0946 = birch::simulate_uniform(1.0, 100.0, handler_);
}

#line 14 "src/test/model/TestBetaNegativeBinomial.birch"
void birch::type::TestBetaNegativeBinomial::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_function_("simulate", "src/test/model/TestBetaNegativeBinomial.birch", 14);
  #line 15 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0961, (birch::Beta(this_()->_u0945, this_()->_u0946, handler_))->distribution(), handler_), handler_);
  #line 16 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::NegativeBinomial(this_()->k, this_()->_u0961, handler_))->distribution(), handler_), handler_);
}

#line 19 "src/test/model/TestBetaNegativeBinomial.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestBetaNegativeBinomial::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_function_("forward", "src/test/model/TestBetaNegativeBinomial.birch", 19);
  #line 20 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 21 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestBetaNegativeBinomial.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0961->value(handler_));
  #line 22 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 23 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestBetaNegativeBinomial.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 24 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestBetaNegativeBinomial.birch"
  return y;
}

#line 27 "src/test/model/TestBetaNegativeBinomial.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestBetaNegativeBinomial::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_function_("backward", "src/test/model/TestBetaNegativeBinomial.birch", 27);
  #line 28 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 29 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestBetaNegativeBinomial.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 30 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_assert_(!this_()->_u0961->hasValue(handler_));
  #line 31 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestBetaNegativeBinomial.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0961->value(handler_));
  #line 32 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestBetaNegativeBinomial.birch"
  return y;
}

#line 35 "src/test/model/TestBetaNegativeBinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> birch::type::TestBetaNegativeBinomial::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_function_("marginal", "src/test/model/TestBetaNegativeBinomial.birch", 35);
  #line 36 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestBetaNegativeBinomial.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestBetaNegativeBinomial.birch"
birch::type::TestBetaNegativeBinomial* birch::type::make_TestBetaNegativeBinomial_() {
  #line 1 "src/test/model/TestBetaNegativeBinomial.birch"
  return new birch::type::TestBetaNegativeBinomial();
  #line 1 "src/test/model/TestBetaNegativeBinomial.birch"
}

#line 1 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
birch::type::TestLinearMultivariateGaussianMultivariateGaussian::TestLinearMultivariateGaussianMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    super_type_(),
    #line 2 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    _u0956(),
    #line 3 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    x(),
    #line 5 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    A(libbirch::make_shape(birch::type::Integer(5), birch::type::Integer(5))),
    #line 6 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    _u0956_0(libbirch::make_shape(birch::type::Integer(5))),
    #line 7 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    _u0931_0(libbirch::make_shape(birch::type::Integer(5), birch::type::Integer(5))),
    #line 8 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    c(libbirch::make_shape(birch::type::Integer(5))),
    #line 9 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    _u0931_1(libbirch::make_shape(birch::type::Integer(5), birch::type::Integer(5))) {
  //
}

#line 11 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
void birch::type::TestLinearMultivariateGaussianMultivariateGaussian::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch", 11);
  #line 12 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(5); ++i) {
    #line 13 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    libbirch_line_(13);
    #line 13 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    this_()->_u0956_0.set(libbirch::make_slice(i - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    #line 14 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    libbirch_line_(14);
    #line 14 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    this_()->c.set(libbirch::make_slice(i - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    #line 15 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    libbirch_line_(15);
    #line 15 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= birch::type::Integer(5); ++j) {
      #line 16 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
      libbirch_line_(16);
      #line 16 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
      this_()->_u0931_0.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
      #line 17 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
      libbirch_line_(17);
      #line 17 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
      this_()->_u0931_1.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
      #line 18 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
      libbirch_line_(18);
      #line 18 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
      this_()->A.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
    }
  }
  #line 21 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  this_()->_u0931_0 = this_()->_u0931_0 * birch::transpose(this_()->_u0931_0, handler_);
  #line 22 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  this_()->_u0931_1 = this_()->_u0931_1 * birch::transpose(this_()->_u0931_1, handler_);
}

#line 25 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
void birch::type::TestLinearMultivariateGaussianMultivariateGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch", 25);
  #line 26 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0956, (birch::Gaussian(this_()->_u0956_0, this_()->_u0931_0, handler_))->distribution(), handler_), handler_);
  #line 27 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Gaussian(this_()->A * this_()->_u0956 + this_()->c, this_()->_u0931_1, handler_))->distribution(), handler_), handler_);
}

#line 30 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMultivariateGaussianMultivariateGaussian::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch", 30);
  #line 31 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(10)));
  #line 32 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, birch::type::Integer(5) - 1)), this_()->_u0956->value(handler_));
  #line 33 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 34 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(6) - 1, birch::type::Integer(10) - 1)), this_()->x->value(handler_));
  #line 35 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  return y;
}

#line 38 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMultivariateGaussianMultivariateGaussian::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch", 38);
  #line 39 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(10)));
  #line 40 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(6) - 1, birch::type::Integer(10) - 1)), this_()->x->value(handler_));
  #line 41 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_assert_(!this_()->_u0956->hasValue(handler_));
  #line 42 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, birch::type::Integer(5) - 1)), this_()->_u0956->value(handler_));
  #line 43 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  return y;
}

#line 46 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>> birch::type::TestLinearMultivariateGaussianMultivariateGaussian::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch", 46);
  #line 47 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
birch::type::TestLinearMultivariateGaussianMultivariateGaussian* birch::type::make_TestLinearMultivariateGaussianMultivariateGaussian_() {
  #line 1 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  return new birch::type::TestLinearMultivariateGaussianMultivariateGaussian();
  #line 1 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
}

#line 1 "src/test/model/TestScaledGammaPoisson.birch"
birch::type::TestScaledGammaPoisson::TestScaledGammaPoisson(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestScaledGammaPoisson.birch"
    super_type_(),
    #line 2 "src/test/model/TestScaledGammaPoisson.birch"
    _u0955(),
    #line 3 "src/test/model/TestScaledGammaPoisson.birch"
    x(),
    #line 5 "src/test/model/TestScaledGammaPoisson.birch"
    a(),
    #line 6 "src/test/model/TestScaledGammaPoisson.birch"
    k(),
    #line 7 "src/test/model/TestScaledGammaPoisson.birch"
    _u0952() {
  //
}

#line 9 "src/test/model/TestScaledGammaPoisson.birch"
void birch::type::TestScaledGammaPoisson::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_function_("initialize", "src/test/model/TestScaledGammaPoisson.birch", 9);
  #line 10 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(10);
  #line 10 "src/test/model/TestScaledGammaPoisson.birch"
  this_()->a = birch::simulate_uniform(0.0, 10.0, handler_);
  #line 11 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(11);
  #line 11 "src/test/model/TestScaledGammaPoisson.birch"
  this_()->k = birch::simulate_uniform_int(birch::type::Integer(1), birch::type::Integer(10), handler_);
  #line 12 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestScaledGammaPoisson.birch"
  this_()->_u0952 = birch::simulate_uniform(0.0, 10.0, handler_);
}

#line 15 "src/test/model/TestScaledGammaPoisson.birch"
void birch::type::TestScaledGammaPoisson::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_function_("simulate", "src/test/model/TestScaledGammaPoisson.birch", 15);
  #line 16 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0955, (birch::Gamma(this_()->k, this_()->_u0952, handler_))->distribution(), handler_), handler_);
  #line 17 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Poisson(this_()->a * this_()->_u0955, handler_))->distribution(), handler_), handler_);
}

#line 20 "src/test/model/TestScaledGammaPoisson.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestScaledGammaPoisson::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_function_("forward", "src/test/model/TestScaledGammaPoisson.birch", 20);
  #line 21 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 22 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestScaledGammaPoisson.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0955->value(handler_));
  #line 23 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 24 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestScaledGammaPoisson.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 25 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestScaledGammaPoisson.birch"
  return y;
}

#line 28 "src/test/model/TestScaledGammaPoisson.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestScaledGammaPoisson::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_function_("backward", "src/test/model/TestScaledGammaPoisson.birch", 28);
  #line 29 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 30 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestScaledGammaPoisson.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 31 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_assert_(!this_()->_u0955->hasValue(handler_));
  #line 32 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestScaledGammaPoisson.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0955->value(handler_));
  #line 33 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestScaledGammaPoisson.birch"
  return y;
}

#line 36 "src/test/model/TestScaledGammaPoisson.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> birch::type::TestScaledGammaPoisson::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_function_("marginal", "src/test/model/TestScaledGammaPoisson.birch", 36);
  #line 37 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestScaledGammaPoisson.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestScaledGammaPoisson.birch"
birch::type::TestScaledGammaPoisson* birch::type::make_TestScaledGammaPoisson_() {
  #line 1 "src/test/model/TestScaledGammaPoisson.birch"
  return new birch::type::TestScaledGammaPoisson();
  #line 1 "src/test/model/TestScaledGammaPoisson.birch"
}

#line 1 "src/test/model/TestScaledGammaExponential.birch"
birch::type::TestScaledGammaExponential::TestScaledGammaExponential(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestScaledGammaExponential.birch"
    super_type_(),
    #line 2 "src/test/model/TestScaledGammaExponential.birch"
    _u0955(),
    #line 3 "src/test/model/TestScaledGammaExponential.birch"
    x(),
    #line 5 "src/test/model/TestScaledGammaExponential.birch"
    a(),
    #line 6 "src/test/model/TestScaledGammaExponential.birch"
    k(),
    #line 7 "src/test/model/TestScaledGammaExponential.birch"
    _u0952() {
  //
}

#line 9 "src/test/model/TestScaledGammaExponential.birch"
void birch::type::TestScaledGammaExponential::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_function_("initialize", "src/test/model/TestScaledGammaExponential.birch", 9);
  #line 10 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(10);
  #line 10 "src/test/model/TestScaledGammaExponential.birch"
  this_()->a = birch::simulate_uniform(0.0, 10.0, handler_);
  #line 11 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(11);
  #line 11 "src/test/model/TestScaledGammaExponential.birch"
  this_()->k = birch::simulate_uniform(1.0, 10.0, handler_);
  #line 12 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestScaledGammaExponential.birch"
  this_()->_u0952 = birch::simulate_uniform(0.0, 10.0, handler_);
}

#line 15 "src/test/model/TestScaledGammaExponential.birch"
void birch::type::TestScaledGammaExponential::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_function_("simulate", "src/test/model/TestScaledGammaExponential.birch", 15);
  #line 16 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestScaledGammaExponential.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0955, (birch::Gamma(this_()->k, this_()->_u0952, handler_))->distribution(), handler_), handler_);
  #line 17 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestScaledGammaExponential.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Exponential(this_()->a * this_()->_u0955, handler_))->distribution(), handler_), handler_);
}

#line 20 "src/test/model/TestScaledGammaExponential.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestScaledGammaExponential::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_function_("forward", "src/test/model/TestScaledGammaExponential.birch", 20);
  #line 21 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestScaledGammaExponential.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 22 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestScaledGammaExponential.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0955->value(handler_));
  #line 23 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 24 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestScaledGammaExponential.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 25 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestScaledGammaExponential.birch"
  return y;
}

#line 28 "src/test/model/TestScaledGammaExponential.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestScaledGammaExponential::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_function_("backward", "src/test/model/TestScaledGammaExponential.birch", 28);
  #line 29 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestScaledGammaExponential.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 30 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestScaledGammaExponential.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 31 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_assert_(!this_()->_u0955->hasValue(handler_));
  #line 32 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestScaledGammaExponential.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0955->value(handler_));
  #line 33 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestScaledGammaExponential.birch"
  return y;
}

#line 36 "src/test/model/TestScaledGammaExponential.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> birch::type::TestScaledGammaExponential::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_function_("marginal", "src/test/model/TestScaledGammaExponential.birch", 36);
  #line 37 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestScaledGammaExponential.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestScaledGammaExponential.birch"
birch::type::TestScaledGammaExponential* birch::type::make_TestScaledGammaExponential_() {
  #line 1 "src/test/model/TestScaledGammaExponential.birch"
  return new birch::type::TestScaledGammaExponential();
  #line 1 "src/test/model/TestScaledGammaExponential.birch"
}

#line 1 "src/test/model/TestBetaGeometric.birch"
birch::type::TestBetaGeometric::TestBetaGeometric(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestBetaGeometric.birch"
    super_type_(),
    #line 2 "src/test/model/TestBetaGeometric.birch"
    _u0961(),
    #line 3 "src/test/model/TestBetaGeometric.birch"
    x(),
    #line 4 "src/test/model/TestBetaGeometric.birch"
    _u0945(),
    #line 5 "src/test/model/TestBetaGeometric.birch"
    _u0946() {
  //
}

#line 7 "src/test/model/TestBetaGeometric.birch"
void birch::type::TestBetaGeometric::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/test/model/TestBetaGeometric.birch"
  libbirch_function_("initialize", "src/test/model/TestBetaGeometric.birch", 7);
  #line 8 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(8);
  #line 8 "src/test/model/TestBetaGeometric.birch"
  this_()->_u0945 = birch::simulate_uniform(1.0, 100.0, handler_);
  #line 9 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(9);
  #line 9 "src/test/model/TestBetaGeometric.birch"
  this_()->_u0946 = birch::simulate_uniform(1.0, 100.0, handler_);
}

#line 12 "src/test/model/TestBetaGeometric.birch"
void birch::type::TestBetaGeometric::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 12 "src/test/model/TestBetaGeometric.birch"
  libbirch_function_("simulate", "src/test/model/TestBetaGeometric.birch", 12);
  #line 13 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestBetaGeometric.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0961, (birch::Beta(this_()->_u0945, this_()->_u0946, handler_))->distribution(), handler_), handler_);
  #line 14 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestBetaGeometric.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Geometric(this_()->_u0961, handler_))->distribution(), handler_), handler_);
}

#line 17 "src/test/model/TestBetaGeometric.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestBetaGeometric::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 17 "src/test/model/TestBetaGeometric.birch"
  libbirch_function_("forward", "src/test/model/TestBetaGeometric.birch", 17);
  #line 18 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestBetaGeometric.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 19 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestBetaGeometric.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0961->value(handler_));
  #line 20 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestBetaGeometric.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 21 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestBetaGeometric.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 22 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestBetaGeometric.birch"
  return y;
}

#line 25 "src/test/model/TestBetaGeometric.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestBetaGeometric::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/test/model/TestBetaGeometric.birch"
  libbirch_function_("backward", "src/test/model/TestBetaGeometric.birch", 25);
  #line 26 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestBetaGeometric.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 27 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestBetaGeometric.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 28 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestBetaGeometric.birch"
  libbirch_assert_(!this_()->_u0961->hasValue(handler_));
  #line 29 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestBetaGeometric.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0961->value(handler_));
  #line 30 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestBetaGeometric.birch"
  return y;
}

#line 1 "src/test/model/TestBetaGeometric.birch"
birch::type::TestBetaGeometric* birch::type::make_TestBetaGeometric_() {
  #line 1 "src/test/model/TestBetaGeometric.birch"
  return new birch::type::TestBetaGeometric();
  #line 1 "src/test/model/TestBetaGeometric.birch"
}

#line 1 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
birch::type::TestLinearNormalInverseGammaGaussian::TestLinearNormalInverseGammaGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    super_type_(),
    #line 2 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    _u09632(),
    #line 3 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    _u0956(),
    #line 4 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    x(),
    #line 6 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    a(),
    #line 7 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    _u0956_0(),
    #line 8 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    a2(),
    #line 9 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    c(),
    #line 10 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    _u0945(),
    #line 11 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    _u0946() {
  //
}

#line 13 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
void birch::type::TestLinearNormalInverseGammaGaussian::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 13 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestLinearNormalInverseGammaGaussian.birch", 13);
  #line 14 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  this_()->a = birch::simulate_uniform(-2.0, 2.0, handler_);
  #line 15 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  this_()->_u0956_0 = birch::simulate_uniform(-10.0, 10.0, handler_);
  #line 16 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  this_()->a2 = birch::simulate_uniform(0.1, 2.0, handler_);
  #line 17 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  this_()->c = birch::simulate_uniform(-10.0, 10.0, handler_);
  #line 18 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  this_()->_u0945 = birch::simulate_uniform(2.0, 10.0, handler_);
  #line 19 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  this_()->_u0946 = birch::simulate_uniform(0.1, 10.0, handler_);
}

#line 22 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
void birch::type::TestLinearNormalInverseGammaGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestLinearNormalInverseGammaGaussian.birch", 22);
  #line 23 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u09632, (birch::InverseGamma(this_()->_u0945, this_()->_u0946, handler_))->distribution(), handler_), handler_);
  #line 24 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0956, (birch::Gaussian(this_()->_u0956_0, this_()->a2, this_()->_u09632, handler_))->distribution(), handler_), handler_);
  #line 25 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Gaussian(this_()->a * this_()->_u0956 + this_()->c, this_()->_u09632, handler_))->distribution(), handler_), handler_);
}

#line 28 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearNormalInverseGammaGaussian::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestLinearNormalInverseGammaGaussian.birch", 28);
  #line 29 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(3)));
  #line 30 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_assert_(!this_()->_u09632->hasValue(handler_));
  #line 31 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u09632->value(handler_));
  #line 32 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_assert_(!this_()->_u0956->hasValue(handler_));
  #line 33 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->_u0956->value(handler_));
  #line 34 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 35 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(3) - 1), this_()->x->value(handler_));
  #line 36 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  return y;
}

#line 39 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearNormalInverseGammaGaussian::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestLinearNormalInverseGammaGaussian.birch", 39);
  #line 40 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(3)));
  #line 41 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 42 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(3) - 1), this_()->x->value(handler_));
  #line 43 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_assert_(!this_()->_u0956->hasValue(handler_));
  #line 44 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->_u0956->value(handler_));
  #line 45 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_assert_(!this_()->_u09632->hasValue(handler_));
  #line 46 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u09632->value(handler_));
  #line 47 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  return y;
}

#line 50 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> birch::type::TestLinearNormalInverseGammaGaussian::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestLinearNormalInverseGammaGaussian.birch", 50);
  #line 51 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
birch::type::TestLinearNormalInverseGammaGaussian* birch::type::make_TestLinearNormalInverseGammaGaussian_() {
  #line 1 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  return new birch::type::TestLinearNormalInverseGammaGaussian();
  #line 1 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
}

#line 1 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
birch::type::TestLinearMultivariateGaussianGaussian::TestLinearMultivariateGaussianGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    super_type_(),
    #line 2 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    _u0956(),
    #line 3 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    x(),
    #line 5 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    a(libbirch::make_shape(birch::type::Integer(5))),
    #line 6 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    _u0956_0(libbirch::make_shape(birch::type::Integer(5))),
    #line 7 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    _u0931_0(libbirch::make_shape(birch::type::Integer(5), birch::type::Integer(5))),
    #line 8 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    c(),
    #line 9 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    _u09632_1() {
  //
}

#line 11 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
void birch::type::TestLinearMultivariateGaussianGaussian::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestLinearMultivariateGaussianGaussian.birch", 11);
  #line 12 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  this_()->c = birch::simulate_uniform(-10.0, 10.0, handler_);
  #line 13 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(5); ++i) {
    #line 14 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    libbirch_line_(14);
    #line 14 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    this_()->a.set(libbirch::make_slice(i - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
    #line 15 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    libbirch_line_(15);
    #line 15 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    this_()->_u0956_0.set(libbirch::make_slice(i - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    #line 16 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    libbirch_line_(16);
    #line 16 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= birch::type::Integer(5); ++j) {
      #line 17 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
      libbirch_line_(17);
      #line 17 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
      this_()->_u0931_0.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
    }
  }
  #line 20 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  this_()->_u0931_0 = this_()->_u0931_0 * birch::transpose(this_()->_u0931_0, handler_);
  #line 21 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  this_()->_u09632_1 = birch::pow(birch::simulate_uniform(-2.0, 2.0, handler_), 2.0, handler_);
}

#line 24 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
void birch::type::TestLinearMultivariateGaussianGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestLinearMultivariateGaussianGaussian.birch", 24);
  #line 25 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0956, (birch::Gaussian(this_()->_u0956_0, this_()->_u0931_0, handler_))->distribution(), handler_), handler_);
  #line 26 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Gaussian(birch::dot(this_()->a, this_()->_u0956, handler_) + this_()->c, this_()->_u09632_1, handler_))->distribution(), handler_), handler_);
}

#line 29 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMultivariateGaussianGaussian::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestLinearMultivariateGaussianGaussian.birch", 29);
  #line 30 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(6)));
  #line 31 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, birch::type::Integer(5) - 1)), this_()->_u0956->value(handler_));
  #line 32 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 33 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(6) - 1), this_()->x->value(handler_));
  #line 34 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  return y;
}

#line 37 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMultivariateGaussianGaussian::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestLinearMultivariateGaussianGaussian.birch", 37);
  #line 38 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(6)));
  #line 39 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(6) - 1), this_()->x->value(handler_));
  #line 40 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_assert_(!this_()->_u0956->hasValue(handler_));
  #line 41 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, birch::type::Integer(5) - 1)), this_()->_u0956->value(handler_));
  #line 42 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  return y;
}

#line 45 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> birch::type::TestLinearMultivariateGaussianGaussian::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestLinearMultivariateGaussianGaussian.birch", 45);
  #line 46 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
birch::type::TestLinearMultivariateGaussianGaussian* birch::type::make_TestLinearMultivariateGaussianGaussian_() {
  #line 1 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  return new birch::type::TestLinearMultivariateGaussianGaussian();
  #line 1 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
}

#line 1 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
birch::type::TestNegativeLinearMultivariateGaussianMultivariateGaussian::TestNegativeLinearMultivariateGaussianMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
    super_type_(),
    #line 2 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
    _u0956(),
    #line 3 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
    x(),
    #line 5 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
    A(libbirch::make_shape(birch::type::Integer(5), birch::type::Integer(5))),
    #line 6 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
    _u0956_0(libbirch::make_shape(birch::type::Integer(5))),
    #line 7 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
    _u0931_0(libbirch::make_shape(birch::type::Integer(5), birch::type::Integer(5))),
    #line 8 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
    c(libbirch::make_shape(birch::type::Integer(5))),
    #line 9 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
    _u0931_1(libbirch::make_shape(birch::type::Integer(5), birch::type::Integer(5))) {
  //
}

#line 11 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
void birch::type::TestNegativeLinearMultivariateGaussianMultivariateGaussian::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch", 11);
  #line 12 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(5); ++i) {
    #line 13 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
    libbirch_line_(13);
    #line 13 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
    this_()->_u0956_0.set(libbirch::make_slice(i - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    #line 14 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
    libbirch_line_(14);
    #line 14 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
    this_()->c.set(libbirch::make_slice(i - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    #line 15 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
    libbirch_line_(15);
    #line 15 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= birch::type::Integer(5); ++j) {
      #line 16 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
      libbirch_line_(16);
      #line 16 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
      this_()->_u0931_0.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
      #line 17 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
      libbirch_line_(17);
      #line 17 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
      this_()->_u0931_1.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
      #line 18 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
      libbirch_line_(18);
      #line 18 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
      this_()->A.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
    }
  }
  #line 21 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  this_()->_u0931_0 = this_()->_u0931_0 * birch::transpose(this_()->_u0931_0, handler_);
  #line 22 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  this_()->_u0931_1 = this_()->_u0931_1 * birch::transpose(this_()->_u0931_1, handler_);
}

#line 25 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
void birch::type::TestNegativeLinearMultivariateGaussianMultivariateGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch", 25);
  #line 26 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0956, (birch::Gaussian(this_()->_u0956_0, this_()->_u0931_0, handler_))->distribution(), handler_), handler_);
  #line 27 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Gaussian(this_()->A * this_()->_u0956 - this_()->c, this_()->_u0931_1, handler_))->distribution(), handler_), handler_);
}

#line 30 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNegativeLinearMultivariateGaussianMultivariateGaussian::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch", 30);
  #line 31 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(10)));
  #line 32 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, birch::type::Integer(5) - 1)), this_()->_u0956->value(handler_));
  #line 33 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 34 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(6) - 1, birch::type::Integer(10) - 1)), this_()->x->value(handler_));
  #line 35 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  return y;
}

#line 38 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNegativeLinearMultivariateGaussianMultivariateGaussian::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch", 38);
  #line 39 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(10)));
  #line 40 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(6) - 1, birch::type::Integer(10) - 1)), this_()->x->value(handler_));
  #line 41 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_assert_(!this_()->_u0956->hasValue(handler_));
  #line 42 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, birch::type::Integer(5) - 1)), this_()->_u0956->value(handler_));
  #line 43 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  return y;
}

#line 46 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>> birch::type::TestNegativeLinearMultivariateGaussianMultivariateGaussian::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch", 46);
  #line 47 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
birch::type::TestNegativeLinearMultivariateGaussianMultivariateGaussian* birch::type::make_TestNegativeLinearMultivariateGaussianMultivariateGaussian_() {
  #line 1 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
  return new birch::type::TestNegativeLinearMultivariateGaussianMultivariateGaussian();
  #line 1 "src/test/model/TestNegativeLinearMultivariateGaussianMultivariateGaussian.birch"
}

#line 1 "src/test/model/TestNegativeScaledGammaPoisson.birch"
birch::type::TestNegativeScaledGammaPoisson::TestNegativeScaledGammaPoisson(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestNegativeScaledGammaPoisson.birch"
    super_type_(),
    #line 2 "src/test/model/TestNegativeScaledGammaPoisson.birch"
    _u0955(),
    #line 3 "src/test/model/TestNegativeScaledGammaPoisson.birch"
    x(),
    #line 5 "src/test/model/TestNegativeScaledGammaPoisson.birch"
    a(),
    #line 6 "src/test/model/TestNegativeScaledGammaPoisson.birch"
    k(),
    #line 7 "src/test/model/TestNegativeScaledGammaPoisson.birch"
    _u0952() {
  //
}

#line 9 "src/test/model/TestNegativeScaledGammaPoisson.birch"
void birch::type::TestNegativeScaledGammaPoisson::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch_function_("initialize", "src/test/model/TestNegativeScaledGammaPoisson.birch", 9);
  #line 10 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch_line_(10);
  #line 10 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  this_()->a = birch::simulate_uniform(1.0, 10.0, handler_);
  #line 11 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch_line_(11);
  #line 11 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  this_()->k = birch::simulate_uniform_int(birch::type::Integer(1), birch::type::Integer(10), handler_);
  #line 12 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  this_()->_u0952 = birch::simulate_uniform(0.0, 10.0, handler_);
}

#line 15 "src/test/model/TestNegativeScaledGammaPoisson.birch"
void birch::type::TestNegativeScaledGammaPoisson::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch_function_("simulate", "src/test/model/TestNegativeScaledGammaPoisson.birch", 15);
  #line 16 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0955, (birch::Gamma(this_()->k, this_()->_u0952, handler_))->distribution(), handler_), handler_);
  #line 17 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Poisson(this_()->_u0955 / this_()->a, handler_))->distribution(), handler_), handler_);
}

#line 20 "src/test/model/TestNegativeScaledGammaPoisson.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNegativeScaledGammaPoisson::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch_function_("forward", "src/test/model/TestNegativeScaledGammaPoisson.birch", 20);
  #line 21 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 22 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0955->value(handler_));
  #line 23 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 24 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 25 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  return y;
}

#line 28 "src/test/model/TestNegativeScaledGammaPoisson.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNegativeScaledGammaPoisson::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch_function_("backward", "src/test/model/TestNegativeScaledGammaPoisson.birch", 28);
  #line 29 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 30 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 31 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch_assert_(!this_()->_u0955->hasValue(handler_));
  #line 32 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0955->value(handler_));
  #line 33 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  return y;
}

#line 36 "src/test/model/TestNegativeScaledGammaPoisson.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> birch::type::TestNegativeScaledGammaPoisson::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch_function_("marginal", "src/test/model/TestNegativeScaledGammaPoisson.birch", 36);
  #line 37 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestNegativeScaledGammaPoisson.birch"
birch::type::TestNegativeScaledGammaPoisson* birch::type::make_TestNegativeScaledGammaPoisson_() {
  #line 1 "src/test/model/TestNegativeScaledGammaPoisson.birch"
  return new birch::type::TestNegativeScaledGammaPoisson();
  #line 1 "src/test/model/TestNegativeScaledGammaPoisson.birch"
}

#line 1 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
birch::type::TestLinearMultivariateNormalInverseGammaGaussian::TestLinearMultivariateNormalInverseGammaGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    super_type_(),
    #line 2 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    _u09632(),
    #line 3 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    _u0956(),
    #line 4 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    x(),
    #line 6 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    a(libbirch::make_shape(birch::type::Integer(10))),
    #line 7 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    _u0956_0(libbirch::make_shape(birch::type::Integer(10))),
    #line 8 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    _u0931(libbirch::make_shape(birch::type::Integer(10), birch::type::Integer(10))),
    #line 9 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    c(),
    #line 10 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    _u0945(),
    #line 11 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    _u0946() {
  //
}

#line 13 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
void birch::type::TestLinearMultivariateNormalInverseGammaGaussian::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 13 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch", 13);
  #line 14 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  this_()->_u0945 = birch::simulate_uniform(2.0, 10.0, handler_);
  #line 15 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  this_()->_u0946 = birch::simulate_uniform(0.0, 10.0, handler_);
  #line 16 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(10); ++i) {
    #line 17 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    libbirch_line_(17);
    #line 17 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    this_()->a.set(libbirch::make_slice(i - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
    #line 18 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    libbirch_line_(18);
    #line 18 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    this_()->_u0956_0.set(libbirch::make_slice(i - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    #line 19 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    libbirch_line_(19);
    #line 19 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= birch::type::Integer(10); ++j) {
      #line 20 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
      libbirch_line_(20);
      #line 20 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
      this_()->_u0931.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
    }
  }
  #line 23 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  this_()->c = birch::simulate_uniform(-10.0, 10.0, handler_);
  #line 24 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  this_()->_u0931 = this_()->_u0931 * birch::transpose(this_()->_u0931, handler_);
}

#line 27 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
void birch::type::TestLinearMultivariateNormalInverseGammaGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch", 27);
  #line 28 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u09632, (birch::InverseGamma(this_()->_u0945, this_()->_u0946, handler_))->distribution(), handler_), handler_);
  #line 29 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0956, (birch::Gaussian(this_()->_u0956_0, this_()->_u0931, this_()->_u09632, handler_))->distribution(), handler_), handler_);
  #line 30 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Gaussian(birch::dot(this_()->a, this_()->_u0956, handler_) + this_()->c, this_()->_u09632, handler_))->distribution(), handler_), handler_);
}

#line 33 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMultivariateNormalInverseGammaGaussian::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch", 33);
  #line 34 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(12)));
  #line 35 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u09632->value(handler_));
  #line 36 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_assert_(!this_()->_u0956->hasValue(handler_));
  #line 37 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(2) - 1, birch::type::Integer(11) - 1)), this_()->_u0956->value(handler_));
  #line 38 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 39 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(12) - 1), this_()->x->value(handler_));
  #line 40 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  return y;
}

#line 43 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMultivariateNormalInverseGammaGaussian::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch", 43);
  #line 44 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(12)));
  #line 45 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(12) - 1), this_()->x->value(handler_));
  #line 46 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_assert_(!this_()->_u0956->hasValue(handler_));
  #line 47 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(2) - 1, birch::type::Integer(11) - 1)), this_()->_u0956->value(handler_));
  #line 48 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_assert_(!this_()->_u09632->hasValue(handler_));
  #line 49 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(49);
  #line 49 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u09632->value(handler_));
  #line 50 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(50);
  #line 50 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  return y;
}

#line 53 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> birch::type::TestLinearMultivariateNormalInverseGammaGaussian::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch", 53);
  #line 54 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
birch::type::TestLinearMultivariateNormalInverseGammaGaussian* birch::type::make_TestLinearMultivariateNormalInverseGammaGaussian_() {
  #line 1 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  return new birch::type::TestLinearMultivariateNormalInverseGammaGaussian();
  #line 1 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
}

#line 1 "src/test/model/TestBetaBernoulli.birch"
birch::type::TestBetaBernoulli::TestBetaBernoulli(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestBetaBernoulli.birch"
    super_type_(),
    #line 2 "src/test/model/TestBetaBernoulli.birch"
    _u0961(),
    #line 3 "src/test/model/TestBetaBernoulli.birch"
    x() {
  //
}

#line 5 "src/test/model/TestBetaBernoulli.birch"
void birch::type::TestBetaBernoulli::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 5 "src/test/model/TestBetaBernoulli.birch"
  libbirch_function_("initialize", "src/test/model/TestBetaBernoulli.birch", 5);
}

#line 9 "src/test/model/TestBetaBernoulli.birch"
void birch::type::TestBetaBernoulli::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/test/model/TestBetaBernoulli.birch"
  libbirch_function_("simulate", "src/test/model/TestBetaBernoulli.birch", 9);
  #line 10 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(10);
  #line 10 "src/test/model/TestBetaBernoulli.birch"
  birch::type::Real _u0945 = birch::simulate_uniform(1.0, 10.0, handler_);
  #line 11 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(11);
  #line 11 "src/test/model/TestBetaBernoulli.birch"
  birch::type::Real _u0946 = birch::simulate_uniform(1.0, 10.0, handler_);
  #line 12 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestBetaBernoulli.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0961, (birch::Beta(_u0945, _u0946, handler_))->distribution(), handler_), handler_);
  #line 13 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestBetaBernoulli.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Bernoulli(this_()->_u0961, handler_))->distribution(), handler_), handler_);
}

#line 16 "src/test/model/TestBetaBernoulli.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestBetaBernoulli::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/test/model/TestBetaBernoulli.birch"
  libbirch_function_("forward", "src/test/model/TestBetaBernoulli.birch", 16);
  #line 17 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestBetaBernoulli.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 18 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestBetaBernoulli.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0961->value(handler_));
  #line 19 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestBetaBernoulli.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 20 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestBetaBernoulli.birch"
  if (this_()->x->value(handler_)) {
    #line 21 "src/test/model/TestBetaBernoulli.birch"
    libbirch_line_(21);
    #line 21 "src/test/model/TestBetaBernoulli.birch"
    y.set(libbirch::make_slice(birch::type::Integer(2) - 1), 1.0);
  } else {
    #line 23 "src/test/model/TestBetaBernoulli.birch"
    libbirch_line_(23);
    #line 23 "src/test/model/TestBetaBernoulli.birch"
    y.set(libbirch::make_slice(birch::type::Integer(2) - 1), 0.0);
  }
  #line 26 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestBetaBernoulli.birch"
  return y;
}

#line 29 "src/test/model/TestBetaBernoulli.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestBetaBernoulli::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "src/test/model/TestBetaBernoulli.birch"
  libbirch_function_("backward", "src/test/model/TestBetaBernoulli.birch", 29);
  #line 30 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestBetaBernoulli.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 31 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestBetaBernoulli.birch"
  if (this_()->x->value(handler_)) {
    #line 32 "src/test/model/TestBetaBernoulli.birch"
    libbirch_line_(32);
    #line 32 "src/test/model/TestBetaBernoulli.birch"
    y.set(libbirch::make_slice(birch::type::Integer(2) - 1), 1.0);
  } else {
    #line 34 "src/test/model/TestBetaBernoulli.birch"
    libbirch_line_(34);
    #line 34 "src/test/model/TestBetaBernoulli.birch"
    y.set(libbirch::make_slice(birch::type::Integer(2) - 1), 0.0);
  }
  #line 36 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestBetaBernoulli.birch"
  libbirch_assert_(!this_()->_u0961->hasValue(handler_));
  #line 37 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestBetaBernoulli.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0961->value(handler_));
  #line 39 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestBetaBernoulli.birch"
  return y;
}

#line 42 "src/test/model/TestBetaBernoulli.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Boolean>>> birch::type::TestBetaBernoulli::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/test/model/TestBetaBernoulli.birch"
  libbirch_function_("marginal", "src/test/model/TestBetaBernoulli.birch", 42);
  #line 43 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestBetaBernoulli.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestBetaBernoulli.birch"
birch::type::TestBetaBernoulli* birch::type::make_TestBetaBernoulli_() {
  #line 1 "src/test/model/TestBetaBernoulli.birch"
  return new birch::type::TestBetaBernoulli();
  #line 1 "src/test/model/TestBetaBernoulli.birch"
}

#line 1 "src/test/model/TestGammaExponential.birch"
birch::type::TestGammaExponential::TestGammaExponential(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestGammaExponential.birch"
    super_type_(),
    #line 2 "src/test/model/TestGammaExponential.birch"
    k(),
    #line 3 "src/test/model/TestGammaExponential.birch"
    _u0952(),
    #line 4 "src/test/model/TestGammaExponential.birch"
    _u0955(),
    #line 5 "src/test/model/TestGammaExponential.birch"
    x() {
  //
}

#line 7 "src/test/model/TestGammaExponential.birch"
void birch::type::TestGammaExponential::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/test/model/TestGammaExponential.birch"
  libbirch_function_("initialize", "src/test/model/TestGammaExponential.birch", 7);
  #line 8 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(8);
  #line 8 "src/test/model/TestGammaExponential.birch"
  this_()->k = birch::simulate_uniform(1.0, 10.0, handler_);
  #line 9 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(9);
  #line 9 "src/test/model/TestGammaExponential.birch"
  this_()->_u0952 = birch::simulate_uniform(0.0, 2.0, handler_);
}

#line 12 "src/test/model/TestGammaExponential.birch"
void birch::type::TestGammaExponential::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 12 "src/test/model/TestGammaExponential.birch"
  libbirch_function_("simulate", "src/test/model/TestGammaExponential.birch", 12);
  #line 13 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestGammaExponential.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0955, (birch::Gamma(this_()->k, this_()->_u0952, handler_))->distribution(), handler_), handler_);
  #line 14 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestGammaExponential.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Exponential(this_()->_u0955, handler_))->distribution(), handler_), handler_);
}

#line 17 "src/test/model/TestGammaExponential.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestGammaExponential::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 17 "src/test/model/TestGammaExponential.birch"
  libbirch_function_("forward", "src/test/model/TestGammaExponential.birch", 17);
  #line 18 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestGammaExponential.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 19 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestGammaExponential.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0955->value(handler_));
  #line 20 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestGammaExponential.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 21 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestGammaExponential.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 22 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestGammaExponential.birch"
  return y;
}

#line 25 "src/test/model/TestGammaExponential.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestGammaExponential::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/test/model/TestGammaExponential.birch"
  libbirch_function_("backward", "src/test/model/TestGammaExponential.birch", 25);
  #line 26 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestGammaExponential.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 27 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestGammaExponential.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 28 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestGammaExponential.birch"
  libbirch_assert_(!this_()->_u0955->hasValue(handler_));
  #line 29 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestGammaExponential.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0955->value(handler_));
  #line 30 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestGammaExponential.birch"
  return y;
}

#line 33 "src/test/model/TestGammaExponential.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> birch::type::TestGammaExponential::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/test/model/TestGammaExponential.birch"
  libbirch_function_("marginal", "src/test/model/TestGammaExponential.birch", 33);
  #line 34 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestGammaExponential.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestGammaExponential.birch"
birch::type::TestGammaExponential* birch::type::make_TestGammaExponential_() {
  #line 1 "src/test/model/TestGammaExponential.birch"
  return new birch::type::TestGammaExponential();
  #line 1 "src/test/model/TestGammaExponential.birch"
}

#line 1 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian::TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    super_type_(),
    #line 2 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    _u09632(),
    #line 3 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    _u0956(),
    #line 4 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    x(),
    #line 6 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    A(libbirch::make_shape(birch::type::Integer(5), birch::type::Integer(10))),
    #line 7 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    _u0956_0(libbirch::make_shape(birch::type::Integer(10))),
    #line 8 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    _u0931(libbirch::make_shape(birch::type::Integer(10), birch::type::Integer(10))),
    #line 9 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    c(libbirch::make_shape(birch::type::Integer(5))),
    #line 10 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    _u0945(),
    #line 11 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    _u0946() {
  //
}

#line 13 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 13 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 13);
  #line 14 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  this_()->_u0945 = birch::simulate_uniform(2.0, 10.0, handler_);
  #line 15 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  this_()->_u0946 = birch::simulate_uniform(0.0, 10.0, handler_);
  #line 16 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(10); ++i) {
    #line 17 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    libbirch_line_(17);
    #line 17 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    this_()->_u0956_0.set(libbirch::make_slice(i - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    #line 18 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    libbirch_line_(18);
    #line 18 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= birch::type::Integer(10); ++j) {
      #line 19 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
      libbirch_line_(19);
      #line 19 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
      this_()->_u0931.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
    }
  }
  #line 22 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(5); ++i) {
    #line 23 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    libbirch_line_(23);
    #line 23 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    this_()->c.set(libbirch::make_slice(i - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    #line 24 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    libbirch_line_(24);
    #line 24 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= birch::type::Integer(10); ++j) {
      #line 25 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
      libbirch_line_(25);
      #line 25 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
      this_()->A.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
    }
  }
  #line 28 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  this_()->_u0931 = this_()->_u0931 * birch::transpose(this_()->_u0931, handler_);
}

#line 31 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 31);
  #line 32 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u09632, (birch::InverseGamma(this_()->_u0945, this_()->_u0946, handler_))->distribution(), handler_), handler_);
  #line 33 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0956, (birch::Gaussian(this_()->_u0956_0, this_()->_u0931, this_()->_u09632, handler_))->distribution(), handler_), handler_);
  #line 34 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Gaussian(this_()->A * this_()->_u0956 - this_()->c, this_()->_u09632, handler_))->distribution(), handler_), handler_);
}

#line 37 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 37);
  #line 38 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(16)));
  #line 39 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u09632->value(handler_));
  #line 40 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_assert_(!this_()->_u0956->hasValue(handler_));
  #line 41 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(2) - 1, birch::type::Integer(11) - 1)), this_()->_u0956->value(handler_));
  #line 42 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 43 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(12) - 1, birch::type::Integer(16) - 1)), this_()->x->value(handler_));
  #line 44 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return y;
}

#line 47 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 47);
  #line 48 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(16)));
  #line 49 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(49);
  #line 49 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(12) - 1, birch::type::Integer(16) - 1)), this_()->x->value(handler_));
  #line 50 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(50);
  #line 50 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_assert_(!this_()->_u0956->hasValue(handler_));
  #line 51 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(2) - 1, birch::type::Integer(11) - 1)), this_()->_u0956->value(handler_));
  #line 52 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_assert_(!this_()->_u09632->hasValue(handler_));
  #line 53 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(53);
  #line 53 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u09632->value(handler_));
  #line 54 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return y;
}

#line 57 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>> birch::type::TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 57 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 57);
  #line 58 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(58);
  #line 58 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian* birch::type::make_TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian_() {
  #line 1 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return new birch::type::TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian();
  #line 1 "src/test/model/TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
}

#line 1 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
birch::type::TestNegativeLinearGaussianGaussian::TestNegativeLinearGaussianGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
    super_type_(),
    #line 2 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
    _u0956_1(),
    #line 3 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
    x(),
    #line 5 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
    a(),
    #line 6 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
    c(),
    #line 7 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
    _u0956_0(),
    #line 8 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
    _u09632_0(),
    #line 9 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
    _u09632_1() {
  //
}

#line 11 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
void birch::type::TestNegativeLinearGaussianGaussian::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestNegativeLinearGaussianGaussian.birch", 11);
  #line 12 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  this_()->a = birch::simulate_uniform(-2.0, 2.0, handler_);
  #line 13 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  this_()->c = birch::simulate_uniform(-10.0, 10.0, handler_);
  #line 14 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  this_()->_u0956_0 = birch::simulate_uniform(-10.0, 10.0, handler_);
  #line 15 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  this_()->_u09632_0 = birch::simulate_uniform(0.0, 2.0, handler_);
  #line 16 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  this_()->_u09632_1 = birch::simulate_uniform(0.0, 2.0, handler_);
}

#line 19 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
void birch::type::TestNegativeLinearGaussianGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestNegativeLinearGaussianGaussian.birch", 19);
  #line 20 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0956_1, (birch::Gaussian(this_()->_u0956_0, this_()->_u09632_0, handler_))->distribution(), handler_), handler_);
  #line 21 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Gaussian(this_()->_u0956_1 / this_()->a - this_()->c, this_()->_u09632_1, handler_))->distribution(), handler_), handler_);
}

#line 24 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNegativeLinearGaussianGaussian::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestNegativeLinearGaussianGaussian.birch", 24);
  #line 25 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 26 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0956_1->value(handler_));
  #line 27 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 28 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 29 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  return y;
}

#line 32 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNegativeLinearGaussianGaussian::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestNegativeLinearGaussianGaussian.birch", 32);
  #line 33 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 34 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 35 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_assert_(!this_()->_u0956_1->hasValue(handler_));
  #line 36 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0956_1->value(handler_));
  #line 37 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  return y;
}

#line 40 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> birch::type::TestNegativeLinearGaussianGaussian::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestNegativeLinearGaussianGaussian.birch", 40);
  #line 41 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
birch::type::TestNegativeLinearGaussianGaussian* birch::type::make_TestNegativeLinearGaussianGaussian_() {
  #line 1 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
  return new birch::type::TestNegativeLinearGaussianGaussian();
  #line 1 "src/test/model/TestNegativeLinearGaussianGaussian.birch"
}

#line 1 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
birch::type::TestNegativeLinearNormalInverseGammaGaussian::TestNegativeLinearNormalInverseGammaGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
    super_type_(),
    #line 2 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
    _u09632(),
    #line 3 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
    _u0956(),
    #line 4 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
    x(),
    #line 6 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
    a(),
    #line 7 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
    _u0956_0(),
    #line 8 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
    a2(),
    #line 9 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
    c(),
    #line 10 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
    _u0945(),
    #line 11 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
    _u0946() {
  //
}

#line 13 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
void birch::type::TestNegativeLinearNormalInverseGammaGaussian::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 13 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch", 13);
  #line 14 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  this_()->a = birch::simulate_uniform(-2.0, 2.0, handler_);
  #line 15 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  this_()->_u0956_0 = birch::simulate_uniform(-10.0, 10.0, handler_);
  #line 16 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  this_()->a2 = birch::simulate_uniform(0.1, 2.0, handler_);
  #line 17 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  this_()->c = birch::simulate_uniform(-10.0, 10.0, handler_);
  #line 18 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  this_()->_u0945 = birch::simulate_uniform(2.0, 10.0, handler_);
  #line 19 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  this_()->_u0946 = birch::simulate_uniform(0.1, 10.0, handler_);
}

#line 22 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
void birch::type::TestNegativeLinearNormalInverseGammaGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch", 22);
  #line 23 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u09632, (birch::InverseGamma(this_()->_u0945, this_()->_u0946, handler_))->distribution(), handler_), handler_);
  #line 24 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0956, (birch::Gaussian(this_()->_u0956_0, this_()->a2, this_()->_u09632, handler_))->distribution(), handler_), handler_);
  #line 25 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Gaussian(this_()->_u0956 / this_()->a - this_()->c, this_()->_u09632, handler_))->distribution(), handler_), handler_);
}

#line 28 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNegativeLinearNormalInverseGammaGaussian::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch", 28);
  #line 29 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(3)));
  #line 30 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_assert_(!this_()->_u09632->hasValue(handler_));
  #line 31 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u09632->value(handler_));
  #line 32 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_assert_(!this_()->_u0956->hasValue(handler_));
  #line 33 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->_u0956->value(handler_));
  #line 34 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 35 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(3) - 1), this_()->x->value(handler_));
  #line 36 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  return y;
}

#line 39 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNegativeLinearNormalInverseGammaGaussian::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch", 39);
  #line 40 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(3)));
  #line 41 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 42 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(3) - 1), this_()->x->value(handler_));
  #line 43 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_assert_(!this_()->_u0956->hasValue(handler_));
  #line 44 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->_u0956->value(handler_));
  #line 45 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_assert_(!this_()->_u09632->hasValue(handler_));
  #line 46 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u09632->value(handler_));
  #line 47 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  return y;
}

#line 50 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> birch::type::TestNegativeLinearNormalInverseGammaGaussian::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch", 50);
  #line 51 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
birch::type::TestNegativeLinearNormalInverseGammaGaussian* birch::type::make_TestNegativeLinearNormalInverseGammaGaussian_() {
  #line 1 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
  return new birch::type::TestNegativeLinearNormalInverseGammaGaussian();
  #line 1 "src/test/model/TestNegativeLinearNormalInverseGammaGaussian.birch"
}

#line 1 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::TestLinearMatrixNormalInverseGammaMatrixGaussian::TestLinearMatrixNormalInverseGammaMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    super_type_(),
    #line 2 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    _u09632(),
    #line 3 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    X(),
    #line 4 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    Y(),
    #line 6 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    n(birch::type::Integer(5)),
    #line 7 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    p(birch::type::Integer(2)),
    #line 8 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    _u0945(),
    #line 9 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    A(libbirch::make_shape(n, n)),
    #line 10 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    M(libbirch::make_shape(n, p)),
    #line 11 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    _u0931(libbirch::make_shape(n, n)),
    #line 12 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    C(libbirch::make_shape(n, p)),
    #line 13 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    _u0946(libbirch::make_shape(p)) {
  //
}

#line 15 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
void birch::type::TestLinearMatrixNormalInverseGammaMatrixGaussian::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch", 15);
  #line 16 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->_u0945 = birch::simulate_uniform(2.0, 10.0, handler_);
  #line 17 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= this_()->n; ++i) {
    #line 18 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    libbirch_line_(18);
    #line 18 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= this_()->n; ++j) {
      #line 19 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
      libbirch_line_(19);
      #line 19 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
      this_()->A.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
      #line 20 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
      libbirch_line_(20);
      #line 20 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
      this_()->_u0931.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
    }
    #line 22 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    libbirch_line_(22);
    #line 22 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= this_()->p; ++j) {
      #line 23 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
      libbirch_line_(23);
      #line 23 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
      this_()->M.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
      #line 24 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
      libbirch_line_(24);
      #line 24 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
      this_()->C.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    }
  }
  #line 27 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= this_()->p; ++i) {
    #line 28 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    libbirch_line_(28);
    #line 28 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    this_()->_u0946.set(libbirch::make_slice(i - 1), birch::simulate_uniform(0.0, 10.0, handler_));
  }
  #line 30 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->_u0931 = this_()->_u0931 * birch::transpose(this_()->_u0931, handler_);
}

#line 33 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
void birch::type::TestLinearMatrixNormalInverseGammaMatrixGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch", 33);
  #line 34 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u09632, (birch::InverseGamma(this_()->_u0945, this_()->_u0946, handler_))->distribution(), handler_), handler_);
  #line 35 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->X, (birch::Gaussian(this_()->M, this_()->_u0931, this_()->_u09632, handler_))->distribution(), handler_), handler_);
  #line 36 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->Y, (birch::Gaussian(this_()->A * this_()->X + this_()->C, this_()->_u09632, handler_))->distribution(), handler_), handler_);
}

#line 39 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMatrixNormalInverseGammaMatrixGaussian::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch", 39);
  #line 40 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_assert_(!this_()->_u09632->hasValue(handler_));
  #line 41 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->_u09632->value(handler_);
  #line 42 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_assert_(!this_()->X->hasValue(handler_));
  #line 43 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->X->value(handler_);
  #line 44 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_assert_(!this_()->Y->hasValue(handler_));
  #line 45 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->Y->value(handler_);
  #line 46 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return this_()->vectorize(handler_);
}

#line 49 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMatrixNormalInverseGammaMatrixGaussian::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch", 49);
  #line 50 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(50);
  #line 50 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_assert_(!this_()->Y->hasValue(handler_));
  #line 51 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->Y->value(handler_);
  #line 52 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_assert_(!this_()->X->hasValue(handler_));
  #line 53 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(53);
  #line 53 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->X->value(handler_);
  #line 54 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_assert_(!this_()->_u09632->hasValue(handler_));
  #line 55 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(55);
  #line 55 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->_u09632->value(handler_);
  #line 56 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return this_()->vectorize(handler_);
}

#line 59 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>> birch::type::TestLinearMatrixNormalInverseGammaMatrixGaussian::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch", 59);
  #line 60 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(60);
  #line 60 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return this_()->Y->distribution(handler_).get();
}

#line 63 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMatrixNormalInverseGammaMatrixGaussian::vectorize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 63 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("vectorize", "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch", 63);
  #line 64 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(64);
  #line 64 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(this_()->size(handler_)));
  #line 65 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(65);
  #line 65 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, birch::length(this_()->_u09632, handler_) - 1)), this_()->_u09632->value(handler_));
  #line 66 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  auto k = birch::length(this_()->_u09632, handler_);
  #line 67 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(67);
  #line 67 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(this_()->X, handler_); ++i) {
    #line 68 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    libbirch_line_(68);
    #line 68 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    y.set(libbirch::make_slice(libbirch::make_range(k + birch::type::Integer(1) - 1, k + birch::columns(this_()->X, handler_) - 1)), this_()->X->value(handler_).get(libbirch::make_slice(i - 1, libbirch::make_range(birch::type::Integer(1) - 1, birch::columns(this_()->X, handler_) - 1))));
    #line 69 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    libbirch_line_(69);
    #line 69 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    k = k + birch::columns(this_()->X, handler_);
  }
  #line 71 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(71);
  #line 71 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(this_()->Y, handler_); ++i) {
    #line 72 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    libbirch_line_(72);
    #line 72 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    y.set(libbirch::make_slice(libbirch::make_range(k + birch::type::Integer(1) - 1, k + birch::columns(this_()->Y, handler_) - 1)), this_()->Y->value(handler_).get(libbirch::make_slice(i - 1, libbirch::make_range(birch::type::Integer(1) - 1, birch::columns(this_()->Y, handler_) - 1))));
    #line 73 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    libbirch_line_(73);
    #line 73 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
    k = k + birch::columns(this_()->Y, handler_);
  }
  #line 75 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(75);
  #line 75 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return y;
}

#line 78 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::Integer birch::type::TestLinearMatrixNormalInverseGammaMatrixGaussian::size(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 78 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("size", "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch", 78);
  #line 79 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(79);
  #line 79 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return this_()->p + birch::type::Integer(2) * this_()->n * this_()->p;
}

#line 1 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::TestLinearMatrixNormalInverseGammaMatrixGaussian* birch::type::make_TestLinearMatrixNormalInverseGammaMatrixGaussian_() {
  #line 1 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return new birch::type::TestLinearMatrixNormalInverseGammaMatrixGaussian();
  #line 1 "src/test/model/TestLinearMatrixNormalInverseGammaMatrixGaussian.birch"
}

#line 1 "src/test/model/TestGammaPoisson.birch"
birch::type::TestGammaPoisson::TestGammaPoisson(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestGammaPoisson.birch"
    super_type_(),
    #line 2 "src/test/model/TestGammaPoisson.birch"
    _u0955(),
    #line 3 "src/test/model/TestGammaPoisson.birch"
    x(),
    #line 4 "src/test/model/TestGammaPoisson.birch"
    k(),
    #line 5 "src/test/model/TestGammaPoisson.birch"
    _u0952() {
  //
}

#line 7 "src/test/model/TestGammaPoisson.birch"
void birch::type::TestGammaPoisson::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/test/model/TestGammaPoisson.birch"
  libbirch_function_("initialize", "src/test/model/TestGammaPoisson.birch", 7);
  #line 8 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(8);
  #line 8 "src/test/model/TestGammaPoisson.birch"
  this_()->k = birch::simulate_uniform_int(birch::type::Integer(1), birch::type::Integer(10), handler_);
  #line 9 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(9);
  #line 9 "src/test/model/TestGammaPoisson.birch"
  this_()->_u0952 = birch::simulate_uniform(0.0, 10.0, handler_);
}

#line 12 "src/test/model/TestGammaPoisson.birch"
void birch::type::TestGammaPoisson::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 12 "src/test/model/TestGammaPoisson.birch"
  libbirch_function_("simulate", "src/test/model/TestGammaPoisson.birch", 12);
  #line 13 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestGammaPoisson.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0955, (birch::Gamma(this_()->k, this_()->_u0952, handler_))->distribution(), handler_), handler_);
  #line 14 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestGammaPoisson.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Poisson(this_()->_u0955, handler_))->distribution(), handler_), handler_);
}

#line 17 "src/test/model/TestGammaPoisson.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestGammaPoisson::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 17 "src/test/model/TestGammaPoisson.birch"
  libbirch_function_("forward", "src/test/model/TestGammaPoisson.birch", 17);
  #line 18 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestGammaPoisson.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 19 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestGammaPoisson.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0955->value(handler_));
  #line 20 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestGammaPoisson.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 21 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestGammaPoisson.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 22 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestGammaPoisson.birch"
  return y;
}

#line 25 "src/test/model/TestGammaPoisson.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestGammaPoisson::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/test/model/TestGammaPoisson.birch"
  libbirch_function_("backward", "src/test/model/TestGammaPoisson.birch", 25);
  #line 26 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestGammaPoisson.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 27 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestGammaPoisson.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 28 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestGammaPoisson.birch"
  libbirch_assert_(!this_()->_u0955->hasValue(handler_));
  #line 29 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestGammaPoisson.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0955->value(handler_));
  #line 30 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestGammaPoisson.birch"
  return y;
}

#line 33 "src/test/model/TestGammaPoisson.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> birch::type::TestGammaPoisson::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/test/model/TestGammaPoisson.birch"
  libbirch_function_("marginal", "src/test/model/TestGammaPoisson.birch", 33);
  #line 34 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestGammaPoisson.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestGammaPoisson.birch"
birch::type::TestGammaPoisson* birch::type::make_TestGammaPoisson_() {
  #line 1 "src/test/model/TestGammaPoisson.birch"
  return new birch::type::TestGammaPoisson();
  #line 1 "src/test/model/TestGammaPoisson.birch"
}

#line 1 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::TestMatrixNormalInverseGammaMatrixGaussian::TestMatrixNormalInverseGammaMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
    super_type_(),
    #line 2 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
    _u09632(),
    #line 3 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
    X(),
    #line 4 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
    Y(),
    #line 6 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
    n(birch::type::Integer(5)),
    #line 7 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
    p(birch::type::Integer(2)),
    #line 8 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
    M(libbirch::make_shape(n, p)),
    #line 9 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
    _u0931(libbirch::make_shape(n, n)),
    #line 10 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
    _u0945(),
    #line 11 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
    _u0946(libbirch::make_shape(p)) {
  //
}

#line 13 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
void birch::type::TestMatrixNormalInverseGammaMatrixGaussian::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 13 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch", 13);
  #line 14 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->_u0945 = birch::simulate_uniform(2.0, 10.0, handler_);
  #line 15 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= this_()->n; ++i) {
    #line 16 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
    libbirch_line_(16);
    #line 16 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= this_()->n; ++j) {
      #line 17 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
      libbirch_line_(17);
      #line 17 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
      this_()->_u0931.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
    }
    #line 19 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
    libbirch_line_(19);
    #line 19 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= this_()->p; ++j) {
      #line 20 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
      libbirch_line_(20);
      #line 20 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
      this_()->M.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    }
  }
  #line 23 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= this_()->p; ++i) {
    #line 24 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
    libbirch_line_(24);
    #line 24 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
    this_()->_u0946.set(libbirch::make_slice(i - 1), birch::simulate_uniform(0.0, 10.0, handler_));
  }
  #line 26 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->_u0931 = this_()->_u0931 * birch::transpose(this_()->_u0931, handler_);
}

#line 29 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
void birch::type::TestMatrixNormalInverseGammaMatrixGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch", 29);
  #line 30 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u09632, (birch::InverseGamma(this_()->_u0945, this_()->_u0946, handler_))->distribution(), handler_), handler_);
  #line 31 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->X, (birch::Gaussian(this_()->M, this_()->_u0931, this_()->_u09632, handler_))->distribution(), handler_), handler_);
  #line 32 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->Y, (birch::Gaussian(this_()->X, this_()->_u09632, handler_))->distribution(), handler_), handler_);
}

#line 35 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestMatrixNormalInverseGammaMatrixGaussian::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch", 35);
  #line 36 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_assert_(!this_()->_u09632->hasValue(handler_));
  #line 37 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->_u09632->value(handler_);
  #line 38 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_assert_(!this_()->X->hasValue(handler_));
  #line 39 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->X->value(handler_);
  #line 40 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_assert_(!this_()->Y->hasValue(handler_));
  #line 41 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->Y->value(handler_);
  #line 42 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  return this_()->vectorize(handler_);
}

#line 45 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestMatrixNormalInverseGammaMatrixGaussian::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch", 45);
  #line 46 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_assert_(!this_()->Y->hasValue(handler_));
  #line 47 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->Y->value(handler_);
  #line 48 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_assert_(!this_()->X->hasValue(handler_));
  #line 49 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(49);
  #line 49 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->X->value(handler_);
  #line 50 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(50);
  #line 50 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_assert_(!this_()->_u09632->hasValue(handler_));
  #line 51 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->_u09632->value(handler_);
  #line 52 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  return this_()->vectorize(handler_);
}

#line 55 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>> birch::type::TestMatrixNormalInverseGammaMatrixGaussian::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 55 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch", 55);
  #line 56 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  return this_()->Y->distribution(handler_).get();
}

#line 59 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestMatrixNormalInverseGammaMatrixGaussian::vectorize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("vectorize", "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch", 59);
  #line 60 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(60);
  #line 60 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(this_()->size(handler_)));
  #line 61 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(61);
  #line 61 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, birch::length(this_()->_u09632, handler_) - 1)), this_()->_u09632->value(handler_));
  #line 62 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(62);
  #line 62 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  auto k = birch::length(this_()->_u09632, handler_);
  #line 63 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(63);
  #line 63 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(this_()->X, handler_); ++i) {
    #line 64 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
    libbirch_line_(64);
    #line 64 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
    y.set(libbirch::make_slice(libbirch::make_range(k + birch::type::Integer(1) - 1, k + birch::columns(this_()->X, handler_) - 1)), this_()->X->value(handler_).get(libbirch::make_slice(i - 1, libbirch::make_range(birch::type::Integer(1) - 1, birch::columns(this_()->X, handler_) - 1))));
    #line 65 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
    libbirch_line_(65);
    #line 65 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
    k = k + birch::columns(this_()->X, handler_);
  }
  #line 67 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(67);
  #line 67 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(this_()->Y, handler_); ++i) {
    #line 68 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
    libbirch_line_(68);
    #line 68 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
    y.set(libbirch::make_slice(libbirch::make_range(k + birch::type::Integer(1) - 1, k + birch::columns(this_()->Y, handler_) - 1)), this_()->Y->value(handler_).get(libbirch::make_slice(i - 1, libbirch::make_range(birch::type::Integer(1) - 1, birch::columns(this_()->Y, handler_) - 1))));
    #line 69 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
    libbirch_line_(69);
    #line 69 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
    k = k + birch::columns(this_()->Y, handler_);
  }
  #line 71 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(71);
  #line 71 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  return y;
}

#line 74 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::Integer birch::type::TestMatrixNormalInverseGammaMatrixGaussian::size(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 74 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("size", "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch", 74);
  #line 75 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(75);
  #line 75 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  return this_()->p + birch::type::Integer(2) * this_()->n * this_()->p;
}

#line 1 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::TestMatrixNormalInverseGammaMatrixGaussian* birch::type::make_TestMatrixNormalInverseGammaMatrixGaussian_() {
  #line 1 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
  return new birch::type::TestMatrixNormalInverseGammaMatrixGaussian();
  #line 1 "src/test/model/TestMatrixNormalInverseGammaMatrixGaussian.birch"
}

#line 1 "src/test/model/TestDirichletCategorical.birch"
birch::type::TestDirichletCategorical::TestDirichletCategorical(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestDirichletCategorical.birch"
    super_type_(),
    #line 2 "src/test/model/TestDirichletCategorical.birch"
    _u0961(),
    #line 3 "src/test/model/TestDirichletCategorical.birch"
    x(),
    #line 4 "src/test/model/TestDirichletCategorical.birch"
    _u0945(libbirch::make_shape(birch::type::Integer(5))) {
  //
}

#line 6 "src/test/model/TestDirichletCategorical.birch"
void birch::type::TestDirichletCategorical::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 6 "src/test/model/TestDirichletCategorical.birch"
  libbirch_function_("initialize", "src/test/model/TestDirichletCategorical.birch", 6);
  #line 7 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(7);
  #line 7 "src/test/model/TestDirichletCategorical.birch"
  for (auto n = birch::type::Integer(1); n <= birch::type::Integer(5); ++n) {
    #line 8 "src/test/model/TestDirichletCategorical.birch"
    libbirch_line_(8);
    #line 8 "src/test/model/TestDirichletCategorical.birch"
    this_()->_u0945.set(libbirch::make_slice(n - 1), birch::simulate_uniform(1.0, 10.0, handler_));
  }
}

#line 12 "src/test/model/TestDirichletCategorical.birch"
void birch::type::TestDirichletCategorical::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 12 "src/test/model/TestDirichletCategorical.birch"
  libbirch_function_("simulate", "src/test/model/TestDirichletCategorical.birch", 12);
  #line 13 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestDirichletCategorical.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0961, (birch::Dirichlet(this_()->_u0945, handler_))->distribution(), handler_), handler_);
  #line 14 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestDirichletCategorical.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Categorical(this_()->_u0961, handler_))->distribution(), handler_), handler_);
}

#line 17 "src/test/model/TestDirichletCategorical.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestDirichletCategorical::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 17 "src/test/model/TestDirichletCategorical.birch"
  libbirch_function_("forward", "src/test/model/TestDirichletCategorical.birch", 17);
  #line 18 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestDirichletCategorical.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(6)));
  #line 19 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestDirichletCategorical.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, birch::type::Integer(5) - 1)), this_()->_u0961->value(handler_));
  #line 20 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestDirichletCategorical.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 21 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestDirichletCategorical.birch"
  y.set(libbirch::make_slice(birch::type::Integer(6) - 1), this_()->x->value(handler_));
  #line 22 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestDirichletCategorical.birch"
  return y;
}

#line 25 "src/test/model/TestDirichletCategorical.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestDirichletCategorical::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/test/model/TestDirichletCategorical.birch"
  libbirch_function_("backward", "src/test/model/TestDirichletCategorical.birch", 25);
  #line 26 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestDirichletCategorical.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(6)));
  #line 27 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestDirichletCategorical.birch"
  y.set(libbirch::make_slice(birch::type::Integer(6) - 1), this_()->x->value(handler_));
  #line 28 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestDirichletCategorical.birch"
  libbirch_assert_(!this_()->_u0961->hasValue(handler_));
  #line 29 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestDirichletCategorical.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, birch::type::Integer(5) - 1)), this_()->_u0961->value(handler_));
  #line 30 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestDirichletCategorical.birch"
  return y;
}

#line 33 "src/test/model/TestDirichletCategorical.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> birch::type::TestDirichletCategorical::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/test/model/TestDirichletCategorical.birch"
  libbirch_function_("marginal", "src/test/model/TestDirichletCategorical.birch", 33);
  #line 34 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestDirichletCategorical.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestDirichletCategorical.birch"
birch::type::TestDirichletCategorical* birch::type::make_TestDirichletCategorical_() {
  #line 1 "src/test/model/TestDirichletCategorical.birch"
  return new birch::type::TestDirichletCategorical();
  #line 1 "src/test/model/TestDirichletCategorical.birch"
}

#line 1 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::TestMatrixNormalInverseWishartMatrixGaussian::TestMatrixNormalInverseWishartMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    super_type_(),
    #line 2 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    V(),
    #line 3 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    X(),
    #line 4 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    Y(),
    #line 6 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    n(birch::type::Integer(5)),
    #line 7 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    p(birch::type::Integer(2)),
    #line 9 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    M(libbirch::make_shape(n, p)),
    #line 10 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    U(libbirch::make_shape(n, n)),
    #line 11 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    k(),
    #line 12 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    _u0936(libbirch::make_shape(p, p)) {
  //
}

#line 14 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::TestMatrixNormalInverseWishartMatrixGaussian::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch", 14);
  #line 15 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->k = birch::simulate_uniform(this_()->p - 1.0, this_()->p + 9.0, handler_);
  #line 16 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= this_()->n; ++i) {
    #line 17 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(17);
    #line 17 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= this_()->n; ++j) {
      #line 18 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
      libbirch_line_(18);
      #line 18 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
      this_()->U.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
    }
    #line 20 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(20);
    #line 20 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= this_()->p; ++j) {
      #line 21 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
      libbirch_line_(21);
      #line 21 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
      this_()->M.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    }
  }
  #line 24 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= this_()->p; ++i) {
    #line 25 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(25);
    #line 25 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= this_()->p; ++j) {
      #line 26 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
      libbirch_line_(26);
      #line 26 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
      this_()->_u0936.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    }
  }
  #line 29 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->U = this_()->U * birch::transpose(this_()->U, handler_);
  #line 30 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->_u0936 = this_()->_u0936 * birch::transpose(this_()->_u0936, handler_);
}

#line 33 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::TestMatrixNormalInverseWishartMatrixGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch", 33);
  #line 34 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->V, (birch::InverseWishart(this_()->_u0936, this_()->k, handler_))->distribution(), handler_), handler_);
  #line 35 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->X, (birch::Gaussian(this_()->M, this_()->U, this_()->V, handler_))->distribution(), handler_), handler_);
  #line 36 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->Y, (birch::Gaussian(this_()->X, this_()->V, handler_))->distribution(), handler_), handler_);
}

#line 39 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestMatrixNormalInverseWishartMatrixGaussian::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch", 39);
  #line 40 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!this_()->V->hasValue(handler_));
  #line 41 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->V->value(handler_);
  #line 42 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!this_()->X->hasValue(handler_));
  #line 43 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->X->value(handler_);
  #line 44 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!this_()->Y->hasValue(handler_));
  #line 45 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->Y->value(handler_);
  #line 46 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  return this_()->vectorize(handler_);
}

#line 49 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestMatrixNormalInverseWishartMatrixGaussian::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch", 49);
  #line 50 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(50);
  #line 50 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!this_()->Y->hasValue(handler_));
  #line 51 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->Y->value(handler_);
  #line 52 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!this_()->X->hasValue(handler_));
  #line 53 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(53);
  #line 53 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->X->value(handler_);
  #line 54 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!this_()->V->hasValue(handler_));
  #line 55 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(55);
  #line 55 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->V->value(handler_);
  #line 56 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  return this_()->vectorize(handler_);
}

#line 59 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>> birch::type::TestMatrixNormalInverseWishartMatrixGaussian::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch", 59);
  #line 60 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(60);
  #line 60 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  return this_()->Y->distribution(handler_).get();
}

#line 63 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestMatrixNormalInverseWishartMatrixGaussian::vectorize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 63 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("vectorize", "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch", 63);
  #line 64 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(64);
  #line 64 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(this_()->size(handler_)));
  #line 65 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(65);
  #line 65 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  auto k = birch::type::Integer(0);
  #line 66 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(this_()->V, handler_); ++i) {
    #line 67 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(67);
    #line 67 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    y.set(libbirch::make_slice(libbirch::make_range(k + birch::type::Integer(1) - 1, k + birch::columns(this_()->V, handler_) - 1)), birch::canonical(this_()->V->value(handler_), handler_).get(libbirch::make_slice(i - 1, libbirch::make_range(birch::type::Integer(1) - 1, birch::columns(this_()->V, handler_) - 1))));
    #line 68 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(68);
    #line 68 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    k = k + birch::columns(this_()->V, handler_);
  }
  #line 70 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(70);
  #line 70 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(this_()->X, handler_); ++i) {
    #line 71 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(71);
    #line 71 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    y.set(libbirch::make_slice(libbirch::make_range(k + birch::type::Integer(1) - 1, k + birch::columns(this_()->X, handler_) - 1)), this_()->X->value(handler_).get(libbirch::make_slice(i - 1, libbirch::make_range(birch::type::Integer(1) - 1, birch::columns(this_()->X, handler_) - 1))));
    #line 72 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(72);
    #line 72 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    k = k + birch::columns(this_()->X, handler_);
  }
  #line 74 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(74);
  #line 74 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(this_()->Y, handler_); ++i) {
    #line 75 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(75);
    #line 75 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    y.set(libbirch::make_slice(libbirch::make_range(k + birch::type::Integer(1) - 1, k + birch::columns(this_()->Y, handler_) - 1)), this_()->Y->value(handler_).get(libbirch::make_slice(i - 1, libbirch::make_range(birch::type::Integer(1) - 1, birch::columns(this_()->Y, handler_) - 1))));
    #line 76 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(76);
    #line 76 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    k = k + birch::columns(this_()->Y, handler_);
  }
  #line 78 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(78);
  #line 78 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  return y;
}

#line 81 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Integer birch::type::TestMatrixNormalInverseWishartMatrixGaussian::size(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("size", "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch", 81);
  #line 82 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(82);
  #line 82 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  return this_()->p * this_()->p + birch::type::Integer(2) * this_()->n * this_()->p;
}

#line 1 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::TestMatrixNormalInverseWishartMatrixGaussian* birch::type::make_TestMatrixNormalInverseWishartMatrixGaussian_() {
  #line 1 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  return new birch::type::TestMatrixNormalInverseWishartMatrixGaussian();
  #line 1 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
}

#line 1 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
birch::type::TestSubtractBoundedDiscreteDelta::TestSubtractBoundedDiscreteDelta(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
    super_type_(),
    #line 2 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
    x1(),
    #line 3 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
    x2(),
    #line 4 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
    s() {
  //
}

#line 6 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
void birch::type::TestSubtractBoundedDiscreteDelta::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 6 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_function_("initialize", "src/test/model/TestSubtractBoundedDiscreteDelta.birch", 6);
}

#line 10 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
void birch::type::TestSubtractBoundedDiscreteDelta::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_function_("simulate", "src/test/model/TestSubtractBoundedDiscreteDelta.birch", 10);
  #line 11 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(11);
  #line 11 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x1, (birch::Binomial(birch::type::Integer(100), 0.75, handler_))->distribution(), handler_), handler_);
  #line 12 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x2, (birch::Binomial(birch::type::Integer(100), 0.25, handler_))->distribution(), handler_), handler_);
  #line 13 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch::assume(birch::AssumeEvent(this_()->s, (birch::Delta(this_()->x1 - this_()->x2, handler_))->distribution(), handler_), handler_);
}

#line 16 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestSubtractBoundedDiscreteDelta::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_function_("forward", "src/test/model/TestSubtractBoundedDiscreteDelta.birch", 16);
  #line 17 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 18 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_assert_(!this_()->x1->hasValue(handler_));
  #line 19 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->x1->value(handler_));
  #line 20 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_assert_(!this_()->x2->hasValue(handler_));
  #line 21 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x2->value(handler_));
  #line 22 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  return y;
}

#line 25 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestSubtractBoundedDiscreteDelta::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_function_("backward", "src/test/model/TestSubtractBoundedDiscreteDelta.birch", 25);
  #line 26 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 27 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  this_()->s->value(handler_);
  #line 28 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x2->value(handler_));
  #line 29 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->x1->value(handler_));
  #line 30 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  return y;
}

#line 1 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
birch::type::TestSubtractBoundedDiscreteDelta* birch::type::make_TestSubtractBoundedDiscreteDelta_() {
  #line 1 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  return new birch::type::TestSubtractBoundedDiscreteDelta();
  #line 1 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
}

#line 1 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian::TestLinearMatrixNormalInverseWishartMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    super_type_(),
    #line 2 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    V(),
    #line 3 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    X(),
    #line 4 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    Y(),
    #line 6 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    n(birch::type::Integer(5)),
    #line 7 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    p(birch::type::Integer(2)),
    #line 8 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    A(libbirch::make_shape(n, n)),
    #line 9 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    M(libbirch::make_shape(n, p)),
    #line 10 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    U(libbirch::make_shape(n, n)),
    #line 11 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    C(libbirch::make_shape(n, p)),
    #line 12 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    k(),
    #line 13 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    _u0936(libbirch::make_shape(p, p)) {
  //
}

#line 15 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch", 15);
  #line 16 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->k = birch::simulate_uniform(this_()->p - 1.0, this_()->p + 9.0, handler_);
  #line 17 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= this_()->n; ++i) {
    #line 18 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(18);
    #line 18 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= this_()->n; ++j) {
      #line 19 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      libbirch_line_(19);
      #line 19 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      this_()->A.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
      #line 20 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      libbirch_line_(20);
      #line 20 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      this_()->U.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
    }
    #line 22 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(22);
    #line 22 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= this_()->p; ++j) {
      #line 23 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      libbirch_line_(23);
      #line 23 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      this_()->M.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
      #line 24 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      libbirch_line_(24);
      #line 24 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      this_()->C.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    }
  }
  #line 27 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= this_()->p; ++i) {
    #line 28 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(28);
    #line 28 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= this_()->p; ++j) {
      #line 29 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      libbirch_line_(29);
      #line 29 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      this_()->_u0936.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    }
  }
  #line 32 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->U = this_()->U * birch::transpose(this_()->U, handler_);
  #line 33 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->_u0936 = this_()->_u0936 * birch::transpose(this_()->_u0936, handler_);
}

#line 36 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch", 36);
  #line 37 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->V, (birch::InverseWishart(this_()->_u0936, this_()->k, handler_))->distribution(), handler_), handler_);
  #line 38 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->X, (birch::Gaussian(this_()->M, this_()->U, this_()->V, handler_))->distribution(), handler_), handler_);
  #line 39 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->Y, (birch::Gaussian(this_()->A * this_()->X + this_()->C, this_()->V, handler_))->distribution(), handler_), handler_);
}

#line 42 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch", 42);
  #line 43 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!this_()->V->hasValue(handler_));
  #line 44 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->V->value(handler_);
  #line 45 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!this_()->X->hasValue(handler_));
  #line 46 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->X->value(handler_);
  #line 47 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!this_()->Y->hasValue(handler_));
  #line 48 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->Y->value(handler_);
  #line 49 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(49);
  #line 49 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return this_()->vectorize(handler_);
}

#line 52 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch", 52);
  #line 53 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(53);
  #line 53 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!this_()->Y->hasValue(handler_));
  #line 54 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->Y->value(handler_);
  #line 55 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(55);
  #line 55 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!this_()->X->hasValue(handler_));
  #line 56 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->X->value(handler_);
  #line 57 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(57);
  #line 57 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!this_()->V->hasValue(handler_));
  #line 58 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(58);
  #line 58 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->V->value(handler_);
  #line 59 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(59);
  #line 59 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return this_()->vectorize(handler_);
}

#line 62 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>> birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 62 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch", 62);
  #line 63 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(63);
  #line 63 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return this_()->Y->distribution(handler_).get();
}

#line 66 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian::vectorize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("vectorize", "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch", 66);
  #line 67 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(67);
  #line 67 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(this_()->size(handler_)));
  #line 68 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(68);
  #line 68 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  auto k = birch::type::Integer(0);
  #line 69 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(69);
  #line 69 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(this_()->V, handler_); ++i) {
    #line 70 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(70);
    #line 70 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    y.set(libbirch::make_slice(libbirch::make_range(k + birch::type::Integer(1) - 1, k + birch::columns(this_()->V, handler_) - 1)), birch::canonical(this_()->V->value(handler_), handler_).get(libbirch::make_slice(i - 1, libbirch::make_range(birch::type::Integer(1) - 1, birch::columns(this_()->V, handler_) - 1))));
    #line 71 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(71);
    #line 71 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    k = k + birch::columns(this_()->V, handler_);
  }
  #line 73 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(73);
  #line 73 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(this_()->X, handler_); ++i) {
    #line 74 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(74);
    #line 74 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    y.set(libbirch::make_slice(libbirch::make_range(k + birch::type::Integer(1) - 1, k + birch::columns(this_()->X, handler_) - 1)), this_()->X->value(handler_).get(libbirch::make_slice(i - 1, libbirch::make_range(birch::type::Integer(1) - 1, birch::columns(this_()->X, handler_) - 1))));
    #line 75 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(75);
    #line 75 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    k = k + birch::columns(this_()->X, handler_);
  }
  #line 77 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(77);
  #line 77 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(this_()->Y, handler_); ++i) {
    #line 78 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(78);
    #line 78 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    y.set(libbirch::make_slice(libbirch::make_range(k + birch::type::Integer(1) - 1, k + birch::columns(this_()->Y, handler_) - 1)), this_()->Y->value(handler_).get(libbirch::make_slice(i - 1, libbirch::make_range(birch::type::Integer(1) - 1, birch::columns(this_()->Y, handler_) - 1))));
    #line 79 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(79);
    #line 79 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    k = k + birch::columns(this_()->Y, handler_);
  }
  #line 81 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(81);
  #line 81 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return y;
}

#line 84 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Integer birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian::size(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 84 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("size", "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch", 84);
  #line 85 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(85);
  #line 85 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return this_()->p * this_()->p + birch::type::Integer(2) * this_()->n * this_()->p;
}

#line 1 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian* birch::type::make_TestLinearMatrixNormalInverseWishartMatrixGaussian_() {
  #line 1 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return new birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian();
  #line 1 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
}

#line 1 "src/test/model/TestNormalInverseGamma.birch"
birch::type::TestNormalInverseGamma::TestNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestNormalInverseGamma.birch"
    super_type_(),
    #line 2 "src/test/model/TestNormalInverseGamma.birch"
    _u09632(),
    #line 3 "src/test/model/TestNormalInverseGamma.birch"
    x(),
    #line 5 "src/test/model/TestNormalInverseGamma.birch"
    _u0956(),
    #line 6 "src/test/model/TestNormalInverseGamma.birch"
    a2(),
    #line 7 "src/test/model/TestNormalInverseGamma.birch"
    _u0945(),
    #line 8 "src/test/model/TestNormalInverseGamma.birch"
    _u0946() {
  //
}

#line 10 "src/test/model/TestNormalInverseGamma.birch"
void birch::type::TestNormalInverseGamma::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_function_("initialize", "src/test/model/TestNormalInverseGamma.birch", 10);
  #line 11 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(11);
  #line 11 "src/test/model/TestNormalInverseGamma.birch"
  this_()->_u0956 = birch::simulate_uniform(-10.0, 10.0, handler_);
  #line 12 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestNormalInverseGamma.birch"
  this_()->a2 = birch::simulate_uniform(0.1, 2.0, handler_);
  #line 13 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestNormalInverseGamma.birch"
  this_()->_u0945 = birch::simulate_uniform(2.0, 10.0, handler_);
  #line 14 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestNormalInverseGamma.birch"
  this_()->_u0946 = birch::simulate_uniform(0.1, 10.0, handler_);
}

#line 17 "src/test/model/TestNormalInverseGamma.birch"
void birch::type::TestNormalInverseGamma::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 17 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_function_("simulate", "src/test/model/TestNormalInverseGamma.birch", 17);
  #line 18 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestNormalInverseGamma.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u09632, (birch::InverseGamma(this_()->_u0945, this_()->_u0946, handler_))->distribution(), handler_), handler_);
  #line 19 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestNormalInverseGamma.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Gaussian(this_()->_u0956, this_()->a2, this_()->_u09632, handler_))->distribution(), handler_), handler_);
}

#line 22 "src/test/model/TestNormalInverseGamma.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNormalInverseGamma::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_function_("forward", "src/test/model/TestNormalInverseGamma.birch", 22);
  #line 23 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestNormalInverseGamma.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 24 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_assert_(!this_()->_u09632->hasValue(handler_));
  #line 25 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestNormalInverseGamma.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u09632->value(handler_));
  #line 26 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 27 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestNormalInverseGamma.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 28 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestNormalInverseGamma.birch"
  return y;
}

#line 31 "src/test/model/TestNormalInverseGamma.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNormalInverseGamma::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_function_("backward", "src/test/model/TestNormalInverseGamma.birch", 31);
  #line 32 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestNormalInverseGamma.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 33 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 34 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestNormalInverseGamma.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 35 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_assert_(!this_()->_u09632->hasValue(handler_));
  #line 36 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestNormalInverseGamma.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u09632->value(handler_));
  #line 37 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestNormalInverseGamma.birch"
  return y;
}

#line 40 "src/test/model/TestNormalInverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> birch::type::TestNormalInverseGamma::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_function_("marginal", "src/test/model/TestNormalInverseGamma.birch", 40);
  #line 41 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestNormalInverseGamma.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestNormalInverseGamma.birch"
birch::type::TestNormalInverseGamma* birch::type::make_TestNormalInverseGamma_() {
  #line 1 "src/test/model/TestNormalInverseGamma.birch"
  return new birch::type::TestNormalInverseGamma();
  #line 1 "src/test/model/TestNormalInverseGamma.birch"
}

#line 1 "src/test/model/TestAddBoundedDiscreteDelta.birch"
birch::type::TestAddBoundedDiscreteDelta::TestAddBoundedDiscreteDelta(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestAddBoundedDiscreteDelta.birch"
    super_type_(),
    #line 2 "src/test/model/TestAddBoundedDiscreteDelta.birch"
    x1(),
    #line 3 "src/test/model/TestAddBoundedDiscreteDelta.birch"
    x2(),
    #line 4 "src/test/model/TestAddBoundedDiscreteDelta.birch"
    s() {
  //
}

#line 6 "src/test/model/TestAddBoundedDiscreteDelta.birch"
void birch::type::TestAddBoundedDiscreteDelta::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 6 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_function_("initialize", "src/test/model/TestAddBoundedDiscreteDelta.birch", 6);
}

#line 10 "src/test/model/TestAddBoundedDiscreteDelta.birch"
void birch::type::TestAddBoundedDiscreteDelta::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_function_("simulate", "src/test/model/TestAddBoundedDiscreteDelta.birch", 10);
  #line 11 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(11);
  #line 11 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x1, (birch::Uniform(birch::type::Integer(1), birch::type::Integer(6), handler_))->distribution(), handler_), handler_);
  #line 12 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x2, (birch::Uniform(birch::type::Integer(1), birch::type::Integer(6), handler_))->distribution(), handler_), handler_);
  #line 13 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch::assume(birch::AssumeEvent(this_()->s, (birch::Delta(this_()->x1 + this_()->x2, handler_))->distribution(), handler_), handler_);
}

#line 16 "src/test/model/TestAddBoundedDiscreteDelta.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestAddBoundedDiscreteDelta::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_function_("forward", "src/test/model/TestAddBoundedDiscreteDelta.birch", 16);
  #line 17 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 18 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_assert_(!this_()->x1->hasValue(handler_));
  #line 19 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->x1->value(handler_));
  #line 20 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_assert_(!this_()->x2->hasValue(handler_));
  #line 21 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x2->value(handler_));
  #line 22 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  return y;
}

#line 25 "src/test/model/TestAddBoundedDiscreteDelta.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestAddBoundedDiscreteDelta::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_function_("backward", "src/test/model/TestAddBoundedDiscreteDelta.birch", 25);
  #line 26 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 27 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  this_()->s->value(handler_);
  #line 28 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x2->value(handler_));
  #line 29 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->x1->value(handler_));
  #line 30 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  return y;
}

#line 1 "src/test/model/TestAddBoundedDiscreteDelta.birch"
birch::type::TestAddBoundedDiscreteDelta* birch::type::make_TestAddBoundedDiscreteDelta_() {
  #line 1 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  return new birch::type::TestAddBoundedDiscreteDelta();
  #line 1 "src/test/model/TestAddBoundedDiscreteDelta.birch"
}

#line 1 "src/test/model/TestDirichletMultinomial.birch"
birch::type::TestDirichletMultinomial::TestDirichletMultinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestDirichletMultinomial.birch"
    super_type_(),
    #line 2 "src/test/model/TestDirichletMultinomial.birch"
    n(),
    #line 3 "src/test/model/TestDirichletMultinomial.birch"
    _u0945(libbirch::make_shape(birch::type::Integer(5))),
    #line 4 "src/test/model/TestDirichletMultinomial.birch"
    _u0961(),
    #line 5 "src/test/model/TestDirichletMultinomial.birch"
    x() {
  //
}

#line 7 "src/test/model/TestDirichletMultinomial.birch"
void birch::type::TestDirichletMultinomial::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_function_("initialize", "src/test/model/TestDirichletMultinomial.birch", 7);
  #line 8 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(8);
  #line 8 "src/test/model/TestDirichletMultinomial.birch"
  this_()->n = birch::simulate_uniform_int(birch::type::Integer(100), birch::type::Integer(500), handler_);
  #line 9 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(9);
  #line 9 "src/test/model/TestDirichletMultinomial.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(5); ++i) {
    #line 10 "src/test/model/TestDirichletMultinomial.birch"
    libbirch_line_(10);
    #line 10 "src/test/model/TestDirichletMultinomial.birch"
    this_()->_u0945.set(libbirch::make_slice(i - 1), birch::simulate_uniform(1.0, 10.0, handler_));
  }
}

#line 14 "src/test/model/TestDirichletMultinomial.birch"
void birch::type::TestDirichletMultinomial::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_function_("simulate", "src/test/model/TestDirichletMultinomial.birch", 14);
  #line 15 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestDirichletMultinomial.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0961, (birch::Dirichlet(this_()->_u0945, handler_))->distribution(), handler_), handler_);
  #line 16 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestDirichletMultinomial.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Multinomial(this_()->n, this_()->_u0961, handler_))->distribution(), handler_), handler_);
}

#line 19 "src/test/model/TestDirichletMultinomial.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestDirichletMultinomial::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_function_("forward", "src/test/model/TestDirichletMultinomial.birch", 19);
  #line 20 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestDirichletMultinomial.birch"
  birch::type::Integer D = birch::length(this_()->_u0945, handler_);
  #line 21 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestDirichletMultinomial.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2) * D));
  #line 22 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestDirichletMultinomial.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, D - 1)), this_()->_u0961->value(handler_));
  #line 23 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 24 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestDirichletMultinomial.birch"
  y.set(libbirch::make_slice(libbirch::make_range(D + birch::type::Integer(1) - 1, birch::type::Integer(2) * D - 1)), this_()->x->value(handler_));
  #line 25 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestDirichletMultinomial.birch"
  return y;
}

#line 28 "src/test/model/TestDirichletMultinomial.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestDirichletMultinomial::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_function_("backward", "src/test/model/TestDirichletMultinomial.birch", 28);
  #line 29 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestDirichletMultinomial.birch"
  birch::type::Integer D = birch::length(this_()->_u0945, handler_);
  #line 30 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestDirichletMultinomial.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2) * D));
  #line 31 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestDirichletMultinomial.birch"
  y.set(libbirch::make_slice(libbirch::make_range(D + birch::type::Integer(1) - 1, birch::type::Integer(2) * D - 1)), this_()->x->value(handler_));
  #line 32 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_assert_(!this_()->_u0961->hasValue(handler_));
  #line 33 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestDirichletMultinomial.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, D - 1)), this_()->_u0961->value(handler_));
  #line 34 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestDirichletMultinomial.birch"
  return y;
}

#line 1 "src/test/model/TestDirichletMultinomial.birch"
birch::type::TestDirichletMultinomial* birch::type::make_TestDirichletMultinomial_() {
  #line 1 "src/test/model/TestDirichletMultinomial.birch"
  return new birch::type::TestDirichletMultinomial();
  #line 1 "src/test/model/TestDirichletMultinomial.birch"
}

#line 1 "src/test/model/TestLinearGaussianGaussian.birch"
birch::type::TestLinearGaussianGaussian::TestLinearGaussianGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestLinearGaussianGaussian.birch"
    super_type_(),
    #line 2 "src/test/model/TestLinearGaussianGaussian.birch"
    _u0956_1(),
    #line 3 "src/test/model/TestLinearGaussianGaussian.birch"
    x(),
    #line 4 "src/test/model/TestLinearGaussianGaussian.birch"
    a(),
    #line 5 "src/test/model/TestLinearGaussianGaussian.birch"
    c(),
    #line 6 "src/test/model/TestLinearGaussianGaussian.birch"
    _u0956_0(),
    #line 7 "src/test/model/TestLinearGaussianGaussian.birch"
    _u09632_0(),
    #line 8 "src/test/model/TestLinearGaussianGaussian.birch"
    _u09632_1() {
  //
}

#line 10 "src/test/model/TestLinearGaussianGaussian.birch"
void birch::type::TestLinearGaussianGaussian::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestLinearGaussianGaussian.birch", 10);
  #line 11 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(11);
  #line 11 "src/test/model/TestLinearGaussianGaussian.birch"
  this_()->a = birch::simulate_uniform(-2.0, 2.0, handler_);
  #line 12 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestLinearGaussianGaussian.birch"
  this_()->c = birch::simulate_uniform(-10.0, 10.0, handler_);
  #line 13 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestLinearGaussianGaussian.birch"
  this_()->_u0956_0 = birch::simulate_uniform(-10.0, 10.0, handler_);
  #line 14 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestLinearGaussianGaussian.birch"
  this_()->_u09632_0 = birch::simulate_uniform(0.0, 2.0, handler_);
  #line 15 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestLinearGaussianGaussian.birch"
  this_()->_u09632_1 = birch::simulate_uniform(0.0, 2.0, handler_);
}

#line 18 "src/test/model/TestLinearGaussianGaussian.birch"
void birch::type::TestLinearGaussianGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestLinearGaussianGaussian.birch", 18);
  #line 19 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0956_1, (birch::Gaussian(this_()->_u0956_0, this_()->_u09632_0, handler_))->distribution(), handler_), handler_);
  #line 20 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Gaussian(this_()->a * this_()->_u0956_1 + this_()->c, this_()->_u09632_1, handler_))->distribution(), handler_), handler_);
}

#line 23 "src/test/model/TestLinearGaussianGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearGaussianGaussian::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestLinearGaussianGaussian.birch", 23);
  #line 24 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 25 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestLinearGaussianGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0956_1->value(handler_));
  #line 26 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 27 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestLinearGaussianGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 28 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestLinearGaussianGaussian.birch"
  return y;
}

#line 31 "src/test/model/TestLinearGaussianGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearGaussianGaussian::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestLinearGaussianGaussian.birch", 31);
  #line 32 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 33 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestLinearGaussianGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 34 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_assert_(!this_()->_u0956_1->hasValue(handler_));
  #line 35 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestLinearGaussianGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0956_1->value(handler_));
  #line 36 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestLinearGaussianGaussian.birch"
  return y;
}

#line 39 "src/test/model/TestLinearGaussianGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> birch::type::TestLinearGaussianGaussian::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestLinearGaussianGaussian.birch", 39);
  #line 40 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestLinearGaussianGaussian.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestLinearGaussianGaussian.birch"
birch::type::TestLinearGaussianGaussian* birch::type::make_TestLinearGaussianGaussian_() {
  #line 1 "src/test/model/TestLinearGaussianGaussian.birch"
  return new birch::type::TestLinearGaussianGaussian();
  #line 1 "src/test/model/TestLinearGaussianGaussian.birch"
}

#line 1 "src/test/model/TestInverseGammaGaussian.birch"
birch::type::TestInverseGammaGamma::TestInverseGammaGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestInverseGammaGaussian.birch"
    super_type_(),
    #line 2 "src/test/model/TestInverseGammaGaussian.birch"
    _u0952(),
    #line 3 "src/test/model/TestInverseGammaGaussian.birch"
    x(),
    #line 4 "src/test/model/TestInverseGammaGaussian.birch"
    k(),
    #line 5 "src/test/model/TestInverseGammaGaussian.birch"
    _u0945(),
    #line 6 "src/test/model/TestInverseGammaGaussian.birch"
    _u0946() {
  //
}

#line 8 "src/test/model/TestInverseGammaGaussian.birch"
void birch::type::TestInverseGammaGamma::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 8 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestInverseGammaGaussian.birch", 8);
  #line 9 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch_line_(9);
  #line 9 "src/test/model/TestInverseGammaGaussian.birch"
  this_()->k = birch::simulate_uniform(1.0, 10.0, handler_);
  #line 10 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch_line_(10);
  #line 10 "src/test/model/TestInverseGammaGaussian.birch"
  this_()->_u0945 = birch::simulate_uniform(2.0, 10.0, handler_);
  #line 11 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch_line_(11);
  #line 11 "src/test/model/TestInverseGammaGaussian.birch"
  this_()->_u0946 = birch::simulate_uniform(0.0, 10.0, handler_);
}

#line 14 "src/test/model/TestInverseGammaGaussian.birch"
void birch::type::TestInverseGammaGamma::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestInverseGammaGaussian.birch", 14);
  #line 15 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0952, (birch::InverseGamma(this_()->_u0945, this_()->_u0946, handler_))->distribution(), handler_), handler_);
  #line 16 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Gamma(this_()->k, this_()->_u0952, handler_))->distribution(), handler_), handler_);
}

#line 19 "src/test/model/TestInverseGammaGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestInverseGammaGamma::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestInverseGammaGaussian.birch", 19);
  #line 20 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 21 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0952->value(handler_));
  #line 22 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 23 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 24 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestInverseGammaGaussian.birch"
  return y;
}

#line 27 "src/test/model/TestInverseGammaGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestInverseGammaGamma::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestInverseGammaGaussian.birch", 27);
  #line 28 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(2)));
  #line 29 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 30 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch_assert_(!this_()->_u0952->hasValue(handler_));
  #line 31 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0952->value(handler_));
  #line 32 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestInverseGammaGaussian.birch"
  return y;
}

#line 35 "src/test/model/TestInverseGammaGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> birch::type::TestInverseGammaGamma::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestInverseGammaGaussian.birch", 35);
  #line 36 "src/test/model/TestInverseGammaGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestInverseGammaGaussian.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestInverseGammaGaussian.birch"
birch::type::TestInverseGammaGamma* birch::type::make_TestInverseGammaGamma_() {
  #line 1 "src/test/model/TestInverseGammaGaussian.birch"
  return new birch::type::TestInverseGammaGamma();
  #line 1 "src/test/model/TestInverseGammaGaussian.birch"
}

#line 1 "src/test/model/TestLinearDiscreteDelta.birch"
birch::type::TestLinearDiscreteDelta::TestLinearDiscreteDelta(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestLinearDiscreteDelta.birch"
    super_type_(),
    #line 2 "src/test/model/TestLinearDiscreteDelta.birch"
    _u0961(),
    #line 3 "src/test/model/TestLinearDiscreteDelta.birch"
    x(),
    #line 4 "src/test/model/TestLinearDiscreteDelta.birch"
    y(),
    #line 5 "src/test/model/TestLinearDiscreteDelta.birch"
    a(),
    #line 6 "src/test/model/TestLinearDiscreteDelta.birch"
    n(),
    #line 7 "src/test/model/TestLinearDiscreteDelta.birch"
    _u0945(),
    #line 8 "src/test/model/TestLinearDiscreteDelta.birch"
    _u0946(),
    #line 9 "src/test/model/TestLinearDiscreteDelta.birch"
    c() {
  //
}

#line 11 "src/test/model/TestLinearDiscreteDelta.birch"
void birch::type::TestLinearDiscreteDelta::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_function_("initialize", "src/test/model/TestLinearDiscreteDelta.birch", 11);
  #line 12 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestLinearDiscreteDelta.birch"
  this_()->a = birch::type::Integer(2) * birch::simulate_uniform_int(birch::type::Integer(0), birch::type::Integer(1), handler_) - birch::type::Integer(1);
  #line 13 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestLinearDiscreteDelta.birch"
  this_()->n = birch::simulate_uniform_int(birch::type::Integer(1), birch::type::Integer(100), handler_);
  #line 14 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestLinearDiscreteDelta.birch"
  this_()->_u0945 = birch::simulate_uniform(0.0, 10.0, handler_);
  #line 15 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestLinearDiscreteDelta.birch"
  this_()->_u0946 = birch::simulate_uniform(0.0, 10.0, handler_);
  #line 16 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestLinearDiscreteDelta.birch"
  this_()->c = birch::simulate_uniform_int(birch::type::Integer(0), birch::type::Integer(100), handler_);
}

#line 19 "src/test/model/TestLinearDiscreteDelta.birch"
void birch::type::TestLinearDiscreteDelta::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_function_("simulate", "src/test/model/TestLinearDiscreteDelta.birch", 19);
  #line 20 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0961, (birch::Beta(this_()->_u0945, this_()->_u0946, handler_))->distribution(), handler_), handler_);
  #line 21 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Binomial(this_()->n, this_()->_u0961, handler_))->distribution(), handler_), handler_);
  #line 22 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch::assume(birch::AssumeEvent(this_()->y, (birch::Delta(this_()->a * this_()->x + this_()->c, handler_))->distribution(), handler_), handler_);
}

#line 25 "src/test/model/TestLinearDiscreteDelta.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearDiscreteDelta::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_function_("forward", "src/test/model/TestLinearDiscreteDelta.birch", 25);
  #line 26 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch::DefaultArray<birch::type::Real,1> z(libbirch::make_shape(birch::type::Integer(2)));
  #line 27 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_assert_(!this_()->_u0961->hasValue(handler_));
  #line 28 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestLinearDiscreteDelta.birch"
  z.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0961->value(handler_));
  #line 29 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 30 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestLinearDiscreteDelta.birch"
  z.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 31 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestLinearDiscreteDelta.birch"
  return z;
}

#line 34 "src/test/model/TestLinearDiscreteDelta.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearDiscreteDelta::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_function_("backward", "src/test/model/TestLinearDiscreteDelta.birch", 34);
  #line 35 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch::DefaultArray<birch::type::Real,1> z(libbirch::make_shape(birch::type::Integer(2)));
  #line 36 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 37 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestLinearDiscreteDelta.birch"
  z.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->x->value(handler_));
  #line 38 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_assert_(!this_()->_u0961->hasValue(handler_));
  #line 39 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestLinearDiscreteDelta.birch"
  z.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u0961->value(handler_));
  #line 40 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestLinearDiscreteDelta.birch"
  return z;
}

#line 43 "src/test/model/TestLinearDiscreteDelta.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> birch::type::TestLinearDiscreteDelta::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_function_("marginal", "src/test/model/TestLinearDiscreteDelta.birch", 43);
  #line 44 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestLinearDiscreteDelta.birch"
  return this_()->y->distribution(handler_).get();
}

#line 1 "src/test/model/TestLinearDiscreteDelta.birch"
birch::type::TestLinearDiscreteDelta* birch::type::make_TestLinearDiscreteDelta_() {
  #line 1 "src/test/model/TestLinearDiscreteDelta.birch"
  return new birch::type::TestLinearDiscreteDelta();
  #line 1 "src/test/model/TestLinearDiscreteDelta.birch"
}

#line 1 "src/test/model/TestNormalInverseGammaGaussian.birch"
birch::type::TestNormalInverseGammaGaussian::TestNormalInverseGammaGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestNormalInverseGammaGaussian.birch"
    super_type_(),
    #line 2 "src/test/model/TestNormalInverseGammaGaussian.birch"
    _u09632(),
    #line 3 "src/test/model/TestNormalInverseGammaGaussian.birch"
    _u0956(),
    #line 4 "src/test/model/TestNormalInverseGammaGaussian.birch"
    x(),
    #line 6 "src/test/model/TestNormalInverseGammaGaussian.birch"
    _u0956_0(),
    #line 7 "src/test/model/TestNormalInverseGammaGaussian.birch"
    a2(),
    #line 8 "src/test/model/TestNormalInverseGammaGaussian.birch"
    _u0945(),
    #line 9 "src/test/model/TestNormalInverseGammaGaussian.birch"
    _u0946() {
  //
}

#line 11 "src/test/model/TestNormalInverseGammaGaussian.birch"
void birch::type::TestNormalInverseGammaGaussian::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestNormalInverseGammaGaussian.birch", 11);
  #line 12 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestNormalInverseGammaGaussian.birch"
  this_()->_u0956_0 = birch::simulate_uniform(-10.0, 10.0, handler_);
  #line 13 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestNormalInverseGammaGaussian.birch"
  this_()->a2 = birch::simulate_uniform(0.0, 2.0, handler_);
  #line 14 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestNormalInverseGammaGaussian.birch"
  this_()->_u0945 = birch::simulate_uniform(2.0, 10.0, handler_);
  #line 15 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestNormalInverseGammaGaussian.birch"
  this_()->_u0946 = birch::simulate_uniform(0.0, 10.0, handler_);
}

#line 18 "src/test/model/TestNormalInverseGammaGaussian.birch"
void birch::type::TestNormalInverseGammaGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestNormalInverseGammaGaussian.birch", 18);
  #line 19 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u09632, (birch::InverseGamma(this_()->_u0945, this_()->_u0946, handler_))->distribution(), handler_), handler_);
  #line 20 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0956, (birch::Gaussian(this_()->_u0956_0, this_()->a2, this_()->_u09632, handler_))->distribution(), handler_), handler_);
  #line 21 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Gaussian(this_()->_u0956, this_()->_u09632, handler_))->distribution(), handler_), handler_);
}

#line 24 "src/test/model/TestNormalInverseGammaGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNormalInverseGammaGaussian::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestNormalInverseGammaGaussian.birch", 24);
  #line 25 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(3)));
  #line 26 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestNormalInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u09632->value(handler_));
  #line 27 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_assert_(!this_()->_u0956->hasValue(handler_));
  #line 28 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestNormalInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->_u0956->value(handler_));
  #line 29 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 30 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestNormalInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(3) - 1), this_()->x->value(handler_));
  #line 31 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestNormalInverseGammaGaussian.birch"
  return y;
}

#line 34 "src/test/model/TestNormalInverseGammaGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNormalInverseGammaGaussian::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestNormalInverseGammaGaussian.birch", 34);
  #line 35 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(3)));
  #line 36 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestNormalInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(3) - 1), this_()->x->value(handler_));
  #line 37 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_assert_(!this_()->_u0956->hasValue(handler_));
  #line 38 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestNormalInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(2) - 1), this_()->_u0956->value(handler_));
  #line 39 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_assert_(!this_()->_u09632->hasValue(handler_));
  #line 40 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestNormalInverseGammaGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u09632->value(handler_));
  #line 41 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestNormalInverseGammaGaussian.birch"
  return y;
}

#line 44 "src/test/model/TestNormalInverseGammaGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> birch::type::TestNormalInverseGammaGaussian::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestNormalInverseGammaGaussian.birch", 44);
  #line 45 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestNormalInverseGammaGaussian.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestNormalInverseGammaGaussian.birch"
birch::type::TestNormalInverseGammaGaussian* birch::type::make_TestNormalInverseGammaGaussian_() {
  #line 1 "src/test/model/TestNormalInverseGammaGaussian.birch"
  return new birch::type::TestNormalInverseGammaGaussian();
  #line 1 "src/test/model/TestNormalInverseGammaGaussian.birch"
}

#line 1 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::TestLinearMultivariateNormalInverseGammaMultivariateGaussian::TestLinearMultivariateNormalInverseGammaMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    super_type_(),
    #line 2 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    _u09632(),
    #line 3 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    _u0956(),
    #line 4 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    x(),
    #line 6 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    A(libbirch::make_shape(birch::type::Integer(5), birch::type::Integer(10))),
    #line 7 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    _u0956_0(libbirch::make_shape(birch::type::Integer(10))),
    #line 8 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    _u0931(libbirch::make_shape(birch::type::Integer(10), birch::type::Integer(10))),
    #line 9 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    c(libbirch::make_shape(birch::type::Integer(5))),
    #line 10 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    _u0945(),
    #line 11 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    _u0946() {
  //
}

#line 13 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::TestLinearMultivariateNormalInverseGammaMultivariateGaussian::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 13 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 13);
  #line 14 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  this_()->_u0945 = birch::simulate_uniform(2.0, 10.0, handler_);
  #line 15 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  this_()->_u0946 = birch::simulate_uniform(0.0, 10.0, handler_);
  #line 16 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(10); ++i) {
    #line 17 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    libbirch_line_(17);
    #line 17 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    this_()->_u0956_0.set(libbirch::make_slice(i - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    #line 18 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    libbirch_line_(18);
    #line 18 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= birch::type::Integer(10); ++j) {
      #line 19 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
      libbirch_line_(19);
      #line 19 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
      this_()->_u0931.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
    }
  }
  #line 22 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(5); ++i) {
    #line 23 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    libbirch_line_(23);
    #line 23 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    this_()->c.set(libbirch::make_slice(i - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    #line 24 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    libbirch_line_(24);
    #line 24 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= birch::type::Integer(10); ++j) {
      #line 25 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
      libbirch_line_(25);
      #line 25 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
      this_()->A.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
    }
  }
  #line 28 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  this_()->_u0931 = this_()->_u0931 * birch::transpose(this_()->_u0931, handler_);
}

#line 31 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::TestLinearMultivariateNormalInverseGammaMultivariateGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 31);
  #line 32 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u09632, (birch::InverseGamma(this_()->_u0945, this_()->_u0946, handler_))->distribution(), handler_), handler_);
  #line 33 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->_u0956, (birch::Gaussian(this_()->_u0956_0, this_()->_u0931, this_()->_u09632, handler_))->distribution(), handler_), handler_);
  #line 34 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::assume(birch::AssumeEvent(this_()->x, (birch::Gaussian(this_()->A * this_()->_u0956 + this_()->c, this_()->_u09632, handler_))->distribution(), handler_), handler_);
}

#line 37 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMultivariateNormalInverseGammaMultivariateGaussian::forward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 37);
  #line 38 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(16)));
  #line 39 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u09632->value(handler_));
  #line 40 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_assert_(!this_()->_u0956->hasValue(handler_));
  #line 41 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(2) - 1, birch::type::Integer(11) - 1)), this_()->_u0956->value(handler_));
  #line 42 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_assert_(!this_()->x->hasValue(handler_));
  #line 43 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(12) - 1, birch::type::Integer(16) - 1)), this_()->x->value(handler_));
  #line 44 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return y;
}

#line 47 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMultivariateNormalInverseGammaMultivariateGaussian::backward(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 47);
  #line 48 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y(libbirch::make_shape(birch::type::Integer(16)));
  #line 49 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(49);
  #line 49 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(12) - 1, birch::type::Integer(16) - 1)), this_()->x->value(handler_));
  #line 50 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(50);
  #line 50 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_assert_(!this_()->_u0956->hasValue(handler_));
  #line 51 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(2) - 1, birch::type::Integer(11) - 1)), this_()->_u0956->value(handler_));
  #line 52 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_assert_(!this_()->_u09632->hasValue(handler_));
  #line 53 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(53);
  #line 53 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y.set(libbirch::make_slice(birch::type::Integer(1) - 1), this_()->_u09632->value(handler_));
  #line 54 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return y;
}

#line 57 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>> birch::type::TestLinearMultivariateNormalInverseGammaMultivariateGaussian::marginal(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 57 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 57);
  #line 58 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(58);
  #line 58 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return this_()->x->distribution(handler_).get()->graft(handler_);
}

#line 1 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::TestLinearMultivariateNormalInverseGammaMultivariateGaussian* birch::type::make_TestLinearMultivariateNormalInverseGammaMultivariateGaussian_() {
  #line 1 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return new birch::type::TestLinearMultivariateNormalInverseGammaMultivariateGaussian();
  #line 1 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
}

