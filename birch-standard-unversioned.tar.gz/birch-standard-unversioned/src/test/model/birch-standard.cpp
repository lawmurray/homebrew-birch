#line 1 "src/test/model/TestAddBoundedDiscreteDelta.birch"
birch::type::TestAddBoundedDiscreteDelta::TestAddBoundedDiscreteDelta() :
    #line 1 "src/test/model/TestAddBoundedDiscreteDelta.birch"
    base_type_(),
    #line 2 "src/test/model/TestAddBoundedDiscreteDelta.birch"
    x1(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Integer>>>()),
    #line 3 "src/test/model/TestAddBoundedDiscreteDelta.birch"
    x2(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Integer>>>()),
    #line 4 "src/test/model/TestAddBoundedDiscreteDelta.birch"
    s(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Integer>>>()) {
  //
}

#line 6 "src/test/model/TestAddBoundedDiscreteDelta.birch"
void birch::type::TestAddBoundedDiscreteDelta::initialize() {
  #line 6 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_function_("initialize", "src/test/model/TestAddBoundedDiscreteDelta.birch", 6);
}

#line 10 "src/test/model/TestAddBoundedDiscreteDelta.birch"
void birch::type::TestAddBoundedDiscreteDelta::simulate() {
  #line 10 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_function_("simulate", "src/test/model/TestAddBoundedDiscreteDelta.birch", 10);
  #line 11 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(11);
  #line 11 "src/test/model/TestAddBoundedDiscreteDelta.birch"
    birch::handle_assume(this->x1, birch::Uniform(birch::type::Integer(1), birch::type::Integer(6)));
;
  #line 12 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestAddBoundedDiscreteDelta.birch"
    birch::handle_assume(this->x2, birch::Uniform(birch::type::Integer(1), birch::type::Integer(6)));
;
  #line 13 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestAddBoundedDiscreteDelta.birch"
    birch::handle_assume(this->s, birch::Delta(this->x1 + this->x2));
;
}

#line 16 "src/test/model/TestAddBoundedDiscreteDelta.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestAddBoundedDiscreteDelta::forward() {
  #line 16 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_function_("forward", "src/test/model/TestAddBoundedDiscreteDelta.birch", 16);
  #line 17 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 18 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  y(birch::type::Integer(1)) = this->x1->value();
  #line 19 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  y(birch::type::Integer(2)) = this->x2->value();
  #line 20 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  return y;
}

#line 23 "src/test/model/TestAddBoundedDiscreteDelta.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestAddBoundedDiscreteDelta::backward() {
  #line 23 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_function_("backward", "src/test/model/TestAddBoundedDiscreteDelta.birch", 23);
  #line 24 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 25 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  this->s->value();
  #line 26 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_assert_(!(this->x1->hasValue()));
  #line 27 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_assert_(!(this->x2->hasValue()));
  #line 28 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  y(birch::type::Integer(2)) = this->x2->value();
  #line 29 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  y(birch::type::Integer(1)) = this->x1->value();
  #line 30 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  return y;
}

#line 33 "src/test/model/TestAddBoundedDiscreteDelta.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestAddBoundedDiscreteDelta::forwardLazy() {
  #line 33 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestAddBoundedDiscreteDelta.birch", 33);
  #line 34 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 35 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  y(birch::type::Integer(1)) = this->x1->get();
  #line 36 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  y(birch::type::Integer(2)) = this->x2->get();
  #line 37 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  return y;
}

#line 40 "src/test/model/TestAddBoundedDiscreteDelta.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestAddBoundedDiscreteDelta::backwardLazy() {
  #line 40 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestAddBoundedDiscreteDelta.birch", 40);
  #line 41 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 42 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  this->s->get();
  #line 43 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_assert_(!(this->x1->hasValue()));
  #line 44 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_assert_(!(this->x2->hasValue()));
  #line 45 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  y(birch::type::Integer(2)) = this->x2->get();
  #line 46 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  y(birch::type::Integer(1)) = this->x1->get();
  #line 47 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  return y;
}

#line 1 "src/test/model/TestAddBoundedDiscreteDelta.birch"
birch::type::TestAddBoundedDiscreteDelta* birch::type::make_TestAddBoundedDiscreteDelta_() {
  #line 1 "src/test/model/TestAddBoundedDiscreteDelta.birch"
  return new birch::type::TestAddBoundedDiscreteDelta();
  #line 1 "src/test/model/TestAddBoundedDiscreteDelta.birch"
}

#line 1 "src/test/model/TestBetaBernoulli.birch"
birch::type::TestBetaBernoulli::TestBetaBernoulli() :
    #line 1 "src/test/model/TestBetaBernoulli.birch"
    base_type_(),
    #line 2 "src/test/model/TestBetaBernoulli.birch"
    ρ(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 3 "src/test/model/TestBetaBernoulli.birch"
    x(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Boolean>>>()) {
  //
}

#line 5 "src/test/model/TestBetaBernoulli.birch"
void birch::type::TestBetaBernoulli::initialize() {
  #line 5 "src/test/model/TestBetaBernoulli.birch"
  libbirch_function_("initialize", "src/test/model/TestBetaBernoulli.birch", 5);
}

#line 9 "src/test/model/TestBetaBernoulli.birch"
void birch::type::TestBetaBernoulli::simulate() {
  #line 9 "src/test/model/TestBetaBernoulli.birch"
  libbirch_function_("simulate", "src/test/model/TestBetaBernoulli.birch", 9);
  #line 10 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(10);
  #line 10 "src/test/model/TestBetaBernoulli.birch"
  birch::type::Real α = birch::simulate_uniform(1.0, 20.0);
  #line 11 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(11);
  #line 11 "src/test/model/TestBetaBernoulli.birch"
  birch::type::Real β = birch::simulate_uniform(1.0, 20.0);
  #line 12 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestBetaBernoulli.birch"
    birch::handle_assume(this->ρ, birch::Beta(α, β));
;
  #line 13 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestBetaBernoulli.birch"
    birch::handle_assume(this->x, birch::Bernoulli(this->ρ));
;
}

#line 16 "src/test/model/TestBetaBernoulli.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestBetaBernoulli::forward() {
  #line 16 "src/test/model/TestBetaBernoulli.birch"
  libbirch_function_("forward", "src/test/model/TestBetaBernoulli.birch", 16);
  #line 17 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestBetaBernoulli.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 18 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestBetaBernoulli.birch"
  y(birch::type::Integer(1)) = this->ρ->value();
  #line 19 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestBetaBernoulli.birch"
  y(birch::type::Integer(2)) = this->x->value();
  #line 20 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestBetaBernoulli.birch"
  return y;
}

#line 23 "src/test/model/TestBetaBernoulli.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestBetaBernoulli::backward() {
  #line 23 "src/test/model/TestBetaBernoulli.birch"
  libbirch_function_("backward", "src/test/model/TestBetaBernoulli.birch", 23);
  #line 24 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestBetaBernoulli.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 25 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestBetaBernoulli.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 26 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestBetaBernoulli.birch"
  y(birch::type::Integer(2)) = this->x->value();
  #line 27 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestBetaBernoulli.birch"
  libbirch_assert_(!(this->ρ->hasValue()));
  #line 28 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestBetaBernoulli.birch"
  y(birch::type::Integer(1)) = this->ρ->value();
  #line 29 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestBetaBernoulli.birch"
  return y;
}

#line 32 "src/test/model/TestBetaBernoulli.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestBetaBernoulli::forwardLazy() {
  #line 32 "src/test/model/TestBetaBernoulli.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestBetaBernoulli.birch", 32);
  #line 33 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestBetaBernoulli.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 34 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestBetaBernoulli.birch"
  y(birch::type::Integer(1)) = this->ρ->get();
  #line 35 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestBetaBernoulli.birch"
  y(birch::type::Integer(2)) = this->x->get();
  #line 36 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestBetaBernoulli.birch"
  return y;
}

#line 39 "src/test/model/TestBetaBernoulli.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestBetaBernoulli::backwardLazy() {
  #line 39 "src/test/model/TestBetaBernoulli.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestBetaBernoulli.birch", 39);
  #line 40 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestBetaBernoulli.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 41 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestBetaBernoulli.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 42 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestBetaBernoulli.birch"
  y(birch::type::Integer(2)) = this->x->get();
  #line 43 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestBetaBernoulli.birch"
  libbirch_assert_(!(this->ρ->hasValue()));
  #line 44 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestBetaBernoulli.birch"
  y(birch::type::Integer(1)) = this->ρ->get();
  #line 45 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestBetaBernoulli.birch"
  return y;
}

#line 48 "src/test/model/TestBetaBernoulli.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Boolean>> birch::type::TestBetaBernoulli::marginal() {
  #line 48 "src/test/model/TestBetaBernoulli.birch"
  libbirch_function_("marginal", "src/test/model/TestBetaBernoulli.birch", 48);
  #line 49 "src/test/model/TestBetaBernoulli.birch"
  libbirch_line_(49);
  #line 49 "src/test/model/TestBetaBernoulli.birch"
  return this->x->distribution().value();
}

#line 1 "src/test/model/TestBetaBernoulli.birch"
birch::type::TestBetaBernoulli* birch::type::make_TestBetaBernoulli_() {
  #line 1 "src/test/model/TestBetaBernoulli.birch"
  return new birch::type::TestBetaBernoulli();
  #line 1 "src/test/model/TestBetaBernoulli.birch"
}

#line 1 "src/test/model/TestBetaBinomial.birch"
birch::type::TestBetaBinomial::TestBetaBinomial() :
    #line 1 "src/test/model/TestBetaBinomial.birch"
    base_type_(),
    #line 2 "src/test/model/TestBetaBinomial.birch"
    ρ(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 3 "src/test/model/TestBetaBinomial.birch"
    x(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Integer>>>()),
    #line 4 "src/test/model/TestBetaBinomial.birch"
    n(libbirch::make<birch::type::Integer>()),
    #line 5 "src/test/model/TestBetaBinomial.birch"
    α(libbirch::make<birch::type::Real>()),
    #line 6 "src/test/model/TestBetaBinomial.birch"
    β(libbirch::make<birch::type::Real>()) {
  //
}

#line 8 "src/test/model/TestBetaBinomial.birch"
void birch::type::TestBetaBinomial::initialize() {
  #line 8 "src/test/model/TestBetaBinomial.birch"
  libbirch_function_("initialize", "src/test/model/TestBetaBinomial.birch", 8);
  #line 9 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(9);
  #line 9 "src/test/model/TestBetaBinomial.birch"
  this->n = birch::simulate_uniform_int(birch::type::Integer(1), birch::type::Integer(100));
  #line 10 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(10);
  #line 10 "src/test/model/TestBetaBinomial.birch"
  this->α = birch::simulate_uniform(1.0, 20.0);
  #line 11 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(11);
  #line 11 "src/test/model/TestBetaBinomial.birch"
  this->β = birch::simulate_uniform(1.0, 20.0);
}

#line 14 "src/test/model/TestBetaBinomial.birch"
void birch::type::TestBetaBinomial::simulate() {
  #line 14 "src/test/model/TestBetaBinomial.birch"
  libbirch_function_("simulate", "src/test/model/TestBetaBinomial.birch", 14);
  #line 15 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestBetaBinomial.birch"
    birch::handle_assume(this->ρ, birch::Beta(this->α, this->β));
;
  #line 16 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestBetaBinomial.birch"
    birch::handle_assume(this->x, birch::Binomial(this->n, this->ρ));
;
}

#line 19 "src/test/model/TestBetaBinomial.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestBetaBinomial::forward() {
  #line 19 "src/test/model/TestBetaBinomial.birch"
  libbirch_function_("forward", "src/test/model/TestBetaBinomial.birch", 19);
  #line 20 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestBetaBinomial.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 21 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestBetaBinomial.birch"
  y(birch::type::Integer(1)) = this->ρ->value();
  #line 22 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestBetaBinomial.birch"
  y(birch::type::Integer(2)) = this->x->value();
  #line 23 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestBetaBinomial.birch"
  return y;
}

#line 26 "src/test/model/TestBetaBinomial.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestBetaBinomial::backward() {
  #line 26 "src/test/model/TestBetaBinomial.birch"
  libbirch_function_("backward", "src/test/model/TestBetaBinomial.birch", 26);
  #line 27 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestBetaBinomial.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 28 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestBetaBinomial.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 29 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestBetaBinomial.birch"
  y(birch::type::Integer(2)) = this->x->value();
  #line 30 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestBetaBinomial.birch"
  libbirch_assert_(!(this->ρ->hasValue()));
  #line 31 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestBetaBinomial.birch"
  y(birch::type::Integer(1)) = this->ρ->value();
  #line 32 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestBetaBinomial.birch"
  return y;
}

#line 35 "src/test/model/TestBetaBinomial.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestBetaBinomial::forwardLazy() {
  #line 35 "src/test/model/TestBetaBinomial.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestBetaBinomial.birch", 35);
  #line 36 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestBetaBinomial.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 37 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestBetaBinomial.birch"
  y(birch::type::Integer(1)) = this->ρ->get();
  #line 38 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestBetaBinomial.birch"
  y(birch::type::Integer(2)) = this->x->get();
  #line 39 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestBetaBinomial.birch"
  return y;
}

#line 42 "src/test/model/TestBetaBinomial.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestBetaBinomial::backwardLazy() {
  #line 42 "src/test/model/TestBetaBinomial.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestBetaBinomial.birch", 42);
  #line 43 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestBetaBinomial.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 44 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestBetaBinomial.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 45 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestBetaBinomial.birch"
  y(birch::type::Integer(2)) = this->x->get();
  #line 46 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestBetaBinomial.birch"
  libbirch_assert_(!(this->ρ->hasValue()));
  #line 47 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestBetaBinomial.birch"
  y(birch::type::Integer(1)) = this->ρ->get();
  #line 48 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(48);
  #line 48 "src/test/model/TestBetaBinomial.birch"
  return y;
}

#line 51 "src/test/model/TestBetaBinomial.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Integer>> birch::type::TestBetaBinomial::marginal() {
  #line 51 "src/test/model/TestBetaBinomial.birch"
  libbirch_function_("marginal", "src/test/model/TestBetaBinomial.birch", 51);
  #line 52 "src/test/model/TestBetaBinomial.birch"
  libbirch_line_(52);
  #line 52 "src/test/model/TestBetaBinomial.birch"
  return this->x->distribution().value();
}

#line 1 "src/test/model/TestBetaBinomial.birch"
birch::type::TestBetaBinomial* birch::type::make_TestBetaBinomial_() {
  #line 1 "src/test/model/TestBetaBinomial.birch"
  return new birch::type::TestBetaBinomial();
  #line 1 "src/test/model/TestBetaBinomial.birch"
}

#line 1 "src/test/model/TestBetaGeometric.birch"
birch::type::TestBetaGeometric::TestBetaGeometric() :
    #line 1 "src/test/model/TestBetaGeometric.birch"
    base_type_(),
    #line 2 "src/test/model/TestBetaGeometric.birch"
    ρ(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 3 "src/test/model/TestBetaGeometric.birch"
    x(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Integer>>>()),
    #line 4 "src/test/model/TestBetaGeometric.birch"
    α(libbirch::make<birch::type::Real>()),
    #line 5 "src/test/model/TestBetaGeometric.birch"
    β(libbirch::make<birch::type::Real>()) {
  //
}

#line 7 "src/test/model/TestBetaGeometric.birch"
void birch::type::TestBetaGeometric::initialize() {
  #line 7 "src/test/model/TestBetaGeometric.birch"
  libbirch_function_("initialize", "src/test/model/TestBetaGeometric.birch", 7);
  #line 8 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(8);
  #line 8 "src/test/model/TestBetaGeometric.birch"
  this->α = birch::simulate_uniform(1.0, 20.0);
  #line 9 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(9);
  #line 9 "src/test/model/TestBetaGeometric.birch"
  this->β = birch::simulate_uniform(1.0, 20.0);
}

#line 12 "src/test/model/TestBetaGeometric.birch"
void birch::type::TestBetaGeometric::simulate() {
  #line 12 "src/test/model/TestBetaGeometric.birch"
  libbirch_function_("simulate", "src/test/model/TestBetaGeometric.birch", 12);
  #line 13 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestBetaGeometric.birch"
    birch::handle_assume(this->ρ, birch::Beta(this->α, this->β));
;
  #line 14 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestBetaGeometric.birch"
    birch::handle_assume(this->x, birch::Geometric(this->ρ));
;
}

#line 17 "src/test/model/TestBetaGeometric.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestBetaGeometric::forward() {
  #line 17 "src/test/model/TestBetaGeometric.birch"
  libbirch_function_("forward", "src/test/model/TestBetaGeometric.birch", 17);
  #line 18 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestBetaGeometric.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 19 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestBetaGeometric.birch"
  y(birch::type::Integer(1)) = this->ρ->value();
  #line 20 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestBetaGeometric.birch"
  y(birch::type::Integer(2)) = this->x->value();
  #line 21 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestBetaGeometric.birch"
  return y;
}

#line 24 "src/test/model/TestBetaGeometric.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestBetaGeometric::backward() {
  #line 24 "src/test/model/TestBetaGeometric.birch"
  libbirch_function_("backward", "src/test/model/TestBetaGeometric.birch", 24);
  #line 25 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestBetaGeometric.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 26 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestBetaGeometric.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 27 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestBetaGeometric.birch"
  y(birch::type::Integer(2)) = this->x->value();
  #line 28 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestBetaGeometric.birch"
  libbirch_assert_(!(this->ρ->hasValue()));
  #line 29 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestBetaGeometric.birch"
  y(birch::type::Integer(1)) = this->ρ->value();
  #line 30 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestBetaGeometric.birch"
  return y;
}

#line 33 "src/test/model/TestBetaGeometric.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestBetaGeometric::forwardLazy() {
  #line 33 "src/test/model/TestBetaGeometric.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestBetaGeometric.birch", 33);
  #line 34 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestBetaGeometric.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 35 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestBetaGeometric.birch"
  y(birch::type::Integer(1)) = this->ρ->get();
  #line 36 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestBetaGeometric.birch"
  y(birch::type::Integer(2)) = this->x->get();
  #line 37 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestBetaGeometric.birch"
  return y;
}

#line 40 "src/test/model/TestBetaGeometric.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestBetaGeometric::backwardLazy() {
  #line 40 "src/test/model/TestBetaGeometric.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestBetaGeometric.birch", 40);
  #line 41 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestBetaGeometric.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 42 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestBetaGeometric.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 43 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestBetaGeometric.birch"
  y(birch::type::Integer(2)) = this->x->get();
  #line 44 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestBetaGeometric.birch"
  libbirch_assert_(!(this->ρ->hasValue()));
  #line 45 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestBetaGeometric.birch"
  y(birch::type::Integer(1)) = this->ρ->get();
  #line 46 "src/test/model/TestBetaGeometric.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestBetaGeometric.birch"
  return y;
}

#line 1 "src/test/model/TestBetaGeometric.birch"
birch::type::TestBetaGeometric* birch::type::make_TestBetaGeometric_() {
  #line 1 "src/test/model/TestBetaGeometric.birch"
  return new birch::type::TestBetaGeometric();
  #line 1 "src/test/model/TestBetaGeometric.birch"
}

#line 1 "src/test/model/TestBetaNegativeBinomial.birch"
birch::type::TestBetaNegativeBinomial::TestBetaNegativeBinomial() :
    #line 1 "src/test/model/TestBetaNegativeBinomial.birch"
    base_type_(),
    #line 2 "src/test/model/TestBetaNegativeBinomial.birch"
    k(libbirch::make<birch::type::Integer>()),
    #line 3 "src/test/model/TestBetaNegativeBinomial.birch"
    α(libbirch::make<birch::type::Real>()),
    #line 4 "src/test/model/TestBetaNegativeBinomial.birch"
    β(libbirch::make<birch::type::Real>()),
    #line 5 "src/test/model/TestBetaNegativeBinomial.birch"
    ρ(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 6 "src/test/model/TestBetaNegativeBinomial.birch"
    x(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Integer>>>()) {
  //
}

#line 8 "src/test/model/TestBetaNegativeBinomial.birch"
void birch::type::TestBetaNegativeBinomial::initialize() {
  #line 8 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_function_("initialize", "src/test/model/TestBetaNegativeBinomial.birch", 8);
  #line 9 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(9);
  #line 9 "src/test/model/TestBetaNegativeBinomial.birch"
  this->k = birch::simulate_uniform_int(birch::type::Integer(1), birch::type::Integer(100));
  #line 10 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(10);
  #line 10 "src/test/model/TestBetaNegativeBinomial.birch"
  this->α = birch::simulate_uniform(1.0, 20.0);
  #line 11 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(11);
  #line 11 "src/test/model/TestBetaNegativeBinomial.birch"
  this->β = birch::simulate_uniform(1.0, 20.0);
}

#line 14 "src/test/model/TestBetaNegativeBinomial.birch"
void birch::type::TestBetaNegativeBinomial::simulate() {
  #line 14 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_function_("simulate", "src/test/model/TestBetaNegativeBinomial.birch", 14);
  #line 15 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestBetaNegativeBinomial.birch"
    birch::handle_assume(this->ρ, birch::Beta(this->α, this->β));
;
  #line 16 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestBetaNegativeBinomial.birch"
    birch::handle_assume(this->x, birch::NegativeBinomial(this->k, this->ρ));
;
}

#line 19 "src/test/model/TestBetaNegativeBinomial.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestBetaNegativeBinomial::forward() {
  #line 19 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_function_("forward", "src/test/model/TestBetaNegativeBinomial.birch", 19);
  #line 20 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 21 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestBetaNegativeBinomial.birch"
  y(birch::type::Integer(1)) = this->ρ->value();
  #line 22 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestBetaNegativeBinomial.birch"
  y(birch::type::Integer(2)) = this->x->value();
  #line 23 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestBetaNegativeBinomial.birch"
  return y;
}

#line 26 "src/test/model/TestBetaNegativeBinomial.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestBetaNegativeBinomial::backward() {
  #line 26 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_function_("backward", "src/test/model/TestBetaNegativeBinomial.birch", 26);
  #line 27 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 28 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 29 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestBetaNegativeBinomial.birch"
  y(birch::type::Integer(2)) = this->x->value();
  #line 30 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_assert_(!(this->ρ->hasValue()));
  #line 31 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestBetaNegativeBinomial.birch"
  y(birch::type::Integer(1)) = this->ρ->value();
  #line 32 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestBetaNegativeBinomial.birch"
  return y;
}

#line 35 "src/test/model/TestBetaNegativeBinomial.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestBetaNegativeBinomial::forwardLazy() {
  #line 35 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestBetaNegativeBinomial.birch", 35);
  #line 36 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 37 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestBetaNegativeBinomial.birch"
  y(birch::type::Integer(1)) = this->ρ->get();
  #line 38 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestBetaNegativeBinomial.birch"
  y(birch::type::Integer(2)) = this->x->get();
  #line 39 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestBetaNegativeBinomial.birch"
  return y;
}

#line 42 "src/test/model/TestBetaNegativeBinomial.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestBetaNegativeBinomial::backwardLazy() {
  #line 42 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestBetaNegativeBinomial.birch", 42);
  #line 43 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 44 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 45 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestBetaNegativeBinomial.birch"
  y(birch::type::Integer(2)) = this->x->get();
  #line 46 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_assert_(!(this->ρ->hasValue()));
  #line 47 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestBetaNegativeBinomial.birch"
  y(birch::type::Integer(1)) = this->ρ->get();
  #line 48 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(48);
  #line 48 "src/test/model/TestBetaNegativeBinomial.birch"
  return y;
}

#line 51 "src/test/model/TestBetaNegativeBinomial.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Integer>> birch::type::TestBetaNegativeBinomial::marginal() {
  #line 51 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_function_("marginal", "src/test/model/TestBetaNegativeBinomial.birch", 51);
  #line 52 "src/test/model/TestBetaNegativeBinomial.birch"
  libbirch_line_(52);
  #line 52 "src/test/model/TestBetaNegativeBinomial.birch"
  return this->x->distribution().value();
}

#line 1 "src/test/model/TestBetaNegativeBinomial.birch"
birch::type::TestBetaNegativeBinomial* birch::type::make_TestBetaNegativeBinomial_() {
  #line 1 "src/test/model/TestBetaNegativeBinomial.birch"
  return new birch::type::TestBetaNegativeBinomial();
  #line 1 "src/test/model/TestBetaNegativeBinomial.birch"
}

#line 1 "src/test/model/TestChainGaussian.birch"
birch::type::TestChainGaussian::TestChainGaussian() :
    #line 1 "src/test/model/TestChainGaussian.birch"
    base_type_(),
    #line 2 "src/test/model/TestChainGaussian.birch"
    x(libbirch::make_array<libbirch::Shared<birch::type::Random<birch::type::Real>>>(libbirch::make_shape(birch::type::Integer(5)))),
    #line 3 "src/test/model/TestChainGaussian.birch"
    μ(libbirch::make<birch::type::Real>()),
    #line 4 "src/test/model/TestChainGaussian.birch"
    σ2(libbirch::make<libbirch::DefaultArray<birch::type::Real,1>>()) {
  //
}

#line 6 "src/test/model/TestChainGaussian.birch"
void birch::type::TestChainGaussian::initialize() {
  #line 6 "src/test/model/TestChainGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestChainGaussian.birch", 6);
  #line 7 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/model/TestChainGaussian.birch"
  this->μ = birch::simulate_uniform(-(10.0), 10.0);
  #line 8 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(8);
  #line 8 "src/test/model/TestChainGaussian.birch"
  this->σ2 = libbirch::make_array_from_sequence({ birch::simulate_uniform(0.1, 10.0), birch::simulate_uniform(0.1, 10.0), birch::simulate_uniform(0.1, 10.0), birch::simulate_uniform(0.1, 10.0), birch::simulate_uniform(0.1, 10.0) });
}

#line 17 "src/test/model/TestChainGaussian.birch"
void birch::type::TestChainGaussian::simulate() {
  #line 17 "src/test/model/TestChainGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestChainGaussian.birch", 17);
  #line 18 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestChainGaussian.birch"
    birch::handle_assume(this->x(birch::type::Integer(1)), birch::Gaussian(this->μ, this->σ2(birch::type::Integer(1))));
;
  #line 19 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestChainGaussian.birch"
    birch::handle_assume(this->x(birch::type::Integer(2)), birch::Gaussian(this->x(birch::type::Integer(1)), this->σ2(birch::type::Integer(2))));
;
  #line 20 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestChainGaussian.birch"
    birch::handle_assume(this->x(birch::type::Integer(3)), birch::Gaussian(this->x(birch::type::Integer(2)), this->σ2(birch::type::Integer(3))));
;
  #line 21 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestChainGaussian.birch"
    birch::handle_assume(this->x(birch::type::Integer(4)), birch::Gaussian(this->x(birch::type::Integer(3)), this->σ2(birch::type::Integer(4))));
;
  #line 22 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestChainGaussian.birch"
    birch::handle_assume(this->x(birch::type::Integer(5)), birch::Gaussian(this->x(birch::type::Integer(4)), this->σ2(birch::type::Integer(5))));
;
}

#line 25 "src/test/model/TestChainGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestChainGaussian::forward() {
  #line 25 "src/test/model/TestChainGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestChainGaussian.birch", 25);
  #line 26 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestChainGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(5)));
  #line 27 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestChainGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(5); ++i) {
    #line 28 "src/test/model/TestChainGaussian.birch"
    libbirch_line_(28);
    #line 28 "src/test/model/TestChainGaussian.birch"
    y(i) = this->x(i)->value();
  }
  #line 30 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestChainGaussian.birch"
  return y;
}

#line 33 "src/test/model/TestChainGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestChainGaussian::backward() {
  #line 33 "src/test/model/TestChainGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestChainGaussian.birch", 33);
  #line 34 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestChainGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(5)));
  #line 35 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestChainGaussian.birch"
  for (auto i = birch::type::Integer(0); i <= birch::type::Integer(4); ++i) {
    #line 36 "src/test/model/TestChainGaussian.birch"
    libbirch_line_(36);
    #line 36 "src/test/model/TestChainGaussian.birch"
    libbirch_assert_(!(this->x(birch::type::Integer(5) - i)->hasValue()));
    #line 37 "src/test/model/TestChainGaussian.birch"
    libbirch_line_(37);
    #line 37 "src/test/model/TestChainGaussian.birch"
    y(birch::type::Integer(5) - i) = this->x(birch::type::Integer(5) - i)->value();
  }
  #line 39 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestChainGaussian.birch"
  return y;
}

#line 42 "src/test/model/TestChainGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestChainGaussian::forwardLazy() {
  #line 42 "src/test/model/TestChainGaussian.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestChainGaussian.birch", 42);
  #line 43 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestChainGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(5)));
  #line 44 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestChainGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(5); ++i) {
    #line 45 "src/test/model/TestChainGaussian.birch"
    libbirch_line_(45);
    #line 45 "src/test/model/TestChainGaussian.birch"
    y(i) = this->x(i)->get();
  }
  #line 47 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestChainGaussian.birch"
  return y;
}

#line 50 "src/test/model/TestChainGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestChainGaussian::backwardLazy() {
  #line 50 "src/test/model/TestChainGaussian.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestChainGaussian.birch", 50);
  #line 51 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/test/model/TestChainGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(5)));
  #line 52 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/test/model/TestChainGaussian.birch"
  for (auto i = birch::type::Integer(0); i <= birch::type::Integer(4); ++i) {
    #line 53 "src/test/model/TestChainGaussian.birch"
    libbirch_line_(53);
    #line 53 "src/test/model/TestChainGaussian.birch"
    libbirch_assert_(!(this->x(birch::type::Integer(5) - i)->hasValue()));
    #line 54 "src/test/model/TestChainGaussian.birch"
    libbirch_line_(54);
    #line 54 "src/test/model/TestChainGaussian.birch"
    y(birch::type::Integer(5) - i) = this->x(birch::type::Integer(5) - i)->get();
  }
  #line 56 "src/test/model/TestChainGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/test/model/TestChainGaussian.birch"
  return y;
}

#line 1 "src/test/model/TestChainGaussian.birch"
birch::type::TestChainGaussian* birch::type::make_TestChainGaussian_() {
  #line 1 "src/test/model/TestChainGaussian.birch"
  return new birch::type::TestChainGaussian();
  #line 1 "src/test/model/TestChainGaussian.birch"
}

#line 1 "src/test/model/TestChainMultivariateGaussian.birch"
birch::type::TestChainMultivariateGaussian::TestChainMultivariateGaussian() :
    #line 1 "src/test/model/TestChainMultivariateGaussian.birch"
    base_type_(),
    #line 2 "src/test/model/TestChainMultivariateGaussian.birch"
    x(libbirch::make_array<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,1>>>>(libbirch::make_shape(birch::type::Integer(5)))),
    #line 3 "src/test/model/TestChainMultivariateGaussian.birch"
    μ(libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(3)))),
    #line 4 "src/test/model/TestChainMultivariateGaussian.birch"
    Σ(libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(3), birch::type::Integer(3)))) {
  //
}

#line 6 "src/test/model/TestChainMultivariateGaussian.birch"
void birch::type::TestChainMultivariateGaussian::initialize() {
  #line 6 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestChainMultivariateGaussian.birch", 6);
  #line 7 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/model/TestChainMultivariateGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(3); ++i) {
    #line 8 "src/test/model/TestChainMultivariateGaussian.birch"
    libbirch_line_(8);
    #line 8 "src/test/model/TestChainMultivariateGaussian.birch"
    this->μ(i) = birch::simulate_uniform(-(10.0), 10.0);
    #line 9 "src/test/model/TestChainMultivariateGaussian.birch"
    libbirch_line_(9);
    #line 9 "src/test/model/TestChainMultivariateGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= birch::type::Integer(3); ++j) {
      #line 10 "src/test/model/TestChainMultivariateGaussian.birch"
      libbirch_line_(10);
      #line 10 "src/test/model/TestChainMultivariateGaussian.birch"
      this->Σ(i, j) = birch::simulate_uniform(-(2.0), 2.0);
    }
  }
  #line 13 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestChainMultivariateGaussian.birch"
  this->Σ = this->Σ * birch::transpose(this->Σ) + birch::diagonal(1.0e-2, birch::type::Integer(3));
}

#line 16 "src/test/model/TestChainMultivariateGaussian.birch"
void birch::type::TestChainMultivariateGaussian::simulate() {
  #line 16 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestChainMultivariateGaussian.birch", 16);
  #line 17 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestChainMultivariateGaussian.birch"
    birch::handle_assume(this->x(birch::type::Integer(1)), birch::Gaussian(this->μ, this->Σ));
;
  #line 18 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestChainMultivariateGaussian.birch"
    birch::handle_assume(this->x(birch::type::Integer(2)), birch::Gaussian(this->x(birch::type::Integer(1)), this->Σ));
;
  #line 19 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestChainMultivariateGaussian.birch"
    birch::handle_assume(this->x(birch::type::Integer(3)), birch::Gaussian(this->x(birch::type::Integer(2)), this->Σ));
;
  #line 20 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestChainMultivariateGaussian.birch"
    birch::handle_assume(this->x(birch::type::Integer(4)), birch::Gaussian(this->x(birch::type::Integer(3)), this->Σ));
;
  #line 21 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestChainMultivariateGaussian.birch"
    birch::handle_assume(this->x(birch::type::Integer(5)), birch::Gaussian(this->x(birch::type::Integer(4)), this->Σ));
;
}

#line 24 "src/test/model/TestChainMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestChainMultivariateGaussian::forward() {
  #line 24 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestChainMultivariateGaussian.birch", 24);
  #line 25 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(15)));
  #line 26 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestChainMultivariateGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(5); ++i) {
    #line 27 "src/test/model/TestChainMultivariateGaussian.birch"
    libbirch_line_(27);
    #line 27 "src/test/model/TestChainMultivariateGaussian.birch"
    y(libbirch::make_range((i - birch::type::Integer(1)) * birch::type::Integer(3) + birch::type::Integer(1), i * birch::type::Integer(3))) = this->x(i)->value();
  }
  #line 29 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestChainMultivariateGaussian.birch"
  return y;
}

#line 32 "src/test/model/TestChainMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestChainMultivariateGaussian::backward() {
  #line 32 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestChainMultivariateGaussian.birch", 32);
  #line 33 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(15)));
  #line 34 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestChainMultivariateGaussian.birch"
  for (auto i = birch::type::Integer(0); i <= birch::type::Integer(4); ++i) {
    #line 35 "src/test/model/TestChainMultivariateGaussian.birch"
    libbirch_line_(35);
    #line 35 "src/test/model/TestChainMultivariateGaussian.birch"
    libbirch_assert_(!(this->x(birch::type::Integer(5) - i)->hasValue()));
    #line 36 "src/test/model/TestChainMultivariateGaussian.birch"
    libbirch_line_(36);
    #line 36 "src/test/model/TestChainMultivariateGaussian.birch"
    y(libbirch::make_range((birch::type::Integer(4) - i) * birch::type::Integer(3) + birch::type::Integer(1), (birch::type::Integer(5) - i) * birch::type::Integer(3))) = this->x(birch::type::Integer(5) - i)->value();
  }
  #line 38 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestChainMultivariateGaussian.birch"
  return y;
}

#line 41 "src/test/model/TestChainMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestChainMultivariateGaussian::forwardLazy() {
  #line 41 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestChainMultivariateGaussian.birch", 41);
  #line 42 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(15)));
  #line 43 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestChainMultivariateGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(5); ++i) {
    #line 44 "src/test/model/TestChainMultivariateGaussian.birch"
    libbirch_line_(44);
    #line 44 "src/test/model/TestChainMultivariateGaussian.birch"
    y(libbirch::make_range((i - birch::type::Integer(1)) * birch::type::Integer(3) + birch::type::Integer(1), i * birch::type::Integer(3))) = this->x(i)->get();
  }
  #line 46 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestChainMultivariateGaussian.birch"
  return y;
}

#line 49 "src/test/model/TestChainMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestChainMultivariateGaussian::backwardLazy() {
  #line 49 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestChainMultivariateGaussian.birch", 49);
  #line 50 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(50);
  #line 50 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(15)));
  #line 51 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/test/model/TestChainMultivariateGaussian.birch"
  for (auto i = birch::type::Integer(0); i <= birch::type::Integer(4); ++i) {
    #line 52 "src/test/model/TestChainMultivariateGaussian.birch"
    libbirch_line_(52);
    #line 52 "src/test/model/TestChainMultivariateGaussian.birch"
    libbirch_assert_(!(this->x(birch::type::Integer(5) - i)->hasValue()));
    #line 53 "src/test/model/TestChainMultivariateGaussian.birch"
    libbirch_line_(53);
    #line 53 "src/test/model/TestChainMultivariateGaussian.birch"
    y(libbirch::make_range((birch::type::Integer(4) - i) * birch::type::Integer(3) + birch::type::Integer(1), (birch::type::Integer(5) - i) * birch::type::Integer(3))) = this->x(birch::type::Integer(5) - i)->get();
  }
  #line 55 "src/test/model/TestChainMultivariateGaussian.birch"
  libbirch_line_(55);
  #line 55 "src/test/model/TestChainMultivariateGaussian.birch"
  return y;
}

#line 1 "src/test/model/TestChainMultivariateGaussian.birch"
birch::type::TestChainMultivariateGaussian* birch::type::make_TestChainMultivariateGaussian_() {
  #line 1 "src/test/model/TestChainMultivariateGaussian.birch"
  return new birch::type::TestChainMultivariateGaussian();
  #line 1 "src/test/model/TestChainMultivariateGaussian.birch"
}

#line 1 "src/test/model/TestDirichletCategorical.birch"
birch::type::TestDirichletCategorical::TestDirichletCategorical() :
    #line 1 "src/test/model/TestDirichletCategorical.birch"
    base_type_(),
    #line 2 "src/test/model/TestDirichletCategorical.birch"
    ρ(libbirch::make<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,1>>>>()),
    #line 3 "src/test/model/TestDirichletCategorical.birch"
    x(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Integer>>>()),
    #line 4 "src/test/model/TestDirichletCategorical.birch"
    α(libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(5)))) {
  //
}

#line 6 "src/test/model/TestDirichletCategorical.birch"
void birch::type::TestDirichletCategorical::initialize() {
  #line 6 "src/test/model/TestDirichletCategorical.birch"
  libbirch_function_("initialize", "src/test/model/TestDirichletCategorical.birch", 6);
  #line 7 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(7);
  #line 7 "src/test/model/TestDirichletCategorical.birch"
  for (auto n = birch::type::Integer(1); n <= birch::type::Integer(5); ++n) {
    #line 8 "src/test/model/TestDirichletCategorical.birch"
    libbirch_line_(8);
    #line 8 "src/test/model/TestDirichletCategorical.birch"
    this->α(n) = birch::simulate_uniform(1.0, 10.0);
  }
}

#line 12 "src/test/model/TestDirichletCategorical.birch"
void birch::type::TestDirichletCategorical::simulate() {
  #line 12 "src/test/model/TestDirichletCategorical.birch"
  libbirch_function_("simulate", "src/test/model/TestDirichletCategorical.birch", 12);
  #line 13 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestDirichletCategorical.birch"
    birch::handle_assume(this->ρ, birch::Dirichlet(this->α));
;
  #line 14 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestDirichletCategorical.birch"
    birch::handle_assume(this->x, birch::Categorical(this->ρ));
;
}

#line 17 "src/test/model/TestDirichletCategorical.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestDirichletCategorical::forward() {
  #line 17 "src/test/model/TestDirichletCategorical.birch"
  libbirch_function_("forward", "src/test/model/TestDirichletCategorical.birch", 17);
  #line 18 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestDirichletCategorical.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(6)));
  #line 19 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestDirichletCategorical.birch"
  y(libbirch::make_range(birch::type::Integer(1), birch::type::Integer(5))) = this->ρ->value();
  #line 20 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestDirichletCategorical.birch"
  y(birch::type::Integer(6)) = this->x->value();
  #line 21 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestDirichletCategorical.birch"
  return y;
}

#line 24 "src/test/model/TestDirichletCategorical.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestDirichletCategorical::backward() {
  #line 24 "src/test/model/TestDirichletCategorical.birch"
  libbirch_function_("backward", "src/test/model/TestDirichletCategorical.birch", 24);
  #line 25 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestDirichletCategorical.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(6)));
  #line 26 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestDirichletCategorical.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 27 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestDirichletCategorical.birch"
  y(birch::type::Integer(6)) = this->x->value();
  #line 28 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestDirichletCategorical.birch"
  libbirch_assert_(!(this->ρ->hasValue()));
  #line 29 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestDirichletCategorical.birch"
  y(libbirch::make_range(birch::type::Integer(1), birch::type::Integer(5))) = this->ρ->value();
  #line 30 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestDirichletCategorical.birch"
  return y;
}

#line 33 "src/test/model/TestDirichletCategorical.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestDirichletCategorical::forwardLazy() {
  #line 33 "src/test/model/TestDirichletCategorical.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestDirichletCategorical.birch", 33);
  #line 34 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestDirichletCategorical.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(6)));
  #line 35 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestDirichletCategorical.birch"
  y(libbirch::make_range(birch::type::Integer(1), birch::type::Integer(5))) = this->ρ->get();
  #line 36 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestDirichletCategorical.birch"
  y(birch::type::Integer(6)) = this->x->get();
  #line 37 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestDirichletCategorical.birch"
  return y;
}

#line 40 "src/test/model/TestDirichletCategorical.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestDirichletCategorical::backwardLazy() {
  #line 40 "src/test/model/TestDirichletCategorical.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestDirichletCategorical.birch", 40);
  #line 41 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestDirichletCategorical.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(6)));
  #line 42 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestDirichletCategorical.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 43 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestDirichletCategorical.birch"
  y(birch::type::Integer(6)) = this->x->get();
  #line 44 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestDirichletCategorical.birch"
  libbirch_assert_(!(this->ρ->hasValue()));
  #line 45 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestDirichletCategorical.birch"
  y(libbirch::make_range(birch::type::Integer(1), birch::type::Integer(5))) = this->ρ->get();
  #line 46 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestDirichletCategorical.birch"
  return y;
}

#line 49 "src/test/model/TestDirichletCategorical.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Integer>> birch::type::TestDirichletCategorical::marginal() {
  #line 49 "src/test/model/TestDirichletCategorical.birch"
  libbirch_function_("marginal", "src/test/model/TestDirichletCategorical.birch", 49);
  #line 50 "src/test/model/TestDirichletCategorical.birch"
  libbirch_line_(50);
  #line 50 "src/test/model/TestDirichletCategorical.birch"
  return this->x->distribution().value();
}

#line 1 "src/test/model/TestDirichletCategorical.birch"
birch::type::TestDirichletCategorical* birch::type::make_TestDirichletCategorical_() {
  #line 1 "src/test/model/TestDirichletCategorical.birch"
  return new birch::type::TestDirichletCategorical();
  #line 1 "src/test/model/TestDirichletCategorical.birch"
}

#line 1 "src/test/model/TestDirichletMultinomial.birch"
birch::type::TestDirichletMultinomial::TestDirichletMultinomial() :
    #line 1 "src/test/model/TestDirichletMultinomial.birch"
    base_type_(),
    #line 2 "src/test/model/TestDirichletMultinomial.birch"
    n(libbirch::make<birch::type::Integer>()),
    #line 3 "src/test/model/TestDirichletMultinomial.birch"
    α(libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(5)))),
    #line 4 "src/test/model/TestDirichletMultinomial.birch"
    ρ(libbirch::make<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,1>>>>()),
    #line 5 "src/test/model/TestDirichletMultinomial.birch"
    x(libbirch::make<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Integer,1>>>>()) {
  //
}

#line 7 "src/test/model/TestDirichletMultinomial.birch"
void birch::type::TestDirichletMultinomial::initialize() {
  #line 7 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_function_("initialize", "src/test/model/TestDirichletMultinomial.birch", 7);
  #line 8 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(8);
  #line 8 "src/test/model/TestDirichletMultinomial.birch"
  this->n = birch::simulate_uniform_int(birch::type::Integer(100), birch::type::Integer(500));
  #line 9 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(9);
  #line 9 "src/test/model/TestDirichletMultinomial.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(5); ++i) {
    #line 10 "src/test/model/TestDirichletMultinomial.birch"
    libbirch_line_(10);
    #line 10 "src/test/model/TestDirichletMultinomial.birch"
    this->α(i) = birch::simulate_uniform(1.0, 10.0);
  }
}

#line 14 "src/test/model/TestDirichletMultinomial.birch"
void birch::type::TestDirichletMultinomial::simulate() {
  #line 14 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_function_("simulate", "src/test/model/TestDirichletMultinomial.birch", 14);
  #line 15 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestDirichletMultinomial.birch"
    birch::handle_assume(this->ρ, birch::Dirichlet(this->α));
;
  #line 16 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestDirichletMultinomial.birch"
    birch::handle_assume(this->x, birch::Multinomial(this->n, this->ρ));
;
}

#line 19 "src/test/model/TestDirichletMultinomial.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestDirichletMultinomial::forward() {
  #line 19 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_function_("forward", "src/test/model/TestDirichletMultinomial.birch", 19);
  #line 20 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestDirichletMultinomial.birch"
  birch::type::Integer D = birch::length(this->α);
  #line 21 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestDirichletMultinomial.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2) * D));
  #line 22 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestDirichletMultinomial.birch"
  y(libbirch::make_range(birch::type::Integer(1), D)) = this->ρ->value();
  #line 23 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestDirichletMultinomial.birch"
  y(libbirch::make_range(D + birch::type::Integer(1), birch::type::Integer(2) * D)) = this->x->value();
  #line 24 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestDirichletMultinomial.birch"
  return y;
}

#line 27 "src/test/model/TestDirichletMultinomial.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestDirichletMultinomial::backward() {
  #line 27 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_function_("backward", "src/test/model/TestDirichletMultinomial.birch", 27);
  #line 28 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestDirichletMultinomial.birch"
  birch::type::Integer D = birch::length(this->α);
  #line 29 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestDirichletMultinomial.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2) * D));
  #line 30 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 31 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestDirichletMultinomial.birch"
  y(libbirch::make_range(D + birch::type::Integer(1), birch::type::Integer(2) * D)) = this->x->value();
  #line 32 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_assert_(!(this->ρ->hasValue()));
  #line 33 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestDirichletMultinomial.birch"
  y(libbirch::make_range(birch::type::Integer(1), D)) = this->ρ->value();
  #line 34 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestDirichletMultinomial.birch"
  return y;
}

#line 37 "src/test/model/TestDirichletMultinomial.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestDirichletMultinomial::forwardLazy() {
  #line 37 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestDirichletMultinomial.birch", 37);
  #line 38 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestDirichletMultinomial.birch"
  birch::type::Integer D = birch::length(this->α);
  #line 39 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestDirichletMultinomial.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2) * D));
  #line 40 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestDirichletMultinomial.birch"
  y(libbirch::make_range(birch::type::Integer(1), D)) = this->ρ->get();
  #line 41 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestDirichletMultinomial.birch"
  y(libbirch::make_range(D + birch::type::Integer(1), birch::type::Integer(2) * D)) = this->x->get();
  #line 42 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestDirichletMultinomial.birch"
  return y;
}

#line 45 "src/test/model/TestDirichletMultinomial.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestDirichletMultinomial::backwardLazy() {
  #line 45 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestDirichletMultinomial.birch", 45);
  #line 46 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestDirichletMultinomial.birch"
  birch::type::Integer D = birch::length(this->α);
  #line 47 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestDirichletMultinomial.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2) * D));
  #line 48 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(48);
  #line 48 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 49 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(49);
  #line 49 "src/test/model/TestDirichletMultinomial.birch"
  y(libbirch::make_range(D + birch::type::Integer(1), birch::type::Integer(2) * D)) = this->x->get();
  #line 50 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(50);
  #line 50 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_assert_(!(this->ρ->hasValue()));
  #line 51 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(51);
  #line 51 "src/test/model/TestDirichletMultinomial.birch"
  y(libbirch::make_range(birch::type::Integer(1), D)) = this->ρ->get();
  #line 52 "src/test/model/TestDirichletMultinomial.birch"
  libbirch_line_(52);
  #line 52 "src/test/model/TestDirichletMultinomial.birch"
  return y;
}

#line 1 "src/test/model/TestDirichletMultinomial.birch"
birch::type::TestDirichletMultinomial* birch::type::make_TestDirichletMultinomial_() {
  #line 1 "src/test/model/TestDirichletMultinomial.birch"
  return new birch::type::TestDirichletMultinomial();
  #line 1 "src/test/model/TestDirichletMultinomial.birch"
}

#line 1 "src/test/model/TestGammaExponential.birch"
birch::type::TestGammaExponential::TestGammaExponential() :
    #line 1 "src/test/model/TestGammaExponential.birch"
    base_type_(),
    #line 2 "src/test/model/TestGammaExponential.birch"
    k(libbirch::make<birch::type::Real>()),
    #line 3 "src/test/model/TestGammaExponential.birch"
    θ(libbirch::make<birch::type::Real>()),
    #line 4 "src/test/model/TestGammaExponential.birch"
    λ(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 5 "src/test/model/TestGammaExponential.birch"
    x(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()) {
  //
}

#line 7 "src/test/model/TestGammaExponential.birch"
void birch::type::TestGammaExponential::initialize() {
  #line 7 "src/test/model/TestGammaExponential.birch"
  libbirch_function_("initialize", "src/test/model/TestGammaExponential.birch", 7);
  #line 8 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(8);
  #line 8 "src/test/model/TestGammaExponential.birch"
  this->k = birch::simulate_uniform(2.1, 10.0);
  #line 9 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(9);
  #line 9 "src/test/model/TestGammaExponential.birch"
  this->θ = birch::simulate_uniform(0.1, 2.0);
}

#line 12 "src/test/model/TestGammaExponential.birch"
void birch::type::TestGammaExponential::simulate() {
  #line 12 "src/test/model/TestGammaExponential.birch"
  libbirch_function_("simulate", "src/test/model/TestGammaExponential.birch", 12);
  #line 13 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestGammaExponential.birch"
    birch::handle_assume(this->λ, birch::Gamma(this->k, this->θ));
;
  #line 14 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestGammaExponential.birch"
    birch::handle_assume(this->x, birch::Exponential(this->λ));
;
}

#line 17 "src/test/model/TestGammaExponential.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestGammaExponential::forward() {
  #line 17 "src/test/model/TestGammaExponential.birch"
  libbirch_function_("forward", "src/test/model/TestGammaExponential.birch", 17);
  #line 18 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestGammaExponential.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 19 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestGammaExponential.birch"
  y(birch::type::Integer(1)) = this->λ->value();
  #line 20 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestGammaExponential.birch"
  y(birch::type::Integer(2)) = this->x->value();
  #line 21 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestGammaExponential.birch"
  return y;
}

#line 24 "src/test/model/TestGammaExponential.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestGammaExponential::backward() {
  #line 24 "src/test/model/TestGammaExponential.birch"
  libbirch_function_("backward", "src/test/model/TestGammaExponential.birch", 24);
  #line 25 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestGammaExponential.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 26 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestGammaExponential.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 27 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestGammaExponential.birch"
  y(birch::type::Integer(2)) = this->x->value();
  #line 28 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestGammaExponential.birch"
  libbirch_assert_(!(this->λ->hasValue()));
  #line 29 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestGammaExponential.birch"
  y(birch::type::Integer(1)) = this->λ->value();
  #line 30 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestGammaExponential.birch"
  return y;
}

#line 33 "src/test/model/TestGammaExponential.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestGammaExponential::forwardLazy() {
  #line 33 "src/test/model/TestGammaExponential.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestGammaExponential.birch", 33);
  #line 34 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestGammaExponential.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 35 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestGammaExponential.birch"
  y(birch::type::Integer(1)) = this->λ->get();
  #line 36 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestGammaExponential.birch"
  y(birch::type::Integer(2)) = this->x->get();
  #line 37 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestGammaExponential.birch"
  return y;
}

#line 40 "src/test/model/TestGammaExponential.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestGammaExponential::backwardLazy() {
  #line 40 "src/test/model/TestGammaExponential.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestGammaExponential.birch", 40);
  #line 41 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestGammaExponential.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 42 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestGammaExponential.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 43 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestGammaExponential.birch"
  y(birch::type::Integer(2)) = this->x->get();
  #line 44 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestGammaExponential.birch"
  libbirch_assert_(!(this->λ->hasValue()));
  #line 45 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestGammaExponential.birch"
  y(birch::type::Integer(1)) = this->λ->get();
  #line 46 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestGammaExponential.birch"
  return y;
}

#line 49 "src/test/model/TestGammaExponential.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::type::TestGammaExponential::marginal() {
  #line 49 "src/test/model/TestGammaExponential.birch"
  libbirch_function_("marginal", "src/test/model/TestGammaExponential.birch", 49);
  #line 50 "src/test/model/TestGammaExponential.birch"
  libbirch_line_(50);
  #line 50 "src/test/model/TestGammaExponential.birch"
  return this->x->distribution().value();
}

#line 1 "src/test/model/TestGammaExponential.birch"
birch::type::TestGammaExponential* birch::type::make_TestGammaExponential_() {
  #line 1 "src/test/model/TestGammaExponential.birch"
  return new birch::type::TestGammaExponential();
  #line 1 "src/test/model/TestGammaExponential.birch"
}

#line 1 "src/test/model/TestGammaPoisson.birch"
birch::type::TestGammaPoisson::TestGammaPoisson() :
    #line 1 "src/test/model/TestGammaPoisson.birch"
    base_type_(),
    #line 2 "src/test/model/TestGammaPoisson.birch"
    λ(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 3 "src/test/model/TestGammaPoisson.birch"
    x(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Integer>>>()),
    #line 4 "src/test/model/TestGammaPoisson.birch"
    k(libbirch::make<birch::type::Real>()),
    #line 5 "src/test/model/TestGammaPoisson.birch"
    θ(libbirch::make<birch::type::Real>()) {
  //
}

#line 7 "src/test/model/TestGammaPoisson.birch"
void birch::type::TestGammaPoisson::initialize() {
  #line 7 "src/test/model/TestGammaPoisson.birch"
  libbirch_function_("initialize", "src/test/model/TestGammaPoisson.birch", 7);
  #line 8 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(8);
  #line 8 "src/test/model/TestGammaPoisson.birch"
  this->k = birch::simulate_uniform_int(birch::type::Integer(1), birch::type::Integer(10));
  #line 9 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(9);
  #line 9 "src/test/model/TestGammaPoisson.birch"
  this->θ = birch::simulate_uniform(0.1, 10.0);
}

#line 12 "src/test/model/TestGammaPoisson.birch"
void birch::type::TestGammaPoisson::simulate() {
  #line 12 "src/test/model/TestGammaPoisson.birch"
  libbirch_function_("simulate", "src/test/model/TestGammaPoisson.birch", 12);
  #line 13 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestGammaPoisson.birch"
    birch::handle_assume(this->λ, birch::Gamma(this->k, this->θ));
;
  #line 14 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestGammaPoisson.birch"
    birch::handle_assume(this->x, birch::Poisson(this->λ));
;
}

#line 17 "src/test/model/TestGammaPoisson.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestGammaPoisson::forward() {
  #line 17 "src/test/model/TestGammaPoisson.birch"
  libbirch_function_("forward", "src/test/model/TestGammaPoisson.birch", 17);
  #line 18 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestGammaPoisson.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 19 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestGammaPoisson.birch"
  y(birch::type::Integer(1)) = this->λ->value();
  #line 20 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestGammaPoisson.birch"
  y(birch::type::Integer(2)) = this->x->value();
  #line 21 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestGammaPoisson.birch"
  return y;
}

#line 24 "src/test/model/TestGammaPoisson.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestGammaPoisson::backward() {
  #line 24 "src/test/model/TestGammaPoisson.birch"
  libbirch_function_("backward", "src/test/model/TestGammaPoisson.birch", 24);
  #line 25 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestGammaPoisson.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 26 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestGammaPoisson.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 27 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestGammaPoisson.birch"
  y(birch::type::Integer(2)) = this->x->value();
  #line 28 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestGammaPoisson.birch"
  libbirch_assert_(!(this->λ->hasValue()));
  #line 29 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestGammaPoisson.birch"
  y(birch::type::Integer(1)) = this->λ->value();
  #line 30 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestGammaPoisson.birch"
  return y;
}

#line 33 "src/test/model/TestGammaPoisson.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestGammaPoisson::forwardLazy() {
  #line 33 "src/test/model/TestGammaPoisson.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestGammaPoisson.birch", 33);
  #line 34 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestGammaPoisson.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 35 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestGammaPoisson.birch"
  y(birch::type::Integer(1)) = this->λ->get();
  #line 36 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestGammaPoisson.birch"
  y(birch::type::Integer(2)) = this->x->get();
  #line 37 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestGammaPoisson.birch"
  return y;
}

#line 40 "src/test/model/TestGammaPoisson.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestGammaPoisson::backwardLazy() {
  #line 40 "src/test/model/TestGammaPoisson.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestGammaPoisson.birch", 40);
  #line 41 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestGammaPoisson.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 42 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestGammaPoisson.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 43 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestGammaPoisson.birch"
  y(birch::type::Integer(2)) = this->x->get();
  #line 44 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestGammaPoisson.birch"
  libbirch_assert_(!(this->λ->hasValue()));
  #line 45 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestGammaPoisson.birch"
  y(birch::type::Integer(1)) = this->λ->get();
  #line 46 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestGammaPoisson.birch"
  return y;
}

#line 49 "src/test/model/TestGammaPoisson.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Integer>> birch::type::TestGammaPoisson::marginal() {
  #line 49 "src/test/model/TestGammaPoisson.birch"
  libbirch_function_("marginal", "src/test/model/TestGammaPoisson.birch", 49);
  #line 50 "src/test/model/TestGammaPoisson.birch"
  libbirch_line_(50);
  #line 50 "src/test/model/TestGammaPoisson.birch"
  return this->x->distribution().value();
}

#line 1 "src/test/model/TestGammaPoisson.birch"
birch::type::TestGammaPoisson* birch::type::make_TestGammaPoisson_() {
  #line 1 "src/test/model/TestGammaPoisson.birch"
  return new birch::type::TestGammaPoisson();
  #line 1 "src/test/model/TestGammaPoisson.birch"
}

#line 1 "src/test/model/TestGaussianGaussian.birch"
birch::type::TestGaussianGaussian::TestGaussianGaussian() :
    #line 1 "src/test/model/TestGaussianGaussian.birch"
    base_type_(),
    #line 2 "src/test/model/TestGaussianGaussian.birch"
    μ_1(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 3 "src/test/model/TestGaussianGaussian.birch"
    x(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 4 "src/test/model/TestGaussianGaussian.birch"
    μ_0(libbirch::make<birch::type::Real>()),
    #line 5 "src/test/model/TestGaussianGaussian.birch"
    σ2_0(libbirch::make<birch::type::Real>()),
    #line 6 "src/test/model/TestGaussianGaussian.birch"
    σ2_1(libbirch::make<birch::type::Real>()) {
  //
}

#line 8 "src/test/model/TestGaussianGaussian.birch"
void birch::type::TestGaussianGaussian::initialize() {
  #line 8 "src/test/model/TestGaussianGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestGaussianGaussian.birch", 8);
  #line 9 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(9);
  #line 9 "src/test/model/TestGaussianGaussian.birch"
  this->μ_0 = birch::simulate_uniform(-(10.0), 10.0);
  #line 10 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(10);
  #line 10 "src/test/model/TestGaussianGaussian.birch"
  this->σ2_0 = birch::simulate_uniform(0.1, 10.0);
  #line 11 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(11);
  #line 11 "src/test/model/TestGaussianGaussian.birch"
  this->σ2_1 = birch::simulate_uniform(0.1, 10.0);
}

#line 14 "src/test/model/TestGaussianGaussian.birch"
void birch::type::TestGaussianGaussian::simulate() {
  #line 14 "src/test/model/TestGaussianGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestGaussianGaussian.birch", 14);
  #line 15 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestGaussianGaussian.birch"
    birch::handle_assume(this->μ_1, birch::Gaussian(this->μ_0, this->σ2_0));
;
  #line 16 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestGaussianGaussian.birch"
    birch::handle_assume(this->x, birch::Gaussian(this->μ_1, this->σ2_1));
;
}

#line 19 "src/test/model/TestGaussianGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestGaussianGaussian::forward() {
  #line 19 "src/test/model/TestGaussianGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestGaussianGaussian.birch", 19);
  #line 20 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestGaussianGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 21 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestGaussianGaussian.birch"
  y(birch::type::Integer(1)) = this->μ_1->value();
  #line 22 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestGaussianGaussian.birch"
  y(birch::type::Integer(2)) = this->x->value();
  #line 23 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestGaussianGaussian.birch"
  return y;
}

#line 26 "src/test/model/TestGaussianGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestGaussianGaussian::backward() {
  #line 26 "src/test/model/TestGaussianGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestGaussianGaussian.birch", 26);
  #line 27 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestGaussianGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 28 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestGaussianGaussian.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 29 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestGaussianGaussian.birch"
  y(birch::type::Integer(2)) = this->x->value();
  #line 30 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestGaussianGaussian.birch"
  libbirch_assert_(!(this->μ_1->hasValue()));
  #line 31 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestGaussianGaussian.birch"
  y(birch::type::Integer(1)) = this->μ_1->value();
  #line 32 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestGaussianGaussian.birch"
  return y;
}

#line 35 "src/test/model/TestGaussianGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestGaussianGaussian::forwardLazy() {
  #line 35 "src/test/model/TestGaussianGaussian.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestGaussianGaussian.birch", 35);
  #line 36 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestGaussianGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 37 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestGaussianGaussian.birch"
  y(birch::type::Integer(1)) = this->μ_1->get();
  #line 38 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestGaussianGaussian.birch"
  y(birch::type::Integer(2)) = this->x->get();
  #line 39 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestGaussianGaussian.birch"
  return y;
}

#line 42 "src/test/model/TestGaussianGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestGaussianGaussian::backwardLazy() {
  #line 42 "src/test/model/TestGaussianGaussian.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestGaussianGaussian.birch", 42);
  #line 43 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestGaussianGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 44 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestGaussianGaussian.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 45 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestGaussianGaussian.birch"
  y(birch::type::Integer(2)) = this->x->get();
  #line 46 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestGaussianGaussian.birch"
  libbirch_assert_(!(this->μ_1->hasValue()));
  #line 47 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestGaussianGaussian.birch"
  y(birch::type::Integer(1)) = this->μ_1->get();
  #line 48 "src/test/model/TestGaussianGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/test/model/TestGaussianGaussian.birch"
  return y;
}

#line 1 "src/test/model/TestGaussianGaussian.birch"
birch::type::TestGaussianGaussian* birch::type::make_TestGaussianGaussian_() {
  #line 1 "src/test/model/TestGaussianGaussian.birch"
  return new birch::type::TestGaussianGaussian();
  #line 1 "src/test/model/TestGaussianGaussian.birch"
}

#line 1 "src/test/model/TestInverseGammaGamma.birch"
birch::type::TestInverseGammaGamma::TestInverseGammaGamma() :
    #line 1 "src/test/model/TestInverseGammaGamma.birch"
    base_type_(),
    #line 2 "src/test/model/TestInverseGammaGamma.birch"
    θ(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 3 "src/test/model/TestInverseGammaGamma.birch"
    x(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 4 "src/test/model/TestInverseGammaGamma.birch"
    k(libbirch::make<birch::type::Real>()),
    #line 5 "src/test/model/TestInverseGammaGamma.birch"
    α(libbirch::make<birch::type::Real>()),
    #line 6 "src/test/model/TestInverseGammaGamma.birch"
    β(libbirch::make<birch::type::Real>()) {
  //
}

#line 8 "src/test/model/TestInverseGammaGamma.birch"
void birch::type::TestInverseGammaGamma::initialize() {
  #line 8 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_function_("initialize", "src/test/model/TestInverseGammaGamma.birch", 8);
  #line 9 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(9);
  #line 9 "src/test/model/TestInverseGammaGamma.birch"
  this->k = birch::simulate_uniform(1.0, 10.0);
  #line 10 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(10);
  #line 10 "src/test/model/TestInverseGammaGamma.birch"
  this->α = birch::simulate_uniform(2.0, 10.0);
  #line 11 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(11);
  #line 11 "src/test/model/TestInverseGammaGamma.birch"
  this->β = birch::simulate_uniform(0.1, 10.0);
}

#line 14 "src/test/model/TestInverseGammaGamma.birch"
void birch::type::TestInverseGammaGamma::simulate() {
  #line 14 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_function_("simulate", "src/test/model/TestInverseGammaGamma.birch", 14);
  #line 15 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestInverseGammaGamma.birch"
    birch::handle_assume(this->θ, birch::InverseGamma(this->α, this->β));
;
  #line 16 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestInverseGammaGamma.birch"
    birch::handle_assume(this->x, birch::Gamma(this->k, this->θ));
;
}

#line 19 "src/test/model/TestInverseGammaGamma.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestInverseGammaGamma::forward() {
  #line 19 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_function_("forward", "src/test/model/TestInverseGammaGamma.birch", 19);
  #line 20 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestInverseGammaGamma.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 21 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestInverseGammaGamma.birch"
  y(birch::type::Integer(1)) = this->θ->value();
  #line 22 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestInverseGammaGamma.birch"
  y(birch::type::Integer(2)) = this->x->value();
  #line 23 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestInverseGammaGamma.birch"
  return y;
}

#line 26 "src/test/model/TestInverseGammaGamma.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestInverseGammaGamma::backward() {
  #line 26 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_function_("backward", "src/test/model/TestInverseGammaGamma.birch", 26);
  #line 27 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestInverseGammaGamma.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 28 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 29 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestInverseGammaGamma.birch"
  y(birch::type::Integer(2)) = this->x->value();
  #line 30 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_assert_(!(this->θ->hasValue()));
  #line 31 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestInverseGammaGamma.birch"
  y(birch::type::Integer(1)) = this->θ->value();
  #line 32 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestInverseGammaGamma.birch"
  return y;
}

#line 35 "src/test/model/TestInverseGammaGamma.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestInverseGammaGamma::forwardLazy() {
  #line 35 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestInverseGammaGamma.birch", 35);
  #line 36 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestInverseGammaGamma.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 37 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestInverseGammaGamma.birch"
  y(birch::type::Integer(1)) = this->θ->get();
  #line 38 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestInverseGammaGamma.birch"
  y(birch::type::Integer(2)) = this->x->get();
  #line 39 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestInverseGammaGamma.birch"
  return y;
}

#line 42 "src/test/model/TestInverseGammaGamma.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestInverseGammaGamma::backwardLazy() {
  #line 42 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestInverseGammaGamma.birch", 42);
  #line 43 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestInverseGammaGamma.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 44 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 45 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestInverseGammaGamma.birch"
  y(birch::type::Integer(2)) = this->x->get();
  #line 46 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_assert_(!(this->θ->hasValue()));
  #line 47 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestInverseGammaGamma.birch"
  y(birch::type::Integer(1)) = this->θ->get();
  #line 48 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(48);
  #line 48 "src/test/model/TestInverseGammaGamma.birch"
  return y;
}

#line 51 "src/test/model/TestInverseGammaGamma.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::type::TestInverseGammaGamma::marginal() {
  #line 51 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_function_("marginal", "src/test/model/TestInverseGammaGamma.birch", 51);
  #line 52 "src/test/model/TestInverseGammaGamma.birch"
  libbirch_line_(52);
  #line 52 "src/test/model/TestInverseGammaGamma.birch"
  return this->x->distribution().value();
}

#line 1 "src/test/model/TestInverseGammaGamma.birch"
birch::type::TestInverseGammaGamma* birch::type::make_TestInverseGammaGamma_() {
  #line 1 "src/test/model/TestInverseGammaGamma.birch"
  return new birch::type::TestInverseGammaGamma();
  #line 1 "src/test/model/TestInverseGammaGamma.birch"
}

#line 1 "src/test/model/TestLinearDiscreteDelta.birch"
birch::type::TestLinearDiscreteDelta::TestLinearDiscreteDelta() :
    #line 1 "src/test/model/TestLinearDiscreteDelta.birch"
    base_type_(),
    #line 2 "src/test/model/TestLinearDiscreteDelta.birch"
    ρ(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 3 "src/test/model/TestLinearDiscreteDelta.birch"
    x(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Integer>>>()),
    #line 4 "src/test/model/TestLinearDiscreteDelta.birch"
    y(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Integer>>>()),
    #line 5 "src/test/model/TestLinearDiscreteDelta.birch"
    a(libbirch::make<birch::type::Integer>()),
    #line 6 "src/test/model/TestLinearDiscreteDelta.birch"
    n(libbirch::make<birch::type::Integer>()),
    #line 7 "src/test/model/TestLinearDiscreteDelta.birch"
    α(libbirch::make<birch::type::Real>()),
    #line 8 "src/test/model/TestLinearDiscreteDelta.birch"
    β(libbirch::make<birch::type::Real>()),
    #line 9 "src/test/model/TestLinearDiscreteDelta.birch"
    c(libbirch::make<birch::type::Integer>()),
    #line 10 "src/test/model/TestLinearDiscreteDelta.birch"
    neg(libbirch::make<birch::type::Boolean>()) {
  //
}

#line 12 "src/test/model/TestLinearDiscreteDelta.birch"
void birch::type::TestLinearDiscreteDelta::initialize() {
  #line 12 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_function_("initialize", "src/test/model/TestLinearDiscreteDelta.birch", 12);
  #line 13 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestLinearDiscreteDelta.birch"
  this->a = birch::type::Integer(2) * birch::simulate_uniform_int(birch::type::Integer(0), birch::type::Integer(1)) - birch::type::Integer(1);
  #line 14 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestLinearDiscreteDelta.birch"
  this->n = birch::simulate_uniform_int(birch::type::Integer(1), birch::type::Integer(100));
  #line 15 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestLinearDiscreteDelta.birch"
  this->α = birch::simulate_uniform(0.0, 10.0);
  #line 16 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestLinearDiscreteDelta.birch"
  this->β = birch::simulate_uniform(0.0, 10.0);
  #line 17 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestLinearDiscreteDelta.birch"
  this->c = birch::simulate_uniform_int(birch::type::Integer(0), birch::type::Integer(100));
  #line 18 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestLinearDiscreteDelta.birch"
  this->neg = birch::simulate_bernoulli(0.5);
}

#line 21 "src/test/model/TestLinearDiscreteDelta.birch"
void birch::type::TestLinearDiscreteDelta::simulate() {
  #line 21 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_function_("simulate", "src/test/model/TestLinearDiscreteDelta.birch", 21);
  #line 22 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestLinearDiscreteDelta.birch"
    birch::handle_assume(this->ρ, birch::Beta(this->α, this->β));
;
  #line 23 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestLinearDiscreteDelta.birch"
    birch::handle_assume(this->x, birch::Binomial(this->n, this->ρ));
;
  #line 24 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestLinearDiscreteDelta.birch"
  if (this->neg) {
    #line 25 "src/test/model/TestLinearDiscreteDelta.birch"
    libbirch_line_(25);
    #line 25 "src/test/model/TestLinearDiscreteDelta.birch"
        birch::handle_assume(this->y, birch::Delta(this->a * this->x - this->c));
;
  } else {
    #line 27 "src/test/model/TestLinearDiscreteDelta.birch"
    libbirch_line_(27);
    #line 27 "src/test/model/TestLinearDiscreteDelta.birch"
        birch::handle_assume(this->y, birch::Delta(this->a * this->x + this->c));
;
  }
}

#line 31 "src/test/model/TestLinearDiscreteDelta.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearDiscreteDelta::forward() {
  #line 31 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_function_("forward", "src/test/model/TestLinearDiscreteDelta.birch", 31);
  #line 32 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch::DefaultArray<birch::type::Real,1> z = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 33 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestLinearDiscreteDelta.birch"
  z(birch::type::Integer(1)) = this->ρ->value();
  #line 34 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestLinearDiscreteDelta.birch"
  z(birch::type::Integer(2)) = this->x->value();
  #line 35 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestLinearDiscreteDelta.birch"
  return z;
}

#line 38 "src/test/model/TestLinearDiscreteDelta.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearDiscreteDelta::backward() {
  #line 38 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_function_("backward", "src/test/model/TestLinearDiscreteDelta.birch", 38);
  #line 39 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch::DefaultArray<birch::type::Real,1> z = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 40 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 41 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestLinearDiscreteDelta.birch"
  z(birch::type::Integer(2)) = this->x->value();
  #line 42 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_assert_(!(this->ρ->hasValue()));
  #line 43 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestLinearDiscreteDelta.birch"
  z(birch::type::Integer(1)) = this->ρ->value();
  #line 44 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestLinearDiscreteDelta.birch"
  return z;
}

#line 47 "src/test/model/TestLinearDiscreteDelta.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearDiscreteDelta::forwardLazy() {
  #line 47 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestLinearDiscreteDelta.birch", 47);
  #line 48 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(48);
  #line 48 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch::DefaultArray<birch::type::Real,1> z = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 49 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(49);
  #line 49 "src/test/model/TestLinearDiscreteDelta.birch"
  z(birch::type::Integer(1)) = this->ρ->get();
  #line 50 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(50);
  #line 50 "src/test/model/TestLinearDiscreteDelta.birch"
  z(birch::type::Integer(2)) = this->x->get();
  #line 51 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(51);
  #line 51 "src/test/model/TestLinearDiscreteDelta.birch"
  return z;
}

#line 54 "src/test/model/TestLinearDiscreteDelta.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearDiscreteDelta::backwardLazy() {
  #line 54 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestLinearDiscreteDelta.birch", 54);
  #line 55 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(55);
  #line 55 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch::DefaultArray<birch::type::Real,1> z = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 56 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(56);
  #line 56 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 57 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(57);
  #line 57 "src/test/model/TestLinearDiscreteDelta.birch"
  z(birch::type::Integer(2)) = this->x->get();
  #line 58 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(58);
  #line 58 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_assert_(!(this->ρ->hasValue()));
  #line 59 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(59);
  #line 59 "src/test/model/TestLinearDiscreteDelta.birch"
  z(birch::type::Integer(1)) = this->ρ->get();
  #line 60 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(60);
  #line 60 "src/test/model/TestLinearDiscreteDelta.birch"
  return z;
}

#line 63 "src/test/model/TestLinearDiscreteDelta.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Integer>> birch::type::TestLinearDiscreteDelta::marginal() {
  #line 63 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_function_("marginal", "src/test/model/TestLinearDiscreteDelta.birch", 63);
  #line 64 "src/test/model/TestLinearDiscreteDelta.birch"
  libbirch_line_(64);
  #line 64 "src/test/model/TestLinearDiscreteDelta.birch"
  return this->y->distribution().value();
}

#line 1 "src/test/model/TestLinearDiscreteDelta.birch"
birch::type::TestLinearDiscreteDelta* birch::type::make_TestLinearDiscreteDelta_() {
  #line 1 "src/test/model/TestLinearDiscreteDelta.birch"
  return new birch::type::TestLinearDiscreteDelta();
  #line 1 "src/test/model/TestLinearDiscreteDelta.birch"
}

#line 1 "src/test/model/TestLinearGaussianGaussian.birch"
birch::type::TestLinearGaussianGaussian::TestLinearGaussianGaussian() :
    #line 1 "src/test/model/TestLinearGaussianGaussian.birch"
    base_type_(),
    #line 2 "src/test/model/TestLinearGaussianGaussian.birch"
    μ_1(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 3 "src/test/model/TestLinearGaussianGaussian.birch"
    x(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 4 "src/test/model/TestLinearGaussianGaussian.birch"
    a(libbirch::make<birch::type::Real>()),
    #line 5 "src/test/model/TestLinearGaussianGaussian.birch"
    c(libbirch::make<birch::type::Real>()),
    #line 6 "src/test/model/TestLinearGaussianGaussian.birch"
    μ_0(libbirch::make<birch::type::Real>()),
    #line 7 "src/test/model/TestLinearGaussianGaussian.birch"
    σ2_0(libbirch::make<birch::type::Real>()),
    #line 8 "src/test/model/TestLinearGaussianGaussian.birch"
    σ2_1(libbirch::make<birch::type::Real>()),
    #line 9 "src/test/model/TestLinearGaussianGaussian.birch"
    neg(libbirch::make<birch::type::Boolean>()) {
  //
}

#line 11 "src/test/model/TestLinearGaussianGaussian.birch"
void birch::type::TestLinearGaussianGaussian::initialize() {
  #line 11 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestLinearGaussianGaussian.birch", 11);
  #line 12 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestLinearGaussianGaussian.birch"
  this->a = birch::simulate_uniform(-(2.0), 2.0);
  #line 13 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestLinearGaussianGaussian.birch"
  this->c = birch::simulate_uniform(-(10.0), 10.0);
  #line 14 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestLinearGaussianGaussian.birch"
  this->μ_0 = birch::simulate_uniform(-(10.0), 10.0);
  #line 15 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestLinearGaussianGaussian.birch"
  this->σ2_0 = birch::simulate_uniform(0.1, 2.0);
  #line 16 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestLinearGaussianGaussian.birch"
  this->σ2_1 = birch::simulate_uniform(0.1, 2.0);
  #line 17 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestLinearGaussianGaussian.birch"
  this->neg = birch::simulate_bernoulli(0.5);
}

#line 20 "src/test/model/TestLinearGaussianGaussian.birch"
void birch::type::TestLinearGaussianGaussian::simulate() {
  #line 20 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestLinearGaussianGaussian.birch", 20);
  #line 21 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestLinearGaussianGaussian.birch"
    birch::handle_assume(this->μ_1, birch::Gaussian(this->μ_0, this->σ2_0));
;
  #line 22 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestLinearGaussianGaussian.birch"
  if (this->neg) {
    #line 23 "src/test/model/TestLinearGaussianGaussian.birch"
    libbirch_line_(23);
    #line 23 "src/test/model/TestLinearGaussianGaussian.birch"
        birch::handle_assume(this->x, birch::Gaussian(this->μ_1 / this->a - this->c, this->σ2_1));
;
  } else {
    #line 25 "src/test/model/TestLinearGaussianGaussian.birch"
    libbirch_line_(25);
    #line 25 "src/test/model/TestLinearGaussianGaussian.birch"
        birch::handle_assume(this->x, birch::Gaussian(this->a * this->μ_1 + this->c, this->σ2_1));
;
  }
}

#line 29 "src/test/model/TestLinearGaussianGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearGaussianGaussian::forward() {
  #line 29 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestLinearGaussianGaussian.birch", 29);
  #line 30 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 31 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestLinearGaussianGaussian.birch"
  y(birch::type::Integer(1)) = this->μ_1->value();
  #line 32 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestLinearGaussianGaussian.birch"
  y(birch::type::Integer(2)) = this->x->value();
  #line 33 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestLinearGaussianGaussian.birch"
  return y;
}

#line 36 "src/test/model/TestLinearGaussianGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearGaussianGaussian::backward() {
  #line 36 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestLinearGaussianGaussian.birch", 36);
  #line 37 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 38 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 39 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestLinearGaussianGaussian.birch"
  y(birch::type::Integer(2)) = this->x->value();
  #line 40 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_assert_(!(this->μ_1->hasValue()));
  #line 41 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestLinearGaussianGaussian.birch"
  y(birch::type::Integer(1)) = this->μ_1->value();
  #line 42 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestLinearGaussianGaussian.birch"
  return y;
}

#line 45 "src/test/model/TestLinearGaussianGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearGaussianGaussian::forwardLazy() {
  #line 45 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestLinearGaussianGaussian.birch", 45);
  #line 46 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 47 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestLinearGaussianGaussian.birch"
  y(birch::type::Integer(1)) = this->μ_1->get();
  #line 48 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/test/model/TestLinearGaussianGaussian.birch"
  y(birch::type::Integer(2)) = this->x->get();
  #line 49 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(49);
  #line 49 "src/test/model/TestLinearGaussianGaussian.birch"
  return y;
}

#line 52 "src/test/model/TestLinearGaussianGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearGaussianGaussian::backwardLazy() {
  #line 52 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestLinearGaussianGaussian.birch", 52);
  #line 53 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(53);
  #line 53 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 54 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 55 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(55);
  #line 55 "src/test/model/TestLinearGaussianGaussian.birch"
  y(birch::type::Integer(2)) = this->x->get();
  #line 56 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_assert_(!(this->μ_1->hasValue()));
  #line 57 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(57);
  #line 57 "src/test/model/TestLinearGaussianGaussian.birch"
  y(birch::type::Integer(1)) = this->μ_1->get();
  #line 58 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(58);
  #line 58 "src/test/model/TestLinearGaussianGaussian.birch"
  return y;
}

#line 61 "src/test/model/TestLinearGaussianGaussian.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::type::TestLinearGaussianGaussian::marginal() {
  #line 61 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestLinearGaussianGaussian.birch", 61);
  #line 62 "src/test/model/TestLinearGaussianGaussian.birch"
  libbirch_line_(62);
  #line 62 "src/test/model/TestLinearGaussianGaussian.birch"
  return this->x->distribution().value();
}

#line 1 "src/test/model/TestLinearGaussianGaussian.birch"
birch::type::TestLinearGaussianGaussian* birch::type::make_TestLinearGaussianGaussian_() {
  #line 1 "src/test/model/TestLinearGaussianGaussian.birch"
  return new birch::type::TestLinearGaussianGaussian();
  #line 1 "src/test/model/TestLinearGaussianGaussian.birch"
}

#line 1 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian::TestLinearMatrixNormalInverseWishartMatrixGaussian() :
    #line 1 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    base_type_(),
    #line 2 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    V(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::LLT>>>()),
    #line 3 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    X(libbirch::make<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,2>>>>()),
    #line 4 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    Y(libbirch::make<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,2>>>>()),
    #line 6 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    n(birch::type::Integer(5)),
    #line 7 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    p(birch::type::Integer(2)),
    #line 8 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    A(libbirch::make_array<birch::type::Real>(libbirch::make_shape(n, n))),
    #line 9 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    M(libbirch::make_array<birch::type::Real>(libbirch::make_shape(n, p))),
    #line 10 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    U(libbirch::make_array<birch::type::Real>(libbirch::make_shape(n, n))),
    #line 11 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    C(libbirch::make_array<birch::type::Real>(libbirch::make_shape(n, p))),
    #line 12 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    k(libbirch::make<birch::type::Real>()),
    #line 13 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    Ψ(libbirch::make_array<birch::type::Real>(libbirch::make_shape(p, p))),
    #line 14 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    neg(libbirch::make<birch::type::Boolean>()) {
  //
}

#line 16 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian::initialize() {
  #line 16 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch", 16);
  #line 17 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this->k = this->p + 1.0 + birch::simulate_uniform(0.0, 10.0);
  #line 18 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= this->n; ++i) {
    #line 19 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(19);
    #line 19 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= this->n; ++j) {
      #line 20 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      libbirch_line_(20);
      #line 20 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      this->A(i, j) = birch::simulate_uniform(-(2.0), 2.0);
      #line 21 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      libbirch_line_(21);
      #line 21 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      this->U(i, j) = birch::simulate_uniform(-(2.0), 2.0);
    }
    #line 23 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(23);
    #line 23 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= this->p; ++j) {
      #line 24 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      libbirch_line_(24);
      #line 24 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      this->M(i, j) = birch::simulate_uniform(-(10.0), 10.0);
      #line 25 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      libbirch_line_(25);
      #line 25 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      this->C(i, j) = birch::simulate_uniform(-(10.0), 10.0);
    }
  }
  #line 28 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= this->p; ++i) {
    #line 29 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(29);
    #line 29 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= this->p; ++j) {
      #line 30 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      libbirch_line_(30);
      #line 30 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
      this->Ψ(i, j) = birch::simulate_uniform(-(10.0), 10.0);
    }
  }
  #line 33 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this->U = this->U * birch::transpose(this->U) + birch::diagonal(1.0e-2, this->n);
  #line 34 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this->Ψ = this->Ψ * birch::transpose(this->Ψ) + birch::diagonal(1.0e-2, this->p);
  #line 35 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this->neg = birch::simulate_bernoulli(0.5);
}

#line 38 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian::simulate() {
  #line 38 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch", 38);
  #line 39 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    birch::handle_assume(this->V, birch::InverseWishart(this->Ψ, this->k));
;
  #line 40 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    birch::handle_assume(this->X, birch::Gaussian(this->M, this->U, this->V));
;
  #line 41 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  if (this->neg) {
    #line 42 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(42);
    #line 42 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
        birch::handle_assume(this->Y, birch::Gaussian(this->A * this->X - this->C, this->V));
;
  } else {
    #line 44 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(44);
    #line 44 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
        birch::handle_assume(this->Y, birch::Gaussian(this->A * this->X + this->C, this->V));
;
  }
}

#line 48 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian::forward() {
  #line 48 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch", 48);
  #line 49 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(49);
  #line 49 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this->V->value();
  #line 50 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(50);
  #line 50 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this->X->value();
  #line 51 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this->Y->value();
  #line 52 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return this->vectorize();
}

#line 55 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian::backward() {
  #line 55 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch", 55);
  #line 56 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!(this->Y->hasValue()));
  #line 57 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(57);
  #line 57 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this->Y->value();
  #line 58 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(58);
  #line 58 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!(this->X->hasValue()));
  #line 59 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(59);
  #line 59 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this->X->value();
  #line 60 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(60);
  #line 60 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!(this->V->hasValue()));
  #line 61 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(61);
  #line 61 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this->V->value();
  #line 62 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(62);
  #line 62 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return this->vectorize();
}

#line 65 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian::forwardLazy() {
  #line 65 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch", 65);
  #line 66 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this->V->get();
  #line 67 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(67);
  #line 67 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this->X->get();
  #line 68 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(68);
  #line 68 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this->Y->get();
  #line 69 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(69);
  #line 69 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return this->vectorize();
}

#line 72 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian::backwardLazy() {
  #line 72 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch", 72);
  #line 73 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(73);
  #line 73 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!(this->Y->hasValue()));
  #line 74 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(74);
  #line 74 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this->Y->get();
  #line 75 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(75);
  #line 75 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!(this->X->hasValue()));
  #line 76 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(76);
  #line 76 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this->X->get();
  #line 77 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(77);
  #line 77 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!(this->V->hasValue()));
  #line 78 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(78);
  #line 78 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this->V->get();
  #line 79 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(79);
  #line 79 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return this->vectorize();
}

#line 82 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian::marginal() {
  #line 82 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch", 82);
  #line 83 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(83);
  #line 83 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return this->Y->distribution().value();
}

#line 86 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian::vectorize() {
  #line 86 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("vectorize", "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch", 86);
  #line 87 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(87);
  #line 87 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(this->size()));
  #line 88 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(88);
  #line 88 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  auto k = birch::type::Integer(0);
  #line 89 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(89);
  #line 89 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(this->V); ++i) {
    #line 90 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(90);
    #line 90 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    y(libbirch::make_range(k + birch::type::Integer(1), k + birch::columns(this->V))) = birch::canonical(this->V->value())(i, libbirch::make_range(birch::type::Integer(1), birch::columns(this->V)));
    #line 91 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(91);
    #line 91 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    k = k + birch::columns(this->V);
  }
  #line 93 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(93);
  #line 93 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(this->X); ++i) {
    #line 94 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(94);
    #line 94 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    y(libbirch::make_range(k + birch::type::Integer(1), k + birch::columns(this->X))) = this->X->value()(i, libbirch::make_range(birch::type::Integer(1), birch::columns(this->X)));
    #line 95 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(95);
    #line 95 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    k = k + birch::columns(this->X);
  }
  #line 97 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(97);
  #line 97 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(this->Y); ++i) {
    #line 98 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(98);
    #line 98 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    y(libbirch::make_range(k + birch::type::Integer(1), k + birch::columns(this->Y))) = this->Y->value()(i, libbirch::make_range(birch::type::Integer(1), birch::columns(this->Y)));
    #line 99 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(99);
    #line 99 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
    k = k + birch::columns(this->Y);
  }
  #line 101 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(101);
  #line 101 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return y;
}

#line 104 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Integer birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian::size() {
  #line 104 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("size", "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch", 104);
  #line 105 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(105);
  #line 105 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return this->p * this->p + birch::type::Integer(2) * this->n * this->p;
}

#line 1 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian* birch::type::make_TestLinearMatrixNormalInverseWishartMatrixGaussian_() {
  #line 1 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return new birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian();
  #line 1 "src/test/model/TestLinearMatrixNormalInverseWishartMatrixGaussian.birch"
}

#line 1 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
birch::type::TestLinearMatrixNormalInverseWishartMultivariateGaussian::TestLinearMatrixNormalInverseWishartMultivariateGaussian() :
    #line 1 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    base_type_(),
    #line 2 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    V(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::LLT>>>()),
    #line 3 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    X(libbirch::make<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,2>>>>()),
    #line 4 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    y(libbirch::make<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,1>>>>()),
    #line 6 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    n(birch::type::Integer(5)),
    #line 7 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    p(birch::type::Integer(2)),
    #line 8 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    a(libbirch::make_array<birch::type::Real>(libbirch::make_shape(n))),
    #line 9 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    M(libbirch::make_array<birch::type::Real>(libbirch::make_shape(n, p))),
    #line 10 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    U(libbirch::make_array<birch::type::Real>(libbirch::make_shape(n, n))),
    #line 11 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    c(libbirch::make_array<birch::type::Real>(libbirch::make_shape(p))),
    #line 12 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    k(libbirch::make<birch::type::Real>()),
    #line 13 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    Ψ(libbirch::make_array<birch::type::Real>(libbirch::make_shape(p, p))),
    #line 14 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    neg(libbirch::make<birch::type::Boolean>()) {
  //
}

#line 16 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
void birch::type::TestLinearMatrixNormalInverseWishartMultivariateGaussian::initialize() {
  #line 16 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch", 16);
  #line 17 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  this->k = this->p + 1.0 + birch::simulate_uniform(0.0, 10.0);
  #line 18 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= this->n; ++i) {
    #line 19 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    libbirch_line_(19);
    #line 19 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    this->a(i) = birch::simulate_uniform(-(2.0), 2.0);
    #line 20 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    libbirch_line_(20);
    #line 20 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= this->n; ++j) {
      #line 21 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
      libbirch_line_(21);
      #line 21 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
      this->U(i, j) = birch::simulate_uniform(-(2.0), 2.0);
    }
    #line 23 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    libbirch_line_(23);
    #line 23 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= this->p; ++j) {
      #line 24 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
      libbirch_line_(24);
      #line 24 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
      this->M(i, j) = birch::simulate_uniform(-(10.0), 10.0);
    }
  }
  #line 27 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= this->p; ++i) {
    #line 28 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    libbirch_line_(28);
    #line 28 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    this->c(i) = birch::simulate_uniform(-(10.0), 10.0);
    #line 29 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    libbirch_line_(29);
    #line 29 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= this->p; ++j) {
      #line 30 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
      libbirch_line_(30);
      #line 30 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
      this->Ψ(i, j) = birch::simulate_uniform(-(10.0), 10.0);
    }
  }
  #line 33 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  this->U = this->U * birch::transpose(this->U) + birch::diagonal(1.0e-2, this->n);
  #line 34 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  this->Ψ = this->Ψ * birch::transpose(this->Ψ) + birch::diagonal(1.0e-2, this->p);
  #line 35 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  this->neg = birch::simulate_bernoulli(0.5);
}

#line 38 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
void birch::type::TestLinearMatrixNormalInverseWishartMultivariateGaussian::simulate() {
  #line 38 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch", 38);
  #line 39 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    birch::handle_assume(this->V, birch::InverseWishart(this->Ψ, this->k));
;
  #line 40 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    birch::handle_assume(this->X, birch::Gaussian(this->M, this->U, this->V));
;
  #line 41 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  if (this->neg) {
    #line 42 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    libbirch_line_(42);
    #line 42 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
        birch::handle_assume(this->y, birch::Gaussian(birch::dot(this->a, this->X) - this->c, this->V));
;
  } else {
    #line 44 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
    libbirch_line_(44);
    #line 44 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
        birch::handle_assume(this->y, birch::Gaussian(birch::dot(this->a, this->X) + this->c, this->V));
;
  }
}

#line 48 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMatrixNormalInverseWishartMultivariateGaussian::forward() {
  #line 48 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch", 48);
  #line 49 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(49);
  #line 49 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  this->V->value();
  #line 50 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(50);
  #line 50 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  this->X->value();
  #line 51 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  this->y->value();
  #line 52 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  return this->vectorize();
}

#line 55 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMatrixNormalInverseWishartMultivariateGaussian::backward() {
  #line 55 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch", 55);
  #line 56 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_assert_(!(this->y->hasValue()));
  #line 57 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(57);
  #line 57 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  this->y->value();
  #line 58 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(58);
  #line 58 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_assert_(!(this->X->hasValue()));
  #line 59 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(59);
  #line 59 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  this->X->value();
  #line 60 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(60);
  #line 60 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_assert_(!(this->V->hasValue()));
  #line 61 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(61);
  #line 61 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  this->V->value();
  #line 62 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(62);
  #line 62 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  return this->vectorize();
}

#line 65 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMatrixNormalInverseWishartMultivariateGaussian::forwardLazy() {
  #line 65 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch", 65);
  #line 66 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  this->V->get();
  #line 67 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(67);
  #line 67 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  this->X->get();
  #line 68 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(68);
  #line 68 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  this->y->get();
  #line 69 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(69);
  #line 69 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  return this->vectorize();
}

#line 72 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMatrixNormalInverseWishartMultivariateGaussian::backwardLazy() {
  #line 72 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch", 72);
  #line 73 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(73);
  #line 73 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_assert_(!(this->y->hasValue()));
  #line 74 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(74);
  #line 74 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  this->y->get();
  #line 75 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(75);
  #line 75 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_assert_(!(this->X->hasValue()));
  #line 76 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(76);
  #line 76 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  this->X->get();
  #line 77 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(77);
  #line 77 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_assert_(!(this->V->hasValue()));
  #line 78 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(78);
  #line 78 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  this->V->get();
  #line 79 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(79);
  #line 79 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  return this->vectorize();
}

#line 82 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::type::TestLinearMatrixNormalInverseWishartMultivariateGaussian::marginal() {
  #line 82 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch", 82);
  #line 83 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(83);
  #line 83 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  return this->y->distribution().value();
}

#line 86 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMatrixNormalInverseWishartMultivariateGaussian::vectorize() {
  #line 86 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_function_("vectorize", "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch", 86);
  #line 87 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(87);
  #line 87 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> z = libbirch::make_array<birch::type::Real>(libbirch::make_shape(this->size()));
  #line 88 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(88);
  #line 88 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  auto k = birch::type::Integer(0);
  #line 89 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(89);
  #line 89 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  z(libbirch::make_range(k + birch::type::Integer(1), k + this->p * this->p)) = birch::vec(birch::canonical(this->V->value()));
  #line 90 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(90);
  #line 90 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  k = k + this->p * this->p;
  #line 91 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(91);
  #line 91 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  z(libbirch::make_range(k + birch::type::Integer(1), k + this->n * this->p)) = birch::vec(this->X->value());
  #line 92 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(92);
  #line 92 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  k = k + this->n * this->p;
  #line 93 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(93);
  #line 93 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  z(libbirch::make_range(k + birch::type::Integer(1), k + this->p)) = this->y->value();
  #line 94 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(94);
  #line 94 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  return z;
}

#line 97 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
birch::type::Integer birch::type::TestLinearMatrixNormalInverseWishartMultivariateGaussian::size() {
  #line 97 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_function_("size", "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch", 97);
  #line 98 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  libbirch_line_(98);
  #line 98 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  return this->p * this->p + this->n * this->p + this->p;
}

#line 1 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
birch::type::TestLinearMatrixNormalInverseWishartMultivariateGaussian* birch::type::make_TestLinearMatrixNormalInverseWishartMultivariateGaussian_() {
  #line 1 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
  return new birch::type::TestLinearMatrixNormalInverseWishartMultivariateGaussian();
  #line 1 "src/test/model/TestLinearMatrixNormalInverseWishartMultivariateGaussian.birch"
}

#line 1 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
birch::type::TestLinearMultivariateGaussianGaussian::TestLinearMultivariateGaussianGaussian() :
    #line 1 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    base_type_(),
    #line 2 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    μ(libbirch::make<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,1>>>>()),
    #line 3 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    x(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 5 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    a(libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(5)))),
    #line 6 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    μ_0(libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(5)))),
    #line 7 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    Σ_0(libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(5), birch::type::Integer(5)))),
    #line 8 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    c(libbirch::make<birch::type::Real>()),
    #line 9 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    σ2_1(libbirch::make<birch::type::Real>()) {
  //
}

#line 11 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
void birch::type::TestLinearMultivariateGaussianGaussian::initialize() {
  #line 11 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestLinearMultivariateGaussianGaussian.birch", 11);
  #line 12 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  this->c = birch::simulate_uniform(-(10.0), 10.0);
  #line 13 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(5); ++i) {
    #line 14 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    libbirch_line_(14);
    #line 14 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    this->a(i) = birch::simulate_uniform(-(2.0), 2.0);
    #line 15 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    libbirch_line_(15);
    #line 15 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    this->μ_0(i) = birch::simulate_uniform(-(10.0), 10.0);
    #line 16 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    libbirch_line_(16);
    #line 16 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= birch::type::Integer(5); ++j) {
      #line 17 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
      libbirch_line_(17);
      #line 17 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
      this->Σ_0(i, j) = birch::simulate_uniform(-(2.0), 2.0);
    }
  }
  #line 20 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  this->Σ_0 = this->Σ_0 * birch::transpose(this->Σ_0) + birch::diagonal(1.0e-2, birch::type::Integer(5));
  #line 21 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  this->σ2_1 = birch::simulate_uniform(0.1, 10.0);
}

#line 24 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
void birch::type::TestLinearMultivariateGaussianGaussian::simulate() {
  #line 24 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestLinearMultivariateGaussianGaussian.birch", 24);
  #line 25 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    birch::handle_assume(this->μ, birch::Gaussian(this->μ_0, this->Σ_0));
;
  #line 26 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
    birch::handle_assume(this->x, birch::Gaussian(birch::dot(this->a, this->μ) + this->c, this->σ2_1));
;
}

#line 29 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMultivariateGaussianGaussian::forward() {
  #line 29 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestLinearMultivariateGaussianGaussian.birch", 29);
  #line 30 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(6)));
  #line 31 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(1), birch::type::Integer(5))) = this->μ->value();
  #line 32 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  y(birch::type::Integer(6)) = this->x->value();
  #line 33 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  return y;
}

#line 36 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMultivariateGaussianGaussian::backward() {
  #line 36 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestLinearMultivariateGaussianGaussian.birch", 36);
  #line 37 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(6)));
  #line 38 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 39 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  y(birch::type::Integer(6)) = this->x->value();
  #line 40 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_assert_(!(this->μ->hasValue()));
  #line 41 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(1), birch::type::Integer(5))) = this->μ->value();
  #line 42 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  return y;
}

#line 45 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMultivariateGaussianGaussian::forwardLazy() {
  #line 45 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestLinearMultivariateGaussianGaussian.birch", 45);
  #line 46 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(6)));
  #line 47 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(1), birch::type::Integer(5))) = this->μ->get();
  #line 48 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  y(birch::type::Integer(6)) = this->x->get();
  #line 49 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(49);
  #line 49 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  return y;
}

#line 52 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMultivariateGaussianGaussian::backwardLazy() {
  #line 52 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestLinearMultivariateGaussianGaussian.birch", 52);
  #line 53 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(53);
  #line 53 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(6)));
  #line 54 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 55 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(55);
  #line 55 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  y(birch::type::Integer(6)) = this->x->get();
  #line 56 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_assert_(!(this->μ->hasValue()));
  #line 57 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(57);
  #line 57 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(1), birch::type::Integer(5))) = this->μ->get();
  #line 58 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(58);
  #line 58 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  return y;
}

#line 61 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::type::TestLinearMultivariateGaussianGaussian::marginal() {
  #line 61 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestLinearMultivariateGaussianGaussian.birch", 61);
  #line 62 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  libbirch_line_(62);
  #line 62 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  return this->x->distribution().value();
}

#line 1 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
birch::type::TestLinearMultivariateGaussianGaussian* birch::type::make_TestLinearMultivariateGaussianGaussian_() {
  #line 1 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
  return new birch::type::TestLinearMultivariateGaussianGaussian();
  #line 1 "src/test/model/TestLinearMultivariateGaussianGaussian.birch"
}

#line 1 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
birch::type::TestLinearMultivariateGaussianMultivariateGaussian::TestLinearMultivariateGaussianMultivariateGaussian() :
    #line 1 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    base_type_(),
    #line 2 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    μ(libbirch::make<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,1>>>>()),
    #line 3 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    x(libbirch::make<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,1>>>>()),
    #line 5 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    A(libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(5), birch::type::Integer(5)))),
    #line 6 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    μ_0(libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(5)))),
    #line 7 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    Σ_0(libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(5), birch::type::Integer(5)))),
    #line 8 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    c(libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(5)))),
    #line 9 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    Σ_1(libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(5), birch::type::Integer(5)))),
    #line 10 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    neg(libbirch::make<birch::type::Boolean>()) {
  //
}

#line 12 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
void birch::type::TestLinearMultivariateGaussianMultivariateGaussian::initialize() {
  #line 12 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch", 12);
  #line 13 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(5); ++i) {
    #line 14 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    libbirch_line_(14);
    #line 14 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    this->μ_0(i) = birch::simulate_uniform(-(10.0), 10.0);
    #line 15 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    libbirch_line_(15);
    #line 15 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    this->c(i) = birch::simulate_uniform(-(10.0), 10.0);
    #line 16 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    libbirch_line_(16);
    #line 16 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= birch::type::Integer(5); ++j) {
      #line 17 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
      libbirch_line_(17);
      #line 17 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
      this->Σ_0(i, j) = birch::simulate_uniform(-(2.0), 2.0);
      #line 18 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
      libbirch_line_(18);
      #line 18 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
      this->Σ_1(i, j) = birch::simulate_uniform(-(2.0), 2.0);
      #line 19 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
      libbirch_line_(19);
      #line 19 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
      this->A(i, j) = birch::simulate_uniform(-(2.0), 2.0);
    }
  }
  #line 22 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  this->Σ_0 = this->Σ_0 * birch::transpose(this->Σ_0) + birch::diagonal(1.0e-2, birch::type::Integer(5));
  #line 23 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  this->Σ_1 = this->Σ_1 * birch::transpose(this->Σ_1) + birch::diagonal(1.0e-2, birch::type::Integer(5));
  #line 24 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  this->neg = birch::simulate_bernoulli(0.5);
}

#line 27 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
void birch::type::TestLinearMultivariateGaussianMultivariateGaussian::simulate() {
  #line 27 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch", 27);
  #line 28 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    birch::handle_assume(this->μ, birch::Gaussian(this->μ_0, this->Σ_0));
;
  #line 29 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  if (this->neg) {
    #line 30 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    libbirch_line_(30);
    #line 30 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
        birch::handle_assume(this->x, birch::Gaussian(this->A * this->μ - this->c, this->Σ_1));
;
  } else {
    #line 32 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
    libbirch_line_(32);
    #line 32 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
        birch::handle_assume(this->x, birch::Gaussian(this->A * this->μ + this->c, this->Σ_1));
;
  }
}

#line 36 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMultivariateGaussianMultivariateGaussian::forward() {
  #line 36 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch", 36);
  #line 37 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(10)));
  #line 38 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(1), birch::type::Integer(5))) = this->μ->value();
  #line 39 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(6), birch::type::Integer(10))) = this->x->value();
  #line 40 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  return y;
}

#line 43 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMultivariateGaussianMultivariateGaussian::backward() {
  #line 43 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch", 43);
  #line 44 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(10)));
  #line 45 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 46 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(6), birch::type::Integer(10))) = this->x->value();
  #line 47 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_assert_(!(this->μ->hasValue()));
  #line 48 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(1), birch::type::Integer(5))) = this->μ->value();
  #line 49 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(49);
  #line 49 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  return y;
}

#line 52 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMultivariateGaussianMultivariateGaussian::forwardLazy() {
  #line 52 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch", 52);
  #line 53 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(53);
  #line 53 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(10)));
  #line 54 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(1), birch::type::Integer(5))) = this->μ->get();
  #line 55 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(55);
  #line 55 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(6), birch::type::Integer(10))) = this->x->get();
  #line 56 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  return y;
}

#line 59 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMultivariateGaussianMultivariateGaussian::backwardLazy() {
  #line 59 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch", 59);
  #line 60 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(60);
  #line 60 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(10)));
  #line 61 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(61);
  #line 61 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 62 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(62);
  #line 62 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(6), birch::type::Integer(10))) = this->x->get();
  #line 63 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(63);
  #line 63 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_assert_(!(this->μ->hasValue()));
  #line 64 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(64);
  #line 64 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(1), birch::type::Integer(5))) = this->μ->get();
  #line 65 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(65);
  #line 65 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  return y;
}

#line 68 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::type::TestLinearMultivariateGaussianMultivariateGaussian::marginal() {
  #line 68 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch", 68);
  #line 69 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(69);
  #line 69 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  return this->x->distribution().value();
}

#line 1 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
birch::type::TestLinearMultivariateGaussianMultivariateGaussian* birch::type::make_TestLinearMultivariateGaussianMultivariateGaussian_() {
  #line 1 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
  return new birch::type::TestLinearMultivariateGaussianMultivariateGaussian();
  #line 1 "src/test/model/TestLinearMultivariateGaussianMultivariateGaussian.birch"
}

#line 1 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
birch::type::TestLinearMultivariateNormalInverseGammaGaussian::TestLinearMultivariateNormalInverseGammaGaussian() :
    #line 1 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    base_type_(),
    #line 2 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    σ2(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 3 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    μ(libbirch::make<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,1>>>>()),
    #line 4 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    x(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 6 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    a(libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(10)))),
    #line 7 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    μ_0(libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(10)))),
    #line 8 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    Σ(libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(10), birch::type::Integer(10)))),
    #line 9 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    c(libbirch::make<birch::type::Real>()),
    #line 10 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    α(libbirch::make<birch::type::Real>()),
    #line 11 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    β(libbirch::make<birch::type::Real>()) {
  //
}

#line 13 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
void birch::type::TestLinearMultivariateNormalInverseGammaGaussian::initialize() {
  #line 13 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch", 13);
  #line 14 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  this->α = birch::simulate_uniform(2.0, 10.0);
  #line 15 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  this->β = birch::simulate_uniform(0.1, 10.0);
  #line 16 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(10); ++i) {
    #line 17 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    libbirch_line_(17);
    #line 17 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    this->a(i) = birch::simulate_uniform(-(2.0), 2.0);
    #line 18 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    libbirch_line_(18);
    #line 18 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    this->μ_0(i) = birch::simulate_uniform(-(10.0), 10.0);
    #line 19 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    libbirch_line_(19);
    #line 19 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= birch::type::Integer(10); ++j) {
      #line 20 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
      libbirch_line_(20);
      #line 20 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
      this->Σ(i, j) = birch::simulate_uniform(-(2.0), 2.0);
    }
  }
  #line 23 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  this->c = birch::simulate_uniform(-(10.0), 10.0);
  #line 24 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  this->Σ = this->Σ * birch::transpose(this->Σ) + birch::diagonal(1.0e-2, birch::type::Integer(10));
}

#line 27 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
void birch::type::TestLinearMultivariateNormalInverseGammaGaussian::simulate() {
  #line 27 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch", 27);
  #line 28 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    birch::handle_assume(this->σ2, birch::InverseGamma(this->α, this->β));
;
  #line 29 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    birch::handle_assume(this->μ, birch::Gaussian(this->μ_0, this->Σ, this->σ2));
;
  #line 30 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
    birch::handle_assume(this->x, birch::Gaussian(birch::dot(this->a, this->μ) + this->c, this->σ2));
;
}

#line 33 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMultivariateNormalInverseGammaGaussian::forward() {
  #line 33 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch", 33);
  #line 34 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(12)));
  #line 35 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(1)) = this->σ2->value();
  #line 36 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(2), birch::type::Integer(11))) = this->μ->value();
  #line 37 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(12)) = this->x->value();
  #line 38 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  return y;
}

#line 41 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMultivariateNormalInverseGammaGaussian::backward() {
  #line 41 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch", 41);
  #line 42 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(12)));
  #line 43 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 44 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(12)) = this->x->value();
  #line 45 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_assert_(!(this->μ->hasValue()));
  #line 46 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(2), birch::type::Integer(11))) = this->μ->value();
  #line 47 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_assert_(!(this->σ2->hasValue()));
  #line 48 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(1)) = this->σ2->value();
  #line 49 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(49);
  #line 49 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  return y;
}

#line 52 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMultivariateNormalInverseGammaGaussian::forwardLazy() {
  #line 52 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch", 52);
  #line 53 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(53);
  #line 53 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(12)));
  #line 54 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(1)) = this->σ2->get();
  #line 55 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(55);
  #line 55 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(2), birch::type::Integer(11))) = this->μ->get();
  #line 56 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(12)) = this->x->get();
  #line 57 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(57);
  #line 57 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  return y;
}

#line 60 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMultivariateNormalInverseGammaGaussian::backwardLazy() {
  #line 60 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch", 60);
  #line 61 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(61);
  #line 61 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(12)));
  #line 62 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(62);
  #line 62 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 63 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(63);
  #line 63 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(12)) = this->x->get();
  #line 64 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(64);
  #line 64 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_assert_(!(this->μ->hasValue()));
  #line 65 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(65);
  #line 65 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(2), birch::type::Integer(11))) = this->μ->get();
  #line 66 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_assert_(!(this->σ2->hasValue()));
  #line 67 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(67);
  #line 67 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(1)) = this->σ2->get();
  #line 68 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(68);
  #line 68 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  return y;
}

#line 71 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::type::TestLinearMultivariateNormalInverseGammaGaussian::marginal() {
  #line 71 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch", 71);
  #line 72 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(72);
  #line 72 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  return this->x->distribution().value();
}

#line 1 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
birch::type::TestLinearMultivariateNormalInverseGammaGaussian* birch::type::make_TestLinearMultivariateNormalInverseGammaGaussian_() {
  #line 1 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
  return new birch::type::TestLinearMultivariateNormalInverseGammaGaussian();
  #line 1 "src/test/model/TestLinearMultivariateNormalInverseGammaGaussian.birch"
}

#line 1 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::TestLinearMultivariateNormalInverseGammaMultivariateGaussian::TestLinearMultivariateNormalInverseGammaMultivariateGaussian() :
    #line 1 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    base_type_(),
    #line 2 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    σ2(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 3 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    μ(libbirch::make<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,1>>>>()),
    #line 4 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    x(libbirch::make<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,1>>>>()),
    #line 6 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    A(libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(5), birch::type::Integer(10)))),
    #line 7 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    μ_0(libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(10)))),
    #line 8 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    Σ(libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(10), birch::type::Integer(10)))),
    #line 9 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    c(libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(5)))),
    #line 10 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    α(libbirch::make<birch::type::Real>()),
    #line 11 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    β(libbirch::make<birch::type::Real>()),
    #line 12 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    neg(libbirch::make<birch::type::Boolean>()) {
  //
}

#line 14 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::TestLinearMultivariateNormalInverseGammaMultivariateGaussian::initialize() {
  #line 14 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 14);
  #line 15 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  this->α = birch::simulate_uniform(2.0, 10.0);
  #line 16 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  this->β = birch::simulate_uniform(0.1, 10.0);
  #line 17 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(10); ++i) {
    #line 18 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    libbirch_line_(18);
    #line 18 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    this->μ_0(i) = birch::simulate_uniform(-(10.0), 10.0);
    #line 19 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    libbirch_line_(19);
    #line 19 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= birch::type::Integer(10); ++j) {
      #line 20 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
      libbirch_line_(20);
      #line 20 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
      this->Σ(i, j) = birch::simulate_uniform(-(2.0), 2.0);
    }
  }
  #line 23 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(5); ++i) {
    #line 24 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    libbirch_line_(24);
    #line 24 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    this->c(i) = birch::simulate_uniform(-(10.0), 10.0);
    #line 25 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    libbirch_line_(25);
    #line 25 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= birch::type::Integer(10); ++j) {
      #line 26 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
      libbirch_line_(26);
      #line 26 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
      this->A(i, j) = birch::simulate_uniform(-(2.0), 2.0);
    }
  }
  #line 29 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  this->Σ = this->Σ * birch::transpose(this->Σ) + birch::diagonal(1.0e-2, birch::type::Integer(10));
  #line 30 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  this->neg = birch::simulate_bernoulli(0.5);
}

#line 33 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::TestLinearMultivariateNormalInverseGammaMultivariateGaussian::simulate() {
  #line 33 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 33);
  #line 34 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    birch::handle_assume(this->σ2, birch::InverseGamma(this->α, this->β));
;
  #line 35 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    birch::handle_assume(this->μ, birch::Gaussian(this->μ_0, this->Σ, this->σ2));
;
  #line 36 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  if (this->neg) {
    #line 37 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    libbirch_line_(37);
    #line 37 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
        birch::handle_assume(this->x, birch::Gaussian(this->A * this->μ - this->c, this->σ2));
;
  } else {
    #line 39 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    libbirch_line_(39);
    #line 39 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
        birch::handle_assume(this->x, birch::Gaussian(this->A * this->μ + this->c, this->σ2));
;
  }
}

#line 43 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMultivariateNormalInverseGammaMultivariateGaussian::forward() {
  #line 43 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 43);
  #line 44 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(16)));
  #line 45 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y(birch::type::Integer(1)) = this->σ2->value();
  #line 46 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(2), birch::type::Integer(11))) = this->μ->value();
  #line 47 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(12), birch::type::Integer(16))) = this->x->value();
  #line 48 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return y;
}

#line 51 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMultivariateNormalInverseGammaMultivariateGaussian::backward() {
  #line 51 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 51);
  #line 52 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(16)));
  #line 53 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(53);
  #line 53 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 54 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(12), birch::type::Integer(16))) = this->x->value();
  #line 55 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(55);
  #line 55 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_assert_(!(this->μ->hasValue()));
  #line 56 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(2), birch::type::Integer(11))) = this->μ->value();
  #line 57 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(57);
  #line 57 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_assert_(!(this->σ2->hasValue()));
  #line 58 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(58);
  #line 58 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y(birch::type::Integer(1)) = this->σ2->value();
  #line 59 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(59);
  #line 59 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return y;
}

#line 62 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMultivariateNormalInverseGammaMultivariateGaussian::forwardLazy() {
  #line 62 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 62);
  #line 63 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(63);
  #line 63 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(16)));
  #line 64 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(64);
  #line 64 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y(birch::type::Integer(1)) = this->σ2->get();
  #line 65 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(65);
  #line 65 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(2), birch::type::Integer(11))) = this->μ->get();
  #line 66 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(12), birch::type::Integer(16))) = this->x->get();
  #line 67 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(67);
  #line 67 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return y;
}

#line 70 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearMultivariateNormalInverseGammaMultivariateGaussian::backwardLazy() {
  #line 70 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 70);
  #line 71 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(71);
  #line 71 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(16)));
  #line 72 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(72);
  #line 72 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 73 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(73);
  #line 73 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(12), birch::type::Integer(16))) = this->x->get();
  #line 74 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(74);
  #line 74 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_assert_(!(this->μ->hasValue()));
  #line 75 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(75);
  #line 75 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(2), birch::type::Integer(11))) = this->μ->get();
  #line 76 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(76);
  #line 76 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_assert_(!(this->σ2->hasValue()));
  #line 77 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(77);
  #line 77 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y(birch::type::Integer(1)) = this->σ2->get();
  #line 78 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(78);
  #line 78 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return y;
}

#line 81 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::type::TestLinearMultivariateNormalInverseGammaMultivariateGaussian::marginal() {
  #line 81 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 81);
  #line 82 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(82);
  #line 82 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return this->x->distribution().value();
}

#line 1 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::TestLinearMultivariateNormalInverseGammaMultivariateGaussian* birch::type::make_TestLinearMultivariateNormalInverseGammaMultivariateGaussian_() {
  #line 1 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return new birch::type::TestLinearMultivariateNormalInverseGammaMultivariateGaussian();
  #line 1 "src/test/model/TestLinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
}

#line 1 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
birch::type::TestLinearNormalInverseGammaGaussian::TestLinearNormalInverseGammaGaussian() :
    #line 1 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    base_type_(),
    #line 2 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    σ2(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 3 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    μ(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 4 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    x(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 6 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    a(libbirch::make<birch::type::Real>()),
    #line 7 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    μ_0(libbirch::make<birch::type::Real>()),
    #line 8 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    a2(libbirch::make<birch::type::Real>()),
    #line 9 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    c(libbirch::make<birch::type::Real>()),
    #line 10 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    α(libbirch::make<birch::type::Real>()),
    #line 11 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    β(libbirch::make<birch::type::Real>()),
    #line 12 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    neg(libbirch::make<birch::type::Boolean>()) {
  //
}

#line 14 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
void birch::type::TestLinearNormalInverseGammaGaussian::initialize() {
  #line 14 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestLinearNormalInverseGammaGaussian.birch", 14);
  #line 15 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  this->a = birch::simulate_uniform(-(2.0), 2.0);
  #line 16 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  this->μ_0 = birch::simulate_uniform(-(10.0), 10.0);
  #line 17 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  this->a2 = birch::simulate_uniform(0.1, 2.0);
  #line 18 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  this->c = birch::simulate_uniform(-(10.0), 10.0);
  #line 19 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  this->α = birch::simulate_uniform(2.0, 10.0);
  #line 20 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  this->β = birch::simulate_uniform(0.1, 10.0);
  #line 21 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  this->neg = birch::simulate_bernoulli(0.5);
}

#line 24 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
void birch::type::TestLinearNormalInverseGammaGaussian::simulate() {
  #line 24 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestLinearNormalInverseGammaGaussian.birch", 24);
  #line 25 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    birch::handle_assume(this->σ2, birch::InverseGamma(this->α, this->β));
;
  #line 26 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    birch::handle_assume(this->μ, birch::Gaussian(this->μ_0, this->a2, this->σ2));
;
  #line 27 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  if (this->neg) {
    #line 28 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    libbirch_line_(28);
    #line 28 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
        birch::handle_assume(this->x, birch::Gaussian(this->μ / this->a - this->c, this->σ2));
;
  } else {
    #line 30 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
    libbirch_line_(30);
    #line 30 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
        birch::handle_assume(this->x, birch::Gaussian(this->a * this->μ + this->c, this->σ2));
;
  }
}

#line 34 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearNormalInverseGammaGaussian::forward() {
  #line 34 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestLinearNormalInverseGammaGaussian.birch", 34);
  #line 35 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(3)));
  #line 36 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(1)) = this->σ2->value();
  #line 37 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(2)) = this->μ->value();
  #line 38 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(3)) = this->x->value();
  #line 39 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  return y;
}

#line 42 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearNormalInverseGammaGaussian::backward() {
  #line 42 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestLinearNormalInverseGammaGaussian.birch", 42);
  #line 43 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(3)));
  #line 44 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 45 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(3)) = this->x->value();
  #line 46 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_assert_(!(this->μ->hasValue()));
  #line 47 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(2)) = this->μ->value();
  #line 48 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_assert_(!(this->σ2->hasValue()));
  #line 49 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(49);
  #line 49 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(1)) = this->σ2->value();
  #line 50 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(50);
  #line 50 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  return y;
}

#line 53 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearNormalInverseGammaGaussian::forwardLazy() {
  #line 53 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestLinearNormalInverseGammaGaussian.birch", 53);
  #line 54 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(3)));
  #line 55 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(55);
  #line 55 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(1)) = this->σ2->get();
  #line 56 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(2)) = this->μ->get();
  #line 57 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(57);
  #line 57 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(3)) = this->x->get();
  #line 58 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(58);
  #line 58 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  return y;
}

#line 61 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestLinearNormalInverseGammaGaussian::backwardLazy() {
  #line 61 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestLinearNormalInverseGammaGaussian.birch", 61);
  #line 62 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(62);
  #line 62 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(3)));
  #line 63 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(63);
  #line 63 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 64 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(64);
  #line 64 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(3)) = this->x->get();
  #line 65 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(65);
  #line 65 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_assert_(!(this->μ->hasValue()));
  #line 66 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(2)) = this->μ->get();
  #line 67 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(67);
  #line 67 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_assert_(!(this->σ2->hasValue()));
  #line 68 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(68);
  #line 68 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(1)) = this->σ2->get();
  #line 69 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(69);
  #line 69 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  return y;
}

#line 72 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::type::TestLinearNormalInverseGammaGaussian::marginal() {
  #line 72 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestLinearNormalInverseGammaGaussian.birch", 72);
  #line 73 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  libbirch_line_(73);
  #line 73 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  return this->x->distribution().value();
}

#line 1 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
birch::type::TestLinearNormalInverseGammaGaussian* birch::type::make_TestLinearNormalInverseGammaGaussian_() {
  #line 1 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
  return new birch::type::TestLinearNormalInverseGammaGaussian();
  #line 1 "src/test/model/TestLinearNormalInverseGammaGaussian.birch"
}

#line 1 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::TestMatrixNormalInverseWishartMatrixGaussian::TestMatrixNormalInverseWishartMatrixGaussian() :
    #line 1 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    base_type_(),
    #line 2 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    V(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::LLT>>>()),
    #line 3 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    X(libbirch::make<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,2>>>>()),
    #line 4 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    Y(libbirch::make<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,2>>>>()),
    #line 6 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    n(birch::type::Integer(5)),
    #line 7 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    p(birch::type::Integer(2)),
    #line 9 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    M(libbirch::make_array<birch::type::Real>(libbirch::make_shape(n, p))),
    #line 10 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    U(libbirch::make_array<birch::type::Real>(libbirch::make_shape(n, n))),
    #line 11 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    k(libbirch::make<birch::type::Real>()),
    #line 12 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    Ψ(libbirch::make_array<birch::type::Real>(libbirch::make_shape(p, p))) {
  //
}

#line 14 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::TestMatrixNormalInverseWishartMatrixGaussian::initialize() {
  #line 14 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch", 14);
  #line 15 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  this->k = this->p + 1.0 + birch::simulate_uniform(0.0, 10.0);
  #line 16 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(16);
  #line 16 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= this->n; ++i) {
    #line 17 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(17);
    #line 17 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= this->n; ++j) {
      #line 18 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
      libbirch_line_(18);
      #line 18 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
      this->U(i, j) = birch::simulate_uniform(-(2.0), 2.0);
    }
    #line 20 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(20);
    #line 20 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= this->p; ++j) {
      #line 21 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
      libbirch_line_(21);
      #line 21 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
      this->M(i, j) = birch::simulate_uniform(-(10.0), 10.0);
    }
  }
  #line 24 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= this->p; ++i) {
    #line 25 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(25);
    #line 25 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= this->p; ++j) {
      #line 26 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
      libbirch_line_(26);
      #line 26 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
      this->Ψ(i, j) = birch::simulate_uniform(-(10.0), 10.0);
    }
  }
  #line 29 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  this->U = this->U * birch::transpose(this->U) + birch::diagonal(1.0e-2, this->n);
  #line 30 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  this->Ψ = this->Ψ * birch::transpose(this->Ψ) + birch::diagonal(1.0e-2, this->p);
}

#line 33 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::TestMatrixNormalInverseWishartMatrixGaussian::simulate() {
  #line 33 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch", 33);
  #line 34 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    birch::handle_assume(this->V, birch::InverseWishart(this->Ψ, this->k));
;
  #line 35 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    birch::handle_assume(this->X, birch::Gaussian(this->M, this->U, this->V));
;
  #line 36 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    birch::handle_assume(this->Y, birch::Gaussian(this->X, this->V));
;
}

#line 39 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestMatrixNormalInverseWishartMatrixGaussian::forward() {
  #line 39 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch", 39);
  #line 40 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  this->V->value();
  #line 41 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  this->X->value();
  #line 42 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  this->Y->value();
  #line 43 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  return this->vectorize();
}

#line 46 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestMatrixNormalInverseWishartMatrixGaussian::backward() {
  #line 46 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch", 46);
  #line 47 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!(this->Y->hasValue()));
  #line 48 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  this->Y->value();
  #line 49 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(49);
  #line 49 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!(this->X->hasValue()));
  #line 50 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(50);
  #line 50 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  this->X->value();
  #line 51 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!(this->V->hasValue()));
  #line 52 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  this->V->value();
  #line 53 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(53);
  #line 53 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  return this->vectorize();
}

#line 56 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestMatrixNormalInverseWishartMatrixGaussian::forwardLazy() {
  #line 56 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch", 56);
  #line 57 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(57);
  #line 57 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  this->V->get();
  #line 58 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(58);
  #line 58 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  this->X->get();
  #line 59 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(59);
  #line 59 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  this->Y->get();
  #line 60 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(60);
  #line 60 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  return this->vectorize();
}

#line 63 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestMatrixNormalInverseWishartMatrixGaussian::backwardLazy() {
  #line 63 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch", 63);
  #line 64 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(64);
  #line 64 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!(this->Y->hasValue()));
  #line 65 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(65);
  #line 65 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  this->Y->get();
  #line 66 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(66);
  #line 66 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!(this->X->hasValue()));
  #line 67 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(67);
  #line 67 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  this->X->get();
  #line 68 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(68);
  #line 68 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_assert_(!(this->V->hasValue()));
  #line 69 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(69);
  #line 69 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  this->V->get();
  #line 70 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(70);
  #line 70 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  return this->vectorize();
}

#line 73 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>> birch::type::TestMatrixNormalInverseWishartMatrixGaussian::marginal() {
  #line 73 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch", 73);
  #line 74 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(74);
  #line 74 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  return this->Y->distribution().value();
}

#line 77 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestMatrixNormalInverseWishartMatrixGaussian::vectorize() {
  #line 77 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("vectorize", "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch", 77);
  #line 78 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(78);
  #line 78 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(this->size()));
  #line 79 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(79);
  #line 79 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  auto k = birch::type::Integer(0);
  #line 80 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(80);
  #line 80 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(this->V); ++i) {
    #line 81 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(81);
    #line 81 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    y(libbirch::make_range(k + birch::type::Integer(1), k + birch::columns(this->V))) = birch::canonical(this->V->value())(i, libbirch::make_range(birch::type::Integer(1), birch::columns(this->V)));
    #line 82 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(82);
    #line 82 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    k = k + birch::columns(this->V);
  }
  #line 84 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(84);
  #line 84 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(this->X); ++i) {
    #line 85 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(85);
    #line 85 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    y(libbirch::make_range(k + birch::type::Integer(1), k + birch::columns(this->X))) = this->X->value()(i, libbirch::make_range(birch::type::Integer(1), birch::columns(this->X)));
    #line 86 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(86);
    #line 86 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    k = k + birch::columns(this->X);
  }
  #line 88 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(88);
  #line 88 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::rows(this->Y); ++i) {
    #line 89 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(89);
    #line 89 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    y(libbirch::make_range(k + birch::type::Integer(1), k + birch::columns(this->Y))) = this->Y->value()(i, libbirch::make_range(birch::type::Integer(1), birch::columns(this->Y)));
    #line 90 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    libbirch_line_(90);
    #line 90 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
    k = k + birch::columns(this->Y);
  }
  #line 92 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(92);
  #line 92 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  return y;
}

#line 95 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Integer birch::type::TestMatrixNormalInverseWishartMatrixGaussian::size() {
  #line 95 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("size", "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch", 95);
  #line 96 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(96);
  #line 96 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  return this->p * this->p + birch::type::Integer(2) * this->n * this->p;
}

#line 1 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::TestMatrixNormalInverseWishartMatrixGaussian* birch::type::make_TestMatrixNormalInverseWishartMatrixGaussian_() {
  #line 1 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
  return new birch::type::TestMatrixNormalInverseWishartMatrixGaussian();
  #line 1 "src/test/model/TestMatrixNormalInverseWishartMatrixGaussian.birch"
}

#line 1 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
birch::type::TestMultivariateGaussianMultivariateGaussian::TestMultivariateGaussianMultivariateGaussian() :
    #line 1 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
    base_type_(),
    #line 2 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
    μ_1(libbirch::make<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,1>>>>()),
    #line 3 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
    x(libbirch::make<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,1>>>>()),
    #line 5 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
    μ_0(libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(5)))),
    #line 6 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
    Σ_0(libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(5), birch::type::Integer(5)))),
    #line 7 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
    Σ_1(libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(5), birch::type::Integer(5)))) {
  //
}

#line 9 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
void birch::type::TestMultivariateGaussianMultivariateGaussian::initialize() {
  #line 9 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch", 9);
  #line 10 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(10);
  #line 10 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(5); ++i) {
    #line 11 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
    libbirch_line_(11);
    #line 11 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
    this->μ_0(i) = birch::simulate_uniform(-(10.0), 10.0);
    #line 12 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
    libbirch_line_(12);
    #line 12 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= birch::type::Integer(5); ++j) {
      #line 13 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
      libbirch_line_(13);
      #line 13 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
      this->Σ_0(i, j) = birch::simulate_uniform(-(2.0), 2.0);
      #line 14 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
      libbirch_line_(14);
      #line 14 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
      this->Σ_1(i, j) = birch::simulate_uniform(-(2.0), 2.0);
    }
  }
  #line 17 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  this->Σ_0 = this->Σ_0 * birch::transpose(this->Σ_0) + birch::diagonal(1.0e-2, birch::type::Integer(5));
  #line 18 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  this->Σ_1 = this->Σ_1 * birch::transpose(this->Σ_1) + birch::diagonal(1.0e-2, birch::type::Integer(5));
}

#line 21 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
void birch::type::TestMultivariateGaussianMultivariateGaussian::simulate() {
  #line 21 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch", 21);
  #line 22 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(22);
  #line 22 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
    birch::handle_assume(this->μ_1, birch::Gaussian(this->μ_0, this->Σ_0));
;
  #line 23 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
    birch::handle_assume(this->x, birch::Gaussian(this->μ_1, this->Σ_1));
;
}

#line 26 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestMultivariateGaussianMultivariateGaussian::forward() {
  #line 26 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch", 26);
  #line 27 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(10)));
  #line 28 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(1), birch::type::Integer(5))) = this->μ_1->value();
  #line 29 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(6), birch::type::Integer(10))) = this->x->value();
  #line 30 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  return y;
}

#line 33 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestMultivariateGaussianMultivariateGaussian::backward() {
  #line 33 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch", 33);
  #line 34 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(10)));
  #line 35 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 36 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(6), birch::type::Integer(10))) = this->x->value();
  #line 37 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_assert_(!(this->μ_1->hasValue()));
  #line 38 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(1), birch::type::Integer(5))) = this->μ_1->value();
  #line 39 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  return y;
}

#line 42 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestMultivariateGaussianMultivariateGaussian::forwardLazy() {
  #line 42 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch", 42);
  #line 43 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(10)));
  #line 44 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(1), birch::type::Integer(5))) = this->μ_1->get();
  #line 45 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(6), birch::type::Integer(10))) = this->x->get();
  #line 46 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  return y;
}

#line 49 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestMultivariateGaussianMultivariateGaussian::backwardLazy() {
  #line 49 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch", 49);
  #line 50 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(50);
  #line 50 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(10)));
  #line 51 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 52 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(6), birch::type::Integer(10))) = this->x->get();
  #line 53 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(53);
  #line 53 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_assert_(!(this->μ_1->hasValue()));
  #line 54 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(1), birch::type::Integer(5))) = this->μ_1->get();
  #line 55 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(55);
  #line 55 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  return y;
}

#line 58 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::type::TestMultivariateGaussianMultivariateGaussian::marginal() {
  #line 58 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch", 58);
  #line 59 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(59);
  #line 59 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  return this->x->distribution().value();
}

#line 1 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
birch::type::TestMultivariateGaussianMultivariateGaussian* birch::type::make_TestMultivariateGaussianMultivariateGaussian_() {
  #line 1 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
  return new birch::type::TestMultivariateGaussianMultivariateGaussian();
  #line 1 "src/test/model/TestMultivariateGaussianMultivariateGaussian.birch"
}

#line 1 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::TestMultivariateNormalInverseGammaMultivariateGaussian::TestMultivariateNormalInverseGammaMultivariateGaussian() :
    #line 1 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    base_type_(),
    #line 2 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    σ2(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 3 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    μ(libbirch::make<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,1>>>>()),
    #line 4 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    x(libbirch::make<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,1>>>>()),
    #line 6 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    μ_0(libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(5)))),
    #line 7 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    A(libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(5), birch::type::Integer(5)))),
    #line 8 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    α(libbirch::make<birch::type::Real>()),
    #line 9 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    β(libbirch::make<birch::type::Real>()) {
  //
}

#line 11 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::TestMultivariateNormalInverseGammaMultivariateGaussian::initialize() {
  #line 11 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch", 11);
  #line 12 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  this->α = birch::simulate_uniform(2.0, 10.0);
  #line 13 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  this->β = birch::simulate_uniform(0.1, 10.0);
  #line 14 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  for (auto i = birch::type::Integer(1); i <= birch::type::Integer(5); ++i) {
    #line 15 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    libbirch_line_(15);
    #line 15 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    this->μ_0(i) = birch::simulate_uniform(-(10.0), 10.0);
    #line 16 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    libbirch_line_(16);
    #line 16 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    for (auto j = birch::type::Integer(1); j <= birch::type::Integer(5); ++j) {
      #line 17 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
      libbirch_line_(17);
      #line 17 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
      this->A(i, j) = birch::simulate_uniform(-(2.0), 2.0);
    }
  }
  #line 20 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  this->A = this->A * birch::transpose(this->A) + birch::diagonal(1.0e-2, birch::type::Integer(5));
}

#line 23 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::TestMultivariateNormalInverseGammaMultivariateGaussian::simulate() {
  #line 23 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch", 23);
  #line 24 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    birch::handle_assume(this->σ2, birch::InverseGamma(this->α, this->β));
;
  #line 25 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    birch::handle_assume(this->μ, birch::Gaussian(this->μ_0, this->A, this->σ2));
;
  #line 26 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
    birch::handle_assume(this->x, birch::Gaussian(this->μ, this->σ2));
;
}

#line 29 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestMultivariateNormalInverseGammaMultivariateGaussian::forward() {
  #line 29 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch", 29);
  #line 30 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(11)));
  #line 31 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y(birch::type::Integer(1)) = this->σ2->value();
  #line 32 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(2), birch::type::Integer(6))) = this->μ->value();
  #line 33 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(7), birch::type::Integer(11))) = this->x->value();
  #line 34 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return y;
}

#line 37 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestMultivariateNormalInverseGammaMultivariateGaussian::backward() {
  #line 37 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch", 37);
  #line 38 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(11)));
  #line 39 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 40 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(7), birch::type::Integer(11))) = this->x->value();
  #line 41 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_assert_(!(this->μ->hasValue()));
  #line 42 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(2), birch::type::Integer(6))) = this->μ->value();
  #line 43 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_assert_(!(this->σ2->hasValue()));
  #line 44 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y(birch::type::Integer(1)) = this->σ2->value();
  #line 45 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return y;
}

#line 48 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestMultivariateNormalInverseGammaMultivariateGaussian::forwardLazy() {
  #line 48 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch", 48);
  #line 49 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(49);
  #line 49 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(11)));
  #line 50 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(50);
  #line 50 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y(birch::type::Integer(1)) = this->σ2->get();
  #line 51 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(51);
  #line 51 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(2), birch::type::Integer(6))) = this->μ->get();
  #line 52 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(7), birch::type::Integer(11))) = this->x->get();
  #line 53 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(53);
  #line 53 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return y;
}

#line 56 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestMultivariateNormalInverseGammaMultivariateGaussian::backwardLazy() {
  #line 56 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch", 56);
  #line 57 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(57);
  #line 57 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(11)));
  #line 58 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(58);
  #line 58 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 59 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(59);
  #line 59 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(7), birch::type::Integer(11))) = this->x->get();
  #line 60 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(60);
  #line 60 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_assert_(!(this->μ->hasValue()));
  #line 61 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(61);
  #line 61 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y(libbirch::make_range(birch::type::Integer(2), birch::type::Integer(6))) = this->μ->get();
  #line 62 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(62);
  #line 62 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_assert_(!(this->σ2->hasValue()));
  #line 63 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(63);
  #line 63 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  y(birch::type::Integer(1)) = this->σ2->get();
  #line 64 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(64);
  #line 64 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return y;
}

#line 67 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>> birch::type::TestMultivariateNormalInverseGammaMultivariateGaussian::marginal() {
  #line 67 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch", 67);
  #line 68 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(68);
  #line 68 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return this->x->distribution().value();
}

#line 1 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::TestMultivariateNormalInverseGammaMultivariateGaussian* birch::type::make_TestMultivariateNormalInverseGammaMultivariateGaussian_() {
  #line 1 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return new birch::type::TestMultivariateNormalInverseGammaMultivariateGaussian();
  #line 1 "src/test/model/TestMultivariateNormalInverseGammaMultivariateGaussian.birch"
}

#line 1 "src/test/model/TestNormalInverseGamma.birch"
birch::type::TestNormalInverseGamma::TestNormalInverseGamma() :
    #line 1 "src/test/model/TestNormalInverseGamma.birch"
    base_type_(),
    #line 2 "src/test/model/TestNormalInverseGamma.birch"
    σ2(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 3 "src/test/model/TestNormalInverseGamma.birch"
    x(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 5 "src/test/model/TestNormalInverseGamma.birch"
    μ(libbirch::make<birch::type::Real>()),
    #line 6 "src/test/model/TestNormalInverseGamma.birch"
    a2(libbirch::make<birch::type::Real>()),
    #line 7 "src/test/model/TestNormalInverseGamma.birch"
    α(libbirch::make<birch::type::Real>()),
    #line 8 "src/test/model/TestNormalInverseGamma.birch"
    β(libbirch::make<birch::type::Real>()) {
  //
}

#line 10 "src/test/model/TestNormalInverseGamma.birch"
void birch::type::TestNormalInverseGamma::initialize() {
  #line 10 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_function_("initialize", "src/test/model/TestNormalInverseGamma.birch", 10);
  #line 11 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(11);
  #line 11 "src/test/model/TestNormalInverseGamma.birch"
  this->μ = birch::simulate_uniform(-(10.0), 10.0);
  #line 12 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestNormalInverseGamma.birch"
  this->a2 = birch::simulate_uniform(0.1, 2.0);
  #line 13 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestNormalInverseGamma.birch"
  this->α = birch::simulate_uniform(2.0, 10.0);
  #line 14 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestNormalInverseGamma.birch"
  this->β = birch::simulate_uniform(0.1, 10.0);
}

#line 17 "src/test/model/TestNormalInverseGamma.birch"
void birch::type::TestNormalInverseGamma::simulate() {
  #line 17 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_function_("simulate", "src/test/model/TestNormalInverseGamma.birch", 17);
  #line 18 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestNormalInverseGamma.birch"
    birch::handle_assume(this->σ2, birch::InverseGamma(this->α, this->β));
;
  #line 19 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestNormalInverseGamma.birch"
    birch::handle_assume(this->x, birch::Gaussian(this->μ, this->a2, this->σ2));
;
}

#line 22 "src/test/model/TestNormalInverseGamma.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNormalInverseGamma::forward() {
  #line 22 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_function_("forward", "src/test/model/TestNormalInverseGamma.birch", 22);
  #line 23 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(23);
  #line 23 "src/test/model/TestNormalInverseGamma.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 24 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestNormalInverseGamma.birch"
  y(birch::type::Integer(1)) = this->σ2->value();
  #line 25 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestNormalInverseGamma.birch"
  y(birch::type::Integer(2)) = this->x->value();
  #line 26 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestNormalInverseGamma.birch"
  return y;
}

#line 29 "src/test/model/TestNormalInverseGamma.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNormalInverseGamma::backward() {
  #line 29 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_function_("backward", "src/test/model/TestNormalInverseGamma.birch", 29);
  #line 30 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestNormalInverseGamma.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 31 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(31);
  #line 31 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 32 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(32);
  #line 32 "src/test/model/TestNormalInverseGamma.birch"
  y(birch::type::Integer(2)) = this->x->value();
  #line 33 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_assert_(!(this->σ2->hasValue()));
  #line 34 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestNormalInverseGamma.birch"
  y(birch::type::Integer(1)) = this->σ2->value();
  #line 35 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestNormalInverseGamma.birch"
  return y;
}

#line 38 "src/test/model/TestNormalInverseGamma.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNormalInverseGamma::forwardLazy() {
  #line 38 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestNormalInverseGamma.birch", 38);
  #line 39 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestNormalInverseGamma.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 40 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestNormalInverseGamma.birch"
  y(birch::type::Integer(1)) = this->σ2->get();
  #line 41 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestNormalInverseGamma.birch"
  y(birch::type::Integer(2)) = this->x->get();
  #line 42 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestNormalInverseGamma.birch"
  return y;
}

#line 45 "src/test/model/TestNormalInverseGamma.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNormalInverseGamma::backwardLazy() {
  #line 45 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestNormalInverseGamma.birch", 45);
  #line 46 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestNormalInverseGamma.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 47 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 48 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(48);
  #line 48 "src/test/model/TestNormalInverseGamma.birch"
  y(birch::type::Integer(2)) = this->x->get();
  #line 49 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(49);
  #line 49 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_assert_(!(this->σ2->hasValue()));
  #line 50 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(50);
  #line 50 "src/test/model/TestNormalInverseGamma.birch"
  y(birch::type::Integer(1)) = this->σ2->get();
  #line 51 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(51);
  #line 51 "src/test/model/TestNormalInverseGamma.birch"
  return y;
}

#line 54 "src/test/model/TestNormalInverseGamma.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::type::TestNormalInverseGamma::marginal() {
  #line 54 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_function_("marginal", "src/test/model/TestNormalInverseGamma.birch", 54);
  #line 55 "src/test/model/TestNormalInverseGamma.birch"
  libbirch_line_(55);
  #line 55 "src/test/model/TestNormalInverseGamma.birch"
  return this->x->distribution().value();
}

#line 1 "src/test/model/TestNormalInverseGamma.birch"
birch::type::TestNormalInverseGamma* birch::type::make_TestNormalInverseGamma_() {
  #line 1 "src/test/model/TestNormalInverseGamma.birch"
  return new birch::type::TestNormalInverseGamma();
  #line 1 "src/test/model/TestNormalInverseGamma.birch"
}

#line 1 "src/test/model/TestNormalInverseGammaGaussian.birch"
birch::type::TestNormalInverseGammaGaussian::TestNormalInverseGammaGaussian() :
    #line 1 "src/test/model/TestNormalInverseGammaGaussian.birch"
    base_type_(),
    #line 2 "src/test/model/TestNormalInverseGammaGaussian.birch"
    σ2(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 3 "src/test/model/TestNormalInverseGammaGaussian.birch"
    μ(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 4 "src/test/model/TestNormalInverseGammaGaussian.birch"
    x(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 6 "src/test/model/TestNormalInverseGammaGaussian.birch"
    μ_0(libbirch::make<birch::type::Real>()),
    #line 7 "src/test/model/TestNormalInverseGammaGaussian.birch"
    a2(libbirch::make<birch::type::Real>()),
    #line 8 "src/test/model/TestNormalInverseGammaGaussian.birch"
    α(libbirch::make<birch::type::Real>()),
    #line 9 "src/test/model/TestNormalInverseGammaGaussian.birch"
    β(libbirch::make<birch::type::Real>()) {
  //
}

#line 11 "src/test/model/TestNormalInverseGammaGaussian.birch"
void birch::type::TestNormalInverseGammaGaussian::initialize() {
  #line 11 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_function_("initialize", "src/test/model/TestNormalInverseGammaGaussian.birch", 11);
  #line 12 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestNormalInverseGammaGaussian.birch"
  this->μ_0 = birch::simulate_uniform(-(10.0), 10.0);
  #line 13 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestNormalInverseGammaGaussian.birch"
  this->a2 = birch::simulate_uniform(0.0, 2.0);
  #line 14 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestNormalInverseGammaGaussian.birch"
  this->α = birch::simulate_uniform(2.0, 10.0);
  #line 15 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(15);
  #line 15 "src/test/model/TestNormalInverseGammaGaussian.birch"
  this->β = birch::simulate_uniform(0.1, 10.0);
}

#line 18 "src/test/model/TestNormalInverseGammaGaussian.birch"
void birch::type::TestNormalInverseGammaGaussian::simulate() {
  #line 18 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_function_("simulate", "src/test/model/TestNormalInverseGammaGaussian.birch", 18);
  #line 19 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestNormalInverseGammaGaussian.birch"
    birch::handle_assume(this->σ2, birch::InverseGamma(this->α, this->β));
;
  #line 20 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestNormalInverseGammaGaussian.birch"
    birch::handle_assume(this->μ, birch::Gaussian(this->μ_0, this->a2, this->σ2));
;
  #line 21 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(21);
  #line 21 "src/test/model/TestNormalInverseGammaGaussian.birch"
    birch::handle_assume(this->x, birch::Gaussian(this->μ, this->σ2));
;
}

#line 24 "src/test/model/TestNormalInverseGammaGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNormalInverseGammaGaussian::forward() {
  #line 24 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_function_("forward", "src/test/model/TestNormalInverseGammaGaussian.birch", 24);
  #line 25 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(3)));
  #line 26 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(1)) = this->σ2->value();
  #line 27 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(2)) = this->μ->value();
  #line 28 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(3)) = this->x->value();
  #line 29 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestNormalInverseGammaGaussian.birch"
  return y;
}

#line 32 "src/test/model/TestNormalInverseGammaGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNormalInverseGammaGaussian::backward() {
  #line 32 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_function_("backward", "src/test/model/TestNormalInverseGammaGaussian.birch", 32);
  #line 33 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(33);
  #line 33 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(3)));
  #line 34 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 35 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(3)) = this->x->value();
  #line 36 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_assert_(!(this->μ->hasValue()));
  #line 37 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(2)) = this->μ->value();
  #line 38 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_assert_(!(this->σ2->hasValue()));
  #line 39 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(1)) = this->σ2->value();
  #line 40 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(40);
  #line 40 "src/test/model/TestNormalInverseGammaGaussian.birch"
  return y;
}

#line 43 "src/test/model/TestNormalInverseGammaGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNormalInverseGammaGaussian::forwardLazy() {
  #line 43 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestNormalInverseGammaGaussian.birch", 43);
  #line 44 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(3)));
  #line 45 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(1)) = this->σ2->get();
  #line 46 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(2)) = this->μ->get();
  #line 47 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(3)) = this->x->get();
  #line 48 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(48);
  #line 48 "src/test/model/TestNormalInverseGammaGaussian.birch"
  return y;
}

#line 51 "src/test/model/TestNormalInverseGammaGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestNormalInverseGammaGaussian::backwardLazy() {
  #line 51 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestNormalInverseGammaGaussian.birch", 51);
  #line 52 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(52);
  #line 52 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(3)));
  #line 53 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(53);
  #line 53 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 54 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(54);
  #line 54 "src/test/model/TestNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(3)) = this->x->get();
  #line 55 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(55);
  #line 55 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_assert_(!(this->μ->hasValue()));
  #line 56 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(56);
  #line 56 "src/test/model/TestNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(2)) = this->μ->get();
  #line 57 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(57);
  #line 57 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_assert_(!(this->σ2->hasValue()));
  #line 58 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(58);
  #line 58 "src/test/model/TestNormalInverseGammaGaussian.birch"
  y(birch::type::Integer(1)) = this->σ2->get();
  #line 59 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(59);
  #line 59 "src/test/model/TestNormalInverseGammaGaussian.birch"
  return y;
}

#line 62 "src/test/model/TestNormalInverseGammaGaussian.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::type::TestNormalInverseGammaGaussian::marginal() {
  #line 62 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_function_("marginal", "src/test/model/TestNormalInverseGammaGaussian.birch", 62);
  #line 63 "src/test/model/TestNormalInverseGammaGaussian.birch"
  libbirch_line_(63);
  #line 63 "src/test/model/TestNormalInverseGammaGaussian.birch"
  return this->x->distribution().value();
}

#line 1 "src/test/model/TestNormalInverseGammaGaussian.birch"
birch::type::TestNormalInverseGammaGaussian* birch::type::make_TestNormalInverseGammaGaussian_() {
  #line 1 "src/test/model/TestNormalInverseGammaGaussian.birch"
  return new birch::type::TestNormalInverseGammaGaussian();
  #line 1 "src/test/model/TestNormalInverseGammaGaussian.birch"
}

#line 1 "src/test/model/TestScaledGammaExponential.birch"
birch::type::TestScaledGammaExponential::TestScaledGammaExponential() :
    #line 1 "src/test/model/TestScaledGammaExponential.birch"
    base_type_(),
    #line 2 "src/test/model/TestScaledGammaExponential.birch"
    λ(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 3 "src/test/model/TestScaledGammaExponential.birch"
    x(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 5 "src/test/model/TestScaledGammaExponential.birch"
    a(libbirch::make<birch::type::Real>()),
    #line 6 "src/test/model/TestScaledGammaExponential.birch"
    k(libbirch::make<birch::type::Real>()),
    #line 7 "src/test/model/TestScaledGammaExponential.birch"
    θ(libbirch::make<birch::type::Real>()),
    #line 8 "src/test/model/TestScaledGammaExponential.birch"
    neg(libbirch::make<birch::type::Boolean>()) {
  //
}

#line 10 "src/test/model/TestScaledGammaExponential.birch"
void birch::type::TestScaledGammaExponential::initialize() {
  #line 10 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_function_("initialize", "src/test/model/TestScaledGammaExponential.birch", 10);
  #line 11 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(11);
  #line 11 "src/test/model/TestScaledGammaExponential.birch"
  this->a = birch::simulate_uniform(0.0, 10.0);
  #line 12 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestScaledGammaExponential.birch"
  this->k = birch::simulate_uniform(2.1, 10.0);
  #line 13 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestScaledGammaExponential.birch"
  this->θ = birch::simulate_uniform(0.1, 10.0);
  #line 14 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestScaledGammaExponential.birch"
  this->neg = birch::simulate_bernoulli(0.5);
}

#line 17 "src/test/model/TestScaledGammaExponential.birch"
void birch::type::TestScaledGammaExponential::simulate() {
  #line 17 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_function_("simulate", "src/test/model/TestScaledGammaExponential.birch", 17);
  #line 18 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestScaledGammaExponential.birch"
    birch::handle_assume(this->λ, birch::Gamma(this->k, this->θ));
;
  #line 19 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestScaledGammaExponential.birch"
  if (this->neg) {
    #line 20 "src/test/model/TestScaledGammaExponential.birch"
    libbirch_line_(20);
    #line 20 "src/test/model/TestScaledGammaExponential.birch"
        birch::handle_assume(this->x, birch::Exponential(this->λ / this->a));
;
  } else {
    #line 22 "src/test/model/TestScaledGammaExponential.birch"
    libbirch_line_(22);
    #line 22 "src/test/model/TestScaledGammaExponential.birch"
        birch::handle_assume(this->x, birch::Exponential(this->a * this->λ));
;
  }
}

#line 26 "src/test/model/TestScaledGammaExponential.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestScaledGammaExponential::forward() {
  #line 26 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_function_("forward", "src/test/model/TestScaledGammaExponential.birch", 26);
  #line 27 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestScaledGammaExponential.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 28 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestScaledGammaExponential.birch"
  y(birch::type::Integer(1)) = this->λ->value();
  #line 29 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestScaledGammaExponential.birch"
  y(birch::type::Integer(2)) = this->x->value();
  #line 30 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestScaledGammaExponential.birch"
  return y;
}

#line 33 "src/test/model/TestScaledGammaExponential.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestScaledGammaExponential::backward() {
  #line 33 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_function_("backward", "src/test/model/TestScaledGammaExponential.birch", 33);
  #line 34 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestScaledGammaExponential.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 35 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 36 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestScaledGammaExponential.birch"
  y(birch::type::Integer(2)) = this->x->value();
  #line 37 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_assert_(!(this->λ->hasValue()));
  #line 38 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestScaledGammaExponential.birch"
  y(birch::type::Integer(1)) = this->λ->value();
  #line 39 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestScaledGammaExponential.birch"
  return y;
}

#line 42 "src/test/model/TestScaledGammaExponential.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestScaledGammaExponential::forwardLazy() {
  #line 42 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestScaledGammaExponential.birch", 42);
  #line 43 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestScaledGammaExponential.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 44 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestScaledGammaExponential.birch"
  y(birch::type::Integer(1)) = this->λ->get();
  #line 45 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestScaledGammaExponential.birch"
  y(birch::type::Integer(2)) = this->x->get();
  #line 46 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestScaledGammaExponential.birch"
  return y;
}

#line 49 "src/test/model/TestScaledGammaExponential.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestScaledGammaExponential::backwardLazy() {
  #line 49 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestScaledGammaExponential.birch", 49);
  #line 50 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(50);
  #line 50 "src/test/model/TestScaledGammaExponential.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 51 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(51);
  #line 51 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 52 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(52);
  #line 52 "src/test/model/TestScaledGammaExponential.birch"
  y(birch::type::Integer(2)) = this->x->get();
  #line 53 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(53);
  #line 53 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_assert_(!(this->λ->hasValue()));
  #line 54 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(54);
  #line 54 "src/test/model/TestScaledGammaExponential.birch"
  y(birch::type::Integer(1)) = this->λ->get();
  #line 55 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(55);
  #line 55 "src/test/model/TestScaledGammaExponential.birch"
  return y;
}

#line 58 "src/test/model/TestScaledGammaExponential.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Real>> birch::type::TestScaledGammaExponential::marginal() {
  #line 58 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_function_("marginal", "src/test/model/TestScaledGammaExponential.birch", 58);
  #line 59 "src/test/model/TestScaledGammaExponential.birch"
  libbirch_line_(59);
  #line 59 "src/test/model/TestScaledGammaExponential.birch"
  return this->x->distribution().value();
}

#line 1 "src/test/model/TestScaledGammaExponential.birch"
birch::type::TestScaledGammaExponential* birch::type::make_TestScaledGammaExponential_() {
  #line 1 "src/test/model/TestScaledGammaExponential.birch"
  return new birch::type::TestScaledGammaExponential();
  #line 1 "src/test/model/TestScaledGammaExponential.birch"
}

#line 1 "src/test/model/TestScaledGammaPoisson.birch"
birch::type::TestScaledGammaPoisson::TestScaledGammaPoisson() :
    #line 1 "src/test/model/TestScaledGammaPoisson.birch"
    base_type_(),
    #line 2 "src/test/model/TestScaledGammaPoisson.birch"
    λ(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>()),
    #line 3 "src/test/model/TestScaledGammaPoisson.birch"
    x(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Integer>>>()),
    #line 5 "src/test/model/TestScaledGammaPoisson.birch"
    a(libbirch::make<birch::type::Real>()),
    #line 6 "src/test/model/TestScaledGammaPoisson.birch"
    k(libbirch::make<birch::type::Real>()),
    #line 7 "src/test/model/TestScaledGammaPoisson.birch"
    θ(libbirch::make<birch::type::Real>()),
    #line 8 "src/test/model/TestScaledGammaPoisson.birch"
    neg(libbirch::make<birch::type::Boolean>()) {
  //
}

#line 10 "src/test/model/TestScaledGammaPoisson.birch"
void birch::type::TestScaledGammaPoisson::initialize() {
  #line 10 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_function_("initialize", "src/test/model/TestScaledGammaPoisson.birch", 10);
  #line 11 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(11);
  #line 11 "src/test/model/TestScaledGammaPoisson.birch"
  this->a = birch::simulate_uniform(0.0, 10.0);
  #line 12 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestScaledGammaPoisson.birch"
  this->k = birch::simulate_uniform_int(birch::type::Integer(1), birch::type::Integer(10));
  #line 13 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestScaledGammaPoisson.birch"
  this->θ = birch::simulate_uniform(0.0, 10.0);
  #line 14 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(14);
  #line 14 "src/test/model/TestScaledGammaPoisson.birch"
  this->neg = birch::simulate_bernoulli(0.5);
}

#line 17 "src/test/model/TestScaledGammaPoisson.birch"
void birch::type::TestScaledGammaPoisson::simulate() {
  #line 17 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_function_("simulate", "src/test/model/TestScaledGammaPoisson.birch", 17);
  #line 18 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestScaledGammaPoisson.birch"
    birch::handle_assume(this->λ, birch::Gamma(this->k, this->θ));
;
  #line 19 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestScaledGammaPoisson.birch"
  if (this->neg) {
    #line 20 "src/test/model/TestScaledGammaPoisson.birch"
    libbirch_line_(20);
    #line 20 "src/test/model/TestScaledGammaPoisson.birch"
        birch::handle_assume(this->x, birch::Poisson(this->λ / this->a));
;
  } else {
    #line 22 "src/test/model/TestScaledGammaPoisson.birch"
    libbirch_line_(22);
    #line 22 "src/test/model/TestScaledGammaPoisson.birch"
        birch::handle_assume(this->x, birch::Poisson(this->a * this->λ));
;
  }
}

#line 26 "src/test/model/TestScaledGammaPoisson.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestScaledGammaPoisson::forward() {
  #line 26 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_function_("forward", "src/test/model/TestScaledGammaPoisson.birch", 26);
  #line 27 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 28 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestScaledGammaPoisson.birch"
  y(birch::type::Integer(1)) = this->λ->value();
  #line 29 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestScaledGammaPoisson.birch"
  y(birch::type::Integer(2)) = this->x->value();
  #line 30 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestScaledGammaPoisson.birch"
  return y;
}

#line 33 "src/test/model/TestScaledGammaPoisson.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestScaledGammaPoisson::backward() {
  #line 33 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_function_("backward", "src/test/model/TestScaledGammaPoisson.birch", 33);
  #line 34 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 35 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 36 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestScaledGammaPoisson.birch"
  y(birch::type::Integer(2)) = this->x->value();
  #line 37 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_assert_(!(this->λ->hasValue()));
  #line 38 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(38);
  #line 38 "src/test/model/TestScaledGammaPoisson.birch"
  y(birch::type::Integer(1)) = this->λ->value();
  #line 39 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(39);
  #line 39 "src/test/model/TestScaledGammaPoisson.birch"
  return y;
}

#line 42 "src/test/model/TestScaledGammaPoisson.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestScaledGammaPoisson::forwardLazy() {
  #line 42 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestScaledGammaPoisson.birch", 42);
  #line 43 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 44 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestScaledGammaPoisson.birch"
  y(birch::type::Integer(1)) = this->λ->get();
  #line 45 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestScaledGammaPoisson.birch"
  y(birch::type::Integer(2)) = this->x->get();
  #line 46 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestScaledGammaPoisson.birch"
  return y;
}

#line 49 "src/test/model/TestScaledGammaPoisson.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestScaledGammaPoisson::backwardLazy() {
  #line 49 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestScaledGammaPoisson.birch", 49);
  #line 50 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(50);
  #line 50 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 51 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(51);
  #line 51 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_assert_(!(this->x->hasValue()));
  #line 52 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(52);
  #line 52 "src/test/model/TestScaledGammaPoisson.birch"
  y(birch::type::Integer(2)) = this->x->get();
  #line 53 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(53);
  #line 53 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_assert_(!(this->λ->hasValue()));
  #line 54 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(54);
  #line 54 "src/test/model/TestScaledGammaPoisson.birch"
  y(birch::type::Integer(1)) = this->λ->get();
  #line 55 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(55);
  #line 55 "src/test/model/TestScaledGammaPoisson.birch"
  return y;
}

#line 58 "src/test/model/TestScaledGammaPoisson.birch"
libbirch::Shared<birch::type::Distribution<birch::type::Integer>> birch::type::TestScaledGammaPoisson::marginal() {
  #line 58 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_function_("marginal", "src/test/model/TestScaledGammaPoisson.birch", 58);
  #line 59 "src/test/model/TestScaledGammaPoisson.birch"
  libbirch_line_(59);
  #line 59 "src/test/model/TestScaledGammaPoisson.birch"
  return this->x->distribution().value();
}

#line 1 "src/test/model/TestScaledGammaPoisson.birch"
birch::type::TestScaledGammaPoisson* birch::type::make_TestScaledGammaPoisson_() {
  #line 1 "src/test/model/TestScaledGammaPoisson.birch"
  return new birch::type::TestScaledGammaPoisson();
  #line 1 "src/test/model/TestScaledGammaPoisson.birch"
}

#line 1 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
birch::type::TestSubtractBoundedDiscreteDelta::TestSubtractBoundedDiscreteDelta() :
    #line 1 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
    base_type_(),
    #line 2 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
    x1(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Integer>>>()),
    #line 3 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
    x2(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Integer>>>()),
    #line 4 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
    s(libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Integer>>>()) {
  //
}

#line 6 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
void birch::type::TestSubtractBoundedDiscreteDelta::initialize() {
  #line 6 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_function_("initialize", "src/test/model/TestSubtractBoundedDiscreteDelta.birch", 6);
}

#line 10 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
void birch::type::TestSubtractBoundedDiscreteDelta::simulate() {
  #line 10 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_function_("simulate", "src/test/model/TestSubtractBoundedDiscreteDelta.birch", 10);
  #line 11 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(11);
  #line 11 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
    birch::handle_assume(this->x1, birch::Binomial(birch::type::Integer(100), 0.75));
;
  #line 12 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(12);
  #line 12 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
    birch::handle_assume(this->x2, birch::Binomial(birch::type::Integer(100), 0.25));
;
  #line 13 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(13);
  #line 13 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
    birch::handle_assume(this->s, birch::Delta(this->x1 - this->x2));
;
}

#line 16 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestSubtractBoundedDiscreteDelta::forward() {
  #line 16 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_function_("forward", "src/test/model/TestSubtractBoundedDiscreteDelta.birch", 16);
  #line 17 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(17);
  #line 17 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 18 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(18);
  #line 18 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  y(birch::type::Integer(1)) = this->x1->value();
  #line 19 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(19);
  #line 19 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  y(birch::type::Integer(2)) = this->x2->value();
  #line 20 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(20);
  #line 20 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  return y;
}

#line 23 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestSubtractBoundedDiscreteDelta::backward() {
  #line 23 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_function_("backward", "src/test/model/TestSubtractBoundedDiscreteDelta.birch", 23);
  #line 24 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(24);
  #line 24 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 25 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(25);
  #line 25 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  this->s->value();
  #line 26 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(26);
  #line 26 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_assert_(!(this->x1->hasValue()));
  #line 27 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(27);
  #line 27 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_assert_(!(this->x2->hasValue()));
  #line 28 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(28);
  #line 28 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  y(birch::type::Integer(2)) = this->x2->value();
  #line 29 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(29);
  #line 29 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  y(birch::type::Integer(1)) = this->x1->value();
  #line 30 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(30);
  #line 30 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  return y;
}

#line 33 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestSubtractBoundedDiscreteDelta::forwardLazy() {
  #line 33 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_function_("forwardLazy", "src/test/model/TestSubtractBoundedDiscreteDelta.birch", 33);
  #line 34 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(34);
  #line 34 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 35 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(35);
  #line 35 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  y(birch::type::Integer(1)) = this->x1->get();
  #line 36 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(36);
  #line 36 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  y(birch::type::Integer(2)) = this->x2->get();
  #line 37 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(37);
  #line 37 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  return y;
}

#line 40 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::TestSubtractBoundedDiscreteDelta::backwardLazy() {
  #line 40 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_function_("backwardLazy", "src/test/model/TestSubtractBoundedDiscreteDelta.birch", 40);
  #line 41 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(41);
  #line 41 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch::DefaultArray<birch::type::Real,1> y = libbirch::make_array<birch::type::Real>(libbirch::make_shape(birch::type::Integer(2)));
  #line 42 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(42);
  #line 42 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  this->s->get();
  #line 43 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(43);
  #line 43 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_assert_(!(this->x1->hasValue()));
  #line 44 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(44);
  #line 44 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_assert_(!(this->x2->hasValue()));
  #line 45 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(45);
  #line 45 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  y(birch::type::Integer(2)) = this->x2->get();
  #line 46 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(46);
  #line 46 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  y(birch::type::Integer(1)) = this->x1->get();
  #line 47 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  libbirch_line_(47);
  #line 47 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  return y;
}

#line 1 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
birch::type::TestSubtractBoundedDiscreteDelta* birch::type::make_TestSubtractBoundedDiscreteDelta_() {
  #line 1 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
  return new birch::type::TestSubtractBoundedDiscreteDelta();
  #line 1 "src/test/model/TestSubtractBoundedDiscreteDelta.birch"
}

