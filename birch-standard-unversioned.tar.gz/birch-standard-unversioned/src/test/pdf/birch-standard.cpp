#line 4 "src/test/pdf/test_pdf_bernoulli.birch"
int birch::test_pdf_bernoulli(int argc_, char** argv_) {
  #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
  libbirch_function_("test_pdf_bernoulli", "src/test/pdf/test_pdf_bernoulli.birch", 4);
  #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
  birch::type::Boolean lazy = false;
  
  enum {
    NFLAG_,
    lazyFLAG_,
  };
  #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
  int c_, option_index_;
  #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
  option long_options_[] = {
    #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
    {"lazy", required_argument, 0, lazyFLAG_ },
    #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
  };
  #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
  ::opterr = 0;
  #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
  while (c_ != -1) {
    #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
    switch (c_) {
      #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
      case NFLAG_:
        #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
      case lazyFLAG_:
        #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
        lazy = birch::Boolean(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
      case '?':
        #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
      case ':':
        #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
      default:
        #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/pdf/test_pdf_bernoulli.birch"
  libbirch_line_(5);
  #line 5 "src/test/pdf/test_pdf_bernoulli.birch"
  auto _u0961 = birch::simulate_uniform(0.0, 1.0, handler_);
  #line 6 "src/test/pdf/test_pdf_bernoulli.birch"
  libbirch_line_(6);
  #line 6 "src/test/pdf/test_pdf_bernoulli.birch"
  auto q = birch::Bernoulli(_u0961, handler_);
  #line 7 "src/test/pdf/test_pdf_bernoulli.birch"
  libbirch_line_(7);
  #line 7 "src/test/pdf/test_pdf_bernoulli.birch"
  birch::test_pdf(q, N, lazy, handler_);
  #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
  libbirch_line_(4);
  #line 4 "src/test/pdf/test_pdf_bernoulli.birch"
  return 0;
}

#line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
int birch::test_pdf_beta_bernoulli(int argc_, char** argv_) {
  #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
  libbirch_function_("test_pdf_beta_bernoulli", "src/test/pdf/test_pdf_beta_bernoulli.birch", 4);
  #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
  birch::type::Boolean lazy = false;
  
  enum {
    NFLAG_,
    lazyFLAG_,
  };
  #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
  int c_, option_index_;
  #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
  option long_options_[] = {
    #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
    {"lazy", required_argument, 0, lazyFLAG_ },
    #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
  };
  #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
  ::opterr = 0;
  #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
  while (c_ != -1) {
    #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
    switch (c_) {
      #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
      case NFLAG_:
        #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
      case lazyFLAG_:
        #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
        lazy = birch::Boolean(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
      case '?':
        #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
      case ':':
        #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
      default:
        #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/pdf/test_pdf_beta_bernoulli.birch"
  libbirch_line_(5);
  #line 5 "src/test/pdf/test_pdf_beta_bernoulli.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestBetaBernoulli>> m;
  #line 6 "src/test/pdf/test_pdf_beta_bernoulli.birch"
  libbirch_line_(6);
  #line 6 "src/test/pdf/test_pdf_beta_bernoulli.birch"
  m->initialize(handler_);
  #line 7 "src/test/pdf/test_pdf_beta_bernoulli.birch"
  libbirch_line_(7);
  #line 7 "src/test/pdf/test_pdf_beta_bernoulli.birch"
  m->simulate(handler_);
  #line 8 "src/test/pdf/test_pdf_beta_bernoulli.birch"
  libbirch_line_(8);
  #line 8 "src/test/pdf/test_pdf_beta_bernoulli.birch"
  birch::test_pdf(m->marginal(handler_), N, lazy, handler_);
  #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
  libbirch_line_(4);
  #line 4 "src/test/pdf/test_pdf_beta_bernoulli.birch"
  return 0;
}

#line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
int birch::test_pdf_beta_negative_binomial(int argc_, char** argv_) {
  #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
  libbirch_function_("test_pdf_beta_negative_binomial", "src/test/pdf/test_pdf_beta_negative_binomial.birch", 4);
  #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
  birch::type::Boolean lazy = false;
  
  enum {
    NFLAG_,
    lazyFLAG_,
  };
  #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
  int c_, option_index_;
  #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
  option long_options_[] = {
    #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
    {"lazy", required_argument, 0, lazyFLAG_ },
    #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
  };
  #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
  ::opterr = 0;
  #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
  while (c_ != -1) {
    #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
    switch (c_) {
      #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
      case NFLAG_:
        #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
      case lazyFLAG_:
        #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
        lazy = birch::Boolean(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
      case '?':
        #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
      case ':':
        #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
      default:
        #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
  libbirch_line_(5);
  #line 5 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestBetaNegativeBinomial>> m;
  #line 6 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
  libbirch_line_(6);
  #line 6 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
  m->initialize(handler_);
  #line 7 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
  libbirch_line_(7);
  #line 7 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
  m->simulate(handler_);
  #line 8 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
  libbirch_line_(8);
  #line 8 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
  birch::test_pdf(m->marginal(handler_), N, lazy, handler_);
  #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
  libbirch_line_(4);
  #line 4 "src/test/pdf/test_pdf_beta_negative_binomial.birch"
  return 0;
}

#line 4 "src/test/pdf/test_pdf_categorical.birch"
int birch::test_pdf_categorical(int argc_, char** argv_) {
  #line 4 "src/test/pdf/test_pdf_categorical.birch"
  libbirch_function_("test_pdf_categorical", "src/test/pdf/test_pdf_categorical.birch", 4);
  #line 4 "src/test/pdf/test_pdf_categorical.birch"
  birch::type::Integer D = birch::type::Integer(10);
  #line 4 "src/test/pdf/test_pdf_categorical.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  #line 4 "src/test/pdf/test_pdf_categorical.birch"
  birch::type::Boolean lazy = false;
  
  enum {
    DFLAG_,
    NFLAG_,
    lazyFLAG_,
  };
  #line 4 "src/test/pdf/test_pdf_categorical.birch"
  int c_, option_index_;
  #line 4 "src/test/pdf/test_pdf_categorical.birch"
  option long_options_[] = {
    #line 4 "src/test/pdf/test_pdf_categorical.birch"
    {"D", required_argument, 0, DFLAG_ },
    #line 4 "src/test/pdf/test_pdf_categorical.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/pdf/test_pdf_categorical.birch"
    {"lazy", required_argument, 0, lazyFLAG_ },
    #line 4 "src/test/pdf/test_pdf_categorical.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/pdf/test_pdf_categorical.birch"
  };
  #line 4 "src/test/pdf/test_pdf_categorical.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/pdf/test_pdf_categorical.birch"
  ::opterr = 0;
  #line 4 "src/test/pdf/test_pdf_categorical.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/pdf/test_pdf_categorical.birch"
  while (c_ != -1) {
    #line 4 "src/test/pdf/test_pdf_categorical.birch"
    switch (c_) {
      #line 4 "src/test/pdf/test_pdf_categorical.birch"
      case DFLAG_:
        #line 4 "src/test/pdf/test_pdf_categorical.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/pdf/test_pdf_categorical.birch"
        D = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_categorical.birch"
      case NFLAG_:
        #line 4 "src/test/pdf/test_pdf_categorical.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/pdf/test_pdf_categorical.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_categorical.birch"
      case lazyFLAG_:
        #line 4 "src/test/pdf/test_pdf_categorical.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/pdf/test_pdf_categorical.birch"
        lazy = birch::Boolean(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_categorical.birch"
      case '?':
        #line 4 "src/test/pdf/test_pdf_categorical.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/pdf/test_pdf_categorical.birch"
      case ':':
        #line 4 "src/test/pdf/test_pdf_categorical.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/pdf/test_pdf_categorical.birch"
      default:
        #line 4 "src/test/pdf/test_pdf_categorical.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/pdf/test_pdf_categorical.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/pdf/test_pdf_categorical.birch"
  libbirch_line_(5);
  #line 5 "src/test/pdf/test_pdf_categorical.birch"
  auto _u0961 = birch::simulate_dirichlet(birch::simulate_uniform(1.0, 10.0, handler_), D, handler_);
  #line 6 "src/test/pdf/test_pdf_categorical.birch"
  libbirch_line_(6);
  #line 6 "src/test/pdf/test_pdf_categorical.birch"
  auto _u0960 = birch::Categorical(_u0961, handler_);
  #line 7 "src/test/pdf/test_pdf_categorical.birch"
  libbirch_line_(7);
  #line 7 "src/test/pdf/test_pdf_categorical.birch"
  if (lazy) {
    #line 8 "src/test/pdf/test_pdf_categorical.birch"
    libbirch_line_(8);
    #line 8 "src/test/pdf/test_pdf_categorical.birch"
    birch::warn(birch::type::String("lazy not supported, reverting to eager."), handler_);
  }
  #line 10 "src/test/pdf/test_pdf_categorical.birch"
  libbirch_line_(10);
  #line 10 "src/test/pdf/test_pdf_categorical.birch"
  birch::test_pdf(_u0960, N, false, handler_);
  #line 4 "src/test/pdf/test_pdf_categorical.birch"
  libbirch_line_(4);
  #line 4 "src/test/pdf/test_pdf_categorical.birch"
  return 0;
}

#line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
int birch::test_pdf_dirichlet_categorical(int argc_, char** argv_) {
  #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
  libbirch_function_("test_pdf_dirichlet_categorical", "src/test/pdf/test_pdf_dirichlet_categorical.birch", 4);
  #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
  birch::type::Boolean lazy = false;
  
  enum {
    NFLAG_,
    lazyFLAG_,
  };
  #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
  int c_, option_index_;
  #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
  option long_options_[] = {
    #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
    {"lazy", required_argument, 0, lazyFLAG_ },
    #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
  };
  #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
  ::opterr = 0;
  #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
  while (c_ != -1) {
    #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
    switch (c_) {
      #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
      case NFLAG_:
        #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
      case lazyFLAG_:
        #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
        lazy = birch::Boolean(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
      case '?':
        #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
      case ':':
        #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
      default:
        #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
  libbirch_line_(5);
  #line 5 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestDirichletCategorical>> m;
  #line 6 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
  libbirch_line_(6);
  #line 6 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
  m->initialize(handler_);
  #line 7 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
  libbirch_line_(7);
  #line 7 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
  m->simulate(handler_);
  #line 8 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
  libbirch_line_(8);
  #line 8 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
  if (lazy) {
    #line 9 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
    libbirch_line_(9);
    #line 9 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
    birch::warn(birch::type::String("lazy not supported, reverting to eager."), handler_);
  }
  #line 11 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
  libbirch_line_(11);
  #line 11 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
  birch::test_pdf(m->marginal(handler_), N, false, handler_);
  #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
  libbirch_line_(4);
  #line 4 "src/test/pdf/test_pdf_dirichlet_categorical.birch"
  return 0;
}

#line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
int birch::test_pdf_linear_discrete_delta(int argc_, char** argv_) {
  #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
  libbirch_function_("test_pdf_linear_discrete_delta", "src/test/pdf/test_pdf_linear_discrete_delta.birch", 4);
  #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
  birch::type::Boolean lazy = false;
  
  enum {
    NFLAG_,
    lazyFLAG_,
  };
  #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
  int c_, option_index_;
  #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
  option long_options_[] = {
    #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
    {"lazy", required_argument, 0, lazyFLAG_ },
    #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
  };
  #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
  ::opterr = 0;
  #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
  while (c_ != -1) {
    #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
    switch (c_) {
      #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
      case NFLAG_:
        #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
      case lazyFLAG_:
        #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
        lazy = birch::Boolean(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
      case '?':
        #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
      case ':':
        #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
      default:
        #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
  libbirch_line_(5);
  #line 5 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestLinearDiscreteDelta>> m;
  #line 6 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
  libbirch_line_(6);
  #line 6 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
  m->initialize(handler_);
  #line 7 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
  libbirch_line_(7);
  #line 7 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
  m->simulate(handler_);
  #line 8 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
  libbirch_line_(8);
  #line 8 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
  if (lazy) {
    #line 9 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
    libbirch_line_(9);
    #line 9 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
    birch::warn(birch::type::String("lazy not supported, reverting to eager."), handler_);
  }
  #line 11 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
  libbirch_line_(11);
  #line 11 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
  birch::test_pdf(m->marginal(handler_), N, false, handler_);
  #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
  libbirch_line_(4);
  #line 4 "src/test/pdf/test_pdf_linear_discrete_delta.birch"
  return 0;
}

#line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
int birch::test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_function_("test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian", "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch", 4);
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  birch::type::Integer B = birch::type::Integer(500);
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  birch::type::Integer S = birch::type::Integer(30);
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  birch::type::Boolean lazy = false;
  
  enum {
    NFLAG_,
    BFLAG_,
    SFLAG_,
    lazyFLAG_,
  };
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    {"B", required_argument, 0, BFLAG_ },
    #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    {"S", required_argument, 0, SFLAG_ },
    #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    {"lazy", required_argument, 0, lazyFLAG_ },
    #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  };
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case BFLAG_:
        #line 5 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        B = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case SFLAG_:
        #line 5 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        S = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case lazyFLAG_:
        #line 5 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        lazy = birch::Boolean(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case '?':
        #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case ':':
        #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      default:
        #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian>> m;
  #line 7 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  m->initialize(handler_);
  #line 8 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_line_(8);
  #line 8 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  m->simulate(handler_);
  #line 9 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_line_(9);
  #line 9 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  birch::test_pdf(m->marginal(handler_), birch::type::Integer(5), birch::type::Integer(2), N, B, S, lazy, handler_);
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  return 0;
}

#line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
int birch::test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  libbirch_function_("test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian", "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch", 4);
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  birch::type::Integer B = birch::type::Integer(500);
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  birch::type::Integer S = birch::type::Integer(20);
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  birch::type::Boolean lazy = false;
  
  enum {
    NFLAG_,
    BFLAG_,
    SFLAG_,
    lazyFLAG_,
  };
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
    {"B", required_argument, 0, BFLAG_ },
    #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
    {"S", required_argument, 0, SFLAG_ },
    #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
    {"lazy", required_argument, 0, lazyFLAG_ },
    #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  };
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
      case BFLAG_:
        #line 5 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
        B = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
      case SFLAG_:
        #line 5 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
        S = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
      case lazyFLAG_:
        #line 5 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
        lazy = birch::Boolean(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
      case '?':
        #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
      case ':':
        #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
      default:
        #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestLinearMatrixNormalInverseWishartMultivariateGaussian>> m;
  #line 7 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  m->initialize(handler_);
  #line 8 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  libbirch_line_(8);
  #line 8 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  m->simulate(handler_);
  #line 9 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  libbirch_line_(9);
  #line 9 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  birch::test_pdf(m->marginal(handler_), birch::type::Integer(2), N, B, S, lazy, handler_);
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/pdf/test_pdf_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  return 0;
}

#line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
int birch::test_pdf_linear_multivariate_gaussian_multivariate_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_function_("test_pdf_linear_multivariate_gaussian_multivariate_gaussian", "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch", 4);
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
  birch::type::Integer B = birch::type::Integer(500);
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
  birch::type::Integer S = birch::type::Integer(20);
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
  birch::type::Boolean lazy = false;
  
  enum {
    NFLAG_,
    BFLAG_,
    SFLAG_,
    lazyFLAG_,
  };
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
    {"B", required_argument, 0, BFLAG_ },
    #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
    {"S", required_argument, 0, SFLAG_ },
    #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
    {"lazy", required_argument, 0, lazyFLAG_ },
    #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
  };
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
      case BFLAG_:
        #line 5 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
        B = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
      case SFLAG_:
        #line 5 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
        S = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
      case lazyFLAG_:
        #line 5 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
        lazy = birch::Boolean(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
      case '?':
        #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
      case ':':
        #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
      default:
        #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestLinearMultivariateGaussianMultivariateGaussian>> m;
  #line 7 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
  m->initialize(handler_);
  #line 8 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_line_(8);
  #line 8 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
  m->simulate(handler_);
  #line 9 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_line_(9);
  #line 9 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
  birch::test_pdf(m->marginal(handler_), birch::type::Integer(5), N, B, S, lazy, handler_);
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_gaussian_multivariate_gaussian.birch"
  return 0;
}

#line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
int birch::test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_function_("test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch", 4);
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  birch::type::Integer B = birch::type::Integer(500);
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  birch::type::Integer S = birch::type::Integer(20);
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  birch::type::Boolean lazy = false;
  
  enum {
    NFLAG_,
    BFLAG_,
    SFLAG_,
    lazyFLAG_,
  };
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    {"B", required_argument, 0, BFLAG_ },
    #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    {"S", required_argument, 0, SFLAG_ },
    #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    {"lazy", required_argument, 0, lazyFLAG_ },
    #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  };
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case BFLAG_:
        #line 5 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        B = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case SFLAG_:
        #line 5 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        S = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case lazyFLAG_:
        #line 5 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        lazy = birch::Boolean(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case '?':
        #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case ':':
        #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      default:
        #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestLinearMultivariateNormalInverseGammaMultivariateGaussian>> m;
  #line 7 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  m->initialize(handler_);
  #line 8 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_line_(8);
  #line 8 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  m->simulate(handler_);
  #line 9 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_line_(9);
  #line 9 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  birch::test_pdf(m->marginal(handler_), birch::type::Integer(5), N, B, S, lazy, handler_);
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/pdf/test_pdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  return 0;
}

#line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
int birch::test_pdf_matrix_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  libbirch_function_("test_pdf_matrix_gaussian", "src/test/pdf/test_pdf_matrix_gaussian.birch", 4);
  #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  birch::type::Integer R = birch::type::Integer(4);
  #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  birch::type::Integer C = birch::type::Integer(3);
  #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  birch::type::Integer B = birch::type::Integer(500);
  #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  birch::type::Integer S = birch::type::Integer(30);
  #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  birch::type::Boolean lazy = false;
  
  enum {
    RFLAG_,
    CFLAG_,
    NFLAG_,
    BFLAG_,
    SFLAG_,
    lazyFLAG_,
  };
  #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
    {"R", required_argument, 0, RFLAG_ },
    #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
    {"C", required_argument, 0, CFLAG_ },
    #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
    {"B", required_argument, 0, BFLAG_ },
    #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
    {"S", required_argument, 0, SFLAG_ },
    #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
    {"lazy", required_argument, 0, lazyFLAG_ },
    #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  };
  #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
      case RFLAG_:
        #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
        R = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
      case CFLAG_:
        #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
        C = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_matrix_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/pdf/test_pdf_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_matrix_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_matrix_gaussian.birch"
      case BFLAG_:
        #line 5 "src/test/pdf/test_pdf_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_matrix_gaussian.birch"
        B = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_matrix_gaussian.birch"
      case SFLAG_:
        #line 5 "src/test/pdf/test_pdf_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_matrix_gaussian.birch"
        S = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_matrix_gaussian.birch"
      case lazyFLAG_:
        #line 5 "src/test/pdf/test_pdf_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_matrix_gaussian.birch"
        lazy = birch::Boolean(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
      case '?':
        #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
      case ':':
        #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
      default:
        #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  libbirch::DefaultArray<birch::type::Real,2> M(libbirch::make_shape(R, C));
  #line 7 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  libbirch::DefaultArray<birch::type::Real,2> U(libbirch::make_shape(R, R));
  #line 8 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  libbirch_line_(8);
  #line 8 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  libbirch::DefaultArray<birch::type::Real,2> V(libbirch::make_shape(C, C));
  #line 10 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  libbirch_line_(10);
  #line 10 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  for (auto i = birch::type::Integer(1); i <= R; ++i) {
    #line 11 "src/test/pdf/test_pdf_matrix_gaussian.birch"
    libbirch_line_(11);
    #line 11 "src/test/pdf/test_pdf_matrix_gaussian.birch"
    for (auto j = birch::type::Integer(1); j <= C; ++j) {
      #line 12 "src/test/pdf/test_pdf_matrix_gaussian.birch"
      libbirch_line_(12);
      #line 12 "src/test/pdf/test_pdf_matrix_gaussian.birch"
      M.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    }
  }
  #line 15 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  libbirch_line_(15);
  #line 15 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  for (auto i = birch::type::Integer(1); i <= R; ++i) {
    #line 16 "src/test/pdf/test_pdf_matrix_gaussian.birch"
    libbirch_line_(16);
    #line 16 "src/test/pdf/test_pdf_matrix_gaussian.birch"
    for (auto j = birch::type::Integer(1); j <= R; ++j) {
      #line 17 "src/test/pdf/test_pdf_matrix_gaussian.birch"
      libbirch_line_(17);
      #line 17 "src/test/pdf/test_pdf_matrix_gaussian.birch"
      U.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
    }
  }
  #line 20 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  libbirch_line_(20);
  #line 20 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  for (auto i = birch::type::Integer(1); i <= C; ++i) {
    #line 21 "src/test/pdf/test_pdf_matrix_gaussian.birch"
    libbirch_line_(21);
    #line 21 "src/test/pdf/test_pdf_matrix_gaussian.birch"
    for (auto j = birch::type::Integer(1); j <= C; ++j) {
      #line 22 "src/test/pdf/test_pdf_matrix_gaussian.birch"
      libbirch_line_(22);
      #line 22 "src/test/pdf/test_pdf_matrix_gaussian.birch"
      V.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
    }
  }
  #line 25 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  libbirch_line_(25);
  #line 25 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  U = U * birch::transpose(U, handler_);
  #line 26 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  libbirch_line_(26);
  #line 26 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  V = V * birch::transpose(V, handler_);
  #line 28 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  libbirch_line_(28);
  #line 28 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  auto _u0960 = birch::Gaussian(M, U, V, handler_);
  #line 29 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  libbirch_line_(29);
  #line 29 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  birch::test_pdf(_u0960, R, C, N, B, S, lazy, handler_);
  #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/pdf/test_pdf_matrix_gaussian.birch"
  return 0;
}

#line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
int birch::test_pdf_matrix_normal_inverse_wishart(int argc_, char** argv_) {
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  libbirch_function_("test_pdf_matrix_normal_inverse_wishart", "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch", 4);
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  birch::type::Integer R = birch::type::Integer(3);
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  birch::type::Integer C = birch::type::Integer(2);
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  birch::type::Integer B = birch::type::Integer(500);
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  birch::type::Integer S = birch::type::Integer(30);
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  birch::type::Boolean lazy = false;
  
  enum {
    RFLAG_,
    CFLAG_,
    NFLAG_,
    BFLAG_,
    SFLAG_,
    lazyFLAG_,
  };
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  int c_, option_index_;
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  option long_options_[] = {
    #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
    {"R", required_argument, 0, RFLAG_ },
    #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
    {"C", required_argument, 0, CFLAG_ },
    #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
    {"B", required_argument, 0, BFLAG_ },
    #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
    {"S", required_argument, 0, SFLAG_ },
    #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
    {"lazy", required_argument, 0, lazyFLAG_ },
    #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  };
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  ::opterr = 0;
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  while (c_ != -1) {
    #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
    switch (c_) {
      #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
      case RFLAG_:
        #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
        R = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
      case CFLAG_:
        #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
        C = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
      case NFLAG_:
        #line 5 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
      case BFLAG_:
        #line 5 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
        B = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
      case SFLAG_:
        #line 5 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
        S = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
      case lazyFLAG_:
        #line 5 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
        lazy = birch::Boolean(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
      case '?':
        #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
      case ':':
        #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
      default:
        #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  libbirch_line_(6);
  #line 6 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  libbirch::DefaultArray<birch::type::Real,2> M(libbirch::make_shape(R, C));
  #line 7 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  libbirch_line_(7);
  #line 7 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  libbirch::DefaultArray<birch::type::Real,2> U(libbirch::make_shape(R, R));
  #line 8 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  libbirch_line_(8);
  #line 8 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  birch::type::Real k;
  #line 9 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  libbirch_line_(9);
  #line 9 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  libbirch::DefaultArray<birch::type::Real,2> _u0936(libbirch::make_shape(C, C));
  #line 11 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  libbirch_line_(11);
  #line 11 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  for (auto i = birch::type::Integer(1); i <= R; ++i) {
    #line 12 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
    libbirch_line_(12);
    #line 12 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
    for (auto j = birch::type::Integer(1); j <= C; ++j) {
      #line 13 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
      libbirch_line_(13);
      #line 13 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
      M.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    }
  }
  #line 16 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  libbirch_line_(16);
  #line 16 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  for (auto i = birch::type::Integer(1); i <= R; ++i) {
    #line 17 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
    libbirch_line_(17);
    #line 17 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
    for (auto j = birch::type::Integer(1); j <= R; ++j) {
      #line 18 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
      libbirch_line_(18);
      #line 18 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
      U.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
    }
  }
  #line 21 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  libbirch_line_(21);
  #line 21 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  k = birch::simulate_uniform(C - 1.0, C + 9.0, handler_);
  #line 22 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  libbirch_line_(22);
  #line 22 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  for (auto i = birch::type::Integer(1); i <= C; ++i) {
    #line 23 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
    libbirch_line_(23);
    #line 23 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
    for (auto j = birch::type::Integer(1); j <= C; ++j) {
      #line 24 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
      libbirch_line_(24);
      #line 24 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
      _u0936.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
    }
  }
  #line 27 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  libbirch_line_(27);
  #line 27 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  U = U * birch::transpose(U, handler_);
  #line 28 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  libbirch_line_(28);
  #line 28 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  _u0936 = _u0936 * birch::transpose(_u0936, handler_);
  #line 30 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  libbirch_line_(30);
  #line 30 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>> V(birch::box(birch::llt(_u0936, handler_), handler_), birch::box(k, handler_));
  #line 31 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  libbirch_line_(31);
  #line 31 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>> _u0960(birch::box(M, handler_), birch::box(birch::llt(U, handler_), handler_), V);
  #line 32 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  libbirch_line_(32);
  #line 32 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  birch::test_pdf(_u0960, R, C, N, B, S, lazy, handler_);
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  libbirch_line_(4);
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart.birch"
  return 0;
}

#line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
int birch::test_pdf_matrix_normal_inverse_wishart_matrix_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_function_("test_pdf_matrix_normal_inverse_wishart_matrix_gaussian", "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch", 4);
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  birch::type::Integer B = birch::type::Integer(500);
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  birch::type::Integer S = birch::type::Integer(30);
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  birch::type::Boolean lazy = false;
  
  enum {
    NFLAG_,
    BFLAG_,
    SFLAG_,
    lazyFLAG_,
  };
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    {"B", required_argument, 0, BFLAG_ },
    #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    {"S", required_argument, 0, SFLAG_ },
    #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    {"lazy", required_argument, 0, lazyFLAG_ },
    #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  };
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case BFLAG_:
        #line 5 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        B = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case SFLAG_:
        #line 5 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        S = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case lazyFLAG_:
        #line 5 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        lazy = birch::Boolean(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case '?':
        #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case ':':
        #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      default:
        #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestMatrixNormalInverseWishartMatrixGaussian>> m;
  #line 7 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  m->initialize(handler_);
  #line 8 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_line_(8);
  #line 8 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  m->simulate(handler_);
  #line 9 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_line_(9);
  #line 9 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  birch::test_pdf(m->marginal(handler_), birch::type::Integer(5), birch::type::Integer(2), N, B, S, lazy, handler_);
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/pdf/test_pdf_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  return 0;
}

#line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
int birch::test_pdf_multivariate_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  libbirch_function_("test_pdf_multivariate_gaussian", "src/test/pdf/test_pdf_multivariate_gaussian.birch", 4);
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  birch::type::Integer D = birch::type::Integer(4);
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  birch::type::Integer B = birch::type::Integer(500);
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  birch::type::Integer S = birch::type::Integer(20);
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  birch::type::Boolean lazy = false;
  
  enum {
    DFLAG_,
    NFLAG_,
    BFLAG_,
    SFLAG_,
    lazyFLAG_,
  };
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
    {"D", required_argument, 0, DFLAG_ },
    #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
    {"B", required_argument, 0, BFLAG_ },
    #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
    {"S", required_argument, 0, SFLAG_ },
    #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
    {"lazy", required_argument, 0, lazyFLAG_ },
    #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  };
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
      case DFLAG_:
        #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
        D = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
      case BFLAG_:
        #line 5 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
        B = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
      case SFLAG_:
        #line 5 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
        S = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
      case lazyFLAG_:
        #line 5 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
        lazy = birch::Boolean(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
      case '?':
        #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
      case ':':
        #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
      default:
        #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  libbirch::DefaultArray<birch::type::Real,1> _u0956(libbirch::make_shape(D));
  #line 7 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  libbirch::DefaultArray<birch::type::Real,2> _u0931(libbirch::make_shape(D, D));
  #line 9 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  libbirch_line_(9);
  #line 9 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  for (auto i = birch::type::Integer(1); i <= D; ++i) {
    #line 10 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
    libbirch_line_(10);
    #line 10 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
    _u0956.set(libbirch::make_slice(i - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    #line 11 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
    libbirch_line_(11);
    #line 11 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
    for (auto j = birch::type::Integer(1); j <= D; ++j) {
      #line 12 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
      libbirch_line_(12);
      #line 12 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
      _u0931.set(libbirch::make_slice(i - 1, j - 1), birch::simulate_uniform(-2.0, 2.0, handler_));
    }
  }
  #line 15 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  libbirch_line_(15);
  #line 15 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  _u0931 = _u0931 * birch::transpose(_u0931, handler_);
  #line 17 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  libbirch_line_(17);
  #line 17 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  auto _u0960 = birch::Gaussian(_u0956, _u0931, handler_);
  #line 18 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  libbirch_line_(18);
  #line 18 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  birch::test_pdf(_u0960, D, N, B, S, lazy, handler_);
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian.birch"
  return 0;
}

#line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
int birch::test_pdf_multivariate_gaussian_multivariate_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_function_("test_pdf_multivariate_gaussian_multivariate_gaussian", "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch", 4);
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
  birch::type::Integer B = birch::type::Integer(500);
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
  birch::type::Integer S = birch::type::Integer(20);
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
  birch::type::Boolean lazy = false;
  
  enum {
    NFLAG_,
    BFLAG_,
    SFLAG_,
    lazyFLAG_,
  };
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
    {"B", required_argument, 0, BFLAG_ },
    #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
    {"S", required_argument, 0, SFLAG_ },
    #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
    {"lazy", required_argument, 0, lazyFLAG_ },
    #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
  };
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
      case BFLAG_:
        #line 5 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
        B = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
      case SFLAG_:
        #line 5 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
        S = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
      case lazyFLAG_:
        #line 5 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
        lazy = birch::Boolean(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
      case '?':
        #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
      case ':':
        #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
      default:
        #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestMultivariateGaussianMultivariateGaussian>> m;
  #line 7 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
  m->initialize(handler_);
  #line 8 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_line_(8);
  #line 8 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
  m->simulate(handler_);
  #line 9 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_line_(9);
  #line 9 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
  birch::test_pdf(m->marginal(handler_), birch::type::Integer(5), N, B, S, lazy, handler_);
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/pdf/test_pdf_multivariate_gaussian_multivariate_gaussian.birch"
  return 0;
}

#line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
int birch::test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_function_("test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch", 4);
  #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  birch::type::Integer B = birch::type::Integer(500);
  #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  birch::type::Integer S = birch::type::Integer(20);
  #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  birch::type::Boolean lazy = false;
  
  enum {
    NFLAG_,
    BFLAG_,
    SFLAG_,
    lazyFLAG_,
  };
  #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    {"B", required_argument, 0, BFLAG_ },
    #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    {"S", required_argument, 0, SFLAG_ },
    #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    {"lazy", required_argument, 0, lazyFLAG_ },
    #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  };
  #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case BFLAG_:
        #line 5 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        B = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case SFLAG_:
        #line 5 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        S = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case lazyFLAG_:
        #line 5 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        lazy = birch::Boolean(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case '?':
        #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case ':':
        #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      default:
        #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestMultivariateNormalInverseGammaMultivariateGaussian>> m;
  #line 7 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  m->initialize(handler_);
  #line 8 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_line_(8);
  #line 8 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  m->simulate(handler_);
  #line 9 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_line_(9);
  #line 9 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  birch::test_pdf(m->marginal(handler_), birch::type::Integer(5), N, B, S, lazy, handler_);
  #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/pdf/test_pdf_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  return 0;
}

#line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
int birch::test_pdf_multivariate_uniform(int argc_, char** argv_) {
  #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  libbirch_function_("test_pdf_multivariate_uniform", "src/test/pdf/test_pdf_multivariate_uniform.birch", 4);
  #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  birch::type::Integer D = birch::type::Integer(4);
  #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  birch::type::Integer B = birch::type::Integer(500);
  #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  birch::type::Integer S = birch::type::Integer(20);
  #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  birch::type::Boolean lazy = false;
  
  enum {
    DFLAG_,
    NFLAG_,
    BFLAG_,
    SFLAG_,
    lazyFLAG_,
  };
  #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  int c_, option_index_;
  #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  option long_options_[] = {
    #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
    {"D", required_argument, 0, DFLAG_ },
    #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
    {"B", required_argument, 0, BFLAG_ },
    #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
    {"S", required_argument, 0, SFLAG_ },
    #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
    {"lazy", required_argument, 0, lazyFLAG_ },
    #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  };
  #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  ::opterr = 0;
  #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  while (c_ != -1) {
    #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
    switch (c_) {
      #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
      case DFLAG_:
        #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
        D = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
      case NFLAG_:
        #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_multivariate_uniform.birch"
      case BFLAG_:
        #line 5 "src/test/pdf/test_pdf_multivariate_uniform.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_multivariate_uniform.birch"
        B = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_multivariate_uniform.birch"
      case SFLAG_:
        #line 5 "src/test/pdf/test_pdf_multivariate_uniform.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_multivariate_uniform.birch"
        S = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/pdf/test_pdf_multivariate_uniform.birch"
      case lazyFLAG_:
        #line 5 "src/test/pdf/test_pdf_multivariate_uniform.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/pdf/test_pdf_multivariate_uniform.birch"
        lazy = birch::Boolean(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
      case '?':
        #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
      case ':':
        #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
      default:
        #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  libbirch_line_(6);
  #line 6 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  libbirch::DefaultArray<birch::type::Real,1> l(libbirch::make_shape(D));
  #line 7 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  libbirch_line_(7);
  #line 7 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  libbirch::DefaultArray<birch::type::Real,1> u(libbirch::make_shape(D));
  #line 9 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  libbirch_line_(9);
  #line 9 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  for (auto i = birch::type::Integer(1); i <= D; ++i) {
    #line 10 "src/test/pdf/test_pdf_multivariate_uniform.birch"
    libbirch_line_(10);
    #line 10 "src/test/pdf/test_pdf_multivariate_uniform.birch"
    l.set(libbirch::make_slice(i - 1), birch::simulate_uniform(-10.0, 10.0, handler_));
    #line 11 "src/test/pdf/test_pdf_multivariate_uniform.birch"
    libbirch_line_(11);
    #line 11 "src/test/pdf/test_pdf_multivariate_uniform.birch"
    u.set(libbirch::make_slice(i - 1), birch::simulate_uniform(l.get(libbirch::make_slice(i - 1)), l.get(libbirch::make_slice(i - 1)) + 20.0, handler_));
  }
  #line 14 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  libbirch_line_(14);
  #line 14 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  auto _u0960 = birch::Uniform(l, u, handler_);
  #line 15 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  libbirch_line_(15);
  #line 15 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  birch::test_pdf(_u0960, D, N, B, S, lazy, handler_);
  #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  libbirch_line_(4);
  #line 4 "src/test/pdf/test_pdf_multivariate_uniform.birch"
  return 0;
}

#line 4 "src/test/pdf/test_pdf_uniform_int.birch"
int birch::test_pdf_uniform_int(int argc_, char** argv_) {
  #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
  libbirch_function_("test_pdf_uniform_int", "src/test/pdf/test_pdf_uniform_int.birch", 4);
  #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
  birch::type::Boolean lazy = false;
  
  enum {
    NFLAG_,
    lazyFLAG_,
  };
  #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
  int c_, option_index_;
  #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
  option long_options_[] = {
    #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
    {"lazy", required_argument, 0, lazyFLAG_ },
    #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
  };
  #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
  ::opterr = 0;
  #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
  while (c_ != -1) {
    #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
    switch (c_) {
      #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
      case NFLAG_:
        #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
      case lazyFLAG_:
        #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
        lazy = birch::Boolean(std::string(::optarg));
        break;
      #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
      case '?':
        #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
      case ':':
        #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
      default:
        #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/pdf/test_pdf_uniform_int.birch"
  libbirch_line_(5);
  #line 5 "src/test/pdf/test_pdf_uniform_int.birch"
  auto l = birch::simulate_uniform_int(-birch::type::Integer(10), birch::type::Integer(10), handler_);
  #line 6 "src/test/pdf/test_pdf_uniform_int.birch"
  libbirch_line_(6);
  #line 6 "src/test/pdf/test_pdf_uniform_int.birch"
  auto u = birch::simulate_uniform_int(l, l + birch::type::Integer(20), handler_);
  #line 7 "src/test/pdf/test_pdf_uniform_int.birch"
  libbirch_line_(7);
  #line 7 "src/test/pdf/test_pdf_uniform_int.birch"
  auto _u0960 = birch::Uniform(l, u, handler_);
  #line 8 "src/test/pdf/test_pdf_uniform_int.birch"
  libbirch_line_(8);
  #line 8 "src/test/pdf/test_pdf_uniform_int.birch"
  if (lazy) {
    #line 9 "src/test/pdf/test_pdf_uniform_int.birch"
    libbirch_line_(9);
    #line 9 "src/test/pdf/test_pdf_uniform_int.birch"
    birch::warn(birch::type::String("lazy not supported, reverting to eager."), handler_);
  }
  #line 11 "src/test/pdf/test_pdf_uniform_int.birch"
  libbirch_line_(11);
  #line 11 "src/test/pdf/test_pdf_uniform_int.birch"
  birch::test_pdf(_u0960, N, false, handler_);
  #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
  libbirch_line_(4);
  #line 4 "src/test/pdf/test_pdf_uniform_int.birch"
  return 0;
}

