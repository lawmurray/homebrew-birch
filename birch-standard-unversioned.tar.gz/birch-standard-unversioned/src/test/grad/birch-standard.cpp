#line 4 "src/test/grad/test_grad_beta.birch"
int birch::test_grad_beta(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_beta.birch"
  libbirch_function_("test_grad_beta", "src/test/grad/test_grad_beta.birch", 4);
  #line 4 "src/test/grad/test_grad_beta.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_beta.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_beta.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_beta.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_beta.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_beta.birch"
  };
  #line 4 "src/test/grad/test_grad_beta.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_beta.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_beta.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_beta.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_beta.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_beta.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_beta.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_beta.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_beta.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_beta.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_beta.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_beta.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_beta.birch"
      default:
        #line 4 "src/test/grad/test_grad_beta.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_beta.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/grad/test_grad_beta.birch"
  libbirch_line_(5);
  #line 5 "src/test/grad/test_grad_beta.birch"
  auto _u0945 = birch::simulate_uniform(1.0, 10.0, handler_);
  #line 6 "src/test/grad/test_grad_beta.birch"
  libbirch_line_(6);
  #line 6 "src/test/grad/test_grad_beta.birch"
  auto _u0946 = birch::simulate_uniform(1.0, 10.0, handler_);
  #line 7 "src/test/grad/test_grad_beta.birch"
  libbirch_line_(7);
  #line 7 "src/test/grad/test_grad_beta.birch"
  auto q = birch::Beta(_u0945, _u0946, handler_);
  #line 8 "src/test/grad/test_grad_beta.birch"
  libbirch_line_(8);
  #line 8 "src/test/grad/test_grad_beta.birch"
  birch::test_grad(q, N, handler_);
  #line 4 "src/test/grad/test_grad_beta.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_beta.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_exponential.birch"
int birch::test_grad_exponential(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_exponential.birch"
  libbirch_function_("test_grad_exponential", "src/test/grad/test_grad_exponential.birch", 4);
  #line 4 "src/test/grad/test_grad_exponential.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_exponential.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_exponential.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_exponential.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_exponential.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_exponential.birch"
  };
  #line 4 "src/test/grad/test_grad_exponential.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_exponential.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_exponential.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_exponential.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_exponential.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_exponential.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_exponential.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_exponential.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_exponential.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_exponential.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_exponential.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_exponential.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_exponential.birch"
      default:
        #line 4 "src/test/grad/test_grad_exponential.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_exponential.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/grad/test_grad_exponential.birch"
  libbirch_line_(5);
  #line 5 "src/test/grad/test_grad_exponential.birch"
  auto _u0955 = birch::simulate_uniform(1.0, 10.0, handler_);
  #line 6 "src/test/grad/test_grad_exponential.birch"
  libbirch_line_(6);
  #line 6 "src/test/grad/test_grad_exponential.birch"
  auto q = birch::Exponential(_u0955, handler_);
  #line 7 "src/test/grad/test_grad_exponential.birch"
  libbirch_line_(7);
  #line 7 "src/test/grad/test_grad_exponential.birch"
  birch::test_grad(q, N, handler_);
  #line 4 "src/test/grad/test_grad_exponential.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_exponential.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_gamma.birch"
int birch::test_grad_gamma(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_gamma.birch"
  libbirch_function_("test_grad_gamma", "src/test/grad/test_grad_gamma.birch", 4);
  #line 4 "src/test/grad/test_grad_gamma.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_gamma.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_gamma.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_gamma.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_gamma.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_gamma.birch"
  };
  #line 4 "src/test/grad/test_grad_gamma.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_gamma.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_gamma.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_gamma.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_gamma.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_gamma.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_gamma.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_gamma.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_gamma.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_gamma.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_gamma.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_gamma.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_gamma.birch"
      default:
        #line 4 "src/test/grad/test_grad_gamma.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_gamma.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/grad/test_grad_gamma.birch"
  libbirch_line_(5);
  #line 5 "src/test/grad/test_grad_gamma.birch"
  auto k = birch::simulate_uniform(1.0, 10.0, handler_);
  #line 6 "src/test/grad/test_grad_gamma.birch"
  libbirch_line_(6);
  #line 6 "src/test/grad/test_grad_gamma.birch"
  auto _u0952 = birch::simulate_uniform(0.0, 10.0, handler_);
  #line 7 "src/test/grad/test_grad_gamma.birch"
  libbirch_line_(7);
  #line 7 "src/test/grad/test_grad_gamma.birch"
  auto q = birch::Gamma(k, _u0952, handler_);
  #line 8 "src/test/grad/test_grad_gamma.birch"
  libbirch_line_(8);
  #line 8 "src/test/grad/test_grad_gamma.birch"
  birch::test_grad(q, N, handler_);
  #line 4 "src/test/grad/test_grad_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_gamma.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_gamma_exponential.birch"
int birch::test_grad_gamma_exponential(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
  libbirch_function_("test_grad_gamma_exponential", "src/test/grad/test_grad_gamma_exponential.birch", 4);
  #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
  };
  #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
      default:
        #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/grad/test_grad_gamma_exponential.birch"
  libbirch_line_(5);
  #line 5 "src/test/grad/test_grad_gamma_exponential.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestGammaExponential>> m;
  #line 6 "src/test/grad/test_grad_gamma_exponential.birch"
  libbirch_line_(6);
  #line 6 "src/test/grad/test_grad_gamma_exponential.birch"
  m->initialize(handler_);
  #line 7 "src/test/grad/test_grad_gamma_exponential.birch"
  libbirch_line_(7);
  #line 7 "src/test/grad/test_grad_gamma_exponential.birch"
  m->simulate(handler_);
  #line 8 "src/test/grad/test_grad_gamma_exponential.birch"
  libbirch_line_(8);
  #line 8 "src/test/grad/test_grad_gamma_exponential.birch"
  birch::test_grad(m->marginal(handler_), N, handler_);
  #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_gaussian.birch"
int birch::test_grad_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_gaussian.birch"
  libbirch_function_("test_grad_gaussian", "src/test/grad/test_grad_gaussian.birch", 4);
  #line 4 "src/test/grad/test_grad_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_gaussian.birch"
  };
  #line 4 "src/test/grad/test_grad_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_gaussian.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_gaussian.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_gaussian.birch"
      default:
        #line 4 "src/test/grad/test_grad_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/grad/test_grad_gaussian.birch"
  libbirch_line_(5);
  #line 5 "src/test/grad/test_grad_gaussian.birch"
  auto _u0956 = birch::simulate_uniform(-10.0, 10.0, handler_);
  #line 6 "src/test/grad/test_grad_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/grad/test_grad_gaussian.birch"
  auto _u09632 = birch::simulate_uniform(0.0, 10.0, handler_);
  #line 7 "src/test/grad/test_grad_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/grad/test_grad_gaussian.birch"
  auto q = birch::Gaussian(_u0956, _u09632, handler_);
  #line 8 "src/test/grad/test_grad_gaussian.birch"
  libbirch_line_(8);
  #line 8 "src/test/grad/test_grad_gaussian.birch"
  birch::test_grad(q, N, handler_);
  #line 4 "src/test/grad/test_grad_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_gaussian.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_inverse_gamma.birch"
int birch::test_grad_inverse_gamma(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
  libbirch_function_("test_grad_inverse_gamma", "src/test/grad/test_grad_inverse_gamma.birch", 4);
  #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
  };
  #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
      default:
        #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/grad/test_grad_inverse_gamma.birch"
  libbirch_line_(5);
  #line 5 "src/test/grad/test_grad_inverse_gamma.birch"
  auto _u0945 = birch::simulate_uniform(2.0, 10.0, handler_);
  #line 6 "src/test/grad/test_grad_inverse_gamma.birch"
  libbirch_line_(6);
  #line 6 "src/test/grad/test_grad_inverse_gamma.birch"
  auto _u0946 = birch::simulate_uniform(0.1, 10.0, handler_);
  #line 7 "src/test/grad/test_grad_inverse_gamma.birch"
  libbirch_line_(7);
  #line 7 "src/test/grad/test_grad_inverse_gamma.birch"
  auto q = birch::InverseGamma(_u0945, _u0946, handler_);
  #line 8 "src/test/grad/test_grad_inverse_gamma.birch"
  libbirch_line_(8);
  #line 8 "src/test/grad/test_grad_inverse_gamma.birch"
  birch::test_grad(q, N, handler_);
  #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
int birch::test_grad_inverse_gamma_gamma(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  libbirch_function_("test_grad_inverse_gamma_gamma", "src/test/grad/test_grad_inverse_gamma_gamma.birch", 4);
  #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  };
  #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
      default:
        #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  libbirch_line_(5);
  #line 5 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestInverseGammaGamma>> m;
  #line 6 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  libbirch_line_(6);
  #line 6 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  m->initialize(handler_);
  #line 7 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  libbirch_line_(7);
  #line 7 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  m->simulate(handler_);
  #line 8 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  libbirch_line_(8);
  #line 8 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  birch::test_grad(m->marginal(handler_), N, handler_);
  #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
int birch::test_grad_linear_gaussian_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  libbirch_function_("test_grad_linear_gaussian_gaussian", "src/test/grad/test_grad_linear_gaussian_gaussian.birch", 4);
  #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  };
  #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
      default:
        #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  libbirch_line_(5);
  #line 5 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestLinearGaussianGaussian>> m;
  #line 6 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  m->initialize(handler_);
  #line 7 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  m->simulate(handler_);
  #line 8 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  libbirch_line_(8);
  #line 8 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  birch::test_grad(m->marginal(handler_), N, handler_);
  #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
int birch::test_grad_linear_multivariate_gaussian_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  libbirch_function_("test_grad_linear_multivariate_gaussian_gaussian", "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch", 4);
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  };
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
      default:
        #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  libbirch_line_(5);
  #line 5 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestLinearMultivariateGaussianGaussian>> m;
  #line 6 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  m->initialize(handler_);
  #line 7 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  m->simulate(handler_);
  #line 8 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  libbirch_line_(8);
  #line 8 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  birch::test_grad(m->marginal(handler_), N, handler_);
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
int birch::test_grad_linear_multivariate_normal_inverse_gamma_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch_function_("test_grad_linear_multivariate_normal_inverse_gamma_gaussian", "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch", 4);
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  };
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
      default:
        #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestLinearMultivariateNormalInverseGammaGaussian>> m;
  #line 7 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  m->initialize(handler_);
  #line 8 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(8);
  #line 8 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  m->simulate(handler_);
  #line 9 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(9);
  #line 9 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  birch::test_grad(m->marginal(handler_), N, handler_);
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
int birch::test_grad_linear_normal_inverse_gamma_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_function_("test_grad_linear_normal_inverse_gamma_gaussian", "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch", 4);
  #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  };
  #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
      default:
        #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(5);
  #line 5 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestLinearNormalInverseGammaGaussian>> m;
  #line 6 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  m->initialize(handler_);
  #line 7 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  m->simulate(handler_);
  #line 8 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(8);
  #line 8 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  birch::test_grad(m->marginal(handler_), N, handler_);
  #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
int birch::test_grad_normal_inverse_gamma(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  libbirch_function_("test_grad_normal_inverse_gamma", "src/test/grad/test_grad_normal_inverse_gamma.birch", 4);
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  };
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
      default:
        #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  libbirch_line_(5);
  #line 5 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestNormalInverseGamma>> m;
  #line 6 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  libbirch_line_(6);
  #line 6 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  m->initialize(handler_);
  #line 7 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  libbirch_line_(7);
  #line 7 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  m->simulate(handler_);
  #line 8 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  libbirch_line_(8);
  #line 8 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  birch::test_grad(m->marginal(handler_), N, handler_);
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
int birch::test_grad_normal_inverse_gamma_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  libbirch_function_("test_grad_normal_inverse_gamma_gaussian", "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch", 4);
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  };
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
      default:
        #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(5);
  #line 5 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestNormalInverseGammaGaussian>> m;
  #line 6 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  m->initialize(handler_);
  #line 7 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  m->simulate(handler_);
  #line 8 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(8);
  #line 8 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  birch::test_grad(m->marginal(handler_), N, handler_);
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
int birch::test_grad_scaled_gamma_exponential(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  libbirch_function_("test_grad_scaled_gamma_exponential", "src/test/grad/test_grad_scaled_gamma_exponential.birch", 4);
  #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  };
  #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
      default:
        #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  libbirch_line_(5);
  #line 5 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestScaledGammaExponential>> m;
  #line 6 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  libbirch_line_(6);
  #line 6 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  m->initialize(handler_);
  #line 7 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  libbirch_line_(7);
  #line 7 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  m->simulate(handler_);
  #line 8 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  libbirch_line_(8);
  #line 8 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  birch::test_grad(m->marginal(handler_), N, handler_);
  #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_student_t.birch"
int birch::test_grad_student_t(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_student_t.birch"
  libbirch_function_("test_grad_student_t", "src/test/grad/test_grad_student_t.birch", 4);
  #line 4 "src/test/grad/test_grad_student_t.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_student_t.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_student_t.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_student_t.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_student_t.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_student_t.birch"
  };
  #line 4 "src/test/grad/test_grad_student_t.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_student_t.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_student_t.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_student_t.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_student_t.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_student_t.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_student_t.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_student_t.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_student_t.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_student_t.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_student_t.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_student_t.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_student_t.birch"
      default:
        #line 4 "src/test/grad/test_grad_student_t.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_student_t.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/grad/test_grad_student_t.birch"
  libbirch_line_(5);
  #line 5 "src/test/grad/test_grad_student_t.birch"
  auto k = birch::simulate_uniform(1.0, 10.0, handler_);
  #line 6 "src/test/grad/test_grad_student_t.birch"
  libbirch_line_(6);
  #line 6 "src/test/grad/test_grad_student_t.birch"
  auto _u0956 = birch::simulate_uniform(-10.0, 10.0, handler_);
  #line 7 "src/test/grad/test_grad_student_t.birch"
  libbirch_line_(7);
  #line 7 "src/test/grad/test_grad_student_t.birch"
  auto _u09632 = birch::simulate_uniform(0.0, 10.0, handler_);
  #line 8 "src/test/grad/test_grad_student_t.birch"
  libbirch_line_(8);
  #line 8 "src/test/grad/test_grad_student_t.birch"
  auto q = birch::Student(k, _u0956, _u09632, handler_);
  #line 9 "src/test/grad/test_grad_student_t.birch"
  libbirch_line_(9);
  #line 9 "src/test/grad/test_grad_student_t.birch"
  birch::test_grad(q, N, handler_);
  #line 4 "src/test/grad/test_grad_student_t.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_student_t.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_weibull.birch"
int birch::test_grad_weibull(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_weibull.birch"
  libbirch_function_("test_grad_weibull", "src/test/grad/test_grad_weibull.birch", 4);
  #line 4 "src/test/grad/test_grad_weibull.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_weibull.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_weibull.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_weibull.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_weibull.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_weibull.birch"
  };
  #line 4 "src/test/grad/test_grad_weibull.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_weibull.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_weibull.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_weibull.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_weibull.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_weibull.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_weibull.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_weibull.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_weibull.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_weibull.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_weibull.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_weibull.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_weibull.birch"
      default:
        #line 4 "src/test/grad/test_grad_weibull.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_weibull.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/grad/test_grad_weibull.birch"
  libbirch_line_(5);
  #line 5 "src/test/grad/test_grad_weibull.birch"
  auto k = birch::simulate_uniform(1.0, 10.0, handler_);
  #line 6 "src/test/grad/test_grad_weibull.birch"
  libbirch_line_(6);
  #line 6 "src/test/grad/test_grad_weibull.birch"
  auto _u0955 = birch::simulate_uniform(0.1, 10.0, handler_);
  #line 7 "src/test/grad/test_grad_weibull.birch"
  libbirch_line_(7);
  #line 7 "src/test/grad/test_grad_weibull.birch"
  auto q = birch::Weibull(k, _u0955, handler_);
  #line 8 "src/test/grad/test_grad_weibull.birch"
  libbirch_line_(8);
  #line 8 "src/test/grad/test_grad_weibull.birch"
  birch::test_grad(q, N, handler_);
  #line 4 "src/test/grad/test_grad_weibull.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_weibull.birch"
  return 0;
}

