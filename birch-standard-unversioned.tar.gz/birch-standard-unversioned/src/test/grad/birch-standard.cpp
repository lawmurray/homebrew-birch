#line 4 "src/test/grad/test_grad_beta.birch"
int birch::test_grad_beta(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_beta.birch"
  libbirch_function_("test_grad_beta", "src/test/grad/test_grad_beta.birch", 4);
  #line 4 "src/test/grad/test_grad_beta.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_beta.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_beta.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_beta.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_beta.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_beta.birch"
  };
  #line 4 "src/test/grad/test_grad_beta.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_beta.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_beta.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_beta.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_beta.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_beta.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_beta.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_beta.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_beta.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_beta.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_beta.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_beta.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_beta.birch"
      default:
        #line 4 "src/test/grad/test_grad_beta.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_beta.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/grad/test_grad_beta.birch"
    libbirch_line_(5);
    #line 5 "src/test/grad/test_grad_beta.birch"
    auto α = birch::simulate_uniform(1.0, 10.0);
    #line 6 "src/test/grad/test_grad_beta.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_beta.birch"
    auto β = birch::simulate_uniform(1.0, 10.0);
    #line 7 "src/test/grad/test_grad_beta.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_beta.birch"
    auto q = birch::Beta(α, β);
    #line 8 "src/test/grad/test_grad_beta.birch"
    libbirch_line_(8);
    #line 8 "src/test/grad/test_grad_beta.birch"
    birch::test_grad(q, N);
  }
  #line 4 "src/test/grad/test_grad_beta.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_beta.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_beta.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_beta.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_exponential.birch"
int birch::test_grad_exponential(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_exponential.birch"
  libbirch_function_("test_grad_exponential", "src/test/grad/test_grad_exponential.birch", 4);
  #line 4 "src/test/grad/test_grad_exponential.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_exponential.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_exponential.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_exponential.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_exponential.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_exponential.birch"
  };
  #line 4 "src/test/grad/test_grad_exponential.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_exponential.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_exponential.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_exponential.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_exponential.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_exponential.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_exponential.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_exponential.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_exponential.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_exponential.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_exponential.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_exponential.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_exponential.birch"
      default:
        #line 4 "src/test/grad/test_grad_exponential.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_exponential.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/grad/test_grad_exponential.birch"
    libbirch_line_(5);
    #line 5 "src/test/grad/test_grad_exponential.birch"
    auto λ = birch::simulate_uniform(1.0, 10.0);
    #line 6 "src/test/grad/test_grad_exponential.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_exponential.birch"
    auto q = birch::Exponential(λ);
    #line 7 "src/test/grad/test_grad_exponential.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_exponential.birch"
    birch::test_grad(q, N);
  }
  #line 4 "src/test/grad/test_grad_exponential.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_exponential.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_exponential.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_exponential.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_gamma.birch"
int birch::test_grad_gamma(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_gamma.birch"
  libbirch_function_("test_grad_gamma", "src/test/grad/test_grad_gamma.birch", 4);
  #line 4 "src/test/grad/test_grad_gamma.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_gamma.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_gamma.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_gamma.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_gamma.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_gamma.birch"
  };
  #line 4 "src/test/grad/test_grad_gamma.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_gamma.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_gamma.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_gamma.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_gamma.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_gamma.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_gamma.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_gamma.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_gamma.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_gamma.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_gamma.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_gamma.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_gamma.birch"
      default:
        #line 4 "src/test/grad/test_grad_gamma.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_gamma.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/grad/test_grad_gamma.birch"
    libbirch_line_(5);
    #line 5 "src/test/grad/test_grad_gamma.birch"
    auto k = birch::simulate_uniform(1.0, 10.0);
    #line 6 "src/test/grad/test_grad_gamma.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_gamma.birch"
    auto θ = birch::simulate_uniform(0.0, 10.0);
    #line 7 "src/test/grad/test_grad_gamma.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_gamma.birch"
    auto q = birch::Gamma(k, θ);
    #line 8 "src/test/grad/test_grad_gamma.birch"
    libbirch_line_(8);
    #line 8 "src/test/grad/test_grad_gamma.birch"
    birch::test_grad(q, N);
  }
  #line 4 "src/test/grad/test_grad_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_gamma.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_gamma.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_gamma_exponential.birch"
int birch::test_grad_gamma_exponential(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
  libbirch_function_("test_grad_gamma_exponential", "src/test/grad/test_grad_gamma_exponential.birch", 4);
  #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
  };
  #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
      default:
        #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/grad/test_grad_gamma_exponential.birch"
    libbirch_line_(5);
    #line 5 "src/test/grad/test_grad_gamma_exponential.birch"
    libbirch::Shared<birch::type::TestGammaExponential> m = libbirch::make<libbirch::Shared<birch::type::TestGammaExponential>>();
    #line 6 "src/test/grad/test_grad_gamma_exponential.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_gamma_exponential.birch"
    m->initialize();
    #line 7 "src/test/grad/test_grad_gamma_exponential.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_gamma_exponential.birch"
    m->simulate();
    #line 8 "src/test/grad/test_grad_gamma_exponential.birch"
    libbirch_line_(8);
    #line 8 "src/test/grad/test_grad_gamma_exponential.birch"
    birch::test_grad(m->marginal(), N);
  }
  #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_gamma_exponential.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_gaussian.birch"
int birch::test_grad_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_gaussian.birch"
  libbirch_function_("test_grad_gaussian", "src/test/grad/test_grad_gaussian.birch", 4);
  #line 4 "src/test/grad/test_grad_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_gaussian.birch"
  };
  #line 4 "src/test/grad/test_grad_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_gaussian.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_gaussian.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_gaussian.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_gaussian.birch"
      default:
        #line 4 "src/test/grad/test_grad_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/grad/test_grad_gaussian.birch"
    libbirch_line_(5);
    #line 5 "src/test/grad/test_grad_gaussian.birch"
    auto μ = birch::simulate_uniform(-(10.0), 10.0);
    #line 6 "src/test/grad/test_grad_gaussian.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_gaussian.birch"
    auto σ2 = birch::simulate_uniform(0.0, 10.0);
    #line 7 "src/test/grad/test_grad_gaussian.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_gaussian.birch"
    auto q = birch::Gaussian(μ, σ2);
    #line 8 "src/test/grad/test_grad_gaussian.birch"
    libbirch_line_(8);
    #line 8 "src/test/grad/test_grad_gaussian.birch"
    birch::test_grad(q, N);
  }
  #line 4 "src/test/grad/test_grad_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_gaussian.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_gaussian.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_inverse_gamma.birch"
int birch::test_grad_inverse_gamma(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
  libbirch_function_("test_grad_inverse_gamma", "src/test/grad/test_grad_inverse_gamma.birch", 4);
  #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
  };
  #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
      default:
        #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/grad/test_grad_inverse_gamma.birch"
    libbirch_line_(5);
    #line 5 "src/test/grad/test_grad_inverse_gamma.birch"
    auto α = birch::simulate_uniform(2.0, 10.0);
    #line 6 "src/test/grad/test_grad_inverse_gamma.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_inverse_gamma.birch"
    auto β = birch::simulate_uniform(0.1, 10.0);
    #line 7 "src/test/grad/test_grad_inverse_gamma.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_inverse_gamma.birch"
    auto q = birch::InverseGamma(α, β);
    #line 8 "src/test/grad/test_grad_inverse_gamma.birch"
    libbirch_line_(8);
    #line 8 "src/test/grad/test_grad_inverse_gamma.birch"
    birch::test_grad(q, N);
  }
  #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_inverse_gamma.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
int birch::test_grad_inverse_gamma_gamma(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  libbirch_function_("test_grad_inverse_gamma_gamma", "src/test/grad/test_grad_inverse_gamma_gamma.birch", 4);
  #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  };
  #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
      default:
        #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
    libbirch_line_(5);
    #line 5 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
    libbirch::Shared<birch::type::TestInverseGammaGamma> m = libbirch::make<libbirch::Shared<birch::type::TestInverseGammaGamma>>();
    #line 6 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
    m->initialize();
    #line 7 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
    m->simulate();
    #line 8 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
    libbirch_line_(8);
    #line 8 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
    birch::test_grad(m->marginal(), N);
  }
  #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_inverse_gamma_gamma.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
int birch::test_grad_linear_gaussian_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  libbirch_function_("test_grad_linear_gaussian_gaussian", "src/test/grad/test_grad_linear_gaussian_gaussian.birch", 4);
  #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  };
  #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
      default:
        #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
    libbirch_line_(5);
    #line 5 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
    libbirch::Shared<birch::type::TestLinearGaussianGaussian> m = libbirch::make<libbirch::Shared<birch::type::TestLinearGaussianGaussian>>();
    #line 6 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
    m->initialize();
    #line 7 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
    m->simulate();
    #line 8 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
    libbirch_line_(8);
    #line 8 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
    birch::test_grad(m->marginal(), N);
  }
  #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_linear_gaussian_gaussian.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
int birch::test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_function_("test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian", "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch", 4);
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  };
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      default:
        #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 6 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    libbirch::Shared<birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian> m = libbirch::make<libbirch::Shared<birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian>>();
    #line 7 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    m->initialize();
    #line 8 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    libbirch_line_(8);
    #line 8 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    m->simulate();
    #line 9 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    libbirch_line_(9);
    #line 9 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    birch::test_grad(m->marginal(), N);
  }
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
int birch::test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  libbirch_function_("test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian", "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch", 4);
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  };
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
      default:
        #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 6 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
    libbirch::Shared<birch::type::TestLinearMatrixNormalInverseWishartMultivariateGaussian> m = libbirch::make<libbirch::Shared<birch::type::TestLinearMatrixNormalInverseWishartMultivariateGaussian>>();
    #line 7 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
    m->initialize();
    #line 8 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
    libbirch_line_(8);
    #line 8 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
    m->simulate();
    #line 9 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
    libbirch_line_(9);
    #line 9 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
    birch::test_grad(m->marginal(), N);
  }
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_linear_matrix_normal_inverse_wishart_multivariate_gaussian.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
int birch::test_grad_linear_multivariate_gaussian_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  libbirch_function_("test_grad_linear_multivariate_gaussian_gaussian", "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch", 4);
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  };
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
      default:
        #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
    libbirch_line_(5);
    #line 5 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
    libbirch::Shared<birch::type::TestLinearMultivariateGaussianGaussian> m = libbirch::make<libbirch::Shared<birch::type::TestLinearMultivariateGaussianGaussian>>();
    #line 6 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
    m->initialize();
    #line 7 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
    m->simulate();
    #line 8 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
    libbirch_line_(8);
    #line 8 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
    birch::test_grad(m->marginal(), N);
  }
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_gaussian.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
int birch::test_grad_linear_multivariate_gaussian_multivariate_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_function_("test_grad_linear_multivariate_gaussian_multivariate_gaussian", "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch", 4);
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
  };
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
      default:
        #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 6 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
    libbirch::Shared<birch::type::TestLinearMultivariateGaussianMultivariateGaussian> m = libbirch::make<libbirch::Shared<birch::type::TestLinearMultivariateGaussianMultivariateGaussian>>();
    #line 7 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
    m->initialize();
    #line 8 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
    libbirch_line_(8);
    #line 8 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
    m->simulate();
    #line 9 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
    libbirch_line_(9);
    #line 9 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
    birch::test_grad(m->marginal(), N);
  }
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_linear_multivariate_gaussian_multivariate_gaussian.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
int birch::test_grad_linear_multivariate_normal_inverse_gamma_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch_function_("test_grad_linear_multivariate_normal_inverse_gamma_gaussian", "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch", 4);
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  };
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
      default:
        #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 6 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    libbirch::Shared<birch::type::TestLinearMultivariateNormalInverseGammaGaussian> m = libbirch::make<libbirch::Shared<birch::type::TestLinearMultivariateNormalInverseGammaGaussian>>();
    #line 7 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    m->initialize();
    #line 8 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    libbirch_line_(8);
    #line 8 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    m->simulate();
    #line 9 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    libbirch_line_(9);
    #line 9 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    birch::test_grad(m->marginal(), N);
  }
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
int birch::test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_function_("test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch", 4);
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  };
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      default:
        #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 6 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    libbirch::Shared<birch::type::TestLinearMultivariateNormalInverseGammaMultivariateGaussian> m = libbirch::make<libbirch::Shared<birch::type::TestLinearMultivariateNormalInverseGammaMultivariateGaussian>>();
    #line 7 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    m->initialize();
    #line 8 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    libbirch_line_(8);
    #line 8 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    m->simulate();
    #line 9 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    libbirch_line_(9);
    #line 9 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    birch::test_grad(m->marginal(), N);
  }
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
int birch::test_grad_linear_normal_inverse_gamma_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_function_("test_grad_linear_normal_inverse_gamma_gaussian", "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch", 4);
  #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  };
  #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
      default:
        #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
    libbirch_line_(5);
    #line 5 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
    libbirch::Shared<birch::type::TestLinearNormalInverseGammaGaussian> m = libbirch::make<libbirch::Shared<birch::type::TestLinearNormalInverseGammaGaussian>>();
    #line 6 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
    m->initialize();
    #line 7 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
    m->simulate();
    #line 8 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
    libbirch_line_(8);
    #line 8 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
    birch::test_grad(m->marginal(), N);
  }
  #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_linear_normal_inverse_gamma_gaussian.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
int birch::test_grad_matrix_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
  libbirch_function_("test_grad_matrix_gaussian", "src/test/grad/test_grad_matrix_gaussian.birch", 4);
  #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
  birch::type::Integer R = birch::type::Integer(4);
  #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
  birch::type::Integer C = birch::type::Integer(3);
  #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    RFLAG_,
    CFLAG_,
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
    {"R", required_argument, 0, RFLAG_ },
    #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
    {"C", required_argument, 0, CFLAG_ },
    #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
  };
  #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
      case RFLAG_:
        #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
        R = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
      case CFLAG_:
        #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
        C = birch::Integer(birch::type::String(::optarg));
        break;
      #line 5 "src/test/grad/test_grad_matrix_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/grad/test_grad_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/grad/test_grad_matrix_gaussian.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
      default:
        #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 6 "src/test/grad/test_grad_matrix_gaussian.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_matrix_gaussian.birch"
    libbirch::DefaultArray<birch::type::Real,2> M = libbirch::make_array<birch::type::Real>(libbirch::make_shape(R, C));
    #line 7 "src/test/grad/test_grad_matrix_gaussian.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_matrix_gaussian.birch"
    libbirch::DefaultArray<birch::type::Real,2> U = libbirch::make_array<birch::type::Real>(libbirch::make_shape(R, R));
    #line 8 "src/test/grad/test_grad_matrix_gaussian.birch"
    libbirch_line_(8);
    #line 8 "src/test/grad/test_grad_matrix_gaussian.birch"
    libbirch::DefaultArray<birch::type::Real,2> V = libbirch::make_array<birch::type::Real>(libbirch::make_shape(C, C));
    #line 10 "src/test/grad/test_grad_matrix_gaussian.birch"
    libbirch_line_(10);
    #line 10 "src/test/grad/test_grad_matrix_gaussian.birch"
    for (auto i = birch::type::Integer(1); i <= R; ++i) {
      #line 11 "src/test/grad/test_grad_matrix_gaussian.birch"
      libbirch_line_(11);
      #line 11 "src/test/grad/test_grad_matrix_gaussian.birch"
      for (auto j = birch::type::Integer(1); j <= C; ++j) {
        #line 12 "src/test/grad/test_grad_matrix_gaussian.birch"
        libbirch_line_(12);
        #line 12 "src/test/grad/test_grad_matrix_gaussian.birch"
        M(i, j) = birch::simulate_uniform(-(10.0), 10.0);
      }
    }
    #line 15 "src/test/grad/test_grad_matrix_gaussian.birch"
    libbirch_line_(15);
    #line 15 "src/test/grad/test_grad_matrix_gaussian.birch"
    for (auto i = birch::type::Integer(1); i <= R; ++i) {
      #line 16 "src/test/grad/test_grad_matrix_gaussian.birch"
      libbirch_line_(16);
      #line 16 "src/test/grad/test_grad_matrix_gaussian.birch"
      for (auto j = birch::type::Integer(1); j <= R; ++j) {
        #line 17 "src/test/grad/test_grad_matrix_gaussian.birch"
        libbirch_line_(17);
        #line 17 "src/test/grad/test_grad_matrix_gaussian.birch"
        U(i, j) = birch::simulate_uniform(-(2.0), 2.0);
      }
    }
    #line 20 "src/test/grad/test_grad_matrix_gaussian.birch"
    libbirch_line_(20);
    #line 20 "src/test/grad/test_grad_matrix_gaussian.birch"
    for (auto i = birch::type::Integer(1); i <= C; ++i) {
      #line 21 "src/test/grad/test_grad_matrix_gaussian.birch"
      libbirch_line_(21);
      #line 21 "src/test/grad/test_grad_matrix_gaussian.birch"
      for (auto j = birch::type::Integer(1); j <= C; ++j) {
        #line 22 "src/test/grad/test_grad_matrix_gaussian.birch"
        libbirch_line_(22);
        #line 22 "src/test/grad/test_grad_matrix_gaussian.birch"
        V(i, j) = birch::simulate_uniform(-(2.0), 2.0);
      }
    }
    #line 25 "src/test/grad/test_grad_matrix_gaussian.birch"
    libbirch_line_(25);
    #line 25 "src/test/grad/test_grad_matrix_gaussian.birch"
    U = U * birch::transpose(U);
    #line 26 "src/test/grad/test_grad_matrix_gaussian.birch"
    libbirch_line_(26);
    #line 26 "src/test/grad/test_grad_matrix_gaussian.birch"
    V = V * birch::transpose(V);
    #line 28 "src/test/grad/test_grad_matrix_gaussian.birch"
    libbirch_line_(28);
    #line 28 "src/test/grad/test_grad_matrix_gaussian.birch"
    auto π = birch::Gaussian(M, U, V);
    #line 29 "src/test/grad/test_grad_matrix_gaussian.birch"
    libbirch_line_(29);
    #line 29 "src/test/grad/test_grad_matrix_gaussian.birch"
    birch::test_grad(π, N);
  }
  #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_matrix_gaussian.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
int birch::test_grad_matrix_normal_inverse_wishart(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
  libbirch_function_("test_grad_matrix_normal_inverse_wishart", "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch", 4);
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
  birch::type::Integer R = birch::type::Integer(3);
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
  birch::type::Integer C = birch::type::Integer(2);
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    RFLAG_,
    CFLAG_,
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    {"R", required_argument, 0, RFLAG_ },
    #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    {"C", required_argument, 0, CFLAG_ },
    #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
  };
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
      case RFLAG_:
        #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
        R = birch::Integer(birch::type::String(::optarg));
        break;
      #line 5 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
      case CFLAG_:
        #line 5 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
        C = birch::Integer(birch::type::String(::optarg));
        break;
      #line 5 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
      case NFLAG_:
        #line 5 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
      default:
        #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 6 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    libbirch::DefaultArray<birch::type::Real,2> M = libbirch::make_array<birch::type::Real>(libbirch::make_shape(R, C));
    #line 7 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    libbirch::DefaultArray<birch::type::Real,2> U = libbirch::make_array<birch::type::Real>(libbirch::make_shape(R, R));
    #line 8 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    libbirch_line_(8);
    #line 8 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    birch::type::Real k = libbirch::make<birch::type::Real>();
    #line 9 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    libbirch_line_(9);
    #line 9 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    libbirch::DefaultArray<birch::type::Real,2> Ψ = libbirch::make_array<birch::type::Real>(libbirch::make_shape(C, C));
    #line 11 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    libbirch_line_(11);
    #line 11 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    for (auto i = birch::type::Integer(1); i <= R; ++i) {
      #line 12 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
      libbirch_line_(12);
      #line 12 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
      for (auto j = birch::type::Integer(1); j <= C; ++j) {
        #line 13 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
        libbirch_line_(13);
        #line 13 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
        M(i, j) = birch::simulate_uniform(-(10.0), 10.0);
      }
    }
    #line 16 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    libbirch_line_(16);
    #line 16 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    for (auto i = birch::type::Integer(1); i <= R; ++i) {
      #line 17 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
      libbirch_line_(17);
      #line 17 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
      for (auto j = birch::type::Integer(1); j <= R; ++j) {
        #line 18 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
        libbirch_line_(18);
        #line 18 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
        U(i, j) = birch::simulate_uniform(-(2.0), 2.0);
      }
    }
    #line 21 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    libbirch_line_(21);
    #line 21 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    k = C + 1.0 + birch::simulate_uniform(0.0, 10.0);
    #line 22 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    libbirch_line_(22);
    #line 22 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    for (auto i = birch::type::Integer(1); i <= C; ++i) {
      #line 23 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
      libbirch_line_(23);
      #line 23 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
      for (auto j = birch::type::Integer(1); j <= C; ++j) {
        #line 24 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
        libbirch_line_(24);
        #line 24 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
        Ψ(i, j) = birch::simulate_uniform(-(2.0), 2.0);
      }
    }
    #line 27 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    libbirch_line_(27);
    #line 27 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    U = U * birch::transpose(U);
    #line 28 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    libbirch_line_(28);
    #line 28 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    Ψ = Ψ * birch::transpose(Ψ);
    #line 30 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    libbirch_line_(30);
    #line 30 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    libbirch::Shared<birch::type::InverseWishart> V = libbirch::make<libbirch::Shared<birch::type::InverseWishart>>(std::in_place, birch::box(birch::llt(Ψ)), birch::box(k));
    #line 31 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    libbirch_line_(31);
    #line 31 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    libbirch::Shared<birch::type::MatrixNormalInverseWishart> π = libbirch::make<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>(std::in_place, birch::box(M), birch::box(birch::llt(U)), V);
    #line 32 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    libbirch_line_(32);
    #line 32 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
    birch::test_grad(π, N);
  }
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
int birch::test_grad_matrix_normal_inverse_wishart_matrix_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_function_("test_grad_matrix_normal_inverse_wishart_matrix_gaussian", "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch", 4);
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  };
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      default:
        #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 6 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    libbirch::Shared<birch::type::TestMatrixNormalInverseWishartMatrixGaussian> m = libbirch::make<libbirch::Shared<birch::type::TestMatrixNormalInverseWishartMatrixGaussian>>();
    #line 7 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    m->initialize();
    #line 8 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    libbirch_line_(8);
    #line 8 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    m->simulate();
    #line 9 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    libbirch_line_(9);
    #line 9 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    birch::test_grad(m->marginal(), N);
  }
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
int birch::test_grad_multivariate_gaussian_multivariate_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_function_("test_grad_multivariate_gaussian_multivariate_gaussian", "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch", 4);
  #line 4 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
  };
  #line 4 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
      default:
        #line 4 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 6 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
    libbirch::Shared<birch::type::TestMultivariateGaussianMultivariateGaussian> m = libbirch::make<libbirch::Shared<birch::type::TestMultivariateGaussianMultivariateGaussian>>();
    #line 7 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
    m->initialize();
    #line 8 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
    libbirch_line_(8);
    #line 8 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
    m->simulate();
    #line 9 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
    libbirch_line_(9);
    #line 9 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
    birch::test_grad(m->marginal(), N);
  }
  #line 4 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_multivariate_gaussian_multivariate_gaussian.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
int birch::test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_function_("test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch", 4);
  #line 4 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  };
  #line 4 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      default:
        #line 4 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 6 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    libbirch::Shared<birch::type::TestMultivariateNormalInverseGammaMultivariateGaussian> m = libbirch::make<libbirch::Shared<birch::type::TestMultivariateNormalInverseGammaMultivariateGaussian>>();
    #line 7 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    m->initialize();
    #line 8 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    libbirch_line_(8);
    #line 8 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    m->simulate();
    #line 9 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    libbirch_line_(9);
    #line 9 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    birch::test_grad(m->marginal(), N);
  }
  #line 4 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
int birch::test_grad_normal_inverse_gamma(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  libbirch_function_("test_grad_normal_inverse_gamma", "src/test/grad/test_grad_normal_inverse_gamma.birch", 4);
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  };
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
      default:
        #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/grad/test_grad_normal_inverse_gamma.birch"
    libbirch_line_(5);
    #line 5 "src/test/grad/test_grad_normal_inverse_gamma.birch"
    libbirch::Shared<birch::type::TestNormalInverseGamma> m = libbirch::make<libbirch::Shared<birch::type::TestNormalInverseGamma>>();
    #line 6 "src/test/grad/test_grad_normal_inverse_gamma.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_normal_inverse_gamma.birch"
    m->initialize();
    #line 7 "src/test/grad/test_grad_normal_inverse_gamma.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_normal_inverse_gamma.birch"
    m->simulate();
    #line 8 "src/test/grad/test_grad_normal_inverse_gamma.birch"
    libbirch_line_(8);
    #line 8 "src/test/grad/test_grad_normal_inverse_gamma.birch"
    birch::test_grad(m->marginal(), N);
  }
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
int birch::test_grad_normal_inverse_gamma_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  libbirch_function_("test_grad_normal_inverse_gamma_gaussian", "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch", 4);
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  };
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
      default:
        #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
    libbirch_line_(5);
    #line 5 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
    libbirch::Shared<birch::type::TestNormalInverseGammaGaussian> m = libbirch::make<libbirch::Shared<birch::type::TestNormalInverseGammaGaussian>>();
    #line 6 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
    m->initialize();
    #line 7 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
    m->simulate();
    #line 8 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
    libbirch_line_(8);
    #line 8 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
    birch::test_grad(m->marginal(), N);
  }
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_normal_inverse_gamma_gaussian.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
int birch::test_grad_scaled_gamma_exponential(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  libbirch_function_("test_grad_scaled_gamma_exponential", "src/test/grad/test_grad_scaled_gamma_exponential.birch", 4);
  #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  };
  #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
      default:
        #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
    libbirch_line_(5);
    #line 5 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
    libbirch::Shared<birch::type::TestScaledGammaExponential> m = libbirch::make<libbirch::Shared<birch::type::TestScaledGammaExponential>>();
    #line 6 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
    m->initialize();
    #line 7 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
    m->simulate();
    #line 8 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
    libbirch_line_(8);
    #line 8 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
    birch::test_grad(m->marginal(), N);
  }
  #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_scaled_gamma_exponential.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_student_t.birch"
int birch::test_grad_student_t(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_student_t.birch"
  libbirch_function_("test_grad_student_t", "src/test/grad/test_grad_student_t.birch", 4);
  #line 4 "src/test/grad/test_grad_student_t.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_student_t.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_student_t.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_student_t.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_student_t.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_student_t.birch"
  };
  #line 4 "src/test/grad/test_grad_student_t.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_student_t.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_student_t.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_student_t.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_student_t.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_student_t.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_student_t.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_student_t.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_student_t.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_student_t.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_student_t.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_student_t.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_student_t.birch"
      default:
        #line 4 "src/test/grad/test_grad_student_t.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_student_t.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/grad/test_grad_student_t.birch"
    libbirch_line_(5);
    #line 5 "src/test/grad/test_grad_student_t.birch"
    auto k = birch::simulate_uniform(1.0, 10.0);
    #line 6 "src/test/grad/test_grad_student_t.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_student_t.birch"
    auto μ = birch::simulate_uniform(-(10.0), 10.0);
    #line 7 "src/test/grad/test_grad_student_t.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_student_t.birch"
    auto σ2 = birch::simulate_uniform(0.0, 10.0);
    #line 8 "src/test/grad/test_grad_student_t.birch"
    libbirch_line_(8);
    #line 8 "src/test/grad/test_grad_student_t.birch"
    auto q = birch::Student(k, μ, σ2);
    #line 9 "src/test/grad/test_grad_student_t.birch"
    libbirch_line_(9);
    #line 9 "src/test/grad/test_grad_student_t.birch"
    birch::test_grad(q, N);
  }
  #line 4 "src/test/grad/test_grad_student_t.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_student_t.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_student_t.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_student_t.birch"
  return 0;
}

#line 4 "src/test/grad/test_grad_weibull.birch"
int birch::test_grad_weibull(int argc_, char** argv_) {
  #line 4 "src/test/grad/test_grad_weibull.birch"
  libbirch_function_("test_grad_weibull", "src/test/grad/test_grad_weibull.birch", 4);
  #line 4 "src/test/grad/test_grad_weibull.birch"
  birch::type::Integer N = birch::type::Integer(1000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/grad/test_grad_weibull.birch"
  int c_, option_index_;
  #line 4 "src/test/grad/test_grad_weibull.birch"
  option long_options_[] = {
    #line 4 "src/test/grad/test_grad_weibull.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/grad/test_grad_weibull.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/grad/test_grad_weibull.birch"
  };
  #line 4 "src/test/grad/test_grad_weibull.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/grad/test_grad_weibull.birch"
  ::opterr = 0;
  #line 4 "src/test/grad/test_grad_weibull.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/grad/test_grad_weibull.birch"
  while (c_ != -1) {
    #line 4 "src/test/grad/test_grad_weibull.birch"
    switch (c_) {
      #line 4 "src/test/grad/test_grad_weibull.birch"
      case NFLAG_:
        #line 4 "src/test/grad/test_grad_weibull.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/grad/test_grad_weibull.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/grad/test_grad_weibull.birch"
      case '?':
        #line 4 "src/test/grad/test_grad_weibull.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/grad/test_grad_weibull.birch"
      case ':':
        #line 4 "src/test/grad/test_grad_weibull.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/grad/test_grad_weibull.birch"
      default:
        #line 4 "src/test/grad/test_grad_weibull.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/grad/test_grad_weibull.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/grad/test_grad_weibull.birch"
    libbirch_line_(5);
    #line 5 "src/test/grad/test_grad_weibull.birch"
    auto k = birch::simulate_uniform(1.0, 10.0);
    #line 6 "src/test/grad/test_grad_weibull.birch"
    libbirch_line_(6);
    #line 6 "src/test/grad/test_grad_weibull.birch"
    auto λ = birch::simulate_uniform(0.1, 10.0);
    #line 7 "src/test/grad/test_grad_weibull.birch"
    libbirch_line_(7);
    #line 7 "src/test/grad/test_grad_weibull.birch"
    auto q = birch::Weibull(k, λ);
    #line 8 "src/test/grad/test_grad_weibull.birch"
    libbirch_line_(8);
    #line 8 "src/test/grad/test_grad_weibull.birch"
    birch::test_grad(q, N);
  }
  #line 4 "src/test/grad/test_grad_weibull.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_weibull.birch"
  libbirch::collect();
  #line 4 "src/test/grad/test_grad_weibull.birch"
  libbirch_line_(4);
  #line 4 "src/test/grad/test_grad_weibull.birch"
  return 0;
}

