#line 4 "src/test/cdf/test_cdf_beta.birch"
int birch::test_cdf_beta(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_beta.birch"
  libbirch_function_("test_cdf_beta", "src/test/cdf/test_cdf_beta.birch", 4);
  #line 4 "src/test/cdf/test_cdf_beta.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_beta.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_beta.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_beta.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_beta.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_beta.birch"
  };
  #line 4 "src/test/cdf/test_cdf_beta.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_beta.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_beta.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_beta.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_beta.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_beta.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_beta.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_beta.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_beta.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_beta.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_beta.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_beta.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_beta.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_beta.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_beta.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/cdf/test_cdf_beta.birch"
  libbirch_line_(5);
  #line 5 "src/test/cdf/test_cdf_beta.birch"
  auto _u0945 = birch::simulate_uniform(1.0, 10.0, handler_);
  #line 6 "src/test/cdf/test_cdf_beta.birch"
  libbirch_line_(6);
  #line 6 "src/test/cdf/test_cdf_beta.birch"
  auto _u0946 = birch::simulate_uniform(1.0, 10.0, handler_);
  #line 7 "src/test/cdf/test_cdf_beta.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_beta.birch"
  auto q = birch::Beta(_u0945, _u0946, handler_);
  #line 8 "src/test/cdf/test_cdf_beta.birch"
  libbirch_line_(8);
  #line 8 "src/test/cdf/test_cdf_beta.birch"
  birch::test_cdf(q, N, handler_);
  #line 4 "src/test/cdf/test_cdf_beta.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_beta.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_beta_binomial.birch"
int birch::test_cdf_beta_binomial(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_beta_binomial.birch"
  libbirch_function_("test_cdf_beta_binomial", "src/test/cdf/test_cdf_beta_binomial.birch", 4);
  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/cdf/test_cdf_beta_binomial.birch"
  libbirch_line_(5);
  #line 5 "src/test/cdf/test_cdf_beta_binomial.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestBetaBinomial>> m;
  #line 6 "src/test/cdf/test_cdf_beta_binomial.birch"
  libbirch_line_(6);
  #line 6 "src/test/cdf/test_cdf_beta_binomial.birch"
  m->initialize(handler_);
  #line 7 "src/test/cdf/test_cdf_beta_binomial.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_beta_binomial.birch"
  m->simulate(handler_);
  #line 8 "src/test/cdf/test_cdf_beta_binomial.birch"
  libbirch_line_(8);
  #line 8 "src/test/cdf/test_cdf_beta_binomial.birch"
  birch::test_cdf(m->marginal(handler_), handler_);
  #line 4 "src/test/cdf/test_cdf_beta_binomial.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_beta_binomial.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_binomial.birch"
int birch::test_cdf_binomial(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_binomial.birch"
  libbirch_function_("test_cdf_binomial", "src/test/cdf/test_cdf_binomial.birch", 4);
  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/cdf/test_cdf_binomial.birch"
  libbirch_line_(5);
  #line 5 "src/test/cdf/test_cdf_binomial.birch"
  auto n = birch::simulate_uniform_int(birch::type::Integer(0), birch::type::Integer(1000), handler_);
  #line 6 "src/test/cdf/test_cdf_binomial.birch"
  libbirch_line_(6);
  #line 6 "src/test/cdf/test_cdf_binomial.birch"
  auto _u0961 = birch::simulate_uniform(0.0, 1.0, handler_);
  #line 7 "src/test/cdf/test_cdf_binomial.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_binomial.birch"
  auto q = birch::Binomial(n, _u0961, handler_);
  #line 8 "src/test/cdf/test_cdf_binomial.birch"
  libbirch_line_(8);
  #line 8 "src/test/cdf/test_cdf_binomial.birch"
  birch::test_cdf(q, handler_);
  #line 4 "src/test/cdf/test_cdf_binomial.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_binomial.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_categorical.birch"
int birch::test_cdf_categorical(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_categorical.birch"
  libbirch_function_("test_cdf_categorical", "src/test/cdf/test_cdf_categorical.birch", 4);
  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/cdf/test_cdf_categorical.birch"
  libbirch_line_(5);
  #line 5 "src/test/cdf/test_cdf_categorical.birch"
  auto n = birch::simulate_uniform_int(birch::type::Integer(10), birch::type::Integer(50), handler_);
  #line 6 "src/test/cdf/test_cdf_categorical.birch"
  libbirch_line_(6);
  #line 6 "src/test/cdf/test_cdf_categorical.birch"
  auto _u0961 = birch::simulate_independent_uniform(birch::vector(0.0, n, handler_), birch::vector(1.0, n, handler_), handler_);
  #line 7 "src/test/cdf/test_cdf_categorical.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_categorical.birch"
  _u0961 = _u0961 / birch::sum(_u0961, handler_);
  #line 8 "src/test/cdf/test_cdf_categorical.birch"
  libbirch_line_(8);
  #line 8 "src/test/cdf/test_cdf_categorical.birch"
  auto q = birch::Categorical(_u0961, handler_);
  #line 9 "src/test/cdf/test_cdf_categorical.birch"
  libbirch_line_(9);
  #line 9 "src/test/cdf/test_cdf_categorical.birch"
  birch::test_cdf(q, handler_);
  #line 4 "src/test/cdf/test_cdf_categorical.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_categorical.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_exponential.birch"
int birch::test_cdf_exponential(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_exponential.birch"
  libbirch_function_("test_cdf_exponential", "src/test/cdf/test_cdf_exponential.birch", 4);
  #line 4 "src/test/cdf/test_cdf_exponential.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_exponential.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_exponential.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_exponential.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_exponential.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_exponential.birch"
  };
  #line 4 "src/test/cdf/test_cdf_exponential.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_exponential.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_exponential.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_exponential.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_exponential.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_exponential.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_exponential.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_exponential.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_exponential.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_exponential.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_exponential.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_exponential.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_exponential.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_exponential.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_exponential.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/cdf/test_cdf_exponential.birch"
  libbirch_line_(5);
  #line 5 "src/test/cdf/test_cdf_exponential.birch"
  auto _u0955 = birch::simulate_uniform(1.0, 10.0, handler_);
  #line 6 "src/test/cdf/test_cdf_exponential.birch"
  libbirch_line_(6);
  #line 6 "src/test/cdf/test_cdf_exponential.birch"
  auto q = birch::Exponential(_u0955, handler_);
  #line 7 "src/test/cdf/test_cdf_exponential.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_exponential.birch"
  birch::test_cdf(q, N, handler_);
  #line 4 "src/test/cdf/test_cdf_exponential.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_exponential.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_gamma.birch"
int birch::test_cdf_gamma(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_gamma.birch"
  libbirch_function_("test_cdf_gamma", "src/test/cdf/test_cdf_gamma.birch", 4);
  #line 4 "src/test/cdf/test_cdf_gamma.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_gamma.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_gamma.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_gamma.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_gamma.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_gamma.birch"
  };
  #line 4 "src/test/cdf/test_cdf_gamma.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_gamma.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_gamma.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_gamma.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_gamma.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_gamma.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_gamma.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_gamma.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_gamma.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_gamma.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_gamma.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_gamma.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_gamma.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_gamma.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_gamma.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/cdf/test_cdf_gamma.birch"
  libbirch_line_(5);
  #line 5 "src/test/cdf/test_cdf_gamma.birch"
  auto k = birch::simulate_uniform(1.0, 10.0, handler_);
  #line 6 "src/test/cdf/test_cdf_gamma.birch"
  libbirch_line_(6);
  #line 6 "src/test/cdf/test_cdf_gamma.birch"
  auto _u0952 = birch::simulate_uniform(0.0, 10.0, handler_);
  #line 7 "src/test/cdf/test_cdf_gamma.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_gamma.birch"
  auto q = birch::Gamma(k, _u0952, handler_);
  #line 8 "src/test/cdf/test_cdf_gamma.birch"
  libbirch_line_(8);
  #line 8 "src/test/cdf/test_cdf_gamma.birch"
  birch::test_cdf(q, N, handler_);
  #line 4 "src/test/cdf/test_cdf_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_gamma.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
int birch::test_cdf_gamma_exponential(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
  libbirch_function_("test_cdf_gamma_exponential", "src/test/cdf/test_cdf_gamma_exponential.birch", 4);
  #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
  };
  #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/cdf/test_cdf_gamma_exponential.birch"
  libbirch_line_(5);
  #line 5 "src/test/cdf/test_cdf_gamma_exponential.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestGammaExponential>> m;
  #line 6 "src/test/cdf/test_cdf_gamma_exponential.birch"
  libbirch_line_(6);
  #line 6 "src/test/cdf/test_cdf_gamma_exponential.birch"
  m->initialize(handler_);
  #line 7 "src/test/cdf/test_cdf_gamma_exponential.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_gamma_exponential.birch"
  m->simulate(handler_);
  #line 8 "src/test/cdf/test_cdf_gamma_exponential.birch"
  libbirch_line_(8);
  #line 8 "src/test/cdf/test_cdf_gamma_exponential.birch"
  birch::test_cdf(m->marginal(handler_), N, handler_);
  #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_gamma_poisson.birch"
int birch::test_cdf_gamma_poisson(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_gamma_poisson.birch"
  libbirch_function_("test_cdf_gamma_poisson", "src/test/cdf/test_cdf_gamma_poisson.birch", 4);
  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/cdf/test_cdf_gamma_poisson.birch"
  libbirch_line_(5);
  #line 5 "src/test/cdf/test_cdf_gamma_poisson.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestGammaPoisson>> m;
  #line 6 "src/test/cdf/test_cdf_gamma_poisson.birch"
  libbirch_line_(6);
  #line 6 "src/test/cdf/test_cdf_gamma_poisson.birch"
  m->initialize(handler_);
  #line 7 "src/test/cdf/test_cdf_gamma_poisson.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_gamma_poisson.birch"
  m->simulate(handler_);
  #line 8 "src/test/cdf/test_cdf_gamma_poisson.birch"
  libbirch_line_(8);
  #line 8 "src/test/cdf/test_cdf_gamma_poisson.birch"
  birch::test_cdf(m->marginal(handler_), handler_);
  #line 4 "src/test/cdf/test_cdf_gamma_poisson.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_gamma_poisson.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_gaussian.birch"
int birch::test_cdf_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_gaussian.birch"
  libbirch_function_("test_cdf_gaussian", "src/test/cdf/test_cdf_gaussian.birch", 4);
  #line 4 "src/test/cdf/test_cdf_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_gaussian.birch"
  };
  #line 4 "src/test/cdf/test_cdf_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_gaussian.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_gaussian.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_gaussian.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/cdf/test_cdf_gaussian.birch"
  libbirch_line_(5);
  #line 5 "src/test/cdf/test_cdf_gaussian.birch"
  auto _u0956 = birch::simulate_uniform(-10.0, 10.0, handler_);
  #line 6 "src/test/cdf/test_cdf_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/cdf/test_cdf_gaussian.birch"
  auto _u09632 = birch::simulate_uniform(0.0, 10.0, handler_);
  #line 7 "src/test/cdf/test_cdf_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_gaussian.birch"
  auto q = birch::Gaussian(_u0956, _u09632, handler_);
  #line 8 "src/test/cdf/test_cdf_gaussian.birch"
  libbirch_line_(8);
  #line 8 "src/test/cdf/test_cdf_gaussian.birch"
  birch::test_cdf(q, N, handler_);
  #line 4 "src/test/cdf/test_cdf_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_gaussian.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_geometric.birch"
int birch::test_cdf_geometric(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_geometric.birch"
  libbirch_function_("test_cdf_geometric", "src/test/cdf/test_cdf_geometric.birch", 4);
  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/cdf/test_cdf_geometric.birch"
  libbirch_line_(5);
  #line 5 "src/test/cdf/test_cdf_geometric.birch"
  auto _u0961 = birch::simulate_uniform(0.0, 1.0, handler_);
  #line 6 "src/test/cdf/test_cdf_geometric.birch"
  libbirch_line_(6);
  #line 6 "src/test/cdf/test_cdf_geometric.birch"
  auto q = birch::Geometric(_u0961, handler_);
  #line 7 "src/test/cdf/test_cdf_geometric.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_geometric.birch"
  birch::test_cdf(q, handler_);
  #line 4 "src/test/cdf/test_cdf_geometric.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_geometric.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
int birch::test_cdf_inverse_gamma(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
  libbirch_function_("test_cdf_inverse_gamma", "src/test/cdf/test_cdf_inverse_gamma.birch", 4);
  #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
  };
  #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/cdf/test_cdf_inverse_gamma.birch"
  libbirch_line_(5);
  #line 5 "src/test/cdf/test_cdf_inverse_gamma.birch"
  auto _u0945 = birch::simulate_uniform(2.0, 10.0, handler_);
  #line 6 "src/test/cdf/test_cdf_inverse_gamma.birch"
  libbirch_line_(6);
  #line 6 "src/test/cdf/test_cdf_inverse_gamma.birch"
  auto _u0946 = birch::simulate_uniform(0.1, 10.0, handler_);
  #line 7 "src/test/cdf/test_cdf_inverse_gamma.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_inverse_gamma.birch"
  auto q = birch::InverseGamma(_u0945, _u0946, handler_);
  #line 8 "src/test/cdf/test_cdf_inverse_gamma.birch"
  libbirch_line_(8);
  #line 8 "src/test/cdf/test_cdf_inverse_gamma.birch"
  birch::test_cdf(q, N, handler_);
  #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
int birch::test_cdf_inverse_gamma_gamma(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  libbirch_function_("test_cdf_inverse_gamma_gamma", "src/test/cdf/test_cdf_inverse_gamma_gamma.birch", 4);
  #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  };
  #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  libbirch_line_(5);
  #line 5 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestInverseGammaGamma>> m;
  #line 6 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  libbirch_line_(6);
  #line 6 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  m->initialize(handler_);
  #line 7 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  m->simulate(handler_);
  #line 8 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  libbirch_line_(8);
  #line 8 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  birch::test_cdf(m->marginal(handler_), N, handler_);
  #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
int birch::test_cdf_linear_gaussian_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  libbirch_function_("test_cdf_linear_gaussian_gaussian", "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch", 4);
  #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  };
  #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  libbirch_line_(5);
  #line 5 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestLinearGaussianGaussian>> m;
  #line 6 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  m->initialize(handler_);
  #line 7 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  m->simulate(handler_);
  #line 8 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  libbirch_line_(8);
  #line 8 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  birch::test_cdf(m->marginal(handler_), N, handler_);
  #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
int birch::test_cdf_linear_multivariate_normal_inverse_gamma_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch_function_("test_cdf_linear_multivariate_normal_inverse_gamma_gaussian", "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch", 4);
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  };
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestLinearMultivariateNormalInverseGammaGaussian>> m;
  #line 7 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  m->initialize(handler_);
  #line 8 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(8);
  #line 8 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  m->simulate(handler_);
  #line 9 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(9);
  #line 9 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  birch::test_cdf(m->marginal(handler_), N, handler_);
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
int birch::test_cdf_linear_normal_inverse_gamma_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_function_("test_cdf_linear_normal_inverse_gamma_gaussian", "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch", 4);
  #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  };
  #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(5);
  #line 5 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestLinearNormalInverseGammaGaussian>> m;
  #line 6 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  m->initialize(handler_);
  #line 7 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  m->simulate(handler_);
  #line 8 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(8);
  #line 8 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  birch::test_cdf(m->marginal(handler_), N, handler_);
  #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_negative_binomial.birch"
int birch::test_cdf_negative_binomial(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_negative_binomial.birch"
  libbirch_function_("test_cdf_negative_binomial", "src/test/cdf/test_cdf_negative_binomial.birch", 4);
  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/cdf/test_cdf_negative_binomial.birch"
  libbirch_line_(5);
  #line 5 "src/test/cdf/test_cdf_negative_binomial.birch"
  auto k = birch::simulate_uniform_int(birch::type::Integer(1), birch::type::Integer(20), handler_);
  #line 6 "src/test/cdf/test_cdf_negative_binomial.birch"
  libbirch_line_(6);
  #line 6 "src/test/cdf/test_cdf_negative_binomial.birch"
  auto _u0961 = birch::simulate_uniform(0.0, 1.0, handler_);
  #line 7 "src/test/cdf/test_cdf_negative_binomial.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_negative_binomial.birch"
  auto q = birch::NegativeBinomial(k, _u0961, handler_);
  #line 8 "src/test/cdf/test_cdf_negative_binomial.birch"
  libbirch_line_(8);
  #line 8 "src/test/cdf/test_cdf_negative_binomial.birch"
  birch::test_cdf(q, handler_);
  #line 4 "src/test/cdf/test_cdf_negative_binomial.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_negative_binomial.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
int birch::test_cdf_normal_inverse_gamma(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  libbirch_function_("test_cdf_normal_inverse_gamma", "src/test/cdf/test_cdf_normal_inverse_gamma.birch", 4);
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  };
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  libbirch_line_(5);
  #line 5 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestNormalInverseGamma>> m;
  #line 6 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  libbirch_line_(6);
  #line 6 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  m->initialize(handler_);
  #line 7 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  m->simulate(handler_);
  #line 8 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  libbirch_line_(8);
  #line 8 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  birch::test_cdf(m->marginal(handler_), N, handler_);
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
int birch::test_cdf_normal_inverse_gamma_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  libbirch_function_("test_cdf_normal_inverse_gamma_gaussian", "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch", 4);
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  };
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(5);
  #line 5 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestNormalInverseGammaGaussian>> m;
  #line 6 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  m->initialize(handler_);
  #line 7 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  m->simulate(handler_);
  #line 8 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(8);
  #line 8 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  birch::test_cdf(m->marginal(handler_), N, handler_);
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_poisson.birch"
int birch::test_cdf_poisson(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_poisson.birch"
  libbirch_function_("test_cdf_poisson", "src/test/cdf/test_cdf_poisson.birch", 4);
  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/cdf/test_cdf_poisson.birch"
  libbirch_line_(5);
  #line 5 "src/test/cdf/test_cdf_poisson.birch"
  auto _u0955 = birch::simulate_uniform(0.1, 100.0, handler_);
  #line 6 "src/test/cdf/test_cdf_poisson.birch"
  libbirch_line_(6);
  #line 6 "src/test/cdf/test_cdf_poisson.birch"
  auto q = birch::Poisson(_u0955, handler_);
  #line 7 "src/test/cdf/test_cdf_poisson.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_poisson.birch"
  birch::test_cdf(q, handler_);
  #line 4 "src/test/cdf/test_cdf_poisson.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_poisson.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
int birch::test_cdf_scaled_gamma_exponential(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  libbirch_function_("test_cdf_scaled_gamma_exponential", "src/test/cdf/test_cdf_scaled_gamma_exponential.birch", 4);
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  };
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  libbirch_line_(5);
  #line 5 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestScaledGammaExponential>> m;
  #line 6 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  libbirch_line_(6);
  #line 6 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  m->initialize(handler_);
  #line 7 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  m->simulate(handler_);
  #line 8 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  libbirch_line_(8);
  #line 8 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  birch::test_cdf(m->marginal(handler_), N, handler_);
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
int birch::test_cdf_scaled_gamma_poisson(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
  libbirch_function_("test_cdf_scaled_gamma_poisson", "src/test/cdf/test_cdf_scaled_gamma_poisson.birch", 4);
  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
  libbirch_line_(5);
  #line 5 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestScaledGammaPoisson>> m;
  #line 6 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
  libbirch_line_(6);
  #line 6 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
  m->initialize(handler_);
  #line 7 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
  m->simulate(handler_);
  #line 8 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
  libbirch_line_(8);
  #line 8 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
  birch::test_cdf(m->marginal(handler_), handler_);
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_student_t.birch"
int birch::test_cdf_student_t(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_student_t.birch"
  libbirch_function_("test_cdf_student_t", "src/test/cdf/test_cdf_student_t.birch", 4);
  #line 4 "src/test/cdf/test_cdf_student_t.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_student_t.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_student_t.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_student_t.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_student_t.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_student_t.birch"
  };
  #line 4 "src/test/cdf/test_cdf_student_t.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_student_t.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_student_t.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_student_t.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_student_t.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_student_t.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_student_t.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_student_t.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_student_t.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_student_t.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_student_t.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_student_t.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_student_t.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_student_t.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_student_t.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/cdf/test_cdf_student_t.birch"
  libbirch_line_(5);
  #line 5 "src/test/cdf/test_cdf_student_t.birch"
  auto k = birch::simulate_uniform(1.0, 10.0, handler_);
  #line 7 "src/test/cdf/test_cdf_student_t.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_student_t.birch"
  auto _u0956 = birch::simulate_uniform(-10.0, 10.0, handler_);
  #line 8 "src/test/cdf/test_cdf_student_t.birch"
  libbirch_line_(8);
  #line 8 "src/test/cdf/test_cdf_student_t.birch"
  auto _u09632 = birch::simulate_uniform(0.0, 10.0, handler_);
  #line 10 "src/test/cdf/test_cdf_student_t.birch"
  libbirch_line_(10);
  #line 10 "src/test/cdf/test_cdf_student_t.birch"
  auto q = birch::Student(k, _u0956, _u09632, handler_);
  #line 11 "src/test/cdf/test_cdf_student_t.birch"
  libbirch_line_(11);
  #line 11 "src/test/cdf/test_cdf_student_t.birch"
  birch::test_cdf(q, N, handler_);
  #line 4 "src/test/cdf/test_cdf_student_t.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_student_t.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_uniform.birch"
int birch::test_cdf_uniform(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_uniform.birch"
  libbirch_function_("test_cdf_uniform", "src/test/cdf/test_cdf_uniform.birch", 4);
  #line 4 "src/test/cdf/test_cdf_uniform.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_uniform.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_uniform.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_uniform.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_uniform.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_uniform.birch"
  };
  #line 4 "src/test/cdf/test_cdf_uniform.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_uniform.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_uniform.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_uniform.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_uniform.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_uniform.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_uniform.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_uniform.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_uniform.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_uniform.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_uniform.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_uniform.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_uniform.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_uniform.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_uniform.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/cdf/test_cdf_uniform.birch"
  libbirch_line_(5);
  #line 5 "src/test/cdf/test_cdf_uniform.birch"
  auto l = birch::simulate_uniform(-10.0, 10.0, handler_);
  #line 6 "src/test/cdf/test_cdf_uniform.birch"
  libbirch_line_(6);
  #line 6 "src/test/cdf/test_cdf_uniform.birch"
  auto u = birch::simulate_uniform(l, l + 20.0, handler_);
  #line 7 "src/test/cdf/test_cdf_uniform.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_uniform.birch"
  auto q = birch::Uniform(l, u, handler_);
  #line 8 "src/test/cdf/test_cdf_uniform.birch"
  libbirch_line_(8);
  #line 8 "src/test/cdf/test_cdf_uniform.birch"
  birch::test_cdf(q, N, handler_);
  #line 4 "src/test/cdf/test_cdf_uniform.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_uniform.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_uniform_int.birch"
int birch::test_cdf_uniform_int(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_uniform_int.birch"
  libbirch_function_("test_cdf_uniform_int", "src/test/cdf/test_cdf_uniform_int.birch", 4);
  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/cdf/test_cdf_uniform_int.birch"
  libbirch_line_(5);
  #line 5 "src/test/cdf/test_cdf_uniform_int.birch"
  auto l = birch::simulate_uniform_int(-birch::type::Integer(100), birch::type::Integer(100), handler_);
  #line 6 "src/test/cdf/test_cdf_uniform_int.birch"
  libbirch_line_(6);
  #line 6 "src/test/cdf/test_cdf_uniform_int.birch"
  auto u = birch::simulate_uniform_int(l, l + birch::type::Integer(200), handler_);
  #line 7 "src/test/cdf/test_cdf_uniform_int.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_uniform_int.birch"
  auto q = birch::Uniform(l, u, handler_);
  #line 8 "src/test/cdf/test_cdf_uniform_int.birch"
  libbirch_line_(8);
  #line 8 "src/test/cdf/test_cdf_uniform_int.birch"
  birch::test_cdf(q, handler_);
  #line 4 "src/test/cdf/test_cdf_uniform_int.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_uniform_int.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_weibull.birch"
int birch::test_cdf_weibull(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_weibull.birch"
  libbirch_function_("test_cdf_weibull", "src/test/cdf/test_cdf_weibull.birch", 4);
  #line 4 "src/test/cdf/test_cdf_weibull.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_weibull.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_weibull.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_weibull.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_weibull.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_weibull.birch"
  };
  #line 4 "src/test/cdf/test_cdf_weibull.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_weibull.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_weibull.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_weibull.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_weibull.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_weibull.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_weibull.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_weibull.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_weibull.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_weibull.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_weibull.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_weibull.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_weibull.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_weibull.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_weibull.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/cdf/test_cdf_weibull.birch"
  libbirch_line_(5);
  #line 5 "src/test/cdf/test_cdf_weibull.birch"
  auto k = birch::simulate_uniform(1.0, 10.0, handler_);
  #line 6 "src/test/cdf/test_cdf_weibull.birch"
  libbirch_line_(6);
  #line 6 "src/test/cdf/test_cdf_weibull.birch"
  auto _u0955 = birch::simulate_uniform(0.1, 10.0, handler_);
  #line 7 "src/test/cdf/test_cdf_weibull.birch"
  libbirch_line_(7);
  #line 7 "src/test/cdf/test_cdf_weibull.birch"
  auto q = birch::Weibull(k, _u0955, handler_);
  #line 8 "src/test/cdf/test_cdf_weibull.birch"
  libbirch_line_(8);
  #line 8 "src/test/cdf/test_cdf_weibull.birch"
  birch::test_cdf(q, N, handler_);
  #line 4 "src/test/cdf/test_cdf_weibull.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_weibull.birch"
  return 0;
}

