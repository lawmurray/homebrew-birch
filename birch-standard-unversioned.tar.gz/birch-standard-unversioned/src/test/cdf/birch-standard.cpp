#line 4 "src/test/cdf/test_cdf_beta.birch"
int birch::test_cdf_beta(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_beta.birch"
  libbirch_function_("test_cdf_beta", "src/test/cdf/test_cdf_beta.birch", 4);
  #line 4 "src/test/cdf/test_cdf_beta.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_beta.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_beta.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_beta.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_beta.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_beta.birch"
  };
  #line 4 "src/test/cdf/test_cdf_beta.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_beta.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_beta.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_beta.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_beta.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_beta.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_beta.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_beta.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_beta.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_beta.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_beta.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_beta.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_beta.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_beta.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_beta.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/cdf/test_cdf_beta.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_beta.birch"
    auto α = birch::simulate_uniform(1.0, 10.0);
    #line 6 "src/test/cdf/test_cdf_beta.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_beta.birch"
    auto β = birch::simulate_uniform(1.0, 10.0);
    #line 7 "src/test/cdf/test_cdf_beta.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_beta.birch"
    auto q = birch::Beta(α, β);
    #line 8 "src/test/cdf/test_cdf_beta.birch"
    libbirch_line_(8);
    #line 8 "src/test/cdf/test_cdf_beta.birch"
    birch::test_cdf(q, N);
  }
  #line 4 "src/test/cdf/test_cdf_beta.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_beta.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_beta.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_beta.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_beta_binomial.birch"
int birch::test_cdf_beta_binomial(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_beta_binomial.birch"
  libbirch_function_("test_cdf_beta_binomial", "src/test/cdf/test_cdf_beta_binomial.birch", 4);
  {
    #line 5 "src/test/cdf/test_cdf_beta_binomial.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_beta_binomial.birch"
    libbirch::Shared<birch::type::TestBetaBinomial> m = libbirch::make<libbirch::Shared<birch::type::TestBetaBinomial>>();
    #line 6 "src/test/cdf/test_cdf_beta_binomial.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_beta_binomial.birch"
    m->initialize();
    #line 7 "src/test/cdf/test_cdf_beta_binomial.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_beta_binomial.birch"
    m->simulate();
    #line 8 "src/test/cdf/test_cdf_beta_binomial.birch"
    libbirch_line_(8);
    #line 8 "src/test/cdf/test_cdf_beta_binomial.birch"
    birch::test_cdf(m->marginal());
  }
  #line 4 "src/test/cdf/test_cdf_beta_binomial.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_beta_binomial.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_beta_binomial.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_beta_binomial.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_binomial.birch"
int birch::test_cdf_binomial(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_binomial.birch"
  libbirch_function_("test_cdf_binomial", "src/test/cdf/test_cdf_binomial.birch", 4);
  {
    #line 5 "src/test/cdf/test_cdf_binomial.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_binomial.birch"
    auto n = birch::simulate_uniform_int(birch::type::Integer(0), birch::type::Integer(1000));
    #line 6 "src/test/cdf/test_cdf_binomial.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_binomial.birch"
    auto ρ = birch::simulate_uniform(0.0, 1.0);
    #line 7 "src/test/cdf/test_cdf_binomial.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_binomial.birch"
    auto q = birch::Binomial(n, ρ);
    #line 8 "src/test/cdf/test_cdf_binomial.birch"
    libbirch_line_(8);
    #line 8 "src/test/cdf/test_cdf_binomial.birch"
    birch::test_cdf(q);
  }
  #line 4 "src/test/cdf/test_cdf_binomial.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_binomial.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_binomial.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_binomial.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_categorical.birch"
int birch::test_cdf_categorical(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_categorical.birch"
  libbirch_function_("test_cdf_categorical", "src/test/cdf/test_cdf_categorical.birch", 4);
  {
    #line 5 "src/test/cdf/test_cdf_categorical.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_categorical.birch"
    auto n = birch::simulate_uniform_int(birch::type::Integer(10), birch::type::Integer(50));
    #line 6 "src/test/cdf/test_cdf_categorical.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_categorical.birch"
    auto ρ = birch::simulate_independent_uniform(birch::vector(0.0, n), birch::vector(1.0, n));
    #line 7 "src/test/cdf/test_cdf_categorical.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_categorical.birch"
    ρ = ρ / birch::sum(ρ);
    #line 8 "src/test/cdf/test_cdf_categorical.birch"
    libbirch_line_(8);
    #line 8 "src/test/cdf/test_cdf_categorical.birch"
    auto q = birch::Categorical(ρ);
    #line 9 "src/test/cdf/test_cdf_categorical.birch"
    libbirch_line_(9);
    #line 9 "src/test/cdf/test_cdf_categorical.birch"
    birch::test_cdf(q);
  }
  #line 4 "src/test/cdf/test_cdf_categorical.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_categorical.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_categorical.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_categorical.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_exponential.birch"
int birch::test_cdf_exponential(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_exponential.birch"
  libbirch_function_("test_cdf_exponential", "src/test/cdf/test_cdf_exponential.birch", 4);
  #line 4 "src/test/cdf/test_cdf_exponential.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_exponential.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_exponential.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_exponential.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_exponential.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_exponential.birch"
  };
  #line 4 "src/test/cdf/test_cdf_exponential.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_exponential.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_exponential.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_exponential.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_exponential.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_exponential.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_exponential.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_exponential.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_exponential.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_exponential.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_exponential.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_exponential.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_exponential.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_exponential.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_exponential.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/cdf/test_cdf_exponential.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_exponential.birch"
    auto λ = birch::simulate_uniform(1.0, 10.0);
    #line 6 "src/test/cdf/test_cdf_exponential.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_exponential.birch"
    auto q = birch::Exponential(λ);
    #line 7 "src/test/cdf/test_cdf_exponential.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_exponential.birch"
    birch::test_cdf(q, N);
  }
  #line 4 "src/test/cdf/test_cdf_exponential.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_exponential.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_exponential.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_exponential.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_gamma.birch"
int birch::test_cdf_gamma(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_gamma.birch"
  libbirch_function_("test_cdf_gamma", "src/test/cdf/test_cdf_gamma.birch", 4);
  #line 4 "src/test/cdf/test_cdf_gamma.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_gamma.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_gamma.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_gamma.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_gamma.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_gamma.birch"
  };
  #line 4 "src/test/cdf/test_cdf_gamma.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_gamma.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_gamma.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_gamma.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_gamma.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_gamma.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_gamma.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_gamma.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_gamma.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_gamma.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_gamma.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_gamma.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_gamma.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_gamma.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_gamma.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/cdf/test_cdf_gamma.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_gamma.birch"
    auto k = birch::simulate_uniform(1.0, 10.0);
    #line 6 "src/test/cdf/test_cdf_gamma.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_gamma.birch"
    auto θ = birch::simulate_uniform(0.0, 10.0);
    #line 7 "src/test/cdf/test_cdf_gamma.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_gamma.birch"
    auto q = birch::Gamma(k, θ);
    #line 8 "src/test/cdf/test_cdf_gamma.birch"
    libbirch_line_(8);
    #line 8 "src/test/cdf/test_cdf_gamma.birch"
    birch::test_cdf(q, N);
  }
  #line 4 "src/test/cdf/test_cdf_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_gamma.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_gamma.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
int birch::test_cdf_gamma_exponential(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
  libbirch_function_("test_cdf_gamma_exponential", "src/test/cdf/test_cdf_gamma_exponential.birch", 4);
  #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
  };
  #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/cdf/test_cdf_gamma_exponential.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_gamma_exponential.birch"
    libbirch::Shared<birch::type::TestGammaExponential> m = libbirch::make<libbirch::Shared<birch::type::TestGammaExponential>>();
    #line 6 "src/test/cdf/test_cdf_gamma_exponential.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_gamma_exponential.birch"
    m->initialize();
    #line 7 "src/test/cdf/test_cdf_gamma_exponential.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_gamma_exponential.birch"
    m->simulate();
    #line 8 "src/test/cdf/test_cdf_gamma_exponential.birch"
    libbirch_line_(8);
    #line 8 "src/test/cdf/test_cdf_gamma_exponential.birch"
    birch::test_cdf(m->marginal(), N);
  }
  #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_gamma_exponential.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_gamma_poisson.birch"
int birch::test_cdf_gamma_poisson(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_gamma_poisson.birch"
  libbirch_function_("test_cdf_gamma_poisson", "src/test/cdf/test_cdf_gamma_poisson.birch", 4);
  {
    #line 5 "src/test/cdf/test_cdf_gamma_poisson.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_gamma_poisson.birch"
    libbirch::Shared<birch::type::TestGammaPoisson> m = libbirch::make<libbirch::Shared<birch::type::TestGammaPoisson>>();
    #line 6 "src/test/cdf/test_cdf_gamma_poisson.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_gamma_poisson.birch"
    m->initialize();
    #line 7 "src/test/cdf/test_cdf_gamma_poisson.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_gamma_poisson.birch"
    m->simulate();
    #line 8 "src/test/cdf/test_cdf_gamma_poisson.birch"
    libbirch_line_(8);
    #line 8 "src/test/cdf/test_cdf_gamma_poisson.birch"
    birch::test_cdf(m->marginal());
  }
  #line 4 "src/test/cdf/test_cdf_gamma_poisson.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_gamma_poisson.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_gamma_poisson.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_gamma_poisson.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_gaussian.birch"
int birch::test_cdf_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_gaussian.birch"
  libbirch_function_("test_cdf_gaussian", "src/test/cdf/test_cdf_gaussian.birch", 4);
  #line 4 "src/test/cdf/test_cdf_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_gaussian.birch"
  };
  #line 4 "src/test/cdf/test_cdf_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_gaussian.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_gaussian.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_gaussian.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_gaussian.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/cdf/test_cdf_gaussian.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_gaussian.birch"
    auto μ = birch::simulate_uniform(-(10.0), 10.0);
    #line 6 "src/test/cdf/test_cdf_gaussian.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_gaussian.birch"
    auto σ2 = birch::simulate_uniform(0.0, 10.0);
    #line 7 "src/test/cdf/test_cdf_gaussian.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_gaussian.birch"
    auto q = birch::Gaussian(μ, σ2);
    #line 8 "src/test/cdf/test_cdf_gaussian.birch"
    libbirch_line_(8);
    #line 8 "src/test/cdf/test_cdf_gaussian.birch"
    birch::test_cdf(q, N);
  }
  #line 4 "src/test/cdf/test_cdf_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_gaussian.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_gaussian.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_geometric.birch"
int birch::test_cdf_geometric(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_geometric.birch"
  libbirch_function_("test_cdf_geometric", "src/test/cdf/test_cdf_geometric.birch", 4);
  {
    #line 5 "src/test/cdf/test_cdf_geometric.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_geometric.birch"
    auto ρ = birch::simulate_uniform(0.0, 1.0);
    #line 6 "src/test/cdf/test_cdf_geometric.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_geometric.birch"
    auto q = birch::Geometric(ρ);
    #line 7 "src/test/cdf/test_cdf_geometric.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_geometric.birch"
    birch::test_cdf(q);
  }
  #line 4 "src/test/cdf/test_cdf_geometric.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_geometric.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_geometric.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_geometric.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
int birch::test_cdf_inverse_gamma(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
  libbirch_function_("test_cdf_inverse_gamma", "src/test/cdf/test_cdf_inverse_gamma.birch", 4);
  #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
  };
  #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/cdf/test_cdf_inverse_gamma.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_inverse_gamma.birch"
    auto α = birch::simulate_uniform(2.0, 10.0);
    #line 6 "src/test/cdf/test_cdf_inverse_gamma.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_inverse_gamma.birch"
    auto β = birch::simulate_uniform(0.1, 10.0);
    #line 7 "src/test/cdf/test_cdf_inverse_gamma.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_inverse_gamma.birch"
    auto q = birch::InverseGamma(α, β);
    #line 8 "src/test/cdf/test_cdf_inverse_gamma.birch"
    libbirch_line_(8);
    #line 8 "src/test/cdf/test_cdf_inverse_gamma.birch"
    birch::test_cdf(q, N);
  }
  #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_inverse_gamma.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
int birch::test_cdf_inverse_gamma_gamma(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  libbirch_function_("test_cdf_inverse_gamma_gamma", "src/test/cdf/test_cdf_inverse_gamma_gamma.birch", 4);
  #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  };
  #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
    libbirch::Shared<birch::type::TestInverseGammaGamma> m = libbirch::make<libbirch::Shared<birch::type::TestInverseGammaGamma>>();
    #line 6 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
    m->initialize();
    #line 7 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
    m->simulate();
    #line 8 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
    libbirch_line_(8);
    #line 8 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
    birch::test_cdf(m->marginal(), N);
  }
  #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_inverse_gamma_gamma.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
int birch::test_cdf_linear_gaussian_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  libbirch_function_("test_cdf_linear_gaussian_gaussian", "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch", 4);
  #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  };
  #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
    libbirch::Shared<birch::type::TestLinearGaussianGaussian> m = libbirch::make<libbirch::Shared<birch::type::TestLinearGaussianGaussian>>();
    #line 6 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
    m->initialize();
    #line 7 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
    m->simulate();
    #line 8 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
    libbirch_line_(8);
    #line 8 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
    birch::test_cdf(m->marginal(), N);
  }
  #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_linear_gaussian_gaussian.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
int birch::test_cdf_linear_multivariate_gaussian_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
  libbirch_function_("test_cdf_linear_multivariate_gaussian_gaussian", "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch", 4);
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
  };
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
    libbirch::Shared<birch::type::TestLinearMultivariateGaussianGaussian> m = libbirch::make<libbirch::Shared<birch::type::TestLinearMultivariateGaussianGaussian>>();
    #line 6 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
    m->initialize();
    #line 7 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
    m->simulate();
    #line 8 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
    libbirch_line_(8);
    #line 8 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
    birch::test_cdf(m->marginal(), N);
  }
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_gaussian_gaussian.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
int birch::test_cdf_linear_multivariate_normal_inverse_gamma_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch_function_("test_cdf_linear_multivariate_normal_inverse_gamma_gaussian", "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch", 4);
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  };
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 6 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    libbirch::Shared<birch::type::TestLinearMultivariateNormalInverseGammaGaussian> m = libbirch::make<libbirch::Shared<birch::type::TestLinearMultivariateNormalInverseGammaGaussian>>();
    #line 7 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    m->initialize();
    #line 8 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    libbirch_line_(8);
    #line 8 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    m->simulate();
    #line 9 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    libbirch_line_(9);
    #line 9 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    birch::test_cdf(m->marginal(), N);
  }
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
int birch::test_cdf_linear_normal_inverse_gamma_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_function_("test_cdf_linear_normal_inverse_gamma_gaussian", "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch", 4);
  #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  };
  #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
    libbirch::Shared<birch::type::TestLinearNormalInverseGammaGaussian> m = libbirch::make<libbirch::Shared<birch::type::TestLinearNormalInverseGammaGaussian>>();
    #line 6 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
    m->initialize();
    #line 7 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
    m->simulate();
    #line 8 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
    libbirch_line_(8);
    #line 8 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
    birch::test_cdf(m->marginal(), N);
  }
  #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_linear_normal_inverse_gamma_gaussian.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_negative_binomial.birch"
int birch::test_cdf_negative_binomial(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_negative_binomial.birch"
  libbirch_function_("test_cdf_negative_binomial", "src/test/cdf/test_cdf_negative_binomial.birch", 4);
  {
    #line 5 "src/test/cdf/test_cdf_negative_binomial.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_negative_binomial.birch"
    auto k = birch::simulate_uniform_int(birch::type::Integer(1), birch::type::Integer(20));
    #line 6 "src/test/cdf/test_cdf_negative_binomial.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_negative_binomial.birch"
    auto ρ = birch::simulate_uniform(0.0, 1.0);
    #line 7 "src/test/cdf/test_cdf_negative_binomial.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_negative_binomial.birch"
    auto q = birch::NegativeBinomial(k, ρ);
    #line 8 "src/test/cdf/test_cdf_negative_binomial.birch"
    libbirch_line_(8);
    #line 8 "src/test/cdf/test_cdf_negative_binomial.birch"
    birch::test_cdf(q);
  }
  #line 4 "src/test/cdf/test_cdf_negative_binomial.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_negative_binomial.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_negative_binomial.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_negative_binomial.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
int birch::test_cdf_normal_inverse_gamma(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  libbirch_function_("test_cdf_normal_inverse_gamma", "src/test/cdf/test_cdf_normal_inverse_gamma.birch", 4);
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  };
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
    libbirch::Shared<birch::type::TestNormalInverseGamma> m = libbirch::make<libbirch::Shared<birch::type::TestNormalInverseGamma>>();
    #line 6 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
    m->initialize();
    #line 7 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
    m->simulate();
    #line 8 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
    libbirch_line_(8);
    #line 8 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
    birch::test_cdf(m->marginal(), N);
  }
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
int birch::test_cdf_normal_inverse_gamma_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  libbirch_function_("test_cdf_normal_inverse_gamma_gaussian", "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch", 4);
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  };
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
    libbirch::Shared<birch::type::TestNormalInverseGammaGaussian> m = libbirch::make<libbirch::Shared<birch::type::TestNormalInverseGammaGaussian>>();
    #line 6 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
    m->initialize();
    #line 7 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
    m->simulate();
    #line 8 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
    libbirch_line_(8);
    #line 8 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
    birch::test_cdf(m->marginal(), N);
  }
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_normal_inverse_gamma_gaussian.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_poisson.birch"
int birch::test_cdf_poisson(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_poisson.birch"
  libbirch_function_("test_cdf_poisson", "src/test/cdf/test_cdf_poisson.birch", 4);
  {
    #line 5 "src/test/cdf/test_cdf_poisson.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_poisson.birch"
    auto λ = birch::simulate_uniform(0.1, 100.0);
    #line 6 "src/test/cdf/test_cdf_poisson.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_poisson.birch"
    auto q = birch::Poisson(λ);
    #line 7 "src/test/cdf/test_cdf_poisson.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_poisson.birch"
    birch::test_cdf(q);
  }
  #line 4 "src/test/cdf/test_cdf_poisson.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_poisson.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_poisson.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_poisson.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
int birch::test_cdf_scaled_gamma_exponential(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  libbirch_function_("test_cdf_scaled_gamma_exponential", "src/test/cdf/test_cdf_scaled_gamma_exponential.birch", 4);
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  };
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
    libbirch::Shared<birch::type::TestScaledGammaExponential> m = libbirch::make<libbirch::Shared<birch::type::TestScaledGammaExponential>>();
    #line 6 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
    m->initialize();
    #line 7 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
    m->simulate();
    #line 8 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
    libbirch_line_(8);
    #line 8 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
    birch::test_cdf(m->marginal(), N);
  }
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_exponential.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
int birch::test_cdf_scaled_gamma_poisson(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
  libbirch_function_("test_cdf_scaled_gamma_poisson", "src/test/cdf/test_cdf_scaled_gamma_poisson.birch", 4);
  {
    #line 5 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
    libbirch::Shared<birch::type::TestScaledGammaPoisson> m = libbirch::make<libbirch::Shared<birch::type::TestScaledGammaPoisson>>();
    #line 6 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
    m->initialize();
    #line 7 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
    m->simulate();
    #line 8 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
    libbirch_line_(8);
    #line 8 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
    birch::test_cdf(m->marginal());
  }
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_scaled_gamma_poisson.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_student_t.birch"
int birch::test_cdf_student_t(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_student_t.birch"
  libbirch_function_("test_cdf_student_t", "src/test/cdf/test_cdf_student_t.birch", 4);
  #line 4 "src/test/cdf/test_cdf_student_t.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_student_t.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_student_t.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_student_t.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_student_t.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_student_t.birch"
  };
  #line 4 "src/test/cdf/test_cdf_student_t.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_student_t.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_student_t.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_student_t.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_student_t.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_student_t.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_student_t.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_student_t.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_student_t.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_student_t.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_student_t.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_student_t.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_student_t.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_student_t.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_student_t.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/cdf/test_cdf_student_t.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_student_t.birch"
    auto k = birch::simulate_uniform(1.0, 10.0);
    #line 7 "src/test/cdf/test_cdf_student_t.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_student_t.birch"
    auto μ = birch::simulate_uniform(-(10.0), 10.0);
    #line 8 "src/test/cdf/test_cdf_student_t.birch"
    libbirch_line_(8);
    #line 8 "src/test/cdf/test_cdf_student_t.birch"
    auto σ2 = birch::simulate_uniform(0.0, 10.0);
    #line 10 "src/test/cdf/test_cdf_student_t.birch"
    libbirch_line_(10);
    #line 10 "src/test/cdf/test_cdf_student_t.birch"
    auto q = birch::Student(k, μ, σ2);
    #line 11 "src/test/cdf/test_cdf_student_t.birch"
    libbirch_line_(11);
    #line 11 "src/test/cdf/test_cdf_student_t.birch"
    birch::test_cdf(q, N);
  }
  #line 4 "src/test/cdf/test_cdf_student_t.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_student_t.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_student_t.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_student_t.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_uniform.birch"
int birch::test_cdf_uniform(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_uniform.birch"
  libbirch_function_("test_cdf_uniform", "src/test/cdf/test_cdf_uniform.birch", 4);
  #line 4 "src/test/cdf/test_cdf_uniform.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_uniform.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_uniform.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_uniform.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_uniform.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_uniform.birch"
  };
  #line 4 "src/test/cdf/test_cdf_uniform.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_uniform.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_uniform.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_uniform.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_uniform.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_uniform.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_uniform.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_uniform.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_uniform.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_uniform.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_uniform.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_uniform.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_uniform.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_uniform.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_uniform.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/cdf/test_cdf_uniform.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_uniform.birch"
    auto l = birch::simulate_uniform(-(10.0), 10.0);
    #line 6 "src/test/cdf/test_cdf_uniform.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_uniform.birch"
    auto u = birch::simulate_uniform(l, l + 20.0);
    #line 7 "src/test/cdf/test_cdf_uniform.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_uniform.birch"
    auto q = birch::Uniform(l, u);
    #line 8 "src/test/cdf/test_cdf_uniform.birch"
    libbirch_line_(8);
    #line 8 "src/test/cdf/test_cdf_uniform.birch"
    birch::test_cdf(q, N);
  }
  #line 4 "src/test/cdf/test_cdf_uniform.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_uniform.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_uniform.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_uniform.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_uniform_int.birch"
int birch::test_cdf_uniform_int(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_uniform_int.birch"
  libbirch_function_("test_cdf_uniform_int", "src/test/cdf/test_cdf_uniform_int.birch", 4);
  {
    #line 5 "src/test/cdf/test_cdf_uniform_int.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_uniform_int.birch"
    auto l = birch::simulate_uniform_int(-(birch::type::Integer(100)), birch::type::Integer(100));
    #line 6 "src/test/cdf/test_cdf_uniform_int.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_uniform_int.birch"
    auto u = birch::simulate_uniform_int(l, l + birch::type::Integer(200));
    #line 7 "src/test/cdf/test_cdf_uniform_int.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_uniform_int.birch"
    auto q = birch::Uniform(l, u);
    #line 8 "src/test/cdf/test_cdf_uniform_int.birch"
    libbirch_line_(8);
    #line 8 "src/test/cdf/test_cdf_uniform_int.birch"
    birch::test_cdf(q);
  }
  #line 4 "src/test/cdf/test_cdf_uniform_int.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_uniform_int.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_uniform_int.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_uniform_int.birch"
  return 0;
}

#line 4 "src/test/cdf/test_cdf_weibull.birch"
int birch::test_cdf_weibull(int argc_, char** argv_) {
  #line 4 "src/test/cdf/test_cdf_weibull.birch"
  libbirch_function_("test_cdf_weibull", "src/test/cdf/test_cdf_weibull.birch", 4);
  #line 4 "src/test/cdf/test_cdf_weibull.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/cdf/test_cdf_weibull.birch"
  int c_, option_index_;
  #line 4 "src/test/cdf/test_cdf_weibull.birch"
  option long_options_[] = {
    #line 4 "src/test/cdf/test_cdf_weibull.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/cdf/test_cdf_weibull.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/cdf/test_cdf_weibull.birch"
  };
  #line 4 "src/test/cdf/test_cdf_weibull.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/cdf/test_cdf_weibull.birch"
  ::opterr = 0;
  #line 4 "src/test/cdf/test_cdf_weibull.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/cdf/test_cdf_weibull.birch"
  while (c_ != -1) {
    #line 4 "src/test/cdf/test_cdf_weibull.birch"
    switch (c_) {
      #line 4 "src/test/cdf/test_cdf_weibull.birch"
      case NFLAG_:
        #line 4 "src/test/cdf/test_cdf_weibull.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/cdf/test_cdf_weibull.birch"
        N = birch::Integer(birch::type::String(::optarg));
        break;
      #line 4 "src/test/cdf/test_cdf_weibull.birch"
      case '?':
        #line 4 "src/test/cdf/test_cdf_weibull.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/cdf/test_cdf_weibull.birch"
      case ':':
        #line 4 "src/test/cdf/test_cdf_weibull.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/cdf/test_cdf_weibull.birch"
      default:
        #line 4 "src/test/cdf/test_cdf_weibull.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/cdf/test_cdf_weibull.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  {
    #line 5 "src/test/cdf/test_cdf_weibull.birch"
    libbirch_line_(5);
    #line 5 "src/test/cdf/test_cdf_weibull.birch"
    auto k = birch::simulate_uniform(1.0, 10.0);
    #line 6 "src/test/cdf/test_cdf_weibull.birch"
    libbirch_line_(6);
    #line 6 "src/test/cdf/test_cdf_weibull.birch"
    auto λ = birch::simulate_uniform(0.1, 10.0);
    #line 7 "src/test/cdf/test_cdf_weibull.birch"
    libbirch_line_(7);
    #line 7 "src/test/cdf/test_cdf_weibull.birch"
    auto q = birch::Weibull(k, λ);
    #line 8 "src/test/cdf/test_cdf_weibull.birch"
    libbirch_line_(8);
    #line 8 "src/test/cdf/test_cdf_weibull.birch"
    birch::test_cdf(q, N);
  }
  #line 4 "src/test/cdf/test_cdf_weibull.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_weibull.birch"
  libbirch::collect();
  #line 4 "src/test/cdf/test_cdf_weibull.birch"
  libbirch_line_(4);
  #line 4 "src/test/cdf/test_cdf_weibull.birch"
  return 0;
}

