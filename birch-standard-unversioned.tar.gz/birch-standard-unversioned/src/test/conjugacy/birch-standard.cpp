#line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
int birch::test_add_bounded_discrete_delta(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
  libbirch_function_("test_add_bounded_discrete_delta", "src/test/conjugacy/test_add_bounded_discrete_delta.birch", 4);
  #line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
  };
  #line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
      default:
        #line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestAddBoundedDiscreteDelta>> m;
  #line 6 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(2), handler_);
  #line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_add_bounded_discrete_delta.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
int birch::test_beta_bernoulli(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
  libbirch_function_("test_beta_bernoulli", "src/test/conjugacy/test_beta_bernoulli.birch", 4);
  #line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
  };
  #line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
      default:
        #line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_beta_bernoulli.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_beta_bernoulli.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestBetaBernoulli>> m;
  #line 6 "src/test/conjugacy/test_beta_bernoulli.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_beta_bernoulli.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(2), handler_);
  #line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_beta_bernoulli.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_beta_binomial.birch"
int birch::test_beta_binomial(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_beta_binomial.birch"
  libbirch_function_("test_beta_binomial", "src/test/conjugacy/test_beta_binomial.birch", 4);
  #line 4 "src/test/conjugacy/test_beta_binomial.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_beta_binomial.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_beta_binomial.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_beta_binomial.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_beta_binomial.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_beta_binomial.birch"
  };
  #line 4 "src/test/conjugacy/test_beta_binomial.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_beta_binomial.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_beta_binomial.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_beta_binomial.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_beta_binomial.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_beta_binomial.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_beta_binomial.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_beta_binomial.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_beta_binomial.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_beta_binomial.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_beta_binomial.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_beta_binomial.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_beta_binomial.birch"
      default:
        #line 4 "src/test/conjugacy/test_beta_binomial.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_beta_binomial.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_beta_binomial.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_beta_binomial.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestBetaBinomial>> m;
  #line 6 "src/test/conjugacy/test_beta_binomial.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_beta_binomial.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(2), handler_);
  #line 4 "src/test/conjugacy/test_beta_binomial.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_beta_binomial.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_beta_geometric.birch"
int birch::test_beta_geometric(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_beta_geometric.birch"
  libbirch_function_("test_beta_geometric", "src/test/conjugacy/test_beta_geometric.birch", 4);
  #line 4 "src/test/conjugacy/test_beta_geometric.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_beta_geometric.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_beta_geometric.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_beta_geometric.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_beta_geometric.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_beta_geometric.birch"
  };
  #line 4 "src/test/conjugacy/test_beta_geometric.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_beta_geometric.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_beta_geometric.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_beta_geometric.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_beta_geometric.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_beta_geometric.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_beta_geometric.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_beta_geometric.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_beta_geometric.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_beta_geometric.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_beta_geometric.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_beta_geometric.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_beta_geometric.birch"
      default:
        #line 4 "src/test/conjugacy/test_beta_geometric.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_beta_geometric.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_beta_geometric.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_beta_geometric.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestBetaGeometric>> m;
  #line 6 "src/test/conjugacy/test_beta_geometric.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_beta_geometric.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(2), handler_);
  #line 4 "src/test/conjugacy/test_beta_geometric.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_beta_geometric.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
int birch::test_beta_negative_binomial(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
  libbirch_function_("test_beta_negative_binomial", "src/test/conjugacy/test_beta_negative_binomial.birch", 4);
  #line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
  };
  #line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
      default:
        #line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_beta_negative_binomial.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_beta_negative_binomial.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestBetaNegativeBinomial>> m;
  #line 6 "src/test/conjugacy/test_beta_negative_binomial.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_beta_negative_binomial.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(2), handler_);
  #line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_beta_negative_binomial.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_chain_gaussian.birch"
int birch::test_chain_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_chain_gaussian.birch"
  libbirch_function_("test_chain_gaussian", "src/test/conjugacy/test_chain_gaussian.birch", 4);
  #line 4 "src/test/conjugacy/test_chain_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_chain_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_chain_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_chain_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_chain_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_chain_gaussian.birch"
  };
  #line 4 "src/test/conjugacy/test_chain_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_chain_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_chain_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_chain_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_chain_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_chain_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_chain_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_chain_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_chain_gaussian.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_chain_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_chain_gaussian.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_chain_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_chain_gaussian.birch"
      default:
        #line 4 "src/test/conjugacy/test_chain_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_chain_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_chain_gaussian.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_chain_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestChainGaussian>> m;
  #line 6 "src/test/conjugacy/test_chain_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_chain_gaussian.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(5), handler_);
  #line 4 "src/test/conjugacy/test_chain_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_chain_gaussian.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
int birch::test_chain_multivariate_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
  libbirch_function_("test_chain_multivariate_gaussian", "src/test/conjugacy/test_chain_multivariate_gaussian.birch", 4);
  #line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
  };
  #line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
      default:
        #line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestChainMultivariateGaussian>> m;
  #line 6 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(15), handler_);
  #line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_chain_multivariate_gaussian.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
int birch::test_dirichlet_categorical(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
  libbirch_function_("test_dirichlet_categorical", "src/test/conjugacy/test_dirichlet_categorical.birch", 4);
  #line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
  };
  #line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
      default:
        #line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_dirichlet_categorical.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_dirichlet_categorical.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestDirichletCategorical>> m;
  #line 6 "src/test/conjugacy/test_dirichlet_categorical.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_dirichlet_categorical.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(6), handler_);
  #line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_dirichlet_categorical.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
int birch::test_dirichlet_multinomial(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
  libbirch_function_("test_dirichlet_multinomial", "src/test/conjugacy/test_dirichlet_multinomial.birch", 4);
  #line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
  };
  #line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
      default:
        #line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_dirichlet_multinomial.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_dirichlet_multinomial.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestDirichletMultinomial>> m;
  #line 6 "src/test/conjugacy/test_dirichlet_multinomial.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_dirichlet_multinomial.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(10), handler_);
  #line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_dirichlet_multinomial.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_gamma_exponential.birch"
int birch::test_gamma_exponential(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_gamma_exponential.birch"
  libbirch_function_("test_gamma_exponential", "src/test/conjugacy/test_gamma_exponential.birch", 4);
  #line 4 "src/test/conjugacy/test_gamma_exponential.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_gamma_exponential.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_gamma_exponential.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_gamma_exponential.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_gamma_exponential.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_gamma_exponential.birch"
  };
  #line 4 "src/test/conjugacy/test_gamma_exponential.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_gamma_exponential.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_gamma_exponential.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_gamma_exponential.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_gamma_exponential.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_gamma_exponential.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_gamma_exponential.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_gamma_exponential.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_gamma_exponential.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_gamma_exponential.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_gamma_exponential.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_gamma_exponential.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_gamma_exponential.birch"
      default:
        #line 4 "src/test/conjugacy/test_gamma_exponential.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_gamma_exponential.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_gamma_exponential.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_gamma_exponential.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestGammaExponential>> m;
  #line 6 "src/test/conjugacy/test_gamma_exponential.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_gamma_exponential.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(2), handler_);
  #line 4 "src/test/conjugacy/test_gamma_exponential.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_gamma_exponential.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_gamma_poisson.birch"
int birch::test_gamma_poisson(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_gamma_poisson.birch"
  libbirch_function_("test_gamma_poisson", "src/test/conjugacy/test_gamma_poisson.birch", 4);
  #line 4 "src/test/conjugacy/test_gamma_poisson.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_gamma_poisson.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_gamma_poisson.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_gamma_poisson.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_gamma_poisson.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_gamma_poisson.birch"
  };
  #line 4 "src/test/conjugacy/test_gamma_poisson.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_gamma_poisson.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_gamma_poisson.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_gamma_poisson.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_gamma_poisson.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_gamma_poisson.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_gamma_poisson.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_gamma_poisson.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_gamma_poisson.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_gamma_poisson.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_gamma_poisson.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_gamma_poisson.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_gamma_poisson.birch"
      default:
        #line 4 "src/test/conjugacy/test_gamma_poisson.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_gamma_poisson.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_gamma_poisson.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_gamma_poisson.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestGammaPoisson>> m;
  #line 6 "src/test/conjugacy/test_gamma_poisson.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_gamma_poisson.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(2), handler_);
  #line 4 "src/test/conjugacy/test_gamma_poisson.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_gamma_poisson.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
int birch::test_gaussian_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
  libbirch_function_("test_gaussian_gaussian", "src/test/conjugacy/test_gaussian_gaussian.birch", 4);
  #line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
  };
  #line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
      default:
        #line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_gaussian_gaussian.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_gaussian_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestGaussianGaussian>> m;
  #line 6 "src/test/conjugacy/test_gaussian_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_gaussian_gaussian.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(2), handler_);
  #line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_gaussian_gaussian.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
int birch::test_inverse_gamma_gamma(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
  libbirch_function_("test_inverse_gamma_gamma", "src/test/conjugacy/test_inverse_gamma_gamma.birch", 4);
  #line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
  };
  #line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
      default:
        #line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestInverseGammaGamma>> m;
  #line 6 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(2), handler_);
  #line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_inverse_gamma_gamma.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
int birch::test_linear_discrete_delta(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
  libbirch_function_("test_linear_discrete_delta", "src/test/conjugacy/test_linear_discrete_delta.birch", 4);
  #line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
  };
  #line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
      default:
        #line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_linear_discrete_delta.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_linear_discrete_delta.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestLinearDiscreteDelta>> m;
  #line 6 "src/test/conjugacy/test_linear_discrete_delta.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_linear_discrete_delta.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(2), handler_);
  #line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_linear_discrete_delta.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
int birch::test_linear_gaussian_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
  libbirch_function_("test_linear_gaussian_gaussian", "src/test/conjugacy/test_linear_gaussian_gaussian.birch", 4);
  #line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
  };
  #line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
      default:
        #line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestLinearGaussianGaussian>> m;
  #line 6 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(2), handler_);
  #line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_linear_gaussian_gaussian.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
int birch::test_linear_matrix_normal_inverse_gamma_matrix_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  libbirch_function_("test_linear_matrix_normal_inverse_gamma_matrix_gaussian", "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch", 4);
  #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  };
  #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
      default:
        #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestLinearMatrixNormalInverseGammaMatrixGaussian>> m;
  #line 7 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  birch::test_conjugacy(m, N, m->size(handler_), handler_);
  #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
int birch::test_linear_matrix_normal_inverse_wishart_matrix_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_function_("test_linear_matrix_normal_inverse_wishart_matrix_gaussian", "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch", 4);
  #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  };
  #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      default:
        #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestLinearMatrixNormalInverseWishartMatrixGaussian>> m;
  #line 7 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  birch::test_conjugacy(m, N, m->size(handler_), handler_);
  #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
int birch::test_linear_multivariate_gaussian_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
  libbirch_function_("test_linear_multivariate_gaussian_gaussian", "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch", 4);
  #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
  };
  #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
      default:
        #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestLinearMultivariateGaussianGaussian>> m;
  #line 7 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(6), handler_);
  #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_gaussian.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
int birch::test_linear_multivariate_gaussian_multivariate_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_function_("test_linear_multivariate_gaussian_multivariate_gaussian", "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch", 4);
  #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
  };
  #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
      default:
        #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestLinearMultivariateGaussianMultivariateGaussian>> m;
  #line 7 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(10), handler_);
  #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_linear_multivariate_gaussian_multivariate_gaussian.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
int birch::test_linear_multivariate_normal_inverse_gamma_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch_function_("test_linear_multivariate_normal_inverse_gamma_gaussian", "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch", 4);
  #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  };
  #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
      default:
        #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestLinearMultivariateNormalInverseGammaGaussian>> m;
  #line 7 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(12), handler_);
  #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_gaussian.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
int birch::test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_function_("test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch", 4);
  #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  };
  #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      default:
        #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestLinearMultivariateNormalInverseGammaMultivariateGaussian>> m;
  #line 7 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(16), handler_);
  #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
int birch::test_linear_normal_inverse_gamma_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_function_("test_linear_normal_inverse_gamma_gaussian", "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch", 4);
  #line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
  };
  #line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
      default:
        #line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestLinearNormalInverseGammaGaussian>> m;
  #line 6 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(3), handler_);
  #line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_linear_normal_inverse_gamma_gaussian.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
int birch::test_matrix_normal_inverse_gamma_matrix_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  libbirch_function_("test_matrix_normal_inverse_gamma_matrix_gaussian", "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch", 4);
  #line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  };
  #line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
      default:
        #line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestMatrixNormalInverseGammaMatrixGaussian>> m;
  #line 6 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  birch::test_conjugacy(m, N, m->size(handler_), handler_);
  #line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
int birch::test_matrix_normal_inverse_wishart_matrix_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_function_("test_matrix_normal_inverse_wishart_matrix_gaussian", "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch", 4);
  #line 4 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  };
  #line 4 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      default:
        #line 4 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestMatrixNormalInverseWishartMatrixGaussian>> m;
  #line 7 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  birch::test_conjugacy(m, N, m->size(handler_), handler_);
  #line 4 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
int birch::test_multivariate_gaussian_multivariate_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_function_("test_multivariate_gaussian_multivariate_gaussian", "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch", 4);
  #line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
  };
  #line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
      default:
        #line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestMultivariateGaussianMultivariateGaussian>> m;
  #line 6 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(10), handler_);
  #line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_multivariate_gaussian_multivariate_gaussian.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
int birch::test_multivariate_normal_inverse_gamma_multivariate_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_function_("test_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch", 4);
  #line 4 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  };
  #line 4 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      default:
        #line 4 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestMultivariateNormalInverseGammaMultivariateGaussian>> m;
  #line 7 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(11), handler_);
  #line 4 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
int birch::test_negative_linear_discrete_delta(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
  libbirch_function_("test_negative_linear_discrete_delta", "src/test/conjugacy/test_negative_linear_discrete_delta.birch", 4);
  #line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
  };
  #line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
      default:
        #line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestNegativeLinearDiscreteDelta>> m;
  #line 6 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(2), handler_);
  #line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_negative_linear_discrete_delta.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
int birch::test_negative_linear_gaussian_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
  libbirch_function_("test_negative_linear_gaussian_gaussian", "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch", 4);
  #line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
  };
  #line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
      default:
        #line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestNegativeLinearGaussianGaussian>> m;
  #line 6 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(2), handler_);
  #line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_negative_linear_gaussian_gaussian.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
int birch::test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  libbirch_function_("test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian", "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch", 4);
  #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  };
  #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
      default:
        #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestNegativeLinearMatrixNormalInverseGammaMatrixGaussian>> m;
  #line 7 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  birch::test_conjugacy(m, N, m->size(handler_), handler_);
  #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_gamma_matrix_gaussian.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
int birch::test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_function_("test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian", "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch", 4);
  #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  };
  #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
      default:
        #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestNegativeLinearMatrixNormalInverseWishartMatrixGaussian>> m;
  #line 7 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  birch::test_conjugacy(m, N, m->size(handler_), handler_);
  #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_negative_linear_matrix_normal_inverse_wishart_matrix_gaussian.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
int birch::test_negative_linear_multivariate_gaussian_multivariate_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_function_("test_negative_linear_multivariate_gaussian_multivariate_gaussian", "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch", 4);
  #line 4 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
  };
  #line 4 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
      default:
        #line 4 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestNegativeLinearMultivariateGaussianMultivariateGaussian>> m;
  #line 7 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(10), handler_);
  #line 4 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_negative_linear_multivariate_gaussian_multivariate_gaussian.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
int birch::test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_function_("test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian", "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch", 4);
  #line 4 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  };
  #line 4 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    switch (c_) {
      #line 5 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case NFLAG_:
        #line 5 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
      default:
        #line 4 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestNegativeLinearMultivariateNormalInverseGammaMultivariateGaussian>> m;
  #line 7 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_line_(7);
  #line 7 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(16), handler_);
  #line 4 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_negative_linear_multivariate_normal_inverse_gamma_multivariate_gaussian.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
int birch::test_negative_linear_normal_inverse_gamma_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_function_("test_negative_linear_normal_inverse_gamma_gaussian", "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch", 4);
  #line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
  };
  #line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
      default:
        #line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestNegativeLinearNormalInverseGammaGaussian>> m;
  #line 6 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(3), handler_);
  #line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_negative_linear_normal_inverse_gamma_gaussian.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
int birch::test_negative_scaled_gamma_exponential(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
  libbirch_function_("test_negative_scaled_gamma_exponential", "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch", 4);
  #line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
  };
  #line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
      default:
        #line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestNegativeScaledGammaExponential>> m;
  #line 6 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(2), handler_);
  #line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_negative_scaled_gamma_exponential.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
int birch::test_negative_scaled_gamma_poisson(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
  libbirch_function_("test_negative_scaled_gamma_poisson", "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch", 4);
  #line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
  };
  #line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
      default:
        #line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestNegativeScaledGammaPoisson>> m;
  #line 6 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(2), handler_);
  #line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_negative_scaled_gamma_poisson.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
int birch::test_normal_inverse_gamma(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
  libbirch_function_("test_normal_inverse_gamma", "src/test/conjugacy/test_normal_inverse_gamma.birch", 4);
  #line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
  };
  #line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
      default:
        #line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_normal_inverse_gamma.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_normal_inverse_gamma.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestNormalInverseGamma>> m;
  #line 6 "src/test/conjugacy/test_normal_inverse_gamma.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_normal_inverse_gamma.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(2), handler_);
  #line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_normal_inverse_gamma.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
int birch::test_normal_inverse_gamma_gaussian(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
  libbirch_function_("test_normal_inverse_gamma_gaussian", "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch", 4);
  #line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
  };
  #line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
      default:
        #line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestNormalInverseGammaGaussian>> m;
  #line 6 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(3), handler_);
  #line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_normal_inverse_gamma_gaussian.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
int birch::test_scaled_gamma_exponential(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
  libbirch_function_("test_scaled_gamma_exponential", "src/test/conjugacy/test_scaled_gamma_exponential.birch", 4);
  #line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
  };
  #line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
      default:
        #line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestScaledGammaExponential>> m;
  #line 6 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(2), handler_);
  #line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_scaled_gamma_exponential.birch"
  return 0;
}

#line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
int birch::test_scaled_gamma_poisson(int argc_, char** argv_) {
  #line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
  libbirch_function_("test_scaled_gamma_poisson", "src/test/conjugacy/test_scaled_gamma_poisson.birch", 4);
  #line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
  int c_, option_index_;
  #line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
  option long_options_[] = {
    #line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
    {0, 0, 0, 0}
  #line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
  };
  #line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
  const char* short_options_ = ":";
  #line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
  ::opterr = 0;
  #line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
  while (c_ != -1) {
    #line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
    switch (c_) {
      #line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
      case NFLAG_:
        #line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
      case '?':
        #line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
      case ':':
        #line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
      default:
        #line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestScaledGammaPoisson>> m;
  #line 6 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(2), handler_);
  #line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
  libbirch_line_(4);
  #line 4 "src/test/conjugacy/test_scaled_gamma_poisson.birch"
  return 0;
}

#line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
int birch::test_subtract_bounded_discrete_delta(int argc_, char** argv_) {
  #line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
  libbirch_function_("test_subtract_bounded_discrete_delta", "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch", 5);
  #line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
  birch::type::Integer N = birch::type::Integer(10000);
  
  enum {
    NFLAG_,
  };
  #line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
  int c_, option_index_;
  #line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
  option long_options_[] = {
    #line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
    {"N", required_argument, 0, NFLAG_ },
    #line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
    {0, 0, 0, 0}
  #line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
  };
  #line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
  const char* short_options_ = ":";
  #line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
  ::opterr = 0;
  #line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
  while (c_ != -1) {
    #line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
    switch (c_) {
      #line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
      case NFLAG_:
        #line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
        N = birch::Integer(std::string(::optarg));
        break;
      #line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
      case '?':
        #line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
      case ':':
        #line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
      default:
        #line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 6 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
  libbirch_line_(6);
  #line 6 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::TestSubtractBoundedDiscreteDelta>> m;
  #line 7 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
  libbirch_line_(7);
  #line 7 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
  birch::test_conjugacy(m, N, birch::type::Integer(2), handler_);
  #line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
  libbirch_line_(5);
  #line 5 "src/test/conjugacy/test_subtract_bounded_discrete_delta.birch"
  return 0;
}

