#line 9 "src/test/test.birch"
birch::type::Boolean birch::pass(const libbirch::DefaultArray<birch::type::Real,1>& x1, const libbirch::DefaultArray<birch::type::Real,1>& x2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/test/test.birch"
  libbirch_function_("pass", "src/test/test.birch", 9);
  #line 10 "src/test/test.birch"
  libbirch_line_(10);
  #line 10 "src/test/test.birch"
  libbirch_assert_(birch::length(x1, handler_) == birch::length(x2, handler_));
  #line 12 "src/test/test.birch"
  libbirch_line_(12);
  #line 12 "src/test/test.birch"
  auto N = birch::length(x1, handler_);
  #line 13 "src/test/test.birch"
  libbirch_line_(13);
  #line 13 "src/test/test.birch"
  auto _u0949 = 4.0 / birch::sqrt(birch::Real(N, handler_), handler_);
  #line 16 "src/test/test.birch"
  libbirch_line_(16);
  #line 16 "src/test/test.birch"
  auto mn = birch::min(birch::min(x1, handler_), birch::min(x2, handler_), handler_);
  #line 17 "src/test/test.birch"
  libbirch_line_(17);
  #line 17 "src/test/test.birch"
  auto mx = birch::max(birch::max(x1, handler_), birch::max(x2, handler_), handler_);
  #line 18 "src/test/test.birch"
  libbirch_line_(18);
  #line 18 "src/test/test.birch"
  auto z1 = (x1 - birch::vector(mn, N, handler_)) / (mx - mn);
  #line 19 "src/test/test.birch"
  libbirch_line_(19);
  #line 19 "src/test/test.birch"
  auto z2 = (x2 - birch::vector(mn, N, handler_)) / (mx - mn);
  #line 22 "src/test/test.birch"
  libbirch_line_(22);
  #line 22 "src/test/test.birch"
  auto _u0948 = birch::wasserstein(z1, z2, handler_);
  #line 23 "src/test/test.birch"
  libbirch_line_(23);
  #line 23 "src/test/test.birch"
  if (!(_u0948 <= _u0949)) {
    #line 24 "src/test/test.birch"
    libbirch_line_(24);
    #line 24 "src/test/test.birch"
    birch::stderr()->print(birch::type::String("failed, ") + _u0948 + birch::type::String(" > ") + _u0949 + birch::type::String("\n"), handler_);
    #line 25 "src/test/test.birch"
    libbirch_line_(25);
    #line 25 "src/test/test.birch"
    return false;
  }
  #line 27 "src/test/test.birch"
  libbirch_line_(27);
  #line 27 "src/test/test.birch"
  return true;
}

#line 38 "src/test/test.birch"
birch::type::Boolean birch::pass(const libbirch::DefaultArray<birch::type::Real,2>& X1, const libbirch::DefaultArray<birch::type::Real,2>& X2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "src/test/test.birch"
  libbirch_function_("pass", "src/test/test.birch", 38);
  #line 39 "src/test/test.birch"
  libbirch_line_(39);
  #line 39 "src/test/test.birch"
  libbirch_assert_(birch::rows(X1, handler_) == birch::rows(X2, handler_));
  #line 40 "src/test/test.birch"
  libbirch_line_(40);
  #line 40 "src/test/test.birch"
  libbirch_assert_(birch::columns(X1, handler_) == birch::columns(X2, handler_));
  #line 42 "src/test/test.birch"
  libbirch_line_(42);
  #line 42 "src/test/test.birch"
  auto R = birch::rows(X1, handler_);
  #line 43 "src/test/test.birch"
  libbirch_line_(43);
  #line 43 "src/test/test.birch"
  auto C = birch::columns(X1, handler_);
  #line 44 "src/test/test.birch"
  libbirch_line_(44);
  #line 44 "src/test/test.birch"
  auto failed = birch::type::Integer(0);
  #line 45 "src/test/test.birch"
  libbirch_line_(45);
  #line 45 "src/test/test.birch"
  auto tests = birch::type::Integer(0);
  #line 46 "src/test/test.birch"
  libbirch_line_(46);
  #line 46 "src/test/test.birch"
  auto _u0949 = 4.0 * birch::columns(X1, handler_) / birch::sqrt(birch::Real(R, handler_), handler_);
  #line 49 "src/test/test.birch"
  libbirch_line_(49);
  #line 49 "src/test/test.birch"
  for (auto c = birch::type::Integer(1); c <= C; ++c) {
    #line 51 "src/test/test.birch"
    libbirch_line_(51);
    #line 51 "src/test/test.birch"
    auto x1 = X1.get(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, R - 1), c - 1));
    #line 52 "src/test/test.birch"
    libbirch_line_(52);
    #line 52 "src/test/test.birch"
    auto x2 = X2.get(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, R - 1), c - 1));
    #line 55 "src/test/test.birch"
    libbirch_line_(55);
    #line 55 "src/test/test.birch"
    auto mn = birch::min(birch::min(x1, handler_), birch::min(x2, handler_), handler_);
    #line 56 "src/test/test.birch"
    libbirch_line_(56);
    #line 56 "src/test/test.birch"
    auto mx = birch::max(birch::max(x1, handler_), birch::max(x2, handler_), handler_);
    #line 57 "src/test/test.birch"
    libbirch_line_(57);
    #line 57 "src/test/test.birch"
    auto z1 = (x1 - birch::vector(mn, R, handler_)) / (mx - mn);
    #line 58 "src/test/test.birch"
    libbirch_line_(58);
    #line 58 "src/test/test.birch"
    auto z2 = (x2 - birch::vector(mn, R, handler_)) / (mx - mn);
    #line 61 "src/test/test.birch"
    libbirch_line_(61);
    #line 61 "src/test/test.birch"
    auto _u0948 = birch::wasserstein(z1, z2, handler_);
    #line 62 "src/test/test.birch"
    libbirch_line_(62);
    #line 62 "src/test/test.birch"
    if (!(_u0948 <= _u0949)) {
      #line 63 "src/test/test.birch"
      libbirch_line_(63);
      #line 63 "src/test/test.birch"
      failed = failed + birch::type::Integer(1);
      #line 64 "src/test/test.birch"
      libbirch_line_(64);
      #line 64 "src/test/test.birch"
      birch::stderr()->print(birch::type::String("failed on component ") + c + birch::type::String(", ") + _u0948 + birch::type::String(" > ") + _u0949 + birch::type::String("\n"), handler_);
    }
    #line 66 "src/test/test.birch"
    libbirch_line_(66);
    #line 66 "src/test/test.birch"
    tests = tests + birch::type::Integer(1);
  }
  #line 72 "src/test/test.birch"
  libbirch_line_(72);
  #line 72 "src/test/test.birch"
  for (auto c = birch::type::Integer(1); c <= C; ++c) {
    #line 74 "src/test/test.birch"
    libbirch_line_(74);
    #line 74 "src/test/test.birch"
    auto u = birch::simulate_uniform_unit_vector(C, handler_);
    #line 75 "src/test/test.birch"
    libbirch_line_(75);
    #line 75 "src/test/test.birch"
    auto x1 = X1 * u;
    #line 76 "src/test/test.birch"
    libbirch_line_(76);
    #line 76 "src/test/test.birch"
    auto x2 = X2 * u;
    #line 79 "src/test/test.birch"
    libbirch_line_(79);
    #line 79 "src/test/test.birch"
    auto mn = birch::min(birch::min(x1, handler_), birch::min(x2, handler_), handler_);
    #line 80 "src/test/test.birch"
    libbirch_line_(80);
    #line 80 "src/test/test.birch"
    auto mx = birch::max(birch::max(x1, handler_), birch::max(x2, handler_), handler_);
    #line 81 "src/test/test.birch"
    libbirch_line_(81);
    #line 81 "src/test/test.birch"
    auto z1 = (x1 - birch::vector(mn, R, handler_)) / (mx - mn);
    #line 82 "src/test/test.birch"
    libbirch_line_(82);
    #line 82 "src/test/test.birch"
    auto z2 = (x2 - birch::vector(mn, R, handler_)) / (mx - mn);
    #line 85 "src/test/test.birch"
    libbirch_line_(85);
    #line 85 "src/test/test.birch"
    auto _u0948 = birch::wasserstein(z1, z2, handler_);
    #line 86 "src/test/test.birch"
    libbirch_line_(86);
    #line 86 "src/test/test.birch"
    if (!(_u0948 <= _u0949)) {
      #line 87 "src/test/test.birch"
      libbirch_line_(87);
      #line 87 "src/test/test.birch"
      failed = failed + birch::type::Integer(1);
      #line 88 "src/test/test.birch"
      libbirch_line_(88);
      #line 88 "src/test/test.birch"
      birch::stderr()->print(birch::type::String("failed on random projection, ") + _u0948 + birch::type::String(" > ") + _u0949 + birch::type::String("\n"), handler_);
    }
    #line 90 "src/test/test.birch"
    libbirch_line_(90);
    #line 90 "src/test/test.birch"
    tests = tests + birch::type::Integer(1);
  }
  #line 92 "src/test/test.birch"
  libbirch_line_(92);
  #line 92 "src/test/test.birch"
  if (failed > birch::type::Integer(0)) {
    #line 93 "src/test/test.birch"
    libbirch_line_(93);
    #line 93 "src/test/test.birch"
    birch::stderr()->print(birch::type::String("failed ") + failed + birch::type::String(" of ") + tests + birch::type::String(" comparisons\n"), handler_);
  }
  #line 95 "src/test/test.birch"
  libbirch_line_(95);
  #line 95 "src/test/test.birch"
  return failed == birch::type::Integer(0);
}

#line 7 "src/test/test_cdf.birch"
void birch::test_cdf(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& q, const birch::type::Integer& N, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/test/test_cdf.birch"
  libbirch_function_("test_cdf", "src/test/test_cdf.birch", 7);
  #line 8 "src/test/test_cdf.birch"
  libbirch_line_(8);
  #line 8 "src/test/test_cdf.birch"
  auto failed = false;
  #line 11 "src/test/test_cdf.birch"
  libbirch_line_(11);
  #line 11 "src/test/test_cdf.birch"
  auto from = q->lower(handler_);
  #line 12 "src/test/test_cdf.birch"
  libbirch_line_(12);
  #line 12 "src/test/test_cdf.birch"
  if (from.query()) {
    #line 14 "src/test/test_cdf.birch"
    libbirch_line_(14);
    #line 14 "src/test/test_cdf.birch"
    auto test = q->quantile(0.0, handler_);
    #line 15 "src/test/test_cdf.birch"
    libbirch_line_(15);
    #line 15 "src/test/test_cdf.birch"
    if (test.query() && birch::abs(from.get() - test.get(), handler_) > 1.0 / N) {
      #line 16 "src/test/test_cdf.birch"
      libbirch_line_(16);
      #line 16 "src/test/test_cdf.birch"
      failed = true;
      #line 17 "src/test/test_cdf.birch"
      libbirch_line_(17);
      #line 17 "src/test/test_cdf.birch"
      birch::stderr()->print(birch::type::String("lower bound and quantile comparison failed\n"), handler_);
    }
  } else {
    #line 20 "src/test/test_cdf.birch"
    libbirch_line_(20);
    #line 20 "src/test/test_cdf.birch"
    from = q->quantile(1.0 / N, handler_);
    #line 21 "src/test/test_cdf.birch"
    libbirch_line_(21);
    #line 21 "src/test/test_cdf.birch"
    libbirch_assert_(from.query());
  }
  #line 25 "src/test/test_cdf.birch"
  libbirch_line_(25);
  #line 25 "src/test/test_cdf.birch"
  auto to = q->upper(handler_);
  #line 26 "src/test/test_cdf.birch"
  libbirch_line_(26);
  #line 26 "src/test/test_cdf.birch"
  if (to.query()) {
    #line 28 "src/test/test_cdf.birch"
    libbirch_line_(28);
    #line 28 "src/test/test_cdf.birch"
    auto test = q->quantile(1.0, handler_);
    #line 29 "src/test/test_cdf.birch"
    libbirch_line_(29);
    #line 29 "src/test/test_cdf.birch"
    if (test.query() && birch::abs(to.get() - test.get(), handler_) > 1.0 / N) {
      #line 30 "src/test/test_cdf.birch"
      libbirch_line_(30);
      #line 30 "src/test/test_cdf.birch"
      failed = true;
      #line 31 "src/test/test_cdf.birch"
      libbirch_line_(31);
      #line 31 "src/test/test_cdf.birch"
      birch::stderr()->print(birch::type::String("upper bound and quantile comparison failed\n"), handler_);
    }
  } else {
    #line 34 "src/test/test_cdf.birch"
    libbirch_line_(34);
    #line 34 "src/test/test_cdf.birch"
    to = q->quantile(1.0 - 1.0 / N, handler_);
    #line 35 "src/test/test_cdf.birch"
    libbirch_line_(35);
    #line 35 "src/test/test_cdf.birch"
    if (!to.query()) {
      #line 37 "src/test/test_cdf.birch"
      libbirch_line_(37);
      #line 37 "src/test/test_cdf.birch"
      auto u = 1.0;
      #line 38 "src/test/test_cdf.birch"
      libbirch_line_(38);
      #line 38 "src/test/test_cdf.birch"
      while (q->pdf(u, handler_) > 1.0 / N) {
        #line 39 "src/test/test_cdf.birch"
        libbirch_line_(39);
        #line 39 "src/test/test_cdf.birch"
        u = 2.0 * u;
      }
      #line 41 "src/test/test_cdf.birch"
      libbirch_line_(41);
      #line 41 "src/test/test_cdf.birch"
      to = u;
    }
    #line 43 "src/test/test_cdf.birch"
    libbirch_line_(43);
    #line 43 "src/test/test_cdf.birch"
    libbirch_assert_(to.query());
  }
  #line 47 "src/test/test_cdf.birch"
  libbirch_line_(47);
  #line 47 "src/test/test_cdf.birch"
  auto P = 0.5 / N;
  #line 48 "src/test/test_cdf.birch"
  libbirch_line_(48);
  #line 48 "src/test/test_cdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 49 "src/test/test_cdf.birch"
    libbirch_line_(49);
    #line 49 "src/test/test_cdf.birch"
    auto x = from.get() + (n - 0.5) * (to.get() - from.get()) / N;
    #line 50 "src/test/test_cdf.birch"
    libbirch_line_(50);
    #line 50 "src/test/test_cdf.birch"
    auto C = q->cdf(x, handler_).get();
    #line 51 "src/test/test_cdf.birch"
    libbirch_line_(51);
    #line 51 "src/test/test_cdf.birch"
    P = P + q->pdf(x, handler_) * (to.get() - from.get()) / N;
    #line 53 "src/test/test_cdf.birch"
    libbirch_line_(53);
    #line 53 "src/test/test_cdf.birch"
    auto _u0948 = birch::abs(C - P, handler_);
    #line 54 "src/test/test_cdf.birch"
    libbirch_line_(54);
    #line 54 "src/test/test_cdf.birch"
    auto _u0949 = 10.0 / birch::sqrt(birch::Real(N, handler_), handler_);
    #line 55 "src/test/test_cdf.birch"
    libbirch_line_(55);
    #line 55 "src/test/test_cdf.birch"
    if (_u0948 > _u0949) {
      #line 56 "src/test/test_cdf.birch"
      libbirch_line_(56);
      #line 56 "src/test/test_cdf.birch"
      failed = true;
      #line 57 "src/test/test_cdf.birch"
      libbirch_line_(57);
      #line 57 "src/test/test_cdf.birch"
      birch::stderr()->print(birch::type::String("failed on step ") + n + birch::type::String(", ") + _u0948 + birch::type::String(" > ") + _u0949 + birch::type::String("\n"), handler_);
    }
    #line 59 "src/test/test_cdf.birch"
    libbirch_line_(59);
    #line 59 "src/test/test_cdf.birch"
    if (failed) {
      #line 60 "src/test/test_cdf.birch"
      libbirch_line_(60);
      #line 60 "src/test/test_cdf.birch"
      birch::exit(birch::type::Integer(1), handler_);
    }
    #line 62 "src/test/test_cdf.birch"
    libbirch_line_(62);
    #line 62 "src/test/test_cdf.birch"
    if (birch::mod(n, birch::type::Integer(10000), handler_) == birch::type::Integer(0)) {
      #line 63 "src/test/test_cdf.birch"
      libbirch_line_(63);
      #line 63 "src/test/test_cdf.birch"
      birch::collect(handler_);
    }
  }
}

#line 73 "src/test/test_cdf.birch"
void birch::test_cdf(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>>& q, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 73 "src/test/test_cdf.birch"
  libbirch_function_("test_cdf", "src/test/test_cdf.birch", 73);
  #line 74 "src/test/test_cdf.birch"
  libbirch_line_(74);
  #line 74 "src/test/test_cdf.birch"
  auto failed = false;
  #line 77 "src/test/test_cdf.birch"
  libbirch_line_(77);
  #line 77 "src/test/test_cdf.birch"
  auto from = q->lower(handler_);
  #line 78 "src/test/test_cdf.birch"
  libbirch_line_(78);
  #line 78 "src/test/test_cdf.birch"
  if (from.query()) {
    #line 80 "src/test/test_cdf.birch"
    libbirch_line_(80);
    #line 80 "src/test/test_cdf.birch"
    auto test = q->quantile(0.0, handler_);
    #line 81 "src/test/test_cdf.birch"
    libbirch_line_(81);
    #line 81 "src/test/test_cdf.birch"
    if (test.query() && birch::abs(from.get() - test.get(), handler_) > 1.0e-6) {
      #line 82 "src/test/test_cdf.birch"
      libbirch_line_(82);
      #line 82 "src/test/test_cdf.birch"
      failed = true;
      #line 83 "src/test/test_cdf.birch"
      libbirch_line_(83);
      #line 83 "src/test/test_cdf.birch"
      birch::stderr()->print(birch::type::String("lower bound and quantile comparison failed\n"), handler_);
    }
  } else {
    #line 86 "src/test/test_cdf.birch"
    libbirch_line_(86);
    #line 86 "src/test/test_cdf.birch"
    from = q->quantile(1.0e-6, handler_);
    #line 87 "src/test/test_cdf.birch"
    libbirch_line_(87);
    #line 87 "src/test/test_cdf.birch"
    libbirch_assert_(from.query());
  }
  #line 91 "src/test/test_cdf.birch"
  libbirch_line_(91);
  #line 91 "src/test/test_cdf.birch"
  auto to = q->upper(handler_);
  #line 92 "src/test/test_cdf.birch"
  libbirch_line_(92);
  #line 92 "src/test/test_cdf.birch"
  if (to.query()) {
    #line 94 "src/test/test_cdf.birch"
    libbirch_line_(94);
    #line 94 "src/test/test_cdf.birch"
    auto test = q->quantile(1.0, handler_);
    #line 95 "src/test/test_cdf.birch"
    libbirch_line_(95);
    #line 95 "src/test/test_cdf.birch"
    if (test.query() && birch::abs(to.get() - test.get(), handler_) > 1.0e-6) {
      #line 96 "src/test/test_cdf.birch"
      libbirch_line_(96);
      #line 96 "src/test/test_cdf.birch"
      failed = true;
      #line 97 "src/test/test_cdf.birch"
      libbirch_line_(97);
      #line 97 "src/test/test_cdf.birch"
      birch::stderr()->print(birch::type::String("upper bound and quantile comparison failed\n"), handler_);
    }
  } else {
    #line 100 "src/test/test_cdf.birch"
    libbirch_line_(100);
    #line 100 "src/test/test_cdf.birch"
    to = q->quantile(1.0 - 1.0e-6, handler_);
    #line 101 "src/test/test_cdf.birch"
    libbirch_line_(101);
    #line 101 "src/test/test_cdf.birch"
    libbirch_assert_(to.query());
  }
  #line 105 "src/test/test_cdf.birch"
  libbirch_line_(105);
  #line 105 "src/test/test_cdf.birch"
  auto P = 0.0;
  #line 106 "src/test/test_cdf.birch"
  libbirch_line_(106);
  #line 106 "src/test/test_cdf.birch"
  for (auto x = from.get(); x <= to.get(); ++x) {
    #line 107 "src/test/test_cdf.birch"
    libbirch_line_(107);
    #line 107 "src/test/test_cdf.birch"
    auto C = q->cdf(x, handler_).get();
    #line 108 "src/test/test_cdf.birch"
    libbirch_line_(108);
    #line 108 "src/test/test_cdf.birch"
    P = P + q->pdf(x, handler_);
    #line 110 "src/test/test_cdf.birch"
    libbirch_line_(110);
    #line 110 "src/test/test_cdf.birch"
    auto _u0948 = birch::abs(C - P, handler_);
    #line 111 "src/test/test_cdf.birch"
    libbirch_line_(111);
    #line 111 "src/test/test_cdf.birch"
    auto _u0949 = 10.0 / birch::sqrt(x - from.get() + 1.0, handler_);
    #line 112 "src/test/test_cdf.birch"
    libbirch_line_(112);
    #line 112 "src/test/test_cdf.birch"
    if (_u0948 > _u0949) {
      #line 113 "src/test/test_cdf.birch"
      libbirch_line_(113);
      #line 113 "src/test/test_cdf.birch"
      failed = true;
      #line 114 "src/test/test_cdf.birch"
      libbirch_line_(114);
      #line 114 "src/test/test_cdf.birch"
      birch::stderr()->print(birch::type::String("failed on value ") + x + birch::type::String(", ") + _u0948 + birch::type::String(" > ") + _u0949 + birch::type::String("\n"), handler_);
    }
    #line 116 "src/test/test_cdf.birch"
    libbirch_line_(116);
    #line 116 "src/test/test_cdf.birch"
    if (failed) {
      #line 117 "src/test/test_cdf.birch"
      libbirch_line_(117);
      #line 117 "src/test/test_cdf.birch"
      birch::exit(birch::type::Integer(1), handler_);
    }
  }
}

#line 7 "src/test/test_grad.birch"
void birch::test_grad(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& _u0960, const birch::type::Integer& N, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/test/test_grad.birch"
  libbirch_function_("test_grad", "src/test/test_grad.birch", 7);
  #line 8 "src/test/test_grad.birch"
  libbirch_line_(8);
  #line 8 "src/test/test_grad.birch"
  libbirch_assert_(_u0960->supportsLazy(handler_));
  #line 9 "src/test/test_grad.birch"
  libbirch_line_(9);
  #line 9 "src/test/test_grad.birch"
  auto failed = birch::type::Integer(0);
  #line 10 "src/test/test_grad.birch"
  libbirch_line_(10);
  #line 10 "src/test/test_grad.birch"
  auto _u0916 = 1.0e-6;
  #line 11 "src/test/test_grad.birch"
  libbirch_line_(11);
  #line 11 "src/test/test_grad.birch"
  auto _u0949 = 1.0e-3;
  #line 13 "src/test/test_grad.birch"
  libbirch_line_(13);
  #line 13 "src/test/test_grad.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 15 "src/test/test_grad.birch"
    libbirch_line_(15);
    #line 15 "src/test/test_grad.birch"
    libbirch::Lazy<libbirch::Shared<birch::type::Random<birch::type::Real>>> x;
    #line 16 "src/test/test_grad.birch"
    libbirch_line_(16);
    #line 16 "src/test/test_grad.birch"
    x->setPilot(birch::type::Integer(1), _u0960->simulate(handler_), handler_);
    #line 19 "src/test/test_grad.birch"
    libbirch_line_(19);
    #line 19 "src/test/test_grad.birch"
    auto p = _u0960->logpdfLazy(x, handler_).get();
    #line 20 "src/test/test_grad.birch"
    libbirch_line_(20);
    #line 20 "src/test/test_grad.birch"
    p->pilot(birch::type::Integer(1), handler_);
    #line 21 "src/test/test_grad.birch"
    libbirch_line_(21);
    #line 21 "src/test/test_grad.birch"
    p->grad(birch::type::Integer(1), 1.0, handler_);
    #line 22 "src/test/test_grad.birch"
    libbirch_line_(22);
    #line 22 "src/test/test_grad.birch"
    auto d = x->getGradient(handler_);
    #line 25 "src/test/test_grad.birch"
    libbirch_line_(25);
    #line 25 "src/test/test_grad.birch"
    auto y = birch::box(x->get(handler_) + _u0916, handler_);
    #line 26 "src/test/test_grad.birch"
    libbirch_line_(26);
    #line 26 "src/test/test_grad.birch"
    auto q = _u0960->logpdfLazy(y, handler_).get();
    #line 27 "src/test/test_grad.birch"
    libbirch_line_(27);
    #line 27 "src/test/test_grad.birch"
    q->pilot(birch::type::Integer(1), handler_);
    #line 28 "src/test/test_grad.birch"
    libbirch_line_(28);
    #line 28 "src/test/test_grad.birch"
    auto fd = (q->get(handler_) - p->get(handler_)) / _u0916;
    #line 31 "src/test/test_grad.birch"
    libbirch_line_(31);
    #line 31 "src/test/test_grad.birch"
    auto _u0948 = birch::abs(d - fd, handler_);
    #line 32 "src/test/test_grad.birch"
    libbirch_line_(32);
    #line 32 "src/test/test_grad.birch"
    if (!(_u0948 <= _u0949)) {
      #line 33 "src/test/test_grad.birch"
      libbirch_line_(33);
      #line 33 "src/test/test_grad.birch"
      birch::stderr()->print(birch::type::String("failed at ") + x->value(handler_) + birch::type::String(", d=") + p->get(handler_) + birch::type::String(", fd=") + q->get(handler_) + birch::type::String(", ") + _u0948 + birch::type::String(" > ") + _u0949 + birch::type::String("\n"), handler_);
      #line 34 "src/test/test_grad.birch"
      libbirch_line_(34);
      #line 34 "src/test/test_grad.birch"
      failed = failed + birch::type::Integer(1);
    }
  }
  #line 37 "src/test/test_grad.birch"
  libbirch_line_(37);
  #line 37 "src/test/test_grad.birch"
  if (failed > birch::type::Integer(0)) {
    #line 38 "src/test/test_grad.birch"
    libbirch_line_(38);
    #line 38 "src/test/test_grad.birch"
    birch::exit(birch::type::Integer(1), handler_);
  }
}

#line 8 "src/test/test_pdf.birch"
void birch::test_pdf(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Boolean>>>& _u0960, const birch::type::Integer& N, const birch::type::Boolean& lazy, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 8 "src/test/test_pdf.birch"
  libbirch_function_("test_pdf", "src/test/test_pdf.birch", 8);
  #line 10 "src/test/test_pdf.birch"
  libbirch_line_(10);
  #line 10 "src/test/test_pdf.birch"
  auto k = birch::type::Integer(0);
  #line 11 "src/test/test_pdf.birch"
  libbirch_line_(11);
  #line 11 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 12 "src/test/test_pdf.birch"
    libbirch_line_(12);
    #line 12 "src/test/test_pdf.birch"
    if (_u0960->simulate(handler_)) {
      #line 13 "src/test/test_pdf.birch"
      libbirch_line_(13);
      #line 13 "src/test/test_pdf.birch"
      k = k + birch::type::Integer(1);
    }
    #line 15 "src/test/test_pdf.birch"
    libbirch_line_(15);
    #line 15 "src/test/test_pdf.birch"
    if (birch::mod(n, birch::type::Integer(10000), handler_) == birch::type::Integer(0)) {
      #line 16 "src/test/test_pdf.birch"
      libbirch_line_(16);
      #line 16 "src/test/test_pdf.birch"
      birch::collect(handler_);
    }
  }
  #line 21 "src/test/test_pdf.birch"
  libbirch_line_(21);
  #line 21 "src/test/test_pdf.birch"
  auto failed = false;
  #line 22 "src/test/test_pdf.birch"
  libbirch_line_(22);
  #line 22 "src/test/test_pdf.birch"
  auto _u0949 = 5.0 / birch::sqrt(birch::Real(N, handler_), handler_);
  #line 24 "src/test/test_pdf.birch"
  libbirch_line_(24);
  #line 24 "src/test/test_pdf.birch"
  birch::type::Real p;
  #line 25 "src/test/test_pdf.birch"
  libbirch_line_(25);
  #line 25 "src/test/test_pdf.birch"
  birch::type::Real q;
  #line 26 "src/test/test_pdf.birch"
  libbirch_line_(26);
  #line 26 "src/test/test_pdf.birch"
  if (lazy && _u0960->supportsLazy(handler_)) {
    #line 27 "src/test/test_pdf.birch"
    libbirch_line_(27);
    #line 27 "src/test/test_pdf.birch"
    p = birch::exp(_u0960->logpdfLazy(birch::box(true, handler_), handler_).get()->value(handler_), handler_);
    #line 28 "src/test/test_pdf.birch"
    libbirch_line_(28);
    #line 28 "src/test/test_pdf.birch"
    q = birch::exp(_u0960->logpdfLazy(birch::box(false, handler_), handler_).get()->value(handler_), handler_);
  } else {
    #line 30 "src/test/test_pdf.birch"
    libbirch_line_(30);
    #line 30 "src/test/test_pdf.birch"
    p = _u0960->pdf(true, handler_);
    #line 31 "src/test/test_pdf.birch"
    libbirch_line_(31);
    #line 31 "src/test/test_pdf.birch"
    q = _u0960->pdf(false, handler_);
  }
  #line 33 "src/test/test_pdf.birch"
  libbirch_line_(33);
  #line 33 "src/test/test_pdf.birch"
  auto _u0948 = birch::abs(p - birch::Real(k, handler_) / N, handler_);
  #line 34 "src/test/test_pdf.birch"
  libbirch_line_(34);
  #line 34 "src/test/test_pdf.birch"
  if (_u0948 > _u0949) {
    #line 35 "src/test/test_pdf.birch"
    libbirch_line_(35);
    #line 35 "src/test/test_pdf.birch"
    failed = true;
    #line 36 "src/test/test_pdf.birch"
    libbirch_line_(36);
    #line 36 "src/test/test_pdf.birch"
    birch::stderr()->print(birch::type::String("failed on true, ") + _u0948 + birch::type::String(" > ") + _u0949 + birch::type::String("\n"), handler_);
  }
  #line 38 "src/test/test_pdf.birch"
  libbirch_line_(38);
  #line 38 "src/test/test_pdf.birch"
  _u0948 = birch::abs(q - birch::Real(N - k, handler_) / N, handler_);
  #line 39 "src/test/test_pdf.birch"
  libbirch_line_(39);
  #line 39 "src/test/test_pdf.birch"
  if (_u0948 > _u0949) {
    #line 40 "src/test/test_pdf.birch"
    libbirch_line_(40);
    #line 40 "src/test/test_pdf.birch"
    failed = true;
    #line 41 "src/test/test_pdf.birch"
    libbirch_line_(41);
    #line 41 "src/test/test_pdf.birch"
    birch::stderr()->print(birch::type::String("failed on false, ") + _u0948 + birch::type::String(" > ") + _u0949 + birch::type::String("\n"), handler_);
  }
  #line 43 "src/test/test_pdf.birch"
  libbirch_line_(43);
  #line 43 "src/test/test_pdf.birch"
  if (failed) {
    #line 44 "src/test/test_pdf.birch"
    libbirch_line_(44);
    #line 44 "src/test/test_pdf.birch"
    birch::exit(birch::type::Integer(1), handler_);
  }
}

#line 55 "src/test/test_pdf.birch"
void birch::test_pdf(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>>& _u0960, const birch::type::Integer& N, const birch::type::Boolean& lazy, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 55 "src/test/test_pdf.birch"
  libbirch_function_("test_pdf", "src/test/test_pdf.birch", 55);
  #line 57 "src/test/test_pdf.birch"
  libbirch_line_(57);
  #line 57 "src/test/test_pdf.birch"
  auto from = _u0960->lower(handler_);
  #line 58 "src/test/test_pdf.birch"
  libbirch_line_(58);
  #line 58 "src/test/test_pdf.birch"
  if (!from.query()) {
    #line 59 "src/test/test_pdf.birch"
    libbirch_line_(59);
    #line 59 "src/test/test_pdf.birch"
    from = _u0960->quantile(1.0e-6, handler_);
    #line 60 "src/test/test_pdf.birch"
    libbirch_line_(60);
    #line 60 "src/test/test_pdf.birch"
    libbirch_assert_(from.query());
  }
  #line 64 "src/test/test_pdf.birch"
  libbirch_line_(64);
  #line 64 "src/test/test_pdf.birch"
  auto to = _u0960->upper(handler_);
  #line 65 "src/test/test_pdf.birch"
  libbirch_line_(65);
  #line 65 "src/test/test_pdf.birch"
  if (!to.query()) {
    #line 66 "src/test/test_pdf.birch"
    libbirch_line_(66);
    #line 66 "src/test/test_pdf.birch"
    to = _u0960->quantile(1.0 - 1.0e-6, handler_);
    #line 67 "src/test/test_pdf.birch"
    libbirch_line_(67);
    #line 67 "src/test/test_pdf.birch"
    if (!to.query()) {
      #line 69 "src/test/test_pdf.birch"
      libbirch_line_(69);
      #line 69 "src/test/test_pdf.birch"
      auto u = birch::type::Integer(50);
      #line 70 "src/test/test_pdf.birch"
      libbirch_line_(70);
      #line 70 "src/test/test_pdf.birch"
      auto p = 0.0;
      #line 71 "src/test/test_pdf.birch"
      libbirch_line_(71);
      #line 71 "src/test/test_pdf.birch"
      do {
        #line 72 "src/test/test_pdf.birch"
        libbirch_line_(72);
        #line 72 "src/test/test_pdf.birch"
        u = birch::type::Integer(2) * u;
        #line 73 "src/test/test_pdf.birch"
        libbirch_line_(73);
        #line 73 "src/test/test_pdf.birch"
        if (lazy) {
          #line 74 "src/test/test_pdf.birch"
          libbirch_line_(74);
          #line 74 "src/test/test_pdf.birch"
          p = birch::exp(_u0960->logpdfLazy(birch::box(u, handler_), handler_).get()->value(handler_), handler_);
        } else {
          #line 76 "src/test/test_pdf.birch"
          libbirch_line_(76);
          #line 76 "src/test/test_pdf.birch"
          p = _u0960->pdf(u, handler_);
        }
      } while (p > 1.0e-6);
      #line 79 "src/test/test_pdf.birch"
      libbirch_line_(79);
      #line 79 "src/test/test_pdf.birch"
      to = u;
    }
  }
  #line 84 "src/test/test_pdf.birch"
  libbirch_line_(84);
  #line 84 "src/test/test_pdf.birch"
  auto count = birch::vector(birch::type::Integer(0), to.get() - from.get() + birch::type::Integer(1), handler_);
  #line 85 "src/test/test_pdf.birch"
  libbirch_line_(85);
  #line 85 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 86 "src/test/test_pdf.birch"
    libbirch_line_(86);
    #line 86 "src/test/test_pdf.birch"
    birch::type::Integer j;
    #line 87 "src/test/test_pdf.birch"
    libbirch_line_(87);
    #line 87 "src/test/test_pdf.birch"
    if (lazy) {
      #line 88 "src/test/test_pdf.birch"
      libbirch_line_(88);
      #line 88 "src/test/test_pdf.birch"
      j = _u0960->simulateLazy(handler_).get();
    } else {
      #line 90 "src/test/test_pdf.birch"
      libbirch_line_(90);
      #line 90 "src/test/test_pdf.birch"
      j = _u0960->simulate(handler_);
    }
    #line 92 "src/test/test_pdf.birch"
    libbirch_line_(92);
    #line 92 "src/test/test_pdf.birch"
    auto i = j - from.get() + birch::type::Integer(1);
    #line 93 "src/test/test_pdf.birch"
    libbirch_line_(93);
    #line 93 "src/test/test_pdf.birch"
    if (birch::type::Integer(1) <= i && i <= birch::length(count, handler_)) {
      #line 94 "src/test/test_pdf.birch"
      libbirch_line_(94);
      #line 94 "src/test/test_pdf.birch"
      count.set(libbirch::make_slice(i - 1), count.get(libbirch::make_slice(i - 1)) + birch::type::Integer(1));
    }
    #line 96 "src/test/test_pdf.birch"
    libbirch_line_(96);
    #line 96 "src/test/test_pdf.birch"
    if (birch::mod(n, birch::type::Integer(10000), handler_) == birch::type::Integer(0)) {
      #line 97 "src/test/test_pdf.birch"
      libbirch_line_(97);
      #line 97 "src/test/test_pdf.birch"
      birch::collect(handler_);
    }
  }
  #line 102 "src/test/test_pdf.birch"
  libbirch_line_(102);
  #line 102 "src/test/test_pdf.birch"
  auto failed = false;
  #line 103 "src/test/test_pdf.birch"
  libbirch_line_(103);
  #line 103 "src/test/test_pdf.birch"
  for (auto x = from.get(); x <= to.get(); ++x) {
    #line 104 "src/test/test_pdf.birch"
    libbirch_line_(104);
    #line 104 "src/test/test_pdf.birch"
    birch::type::Real p;
    #line 105 "src/test/test_pdf.birch"
    libbirch_line_(105);
    #line 105 "src/test/test_pdf.birch"
    if (lazy) {
      #line 106 "src/test/test_pdf.birch"
      libbirch_line_(106);
      #line 106 "src/test/test_pdf.birch"
      p = birch::exp(_u0960->logpdfLazy(birch::box(x, handler_), handler_).get()->value(handler_), handler_);
    } else {
      #line 108 "src/test/test_pdf.birch"
      libbirch_line_(108);
      #line 108 "src/test/test_pdf.birch"
      p = _u0960->pdf(x, handler_);
    }
    #line 110 "src/test/test_pdf.birch"
    libbirch_line_(110);
    #line 110 "src/test/test_pdf.birch"
    auto _u0948 = birch::abs(p - birch::Real(count.get(libbirch::make_slice(x - from.get() + birch::type::Integer(1) - 1)), handler_) / N, handler_);
    #line 111 "src/test/test_pdf.birch"
    libbirch_line_(111);
    #line 111 "src/test/test_pdf.birch"
    auto _u0949 = 5.0 / birch::sqrt(birch::Real(N, handler_), handler_);
    #line 112 "src/test/test_pdf.birch"
    libbirch_line_(112);
    #line 112 "src/test/test_pdf.birch"
    if (_u0948 > _u0949) {
      #line 113 "src/test/test_pdf.birch"
      libbirch_line_(113);
      #line 113 "src/test/test_pdf.birch"
      failed = true;
      #line 114 "src/test/test_pdf.birch"
      libbirch_line_(114);
      #line 114 "src/test/test_pdf.birch"
      birch::stderr()->print(birch::type::String("failed on value ") + x + birch::type::String(", ") + _u0948 + birch::type::String(" > ") + _u0949 + birch::type::String("\n"), handler_);
    }
  }
  #line 117 "src/test/test_pdf.birch"
  libbirch_line_(117);
  #line 117 "src/test/test_pdf.birch"
  if (failed) {
    #line 118 "src/test/test_pdf.birch"
    libbirch_line_(118);
    #line 118 "src/test/test_pdf.birch"
    birch::exit(birch::type::Integer(1), handler_);
  }
}

#line 131 "src/test/test_pdf.birch"
void birch::test_pdf(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& _u0960, const birch::type::Integer& N, const birch::type::Integer& B, const birch::type::Integer& S, const birch::type::Boolean& lazy, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 131 "src/test/test_pdf.birch"
  libbirch_function_("test_pdf", "src/test/test_pdf.birch", 131);
  #line 133 "src/test/test_pdf.birch"
  libbirch_line_(133);
  #line 133 "src/test/test_pdf.birch"
  libbirch::DefaultArray<birch::type::Real,1> x1(libbirch::make_shape(N));
  #line 134 "src/test/test_pdf.birch"
  libbirch_line_(134);
  #line 134 "src/test/test_pdf.birch"
  libbirch::DefaultArray<birch::type::Real,1> x2(libbirch::make_shape(N));
  #line 137 "src/test/test_pdf.birch"
  libbirch_line_(137);
  #line 137 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 138 "src/test/test_pdf.birch"
    libbirch_line_(138);
    #line 138 "src/test/test_pdf.birch"
    x1.set(libbirch::make_slice(n - 1), birch::canonical(_u0960->simulate(handler_), handler_));
    #line 139 "src/test/test_pdf.birch"
    libbirch_line_(139);
    #line 139 "src/test/test_pdf.birch"
    if (birch::mod(n, birch::type::Integer(10000), handler_) == birch::type::Integer(0)) {
      #line 140 "src/test/test_pdf.birch"
      libbirch_line_(140);
      #line 140 "src/test/test_pdf.birch"
      birch::collect(handler_);
    }
  }
  #line 145 "src/test/test_pdf.birch"
  libbirch_line_(145);
  #line 145 "src/test/test_pdf.birch"
  auto _u0956 = birch::sum(x1, handler_) / N;
  #line 146 "src/test/test_pdf.birch"
  libbirch_line_(146);
  #line 146 "src/test/test_pdf.birch"
  auto _u09632 = birch::dot(x1, handler_) / N - _u0956 * _u0956;
  #line 149 "src/test/test_pdf.birch"
  libbirch_line_(149);
  #line 149 "src/test/test_pdf.birch"
  auto done = false;
  #line 150 "src/test/test_pdf.birch"
  libbirch_line_(150);
  #line 150 "src/test/test_pdf.birch"
  do {
    #line 151 "src/test/test_pdf.birch"
    libbirch_line_(151);
    #line 151 "src/test/test_pdf.birch"
    auto a = 0.0;
    #line 152 "src/test/test_pdf.birch"
    libbirch_line_(152);
    #line 152 "src/test/test_pdf.birch"
    birch::type::Real x;
    #line 153 "src/test/test_pdf.birch"
    libbirch_line_(153);
    #line 153 "src/test/test_pdf.birch"
    if (lazy && _u0960->supportsLazy(handler_)) {
      #line 154 "src/test/test_pdf.birch"
      libbirch_line_(154);
      #line 154 "src/test/test_pdf.birch"
      x = _u0960->simulateLazy(handler_).get();
    } else {
      #line 156 "src/test/test_pdf.birch"
      libbirch_line_(156);
      #line 156 "src/test/test_pdf.birch"
      x = _u0960->simulate(handler_);
    }
    #line 158 "src/test/test_pdf.birch"
    libbirch_line_(158);
    #line 158 "src/test/test_pdf.birch"
    birch::type::Real l;
    #line 159 "src/test/test_pdf.birch"
    libbirch_line_(159);
    #line 159 "src/test/test_pdf.birch"
    if (lazy && _u0960->supportsLazy(handler_)) {
      #line 160 "src/test/test_pdf.birch"
      libbirch_line_(160);
      #line 160 "src/test/test_pdf.birch"
      l = _u0960->logpdfLazy(birch::box(x, handler_), handler_).get()->value(handler_);
    } else {
      #line 162 "src/test/test_pdf.birch"
      libbirch_line_(162);
      #line 162 "src/test/test_pdf.birch"
      l = _u0960->logpdf(x, handler_);
    }
    #line 165 "src/test/test_pdf.birch"
    libbirch_line_(165);
    #line 165 "src/test/test_pdf.birch"
    for (auto n = birch::type::Integer(1); n <= B; ++n) {
      #line 166 "src/test/test_pdf.birch"
      libbirch_line_(166);
      #line 166 "src/test/test_pdf.birch"
      auto x_prime_ = birch::simulate_gaussian(x, _u09632, handler_);
      #line 167 "src/test/test_pdf.birch"
      libbirch_line_(167);
      #line 167 "src/test/test_pdf.birch"
      birch::type::Real l_prime_;
      #line 168 "src/test/test_pdf.birch"
      libbirch_line_(168);
      #line 168 "src/test/test_pdf.birch"
      if (lazy && _u0960->supportsLazy(handler_)) {
        #line 169 "src/test/test_pdf.birch"
        libbirch_line_(169);
        #line 169 "src/test/test_pdf.birch"
        l_prime_ = _u0960->logpdfLazy(birch::box(x_prime_, handler_), handler_).get()->value(handler_);
      } else {
        #line 171 "src/test/test_pdf.birch"
        libbirch_line_(171);
        #line 171 "src/test/test_pdf.birch"
        l_prime_ = _u0960->logpdf(x_prime_, handler_);
      }
      #line 173 "src/test/test_pdf.birch"
      libbirch_line_(173);
      #line 173 "src/test/test_pdf.birch"
      if (birch::log(birch::simulate_uniform(0.0, 1.0, handler_), handler_) <= l_prime_ - l) {
        #line 175 "src/test/test_pdf.birch"
        libbirch_line_(175);
        #line 175 "src/test/test_pdf.birch"
        x = x_prime_;
        #line 176 "src/test/test_pdf.birch"
        libbirch_line_(176);
        #line 176 "src/test/test_pdf.birch"
        l = l_prime_;
        #line 177 "src/test/test_pdf.birch"
        libbirch_line_(177);
        #line 177 "src/test/test_pdf.birch"
        a = a + 1.0 / B;
      }
    }
    #line 181 "src/test/test_pdf.birch"
    libbirch_line_(181);
    #line 181 "src/test/test_pdf.birch"
    if (a < 0.4) {
      #line 182 "src/test/test_pdf.birch"
      libbirch_line_(182);
      #line 182 "src/test/test_pdf.birch"
      _u09632 = 0.5 * _u09632;
    } else {
      #line 183 "src/test/test_pdf.birch"
      libbirch_line_(183);
      #line 183 "src/test/test_pdf.birch"
      if (a > 0.6) {
        #line 184 "src/test/test_pdf.birch"
        libbirch_line_(184);
        #line 184 "src/test/test_pdf.birch"
        _u09632 = 1.5 * _u09632;
      } else {
        #line 186 "src/test/test_pdf.birch"
        libbirch_line_(186);
        #line 186 "src/test/test_pdf.birch"
        done = true;
      }
    }
  } while (!done);
  #line 191 "src/test/test_pdf.birch"
  libbirch_line_(191);
  #line 191 "src/test/test_pdf.birch"
  auto a = 0.0;
  #line 192 "src/test/test_pdf.birch"
  libbirch_line_(192);
  #line 192 "src/test/test_pdf.birch"
  birch::type::Real x;
  #line 193 "src/test/test_pdf.birch"
  libbirch_line_(193);
  #line 193 "src/test/test_pdf.birch"
  if (lazy && _u0960->supportsLazy(handler_)) {
    #line 194 "src/test/test_pdf.birch"
    libbirch_line_(194);
    #line 194 "src/test/test_pdf.birch"
    x = _u0960->simulateLazy(handler_).get();
  } else {
    #line 196 "src/test/test_pdf.birch"
    libbirch_line_(196);
    #line 196 "src/test/test_pdf.birch"
    x = _u0960->simulate(handler_);
  }
  #line 198 "src/test/test_pdf.birch"
  libbirch_line_(198);
  #line 198 "src/test/test_pdf.birch"
  birch::type::Real l;
  #line 199 "src/test/test_pdf.birch"
  libbirch_line_(199);
  #line 199 "src/test/test_pdf.birch"
  if (lazy && _u0960->supportsLazy(handler_)) {
    #line 200 "src/test/test_pdf.birch"
    libbirch_line_(200);
    #line 200 "src/test/test_pdf.birch"
    l = _u0960->logpdfLazy(birch::box(x, handler_), handler_).get()->value(handler_);
  } else {
    #line 202 "src/test/test_pdf.birch"
    libbirch_line_(202);
    #line 202 "src/test/test_pdf.birch"
    l = _u0960->logpdf(x, handler_);
  }
  #line 204 "src/test/test_pdf.birch"
  libbirch_line_(204);
  #line 204 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 205 "src/test/test_pdf.birch"
    libbirch_line_(205);
    #line 205 "src/test/test_pdf.birch"
    for (auto s = birch::type::Integer(1); s <= S; ++s) {
      #line 206 "src/test/test_pdf.birch"
      libbirch_line_(206);
      #line 206 "src/test/test_pdf.birch"
      auto x_prime_ = birch::simulate_gaussian(x, _u09632, handler_);
      #line 207 "src/test/test_pdf.birch"
      libbirch_line_(207);
      #line 207 "src/test/test_pdf.birch"
      birch::type::Real l_prime_;
      #line 208 "src/test/test_pdf.birch"
      libbirch_line_(208);
      #line 208 "src/test/test_pdf.birch"
      if (lazy && _u0960->supportsLazy(handler_)) {
        #line 209 "src/test/test_pdf.birch"
        libbirch_line_(209);
        #line 209 "src/test/test_pdf.birch"
        l_prime_ = _u0960->logpdfLazy(birch::box(x_prime_, handler_), handler_).get()->value(handler_);
      } else {
        #line 211 "src/test/test_pdf.birch"
        libbirch_line_(211);
        #line 211 "src/test/test_pdf.birch"
        l_prime_ = _u0960->logpdf(x_prime_, handler_);
      }
      #line 213 "src/test/test_pdf.birch"
      libbirch_line_(213);
      #line 213 "src/test/test_pdf.birch"
      if (birch::log(birch::simulate_uniform(0.0, 1.0, handler_), handler_) <= l_prime_ - l) {
        #line 215 "src/test/test_pdf.birch"
        libbirch_line_(215);
        #line 215 "src/test/test_pdf.birch"
        x = x_prime_;
        #line 216 "src/test/test_pdf.birch"
        libbirch_line_(216);
        #line 216 "src/test/test_pdf.birch"
        l = l_prime_;
        #line 217 "src/test/test_pdf.birch"
        libbirch_line_(217);
        #line 217 "src/test/test_pdf.birch"
        a = a + 1.0 / (N * S);
      }
      #line 219 "src/test/test_pdf.birch"
      libbirch_line_(219);
      #line 219 "src/test/test_pdf.birch"
      if (birch::mod((n - birch::type::Integer(1)) * S + s, birch::type::Integer(10000), handler_) == birch::type::Integer(0)) {
        #line 220 "src/test/test_pdf.birch"
        libbirch_line_(220);
        #line 220 "src/test/test_pdf.birch"
        birch::collect(handler_);
      }
    }
    #line 223 "src/test/test_pdf.birch"
    libbirch_line_(223);
    #line 223 "src/test/test_pdf.birch"
    x2.set(libbirch::make_slice(n - 1), x);
  }
  #line 228 "src/test/test_pdf.birch"
  libbirch_line_(228);
  #line 228 "src/test/test_pdf.birch"
  if (!birch::pass(x1, x2, handler_)) {
    #line 229 "src/test/test_pdf.birch"
    libbirch_line_(229);
    #line 229 "src/test/test_pdf.birch"
    birch::exit(birch::type::Integer(1), handler_);
  }
}

#line 243 "src/test/test_pdf.birch"
void birch::test_pdf(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0960, const birch::type::Integer& D, const birch::type::Integer& N, const birch::type::Integer& B, const birch::type::Integer& S, const birch::type::Boolean& lazy, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 243 "src/test/test_pdf.birch"
  libbirch_function_("test_pdf", "src/test/test_pdf.birch", 243);
  #line 245 "src/test/test_pdf.birch"
  libbirch_line_(245);
  #line 245 "src/test/test_pdf.birch"
  libbirch::DefaultArray<birch::type::Real,2> X1(libbirch::make_shape(N, D));
  #line 246 "src/test/test_pdf.birch"
  libbirch_line_(246);
  #line 246 "src/test/test_pdf.birch"
  libbirch::DefaultArray<birch::type::Real,2> X2(libbirch::make_shape(N, D));
  #line 249 "src/test/test_pdf.birch"
  libbirch_line_(249);
  #line 249 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 250 "src/test/test_pdf.birch"
    libbirch_line_(250);
    #line 250 "src/test/test_pdf.birch"
    X1.set(libbirch::make_slice(n - 1, libbirch::make_range(birch::type::Integer(1) - 1, D - 1)), birch::canonical(_u0960->simulate(handler_), handler_));
    #line 251 "src/test/test_pdf.birch"
    libbirch_line_(251);
    #line 251 "src/test/test_pdf.birch"
    if (birch::mod(n, birch::type::Integer(10000), handler_) == birch::type::Integer(0)) {
      #line 252 "src/test/test_pdf.birch"
      libbirch_line_(252);
      #line 252 "src/test/test_pdf.birch"
      birch::collect(handler_);
    }
  }
  #line 257 "src/test/test_pdf.birch"
  libbirch_line_(257);
  #line 257 "src/test/test_pdf.birch"
  auto _u0956 = birch::vector(0.0, D, handler_);
  #line 258 "src/test/test_pdf.birch"
  libbirch_line_(258);
  #line 258 "src/test/test_pdf.birch"
  auto _u0931 = birch::matrix(0.0, D, D, handler_);
  #line 259 "src/test/test_pdf.birch"
  libbirch_line_(259);
  #line 259 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 260 "src/test/test_pdf.birch"
    libbirch_line_(260);
    #line 260 "src/test/test_pdf.birch"
    auto x = X1.get(libbirch::make_slice(n - 1, libbirch::make_range(birch::type::Integer(1) - 1, D - 1)));
    #line 261 "src/test/test_pdf.birch"
    libbirch_line_(261);
    #line 261 "src/test/test_pdf.birch"
    _u0956 = _u0956 + x;
    #line 262 "src/test/test_pdf.birch"
    libbirch_line_(262);
    #line 262 "src/test/test_pdf.birch"
    _u0931 = _u0931 + birch::outer(x, handler_);
  }
  #line 264 "src/test/test_pdf.birch"
  libbirch_line_(264);
  #line 264 "src/test/test_pdf.birch"
  _u0956 = _u0956 / birch::Real(N, handler_);
  #line 265 "src/test/test_pdf.birch"
  libbirch_line_(265);
  #line 265 "src/test/test_pdf.birch"
  _u0931 = _u0931 / birch::Real(N, handler_) - birch::outer(_u0956, handler_);
  #line 268 "src/test/test_pdf.birch"
  libbirch_line_(268);
  #line 268 "src/test/test_pdf.birch"
  auto done = false;
  #line 269 "src/test/test_pdf.birch"
  libbirch_line_(269);
  #line 269 "src/test/test_pdf.birch"
  do {
    #line 270 "src/test/test_pdf.birch"
    libbirch_line_(270);
    #line 270 "src/test/test_pdf.birch"
    auto a = 0.0;
    #line 271 "src/test/test_pdf.birch"
    libbirch_line_(271);
    #line 271 "src/test/test_pdf.birch"
    libbirch::DefaultArray<birch::type::Real,1> x;
    #line 272 "src/test/test_pdf.birch"
    libbirch_line_(272);
    #line 272 "src/test/test_pdf.birch"
    if (lazy && _u0960->supportsLazy(handler_)) {
      #line 273 "src/test/test_pdf.birch"
      libbirch_line_(273);
      #line 273 "src/test/test_pdf.birch"
      x = _u0960->simulateLazy(handler_).get();
    } else {
      #line 275 "src/test/test_pdf.birch"
      libbirch_line_(275);
      #line 275 "src/test/test_pdf.birch"
      x = _u0960->simulate(handler_);
    }
    #line 277 "src/test/test_pdf.birch"
    libbirch_line_(277);
    #line 277 "src/test/test_pdf.birch"
    birch::type::Real l;
    #line 278 "src/test/test_pdf.birch"
    libbirch_line_(278);
    #line 278 "src/test/test_pdf.birch"
    if (lazy && _u0960->supportsLazy(handler_)) {
      #line 279 "src/test/test_pdf.birch"
      libbirch_line_(279);
      #line 279 "src/test/test_pdf.birch"
      l = _u0960->logpdfLazy(birch::box(x, handler_), handler_).get()->value(handler_);
    } else {
      #line 281 "src/test/test_pdf.birch"
      libbirch_line_(281);
      #line 281 "src/test/test_pdf.birch"
      l = _u0960->logpdf(x, handler_);
    }
    #line 284 "src/test/test_pdf.birch"
    libbirch_line_(284);
    #line 284 "src/test/test_pdf.birch"
    for (auto n = birch::type::Integer(1); n <= B; ++n) {
      #line 285 "src/test/test_pdf.birch"
      libbirch_line_(285);
      #line 285 "src/test/test_pdf.birch"
      auto x_prime_ = birch::simulate_multivariate_gaussian(x, birch::llt(_u0931, handler_), handler_);
      #line 286 "src/test/test_pdf.birch"
      libbirch_line_(286);
      #line 286 "src/test/test_pdf.birch"
      birch::type::Real l_prime_;
      #line 287 "src/test/test_pdf.birch"
      libbirch_line_(287);
      #line 287 "src/test/test_pdf.birch"
      if (lazy && _u0960->supportsLazy(handler_)) {
        #line 288 "src/test/test_pdf.birch"
        libbirch_line_(288);
        #line 288 "src/test/test_pdf.birch"
        l_prime_ = _u0960->logpdfLazy(birch::box(x_prime_, handler_), handler_).get()->value(handler_);
      } else {
        #line 290 "src/test/test_pdf.birch"
        libbirch_line_(290);
        #line 290 "src/test/test_pdf.birch"
        l_prime_ = _u0960->logpdf(x_prime_, handler_);
      }
      #line 292 "src/test/test_pdf.birch"
      libbirch_line_(292);
      #line 292 "src/test/test_pdf.birch"
      if (birch::log(birch::simulate_uniform(0.0, 1.0, handler_), handler_) <= l_prime_ - l) {
        #line 294 "src/test/test_pdf.birch"
        libbirch_line_(294);
        #line 294 "src/test/test_pdf.birch"
        x = x_prime_;
        #line 295 "src/test/test_pdf.birch"
        libbirch_line_(295);
        #line 295 "src/test/test_pdf.birch"
        l = l_prime_;
        #line 296 "src/test/test_pdf.birch"
        libbirch_line_(296);
        #line 296 "src/test/test_pdf.birch"
        a = a + 1.0 / B;
      }
    }
    #line 300 "src/test/test_pdf.birch"
    libbirch_line_(300);
    #line 300 "src/test/test_pdf.birch"
    if (a < 0.2) {
      #line 301 "src/test/test_pdf.birch"
      libbirch_line_(301);
      #line 301 "src/test/test_pdf.birch"
      _u0931 = 0.5 * _u0931;
    } else {
      #line 302 "src/test/test_pdf.birch"
      libbirch_line_(302);
      #line 302 "src/test/test_pdf.birch"
      if (a > 0.4) {
        #line 303 "src/test/test_pdf.birch"
        libbirch_line_(303);
        #line 303 "src/test/test_pdf.birch"
        _u0931 = 1.5 * _u0931;
      } else {
        #line 305 "src/test/test_pdf.birch"
        libbirch_line_(305);
        #line 305 "src/test/test_pdf.birch"
        done = true;
      }
    }
  } while (!done);
  #line 310 "src/test/test_pdf.birch"
  libbirch_line_(310);
  #line 310 "src/test/test_pdf.birch"
  auto a = 0.0;
  #line 311 "src/test/test_pdf.birch"
  libbirch_line_(311);
  #line 311 "src/test/test_pdf.birch"
  libbirch::DefaultArray<birch::type::Real,1> x;
  #line 312 "src/test/test_pdf.birch"
  libbirch_line_(312);
  #line 312 "src/test/test_pdf.birch"
  if (lazy && _u0960->supportsLazy(handler_)) {
    #line 313 "src/test/test_pdf.birch"
    libbirch_line_(313);
    #line 313 "src/test/test_pdf.birch"
    x = _u0960->simulateLazy(handler_).get();
  } else {
    #line 315 "src/test/test_pdf.birch"
    libbirch_line_(315);
    #line 315 "src/test/test_pdf.birch"
    x = _u0960->simulate(handler_);
  }
  #line 317 "src/test/test_pdf.birch"
  libbirch_line_(317);
  #line 317 "src/test/test_pdf.birch"
  birch::type::Real l;
  #line 318 "src/test/test_pdf.birch"
  libbirch_line_(318);
  #line 318 "src/test/test_pdf.birch"
  if (lazy && _u0960->supportsLazy(handler_)) {
    #line 319 "src/test/test_pdf.birch"
    libbirch_line_(319);
    #line 319 "src/test/test_pdf.birch"
    l = _u0960->logpdfLazy(birch::box(x, handler_), handler_).get()->value(handler_);
  } else {
    #line 321 "src/test/test_pdf.birch"
    libbirch_line_(321);
    #line 321 "src/test/test_pdf.birch"
    l = _u0960->logpdf(x, handler_);
  }
  #line 323 "src/test/test_pdf.birch"
  libbirch_line_(323);
  #line 323 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 324 "src/test/test_pdf.birch"
    libbirch_line_(324);
    #line 324 "src/test/test_pdf.birch"
    for (auto s = birch::type::Integer(1); s <= S; ++s) {
      #line 325 "src/test/test_pdf.birch"
      libbirch_line_(325);
      #line 325 "src/test/test_pdf.birch"
      auto x_prime_ = birch::simulate_multivariate_gaussian(x, birch::llt(_u0931, handler_), handler_);
      #line 326 "src/test/test_pdf.birch"
      libbirch_line_(326);
      #line 326 "src/test/test_pdf.birch"
      birch::type::Real l_prime_;
      #line 327 "src/test/test_pdf.birch"
      libbirch_line_(327);
      #line 327 "src/test/test_pdf.birch"
      if (lazy && _u0960->supportsLazy(handler_)) {
        #line 328 "src/test/test_pdf.birch"
        libbirch_line_(328);
        #line 328 "src/test/test_pdf.birch"
        l_prime_ = _u0960->logpdfLazy(birch::box(x_prime_, handler_), handler_).get()->value(handler_);
      } else {
        #line 330 "src/test/test_pdf.birch"
        libbirch_line_(330);
        #line 330 "src/test/test_pdf.birch"
        l_prime_ = _u0960->logpdf(x_prime_, handler_);
      }
      #line 332 "src/test/test_pdf.birch"
      libbirch_line_(332);
      #line 332 "src/test/test_pdf.birch"
      if (birch::log(birch::simulate_uniform(0.0, 1.0, handler_), handler_) <= l_prime_ - l) {
        #line 334 "src/test/test_pdf.birch"
        libbirch_line_(334);
        #line 334 "src/test/test_pdf.birch"
        x = x_prime_;
        #line 335 "src/test/test_pdf.birch"
        libbirch_line_(335);
        #line 335 "src/test/test_pdf.birch"
        l = l_prime_;
        #line 336 "src/test/test_pdf.birch"
        libbirch_line_(336);
        #line 336 "src/test/test_pdf.birch"
        a = a + 1.0 / (N * S);
      }
      #line 338 "src/test/test_pdf.birch"
      libbirch_line_(338);
      #line 338 "src/test/test_pdf.birch"
      if (birch::mod((n - birch::type::Integer(1)) * S + s, birch::type::Integer(10000), handler_) == birch::type::Integer(0)) {
        #line 339 "src/test/test_pdf.birch"
        libbirch_line_(339);
        #line 339 "src/test/test_pdf.birch"
        birch::collect(handler_);
      }
    }
    #line 342 "src/test/test_pdf.birch"
    libbirch_line_(342);
    #line 342 "src/test/test_pdf.birch"
    X2.set(libbirch::make_slice(n - 1, libbirch::make_range(birch::type::Integer(1) - 1, D - 1)), x);
  }
  #line 347 "src/test/test_pdf.birch"
  libbirch_line_(347);
  #line 347 "src/test/test_pdf.birch"
  if (!birch::pass(X1, X2, handler_)) {
    #line 348 "src/test/test_pdf.birch"
    libbirch_line_(348);
    #line 348 "src/test/test_pdf.birch"
    birch::exit(birch::type::Integer(1), handler_);
  }
}

#line 363 "src/test/test_pdf.birch"
void birch::test_pdf(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>>& _u0960, const birch::type::Integer& R, const birch::type::Integer& C, const birch::type::Integer& N, const birch::type::Integer& B, const birch::type::Integer& S, const birch::type::Boolean& lazy, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 363 "src/test/test_pdf.birch"
  libbirch_function_("test_pdf", "src/test/test_pdf.birch", 363);
  #line 365 "src/test/test_pdf.birch"
  libbirch_line_(365);
  #line 365 "src/test/test_pdf.birch"
  libbirch::DefaultArray<birch::type::Real,2> X1(libbirch::make_shape(N, R * C));
  #line 366 "src/test/test_pdf.birch"
  libbirch_line_(366);
  #line 366 "src/test/test_pdf.birch"
  libbirch::DefaultArray<birch::type::Real,2> X2(libbirch::make_shape(N, R * C));
  #line 369 "src/test/test_pdf.birch"
  libbirch_line_(369);
  #line 369 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 370 "src/test/test_pdf.birch"
    libbirch_line_(370);
    #line 370 "src/test/test_pdf.birch"
    X1.set(libbirch::make_slice(n - 1, libbirch::make_range(birch::type::Integer(1) - 1, R * C - 1)), birch::vec(_u0960->simulate(handler_), handler_));
    #line 371 "src/test/test_pdf.birch"
    libbirch_line_(371);
    #line 371 "src/test/test_pdf.birch"
    if (birch::mod(n, birch::type::Integer(10000), handler_) == birch::type::Integer(0)) {
      #line 372 "src/test/test_pdf.birch"
      libbirch_line_(372);
      #line 372 "src/test/test_pdf.birch"
      birch::collect(handler_);
    }
  }
  #line 377 "src/test/test_pdf.birch"
  libbirch_line_(377);
  #line 377 "src/test/test_pdf.birch"
  auto _u0956 = birch::vector(0.0, R * C, handler_);
  #line 378 "src/test/test_pdf.birch"
  libbirch_line_(378);
  #line 378 "src/test/test_pdf.birch"
  auto _u0931 = birch::matrix(0.0, R * C, R * C, handler_);
  #line 379 "src/test/test_pdf.birch"
  libbirch_line_(379);
  #line 379 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 380 "src/test/test_pdf.birch"
    libbirch_line_(380);
    #line 380 "src/test/test_pdf.birch"
    auto x = X1.get(libbirch::make_slice(n - 1, libbirch::make_range(birch::type::Integer(1) - 1, R * C - 1)));
    #line 381 "src/test/test_pdf.birch"
    libbirch_line_(381);
    #line 381 "src/test/test_pdf.birch"
    _u0956 = _u0956 + x;
    #line 382 "src/test/test_pdf.birch"
    libbirch_line_(382);
    #line 382 "src/test/test_pdf.birch"
    _u0931 = _u0931 + birch::outer(x, handler_);
  }
  #line 384 "src/test/test_pdf.birch"
  libbirch_line_(384);
  #line 384 "src/test/test_pdf.birch"
  _u0956 = _u0956 / birch::Real(N, handler_);
  #line 385 "src/test/test_pdf.birch"
  libbirch_line_(385);
  #line 385 "src/test/test_pdf.birch"
  _u0931 = _u0931 / birch::Real(N, handler_) - birch::outer(_u0956, handler_);
  #line 388 "src/test/test_pdf.birch"
  libbirch_line_(388);
  #line 388 "src/test/test_pdf.birch"
  auto done = false;
  #line 389 "src/test/test_pdf.birch"
  libbirch_line_(389);
  #line 389 "src/test/test_pdf.birch"
  do {
    #line 390 "src/test/test_pdf.birch"
    libbirch_line_(390);
    #line 390 "src/test/test_pdf.birch"
    auto a = 0.0;
    #line 391 "src/test/test_pdf.birch"
    libbirch_line_(391);
    #line 391 "src/test/test_pdf.birch"
    libbirch::DefaultArray<birch::type::Real,2> x;
    #line 392 "src/test/test_pdf.birch"
    libbirch_line_(392);
    #line 392 "src/test/test_pdf.birch"
    birch::type::Real l;
    #line 393 "src/test/test_pdf.birch"
    libbirch_line_(393);
    #line 393 "src/test/test_pdf.birch"
    if (lazy && _u0960->supportsLazy(handler_)) {
      #line 394 "src/test/test_pdf.birch"
      libbirch_line_(394);
      #line 394 "src/test/test_pdf.birch"
      x = _u0960->simulateLazy(handler_).get();
      #line 395 "src/test/test_pdf.birch"
      libbirch_line_(395);
      #line 395 "src/test/test_pdf.birch"
      l = _u0960->logpdfLazy(birch::box(x, handler_), handler_).get()->value(handler_);
    } else {
      #line 397 "src/test/test_pdf.birch"
      libbirch_line_(397);
      #line 397 "src/test/test_pdf.birch"
      x = _u0960->simulate(handler_);
      #line 398 "src/test/test_pdf.birch"
      libbirch_line_(398);
      #line 398 "src/test/test_pdf.birch"
      l = _u0960->logpdf(x, handler_);
    }
    #line 400 "src/test/test_pdf.birch"
    libbirch_line_(400);
    #line 400 "src/test/test_pdf.birch"
    for (auto n = birch::type::Integer(1); n <= B; ++n) {
      #line 401 "src/test/test_pdf.birch"
      libbirch_line_(401);
      #line 401 "src/test/test_pdf.birch"
      auto x_prime_ = birch::mat(birch::simulate_multivariate_gaussian(birch::vec(x, handler_), birch::llt(_u0931, handler_), handler_), C, handler_);
      #line 402 "src/test/test_pdf.birch"
      libbirch_line_(402);
      #line 402 "src/test/test_pdf.birch"
      birch::type::Real l_prime_;
      #line 403 "src/test/test_pdf.birch"
      libbirch_line_(403);
      #line 403 "src/test/test_pdf.birch"
      if (lazy && _u0960->supportsLazy(handler_)) {
        #line 404 "src/test/test_pdf.birch"
        libbirch_line_(404);
        #line 404 "src/test/test_pdf.birch"
        l_prime_ = _u0960->logpdfLazy(birch::box(x_prime_, handler_), handler_).get()->value(handler_);
      } else {
        #line 406 "src/test/test_pdf.birch"
        libbirch_line_(406);
        #line 406 "src/test/test_pdf.birch"
        l_prime_ = _u0960->logpdf(x_prime_, handler_);
      }
      #line 408 "src/test/test_pdf.birch"
      libbirch_line_(408);
      #line 408 "src/test/test_pdf.birch"
      if (birch::log(birch::simulate_uniform(0.0, 1.0, handler_), handler_) <= l_prime_ - l) {
        #line 410 "src/test/test_pdf.birch"
        libbirch_line_(410);
        #line 410 "src/test/test_pdf.birch"
        x = x_prime_;
        #line 411 "src/test/test_pdf.birch"
        libbirch_line_(411);
        #line 411 "src/test/test_pdf.birch"
        l = l_prime_;
        #line 412 "src/test/test_pdf.birch"
        libbirch_line_(412);
        #line 412 "src/test/test_pdf.birch"
        a = a + 1.0 / B;
      }
    }
    #line 416 "src/test/test_pdf.birch"
    libbirch_line_(416);
    #line 416 "src/test/test_pdf.birch"
    if (a < 0.2) {
      #line 417 "src/test/test_pdf.birch"
      libbirch_line_(417);
      #line 417 "src/test/test_pdf.birch"
      _u0931 = 0.5 * _u0931;
    } else {
      #line 418 "src/test/test_pdf.birch"
      libbirch_line_(418);
      #line 418 "src/test/test_pdf.birch"
      if (a > 0.4) {
        #line 419 "src/test/test_pdf.birch"
        libbirch_line_(419);
        #line 419 "src/test/test_pdf.birch"
        _u0931 = 1.5 * _u0931;
      } else {
        #line 421 "src/test/test_pdf.birch"
        libbirch_line_(421);
        #line 421 "src/test/test_pdf.birch"
        done = true;
      }
    }
  } while (!done);
  #line 426 "src/test/test_pdf.birch"
  libbirch_line_(426);
  #line 426 "src/test/test_pdf.birch"
  auto a = 0.0;
  #line 427 "src/test/test_pdf.birch"
  libbirch_line_(427);
  #line 427 "src/test/test_pdf.birch"
  libbirch::DefaultArray<birch::type::Real,2> x;
  #line 428 "src/test/test_pdf.birch"
  libbirch_line_(428);
  #line 428 "src/test/test_pdf.birch"
  birch::type::Real l;
  #line 429 "src/test/test_pdf.birch"
  libbirch_line_(429);
  #line 429 "src/test/test_pdf.birch"
  if (lazy && _u0960->supportsLazy(handler_)) {
    #line 430 "src/test/test_pdf.birch"
    libbirch_line_(430);
    #line 430 "src/test/test_pdf.birch"
    x = _u0960->simulateLazy(handler_).get();
    #line 431 "src/test/test_pdf.birch"
    libbirch_line_(431);
    #line 431 "src/test/test_pdf.birch"
    l = _u0960->logpdfLazy(birch::box(x, handler_), handler_).get()->value(handler_);
  } else {
    #line 433 "src/test/test_pdf.birch"
    libbirch_line_(433);
    #line 433 "src/test/test_pdf.birch"
    x = _u0960->simulate(handler_);
    #line 434 "src/test/test_pdf.birch"
    libbirch_line_(434);
    #line 434 "src/test/test_pdf.birch"
    l = _u0960->logpdf(x, handler_);
  }
  #line 436 "src/test/test_pdf.birch"
  libbirch_line_(436);
  #line 436 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 437 "src/test/test_pdf.birch"
    libbirch_line_(437);
    #line 437 "src/test/test_pdf.birch"
    for (auto s = birch::type::Integer(1); s <= S; ++s) {
      #line 438 "src/test/test_pdf.birch"
      libbirch_line_(438);
      #line 438 "src/test/test_pdf.birch"
      auto x_prime_ = birch::mat(birch::simulate_multivariate_gaussian(birch::vec(x, handler_), birch::llt(_u0931, handler_), handler_), C, handler_);
      #line 439 "src/test/test_pdf.birch"
      libbirch_line_(439);
      #line 439 "src/test/test_pdf.birch"
      birch::type::Real l_prime_;
      #line 440 "src/test/test_pdf.birch"
      libbirch_line_(440);
      #line 440 "src/test/test_pdf.birch"
      if (lazy && _u0960->supportsLazy(handler_)) {
        #line 441 "src/test/test_pdf.birch"
        libbirch_line_(441);
        #line 441 "src/test/test_pdf.birch"
        l_prime_ = _u0960->logpdfLazy(birch::box(x_prime_, handler_), handler_).get()->value(handler_);
      } else {
        #line 443 "src/test/test_pdf.birch"
        libbirch_line_(443);
        #line 443 "src/test/test_pdf.birch"
        l_prime_ = _u0960->logpdf(x_prime_, handler_);
      }
      #line 445 "src/test/test_pdf.birch"
      libbirch_line_(445);
      #line 445 "src/test/test_pdf.birch"
      if (birch::log(birch::simulate_uniform(0.0, 1.0, handler_), handler_) <= l_prime_ - l) {
        #line 447 "src/test/test_pdf.birch"
        libbirch_line_(447);
        #line 447 "src/test/test_pdf.birch"
        x = x_prime_;
        #line 448 "src/test/test_pdf.birch"
        libbirch_line_(448);
        #line 448 "src/test/test_pdf.birch"
        l = l_prime_;
        #line 449 "src/test/test_pdf.birch"
        libbirch_line_(449);
        #line 449 "src/test/test_pdf.birch"
        a = a + 1.0 / (N * S);
      }
      #line 451 "src/test/test_pdf.birch"
      libbirch_line_(451);
      #line 451 "src/test/test_pdf.birch"
      if (birch::mod((n - birch::type::Integer(1)) * S + s, birch::type::Integer(10000), handler_) == birch::type::Integer(0)) {
        #line 452 "src/test/test_pdf.birch"
        libbirch_line_(452);
        #line 452 "src/test/test_pdf.birch"
        birch::collect(handler_);
      }
    }
    #line 455 "src/test/test_pdf.birch"
    libbirch_line_(455);
    #line 455 "src/test/test_pdf.birch"
    X2.set(libbirch::make_slice(n - 1, libbirch::make_range(birch::type::Integer(1) - 1, R * C - 1)), birch::vec(x, handler_));
  }
  #line 460 "src/test/test_pdf.birch"
  libbirch_line_(460);
  #line 460 "src/test/test_pdf.birch"
  if (!birch::pass(X1, X2, handler_)) {
    #line 461 "src/test/test_pdf.birch"
    libbirch_line_(461);
    #line 461 "src/test/test_pdf.birch"
    birch::exit(birch::type::Integer(1), handler_);
  }
}

