#line 9 "src/test/test.birch"
birch::type::Boolean birch::pass(const libbirch::DefaultArray<birch::type::Real,1>& x1, const libbirch::DefaultArray<birch::type::Real,1>& x2) {
  #line 9 "src/test/test.birch"
  libbirch_function_("pass", "src/test/test.birch", 9);
  #line 10 "src/test/test.birch"
  libbirch_line_(10);
  #line 10 "src/test/test.birch"
  libbirch_assert_(birch::length(x1) == birch::length(x2));
  #line 12 "src/test/test.birch"
  libbirch_line_(12);
  #line 12 "src/test/test.birch"
  auto N = birch::length(x1);
  #line 13 "src/test/test.birch"
  libbirch_line_(13);
  #line 13 "src/test/test.birch"
  auto ε = 4.0 / birch::sqrt(birch::Real(N));
  #line 16 "src/test/test.birch"
  libbirch_line_(16);
  #line 16 "src/test/test.birch"
  auto mn = birch::min(birch::min(x1), birch::min(x2));
  #line 17 "src/test/test.birch"
  libbirch_line_(17);
  #line 17 "src/test/test.birch"
  auto mx = birch::max(birch::max(x1), birch::max(x2));
  #line 18 "src/test/test.birch"
  libbirch_line_(18);
  #line 18 "src/test/test.birch"
  auto z1 = (x1 - birch::vector(mn, N)) / (mx - mn);
  #line 19 "src/test/test.birch"
  libbirch_line_(19);
  #line 19 "src/test/test.birch"
  auto z2 = (x2 - birch::vector(mn, N)) / (mx - mn);
  #line 22 "src/test/test.birch"
  libbirch_line_(22);
  #line 22 "src/test/test.birch"
  auto δ = birch::wasserstein(z1, z2);
  #line 23 "src/test/test.birch"
  libbirch_line_(23);
  #line 23 "src/test/test.birch"
  if (!((δ <= ε))) {
    #line 24 "src/test/test.birch"
    libbirch_line_(24);
    #line 24 "src/test/test.birch"
    birch::stderr()->print(birch::type::String("***failed***, ") + δ + birch::type::String(" > ") + ε + birch::type::String("\n"));
    #line 25 "src/test/test.birch"
    libbirch_line_(25);
    #line 25 "src/test/test.birch"
    return false;
  }
  #line 27 "src/test/test.birch"
  libbirch_line_(27);
  #line 27 "src/test/test.birch"
  return true;
}

#line 38 "src/test/test.birch"
birch::type::Boolean birch::pass(const libbirch::DefaultArray<birch::type::Real,2>& X1, const libbirch::DefaultArray<birch::type::Real,2>& X2) {
  #line 38 "src/test/test.birch"
  libbirch_function_("pass", "src/test/test.birch", 38);
  #line 39 "src/test/test.birch"
  libbirch_line_(39);
  #line 39 "src/test/test.birch"
  libbirch_assert_(birch::rows(X1) == birch::rows(X2));
  #line 40 "src/test/test.birch"
  libbirch_line_(40);
  #line 40 "src/test/test.birch"
  libbirch_assert_(birch::columns(X1) == birch::columns(X2));
  #line 42 "src/test/test.birch"
  libbirch_line_(42);
  #line 42 "src/test/test.birch"
  auto R = birch::rows(X1);
  #line 43 "src/test/test.birch"
  libbirch_line_(43);
  #line 43 "src/test/test.birch"
  auto C = birch::columns(X1);
  #line 44 "src/test/test.birch"
  libbirch_line_(44);
  #line 44 "src/test/test.birch"
  auto failed = birch::type::Integer(0);
  #line 45 "src/test/test.birch"
  libbirch_line_(45);
  #line 45 "src/test/test.birch"
  auto tests = birch::type::Integer(0);
  #line 46 "src/test/test.birch"
  libbirch_line_(46);
  #line 46 "src/test/test.birch"
  auto ε = 2.0 / birch::sqrt(birch::Real(R));
  #line 49 "src/test/test.birch"
  libbirch_line_(49);
  #line 49 "src/test/test.birch"
  for (auto c = birch::type::Integer(1); c <= C; ++c) {
    #line 51 "src/test/test.birch"
    libbirch_line_(51);
    #line 51 "src/test/test.birch"
    auto x1 = X1(libbirch::make_range(birch::type::Integer(1), R), c);
    #line 52 "src/test/test.birch"
    libbirch_line_(52);
    #line 52 "src/test/test.birch"
    auto x2 = X2(libbirch::make_range(birch::type::Integer(1), R), c);
    #line 55 "src/test/test.birch"
    libbirch_line_(55);
    #line 55 "src/test/test.birch"
    auto mn = birch::min(birch::min(x1), birch::min(x2));
    #line 56 "src/test/test.birch"
    libbirch_line_(56);
    #line 56 "src/test/test.birch"
    auto mx = birch::max(birch::max(x1), birch::max(x2));
    #line 57 "src/test/test.birch"
    libbirch_line_(57);
    #line 57 "src/test/test.birch"
    auto z1 = (x1 - birch::vector(mn, R)) / (mx - mn);
    #line 58 "src/test/test.birch"
    libbirch_line_(58);
    #line 58 "src/test/test.birch"
    auto z2 = (x2 - birch::vector(mn, R)) / (mx - mn);
    #line 61 "src/test/test.birch"
    libbirch_line_(61);
    #line 61 "src/test/test.birch"
    auto δ = birch::wasserstein(z1, z2);
    #line 62 "src/test/test.birch"
    libbirch_line_(62);
    #line 62 "src/test/test.birch"
    if (!((δ <= ε))) {
      #line 63 "src/test/test.birch"
      libbirch_line_(63);
      #line 63 "src/test/test.birch"
      failed = failed + birch::type::Integer(1);
      #line 64 "src/test/test.birch"
      libbirch_line_(64);
      #line 64 "src/test/test.birch"
      birch::stderr()->print(birch::type::String("***failed*** on component ") + c + birch::type::String(", ") + δ + birch::type::String(" > ") + ε + birch::type::String("\n"));
    }
    #line 66 "src/test/test.birch"
    libbirch_line_(66);
    #line 66 "src/test/test.birch"
    tests = tests + birch::type::Integer(1);
  }
  #line 72 "src/test/test.birch"
  libbirch_line_(72);
  #line 72 "src/test/test.birch"
  for (auto c = birch::type::Integer(1); c <= C; ++c) {
    #line 74 "src/test/test.birch"
    libbirch_line_(74);
    #line 74 "src/test/test.birch"
    auto u = birch::simulate_uniform_unit_vector(C);
    #line 75 "src/test/test.birch"
    libbirch_line_(75);
    #line 75 "src/test/test.birch"
    auto x1 = X1 * u;
    #line 76 "src/test/test.birch"
    libbirch_line_(76);
    #line 76 "src/test/test.birch"
    auto x2 = X2 * u;
    #line 79 "src/test/test.birch"
    libbirch_line_(79);
    #line 79 "src/test/test.birch"
    auto mn = birch::min(birch::min(x1), birch::min(x2));
    #line 80 "src/test/test.birch"
    libbirch_line_(80);
    #line 80 "src/test/test.birch"
    auto mx = birch::max(birch::max(x1), birch::max(x2));
    #line 81 "src/test/test.birch"
    libbirch_line_(81);
    #line 81 "src/test/test.birch"
    auto z1 = (x1 - birch::vector(mn, R)) / (mx - mn);
    #line 82 "src/test/test.birch"
    libbirch_line_(82);
    #line 82 "src/test/test.birch"
    auto z2 = (x2 - birch::vector(mn, R)) / (mx - mn);
    #line 85 "src/test/test.birch"
    libbirch_line_(85);
    #line 85 "src/test/test.birch"
    auto δ = birch::wasserstein(z1, z2);
    #line 86 "src/test/test.birch"
    libbirch_line_(86);
    #line 86 "src/test/test.birch"
    if (!((δ <= ε))) {
      #line 87 "src/test/test.birch"
      libbirch_line_(87);
      #line 87 "src/test/test.birch"
      failed = failed + birch::type::Integer(1);
      #line 88 "src/test/test.birch"
      libbirch_line_(88);
      #line 88 "src/test/test.birch"
      birch::stderr()->print(birch::type::String("***failed*** on random projection, ") + δ + birch::type::String(" > ") + ε + birch::type::String("\n"));
    }
    #line 90 "src/test/test.birch"
    libbirch_line_(90);
    #line 90 "src/test/test.birch"
    tests = tests + birch::type::Integer(1);
  }
  #line 92 "src/test/test.birch"
  libbirch_line_(92);
  #line 92 "src/test/test.birch"
  if (failed > birch::type::Integer(0)) {
    #line 93 "src/test/test.birch"
    libbirch_line_(93);
    #line 93 "src/test/test.birch"
    birch::stderr()->print(birch::type::String("***failed*** ") + failed + birch::type::String(" of ") + tests + birch::type::String(" comparisons\n"));
  }
  #line 95 "src/test/test.birch"
  libbirch_line_(95);
  #line 95 "src/test/test.birch"
  return failed == birch::type::Integer(0);
}

#line 7 "src/test/test_cdf.birch"
void birch::test_cdf(const libbirch::Shared<birch::type::Distribution<birch::type::Real>>& q, const birch::type::Integer& N) {
  #line 7 "src/test/test_cdf.birch"
  libbirch_function_("test_cdf", "src/test/test_cdf.birch", 7);
  #line 8 "src/test/test_cdf.birch"
  libbirch_line_(8);
  #line 8 "src/test/test_cdf.birch"
  auto failed = false;
  #line 11 "src/test/test_cdf.birch"
  libbirch_line_(11);
  #line 11 "src/test/test_cdf.birch"
  auto from = q->lower();
  #line 12 "src/test/test_cdf.birch"
  libbirch_line_(12);
  #line 12 "src/test/test_cdf.birch"
  if (from.has_value()) {
    #line 14 "src/test/test_cdf.birch"
    libbirch_line_(14);
    #line 14 "src/test/test_cdf.birch"
    auto test = q->quantile(0.0);
    #line 15 "src/test/test_cdf.birch"
    libbirch_line_(15);
    #line 15 "src/test/test_cdf.birch"
    if (test.has_value() && birch::abs(from.value() - test.value()) > 1.0 / N) {
      #line 16 "src/test/test_cdf.birch"
      libbirch_line_(16);
      #line 16 "src/test/test_cdf.birch"
      birch::error(birch::type::String("upper bound and quantile comparison failed, ") + from.value() + birch::type::String(" vs ") + test.value() + birch::type::String("."));
    }
  } else {
    #line 20 "src/test/test_cdf.birch"
    libbirch_line_(20);
    #line 20 "src/test/test_cdf.birch"
    from = q->quantile(1.0 / N);
    #line 21 "src/test/test_cdf.birch"
    libbirch_line_(21);
    #line 21 "src/test/test_cdf.birch"
    libbirch_assert_(from.has_value());
  }
  #line 25 "src/test/test_cdf.birch"
  libbirch_line_(25);
  #line 25 "src/test/test_cdf.birch"
  auto to = q->upper();
  #line 26 "src/test/test_cdf.birch"
  libbirch_line_(26);
  #line 26 "src/test/test_cdf.birch"
  if (to.has_value()) {
    #line 28 "src/test/test_cdf.birch"
    libbirch_line_(28);
    #line 28 "src/test/test_cdf.birch"
    auto test = q->quantile(1.0);
    #line 29 "src/test/test_cdf.birch"
    libbirch_line_(29);
    #line 29 "src/test/test_cdf.birch"
    if (test.has_value() && birch::abs(to.value() - test.value()) > 1.0 / N) {
      #line 30 "src/test/test_cdf.birch"
      libbirch_line_(30);
      #line 30 "src/test/test_cdf.birch"
      birch::error(birch::type::String("upper bound and quantile comparison failed, ") + to.value() + birch::type::String(" vs ") + test.value() + birch::type::String("."));
    }
  } else {
    #line 34 "src/test/test_cdf.birch"
    libbirch_line_(34);
    #line 34 "src/test/test_cdf.birch"
    to = q->quantile(1.0 - 1.0 / N);
    #line 35 "src/test/test_cdf.birch"
    libbirch_line_(35);
    #line 35 "src/test/test_cdf.birch"
    if (!(to.has_value())) {
      #line 37 "src/test/test_cdf.birch"
      libbirch_line_(37);
      #line 37 "src/test/test_cdf.birch"
      auto u = 1.0;
      #line 38 "src/test/test_cdf.birch"
      libbirch_line_(38);
      #line 38 "src/test/test_cdf.birch"
      while (q->pdf(u) > 1.0 / N) {
        #line 39 "src/test/test_cdf.birch"
        libbirch_line_(39);
        #line 39 "src/test/test_cdf.birch"
        u = 2.0 * u;
      }
      #line 41 "src/test/test_cdf.birch"
      libbirch_line_(41);
      #line 41 "src/test/test_cdf.birch"
      to = u;
    }
    #line 43 "src/test/test_cdf.birch"
    libbirch_line_(43);
    #line 43 "src/test/test_cdf.birch"
    libbirch_assert_(to.has_value());
  }
  #line 47 "src/test/test_cdf.birch"
  libbirch_line_(47);
  #line 47 "src/test/test_cdf.birch"
  auto P = 0.5 / N;
  #line 48 "src/test/test_cdf.birch"
  libbirch_line_(48);
  #line 48 "src/test/test_cdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 49 "src/test/test_cdf.birch"
    libbirch_line_(49);
    #line 49 "src/test/test_cdf.birch"
    auto x = from.value() + (n - 0.5) * (to.value() - from.value()) / N;
    #line 50 "src/test/test_cdf.birch"
    libbirch_line_(50);
    #line 50 "src/test/test_cdf.birch"
    auto C = q->cdf(x).value();
    #line 51 "src/test/test_cdf.birch"
    libbirch_line_(51);
    #line 51 "src/test/test_cdf.birch"
    P = P + q->pdf(x) * (to.value() - from.value()) / N;
    #line 53 "src/test/test_cdf.birch"
    libbirch_line_(53);
    #line 53 "src/test/test_cdf.birch"
    auto δ = birch::abs(C - P);
    #line 54 "src/test/test_cdf.birch"
    libbirch_line_(54);
    #line 54 "src/test/test_cdf.birch"
    auto ε = 10.0 / birch::sqrt(birch::Real(N));
    #line 55 "src/test/test_cdf.birch"
    libbirch_line_(55);
    #line 55 "src/test/test_cdf.birch"
    if (!((δ <= ε))) {
      #line 56 "src/test/test_cdf.birch"
      libbirch_line_(56);
      #line 56 "src/test/test_cdf.birch"
      failed = true;
      #line 57 "src/test/test_cdf.birch"
      libbirch_line_(57);
      #line 57 "src/test/test_cdf.birch"
      birch::stderr()->print(birch::type::String("***failed*** on step ") + n + birch::type::String(", ") + δ + birch::type::String(" > ") + ε + birch::type::String("\n"));
    }
    #line 59 "src/test/test_cdf.birch"
    libbirch_line_(59);
    #line 59 "src/test/test_cdf.birch"
    if (failed) {
      #line 60 "src/test/test_cdf.birch"
      libbirch_line_(60);
      #line 60 "src/test/test_cdf.birch"
      birch::exit(birch::type::Integer(1));
    }
    #line 62 "src/test/test_cdf.birch"
    libbirch_line_(62);
    #line 62 "src/test/test_cdf.birch"
    if (birch::mod(n, birch::type::Integer(10000)) == birch::type::Integer(0)) {
      #line 63 "src/test/test_cdf.birch"
      libbirch_line_(63);
      #line 63 "src/test/test_cdf.birch"
      birch::collect();
    }
  }
}

#line 73 "src/test/test_cdf.birch"
void birch::test_cdf(const libbirch::Shared<birch::type::Distribution<birch::type::Integer>>& q) {
  #line 73 "src/test/test_cdf.birch"
  libbirch_function_("test_cdf", "src/test/test_cdf.birch", 73);
  #line 74 "src/test/test_cdf.birch"
  libbirch_line_(74);
  #line 74 "src/test/test_cdf.birch"
  auto failed = false;
  #line 77 "src/test/test_cdf.birch"
  libbirch_line_(77);
  #line 77 "src/test/test_cdf.birch"
  auto from = q->lower();
  #line 78 "src/test/test_cdf.birch"
  libbirch_line_(78);
  #line 78 "src/test/test_cdf.birch"
  if (from.has_value()) {
    #line 80 "src/test/test_cdf.birch"
    libbirch_line_(80);
    #line 80 "src/test/test_cdf.birch"
    auto test = q->quantile(0.0);
    #line 81 "src/test/test_cdf.birch"
    libbirch_line_(81);
    #line 81 "src/test/test_cdf.birch"
    if (test.has_value() && birch::abs(from.value() - test.value()) > 1.0e-6) {
      #line 82 "src/test/test_cdf.birch"
      libbirch_line_(82);
      #line 82 "src/test/test_cdf.birch"
      birch::error(birch::type::String("upper bound and quantile comparison failed, ") + from.value() + birch::type::String(" vs ") + test.value() + birch::type::String("."));
    }
  } else {
    #line 86 "src/test/test_cdf.birch"
    libbirch_line_(86);
    #line 86 "src/test/test_cdf.birch"
    from = q->quantile(1.0e-6);
    #line 87 "src/test/test_cdf.birch"
    libbirch_line_(87);
    #line 87 "src/test/test_cdf.birch"
    libbirch_assert_(from.has_value());
  }
  #line 91 "src/test/test_cdf.birch"
  libbirch_line_(91);
  #line 91 "src/test/test_cdf.birch"
  auto to = q->upper();
  #line 92 "src/test/test_cdf.birch"
  libbirch_line_(92);
  #line 92 "src/test/test_cdf.birch"
  if (to.has_value()) {
    #line 94 "src/test/test_cdf.birch"
    libbirch_line_(94);
    #line 94 "src/test/test_cdf.birch"
    auto test = q->quantile(1.0);
    #line 95 "src/test/test_cdf.birch"
    libbirch_line_(95);
    #line 95 "src/test/test_cdf.birch"
    if (test.has_value() && birch::abs(to.value() - test.value()) > 1.0e-6) {
      #line 96 "src/test/test_cdf.birch"
      libbirch_line_(96);
      #line 96 "src/test/test_cdf.birch"
      birch::error(birch::type::String("upper bound and quantile comparison failed, ") + to.value() + birch::type::String(" vs ") + test.value() + birch::type::String("."));
    }
  } else {
    #line 100 "src/test/test_cdf.birch"
    libbirch_line_(100);
    #line 100 "src/test/test_cdf.birch"
    to = q->quantile(1.0 - 1.0e-6);
    #line 101 "src/test/test_cdf.birch"
    libbirch_line_(101);
    #line 101 "src/test/test_cdf.birch"
    libbirch_assert_(to.has_value());
  }
  #line 105 "src/test/test_cdf.birch"
  libbirch_line_(105);
  #line 105 "src/test/test_cdf.birch"
  auto P = 0.0;
  #line 106 "src/test/test_cdf.birch"
  libbirch_line_(106);
  #line 106 "src/test/test_cdf.birch"
  for (auto x = from.value(); x <= to.value(); ++x) {
    #line 107 "src/test/test_cdf.birch"
    libbirch_line_(107);
    #line 107 "src/test/test_cdf.birch"
    auto C = q->cdf(x).value();
    #line 108 "src/test/test_cdf.birch"
    libbirch_line_(108);
    #line 108 "src/test/test_cdf.birch"
    P = P + q->pdf(x);
    #line 110 "src/test/test_cdf.birch"
    libbirch_line_(110);
    #line 110 "src/test/test_cdf.birch"
    auto δ = birch::abs(C - P);
    #line 111 "src/test/test_cdf.birch"
    libbirch_line_(111);
    #line 111 "src/test/test_cdf.birch"
    auto ε = 2.0e-3;
    #line 112 "src/test/test_cdf.birch"
    libbirch_line_(112);
    #line 112 "src/test/test_cdf.birch"
    if (!((δ <= ε))) {
      #line 113 "src/test/test_cdf.birch"
      libbirch_line_(113);
      #line 113 "src/test/test_cdf.birch"
      failed = true;
      #line 114 "src/test/test_cdf.birch"
      libbirch_line_(114);
      #line 114 "src/test/test_cdf.birch"
      birch::stderr()->print(birch::type::String("***failed*** on value ") + x + birch::type::String(", ") + δ + birch::type::String(" > ") + ε + birch::type::String("\n"));
    }
    #line 116 "src/test/test_cdf.birch"
    libbirch_line_(116);
    #line 116 "src/test/test_cdf.birch"
    if (failed) {
      #line 117 "src/test/test_cdf.birch"
      libbirch_line_(117);
      #line 117 "src/test/test_cdf.birch"
      birch::exit(birch::type::Integer(1));
    }
  }
}

#line 7 "src/test/test_grad.birch"
void birch::test_grad(const libbirch::Shared<birch::type::Distribution<birch::type::Real>>& π, const birch::type::Integer& N) {
  #line 7 "src/test/test_grad.birch"
  libbirch_function_("test_grad", "src/test/test_grad.birch", 7);
  #line 8 "src/test/test_grad.birch"
  libbirch_line_(8);
  #line 8 "src/test/test_grad.birch"
  libbirch_assert_(π->supportsLazy());
  #line 9 "src/test/test_grad.birch"
  libbirch_line_(9);
  #line 9 "src/test/test_grad.birch"
  auto failed = birch::type::Integer(0);
  #line 10 "src/test/test_grad.birch"
  libbirch_line_(10);
  #line 10 "src/test/test_grad.birch"
  auto h = 1.0e-4;
  #line 11 "src/test/test_grad.birch"
  libbirch_line_(11);
  #line 11 "src/test/test_grad.birch"
  auto ε = 1.0e-2;
  #line 13 "src/test/test_grad.birch"
  libbirch_line_(13);
  #line 13 "src/test/test_grad.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 15 "src/test/test_grad.birch"
    libbirch_line_(15);
    #line 15 "src/test/test_grad.birch"
    libbirch::Shared<birch::type::Random<birch::type::Real>> x = libbirch::make<libbirch::Shared<birch::type::Random<birch::type::Real>>>();
    #line 16 "src/test/test_grad.birch"
    libbirch_line_(16);
    #line 16 "src/test/test_grad.birch"
    x->setPilot(π->simulate() + 0.5 * h);
    #line 19 "src/test/test_grad.birch"
    libbirch_line_(19);
    #line 19 "src/test/test_grad.birch"
    auto p = π->logpdfLazy(x).value();
    #line 20 "src/test/test_grad.birch"
    libbirch_line_(20);
    #line 20 "src/test/test_grad.birch"
    p->pilot(birch::type::Integer(1));
    #line 21 "src/test/test_grad.birch"
    libbirch_line_(21);
    #line 21 "src/test/test_grad.birch"
    p->grad(birch::type::Integer(1), 1.0);
    #line 22 "src/test/test_grad.birch"
    libbirch_line_(22);
    #line 22 "src/test/test_grad.birch"
    auto d = x->getGradient();
    #line 25 "src/test/test_grad.birch"
    libbirch_line_(25);
    #line 25 "src/test/test_grad.birch"
    auto y = x->get();
    #line 26 "src/test/test_grad.birch"
    libbirch_line_(26);
    #line 26 "src/test/test_grad.birch"
    auto z = x->get();
    #line 27 "src/test/test_grad.birch"
    libbirch_line_(27);
    #line 27 "src/test/test_grad.birch"
    y = y - 0.5 * h;
    #line 28 "src/test/test_grad.birch"
    libbirch_line_(28);
    #line 28 "src/test/test_grad.birch"
    z = z + 0.5 * h;
    #line 29 "src/test/test_grad.birch"
    libbirch_line_(29);
    #line 29 "src/test/test_grad.birch"
    auto q = π->logpdf(y);
    #line 30 "src/test/test_grad.birch"
    libbirch_line_(30);
    #line 30 "src/test/test_grad.birch"
    auto r = π->logpdf(z);
    #line 31 "src/test/test_grad.birch"
    libbirch_line_(31);
    #line 31 "src/test/test_grad.birch"
    auto fd = (r - q) / h;
    #line 34 "src/test/test_grad.birch"
    libbirch_line_(34);
    #line 34 "src/test/test_grad.birch"
    auto δ = birch::abs(d - fd);
    #line 35 "src/test/test_grad.birch"
    libbirch_line_(35);
    #line 35 "src/test/test_grad.birch"
    if (!((δ <= ε * birch::abs(fd)))) {
      #line 36 "src/test/test_grad.birch"
      libbirch_line_(36);
      #line 36 "src/test/test_grad.birch"
      birch::stderr()->print(birch::type::String("***failed*** d=") + d + birch::type::String(", fd=") + fd + birch::type::String(", ") + δ + birch::type::String(" > ") + ε * birch::abs(fd) + birch::type::String("\n"));
      #line 37 "src/test/test_grad.birch"
      libbirch_line_(37);
      #line 37 "src/test/test_grad.birch"
      failed = failed + birch::type::Integer(1);
    }
    #line 39 "src/test/test_grad.birch"
    libbirch_line_(39);
    #line 39 "src/test/test_grad.birch"
    if (failed > birch::type::Integer(0)) {
      #line 40 "src/test/test_grad.birch"
      libbirch_line_(40);
      #line 40 "src/test/test_grad.birch"
      birch::exit(birch::type::Integer(1));
    }
  }
}

#line 51 "src/test/test_grad.birch"
void birch::test_grad(const libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>& π, const birch::type::Integer& N) {
  #line 51 "src/test/test_grad.birch"
  libbirch_function_("test_grad", "src/test/test_grad.birch", 51);
  #line 52 "src/test/test_grad.birch"
  libbirch_line_(52);
  #line 52 "src/test/test_grad.birch"
  libbirch_assert_(π->supportsLazy());
  #line 53 "src/test/test_grad.birch"
  libbirch_line_(53);
  #line 53 "src/test/test_grad.birch"
  auto failed = birch::type::Integer(0);
  #line 54 "src/test/test_grad.birch"
  libbirch_line_(54);
  #line 54 "src/test/test_grad.birch"
  auto h = 1.0e-4;
  #line 55 "src/test/test_grad.birch"
  libbirch_line_(55);
  #line 55 "src/test/test_grad.birch"
  auto ε = 1.0e-2;
  #line 56 "src/test/test_grad.birch"
  libbirch_line_(56);
  #line 56 "src/test/test_grad.birch"
  auto D = π->rows();
  #line 58 "src/test/test_grad.birch"
  libbirch_line_(58);
  #line 58 "src/test/test_grad.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 60 "src/test/test_grad.birch"
    libbirch_line_(60);
    #line 60 "src/test/test_grad.birch"
    libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,1>>> x = libbirch::make<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,1>>>>();
    #line 61 "src/test/test_grad.birch"
    libbirch_line_(61);
    #line 61 "src/test/test_grad.birch"
    x->setPilot(π->simulate() + birch::vector(0.5 * h, D));
    #line 64 "src/test/test_grad.birch"
    libbirch_line_(64);
    #line 64 "src/test/test_grad.birch"
    auto p = π->logpdfLazy(x).value();
    #line 65 "src/test/test_grad.birch"
    libbirch_line_(65);
    #line 65 "src/test/test_grad.birch"
    p->pilot(birch::type::Integer(1));
    #line 66 "src/test/test_grad.birch"
    libbirch_line_(66);
    #line 66 "src/test/test_grad.birch"
    p->grad(birch::type::Integer(1), 1.0);
    #line 67 "src/test/test_grad.birch"
    libbirch_line_(67);
    #line 67 "src/test/test_grad.birch"
    auto d = x->getGradient();
    #line 69 "src/test/test_grad.birch"
    libbirch_line_(69);
    #line 69 "src/test/test_grad.birch"
    for (auto i = birch::type::Integer(1); i <= D; ++i) {
      #line 71 "src/test/test_grad.birch"
      libbirch_line_(71);
      #line 71 "src/test/test_grad.birch"
      auto y = x->get();
      #line 72 "src/test/test_grad.birch"
      libbirch_line_(72);
      #line 72 "src/test/test_grad.birch"
      auto z = x->get();
      #line 73 "src/test/test_grad.birch"
      libbirch_line_(73);
      #line 73 "src/test/test_grad.birch"
      y(i) = y(i) - 0.5 * h;
      #line 74 "src/test/test_grad.birch"
      libbirch_line_(74);
      #line 74 "src/test/test_grad.birch"
      z(i) = z(i) + 0.5 * h;
      #line 75 "src/test/test_grad.birch"
      libbirch_line_(75);
      #line 75 "src/test/test_grad.birch"
      auto q = π->logpdf(y);
      #line 76 "src/test/test_grad.birch"
      libbirch_line_(76);
      #line 76 "src/test/test_grad.birch"
      auto r = π->logpdf(z);
      #line 77 "src/test/test_grad.birch"
      libbirch_line_(77);
      #line 77 "src/test/test_grad.birch"
      auto fd = (r - q) / h;
      #line 80 "src/test/test_grad.birch"
      libbirch_line_(80);
      #line 80 "src/test/test_grad.birch"
      auto δ = birch::abs(d(i) - fd);
      #line 81 "src/test/test_grad.birch"
      libbirch_line_(81);
      #line 81 "src/test/test_grad.birch"
      if (!((δ <= ε * birch::abs(fd)))) {
        #line 82 "src/test/test_grad.birch"
        libbirch_line_(82);
        #line 82 "src/test/test_grad.birch"
        birch::stderr()->print(birch::type::String("***failed*** d=") + d(i) + birch::type::String(", fd=") + fd + birch::type::String(", ") + δ + birch::type::String(" > ") + ε * birch::abs(fd) + birch::type::String("\n"));
        #line 83 "src/test/test_grad.birch"
        libbirch_line_(83);
        #line 83 "src/test/test_grad.birch"
        failed = failed + birch::type::Integer(1);
      }
    }
    #line 86 "src/test/test_grad.birch"
    libbirch_line_(86);
    #line 86 "src/test/test_grad.birch"
    if (failed > birch::type::Integer(0)) {
      #line 87 "src/test/test_grad.birch"
      libbirch_line_(87);
      #line 87 "src/test/test_grad.birch"
      birch::exit(birch::type::Integer(1));
    }
  }
}

#line 98 "src/test/test_grad.birch"
void birch::test_grad(const libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>& π, const birch::type::Integer& N) {
  #line 98 "src/test/test_grad.birch"
  libbirch_function_("test_grad", "src/test/test_grad.birch", 98);
  #line 99 "src/test/test_grad.birch"
  libbirch_line_(99);
  #line 99 "src/test/test_grad.birch"
  libbirch_assert_(π->supportsLazy());
  #line 100 "src/test/test_grad.birch"
  libbirch_line_(100);
  #line 100 "src/test/test_grad.birch"
  auto failed = birch::type::Integer(0);
  #line 101 "src/test/test_grad.birch"
  libbirch_line_(101);
  #line 101 "src/test/test_grad.birch"
  auto h = 1.0e-4;
  #line 102 "src/test/test_grad.birch"
  libbirch_line_(102);
  #line 102 "src/test/test_grad.birch"
  auto ε = 1.0e-2;
  #line 103 "src/test/test_grad.birch"
  libbirch_line_(103);
  #line 103 "src/test/test_grad.birch"
  auto R = π->rows();
  #line 104 "src/test/test_grad.birch"
  libbirch_line_(104);
  #line 104 "src/test/test_grad.birch"
  auto C = π->columns();
  #line 106 "src/test/test_grad.birch"
  libbirch_line_(106);
  #line 106 "src/test/test_grad.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 108 "src/test/test_grad.birch"
    libbirch_line_(108);
    #line 108 "src/test/test_grad.birch"
    libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,2>>> x = libbirch::make<libbirch::Shared<birch::type::Random<libbirch::DefaultArray<birch::type::Real,2>>>>();
    #line 109 "src/test/test_grad.birch"
    libbirch_line_(109);
    #line 109 "src/test/test_grad.birch"
    x->setPilot(π->simulate() + birch::matrix(0.5 * h, R, C));
    #line 112 "src/test/test_grad.birch"
    libbirch_line_(112);
    #line 112 "src/test/test_grad.birch"
    auto p = π->logpdfLazy(x).value();
    #line 113 "src/test/test_grad.birch"
    libbirch_line_(113);
    #line 113 "src/test/test_grad.birch"
    p->pilot(birch::type::Integer(1));
    #line 114 "src/test/test_grad.birch"
    libbirch_line_(114);
    #line 114 "src/test/test_grad.birch"
    p->grad(birch::type::Integer(1), 1.0);
    #line 115 "src/test/test_grad.birch"
    libbirch_line_(115);
    #line 115 "src/test/test_grad.birch"
    auto d = x->getGradient();
    #line 117 "src/test/test_grad.birch"
    libbirch_line_(117);
    #line 117 "src/test/test_grad.birch"
    for (auto i = birch::type::Integer(1); i <= R; ++i) {
      #line 118 "src/test/test_grad.birch"
      libbirch_line_(118);
      #line 118 "src/test/test_grad.birch"
      for (auto j = birch::type::Integer(1); j <= C; ++j) {
        #line 120 "src/test/test_grad.birch"
        libbirch_line_(120);
        #line 120 "src/test/test_grad.birch"
        auto y = x->get();
        #line 121 "src/test/test_grad.birch"
        libbirch_line_(121);
        #line 121 "src/test/test_grad.birch"
        auto z = x->get();
        #line 122 "src/test/test_grad.birch"
        libbirch_line_(122);
        #line 122 "src/test/test_grad.birch"
        y(i, j) = y(i, j) - 0.5 * h;
        #line 123 "src/test/test_grad.birch"
        libbirch_line_(123);
        #line 123 "src/test/test_grad.birch"
        z(i, j) = z(i, j) + 0.5 * h;
        #line 124 "src/test/test_grad.birch"
        libbirch_line_(124);
        #line 124 "src/test/test_grad.birch"
        auto q = π->logpdf(y);
        #line 125 "src/test/test_grad.birch"
        libbirch_line_(125);
        #line 125 "src/test/test_grad.birch"
        auto r = π->logpdf(z);
        #line 126 "src/test/test_grad.birch"
        libbirch_line_(126);
        #line 126 "src/test/test_grad.birch"
        auto fd = (r - q) / h;
        #line 129 "src/test/test_grad.birch"
        libbirch_line_(129);
        #line 129 "src/test/test_grad.birch"
        auto δ = birch::abs(d(i, j) - fd);
        #line 130 "src/test/test_grad.birch"
        libbirch_line_(130);
        #line 130 "src/test/test_grad.birch"
        if (!((δ <= ε * birch::abs(fd)))) {
          #line 131 "src/test/test_grad.birch"
          libbirch_line_(131);
          #line 131 "src/test/test_grad.birch"
          birch::stderr()->print(birch::type::String("***failed*** d=") + d(i, j) + birch::type::String(", fd=") + fd + birch::type::String(", ") + δ + birch::type::String(" > ") + ε * birch::abs(fd) + birch::type::String("\n"));
          #line 132 "src/test/test_grad.birch"
          libbirch_line_(132);
          #line 132 "src/test/test_grad.birch"
          failed = failed + birch::type::Integer(1);
        }
      }
    }
    #line 136 "src/test/test_grad.birch"
    libbirch_line_(136);
    #line 136 "src/test/test_grad.birch"
    if (failed > birch::type::Integer(0)) {
      #line 137 "src/test/test_grad.birch"
      libbirch_line_(137);
      #line 137 "src/test/test_grad.birch"
      birch::exit(birch::type::Integer(1));
    }
  }
}

#line 8 "src/test/test_pdf.birch"
void birch::test_pdf(const libbirch::Shared<birch::type::Distribution<birch::type::Boolean>>& π, const birch::type::Integer& N, const birch::type::Boolean& lazy) {
  #line 8 "src/test/test_pdf.birch"
  libbirch_function_("test_pdf", "src/test/test_pdf.birch", 8);
  #line 10 "src/test/test_pdf.birch"
  libbirch_line_(10);
  #line 10 "src/test/test_pdf.birch"
  auto k = birch::type::Integer(0);
  #line 11 "src/test/test_pdf.birch"
  libbirch_line_(11);
  #line 11 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 12 "src/test/test_pdf.birch"
    libbirch_line_(12);
    #line 12 "src/test/test_pdf.birch"
    if (π->simulate()) {
      #line 13 "src/test/test_pdf.birch"
      libbirch_line_(13);
      #line 13 "src/test/test_pdf.birch"
      k = k + birch::type::Integer(1);
    }
    #line 15 "src/test/test_pdf.birch"
    libbirch_line_(15);
    #line 15 "src/test/test_pdf.birch"
    if (birch::mod(n, birch::type::Integer(10000)) == birch::type::Integer(0)) {
      #line 16 "src/test/test_pdf.birch"
      libbirch_line_(16);
      #line 16 "src/test/test_pdf.birch"
      birch::collect();
    }
  }
  #line 21 "src/test/test_pdf.birch"
  libbirch_line_(21);
  #line 21 "src/test/test_pdf.birch"
  auto failed = false;
  #line 22 "src/test/test_pdf.birch"
  libbirch_line_(22);
  #line 22 "src/test/test_pdf.birch"
  auto ε = 5.0 / birch::sqrt(birch::Real(N));
  #line 24 "src/test/test_pdf.birch"
  libbirch_line_(24);
  #line 24 "src/test/test_pdf.birch"
  birch::type::Real p = libbirch::make<birch::type::Real>();
  #line 25 "src/test/test_pdf.birch"
  libbirch_line_(25);
  #line 25 "src/test/test_pdf.birch"
  birch::type::Real q = libbirch::make<birch::type::Real>();
  #line 26 "src/test/test_pdf.birch"
  libbirch_line_(26);
  #line 26 "src/test/test_pdf.birch"
  if (lazy && π->supportsLazy()) {
    #line 27 "src/test/test_pdf.birch"
    libbirch_line_(27);
    #line 27 "src/test/test_pdf.birch"
    p = birch::exp(π->logpdfLazy(birch::box(true)).value()->value());
    #line 28 "src/test/test_pdf.birch"
    libbirch_line_(28);
    #line 28 "src/test/test_pdf.birch"
    q = birch::exp(π->logpdfLazy(birch::box(false)).value()->value());
  } else {
    #line 30 "src/test/test_pdf.birch"
    libbirch_line_(30);
    #line 30 "src/test/test_pdf.birch"
    p = π->pdf(true);
    #line 31 "src/test/test_pdf.birch"
    libbirch_line_(31);
    #line 31 "src/test/test_pdf.birch"
    q = π->pdf(false);
  }
  #line 33 "src/test/test_pdf.birch"
  libbirch_line_(33);
  #line 33 "src/test/test_pdf.birch"
  auto δ = birch::abs(p - birch::Real(k) / N);
  #line 34 "src/test/test_pdf.birch"
  libbirch_line_(34);
  #line 34 "src/test/test_pdf.birch"
  if (!((δ <= ε))) {
    #line 35 "src/test/test_pdf.birch"
    libbirch_line_(35);
    #line 35 "src/test/test_pdf.birch"
    failed = true;
    #line 36 "src/test/test_pdf.birch"
    libbirch_line_(36);
    #line 36 "src/test/test_pdf.birch"
    birch::stderr()->print(birch::type::String("***failed*** on true, ") + δ + birch::type::String(" > ") + ε + birch::type::String("\n"));
  }
  #line 38 "src/test/test_pdf.birch"
  libbirch_line_(38);
  #line 38 "src/test/test_pdf.birch"
  δ = birch::abs(q - birch::Real(N - k) / N);
  #line 39 "src/test/test_pdf.birch"
  libbirch_line_(39);
  #line 39 "src/test/test_pdf.birch"
  if (!((δ <= ε))) {
    #line 40 "src/test/test_pdf.birch"
    libbirch_line_(40);
    #line 40 "src/test/test_pdf.birch"
    failed = true;
    #line 41 "src/test/test_pdf.birch"
    libbirch_line_(41);
    #line 41 "src/test/test_pdf.birch"
    birch::stderr()->print(birch::type::String("***failed*** on false, ") + δ + birch::type::String(" > ") + ε + birch::type::String("\n"));
  }
  #line 43 "src/test/test_pdf.birch"
  libbirch_line_(43);
  #line 43 "src/test/test_pdf.birch"
  if (failed) {
    #line 44 "src/test/test_pdf.birch"
    libbirch_line_(44);
    #line 44 "src/test/test_pdf.birch"
    birch::exit(birch::type::Integer(1));
  }
}

#line 55 "src/test/test_pdf.birch"
void birch::test_pdf(const libbirch::Shared<birch::type::Distribution<birch::type::Integer>>& π, const birch::type::Integer& N, const birch::type::Boolean& lazy) {
  #line 55 "src/test/test_pdf.birch"
  libbirch_function_("test_pdf", "src/test/test_pdf.birch", 55);
  #line 57 "src/test/test_pdf.birch"
  libbirch_line_(57);
  #line 57 "src/test/test_pdf.birch"
  auto from = π->lower();
  #line 58 "src/test/test_pdf.birch"
  libbirch_line_(58);
  #line 58 "src/test/test_pdf.birch"
  if (!(from.has_value())) {
    #line 59 "src/test/test_pdf.birch"
    libbirch_line_(59);
    #line 59 "src/test/test_pdf.birch"
    from = π->quantile(1.0e-6);
    #line 60 "src/test/test_pdf.birch"
    libbirch_line_(60);
    #line 60 "src/test/test_pdf.birch"
    libbirch_assert_(from.has_value());
  }
  #line 64 "src/test/test_pdf.birch"
  libbirch_line_(64);
  #line 64 "src/test/test_pdf.birch"
  auto to = π->upper();
  #line 65 "src/test/test_pdf.birch"
  libbirch_line_(65);
  #line 65 "src/test/test_pdf.birch"
  if (!(to.has_value())) {
    #line 66 "src/test/test_pdf.birch"
    libbirch_line_(66);
    #line 66 "src/test/test_pdf.birch"
    to = π->quantile(1.0 - 1.0e-6);
    #line 67 "src/test/test_pdf.birch"
    libbirch_line_(67);
    #line 67 "src/test/test_pdf.birch"
    if (!(to.has_value())) {
      #line 69 "src/test/test_pdf.birch"
      libbirch_line_(69);
      #line 69 "src/test/test_pdf.birch"
      auto u = birch::type::Integer(50);
      #line 70 "src/test/test_pdf.birch"
      libbirch_line_(70);
      #line 70 "src/test/test_pdf.birch"
      auto p = 0.0;
      #line 71 "src/test/test_pdf.birch"
      libbirch_line_(71);
      #line 71 "src/test/test_pdf.birch"
      do {
        #line 72 "src/test/test_pdf.birch"
        libbirch_line_(72);
        #line 72 "src/test/test_pdf.birch"
        u = birch::type::Integer(2) * u;
        #line 73 "src/test/test_pdf.birch"
        libbirch_line_(73);
        #line 73 "src/test/test_pdf.birch"
        if (lazy) {
          #line 74 "src/test/test_pdf.birch"
          libbirch_line_(74);
          #line 74 "src/test/test_pdf.birch"
          p = birch::exp(π->logpdfLazy(birch::box(u)).value()->value());
        } else {
          #line 76 "src/test/test_pdf.birch"
          libbirch_line_(76);
          #line 76 "src/test/test_pdf.birch"
          p = π->pdf(u);
        }
      } while (p > 1.0e-6);
      #line 79 "src/test/test_pdf.birch"
      libbirch_line_(79);
      #line 79 "src/test/test_pdf.birch"
      to = u;
    }
  }
  #line 84 "src/test/test_pdf.birch"
  libbirch_line_(84);
  #line 84 "src/test/test_pdf.birch"
  auto count = birch::vector(birch::type::Integer(0), to.value() - from.value() + birch::type::Integer(1));
  #line 85 "src/test/test_pdf.birch"
  libbirch_line_(85);
  #line 85 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 86 "src/test/test_pdf.birch"
    libbirch_line_(86);
    #line 86 "src/test/test_pdf.birch"
    birch::type::Integer j = libbirch::make<birch::type::Integer>();
    #line 87 "src/test/test_pdf.birch"
    libbirch_line_(87);
    #line 87 "src/test/test_pdf.birch"
    if (lazy) {
      #line 88 "src/test/test_pdf.birch"
      libbirch_line_(88);
      #line 88 "src/test/test_pdf.birch"
      j = π->simulateLazy().value();
    } else {
      #line 90 "src/test/test_pdf.birch"
      libbirch_line_(90);
      #line 90 "src/test/test_pdf.birch"
      j = π->simulate();
    }
    #line 92 "src/test/test_pdf.birch"
    libbirch_line_(92);
    #line 92 "src/test/test_pdf.birch"
    auto i = j - from.value() + birch::type::Integer(1);
    #line 93 "src/test/test_pdf.birch"
    libbirch_line_(93);
    #line 93 "src/test/test_pdf.birch"
    if (birch::type::Integer(1) <= i && i <= birch::length(count)) {
      #line 94 "src/test/test_pdf.birch"
      libbirch_line_(94);
      #line 94 "src/test/test_pdf.birch"
      count(i) = count(i) + birch::type::Integer(1);
    }
    #line 96 "src/test/test_pdf.birch"
    libbirch_line_(96);
    #line 96 "src/test/test_pdf.birch"
    if (birch::mod(n, birch::type::Integer(10000)) == birch::type::Integer(0)) {
      #line 97 "src/test/test_pdf.birch"
      libbirch_line_(97);
      #line 97 "src/test/test_pdf.birch"
      birch::collect();
    }
  }
  #line 102 "src/test/test_pdf.birch"
  libbirch_line_(102);
  #line 102 "src/test/test_pdf.birch"
  auto failed = false;
  #line 103 "src/test/test_pdf.birch"
  libbirch_line_(103);
  #line 103 "src/test/test_pdf.birch"
  for (auto x = from.value(); x <= to.value(); ++x) {
    #line 104 "src/test/test_pdf.birch"
    libbirch_line_(104);
    #line 104 "src/test/test_pdf.birch"
    birch::type::Real p = libbirch::make<birch::type::Real>();
    #line 105 "src/test/test_pdf.birch"
    libbirch_line_(105);
    #line 105 "src/test/test_pdf.birch"
    if (lazy) {
      #line 106 "src/test/test_pdf.birch"
      libbirch_line_(106);
      #line 106 "src/test/test_pdf.birch"
      p = birch::exp(π->logpdfLazy(birch::box(x)).value()->value());
    } else {
      #line 108 "src/test/test_pdf.birch"
      libbirch_line_(108);
      #line 108 "src/test/test_pdf.birch"
      p = π->pdf(x);
    }
    #line 110 "src/test/test_pdf.birch"
    libbirch_line_(110);
    #line 110 "src/test/test_pdf.birch"
    auto δ = birch::abs(p - birch::Real(count(x - from.value() + birch::type::Integer(1))) / N);
    #line 111 "src/test/test_pdf.birch"
    libbirch_line_(111);
    #line 111 "src/test/test_pdf.birch"
    auto ε = 5.0 / birch::sqrt(birch::Real(N));
    #line 112 "src/test/test_pdf.birch"
    libbirch_line_(112);
    #line 112 "src/test/test_pdf.birch"
    if (!((δ <= ε))) {
      #line 113 "src/test/test_pdf.birch"
      libbirch_line_(113);
      #line 113 "src/test/test_pdf.birch"
      failed = true;
      #line 114 "src/test/test_pdf.birch"
      libbirch_line_(114);
      #line 114 "src/test/test_pdf.birch"
      birch::stderr()->print(birch::type::String("***failed*** on value ") + x + birch::type::String(", ") + δ + birch::type::String(" > ") + ε + birch::type::String("\n"));
    }
  }
  #line 117 "src/test/test_pdf.birch"
  libbirch_line_(117);
  #line 117 "src/test/test_pdf.birch"
  if (failed) {
    #line 118 "src/test/test_pdf.birch"
    libbirch_line_(118);
    #line 118 "src/test/test_pdf.birch"
    birch::exit(birch::type::Integer(1));
  }
}

#line 131 "src/test/test_pdf.birch"
void birch::test_pdf(const libbirch::Shared<birch::type::Distribution<birch::type::Real>>& π, const birch::type::Integer& N, const birch::type::Integer& B, const birch::type::Integer& S, const birch::type::Boolean& lazy) {
  #line 131 "src/test/test_pdf.birch"
  libbirch_function_("test_pdf", "src/test/test_pdf.birch", 131);
  #line 133 "src/test/test_pdf.birch"
  libbirch_line_(133);
  #line 133 "src/test/test_pdf.birch"
  libbirch::DefaultArray<birch::type::Real,1> x1 = libbirch::make_array<birch::type::Real>(libbirch::make_shape(N));
  #line 134 "src/test/test_pdf.birch"
  libbirch_line_(134);
  #line 134 "src/test/test_pdf.birch"
  libbirch::DefaultArray<birch::type::Real,1> x2 = libbirch::make_array<birch::type::Real>(libbirch::make_shape(N));
  #line 137 "src/test/test_pdf.birch"
  libbirch_line_(137);
  #line 137 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 138 "src/test/test_pdf.birch"
    libbirch_line_(138);
    #line 138 "src/test/test_pdf.birch"
    x1(n) = birch::canonical(π->simulate());
    #line 139 "src/test/test_pdf.birch"
    libbirch_line_(139);
    #line 139 "src/test/test_pdf.birch"
    if (birch::mod(n, birch::type::Integer(10000)) == birch::type::Integer(0)) {
      #line 140 "src/test/test_pdf.birch"
      libbirch_line_(140);
      #line 140 "src/test/test_pdf.birch"
      birch::collect();
    }
  }
  #line 145 "src/test/test_pdf.birch"
  libbirch_line_(145);
  #line 145 "src/test/test_pdf.birch"
  auto μ = birch::sum(x1) / N;
  #line 146 "src/test/test_pdf.birch"
  libbirch_line_(146);
  #line 146 "src/test/test_pdf.birch"
  auto σ2 = birch::dot(x1) / N - μ * μ;
  #line 149 "src/test/test_pdf.birch"
  libbirch_line_(149);
  #line 149 "src/test/test_pdf.birch"
  auto done = false;
  #line 150 "src/test/test_pdf.birch"
  libbirch_line_(150);
  #line 150 "src/test/test_pdf.birch"
  do {
    #line 151 "src/test/test_pdf.birch"
    libbirch_line_(151);
    #line 151 "src/test/test_pdf.birch"
    auto a = 0.0;
    #line 152 "src/test/test_pdf.birch"
    libbirch_line_(152);
    #line 152 "src/test/test_pdf.birch"
    birch::type::Real x = libbirch::make<birch::type::Real>();
    #line 153 "src/test/test_pdf.birch"
    libbirch_line_(153);
    #line 153 "src/test/test_pdf.birch"
    if (lazy && π->supportsLazy()) {
      #line 154 "src/test/test_pdf.birch"
      libbirch_line_(154);
      #line 154 "src/test/test_pdf.birch"
      x = π->simulateLazy().value();
    } else {
      #line 156 "src/test/test_pdf.birch"
      libbirch_line_(156);
      #line 156 "src/test/test_pdf.birch"
      x = π->simulate();
    }
    #line 158 "src/test/test_pdf.birch"
    libbirch_line_(158);
    #line 158 "src/test/test_pdf.birch"
    birch::type::Real l = libbirch::make<birch::type::Real>();
    #line 159 "src/test/test_pdf.birch"
    libbirch_line_(159);
    #line 159 "src/test/test_pdf.birch"
    if (lazy && π->supportsLazy()) {
      #line 160 "src/test/test_pdf.birch"
      libbirch_line_(160);
      #line 160 "src/test/test_pdf.birch"
      l = π->logpdfLazy(birch::box(x)).value()->value();
    } else {
      #line 162 "src/test/test_pdf.birch"
      libbirch_line_(162);
      #line 162 "src/test/test_pdf.birch"
      l = π->logpdf(x);
    }
    #line 165 "src/test/test_pdf.birch"
    libbirch_line_(165);
    #line 165 "src/test/test_pdf.birch"
    for (auto n = birch::type::Integer(1); n <= B; ++n) {
      #line 166 "src/test/test_pdf.birch"
      libbirch_line_(166);
      #line 166 "src/test/test_pdf.birch"
      auto x_prime_ = birch::simulate_gaussian(x, σ2);
      #line 167 "src/test/test_pdf.birch"
      libbirch_line_(167);
      #line 167 "src/test/test_pdf.birch"
      birch::type::Real l_prime_ = libbirch::make<birch::type::Real>();
      #line 168 "src/test/test_pdf.birch"
      libbirch_line_(168);
      #line 168 "src/test/test_pdf.birch"
      if (lazy && π->supportsLazy()) {
        #line 169 "src/test/test_pdf.birch"
        libbirch_line_(169);
        #line 169 "src/test/test_pdf.birch"
        l_prime_ = π->logpdfLazy(birch::box(x_prime_)).value()->value();
      } else {
        #line 171 "src/test/test_pdf.birch"
        libbirch_line_(171);
        #line 171 "src/test/test_pdf.birch"
        l_prime_ = π->logpdf(x_prime_);
      }
      #line 173 "src/test/test_pdf.birch"
      libbirch_line_(173);
      #line 173 "src/test/test_pdf.birch"
      if (birch::log(birch::simulate_uniform(0.0, 1.0)) <= l_prime_ - l) {
        #line 175 "src/test/test_pdf.birch"
        libbirch_line_(175);
        #line 175 "src/test/test_pdf.birch"
        x = x_prime_;
        #line 176 "src/test/test_pdf.birch"
        libbirch_line_(176);
        #line 176 "src/test/test_pdf.birch"
        l = l_prime_;
        #line 177 "src/test/test_pdf.birch"
        libbirch_line_(177);
        #line 177 "src/test/test_pdf.birch"
        a = a + 1.0 / B;
      }
    }
    #line 181 "src/test/test_pdf.birch"
    libbirch_line_(181);
    #line 181 "src/test/test_pdf.birch"
    if (a < 0.4) {
      #line 182 "src/test/test_pdf.birch"
      libbirch_line_(182);
      #line 182 "src/test/test_pdf.birch"
      σ2 = 0.5 * σ2;
    } else {
      #line 183 "src/test/test_pdf.birch"
      libbirch_line_(183);
      #line 183 "src/test/test_pdf.birch"
      if (a > 0.5) {
        #line 184 "src/test/test_pdf.birch"
        libbirch_line_(184);
        #line 184 "src/test/test_pdf.birch"
        σ2 = 1.5 * σ2;
      } else {
        #line 186 "src/test/test_pdf.birch"
        libbirch_line_(186);
        #line 186 "src/test/test_pdf.birch"
        done = true;
      }
    }
  } while (!(done));
  #line 191 "src/test/test_pdf.birch"
  libbirch_line_(191);
  #line 191 "src/test/test_pdf.birch"
  auto a = 0.0;
  #line 192 "src/test/test_pdf.birch"
  libbirch_line_(192);
  #line 192 "src/test/test_pdf.birch"
  birch::type::Real x = libbirch::make<birch::type::Real>();
  #line 193 "src/test/test_pdf.birch"
  libbirch_line_(193);
  #line 193 "src/test/test_pdf.birch"
  if (lazy && π->supportsLazy()) {
    #line 194 "src/test/test_pdf.birch"
    libbirch_line_(194);
    #line 194 "src/test/test_pdf.birch"
    x = π->simulateLazy().value();
  } else {
    #line 196 "src/test/test_pdf.birch"
    libbirch_line_(196);
    #line 196 "src/test/test_pdf.birch"
    x = π->simulate();
  }
  #line 198 "src/test/test_pdf.birch"
  libbirch_line_(198);
  #line 198 "src/test/test_pdf.birch"
  birch::type::Real l = libbirch::make<birch::type::Real>();
  #line 199 "src/test/test_pdf.birch"
  libbirch_line_(199);
  #line 199 "src/test/test_pdf.birch"
  if (lazy && π->supportsLazy()) {
    #line 200 "src/test/test_pdf.birch"
    libbirch_line_(200);
    #line 200 "src/test/test_pdf.birch"
    l = π->logpdfLazy(birch::box(x)).value()->value();
  } else {
    #line 202 "src/test/test_pdf.birch"
    libbirch_line_(202);
    #line 202 "src/test/test_pdf.birch"
    l = π->logpdf(x);
  }
  #line 204 "src/test/test_pdf.birch"
  libbirch_line_(204);
  #line 204 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 205 "src/test/test_pdf.birch"
    libbirch_line_(205);
    #line 205 "src/test/test_pdf.birch"
    for (auto s = birch::type::Integer(1); s <= S; ++s) {
      #line 206 "src/test/test_pdf.birch"
      libbirch_line_(206);
      #line 206 "src/test/test_pdf.birch"
      auto x_prime_ = birch::simulate_gaussian(x, σ2);
      #line 207 "src/test/test_pdf.birch"
      libbirch_line_(207);
      #line 207 "src/test/test_pdf.birch"
      birch::type::Real l_prime_ = libbirch::make<birch::type::Real>();
      #line 208 "src/test/test_pdf.birch"
      libbirch_line_(208);
      #line 208 "src/test/test_pdf.birch"
      if (lazy && π->supportsLazy()) {
        #line 209 "src/test/test_pdf.birch"
        libbirch_line_(209);
        #line 209 "src/test/test_pdf.birch"
        l_prime_ = π->logpdfLazy(birch::box(x_prime_)).value()->value();
      } else {
        #line 211 "src/test/test_pdf.birch"
        libbirch_line_(211);
        #line 211 "src/test/test_pdf.birch"
        l_prime_ = π->logpdf(x_prime_);
      }
      #line 213 "src/test/test_pdf.birch"
      libbirch_line_(213);
      #line 213 "src/test/test_pdf.birch"
      if (birch::log(birch::simulate_uniform(0.0, 1.0)) <= l_prime_ - l) {
        #line 215 "src/test/test_pdf.birch"
        libbirch_line_(215);
        #line 215 "src/test/test_pdf.birch"
        x = x_prime_;
        #line 216 "src/test/test_pdf.birch"
        libbirch_line_(216);
        #line 216 "src/test/test_pdf.birch"
        l = l_prime_;
        #line 217 "src/test/test_pdf.birch"
        libbirch_line_(217);
        #line 217 "src/test/test_pdf.birch"
        a = a + 1.0 / (N * S);
      }
    }
    #line 220 "src/test/test_pdf.birch"
    libbirch_line_(220);
    #line 220 "src/test/test_pdf.birch"
    x2(n) = x;
    #line 221 "src/test/test_pdf.birch"
    libbirch_line_(221);
    #line 221 "src/test/test_pdf.birch"
    if (birch::mod(n, birch::type::Integer(1000)) == birch::type::Integer(0)) {
      #line 222 "src/test/test_pdf.birch"
      libbirch_line_(222);
      #line 222 "src/test/test_pdf.birch"
      birch::collect();
    }
  }
  #line 228 "src/test/test_pdf.birch"
  libbirch_line_(228);
  #line 228 "src/test/test_pdf.birch"
  if (!(birch::pass(x1, x2))) {
    #line 229 "src/test/test_pdf.birch"
    libbirch_line_(229);
    #line 229 "src/test/test_pdf.birch"
    birch::exit(birch::type::Integer(1));
  }
}

#line 243 "src/test/test_pdf.birch"
void birch::test_pdf(const libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>& π, const birch::type::Integer& D, const birch::type::Integer& N, const birch::type::Integer& B, const birch::type::Integer& S, const birch::type::Boolean& lazy) {
  #line 243 "src/test/test_pdf.birch"
  libbirch_function_("test_pdf", "src/test/test_pdf.birch", 243);
  #line 245 "src/test/test_pdf.birch"
  libbirch_line_(245);
  #line 245 "src/test/test_pdf.birch"
  libbirch::DefaultArray<birch::type::Real,2> X1 = libbirch::make_array<birch::type::Real>(libbirch::make_shape(N, D));
  #line 246 "src/test/test_pdf.birch"
  libbirch_line_(246);
  #line 246 "src/test/test_pdf.birch"
  libbirch::DefaultArray<birch::type::Real,2> X2 = libbirch::make_array<birch::type::Real>(libbirch::make_shape(N, D));
  #line 249 "src/test/test_pdf.birch"
  libbirch_line_(249);
  #line 249 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 250 "src/test/test_pdf.birch"
    libbirch_line_(250);
    #line 250 "src/test/test_pdf.birch"
    X1(n, libbirch::make_range(birch::type::Integer(1), D)) = π->simulate();
    #line 251 "src/test/test_pdf.birch"
    libbirch_line_(251);
    #line 251 "src/test/test_pdf.birch"
    if (birch::mod(n, birch::type::Integer(10000)) == birch::type::Integer(0)) {
      #line 252 "src/test/test_pdf.birch"
      libbirch_line_(252);
      #line 252 "src/test/test_pdf.birch"
      birch::collect();
    }
  }
  #line 257 "src/test/test_pdf.birch"
  libbirch_line_(257);
  #line 257 "src/test/test_pdf.birch"
  auto μ = birch::vector(0.0, D);
  #line 258 "src/test/test_pdf.birch"
  libbirch_line_(258);
  #line 258 "src/test/test_pdf.birch"
  auto Σ = birch::matrix(0.0, D, D);
  #line 259 "src/test/test_pdf.birch"
  libbirch_line_(259);
  #line 259 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 260 "src/test/test_pdf.birch"
    libbirch_line_(260);
    #line 260 "src/test/test_pdf.birch"
    auto x = X1(n, libbirch::make_range(birch::type::Integer(1), D));
    #line 261 "src/test/test_pdf.birch"
    libbirch_line_(261);
    #line 261 "src/test/test_pdf.birch"
    μ = μ + x;
    #line 262 "src/test/test_pdf.birch"
    libbirch_line_(262);
    #line 262 "src/test/test_pdf.birch"
    Σ = Σ + birch::outer(x);
  }
  #line 264 "src/test/test_pdf.birch"
  libbirch_line_(264);
  #line 264 "src/test/test_pdf.birch"
  μ = μ / birch::Real(N);
  #line 265 "src/test/test_pdf.birch"
  libbirch_line_(265);
  #line 265 "src/test/test_pdf.birch"
  Σ = Σ / birch::Real(N) - birch::outer(μ);
  #line 266 "src/test/test_pdf.birch"
  libbirch_line_(266);
  #line 266 "src/test/test_pdf.birch"
  auto T = birch::llt(Σ);
  #line 269 "src/test/test_pdf.birch"
  libbirch_line_(269);
  #line 269 "src/test/test_pdf.birch"
  auto done = false;
  #line 270 "src/test/test_pdf.birch"
  libbirch_line_(270);
  #line 270 "src/test/test_pdf.birch"
  do {
    #line 271 "src/test/test_pdf.birch"
    libbirch_line_(271);
    #line 271 "src/test/test_pdf.birch"
    auto a = 0.0;
    #line 272 "src/test/test_pdf.birch"
    libbirch_line_(272);
    #line 272 "src/test/test_pdf.birch"
    libbirch::DefaultArray<birch::type::Real,1> x = libbirch::make<libbirch::DefaultArray<birch::type::Real,1>>();
    #line 273 "src/test/test_pdf.birch"
    libbirch_line_(273);
    #line 273 "src/test/test_pdf.birch"
    if (lazy && π->supportsLazy()) {
      #line 274 "src/test/test_pdf.birch"
      libbirch_line_(274);
      #line 274 "src/test/test_pdf.birch"
      x = π->simulateLazy().value();
    } else {
      #line 276 "src/test/test_pdf.birch"
      libbirch_line_(276);
      #line 276 "src/test/test_pdf.birch"
      x = π->simulate();
    }
    #line 278 "src/test/test_pdf.birch"
    libbirch_line_(278);
    #line 278 "src/test/test_pdf.birch"
    birch::type::Real l = libbirch::make<birch::type::Real>();
    #line 279 "src/test/test_pdf.birch"
    libbirch_line_(279);
    #line 279 "src/test/test_pdf.birch"
    if (lazy && π->supportsLazy()) {
      #line 280 "src/test/test_pdf.birch"
      libbirch_line_(280);
      #line 280 "src/test/test_pdf.birch"
      l = π->logpdfLazy(birch::box(x)).value()->value();
    } else {
      #line 282 "src/test/test_pdf.birch"
      libbirch_line_(282);
      #line 282 "src/test/test_pdf.birch"
      l = π->logpdf(x);
    }
    #line 285 "src/test/test_pdf.birch"
    libbirch_line_(285);
    #line 285 "src/test/test_pdf.birch"
    for (auto n = birch::type::Integer(1); n <= B; ++n) {
      #line 286 "src/test/test_pdf.birch"
      libbirch_line_(286);
      #line 286 "src/test/test_pdf.birch"
      auto x_prime_ = birch::simulate_multivariate_gaussian(x, T);
      #line 287 "src/test/test_pdf.birch"
      libbirch_line_(287);
      #line 287 "src/test/test_pdf.birch"
      birch::type::Real l_prime_ = libbirch::make<birch::type::Real>();
      #line 288 "src/test/test_pdf.birch"
      libbirch_line_(288);
      #line 288 "src/test/test_pdf.birch"
      if (lazy && π->supportsLazy()) {
        #line 289 "src/test/test_pdf.birch"
        libbirch_line_(289);
        #line 289 "src/test/test_pdf.birch"
        l_prime_ = π->logpdfLazy(birch::box(x_prime_)).value()->value();
      } else {
        #line 291 "src/test/test_pdf.birch"
        libbirch_line_(291);
        #line 291 "src/test/test_pdf.birch"
        l_prime_ = π->logpdf(x_prime_);
      }
      #line 293 "src/test/test_pdf.birch"
      libbirch_line_(293);
      #line 293 "src/test/test_pdf.birch"
      if (birch::log(birch::simulate_uniform(0.0, 1.0)) <= l_prime_ - l) {
        #line 295 "src/test/test_pdf.birch"
        libbirch_line_(295);
        #line 295 "src/test/test_pdf.birch"
        x = x_prime_;
        #line 296 "src/test/test_pdf.birch"
        libbirch_line_(296);
        #line 296 "src/test/test_pdf.birch"
        l = l_prime_;
        #line 297 "src/test/test_pdf.birch"
        libbirch_line_(297);
        #line 297 "src/test/test_pdf.birch"
        a = a + 1.0 / B;
      }
    }
    #line 301 "src/test/test_pdf.birch"
    libbirch_line_(301);
    #line 301 "src/test/test_pdf.birch"
    if (a < 0.2) {
      #line 302 "src/test/test_pdf.birch"
      libbirch_line_(302);
      #line 302 "src/test/test_pdf.birch"
      Σ = 0.5 * Σ;
      #line 303 "src/test/test_pdf.birch"
      libbirch_line_(303);
      #line 303 "src/test/test_pdf.birch"
      T = birch::llt(Σ);
    } else {
      #line 304 "src/test/test_pdf.birch"
      libbirch_line_(304);
      #line 304 "src/test/test_pdf.birch"
      if (a > 0.25) {
        #line 305 "src/test/test_pdf.birch"
        libbirch_line_(305);
        #line 305 "src/test/test_pdf.birch"
        Σ = 1.5 * Σ;
        #line 306 "src/test/test_pdf.birch"
        libbirch_line_(306);
        #line 306 "src/test/test_pdf.birch"
        T = birch::llt(Σ);
      } else {
        #line 308 "src/test/test_pdf.birch"
        libbirch_line_(308);
        #line 308 "src/test/test_pdf.birch"
        done = true;
      }
    }
  } while (!(done));
  #line 313 "src/test/test_pdf.birch"
  libbirch_line_(313);
  #line 313 "src/test/test_pdf.birch"
  auto a = 0.0;
  #line 314 "src/test/test_pdf.birch"
  libbirch_line_(314);
  #line 314 "src/test/test_pdf.birch"
  libbirch::DefaultArray<birch::type::Real,1> x = libbirch::make<libbirch::DefaultArray<birch::type::Real,1>>();
  #line 315 "src/test/test_pdf.birch"
  libbirch_line_(315);
  #line 315 "src/test/test_pdf.birch"
  if (lazy && π->supportsLazy()) {
    #line 316 "src/test/test_pdf.birch"
    libbirch_line_(316);
    #line 316 "src/test/test_pdf.birch"
    x = π->simulateLazy().value();
  } else {
    #line 318 "src/test/test_pdf.birch"
    libbirch_line_(318);
    #line 318 "src/test/test_pdf.birch"
    x = π->simulate();
  }
  #line 320 "src/test/test_pdf.birch"
  libbirch_line_(320);
  #line 320 "src/test/test_pdf.birch"
  birch::type::Real l = libbirch::make<birch::type::Real>();
  #line 321 "src/test/test_pdf.birch"
  libbirch_line_(321);
  #line 321 "src/test/test_pdf.birch"
  if (lazy && π->supportsLazy()) {
    #line 322 "src/test/test_pdf.birch"
    libbirch_line_(322);
    #line 322 "src/test/test_pdf.birch"
    l = π->logpdfLazy(birch::box(x)).value()->value();
  } else {
    #line 324 "src/test/test_pdf.birch"
    libbirch_line_(324);
    #line 324 "src/test/test_pdf.birch"
    l = π->logpdf(x);
  }
  #line 326 "src/test/test_pdf.birch"
  libbirch_line_(326);
  #line 326 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 327 "src/test/test_pdf.birch"
    libbirch_line_(327);
    #line 327 "src/test/test_pdf.birch"
    for (auto s = birch::type::Integer(1); s <= S; ++s) {
      #line 328 "src/test/test_pdf.birch"
      libbirch_line_(328);
      #line 328 "src/test/test_pdf.birch"
      auto x_prime_ = birch::simulate_multivariate_gaussian(x, T);
      #line 329 "src/test/test_pdf.birch"
      libbirch_line_(329);
      #line 329 "src/test/test_pdf.birch"
      birch::type::Real l_prime_ = libbirch::make<birch::type::Real>();
      #line 330 "src/test/test_pdf.birch"
      libbirch_line_(330);
      #line 330 "src/test/test_pdf.birch"
      if (lazy && π->supportsLazy()) {
        #line 331 "src/test/test_pdf.birch"
        libbirch_line_(331);
        #line 331 "src/test/test_pdf.birch"
        l_prime_ = π->logpdfLazy(birch::box(x_prime_)).value()->value();
      } else {
        #line 333 "src/test/test_pdf.birch"
        libbirch_line_(333);
        #line 333 "src/test/test_pdf.birch"
        l_prime_ = π->logpdf(x_prime_);
      }
      #line 335 "src/test/test_pdf.birch"
      libbirch_line_(335);
      #line 335 "src/test/test_pdf.birch"
      if (birch::log(birch::simulate_uniform(0.0, 1.0)) <= l_prime_ - l) {
        #line 337 "src/test/test_pdf.birch"
        libbirch_line_(337);
        #line 337 "src/test/test_pdf.birch"
        x = x_prime_;
        #line 338 "src/test/test_pdf.birch"
        libbirch_line_(338);
        #line 338 "src/test/test_pdf.birch"
        l = l_prime_;
        #line 339 "src/test/test_pdf.birch"
        libbirch_line_(339);
        #line 339 "src/test/test_pdf.birch"
        a = a + 1.0 / (N * S);
      }
    }
    #line 342 "src/test/test_pdf.birch"
    libbirch_line_(342);
    #line 342 "src/test/test_pdf.birch"
    X2(n, libbirch::make_range(birch::type::Integer(1), D)) = x;
    #line 343 "src/test/test_pdf.birch"
    libbirch_line_(343);
    #line 343 "src/test/test_pdf.birch"
    if (birch::mod(n, birch::type::Integer(1000)) == birch::type::Integer(0)) {
      #line 344 "src/test/test_pdf.birch"
      libbirch_line_(344);
      #line 344 "src/test/test_pdf.birch"
      birch::collect();
    }
  }
  #line 350 "src/test/test_pdf.birch"
  libbirch_line_(350);
  #line 350 "src/test/test_pdf.birch"
  if (!(birch::pass(X1, X2))) {
    #line 351 "src/test/test_pdf.birch"
    libbirch_line_(351);
    #line 351 "src/test/test_pdf.birch"
    birch::exit(birch::type::Integer(1));
  }
}

#line 366 "src/test/test_pdf.birch"
void birch::test_pdf(const libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>& π, const birch::type::Integer& R, const birch::type::Integer& C, const birch::type::Integer& N, const birch::type::Integer& B, const birch::type::Integer& S, const birch::type::Boolean& lazy) {
  #line 366 "src/test/test_pdf.birch"
  libbirch_function_("test_pdf", "src/test/test_pdf.birch", 366);
  #line 368 "src/test/test_pdf.birch"
  libbirch_line_(368);
  #line 368 "src/test/test_pdf.birch"
  libbirch::DefaultArray<birch::type::Real,2> X1 = libbirch::make_array<birch::type::Real>(libbirch::make_shape(N, R * C));
  #line 369 "src/test/test_pdf.birch"
  libbirch_line_(369);
  #line 369 "src/test/test_pdf.birch"
  libbirch::DefaultArray<birch::type::Real,2> X2 = libbirch::make_array<birch::type::Real>(libbirch::make_shape(N, R * C));
  #line 372 "src/test/test_pdf.birch"
  libbirch_line_(372);
  #line 372 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 373 "src/test/test_pdf.birch"
    libbirch_line_(373);
    #line 373 "src/test/test_pdf.birch"
    X1(n, libbirch::make_range(birch::type::Integer(1), R * C)) = birch::vec(π->simulate());
    #line 374 "src/test/test_pdf.birch"
    libbirch_line_(374);
    #line 374 "src/test/test_pdf.birch"
    if (birch::mod(n, birch::type::Integer(10000)) == birch::type::Integer(0)) {
      #line 375 "src/test/test_pdf.birch"
      libbirch_line_(375);
      #line 375 "src/test/test_pdf.birch"
      birch::collect();
    }
  }
  #line 380 "src/test/test_pdf.birch"
  libbirch_line_(380);
  #line 380 "src/test/test_pdf.birch"
  auto μ = birch::vector(0.0, R * C);
  #line 381 "src/test/test_pdf.birch"
  libbirch_line_(381);
  #line 381 "src/test/test_pdf.birch"
  auto Σ = birch::matrix(0.0, R * C, R * C);
  #line 382 "src/test/test_pdf.birch"
  libbirch_line_(382);
  #line 382 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 383 "src/test/test_pdf.birch"
    libbirch_line_(383);
    #line 383 "src/test/test_pdf.birch"
    auto x = X1(n, libbirch::make_range(birch::type::Integer(1), R * C));
    #line 384 "src/test/test_pdf.birch"
    libbirch_line_(384);
    #line 384 "src/test/test_pdf.birch"
    μ = μ + x;
    #line 385 "src/test/test_pdf.birch"
    libbirch_line_(385);
    #line 385 "src/test/test_pdf.birch"
    Σ = Σ + birch::outer(x);
  }
  #line 387 "src/test/test_pdf.birch"
  libbirch_line_(387);
  #line 387 "src/test/test_pdf.birch"
  μ = μ / birch::Real(N);
  #line 388 "src/test/test_pdf.birch"
  libbirch_line_(388);
  #line 388 "src/test/test_pdf.birch"
  Σ = Σ / birch::Real(N) - birch::outer(μ);
  #line 389 "src/test/test_pdf.birch"
  libbirch_line_(389);
  #line 389 "src/test/test_pdf.birch"
  auto T = birch::llt(Σ);
  #line 392 "src/test/test_pdf.birch"
  libbirch_line_(392);
  #line 392 "src/test/test_pdf.birch"
  auto done = false;
  #line 393 "src/test/test_pdf.birch"
  libbirch_line_(393);
  #line 393 "src/test/test_pdf.birch"
  do {
    #line 394 "src/test/test_pdf.birch"
    libbirch_line_(394);
    #line 394 "src/test/test_pdf.birch"
    auto a = 0.0;
    #line 395 "src/test/test_pdf.birch"
    libbirch_line_(395);
    #line 395 "src/test/test_pdf.birch"
    libbirch::DefaultArray<birch::type::Real,2> x = libbirch::make<libbirch::DefaultArray<birch::type::Real,2>>();
    #line 396 "src/test/test_pdf.birch"
    libbirch_line_(396);
    #line 396 "src/test/test_pdf.birch"
    birch::type::Real l = libbirch::make<birch::type::Real>();
    #line 397 "src/test/test_pdf.birch"
    libbirch_line_(397);
    #line 397 "src/test/test_pdf.birch"
    if (lazy && π->supportsLazy()) {
      #line 398 "src/test/test_pdf.birch"
      libbirch_line_(398);
      #line 398 "src/test/test_pdf.birch"
      x = π->simulateLazy().value();
      #line 399 "src/test/test_pdf.birch"
      libbirch_line_(399);
      #line 399 "src/test/test_pdf.birch"
      l = π->logpdfLazy(birch::box(x)).value()->value();
    } else {
      #line 401 "src/test/test_pdf.birch"
      libbirch_line_(401);
      #line 401 "src/test/test_pdf.birch"
      x = π->simulate();
      #line 402 "src/test/test_pdf.birch"
      libbirch_line_(402);
      #line 402 "src/test/test_pdf.birch"
      l = π->logpdf(x);
    }
    #line 404 "src/test/test_pdf.birch"
    libbirch_line_(404);
    #line 404 "src/test/test_pdf.birch"
    for (auto n = birch::type::Integer(1); n <= B; ++n) {
      #line 405 "src/test/test_pdf.birch"
      libbirch_line_(405);
      #line 405 "src/test/test_pdf.birch"
      auto x_prime_ = birch::mat(birch::simulate_multivariate_gaussian(birch::vec(x), T), C);
      #line 406 "src/test/test_pdf.birch"
      libbirch_line_(406);
      #line 406 "src/test/test_pdf.birch"
      birch::type::Real l_prime_ = libbirch::make<birch::type::Real>();
      #line 407 "src/test/test_pdf.birch"
      libbirch_line_(407);
      #line 407 "src/test/test_pdf.birch"
      if (lazy && π->supportsLazy()) {
        #line 408 "src/test/test_pdf.birch"
        libbirch_line_(408);
        #line 408 "src/test/test_pdf.birch"
        l_prime_ = π->logpdfLazy(birch::box(x_prime_)).value()->value();
      } else {
        #line 410 "src/test/test_pdf.birch"
        libbirch_line_(410);
        #line 410 "src/test/test_pdf.birch"
        l_prime_ = π->logpdf(x_prime_);
      }
      #line 412 "src/test/test_pdf.birch"
      libbirch_line_(412);
      #line 412 "src/test/test_pdf.birch"
      if (birch::log(birch::simulate_uniform(0.0, 1.0)) <= l_prime_ - l) {
        #line 414 "src/test/test_pdf.birch"
        libbirch_line_(414);
        #line 414 "src/test/test_pdf.birch"
        x = x_prime_;
        #line 415 "src/test/test_pdf.birch"
        libbirch_line_(415);
        #line 415 "src/test/test_pdf.birch"
        l = l_prime_;
        #line 416 "src/test/test_pdf.birch"
        libbirch_line_(416);
        #line 416 "src/test/test_pdf.birch"
        a = a + 1.0 / B;
      }
    }
    #line 420 "src/test/test_pdf.birch"
    libbirch_line_(420);
    #line 420 "src/test/test_pdf.birch"
    if (a < 0.2) {
      #line 421 "src/test/test_pdf.birch"
      libbirch_line_(421);
      #line 421 "src/test/test_pdf.birch"
      Σ = 0.5 * Σ;
      #line 422 "src/test/test_pdf.birch"
      libbirch_line_(422);
      #line 422 "src/test/test_pdf.birch"
      T = birch::llt(Σ);
    } else {
      #line 423 "src/test/test_pdf.birch"
      libbirch_line_(423);
      #line 423 "src/test/test_pdf.birch"
      if (a > 0.25) {
        #line 424 "src/test/test_pdf.birch"
        libbirch_line_(424);
        #line 424 "src/test/test_pdf.birch"
        Σ = 1.5 * Σ;
        #line 425 "src/test/test_pdf.birch"
        libbirch_line_(425);
        #line 425 "src/test/test_pdf.birch"
        T = birch::llt(Σ);
      } else {
        #line 427 "src/test/test_pdf.birch"
        libbirch_line_(427);
        #line 427 "src/test/test_pdf.birch"
        done = true;
      }
    }
  } while (!(done));
  #line 432 "src/test/test_pdf.birch"
  libbirch_line_(432);
  #line 432 "src/test/test_pdf.birch"
  auto a = 0.0;
  #line 433 "src/test/test_pdf.birch"
  libbirch_line_(433);
  #line 433 "src/test/test_pdf.birch"
  libbirch::DefaultArray<birch::type::Real,2> x = libbirch::make<libbirch::DefaultArray<birch::type::Real,2>>();
  #line 434 "src/test/test_pdf.birch"
  libbirch_line_(434);
  #line 434 "src/test/test_pdf.birch"
  birch::type::Real l = libbirch::make<birch::type::Real>();
  #line 435 "src/test/test_pdf.birch"
  libbirch_line_(435);
  #line 435 "src/test/test_pdf.birch"
  if (lazy && π->supportsLazy()) {
    #line 436 "src/test/test_pdf.birch"
    libbirch_line_(436);
    #line 436 "src/test/test_pdf.birch"
    x = π->simulateLazy().value();
    #line 437 "src/test/test_pdf.birch"
    libbirch_line_(437);
    #line 437 "src/test/test_pdf.birch"
    l = π->logpdfLazy(birch::box(x)).value()->value();
  } else {
    #line 439 "src/test/test_pdf.birch"
    libbirch_line_(439);
    #line 439 "src/test/test_pdf.birch"
    x = π->simulate();
    #line 440 "src/test/test_pdf.birch"
    libbirch_line_(440);
    #line 440 "src/test/test_pdf.birch"
    l = π->logpdf(x);
  }
  #line 442 "src/test/test_pdf.birch"
  libbirch_line_(442);
  #line 442 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 443 "src/test/test_pdf.birch"
    libbirch_line_(443);
    #line 443 "src/test/test_pdf.birch"
    for (auto s = birch::type::Integer(1); s <= S; ++s) {
      #line 444 "src/test/test_pdf.birch"
      libbirch_line_(444);
      #line 444 "src/test/test_pdf.birch"
      auto x_prime_ = birch::mat(birch::simulate_multivariate_gaussian(birch::vec(x), T), C);
      #line 445 "src/test/test_pdf.birch"
      libbirch_line_(445);
      #line 445 "src/test/test_pdf.birch"
      birch::type::Real l_prime_ = libbirch::make<birch::type::Real>();
      #line 446 "src/test/test_pdf.birch"
      libbirch_line_(446);
      #line 446 "src/test/test_pdf.birch"
      if (lazy && π->supportsLazy()) {
        #line 447 "src/test/test_pdf.birch"
        libbirch_line_(447);
        #line 447 "src/test/test_pdf.birch"
        l_prime_ = π->logpdfLazy(birch::box(x_prime_)).value()->value();
      } else {
        #line 449 "src/test/test_pdf.birch"
        libbirch_line_(449);
        #line 449 "src/test/test_pdf.birch"
        l_prime_ = π->logpdf(x_prime_);
      }
      #line 451 "src/test/test_pdf.birch"
      libbirch_line_(451);
      #line 451 "src/test/test_pdf.birch"
      if (birch::log(birch::simulate_uniform(0.0, 1.0)) <= l_prime_ - l) {
        #line 453 "src/test/test_pdf.birch"
        libbirch_line_(453);
        #line 453 "src/test/test_pdf.birch"
        x = x_prime_;
        #line 454 "src/test/test_pdf.birch"
        libbirch_line_(454);
        #line 454 "src/test/test_pdf.birch"
        l = l_prime_;
        #line 455 "src/test/test_pdf.birch"
        libbirch_line_(455);
        #line 455 "src/test/test_pdf.birch"
        a = a + 1.0 / (N * S);
      }
    }
    #line 458 "src/test/test_pdf.birch"
    libbirch_line_(458);
    #line 458 "src/test/test_pdf.birch"
    X2(n, libbirch::make_range(birch::type::Integer(1), R * C)) = birch::vec(x);
    #line 459 "src/test/test_pdf.birch"
    libbirch_line_(459);
    #line 459 "src/test/test_pdf.birch"
    if (birch::mod(n, birch::type::Integer(1000)) == birch::type::Integer(0)) {
      #line 460 "src/test/test_pdf.birch"
      libbirch_line_(460);
      #line 460 "src/test/test_pdf.birch"
      birch::collect();
    }
  }
  #line 466 "src/test/test_pdf.birch"
  libbirch_line_(466);
  #line 466 "src/test/test_pdf.birch"
  if (!(birch::pass(X1, X2))) {
    #line 467 "src/test/test_pdf.birch"
    libbirch_line_(467);
    #line 467 "src/test/test_pdf.birch"
    birch::exit(birch::type::Integer(1));
  }
}

