#line 8 "src/test/test.birch"
birch::type::Integer birch::run_test(const birch::type::String& test, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 8 "src/test/test.birch"
  libbirch_function_("run_test", "src/test/test.birch", 8);
  #line 9 "src/test/test.birch"
  libbirch_line_(9);
  #line 9 "src/test/test.birch"
  birch::tic(handler_);
  #line 10 "src/test/test.birch"
  libbirch_line_(10);
  #line 10 "src/test/test.birch"
  birch::type::Integer code = birch::system(birch::type::String("birch test_") + test, handler_);
  #line 11 "src/test/test.birch"
  libbirch_line_(11);
  #line 11 "src/test/test.birch"
  birch::type::Real s = birch::toc(handler_);
  #line 12 "src/test/test.birch"
  libbirch_line_(12);
  #line 12 "src/test/test.birch"
  if (code == birch::type::Integer(0)) {
    #line 13 "src/test/test.birch"
    libbirch_line_(13);
    #line 13 "src/test/test.birch"
    birch::stdout()->print(birch::type::String("PASS"), handler_);
  } else {
    #line 15 "src/test/test.birch"
    libbirch_line_(15);
    #line 15 "src/test/test.birch"
    birch::stdout()->print(birch::type::String("FAIL"), handler_);
  }
  #line 17 "src/test/test.birch"
  libbirch_line_(17);
  #line 17 "src/test/test.birch"
  birch::stdout()->print(birch::type::String("\t") + s + birch::type::String("s\t"), handler_);
  #line 18 "src/test/test.birch"
  libbirch_line_(18);
  #line 18 "src/test/test.birch"
  birch::stdout()->print(test, handler_);
  #line 19 "src/test/test.birch"
  libbirch_line_(19);
  #line 19 "src/test/test.birch"
  birch::stdout()->print(birch::type::String("\n"), handler_);
  #line 21 "src/test/test.birch"
  libbirch_line_(21);
  #line 21 "src/test/test.birch"
  return code;
}

#line 32 "src/test/test.birch"
birch::type::Integer birch::run_test(const birch::type::String& test, const birch::type::Integer& N, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "src/test/test.birch"
  libbirch_function_("run_test", "src/test/test.birch", 32);
  #line 33 "src/test/test.birch"
  libbirch_line_(33);
  #line 33 "src/test/test.birch"
  birch::tic(handler_);
  #line 34 "src/test/test.birch"
  libbirch_line_(34);
  #line 34 "src/test/test.birch"
  birch::type::Integer code = birch::system(birch::type::String("birch test_") + test + birch::type::String(" -N ") + N, handler_);
  #line 35 "src/test/test.birch"
  libbirch_line_(35);
  #line 35 "src/test/test.birch"
  birch::type::Real s = birch::toc(handler_);
  #line 36 "src/test/test.birch"
  libbirch_line_(36);
  #line 36 "src/test/test.birch"
  if (code == birch::type::Integer(0)) {
    #line 37 "src/test/test.birch"
    libbirch_line_(37);
    #line 37 "src/test/test.birch"
    birch::stdout()->print(birch::type::String("PASS"), handler_);
  } else {
    #line 39 "src/test/test.birch"
    libbirch_line_(39);
    #line 39 "src/test/test.birch"
    birch::stdout()->print(birch::type::String("FAIL"), handler_);
  }
  #line 41 "src/test/test.birch"
  libbirch_line_(41);
  #line 41 "src/test/test.birch"
  birch::stdout()->print(birch::type::String("\t") + s + birch::type::String("s\t"), handler_);
  #line 42 "src/test/test.birch"
  libbirch_line_(42);
  #line 42 "src/test/test.birch"
  birch::stdout()->print(test, handler_);
  #line 43 "src/test/test.birch"
  libbirch_line_(43);
  #line 43 "src/test/test.birch"
  birch::stdout()->print(birch::type::String("\n"), handler_);
  #line 45 "src/test/test.birch"
  libbirch_line_(45);
  #line 45 "src/test/test.birch"
  return code;
}

#line 56 "src/test/test.birch"
birch::type::Boolean birch::pass(const libbirch::DefaultArray<birch::type::Real,2>& X1, const libbirch::DefaultArray<birch::type::Real,2>& X2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 56 "src/test/test.birch"
  libbirch_function_("pass", "src/test/test.birch", 56);
  #line 57 "src/test/test.birch"
  libbirch_line_(57);
  #line 57 "src/test/test.birch"
  libbirch_assert_(birch::rows(X1, handler_) == birch::rows(X2, handler_));  // GCOV_EXCL_LINE
  #line 58 "src/test/test.birch"
  libbirch_line_(58);
  #line 58 "src/test/test.birch"
  libbirch_assert_(birch::columns(X1, handler_) == birch::columns(X2, handler_));  // GCOV_EXCL_LINE
  #line 60 "src/test/test.birch"
  libbirch_line_(60);
  #line 60 "src/test/test.birch"
  auto R = birch::rows(X1, handler_);
  #line 61 "src/test/test.birch"
  libbirch_line_(61);
  #line 61 "src/test/test.birch"
  auto C = birch::columns(X1, handler_);
  #line 62 "src/test/test.birch"
  libbirch_line_(62);
  #line 62 "src/test/test.birch"
  auto failed = birch::type::Integer(0);
  #line 63 "src/test/test.birch"
  libbirch_line_(63);
  #line 63 "src/test/test.birch"
  auto tests = birch::type::Integer(0);
  #line 64 "src/test/test.birch"
  libbirch_line_(64);
  #line 64 "src/test/test.birch"
  auto _u0949 = 4.0 * birch::columns(X1, handler_) / birch::sqrt(birch::Real(R, handler_), handler_);
  #line 67 "src/test/test.birch"
  libbirch_line_(67);
  #line 67 "src/test/test.birch"
  for (auto c = birch::type::Integer(1); c <= C; ++c) {
    #line 69 "src/test/test.birch"
    libbirch_line_(69);
    #line 69 "src/test/test.birch"
    auto x1 = X1.get(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, R - 1), c - 1));
    #line 70 "src/test/test.birch"
    libbirch_line_(70);
    #line 70 "src/test/test.birch"
    auto x2 = X2.get(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, R - 1), c - 1));
    #line 73 "src/test/test.birch"
    libbirch_line_(73);
    #line 73 "src/test/test.birch"
    auto mn = birch::min(birch::min(x1, handler_), birch::min(x2, handler_), handler_);
    #line 74 "src/test/test.birch"
    libbirch_line_(74);
    #line 74 "src/test/test.birch"
    auto mx = birch::max(birch::max(x1, handler_), birch::max(x2, handler_), handler_);
    #line 75 "src/test/test.birch"
    libbirch_line_(75);
    #line 75 "src/test/test.birch"
    auto z1 = (x1 - birch::vector(mn, R, handler_)) / (mx - mn);
    #line 76 "src/test/test.birch"
    libbirch_line_(76);
    #line 76 "src/test/test.birch"
    auto z2 = (x2 - birch::vector(mn, R, handler_)) / (mx - mn);
    #line 79 "src/test/test.birch"
    libbirch_line_(79);
    #line 79 "src/test/test.birch"
    auto _u0948 = birch::wasserstein(z1, z2, handler_);
    #line 80 "src/test/test.birch"
    libbirch_line_(80);
    #line 80 "src/test/test.birch"
    if (_u0948 > _u0949) {
      #line 81 "src/test/test.birch"
      libbirch_line_(81);
      #line 81 "src/test/test.birch"
      failed = failed + birch::type::Integer(1);
      #line 82 "src/test/test.birch"
      libbirch_line_(82);
      #line 82 "src/test/test.birch"
      birch::stderr()->print(birch::type::String("failed on component ") + c + birch::type::String(", ") + _u0948 + birch::type::String(" > ") + _u0949 + birch::type::String("\n"), handler_);
    }
    #line 84 "src/test/test.birch"
    libbirch_line_(84);
    #line 84 "src/test/test.birch"
    tests = tests + birch::type::Integer(1);
  }
  #line 90 "src/test/test.birch"
  libbirch_line_(90);
  #line 90 "src/test/test.birch"
  for (auto c = birch::type::Integer(1); c <= C; ++c) {
    #line 92 "src/test/test.birch"
    libbirch_line_(92);
    #line 92 "src/test/test.birch"
    auto u = birch::simulate_uniform_unit_vector(C, handler_);
    #line 93 "src/test/test.birch"
    libbirch_line_(93);
    #line 93 "src/test/test.birch"
    auto x1 = X1 * u;
    #line 94 "src/test/test.birch"
    libbirch_line_(94);
    #line 94 "src/test/test.birch"
    auto x2 = X2 * u;
    #line 97 "src/test/test.birch"
    libbirch_line_(97);
    #line 97 "src/test/test.birch"
    auto mn = birch::min(birch::min(x1, handler_), birch::min(x2, handler_), handler_);
    #line 98 "src/test/test.birch"
    libbirch_line_(98);
    #line 98 "src/test/test.birch"
    auto mx = birch::max(birch::max(x1, handler_), birch::max(x2, handler_), handler_);
    #line 99 "src/test/test.birch"
    libbirch_line_(99);
    #line 99 "src/test/test.birch"
    auto z1 = (x1 - birch::vector(mn, R, handler_)) / (mx - mn);
    #line 100 "src/test/test.birch"
    libbirch_line_(100);
    #line 100 "src/test/test.birch"
    auto z2 = (x2 - birch::vector(mn, R, handler_)) / (mx - mn);
    #line 103 "src/test/test.birch"
    libbirch_line_(103);
    #line 103 "src/test/test.birch"
    auto _u0948 = birch::wasserstein(z1, z2, handler_);
    #line 104 "src/test/test.birch"
    libbirch_line_(104);
    #line 104 "src/test/test.birch"
    if (_u0948 > _u0949) {
      #line 105 "src/test/test.birch"
      libbirch_line_(105);
      #line 105 "src/test/test.birch"
      failed = failed + birch::type::Integer(1);
      #line 106 "src/test/test.birch"
      libbirch_line_(106);
      #line 106 "src/test/test.birch"
      birch::stderr()->print(birch::type::String("failed on random projection, ") + _u0948 + birch::type::String(" > ") + _u0949 + birch::type::String("\n"), handler_);
    }
    #line 108 "src/test/test.birch"
    libbirch_line_(108);
    #line 108 "src/test/test.birch"
    tests = tests + birch::type::Integer(1);
  }
  #line 111 "src/test/test.birch"
  libbirch_line_(111);
  #line 111 "src/test/test.birch"
  if (failed > birch::type::Integer(0)) {
    #line 112 "src/test/test.birch"
    libbirch_line_(112);
    #line 112 "src/test/test.birch"
    birch::stderr()->print(birch::type::String("failed ") + failed + birch::type::String(" of ") + tests + birch::type::String(" comparisons\n"), handler_);
  }
  #line 114 "src/test/test.birch"
  libbirch_line_(114);
  #line 114 "src/test/test.birch"
  return failed == birch::type::Integer(0);
}

#line 7 "src/test/test_cdf.birch"
void birch::test_cdf(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& q, const birch::type::Integer& N, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/test/test_cdf.birch"
  libbirch_function_("test_cdf", "src/test/test_cdf.birch", 7);
  #line 8 "src/test/test_cdf.birch"
  libbirch_line_(8);
  #line 8 "src/test/test_cdf.birch"
  auto failed = false;
  #line 11 "src/test/test_cdf.birch"
  libbirch_line_(11);
  #line 11 "src/test/test_cdf.birch"
  auto from = q->lower(handler_);
  #line 12 "src/test/test_cdf.birch"
  libbirch_line_(12);
  #line 12 "src/test/test_cdf.birch"
  if (from.query()) {
    #line 14 "src/test/test_cdf.birch"
    libbirch_line_(14);
    #line 14 "src/test/test_cdf.birch"
    auto test = q->quantile(0.0, handler_);
    #line 15 "src/test/test_cdf.birch"
    libbirch_line_(15);
    #line 15 "src/test/test_cdf.birch"
    if (test.query() && birch::abs(from.get() - test.get(), handler_) > 1.0 / N) {
      #line 16 "src/test/test_cdf.birch"
      libbirch_line_(16);
      #line 16 "src/test/test_cdf.birch"
      failed = true;
      #line 17 "src/test/test_cdf.birch"
      libbirch_line_(17);
      #line 17 "src/test/test_cdf.birch"
      birch::stderr()->print(birch::type::String("lower bound and quantile comparison failed\n"), handler_);
    }
  } else {
    #line 20 "src/test/test_cdf.birch"
    libbirch_line_(20);
    #line 20 "src/test/test_cdf.birch"
    from = q->quantile(1.0 / N, handler_);
    #line 21 "src/test/test_cdf.birch"
    libbirch_line_(21);
    #line 21 "src/test/test_cdf.birch"
    libbirch_assert_(from.query());  // GCOV_EXCL_LINE
  }
  #line 25 "src/test/test_cdf.birch"
  libbirch_line_(25);
  #line 25 "src/test/test_cdf.birch"
  auto to = q->upper(handler_);
  #line 26 "src/test/test_cdf.birch"
  libbirch_line_(26);
  #line 26 "src/test/test_cdf.birch"
  if (to.query()) {
    #line 28 "src/test/test_cdf.birch"
    libbirch_line_(28);
    #line 28 "src/test/test_cdf.birch"
    auto test = q->quantile(1.0, handler_);
    #line 29 "src/test/test_cdf.birch"
    libbirch_line_(29);
    #line 29 "src/test/test_cdf.birch"
    if (test.query() && birch::abs(to.get() - test.get(), handler_) > 1.0 / N) {
      #line 30 "src/test/test_cdf.birch"
      libbirch_line_(30);
      #line 30 "src/test/test_cdf.birch"
      failed = true;
      #line 31 "src/test/test_cdf.birch"
      libbirch_line_(31);
      #line 31 "src/test/test_cdf.birch"
      birch::stderr()->print(birch::type::String("upper bound and quantile comparison failed\n"), handler_);
    }
  } else {
    #line 34 "src/test/test_cdf.birch"
    libbirch_line_(34);
    #line 34 "src/test/test_cdf.birch"
    to = q->quantile(1.0 - 1.0 / N, handler_);
    #line 35 "src/test/test_cdf.birch"
    libbirch_line_(35);
    #line 35 "src/test/test_cdf.birch"
    if (!to.query()) {
      #line 37 "src/test/test_cdf.birch"
      libbirch_line_(37);
      #line 37 "src/test/test_cdf.birch"
      auto u = 1.0;
      #line 38 "src/test/test_cdf.birch"
      libbirch_line_(38);
      #line 38 "src/test/test_cdf.birch"
      while (q->pdf(u, handler_) > 1.0 / N) {
        #line 39 "src/test/test_cdf.birch"
        libbirch_line_(39);
        #line 39 "src/test/test_cdf.birch"
        u = 2.0 * u;
      }
      #line 41 "src/test/test_cdf.birch"
      libbirch_line_(41);
      #line 41 "src/test/test_cdf.birch"
      to = u;
    }
    #line 43 "src/test/test_cdf.birch"
    libbirch_line_(43);
    #line 43 "src/test/test_cdf.birch"
    libbirch_assert_(to.query());  // GCOV_EXCL_LINE
  }
  #line 47 "src/test/test_cdf.birch"
  libbirch_line_(47);
  #line 47 "src/test/test_cdf.birch"
  auto P = 0.5 / N;
  #line 48 "src/test/test_cdf.birch"
  libbirch_line_(48);
  #line 48 "src/test/test_cdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 49 "src/test/test_cdf.birch"
    libbirch_line_(49);
    #line 49 "src/test/test_cdf.birch"
    auto x = from.get() + (n - 0.5) * (to.get() - from.get()) / N;
    #line 50 "src/test/test_cdf.birch"
    libbirch_line_(50);
    #line 50 "src/test/test_cdf.birch"
    auto C = q->cdf(x, handler_).get();
    #line 51 "src/test/test_cdf.birch"
    libbirch_line_(51);
    #line 51 "src/test/test_cdf.birch"
    P = P + q->pdf(x, handler_) * (to.get() - from.get()) / N;
    #line 53 "src/test/test_cdf.birch"
    libbirch_line_(53);
    #line 53 "src/test/test_cdf.birch"
    auto _u0948 = birch::abs(C - P, handler_);
    #line 54 "src/test/test_cdf.birch"
    libbirch_line_(54);
    #line 54 "src/test/test_cdf.birch"
    auto _u0949 = 10.0 / birch::sqrt(birch::Real(N, handler_), handler_);
    #line 55 "src/test/test_cdf.birch"
    libbirch_line_(55);
    #line 55 "src/test/test_cdf.birch"
    if (_u0948 > _u0949) {
      #line 56 "src/test/test_cdf.birch"
      libbirch_line_(56);
      #line 56 "src/test/test_cdf.birch"
      failed = true;
      #line 57 "src/test/test_cdf.birch"
      libbirch_line_(57);
      #line 57 "src/test/test_cdf.birch"
      birch::stderr()->print(birch::type::String("failed on step ") + n + birch::type::String(", ") + _u0948 + birch::type::String(" > ") + _u0949 + birch::type::String("\n"), handler_);
    }
    #line 59 "src/test/test_cdf.birch"
    libbirch_line_(59);
    #line 59 "src/test/test_cdf.birch"
    if (failed) {
      #line 60 "src/test/test_cdf.birch"
      libbirch_line_(60);
      #line 60 "src/test/test_cdf.birch"
      birch::exit(birch::type::Integer(1), handler_);
    }
  }
}

#line 70 "src/test/test_cdf.birch"
void birch::test_cdf(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>>& q, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "src/test/test_cdf.birch"
  libbirch_function_("test_cdf", "src/test/test_cdf.birch", 70);
  #line 71 "src/test/test_cdf.birch"
  libbirch_line_(71);
  #line 71 "src/test/test_cdf.birch"
  auto failed = false;
  #line 74 "src/test/test_cdf.birch"
  libbirch_line_(74);
  #line 74 "src/test/test_cdf.birch"
  auto from = q->lower(handler_);
  #line 75 "src/test/test_cdf.birch"
  libbirch_line_(75);
  #line 75 "src/test/test_cdf.birch"
  if (from.query()) {
    #line 77 "src/test/test_cdf.birch"
    libbirch_line_(77);
    #line 77 "src/test/test_cdf.birch"
    auto test = q->quantile(0.0, handler_);
    #line 78 "src/test/test_cdf.birch"
    libbirch_line_(78);
    #line 78 "src/test/test_cdf.birch"
    if (test.query() && birch::abs(from.get() - test.get(), handler_) > 1.0e-6) {
      #line 79 "src/test/test_cdf.birch"
      libbirch_line_(79);
      #line 79 "src/test/test_cdf.birch"
      failed = true;
      #line 80 "src/test/test_cdf.birch"
      libbirch_line_(80);
      #line 80 "src/test/test_cdf.birch"
      birch::stderr()->print(birch::type::String("lower bound and quantile comparison failed\n"), handler_);
    }
  } else {
    #line 83 "src/test/test_cdf.birch"
    libbirch_line_(83);
    #line 83 "src/test/test_cdf.birch"
    from = q->quantile(1.0e-6, handler_);
    #line 84 "src/test/test_cdf.birch"
    libbirch_line_(84);
    #line 84 "src/test/test_cdf.birch"
    libbirch_assert_(from.query());  // GCOV_EXCL_LINE
  }
  #line 88 "src/test/test_cdf.birch"
  libbirch_line_(88);
  #line 88 "src/test/test_cdf.birch"
  auto to = q->upper(handler_);
  #line 89 "src/test/test_cdf.birch"
  libbirch_line_(89);
  #line 89 "src/test/test_cdf.birch"
  if (to.query()) {
    #line 91 "src/test/test_cdf.birch"
    libbirch_line_(91);
    #line 91 "src/test/test_cdf.birch"
    auto test = q->quantile(1.0, handler_);
    #line 92 "src/test/test_cdf.birch"
    libbirch_line_(92);
    #line 92 "src/test/test_cdf.birch"
    if (test.query() && birch::abs(to.get() - test.get(), handler_) > 1.0e-6) {
      #line 93 "src/test/test_cdf.birch"
      libbirch_line_(93);
      #line 93 "src/test/test_cdf.birch"
      failed = true;
      #line 94 "src/test/test_cdf.birch"
      libbirch_line_(94);
      #line 94 "src/test/test_cdf.birch"
      birch::stderr()->print(birch::type::String("upper bound and quantile comparison failed\n"), handler_);
    }
  } else {
    #line 97 "src/test/test_cdf.birch"
    libbirch_line_(97);
    #line 97 "src/test/test_cdf.birch"
    to = q->quantile(1.0 - 1.0e-6, handler_);
    #line 98 "src/test/test_cdf.birch"
    libbirch_line_(98);
    #line 98 "src/test/test_cdf.birch"
    libbirch_assert_(to.query());  // GCOV_EXCL_LINE
  }
  #line 102 "src/test/test_cdf.birch"
  libbirch_line_(102);
  #line 102 "src/test/test_cdf.birch"
  auto P = 0.0;
  #line 103 "src/test/test_cdf.birch"
  libbirch_line_(103);
  #line 103 "src/test/test_cdf.birch"
  for (auto x = from.get(); x <= to.get(); ++x) {
    #line 104 "src/test/test_cdf.birch"
    libbirch_line_(104);
    #line 104 "src/test/test_cdf.birch"
    auto C = q->cdf(x, handler_).get();
    #line 105 "src/test/test_cdf.birch"
    libbirch_line_(105);
    #line 105 "src/test/test_cdf.birch"
    P = P + q->pdf(x, handler_);
    #line 107 "src/test/test_cdf.birch"
    libbirch_line_(107);
    #line 107 "src/test/test_cdf.birch"
    auto _u0948 = birch::abs(C - P, handler_);
    #line 108 "src/test/test_cdf.birch"
    libbirch_line_(108);
    #line 108 "src/test/test_cdf.birch"
    auto _u0949 = 10.0 / birch::sqrt(x - from.get() + 1.0, handler_);
    #line 109 "src/test/test_cdf.birch"
    libbirch_line_(109);
    #line 109 "src/test/test_cdf.birch"
    if (_u0948 > _u0949) {
      #line 110 "src/test/test_cdf.birch"
      libbirch_line_(110);
      #line 110 "src/test/test_cdf.birch"
      failed = true;
      #line 111 "src/test/test_cdf.birch"
      libbirch_line_(111);
      #line 111 "src/test/test_cdf.birch"
      birch::stderr()->print(birch::type::String("failed on value ") + x + birch::type::String(", ") + _u0948 + birch::type::String(" > ") + _u0949 + birch::type::String("\n"), handler_);
    }
    #line 113 "src/test/test_cdf.birch"
    libbirch_line_(113);
    #line 113 "src/test/test_cdf.birch"
    if (failed) {
      #line 114 "src/test/test_cdf.birch"
      libbirch_line_(114);
      #line 114 "src/test/test_cdf.birch"
      birch::exit(birch::type::Integer(1), handler_);
    }
  }
}

#line 7 "src/test/test_pdf.birch"
void birch::test_pdf(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Boolean>>>& _u0960, const birch::type::Integer& N, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 7 "src/test/test_pdf.birch"
  libbirch_function_("test_pdf", "src/test/test_pdf.birch", 7);
  #line 9 "src/test/test_pdf.birch"
  libbirch_line_(9);
  #line 9 "src/test/test_pdf.birch"
  auto k = birch::type::Integer(0);
  #line 10 "src/test/test_pdf.birch"
  libbirch_line_(10);
  #line 10 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 11 "src/test/test_pdf.birch"
    libbirch_line_(11);
    #line 11 "src/test/test_pdf.birch"
    if (_u0960->simulate(handler_)) {
      #line 12 "src/test/test_pdf.birch"
      libbirch_line_(12);
      #line 12 "src/test/test_pdf.birch"
      k = k + birch::type::Integer(1);
    }
  }
  #line 17 "src/test/test_pdf.birch"
  libbirch_line_(17);
  #line 17 "src/test/test_pdf.birch"
  auto failed = false;
  #line 18 "src/test/test_pdf.birch"
  libbirch_line_(18);
  #line 18 "src/test/test_pdf.birch"
  auto _u0949 = 5.0 / birch::sqrt(birch::Real(N, handler_), handler_);
  #line 20 "src/test/test_pdf.birch"
  libbirch_line_(20);
  #line 20 "src/test/test_pdf.birch"
  auto _u0948 = birch::abs(_u0960->pdf(true, handler_) - birch::Real(k, handler_) / N, handler_);
  #line 21 "src/test/test_pdf.birch"
  libbirch_line_(21);
  #line 21 "src/test/test_pdf.birch"
  if (_u0948 > _u0949) {
    #line 22 "src/test/test_pdf.birch"
    libbirch_line_(22);
    #line 22 "src/test/test_pdf.birch"
    failed = true;
    #line 23 "src/test/test_pdf.birch"
    libbirch_line_(23);
    #line 23 "src/test/test_pdf.birch"
    birch::stderr()->print(birch::type::String("failed on true, ") + _u0948 + birch::type::String(" > ") + _u0949 + birch::type::String("\n"), handler_);
  }
  #line 25 "src/test/test_pdf.birch"
  libbirch_line_(25);
  #line 25 "src/test/test_pdf.birch"
  _u0948 = birch::abs(_u0960->pdf(false, handler_) - birch::Real(N - k, handler_) / N, handler_);
  #line 26 "src/test/test_pdf.birch"
  libbirch_line_(26);
  #line 26 "src/test/test_pdf.birch"
  if (_u0948 > _u0949) {
    #line 27 "src/test/test_pdf.birch"
    libbirch_line_(27);
    #line 27 "src/test/test_pdf.birch"
    failed = true;
    #line 28 "src/test/test_pdf.birch"
    libbirch_line_(28);
    #line 28 "src/test/test_pdf.birch"
    birch::stderr()->print(birch::type::String("failed on false, ") + _u0948 + birch::type::String(" > ") + _u0949 + birch::type::String("\n"), handler_);
  }
  #line 30 "src/test/test_pdf.birch"
  libbirch_line_(30);
  #line 30 "src/test/test_pdf.birch"
  if (failed) {
    #line 31 "src/test/test_pdf.birch"
    libbirch_line_(31);
    #line 31 "src/test/test_pdf.birch"
    birch::exit(birch::type::Integer(1), handler_);
  }
}

#line 41 "src/test/test_pdf.birch"
void birch::test_pdf(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>>& _u0960, const birch::type::Integer& N, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "src/test/test_pdf.birch"
  libbirch_function_("test_pdf", "src/test/test_pdf.birch", 41);
  #line 43 "src/test/test_pdf.birch"
  libbirch_line_(43);
  #line 43 "src/test/test_pdf.birch"
  auto from = _u0960->lower(handler_);
  #line 44 "src/test/test_pdf.birch"
  libbirch_line_(44);
  #line 44 "src/test/test_pdf.birch"
  if (!from.query()) {
    #line 45 "src/test/test_pdf.birch"
    libbirch_line_(45);
    #line 45 "src/test/test_pdf.birch"
    from = _u0960->quantile(1.0e-6, handler_);
    #line 46 "src/test/test_pdf.birch"
    libbirch_line_(46);
    #line 46 "src/test/test_pdf.birch"
    libbirch_assert_(from.query());  // GCOV_EXCL_LINE
  }
  #line 50 "src/test/test_pdf.birch"
  libbirch_line_(50);
  #line 50 "src/test/test_pdf.birch"
  auto to = _u0960->upper(handler_);
  #line 51 "src/test/test_pdf.birch"
  libbirch_line_(51);
  #line 51 "src/test/test_pdf.birch"
  if (!to.query()) {
    #line 52 "src/test/test_pdf.birch"
    libbirch_line_(52);
    #line 52 "src/test/test_pdf.birch"
    to = _u0960->quantile(1.0 - 1.0e-6, handler_);
    #line 53 "src/test/test_pdf.birch"
    libbirch_line_(53);
    #line 53 "src/test/test_pdf.birch"
    if (!to.query()) {
      #line 55 "src/test/test_pdf.birch"
      libbirch_line_(55);
      #line 55 "src/test/test_pdf.birch"
      auto u = birch::type::Integer(100);
      #line 56 "src/test/test_pdf.birch"
      libbirch_line_(56);
      #line 56 "src/test/test_pdf.birch"
      while (_u0960->pdf(u, handler_) > 1.0e-6) {
        #line 57 "src/test/test_pdf.birch"
        libbirch_line_(57);
        #line 57 "src/test/test_pdf.birch"
        u = birch::type::Integer(2) * u;
      }
      #line 59 "src/test/test_pdf.birch"
      libbirch_line_(59);
      #line 59 "src/test/test_pdf.birch"
      to = u;
    }
  }
  #line 64 "src/test/test_pdf.birch"
  libbirch_line_(64);
  #line 64 "src/test/test_pdf.birch"
  auto count = birch::vector(birch::type::Integer(0), to.get() - from.get() + birch::type::Integer(1), handler_);
  #line 65 "src/test/test_pdf.birch"
  libbirch_line_(65);
  #line 65 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 66 "src/test/test_pdf.birch"
    libbirch_line_(66);
    #line 66 "src/test/test_pdf.birch"
    auto i = _u0960->simulate(handler_) - from.get() + birch::type::Integer(1);
    #line 67 "src/test/test_pdf.birch"
    libbirch_line_(67);
    #line 67 "src/test/test_pdf.birch"
    if (birch::type::Integer(1) <= i && i <= birch::length(count, handler_)) {
      #line 68 "src/test/test_pdf.birch"
      libbirch_line_(68);
      #line 68 "src/test/test_pdf.birch"
      count.set(libbirch::make_slice(i - 1), count.get(libbirch::make_slice(i - 1)) + birch::type::Integer(1));
    }
  }
  #line 73 "src/test/test_pdf.birch"
  libbirch_line_(73);
  #line 73 "src/test/test_pdf.birch"
  auto failed = false;
  #line 74 "src/test/test_pdf.birch"
  libbirch_line_(74);
  #line 74 "src/test/test_pdf.birch"
  for (auto x = from.get(); x <= to.get(); ++x) {
    #line 75 "src/test/test_pdf.birch"
    libbirch_line_(75);
    #line 75 "src/test/test_pdf.birch"
    auto _u0948 = birch::abs(_u0960->pdf(x, handler_) - birch::Real(count.get(libbirch::make_slice(x - from.get() + birch::type::Integer(1) - 1)), handler_) / N, handler_);
    #line 76 "src/test/test_pdf.birch"
    libbirch_line_(76);
    #line 76 "src/test/test_pdf.birch"
    auto _u0949 = 5.0 / birch::sqrt(birch::Real(N, handler_), handler_);
    #line 77 "src/test/test_pdf.birch"
    libbirch_line_(77);
    #line 77 "src/test/test_pdf.birch"
    if (_u0948 > _u0949) {
      #line 78 "src/test/test_pdf.birch"
      libbirch_line_(78);
      #line 78 "src/test/test_pdf.birch"
      failed = true;
      #line 79 "src/test/test_pdf.birch"
      libbirch_line_(79);
      #line 79 "src/test/test_pdf.birch"
      birch::stderr()->print(birch::type::String("failed on value ") + x + birch::type::String(", ") + _u0948 + birch::type::String(" > ") + _u0949 + birch::type::String("\n"), handler_);
    }
  }
  #line 82 "src/test/test_pdf.birch"
  libbirch_line_(82);
  #line 82 "src/test/test_pdf.birch"
  if (failed) {
    #line 83 "src/test/test_pdf.birch"
    libbirch_line_(83);
    #line 83 "src/test/test_pdf.birch"
    birch::exit(birch::type::Integer(1), handler_);
  }
}

#line 96 "src/test/test_pdf.birch"
void birch::test_pdf(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0960, const birch::type::Integer& D, const birch::type::Integer& N, const birch::type::Integer& B, const birch::type::Integer& S, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 96 "src/test/test_pdf.birch"
  libbirch_function_("test_pdf", "src/test/test_pdf.birch", 96);
  #line 98 "src/test/test_pdf.birch"
  libbirch_line_(98);
  #line 98 "src/test/test_pdf.birch"
  libbirch::DefaultArray<birch::type::Real,2> X1(libbirch::make_shape(N, D));
  #line 99 "src/test/test_pdf.birch"
  libbirch_line_(99);
  #line 99 "src/test/test_pdf.birch"
  libbirch::DefaultArray<birch::type::Real,2> X2(libbirch::make_shape(N, D));
  #line 102 "src/test/test_pdf.birch"
  libbirch_line_(102);
  #line 102 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 103 "src/test/test_pdf.birch"
    libbirch_line_(103);
    #line 103 "src/test/test_pdf.birch"
    X1.set(libbirch::make_slice(n - 1, libbirch::make_range(birch::type::Integer(1) - 1, D - 1)), birch::canonical(_u0960->simulate(handler_), handler_));
  }
  #line 107 "src/test/test_pdf.birch"
  libbirch_line_(107);
  #line 107 "src/test/test_pdf.birch"
  auto _u0956 = birch::vector(0.0, D, handler_);
  #line 108 "src/test/test_pdf.birch"
  libbirch_line_(108);
  #line 108 "src/test/test_pdf.birch"
  auto _u0931 = birch::matrix(0.0, D, D, handler_);
  #line 109 "src/test/test_pdf.birch"
  libbirch_line_(109);
  #line 109 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 110 "src/test/test_pdf.birch"
    libbirch_line_(110);
    #line 110 "src/test/test_pdf.birch"
    auto x = X1.get(libbirch::make_slice(n - 1, libbirch::make_range(birch::type::Integer(1) - 1, D - 1)));
    #line 111 "src/test/test_pdf.birch"
    libbirch_line_(111);
    #line 111 "src/test/test_pdf.birch"
    _u0956 = _u0956 + x;
    #line 112 "src/test/test_pdf.birch"
    libbirch_line_(112);
    #line 112 "src/test/test_pdf.birch"
    _u0931 = _u0931 + birch::outer(x, handler_);
  }
  #line 114 "src/test/test_pdf.birch"
  libbirch_line_(114);
  #line 114 "src/test/test_pdf.birch"
  _u0956 = _u0956 / birch::Real(N, handler_);
  #line 115 "src/test/test_pdf.birch"
  libbirch_line_(115);
  #line 115 "src/test/test_pdf.birch"
  _u0931 = _u0931 / birch::Real(N, handler_) - birch::outer(_u0956, handler_);
  #line 118 "src/test/test_pdf.birch"
  libbirch_line_(118);
  #line 118 "src/test/test_pdf.birch"
  auto done = false;
  #line 119 "src/test/test_pdf.birch"
  libbirch_line_(119);
  #line 119 "src/test/test_pdf.birch"
  do {
    #line 120 "src/test/test_pdf.birch"
    libbirch_line_(120);
    #line 120 "src/test/test_pdf.birch"
    auto a = 0.0;
    #line 121 "src/test/test_pdf.birch"
    libbirch_line_(121);
    #line 121 "src/test/test_pdf.birch"
    auto x = _u0960->simulate(handler_);
    #line 122 "src/test/test_pdf.birch"
    libbirch_line_(122);
    #line 122 "src/test/test_pdf.birch"
    auto l = _u0960->logpdf(x, handler_);
    #line 124 "src/test/test_pdf.birch"
    libbirch_line_(124);
    #line 124 "src/test/test_pdf.birch"
    for (auto n = birch::type::Integer(1); n <= B; ++n) {
      #line 125 "src/test/test_pdf.birch"
      libbirch_line_(125);
      #line 125 "src/test/test_pdf.birch"
      auto x_prime_ = birch::simulate_multivariate_gaussian(x, birch::llt(_u0931, handler_), handler_);
      #line 126 "src/test/test_pdf.birch"
      libbirch_line_(126);
      #line 126 "src/test/test_pdf.birch"
      auto l_prime_ = _u0960->logpdf(x_prime_, handler_);
      #line 127 "src/test/test_pdf.birch"
      libbirch_line_(127);
      #line 127 "src/test/test_pdf.birch"
      if (birch::log(birch::simulate_uniform(0.0, 1.0, handler_), handler_) <= l_prime_ - l) {
        #line 129 "src/test/test_pdf.birch"
        libbirch_line_(129);
        #line 129 "src/test/test_pdf.birch"
        x = x_prime_;
        #line 130 "src/test/test_pdf.birch"
        libbirch_line_(130);
        #line 130 "src/test/test_pdf.birch"
        l = l_prime_;
        #line 131 "src/test/test_pdf.birch"
        libbirch_line_(131);
        #line 131 "src/test/test_pdf.birch"
        a = a + 1.0 / B;
      }
    }
    #line 135 "src/test/test_pdf.birch"
    libbirch_line_(135);
    #line 135 "src/test/test_pdf.birch"
    if (a < 0.2) {
      #line 136 "src/test/test_pdf.birch"
      libbirch_line_(136);
      #line 136 "src/test/test_pdf.birch"
      _u0931 = 0.5 * _u0931;
    } else {
      #line 137 "src/test/test_pdf.birch"
      libbirch_line_(137);
      #line 137 "src/test/test_pdf.birch"
      if (a > 0.4) {
        #line 138 "src/test/test_pdf.birch"
        libbirch_line_(138);
        #line 138 "src/test/test_pdf.birch"
        _u0931 = 1.5 * _u0931;
      } else {
        #line 140 "src/test/test_pdf.birch"
        libbirch_line_(140);
        #line 140 "src/test/test_pdf.birch"
        done = true;
      }
    }
  } while (!done);
  #line 145 "src/test/test_pdf.birch"
  libbirch_line_(145);
  #line 145 "src/test/test_pdf.birch"
  auto a = 0.0;
  #line 146 "src/test/test_pdf.birch"
  libbirch_line_(146);
  #line 146 "src/test/test_pdf.birch"
  auto x = _u0960->simulate(handler_);
  #line 147 "src/test/test_pdf.birch"
  libbirch_line_(147);
  #line 147 "src/test/test_pdf.birch"
  auto l = _u0960->logpdf(x, handler_);
  #line 148 "src/test/test_pdf.birch"
  libbirch_line_(148);
  #line 148 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 149 "src/test/test_pdf.birch"
    libbirch_line_(149);
    #line 149 "src/test/test_pdf.birch"
    for (auto s = birch::type::Integer(1); s <= S; ++s) {
      #line 150 "src/test/test_pdf.birch"
      libbirch_line_(150);
      #line 150 "src/test/test_pdf.birch"
      auto x_prime_ = birch::simulate_multivariate_gaussian(x, birch::llt(_u0931, handler_), handler_);
      #line 151 "src/test/test_pdf.birch"
      libbirch_line_(151);
      #line 151 "src/test/test_pdf.birch"
      auto l_prime_ = _u0960->logpdf(x_prime_, handler_);
      #line 152 "src/test/test_pdf.birch"
      libbirch_line_(152);
      #line 152 "src/test/test_pdf.birch"
      if (birch::log(birch::simulate_uniform(0.0, 1.0, handler_), handler_) <= l_prime_ - l) {
        #line 154 "src/test/test_pdf.birch"
        libbirch_line_(154);
        #line 154 "src/test/test_pdf.birch"
        x = x_prime_;
        #line 155 "src/test/test_pdf.birch"
        libbirch_line_(155);
        #line 155 "src/test/test_pdf.birch"
        l = l_prime_;
        #line 156 "src/test/test_pdf.birch"
        libbirch_line_(156);
        #line 156 "src/test/test_pdf.birch"
        a = a + 1.0 / (N * S);
      }
    }
    #line 159 "src/test/test_pdf.birch"
    libbirch_line_(159);
    #line 159 "src/test/test_pdf.birch"
    X2.set(libbirch::make_slice(n - 1, libbirch::make_range(birch::type::Integer(1) - 1, D - 1)), x);
  }
  #line 164 "src/test/test_pdf.birch"
  libbirch_line_(164);
  #line 164 "src/test/test_pdf.birch"
  if (!birch::pass(X1, X2, handler_)) {
    #line 165 "src/test/test_pdf.birch"
    libbirch_line_(165);
    #line 165 "src/test/test_pdf.birch"
    birch::exit(birch::type::Integer(1), handler_);
  }
}

#line 179 "src/test/test_pdf.birch"
void birch::test_pdf(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>>& _u0960, const birch::type::Integer& R, const birch::type::Integer& C, const birch::type::Integer& N, const birch::type::Integer& B, const birch::type::Integer& S, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 179 "src/test/test_pdf.birch"
  libbirch_function_("test_pdf", "src/test/test_pdf.birch", 179);
  #line 181 "src/test/test_pdf.birch"
  libbirch_line_(181);
  #line 181 "src/test/test_pdf.birch"
  libbirch::DefaultArray<birch::type::Real,2> X1(libbirch::make_shape(N, R * C));
  #line 182 "src/test/test_pdf.birch"
  libbirch_line_(182);
  #line 182 "src/test/test_pdf.birch"
  libbirch::DefaultArray<birch::type::Real,2> X2(libbirch::make_shape(N, R * C));
  #line 185 "src/test/test_pdf.birch"
  libbirch_line_(185);
  #line 185 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 186 "src/test/test_pdf.birch"
    libbirch_line_(186);
    #line 186 "src/test/test_pdf.birch"
    X1.set(libbirch::make_slice(n - 1, libbirch::make_range(birch::type::Integer(1) - 1, R * C - 1)), birch::vec(_u0960->simulate(handler_), handler_));
  }
  #line 190 "src/test/test_pdf.birch"
  libbirch_line_(190);
  #line 190 "src/test/test_pdf.birch"
  auto _u0956 = birch::vector(0.0, R * C, handler_);
  #line 191 "src/test/test_pdf.birch"
  libbirch_line_(191);
  #line 191 "src/test/test_pdf.birch"
  auto _u0931 = birch::matrix(0.0, R * C, R * C, handler_);
  #line 192 "src/test/test_pdf.birch"
  libbirch_line_(192);
  #line 192 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 193 "src/test/test_pdf.birch"
    libbirch_line_(193);
    #line 193 "src/test/test_pdf.birch"
    auto x = X1.get(libbirch::make_slice(n - 1, libbirch::make_range(birch::type::Integer(1) - 1, R * C - 1)));
    #line 194 "src/test/test_pdf.birch"
    libbirch_line_(194);
    #line 194 "src/test/test_pdf.birch"
    _u0956 = _u0956 + x;
    #line 195 "src/test/test_pdf.birch"
    libbirch_line_(195);
    #line 195 "src/test/test_pdf.birch"
    _u0931 = _u0931 + birch::outer(x, handler_);
  }
  #line 197 "src/test/test_pdf.birch"
  libbirch_line_(197);
  #line 197 "src/test/test_pdf.birch"
  _u0956 = _u0956 / birch::Real(N, handler_);
  #line 198 "src/test/test_pdf.birch"
  libbirch_line_(198);
  #line 198 "src/test/test_pdf.birch"
  _u0931 = _u0931 / birch::Real(N, handler_) - birch::outer(_u0956, handler_);
  #line 201 "src/test/test_pdf.birch"
  libbirch_line_(201);
  #line 201 "src/test/test_pdf.birch"
  auto done = false;
  #line 202 "src/test/test_pdf.birch"
  libbirch_line_(202);
  #line 202 "src/test/test_pdf.birch"
  do {
    #line 203 "src/test/test_pdf.birch"
    libbirch_line_(203);
    #line 203 "src/test/test_pdf.birch"
    auto a = 0.0;
    #line 204 "src/test/test_pdf.birch"
    libbirch_line_(204);
    #line 204 "src/test/test_pdf.birch"
    auto x = _u0960->simulate(handler_);
    #line 205 "src/test/test_pdf.birch"
    libbirch_line_(205);
    #line 205 "src/test/test_pdf.birch"
    auto l = _u0960->logpdf(x, handler_);
    #line 207 "src/test/test_pdf.birch"
    libbirch_line_(207);
    #line 207 "src/test/test_pdf.birch"
    for (auto n = birch::type::Integer(1); n <= B; ++n) {
      #line 208 "src/test/test_pdf.birch"
      libbirch_line_(208);
      #line 208 "src/test/test_pdf.birch"
      auto x_prime_ = birch::mat(birch::simulate_multivariate_gaussian(birch::vec(x, handler_), birch::llt(_u0931, handler_), handler_), C, handler_);
      #line 209 "src/test/test_pdf.birch"
      libbirch_line_(209);
      #line 209 "src/test/test_pdf.birch"
      auto l_prime_ = _u0960->logpdf(x_prime_, handler_);
      #line 210 "src/test/test_pdf.birch"
      libbirch_line_(210);
      #line 210 "src/test/test_pdf.birch"
      if (birch::log(birch::simulate_uniform(0.0, 1.0, handler_), handler_) <= l_prime_ - l) {
        #line 212 "src/test/test_pdf.birch"
        libbirch_line_(212);
        #line 212 "src/test/test_pdf.birch"
        x = x_prime_;
        #line 213 "src/test/test_pdf.birch"
        libbirch_line_(213);
        #line 213 "src/test/test_pdf.birch"
        l = l_prime_;
        #line 214 "src/test/test_pdf.birch"
        libbirch_line_(214);
        #line 214 "src/test/test_pdf.birch"
        a = a + 1.0 / B;
      }
    }
    #line 218 "src/test/test_pdf.birch"
    libbirch_line_(218);
    #line 218 "src/test/test_pdf.birch"
    if (a < 0.2) {
      #line 219 "src/test/test_pdf.birch"
      libbirch_line_(219);
      #line 219 "src/test/test_pdf.birch"
      _u0931 = 0.5 * _u0931;
    } else {
      #line 220 "src/test/test_pdf.birch"
      libbirch_line_(220);
      #line 220 "src/test/test_pdf.birch"
      if (a > 0.4) {
        #line 221 "src/test/test_pdf.birch"
        libbirch_line_(221);
        #line 221 "src/test/test_pdf.birch"
        _u0931 = 1.5 * _u0931;
      } else {
        #line 223 "src/test/test_pdf.birch"
        libbirch_line_(223);
        #line 223 "src/test/test_pdf.birch"
        done = true;
      }
    }
  } while (!done);
  #line 228 "src/test/test_pdf.birch"
  libbirch_line_(228);
  #line 228 "src/test/test_pdf.birch"
  auto a = 0.0;
  #line 229 "src/test/test_pdf.birch"
  libbirch_line_(229);
  #line 229 "src/test/test_pdf.birch"
  auto x = _u0960->simulate(handler_);
  #line 230 "src/test/test_pdf.birch"
  libbirch_line_(230);
  #line 230 "src/test/test_pdf.birch"
  auto l = _u0960->logpdf(x, handler_);
  #line 231 "src/test/test_pdf.birch"
  libbirch_line_(231);
  #line 231 "src/test/test_pdf.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 232 "src/test/test_pdf.birch"
    libbirch_line_(232);
    #line 232 "src/test/test_pdf.birch"
    for (auto s = birch::type::Integer(1); s <= S; ++s) {
      #line 233 "src/test/test_pdf.birch"
      libbirch_line_(233);
      #line 233 "src/test/test_pdf.birch"
      auto x_prime_ = birch::mat(birch::simulate_multivariate_gaussian(birch::vec(x, handler_), birch::llt(_u0931, handler_), handler_), C, handler_);
      #line 234 "src/test/test_pdf.birch"
      libbirch_line_(234);
      #line 234 "src/test/test_pdf.birch"
      auto l_prime_ = _u0960->logpdf(x_prime_, handler_);
      #line 235 "src/test/test_pdf.birch"
      libbirch_line_(235);
      #line 235 "src/test/test_pdf.birch"
      if (birch::log(birch::simulate_uniform(0.0, 1.0, handler_), handler_) <= l_prime_ - l) {
        #line 237 "src/test/test_pdf.birch"
        libbirch_line_(237);
        #line 237 "src/test/test_pdf.birch"
        x = x_prime_;
        #line 238 "src/test/test_pdf.birch"
        libbirch_line_(238);
        #line 238 "src/test/test_pdf.birch"
        l = l_prime_;
        #line 239 "src/test/test_pdf.birch"
        libbirch_line_(239);
        #line 239 "src/test/test_pdf.birch"
        a = a + 1.0 / (N * S);
      }
    }
    #line 242 "src/test/test_pdf.birch"
    libbirch_line_(242);
    #line 242 "src/test/test_pdf.birch"
    X2.set(libbirch::make_slice(n - 1, libbirch::make_range(birch::type::Integer(1) - 1, R * C - 1)), birch::vec(x, handler_));
  }
  #line 247 "src/test/test_pdf.birch"
  libbirch_line_(247);
  #line 247 "src/test/test_pdf.birch"
  if (!birch::pass(X1, X2, handler_)) {
    #line 248 "src/test/test_pdf.birch"
    libbirch_line_(248);
    #line 248 "src/test/test_pdf.birch"
    birch::exit(birch::type::Integer(1), handler_);
  }
}

