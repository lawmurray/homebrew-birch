#line 9 "src/basic/Boolean.birch"
birch::type::Boolean birch::Boolean(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/basic/Boolean.birch"
  libbirch_function_("Boolean", "src/basic/Boolean.birch", 9);
  #line 10 "src/basic/Boolean.birch"
  libbirch_line_(10);
  #line 10 "src/basic/Boolean.birch"
  return x;
}

#line 16 "src/basic/Boolean.birch"
birch::type::Boolean birch::Boolean(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/basic/Boolean.birch"
  libbirch_function_("Boolean", "src/basic/Boolean.birch", 16);
  #line 17 "src/basic/Boolean.birch"
  libbirch_line_(17);
  #line 17 "src/basic/Boolean.birch"
  return x == birch::type::String("true");
}

#line 23 "src/basic/Boolean.birch"
libbirch::Optional<birch::type::Boolean> birch::Boolean(const libbirch::Optional<birch::type::Boolean>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "src/basic/Boolean.birch"
  libbirch_function_("Boolean", "src/basic/Boolean.birch", 23);
  #line 24 "src/basic/Boolean.birch"
  libbirch_line_(24);
  #line 24 "src/basic/Boolean.birch"
  return x;
}

#line 30 "src/basic/Boolean.birch"
libbirch::Optional<birch::type::Boolean> birch::Boolean(const libbirch::Optional<birch::type::String>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/basic/Boolean.birch"
  libbirch_function_("Boolean", "src/basic/Boolean.birch", 30);
  #line 31 "src/basic/Boolean.birch"
  libbirch_line_(31);
  #line 31 "src/basic/Boolean.birch"
  if (x.query()) {
    #line 32 "src/basic/Boolean.birch"
    libbirch_line_(32);
    #line 32 "src/basic/Boolean.birch"
    return birch::Boolean(x.get(), handler_);
  } else {
    #line 34 "src/basic/Boolean.birch"
    libbirch_line_(34);
    #line 34 "src/basic/Boolean.birch"
    return libbirch::nil;
  }
}

#line 52 "src/basic/Boolean.birch"
birch::type::Boolean birch::max(const birch::type::Boolean& x, const birch::type::Boolean& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "src/basic/Boolean.birch"
  libbirch_function_("max", "src/basic/Boolean.birch", 52);
  #line 53 "src/basic/Boolean.birch"
  libbirch_line_(53);
  #line 53 "src/basic/Boolean.birch"
  return x || y;
}

#line 59 "src/basic/Boolean.birch"
birch::type::Boolean birch::min(const birch::type::Boolean& x, const birch::type::Boolean& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/basic/Boolean.birch"
  libbirch_function_("min", "src/basic/Boolean.birch", 59);
  #line 60 "src/basic/Boolean.birch"
  libbirch_line_(60);
  #line 60 "src/basic/Boolean.birch"
  return x && y;
}

#line 9 "src/basic/Integer.birch"
birch::type::Integer birch::Integer(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/basic/Integer.birch"
  libbirch_function_("Integer", "src/basic/Integer.birch", 9);
  #line 10 "src/basic/Integer.birch"
  libbirch_line_(10);
  #line 10 "src/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 16 "src/basic/Integer.birch"
birch::type::Integer birch::Integer(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/basic/Integer.birch"
  libbirch_function_("Integer", "src/basic/Integer.birch", 16);
  #line 17 "src/basic/Integer.birch"
  libbirch_line_(17);
  #line 17 "src/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 23 "src/basic/Integer.birch"
birch::type::Integer birch::Integer(const birch::type::Integer64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "src/basic/Integer.birch"
  libbirch_function_("Integer", "src/basic/Integer.birch", 23);
  #line 24 "src/basic/Integer.birch"
  libbirch_line_(24);
  #line 24 "src/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 30 "src/basic/Integer.birch"
birch::type::Integer birch::Integer(const birch::type::Integer32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/basic/Integer.birch"
  libbirch_function_("Integer", "src/basic/Integer.birch", 30);
  #line 31 "src/basic/Integer.birch"
  libbirch_line_(31);
  #line 31 "src/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 37 "src/basic/Integer.birch"
birch::type::Integer birch::Integer(const birch::type::Integer16& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/basic/Integer.birch"
  libbirch_function_("Integer", "src/basic/Integer.birch", 37);
  #line 38 "src/basic/Integer.birch"
  libbirch_line_(38);
  #line 38 "src/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 44 "src/basic/Integer.birch"
birch::type::Integer birch::Integer(const birch::type::Integer8& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/basic/Integer.birch"
  libbirch_function_("Integer", "src/basic/Integer.birch", 44);
  #line 45 "src/basic/Integer.birch"
  libbirch_line_(45);
  #line 45 "src/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 51 "src/basic/Integer.birch"
birch::type::Integer birch::Integer(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 51 "src/basic/Integer.birch"
  libbirch_function_("Integer", "src/basic/Integer.birch", 51);
  #line 52 "src/basic/Integer.birch"
  libbirch_line_(52);
  #line 52 "src/basic/Integer.birch"
  if (x) {
    #line 53 "src/basic/Integer.birch"
    libbirch_line_(53);
    #line 53 "src/basic/Integer.birch"
    return birch::Integer(birch::type::Integer(1), handler_);
  } else {
    #line 55 "src/basic/Integer.birch"
    libbirch_line_(55);
    #line 55 "src/basic/Integer.birch"
    return birch::Integer(birch::type::Integer(0), handler_);
  }
}

#line 62 "src/basic/Integer.birch"
birch::type::Integer birch::Integer(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 62 "src/basic/Integer.birch"
  libbirch_function_("Integer", "src/basic/Integer.birch", 62);
  #line 63 "src/basic/Integer.birch"
  libbirch_line_(63);
  #line 63 "src/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 69 "src/basic/Integer.birch"
libbirch::Optional<birch::type::Integer> birch::Integer(const libbirch::Optional<birch::type::Real64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "src/basic/Integer.birch"
  libbirch_function_("Integer", "src/basic/Integer.birch", 69);
  #line 70 "src/basic/Integer.birch"
  libbirch_line_(70);
  #line 70 "src/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 76 "src/basic/Integer.birch"
libbirch::Optional<birch::type::Integer> birch::Integer(const libbirch::Optional<birch::type::Real32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "src/basic/Integer.birch"
  libbirch_function_("Integer", "src/basic/Integer.birch", 76);
  #line 77 "src/basic/Integer.birch"
  libbirch_line_(77);
  #line 77 "src/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 83 "src/basic/Integer.birch"
libbirch::Optional<birch::type::Integer> birch::Integer(const libbirch::Optional<birch::type::Integer64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 83 "src/basic/Integer.birch"
  libbirch_function_("Integer", "src/basic/Integer.birch", 83);
  #line 84 "src/basic/Integer.birch"
  libbirch_line_(84);
  #line 84 "src/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 90 "src/basic/Integer.birch"
libbirch::Optional<birch::type::Integer> birch::Integer(const libbirch::Optional<birch::type::Integer32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 90 "src/basic/Integer.birch"
  libbirch_function_("Integer", "src/basic/Integer.birch", 90);
  #line 91 "src/basic/Integer.birch"
  libbirch_line_(91);
  #line 91 "src/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 97 "src/basic/Integer.birch"
libbirch::Optional<birch::type::Integer> birch::Integer(const libbirch::Optional<birch::type::Integer16>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 97 "src/basic/Integer.birch"
  libbirch_function_("Integer", "src/basic/Integer.birch", 97);
  #line 98 "src/basic/Integer.birch"
  libbirch_line_(98);
  #line 98 "src/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 104 "src/basic/Integer.birch"
libbirch::Optional<birch::type::Integer> birch::Integer(const libbirch::Optional<birch::type::Integer8>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 104 "src/basic/Integer.birch"
  libbirch_function_("Integer", "src/basic/Integer.birch", 104);
  #line 105 "src/basic/Integer.birch"
  libbirch_line_(105);
  #line 105 "src/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 111 "src/basic/Integer.birch"
libbirch::Optional<birch::type::Integer> birch::Integer(const libbirch::Optional<birch::type::String>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 111 "src/basic/Integer.birch"
  libbirch_function_("Integer", "src/basic/Integer.birch", 111);
  #line 112 "src/basic/Integer.birch"
  libbirch_line_(112);
  #line 112 "src/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 9 "src/basic/Integer8.birch"
birch::type::Integer8 birch::Integer8(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/basic/Integer8.birch"
  libbirch_function_("Integer8", "src/basic/Integer8.birch", 9);
  #line 10 "src/basic/Integer8.birch"
return static_cast<birch::type::Integer8>(x);
  }

#line 18 "src/basic/Integer8.birch"
birch::type::Integer8 birch::Integer8(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/basic/Integer8.birch"
  libbirch_function_("Integer8", "src/basic/Integer8.birch", 18);
  #line 19 "src/basic/Integer8.birch"
return static_cast<birch::type::Integer8>(x);
  }

#line 27 "src/basic/Integer8.birch"
birch::type::Integer8 birch::Integer8(const birch::type::Integer64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/basic/Integer8.birch"
  libbirch_function_("Integer8", "src/basic/Integer8.birch", 27);
  #line 28 "src/basic/Integer8.birch"
return static_cast<birch::type::Integer8>(x);
  }

#line 36 "src/basic/Integer8.birch"
birch::type::Integer8 birch::Integer8(const birch::type::Integer32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/basic/Integer8.birch"
  libbirch_function_("Integer8", "src/basic/Integer8.birch", 36);
  #line 37 "src/basic/Integer8.birch"
return static_cast<birch::type::Integer8>(x);
  }

#line 45 "src/basic/Integer8.birch"
birch::type::Integer8 birch::Integer8(const birch::type::Integer16& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "src/basic/Integer8.birch"
  libbirch_function_("Integer8", "src/basic/Integer8.birch", 45);
  #line 46 "src/basic/Integer8.birch"
return static_cast<birch::type::Integer8>(x);
  }

#line 54 "src/basic/Integer8.birch"
birch::type::Integer8 birch::Integer8(const birch::type::Integer8& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "src/basic/Integer8.birch"
  libbirch_function_("Integer8", "src/basic/Integer8.birch", 54);
  #line 55 "src/basic/Integer8.birch"
  libbirch_line_(55);
  #line 55 "src/basic/Integer8.birch"
  return x;
}

#line 61 "src/basic/Integer8.birch"
birch::type::Integer8 birch::Integer8(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "src/basic/Integer8.birch"
  libbirch_function_("Integer8", "src/basic/Integer8.birch", 61);
  #line 62 "src/basic/Integer8.birch"
  libbirch_line_(62);
  #line 62 "src/basic/Integer8.birch"
  if (x) {
    #line 63 "src/basic/Integer8.birch"
    libbirch_line_(63);
    #line 63 "src/basic/Integer8.birch"
    return birch::Integer8(birch::type::Integer(1), handler_);
  } else {
    #line 65 "src/basic/Integer8.birch"
    libbirch_line_(65);
    #line 65 "src/basic/Integer8.birch"
    return birch::Integer8(birch::type::Integer(0), handler_);
  }
}

#line 72 "src/basic/Integer8.birch"
birch::type::Integer8 birch::Integer8(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "src/basic/Integer8.birch"
  libbirch_function_("Integer8", "src/basic/Integer8.birch", 72);
  #line 73 "src/basic/Integer8.birch"
return ::atoi(x.c_str());
  }

#line 81 "src/basic/Integer8.birch"
libbirch::Optional<birch::type::Integer8> birch::Integer8(const libbirch::Optional<birch::type::Real64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "src/basic/Integer8.birch"
  libbirch_function_("Integer8", "src/basic/Integer8.birch", 81);
  #line 82 "src/basic/Integer8.birch"
  libbirch_line_(82);
  #line 82 "src/basic/Integer8.birch"
  if (x.query()) {
    #line 83 "src/basic/Integer8.birch"
    libbirch_line_(83);
    #line 83 "src/basic/Integer8.birch"
    return birch::Integer8(x.get(), handler_);
  } else {
    #line 85 "src/basic/Integer8.birch"
    libbirch_line_(85);
    #line 85 "src/basic/Integer8.birch"
    return libbirch::nil;
  }
}

#line 92 "src/basic/Integer8.birch"
libbirch::Optional<birch::type::Integer8> birch::Integer8(const libbirch::Optional<birch::type::Real32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 92 "src/basic/Integer8.birch"
  libbirch_function_("Integer8", "src/basic/Integer8.birch", 92);
  #line 93 "src/basic/Integer8.birch"
  libbirch_line_(93);
  #line 93 "src/basic/Integer8.birch"
  if (x.query()) {
    #line 94 "src/basic/Integer8.birch"
    libbirch_line_(94);
    #line 94 "src/basic/Integer8.birch"
    return birch::Integer8(x.get(), handler_);
  } else {
    #line 96 "src/basic/Integer8.birch"
    libbirch_line_(96);
    #line 96 "src/basic/Integer8.birch"
    return libbirch::nil;
  }
}

#line 103 "src/basic/Integer8.birch"
libbirch::Optional<birch::type::Integer8> birch::Integer8(const libbirch::Optional<birch::type::Integer64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 103 "src/basic/Integer8.birch"
  libbirch_function_("Integer8", "src/basic/Integer8.birch", 103);
  #line 104 "src/basic/Integer8.birch"
  libbirch_line_(104);
  #line 104 "src/basic/Integer8.birch"
  if (x.query()) {
    #line 105 "src/basic/Integer8.birch"
    libbirch_line_(105);
    #line 105 "src/basic/Integer8.birch"
    return birch::Integer8(x.get(), handler_);
  } else {
    #line 107 "src/basic/Integer8.birch"
    libbirch_line_(107);
    #line 107 "src/basic/Integer8.birch"
    return libbirch::nil;
  }
}

#line 114 "src/basic/Integer8.birch"
libbirch::Optional<birch::type::Integer8> birch::Integer8(const libbirch::Optional<birch::type::Integer32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 114 "src/basic/Integer8.birch"
  libbirch_function_("Integer8", "src/basic/Integer8.birch", 114);
  #line 115 "src/basic/Integer8.birch"
  libbirch_line_(115);
  #line 115 "src/basic/Integer8.birch"
  if (x.query()) {
    #line 116 "src/basic/Integer8.birch"
    libbirch_line_(116);
    #line 116 "src/basic/Integer8.birch"
    return birch::Integer8(x.get(), handler_);
  } else {
    #line 118 "src/basic/Integer8.birch"
    libbirch_line_(118);
    #line 118 "src/basic/Integer8.birch"
    return libbirch::nil;
  }
}

#line 125 "src/basic/Integer8.birch"
libbirch::Optional<birch::type::Integer8> birch::Integer8(const libbirch::Optional<birch::type::Integer16>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 125 "src/basic/Integer8.birch"
  libbirch_function_("Integer8", "src/basic/Integer8.birch", 125);
  #line 126 "src/basic/Integer8.birch"
  libbirch_line_(126);
  #line 126 "src/basic/Integer8.birch"
  if (x.query()) {
    #line 127 "src/basic/Integer8.birch"
    libbirch_line_(127);
    #line 127 "src/basic/Integer8.birch"
    return birch::Integer8(x.get(), handler_);
  } else {
    #line 129 "src/basic/Integer8.birch"
    libbirch_line_(129);
    #line 129 "src/basic/Integer8.birch"
    return libbirch::nil;
  }
}

#line 136 "src/basic/Integer8.birch"
libbirch::Optional<birch::type::Integer8> birch::Integer8(const libbirch::Optional<birch::type::Integer8>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 136 "src/basic/Integer8.birch"
  libbirch_function_("Integer8", "src/basic/Integer8.birch", 136);
  #line 137 "src/basic/Integer8.birch"
  libbirch_line_(137);
  #line 137 "src/basic/Integer8.birch"
  return x;
}

#line 143 "src/basic/Integer8.birch"
libbirch::Optional<birch::type::Integer8> birch::Integer8(const libbirch::Optional<birch::type::String>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 143 "src/basic/Integer8.birch"
  libbirch_function_("Integer8", "src/basic/Integer8.birch", 143);
  #line 144 "src/basic/Integer8.birch"
  libbirch_line_(144);
  #line 144 "src/basic/Integer8.birch"
  if (x.query()) {
    #line 145 "src/basic/Integer8.birch"
    libbirch_line_(145);
    #line 145 "src/basic/Integer8.birch"
    return birch::Integer8(x.get(), handler_);
  } else {
    #line 147 "src/basic/Integer8.birch"
    libbirch_line_(147);
    #line 147 "src/basic/Integer8.birch"
    return libbirch::nil;
  }
}

#line 170 "src/basic/Integer8.birch"
birch::type::Integer8 birch::abs(const birch::type::Integer8& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 170 "src/basic/Integer8.birch"
  libbirch_function_("abs", "src/basic/Integer8.birch", 170);
  #line 171 "src/basic/Integer8.birch"
return std::abs(x);
  }

#line 179 "src/basic/Integer8.birch"
birch::type::Integer8 birch::pow(const birch::type::Integer8& x, const birch::type::Integer8& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 179 "src/basic/Integer8.birch"
  libbirch_function_("pow", "src/basic/Integer8.birch", 179);
  #line 180 "src/basic/Integer8.birch"
return std::pow(x, y);
  }

#line 188 "src/basic/Integer8.birch"
birch::type::Integer8 birch::mod(const birch::type::Integer8& x, const birch::type::Integer8& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 188 "src/basic/Integer8.birch"
  libbirch_function_("mod", "src/basic/Integer8.birch", 188);
  #line 189 "src/basic/Integer8.birch"
return x % y;
  }

#line 197 "src/basic/Integer8.birch"
birch::type::Integer8 birch::max(const birch::type::Integer8& x, const birch::type::Integer8& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 197 "src/basic/Integer8.birch"
  libbirch_function_("max", "src/basic/Integer8.birch", 197);
  #line 198 "src/basic/Integer8.birch"
return std::max(x, y);
  }

#line 206 "src/basic/Integer8.birch"
birch::type::Integer8 birch::min(const birch::type::Integer8& x, const birch::type::Integer8& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 206 "src/basic/Integer8.birch"
  libbirch_function_("min", "src/basic/Integer8.birch", 206);
  #line 207 "src/basic/Integer8.birch"
return std::min(x, y);
  }

#line 9 "src/basic/Integer16.birch"
birch::type::Integer16 birch::Integer16(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/basic/Integer16.birch"
  libbirch_function_("Integer16", "src/basic/Integer16.birch", 9);
  #line 10 "src/basic/Integer16.birch"
return static_cast<birch::type::Integer16>(x);
  }

#line 18 "src/basic/Integer16.birch"
birch::type::Integer16 birch::Integer16(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/basic/Integer16.birch"
  libbirch_function_("Integer16", "src/basic/Integer16.birch", 18);
  #line 19 "src/basic/Integer16.birch"
return static_cast<birch::type::Integer16>(x);
  }

#line 27 "src/basic/Integer16.birch"
birch::type::Integer16 birch::Integer16(const birch::type::Integer64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/basic/Integer16.birch"
  libbirch_function_("Integer16", "src/basic/Integer16.birch", 27);
  #line 28 "src/basic/Integer16.birch"
return static_cast<birch::type::Integer16>(x);
  }

#line 36 "src/basic/Integer16.birch"
birch::type::Integer16 birch::Integer16(const birch::type::Integer32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/basic/Integer16.birch"
  libbirch_function_("Integer16", "src/basic/Integer16.birch", 36);
  #line 37 "src/basic/Integer16.birch"
return static_cast<birch::type::Integer16>(x);
  }

#line 45 "src/basic/Integer16.birch"
birch::type::Integer16 birch::Integer16(const birch::type::Integer16& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "src/basic/Integer16.birch"
  libbirch_function_("Integer16", "src/basic/Integer16.birch", 45);
  #line 46 "src/basic/Integer16.birch"
  libbirch_line_(46);
  #line 46 "src/basic/Integer16.birch"
  return x;
}

#line 52 "src/basic/Integer16.birch"
birch::type::Integer16 birch::Integer16(const birch::type::Integer8& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "src/basic/Integer16.birch"
  libbirch_function_("Integer16", "src/basic/Integer16.birch", 52);
  #line 53 "src/basic/Integer16.birch"
return static_cast<birch::type::Integer8>(x);
  }

#line 61 "src/basic/Integer16.birch"
birch::type::Integer16 birch::Integer16(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "src/basic/Integer16.birch"
  libbirch_function_("Integer16", "src/basic/Integer16.birch", 61);
  #line 62 "src/basic/Integer16.birch"
  libbirch_line_(62);
  #line 62 "src/basic/Integer16.birch"
  if (x) {
    #line 63 "src/basic/Integer16.birch"
    libbirch_line_(63);
    #line 63 "src/basic/Integer16.birch"
    return birch::Integer16(birch::type::Integer(1), handler_);
  } else {
    #line 65 "src/basic/Integer16.birch"
    libbirch_line_(65);
    #line 65 "src/basic/Integer16.birch"
    return birch::Integer16(birch::type::Integer(0), handler_);
  }
}

#line 72 "src/basic/Integer16.birch"
birch::type::Integer16 birch::Integer16(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "src/basic/Integer16.birch"
  libbirch_function_("Integer16", "src/basic/Integer16.birch", 72);
  #line 73 "src/basic/Integer16.birch"
return ::atoi(x.c_str());
  }

#line 81 "src/basic/Integer16.birch"
libbirch::Optional<birch::type::Integer16> birch::Integer16(const libbirch::Optional<birch::type::Real64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "src/basic/Integer16.birch"
  libbirch_function_("Integer16", "src/basic/Integer16.birch", 81);
  #line 82 "src/basic/Integer16.birch"
  libbirch_line_(82);
  #line 82 "src/basic/Integer16.birch"
  if (x.query()) {
    #line 83 "src/basic/Integer16.birch"
    libbirch_line_(83);
    #line 83 "src/basic/Integer16.birch"
    return birch::Integer16(x.get(), handler_);
  } else {
    #line 85 "src/basic/Integer16.birch"
    libbirch_line_(85);
    #line 85 "src/basic/Integer16.birch"
    return libbirch::nil;
  }
}

#line 92 "src/basic/Integer16.birch"
libbirch::Optional<birch::type::Integer16> birch::Integer16(const libbirch::Optional<birch::type::Real32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 92 "src/basic/Integer16.birch"
  libbirch_function_("Integer16", "src/basic/Integer16.birch", 92);
  #line 93 "src/basic/Integer16.birch"
  libbirch_line_(93);
  #line 93 "src/basic/Integer16.birch"
  if (x.query()) {
    #line 94 "src/basic/Integer16.birch"
    libbirch_line_(94);
    #line 94 "src/basic/Integer16.birch"
    return birch::Integer16(x.get(), handler_);
  } else {
    #line 96 "src/basic/Integer16.birch"
    libbirch_line_(96);
    #line 96 "src/basic/Integer16.birch"
    return libbirch::nil;
  }
}

#line 103 "src/basic/Integer16.birch"
libbirch::Optional<birch::type::Integer16> birch::Integer16(const libbirch::Optional<birch::type::Integer64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 103 "src/basic/Integer16.birch"
  libbirch_function_("Integer16", "src/basic/Integer16.birch", 103);
  #line 104 "src/basic/Integer16.birch"
  libbirch_line_(104);
  #line 104 "src/basic/Integer16.birch"
  if (x.query()) {
    #line 105 "src/basic/Integer16.birch"
    libbirch_line_(105);
    #line 105 "src/basic/Integer16.birch"
    return birch::Integer16(x.get(), handler_);
  } else {
    #line 107 "src/basic/Integer16.birch"
    libbirch_line_(107);
    #line 107 "src/basic/Integer16.birch"
    return libbirch::nil;
  }
}

#line 114 "src/basic/Integer16.birch"
libbirch::Optional<birch::type::Integer16> birch::Integer16(const libbirch::Optional<birch::type::Integer32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 114 "src/basic/Integer16.birch"
  libbirch_function_("Integer16", "src/basic/Integer16.birch", 114);
  #line 115 "src/basic/Integer16.birch"
  libbirch_line_(115);
  #line 115 "src/basic/Integer16.birch"
  if (x.query()) {
    #line 116 "src/basic/Integer16.birch"
    libbirch_line_(116);
    #line 116 "src/basic/Integer16.birch"
    return birch::Integer16(x.get(), handler_);
  } else {
    #line 118 "src/basic/Integer16.birch"
    libbirch_line_(118);
    #line 118 "src/basic/Integer16.birch"
    return libbirch::nil;
  }
}

#line 125 "src/basic/Integer16.birch"
libbirch::Optional<birch::type::Integer16> birch::Integer16(const libbirch::Optional<birch::type::Integer16>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 125 "src/basic/Integer16.birch"
  libbirch_function_("Integer16", "src/basic/Integer16.birch", 125);
  #line 126 "src/basic/Integer16.birch"
  libbirch_line_(126);
  #line 126 "src/basic/Integer16.birch"
  return x;
}

#line 132 "src/basic/Integer16.birch"
libbirch::Optional<birch::type::Integer16> birch::Integer16(const libbirch::Optional<birch::type::Integer8>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 132 "src/basic/Integer16.birch"
  libbirch_function_("Integer16", "src/basic/Integer16.birch", 132);
  #line 133 "src/basic/Integer16.birch"
  libbirch_line_(133);
  #line 133 "src/basic/Integer16.birch"
  if (x.query()) {
    #line 134 "src/basic/Integer16.birch"
    libbirch_line_(134);
    #line 134 "src/basic/Integer16.birch"
    return birch::Integer16(x.get(), handler_);
  } else {
    #line 136 "src/basic/Integer16.birch"
    libbirch_line_(136);
    #line 136 "src/basic/Integer16.birch"
    return libbirch::nil;
  }
}

#line 143 "src/basic/Integer16.birch"
libbirch::Optional<birch::type::Integer16> birch::Integer16(const libbirch::Optional<birch::type::String>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 143 "src/basic/Integer16.birch"
  libbirch_function_("Integer16", "src/basic/Integer16.birch", 143);
  #line 144 "src/basic/Integer16.birch"
  libbirch_line_(144);
  #line 144 "src/basic/Integer16.birch"
  if (x.query()) {
    #line 145 "src/basic/Integer16.birch"
    libbirch_line_(145);
    #line 145 "src/basic/Integer16.birch"
    return birch::Integer16(x.get(), handler_);
  } else {
    #line 147 "src/basic/Integer16.birch"
    libbirch_line_(147);
    #line 147 "src/basic/Integer16.birch"
    return libbirch::nil;
  }
}

#line 170 "src/basic/Integer16.birch"
birch::type::Integer16 birch::abs(const birch::type::Integer16& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 170 "src/basic/Integer16.birch"
  libbirch_function_("abs", "src/basic/Integer16.birch", 170);
  #line 171 "src/basic/Integer16.birch"
return std::abs(x);
  }

#line 179 "src/basic/Integer16.birch"
birch::type::Integer16 birch::pow(const birch::type::Integer16& x, const birch::type::Integer16& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 179 "src/basic/Integer16.birch"
  libbirch_function_("pow", "src/basic/Integer16.birch", 179);
  #line 180 "src/basic/Integer16.birch"
return std::pow(x, y);
  }

#line 188 "src/basic/Integer16.birch"
birch::type::Integer16 birch::mod(const birch::type::Integer16& x, const birch::type::Integer16& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 188 "src/basic/Integer16.birch"
  libbirch_function_("mod", "src/basic/Integer16.birch", 188);
  #line 189 "src/basic/Integer16.birch"
return x % y;
  }

#line 197 "src/basic/Integer16.birch"
birch::type::Integer16 birch::max(const birch::type::Integer16& x, const birch::type::Integer16& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 197 "src/basic/Integer16.birch"
  libbirch_function_("max", "src/basic/Integer16.birch", 197);
  #line 198 "src/basic/Integer16.birch"
return std::max(x, y);
  }

#line 206 "src/basic/Integer16.birch"
birch::type::Integer16 birch::min(const birch::type::Integer16& x, const birch::type::Integer16& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 206 "src/basic/Integer16.birch"
  libbirch_function_("min", "src/basic/Integer16.birch", 206);
  #line 207 "src/basic/Integer16.birch"
return std::min(x, y);
  }

#line 9 "src/basic/Integer32.birch"
birch::type::Integer32 birch::Integer32(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/basic/Integer32.birch"
  libbirch_function_("Integer32", "src/basic/Integer32.birch", 9);
  #line 10 "src/basic/Integer32.birch"
return static_cast<birch::type::Integer32>(x);
  }

#line 18 "src/basic/Integer32.birch"
birch::type::Integer32 birch::Integer32(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/basic/Integer32.birch"
  libbirch_function_("Integer32", "src/basic/Integer32.birch", 18);
  #line 19 "src/basic/Integer32.birch"
return static_cast<birch::type::Integer32>(x);
  }

#line 27 "src/basic/Integer32.birch"
birch::type::Integer32 birch::Integer32(const birch::type::Integer64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/basic/Integer32.birch"
  libbirch_function_("Integer32", "src/basic/Integer32.birch", 27);
  #line 28 "src/basic/Integer32.birch"
return static_cast<birch::type::Integer32>(x);
  }

#line 36 "src/basic/Integer32.birch"
birch::type::Integer32 birch::Integer32(const birch::type::Integer32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/basic/Integer32.birch"
  libbirch_function_("Integer32", "src/basic/Integer32.birch", 36);
  #line 37 "src/basic/Integer32.birch"
  libbirch_line_(37);
  #line 37 "src/basic/Integer32.birch"
  return x;
}

#line 43 "src/basic/Integer32.birch"
birch::type::Integer32 birch::Integer32(const birch::type::Integer16& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "src/basic/Integer32.birch"
  libbirch_function_("Integer32", "src/basic/Integer32.birch", 43);
  #line 44 "src/basic/Integer32.birch"
return static_cast<birch::type::Integer32>(x);
  }

#line 52 "src/basic/Integer32.birch"
birch::type::Integer32 birch::Integer32(const birch::type::Integer8& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "src/basic/Integer32.birch"
  libbirch_function_("Integer32", "src/basic/Integer32.birch", 52);
  #line 53 "src/basic/Integer32.birch"
return static_cast<birch::type::Integer32>(x);
  }

#line 61 "src/basic/Integer32.birch"
birch::type::Integer32 birch::Integer32(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "src/basic/Integer32.birch"
  libbirch_function_("Integer32", "src/basic/Integer32.birch", 61);
  #line 62 "src/basic/Integer32.birch"
  libbirch_line_(62);
  #line 62 "src/basic/Integer32.birch"
  if (x) {
    #line 63 "src/basic/Integer32.birch"
    libbirch_line_(63);
    #line 63 "src/basic/Integer32.birch"
    return birch::Integer32(birch::type::Integer(1), handler_);
  } else {
    #line 65 "src/basic/Integer32.birch"
    libbirch_line_(65);
    #line 65 "src/basic/Integer32.birch"
    return birch::Integer32(birch::type::Integer(0), handler_);
  }
}

#line 72 "src/basic/Integer32.birch"
birch::type::Integer32 birch::Integer32(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "src/basic/Integer32.birch"
  libbirch_function_("Integer32", "src/basic/Integer32.birch", 72);
  #line 73 "src/basic/Integer32.birch"
return ::atoi(x.c_str());
  }

#line 81 "src/basic/Integer32.birch"
libbirch::Optional<birch::type::Integer32> birch::Integer32(const libbirch::Optional<birch::type::Real64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "src/basic/Integer32.birch"
  libbirch_function_("Integer32", "src/basic/Integer32.birch", 81);
  #line 82 "src/basic/Integer32.birch"
  libbirch_line_(82);
  #line 82 "src/basic/Integer32.birch"
  if (x.query()) {
    #line 83 "src/basic/Integer32.birch"
    libbirch_line_(83);
    #line 83 "src/basic/Integer32.birch"
    return birch::Integer32(x.get(), handler_);
  } else {
    #line 85 "src/basic/Integer32.birch"
    libbirch_line_(85);
    #line 85 "src/basic/Integer32.birch"
    return libbirch::nil;
  }
}

#line 92 "src/basic/Integer32.birch"
libbirch::Optional<birch::type::Integer32> birch::Integer32(const libbirch::Optional<birch::type::Real32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 92 "src/basic/Integer32.birch"
  libbirch_function_("Integer32", "src/basic/Integer32.birch", 92);
  #line 93 "src/basic/Integer32.birch"
  libbirch_line_(93);
  #line 93 "src/basic/Integer32.birch"
  if (x.query()) {
    #line 94 "src/basic/Integer32.birch"
    libbirch_line_(94);
    #line 94 "src/basic/Integer32.birch"
    return birch::Integer32(x.get(), handler_);
  } else {
    #line 96 "src/basic/Integer32.birch"
    libbirch_line_(96);
    #line 96 "src/basic/Integer32.birch"
    return libbirch::nil;
  }
}

#line 103 "src/basic/Integer32.birch"
libbirch::Optional<birch::type::Integer32> birch::Integer32(const libbirch::Optional<birch::type::Integer64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 103 "src/basic/Integer32.birch"
  libbirch_function_("Integer32", "src/basic/Integer32.birch", 103);
  #line 104 "src/basic/Integer32.birch"
  libbirch_line_(104);
  #line 104 "src/basic/Integer32.birch"
  if (x.query()) {
    #line 105 "src/basic/Integer32.birch"
    libbirch_line_(105);
    #line 105 "src/basic/Integer32.birch"
    return birch::Integer32(x.get(), handler_);
  } else {
    #line 107 "src/basic/Integer32.birch"
    libbirch_line_(107);
    #line 107 "src/basic/Integer32.birch"
    return libbirch::nil;
  }
}

#line 114 "src/basic/Integer32.birch"
libbirch::Optional<birch::type::Integer32> birch::Integer32(const libbirch::Optional<birch::type::Integer32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 114 "src/basic/Integer32.birch"
  libbirch_function_("Integer32", "src/basic/Integer32.birch", 114);
  #line 115 "src/basic/Integer32.birch"
  libbirch_line_(115);
  #line 115 "src/basic/Integer32.birch"
  return x;
}

#line 121 "src/basic/Integer32.birch"
libbirch::Optional<birch::type::Integer32> birch::Integer32(const libbirch::Optional<birch::type::Integer16>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 121 "src/basic/Integer32.birch"
  libbirch_function_("Integer32", "src/basic/Integer32.birch", 121);
  #line 122 "src/basic/Integer32.birch"
  libbirch_line_(122);
  #line 122 "src/basic/Integer32.birch"
  if (x.query()) {
    #line 123 "src/basic/Integer32.birch"
    libbirch_line_(123);
    #line 123 "src/basic/Integer32.birch"
    return birch::Integer32(x.get(), handler_);
  } else {
    #line 125 "src/basic/Integer32.birch"
    libbirch_line_(125);
    #line 125 "src/basic/Integer32.birch"
    return libbirch::nil;
  }
}

#line 132 "src/basic/Integer32.birch"
libbirch::Optional<birch::type::Integer32> birch::Integer32(const libbirch::Optional<birch::type::Integer8>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 132 "src/basic/Integer32.birch"
  libbirch_function_("Integer32", "src/basic/Integer32.birch", 132);
  #line 133 "src/basic/Integer32.birch"
  libbirch_line_(133);
  #line 133 "src/basic/Integer32.birch"
  if (x.query()) {
    #line 134 "src/basic/Integer32.birch"
    libbirch_line_(134);
    #line 134 "src/basic/Integer32.birch"
    return birch::Integer32(x.get(), handler_);
  } else {
    #line 136 "src/basic/Integer32.birch"
    libbirch_line_(136);
    #line 136 "src/basic/Integer32.birch"
    return libbirch::nil;
  }
}

#line 143 "src/basic/Integer32.birch"
libbirch::Optional<birch::type::Integer32> birch::Integer32(const libbirch::Optional<birch::type::String>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 143 "src/basic/Integer32.birch"
  libbirch_function_("Integer32", "src/basic/Integer32.birch", 143);
  #line 144 "src/basic/Integer32.birch"
  libbirch_line_(144);
  #line 144 "src/basic/Integer32.birch"
  if (x.query()) {
    #line 145 "src/basic/Integer32.birch"
    libbirch_line_(145);
    #line 145 "src/basic/Integer32.birch"
    return birch::Integer32(x.get(), handler_);
  } else {
    #line 147 "src/basic/Integer32.birch"
    libbirch_line_(147);
    #line 147 "src/basic/Integer32.birch"
    return libbirch::nil;
  }
}

#line 170 "src/basic/Integer32.birch"
birch::type::Integer32 birch::abs(const birch::type::Integer32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 170 "src/basic/Integer32.birch"
  libbirch_function_("abs", "src/basic/Integer32.birch", 170);
  #line 171 "src/basic/Integer32.birch"
return std::abs(x);
  }

#line 179 "src/basic/Integer32.birch"
birch::type::Integer32 birch::pow(const birch::type::Integer32& x, const birch::type::Integer32& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 179 "src/basic/Integer32.birch"
  libbirch_function_("pow", "src/basic/Integer32.birch", 179);
  #line 180 "src/basic/Integer32.birch"
return std::pow(x, y);
  }

#line 188 "src/basic/Integer32.birch"
birch::type::Integer32 birch::mod(const birch::type::Integer32& x, const birch::type::Integer32& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 188 "src/basic/Integer32.birch"
  libbirch_function_("mod", "src/basic/Integer32.birch", 188);
  #line 189 "src/basic/Integer32.birch"
return x % y;
  }

#line 197 "src/basic/Integer32.birch"
birch::type::Integer32 birch::max(const birch::type::Integer32& x, const birch::type::Integer32& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 197 "src/basic/Integer32.birch"
  libbirch_function_("max", "src/basic/Integer32.birch", 197);
  #line 198 "src/basic/Integer32.birch"
return std::max(x, y);
  }

#line 206 "src/basic/Integer32.birch"
birch::type::Integer32 birch::min(const birch::type::Integer32& x, const birch::type::Integer32& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 206 "src/basic/Integer32.birch"
  libbirch_function_("min", "src/basic/Integer32.birch", 206);
  #line 207 "src/basic/Integer32.birch"
return std::min(x, y);
  }

#line 9 "src/basic/Integer64.birch"
birch::type::Integer64 birch::Integer64(const birch::type::Integer64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/basic/Integer64.birch"
  libbirch_function_("Integer64", "src/basic/Integer64.birch", 9);
  #line 10 "src/basic/Integer64.birch"
  libbirch_line_(10);
  #line 10 "src/basic/Integer64.birch"
  return x;
}

#line 16 "src/basic/Integer64.birch"
birch::type::Integer64 birch::Integer64(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/basic/Integer64.birch"
  libbirch_function_("Integer64", "src/basic/Integer64.birch", 16);
  #line 17 "src/basic/Integer64.birch"
return static_cast<birch::type::Integer64>(x);
  }

#line 25 "src/basic/Integer64.birch"
birch::type::Integer64 birch::Integer64(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/basic/Integer64.birch"
  libbirch_function_("Integer64", "src/basic/Integer64.birch", 25);
  #line 26 "src/basic/Integer64.birch"
return static_cast<birch::type::Integer64>(x);
  }

#line 34 "src/basic/Integer64.birch"
birch::type::Integer64 birch::Integer64(const birch::type::Integer32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/basic/Integer64.birch"
  libbirch_function_("Integer64", "src/basic/Integer64.birch", 34);
  #line 35 "src/basic/Integer64.birch"
return static_cast<birch::type::Integer64>(x);
  }

#line 43 "src/basic/Integer64.birch"
birch::type::Integer64 birch::Integer64(const birch::type::Integer16& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "src/basic/Integer64.birch"
  libbirch_function_("Integer64", "src/basic/Integer64.birch", 43);
  #line 44 "src/basic/Integer64.birch"
return static_cast<birch::type::Integer64>(x);
  }

#line 52 "src/basic/Integer64.birch"
birch::type::Integer64 birch::Integer64(const birch::type::Integer8& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "src/basic/Integer64.birch"
  libbirch_function_("Integer64", "src/basic/Integer64.birch", 52);
  #line 53 "src/basic/Integer64.birch"
return static_cast<birch::type::Integer64>(x);
  }

#line 61 "src/basic/Integer64.birch"
birch::type::Integer64 birch::Integer64(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "src/basic/Integer64.birch"
  libbirch_function_("Integer64", "src/basic/Integer64.birch", 61);
  #line 62 "src/basic/Integer64.birch"
  libbirch_line_(62);
  #line 62 "src/basic/Integer64.birch"
  if (x) {
    #line 63 "src/basic/Integer64.birch"
    libbirch_line_(63);
    #line 63 "src/basic/Integer64.birch"
    return birch::Integer64(birch::type::Integer(1), handler_);
  } else {
    #line 65 "src/basic/Integer64.birch"
    libbirch_line_(65);
    #line 65 "src/basic/Integer64.birch"
    return birch::Integer64(birch::type::Integer(0), handler_);
  }
}

#line 72 "src/basic/Integer64.birch"
birch::type::Integer64 birch::Integer64(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "src/basic/Integer64.birch"
  libbirch_function_("Integer64", "src/basic/Integer64.birch", 72);
  #line 73 "src/basic/Integer64.birch"
return ::atol(x.c_str());
  }

#line 81 "src/basic/Integer64.birch"
libbirch::Optional<birch::type::Integer64> birch::Integer64(const libbirch::Optional<birch::type::Integer64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "src/basic/Integer64.birch"
  libbirch_function_("Integer64", "src/basic/Integer64.birch", 81);
  #line 82 "src/basic/Integer64.birch"
  libbirch_line_(82);
  #line 82 "src/basic/Integer64.birch"
  return x;
}

#line 88 "src/basic/Integer64.birch"
libbirch::Optional<birch::type::Integer64> birch::Integer64(const libbirch::Optional<birch::type::Real64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 88 "src/basic/Integer64.birch"
  libbirch_function_("Integer64", "src/basic/Integer64.birch", 88);
  #line 89 "src/basic/Integer64.birch"
  libbirch_line_(89);
  #line 89 "src/basic/Integer64.birch"
  if (x.query()) {
    #line 90 "src/basic/Integer64.birch"
    libbirch_line_(90);
    #line 90 "src/basic/Integer64.birch"
    return birch::Integer64(x.get(), handler_);
  } else {
    #line 92 "src/basic/Integer64.birch"
    libbirch_line_(92);
    #line 92 "src/basic/Integer64.birch"
    return libbirch::nil;
  }
}

#line 99 "src/basic/Integer64.birch"
libbirch::Optional<birch::type::Integer64> birch::Integer64(const libbirch::Optional<birch::type::Real32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 99 "src/basic/Integer64.birch"
  libbirch_function_("Integer64", "src/basic/Integer64.birch", 99);
  #line 100 "src/basic/Integer64.birch"
  libbirch_line_(100);
  #line 100 "src/basic/Integer64.birch"
  if (x.query()) {
    #line 101 "src/basic/Integer64.birch"
    libbirch_line_(101);
    #line 101 "src/basic/Integer64.birch"
    return birch::Integer64(x.get(), handler_);
  } else {
    #line 103 "src/basic/Integer64.birch"
    libbirch_line_(103);
    #line 103 "src/basic/Integer64.birch"
    return libbirch::nil;
  }
}

#line 110 "src/basic/Integer64.birch"
libbirch::Optional<birch::type::Integer64> birch::Integer64(const libbirch::Optional<birch::type::Integer32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 110 "src/basic/Integer64.birch"
  libbirch_function_("Integer64", "src/basic/Integer64.birch", 110);
  #line 111 "src/basic/Integer64.birch"
  libbirch_line_(111);
  #line 111 "src/basic/Integer64.birch"
  if (x.query()) {
    #line 112 "src/basic/Integer64.birch"
    libbirch_line_(112);
    #line 112 "src/basic/Integer64.birch"
    return birch::Integer64(x.get(), handler_);
  } else {
    #line 114 "src/basic/Integer64.birch"
    libbirch_line_(114);
    #line 114 "src/basic/Integer64.birch"
    return libbirch::nil;
  }
}

#line 121 "src/basic/Integer64.birch"
libbirch::Optional<birch::type::Integer64> birch::Integer64(const libbirch::Optional<birch::type::Integer16>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 121 "src/basic/Integer64.birch"
  libbirch_function_("Integer64", "src/basic/Integer64.birch", 121);
  #line 122 "src/basic/Integer64.birch"
  libbirch_line_(122);
  #line 122 "src/basic/Integer64.birch"
  if (x.query()) {
    #line 123 "src/basic/Integer64.birch"
    libbirch_line_(123);
    #line 123 "src/basic/Integer64.birch"
    return birch::Integer64(x.get(), handler_);
  } else {
    #line 125 "src/basic/Integer64.birch"
    libbirch_line_(125);
    #line 125 "src/basic/Integer64.birch"
    return libbirch::nil;
  }
}

#line 132 "src/basic/Integer64.birch"
libbirch::Optional<birch::type::Integer64> birch::Integer64(const libbirch::Optional<birch::type::Integer8>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 132 "src/basic/Integer64.birch"
  libbirch_function_("Integer64", "src/basic/Integer64.birch", 132);
  #line 133 "src/basic/Integer64.birch"
  libbirch_line_(133);
  #line 133 "src/basic/Integer64.birch"
  if (x.query()) {
    #line 134 "src/basic/Integer64.birch"
    libbirch_line_(134);
    #line 134 "src/basic/Integer64.birch"
    return birch::Integer64(x.get(), handler_);
  } else {
    #line 136 "src/basic/Integer64.birch"
    libbirch_line_(136);
    #line 136 "src/basic/Integer64.birch"
    return libbirch::nil;
  }
}

#line 143 "src/basic/Integer64.birch"
libbirch::Optional<birch::type::Integer64> birch::Integer64(const libbirch::Optional<birch::type::String>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 143 "src/basic/Integer64.birch"
  libbirch_function_("Integer64", "src/basic/Integer64.birch", 143);
  #line 144 "src/basic/Integer64.birch"
  libbirch_line_(144);
  #line 144 "src/basic/Integer64.birch"
  if (x.query()) {
    #line 145 "src/basic/Integer64.birch"
    libbirch_line_(145);
    #line 145 "src/basic/Integer64.birch"
    return birch::Integer64(x.get(), handler_);
  } else {
    #line 147 "src/basic/Integer64.birch"
    libbirch_line_(147);
    #line 147 "src/basic/Integer64.birch"
    return libbirch::nil;
  }
}

#line 170 "src/basic/Integer64.birch"
birch::type::Integer64 birch::abs(const birch::type::Integer64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 170 "src/basic/Integer64.birch"
  libbirch_function_("abs", "src/basic/Integer64.birch", 170);
  #line 171 "src/basic/Integer64.birch"
return std::abs(x);
  }

#line 179 "src/basic/Integer64.birch"
birch::type::Integer64 birch::pow(const birch::type::Integer64& x, const birch::type::Integer64& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 179 "src/basic/Integer64.birch"
  libbirch_function_("pow", "src/basic/Integer64.birch", 179);
  #line 180 "src/basic/Integer64.birch"
return std::pow(x, y);
  }

#line 188 "src/basic/Integer64.birch"
birch::type::Integer64 birch::mod(const birch::type::Integer64& x, const birch::type::Integer64& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 188 "src/basic/Integer64.birch"
  libbirch_function_("mod", "src/basic/Integer64.birch", 188);
  #line 189 "src/basic/Integer64.birch"
return x % y;
  }

#line 197 "src/basic/Integer64.birch"
birch::type::Integer64 birch::max(const birch::type::Integer64& x, const birch::type::Integer64& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 197 "src/basic/Integer64.birch"
  libbirch_function_("max", "src/basic/Integer64.birch", 197);
  #line 198 "src/basic/Integer64.birch"
return std::max(x, y);
  }

#line 206 "src/basic/Integer64.birch"
birch::type::Integer64 birch::min(const birch::type::Integer64& x, const birch::type::Integer64& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 206 "src/basic/Integer64.birch"
  libbirch_function_("min", "src/basic/Integer64.birch", 206);
  #line 207 "src/basic/Integer64.birch"
return std::min(x, y);
  }

#line 9 "src/basic/LLT.birch"
birch::type::Integer64 birch::rows(const birch::type::LLT& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/basic/LLT.birch"
  libbirch_function_("rows", "src/basic/LLT.birch", 9);
  #line 10 "src/basic/LLT.birch"
return X.rows();
  }

#line 18 "src/basic/LLT.birch"
birch::type::Integer64 birch::columns(const birch::type::LLT& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/basic/LLT.birch"
  libbirch_function_("columns", "src/basic/LLT.birch", 18);
  #line 19 "src/basic/LLT.birch"
return X.cols();
  }

#line 58 "src/basic/LLT.birch"
birch::type::LLT birch::llt(const libbirch::DefaultArray<birch::type::Real,2>& S, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "src/basic/LLT.birch"
  libbirch_function_("llt", "src/basic/LLT.birch", 58);
  #line 59 "src/basic/LLT.birch"
  libbirch_line_(59);
  #line 59 "src/basic/LLT.birch"
  birch::type::LLT A;
  #line 60 "src/basic/LLT.birch"
A.compute(S.toEigen());
    #line 63 "src/basic/LLT.birch"
  libbirch_line_(63);
  #line 63 "src/basic/LLT.birch"
  return A;
}

#line 70 "src/basic/LLT.birch"
birch::type::LLT birch::llt(const birch::type::LLT& S, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "src/basic/LLT.birch"
  libbirch_function_("llt", "src/basic/LLT.birch", 70);
  #line 71 "src/basic/LLT.birch"
  libbirch_line_(71);
  #line 71 "src/basic/LLT.birch"
  return S;
}

#line 84 "src/basic/LLT.birch"
birch::type::LLT birch::rank_update(const birch::type::LLT& S, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 84 "src/basic/LLT.birch"
  libbirch_function_("rank_update", "src/basic/LLT.birch", 84);
  #line 85 "src/basic/LLT.birch"
  libbirch_line_(85);
  #line 85 "src/basic/LLT.birch"
  libbirch_assert_(birch::rows(S, handler_) == birch::length(x, handler_));
  #line 86 "src/basic/LLT.birch"
auto A = S;
  A.rankUpdate(x.toEigen(), 1.0);
  return A;
  }

#line 106 "src/basic/LLT.birch"
birch::type::LLT birch::rank_update(const birch::type::LLT& S, const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 106 "src/basic/LLT.birch"
  libbirch_function_("rank_update", "src/basic/LLT.birch", 106);
  #line 107 "src/basic/LLT.birch"
  libbirch_line_(107);
  #line 107 "src/basic/LLT.birch"
  libbirch_assert_(birch::rows(S, handler_) == birch::rows(X, handler_));
  #line 108 "src/basic/LLT.birch"
  libbirch_line_(108);
  #line 108 "src/basic/LLT.birch"
  birch::type::LLT A;
  #line 109 "src/basic/LLT.birch"
A = S;
    #line 112 "src/basic/LLT.birch"
  libbirch_line_(112);
  #line 112 "src/basic/LLT.birch"
  auto R = birch::rows(X, handler_);
  #line 113 "src/basic/LLT.birch"
  libbirch_line_(113);
  #line 113 "src/basic/LLT.birch"
  auto C = birch::columns(X, handler_);
  #line 114 "src/basic/LLT.birch"
  libbirch_line_(114);
  #line 114 "src/basic/LLT.birch"
  for (auto j = birch::type::Integer(1); j <= C; ++j) {
    #line 115 "src/basic/LLT.birch"
    libbirch_line_(115);
    #line 115 "src/basic/LLT.birch"
    auto x = X.get(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, R - 1), j - 1));
    #line 116 "src/basic/LLT.birch"
A.rankUpdate(x.toEigen(), 1.0);
      }
  #line 120 "src/basic/LLT.birch"
  libbirch_line_(120);
  #line 120 "src/basic/LLT.birch"
  return A;
}

#line 133 "src/basic/LLT.birch"
birch::type::LLT birch::rank_downdate(const birch::type::LLT& S, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 133 "src/basic/LLT.birch"
  libbirch_function_("rank_downdate", "src/basic/LLT.birch", 133);
  #line 134 "src/basic/LLT.birch"
  libbirch_line_(134);
  #line 134 "src/basic/LLT.birch"
  libbirch_assert_(birch::rows(S, handler_) == birch::length(x, handler_));
  #line 135 "src/basic/LLT.birch"
auto A = S;
  A.rankUpdate(x.toEigen(), -1.0);
  return A;
  }

#line 155 "src/basic/LLT.birch"
birch::type::LLT birch::rank_downdate(const birch::type::LLT& S, const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 155 "src/basic/LLT.birch"
  libbirch_function_("rank_downdate", "src/basic/LLT.birch", 155);
  #line 156 "src/basic/LLT.birch"
  libbirch_line_(156);
  #line 156 "src/basic/LLT.birch"
  libbirch_assert_(birch::rows(S, handler_) == birch::rows(X, handler_));
  #line 157 "src/basic/LLT.birch"
  libbirch_line_(157);
  #line 157 "src/basic/LLT.birch"
  birch::type::LLT A;
  #line 158 "src/basic/LLT.birch"
A = S;
    #line 161 "src/basic/LLT.birch"
  libbirch_line_(161);
  #line 161 "src/basic/LLT.birch"
  auto R = birch::rows(X, handler_);
  #line 162 "src/basic/LLT.birch"
  libbirch_line_(162);
  #line 162 "src/basic/LLT.birch"
  auto C = birch::columns(X, handler_);
  #line 163 "src/basic/LLT.birch"
  libbirch_line_(163);
  #line 163 "src/basic/LLT.birch"
  for (auto j = birch::type::Integer(1); j <= C; ++j) {
    #line 164 "src/basic/LLT.birch"
    libbirch_line_(164);
    #line 164 "src/basic/LLT.birch"
    auto x = X.get(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, R - 1), j - 1));
    #line 165 "src/basic/LLT.birch"
A.rankUpdate(x.toEigen(), -1.0);
      }
  #line 169 "src/basic/LLT.birch"
  libbirch_line_(169);
  #line 169 "src/basic/LLT.birch"
  return A;
}

#line 175 "src/basic/LLT.birch"
birch::type::LLT birch::operator+(const birch::type::LLT& x, const birch::type::LLT& y) {
  #line 175 "src/basic/LLT.birch"
  libbirch_function_("+", "src/basic/LLT.birch", 175);
  #line 176 "src/basic/LLT.birch"
return (x.reconstructedMatrix() + y.reconstructedMatrix()).llt();
  }

#line 4 "src/basic/Object.birch"
birch::type::Object::Object(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "src/basic/Object.birch"
    super_type_() {
  //
}

#line 8 "src/basic/Object.birch"
void birch::type::Object::read(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 8 "src/basic/Object.birch"
  libbirch_function_("read", "src/basic/Object.birch", 8);
}

#line 15 "src/basic/Object.birch"
void birch::type::Object::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/basic/Object.birch"
  libbirch_function_("write", "src/basic/Object.birch", 15);
}

#line 23 "src/basic/Object.birch"
birch::type::Boolean birch::operator==(const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& y) {
  #line 23 "src/basic/Object.birch"
  libbirch_function_("==", "src/basic/Object.birch", 23);
  #line 24 "src/basic/Object.birch"
return x.get() == y.get();
  }

#line 32 "src/basic/Object.birch"
birch::type::Boolean birch::operator!=(const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& y) {
  #line 32 "src/basic/Object.birch"
  libbirch_function_("!=", "src/basic/Object.birch", 32);
  #line 33 "src/basic/Object.birch"
  libbirch_line_(33);
  #line 33 "src/basic/Object.birch"
  return !(x == y);
}

#line 39 "src/basic/Object.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Object>> birch::Object(const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& o, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "src/basic/Object.birch"
  libbirch_function_("Object", "src/basic/Object.birch", 39);
  #line 40 "src/basic/Object.birch"
  libbirch_line_(40);
  #line 40 "src/basic/Object.birch"
  return o;
}

#line 9 "src/basic/Real.birch"
birch::type::Real birch::Real(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/basic/Real.birch"
  libbirch_function_("Real", "src/basic/Real.birch", 9);
  #line 10 "src/basic/Real.birch"
  libbirch_line_(10);
  #line 10 "src/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 16 "src/basic/Real.birch"
birch::type::Real birch::Real(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/basic/Real.birch"
  libbirch_function_("Real", "src/basic/Real.birch", 16);
  #line 17 "src/basic/Real.birch"
  libbirch_line_(17);
  #line 17 "src/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 23 "src/basic/Real.birch"
birch::type::Real birch::Real(const birch::type::Integer64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "src/basic/Real.birch"
  libbirch_function_("Real", "src/basic/Real.birch", 23);
  #line 24 "src/basic/Real.birch"
  libbirch_line_(24);
  #line 24 "src/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 30 "src/basic/Real.birch"
birch::type::Real birch::Real(const birch::type::Integer32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "src/basic/Real.birch"
  libbirch_function_("Real", "src/basic/Real.birch", 30);
  #line 31 "src/basic/Real.birch"
  libbirch_line_(31);
  #line 31 "src/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 37 "src/basic/Real.birch"
birch::type::Real birch::Real(const birch::type::Integer16& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "src/basic/Real.birch"
  libbirch_function_("Real", "src/basic/Real.birch", 37);
  #line 38 "src/basic/Real.birch"
  libbirch_line_(38);
  #line 38 "src/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 44 "src/basic/Real.birch"
birch::type::Real birch::Real(const birch::type::Integer8& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "src/basic/Real.birch"
  libbirch_function_("Real", "src/basic/Real.birch", 44);
  #line 45 "src/basic/Real.birch"
  libbirch_line_(45);
  #line 45 "src/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 51 "src/basic/Real.birch"
birch::type::Real birch::Real(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 51 "src/basic/Real.birch"
  libbirch_function_("Real", "src/basic/Real.birch", 51);
  #line 52 "src/basic/Real.birch"
  libbirch_line_(52);
  #line 52 "src/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 58 "src/basic/Real.birch"
birch::type::Real birch::Real(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "src/basic/Real.birch"
  libbirch_function_("Real", "src/basic/Real.birch", 58);
  #line 59 "src/basic/Real.birch"
  libbirch_line_(59);
  #line 59 "src/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 65 "src/basic/Real.birch"
libbirch::Optional<birch::type::Real> birch::Real(const libbirch::Optional<birch::type::Real64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "src/basic/Real.birch"
  libbirch_function_("Real", "src/basic/Real.birch", 65);
  #line 66 "src/basic/Real.birch"
  libbirch_line_(66);
  #line 66 "src/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 72 "src/basic/Real.birch"
libbirch::Optional<birch::type::Real> birch::Real(const libbirch::Optional<birch::type::Real32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "src/basic/Real.birch"
  libbirch_function_("Real", "src/basic/Real.birch", 72);
  #line 73 "src/basic/Real.birch"
  libbirch_line_(73);
  #line 73 "src/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 79 "src/basic/Real.birch"
libbirch::Optional<birch::type::Real> birch::Real(const libbirch::Optional<birch::type::Integer64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 79 "src/basic/Real.birch"
  libbirch_function_("Real", "src/basic/Real.birch", 79);
  #line 80 "src/basic/Real.birch"
  libbirch_line_(80);
  #line 80 "src/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 86 "src/basic/Real.birch"
libbirch::Optional<birch::type::Real> birch::Real(const libbirch::Optional<birch::type::Integer32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 86 "src/basic/Real.birch"
  libbirch_function_("Real", "src/basic/Real.birch", 86);
  #line 87 "src/basic/Real.birch"
  libbirch_line_(87);
  #line 87 "src/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 93 "src/basic/Real.birch"
libbirch::Optional<birch::type::Real> birch::Real(const libbirch::Optional<birch::type::Integer16>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 93 "src/basic/Real.birch"
  libbirch_function_("Real", "src/basic/Real.birch", 93);
  #line 94 "src/basic/Real.birch"
  libbirch_line_(94);
  #line 94 "src/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 100 "src/basic/Real.birch"
libbirch::Optional<birch::type::Real> birch::Real(const libbirch::Optional<birch::type::Integer8>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 100 "src/basic/Real.birch"
  libbirch_function_("Real", "src/basic/Real.birch", 100);
  #line 101 "src/basic/Real.birch"
  libbirch_line_(101);
  #line 101 "src/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 107 "src/basic/Real.birch"
libbirch::Optional<birch::type::Real> birch::Real(const libbirch::Optional<birch::type::String>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 107 "src/basic/Real.birch"
  libbirch_function_("Real", "src/basic/Real.birch", 107);
  #line 108 "src/basic/Real.birch"
  libbirch_line_(108);
  #line 108 "src/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 9 "src/basic/Real32.birch"
birch::type::Real32 birch::Real32(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/basic/Real32.birch"
  libbirch_function_("Real32", "src/basic/Real32.birch", 9);
  #line 10 "src/basic/Real32.birch"
return static_cast<birch::type::Real32>(x);
  }

#line 18 "src/basic/Real32.birch"
birch::type::Real32 birch::Real32(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "src/basic/Real32.birch"
  libbirch_function_("Real32", "src/basic/Real32.birch", 18);
  #line 19 "src/basic/Real32.birch"
  libbirch_line_(19);
  #line 19 "src/basic/Real32.birch"
  return x;
}

#line 25 "src/basic/Real32.birch"
birch::type::Real32 birch::Real32(const birch::type::Integer64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/basic/Real32.birch"
  libbirch_function_("Real32", "src/basic/Real32.birch", 25);
  #line 26 "src/basic/Real32.birch"
return static_cast<birch::type::Real32>(x);
  }

#line 34 "src/basic/Real32.birch"
birch::type::Real32 birch::Real32(const birch::type::Integer32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/basic/Real32.birch"
  libbirch_function_("Real32", "src/basic/Real32.birch", 34);
  #line 35 "src/basic/Real32.birch"
return static_cast<birch::type::Real32>(x);
  }

#line 43 "src/basic/Real32.birch"
birch::type::Real32 birch::Real32(const birch::type::Integer16& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "src/basic/Real32.birch"
  libbirch_function_("Real32", "src/basic/Real32.birch", 43);
  #line 44 "src/basic/Real32.birch"
return static_cast<birch::type::Real32>(x);
  }

#line 52 "src/basic/Real32.birch"
birch::type::Real32 birch::Real32(const birch::type::Integer8& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "src/basic/Real32.birch"
  libbirch_function_("Real32", "src/basic/Real32.birch", 52);
  #line 53 "src/basic/Real32.birch"
return static_cast<birch::type::Real32>(x);
  }

#line 61 "src/basic/Real32.birch"
birch::type::Real32 birch::Real32(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "src/basic/Real32.birch"
  libbirch_function_("Real32", "src/basic/Real32.birch", 61);
  #line 62 "src/basic/Real32.birch"
  libbirch_line_(62);
  #line 62 "src/basic/Real32.birch"
  if (x) {
    #line 63 "src/basic/Real32.birch"
    libbirch_line_(63);
    #line 63 "src/basic/Real32.birch"
    return birch::Real32(1.0, handler_);
  } else {
    #line 65 "src/basic/Real32.birch"
    libbirch_line_(65);
    #line 65 "src/basic/Real32.birch"
    return birch::Real32(0.0, handler_);
  }
}

#line 72 "src/basic/Real32.birch"
birch::type::Real32 birch::Real32(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "src/basic/Real32.birch"
  libbirch_function_("Real32", "src/basic/Real32.birch", 72);
  #line 73 "src/basic/Real32.birch"
return ::strtof(x.c_str(), nullptr);
  }

#line 81 "src/basic/Real32.birch"
libbirch::Optional<birch::type::Real32> birch::Real32(const libbirch::Optional<birch::type::Real64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "src/basic/Real32.birch"
  libbirch_function_("Real32", "src/basic/Real32.birch", 81);
  #line 82 "src/basic/Real32.birch"
  libbirch_line_(82);
  #line 82 "src/basic/Real32.birch"
  if (x.query()) {
    #line 83 "src/basic/Real32.birch"
    libbirch_line_(83);
    #line 83 "src/basic/Real32.birch"
    return birch::Real32(x.get(), handler_);
  } else {
    #line 85 "src/basic/Real32.birch"
    libbirch_line_(85);
    #line 85 "src/basic/Real32.birch"
    return libbirch::nil;
  }
}

#line 92 "src/basic/Real32.birch"
libbirch::Optional<birch::type::Real32> birch::Real32(const libbirch::Optional<birch::type::Real32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 92 "src/basic/Real32.birch"
  libbirch_function_("Real32", "src/basic/Real32.birch", 92);
  #line 93 "src/basic/Real32.birch"
  libbirch_line_(93);
  #line 93 "src/basic/Real32.birch"
  return x;
}

#line 99 "src/basic/Real32.birch"
libbirch::Optional<birch::type::Real32> birch::Real32(const libbirch::Optional<birch::type::Integer64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 99 "src/basic/Real32.birch"
  libbirch_function_("Real32", "src/basic/Real32.birch", 99);
  #line 100 "src/basic/Real32.birch"
  libbirch_line_(100);
  #line 100 "src/basic/Real32.birch"
  if (x.query()) {
    #line 101 "src/basic/Real32.birch"
    libbirch_line_(101);
    #line 101 "src/basic/Real32.birch"
    return birch::Real32(x.get(), handler_);
  } else {
    #line 103 "src/basic/Real32.birch"
    libbirch_line_(103);
    #line 103 "src/basic/Real32.birch"
    return libbirch::nil;
  }
}

#line 110 "src/basic/Real32.birch"
libbirch::Optional<birch::type::Real32> birch::Real32(const libbirch::Optional<birch::type::Integer32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 110 "src/basic/Real32.birch"
  libbirch_function_("Real32", "src/basic/Real32.birch", 110);
  #line 111 "src/basic/Real32.birch"
  libbirch_line_(111);
  #line 111 "src/basic/Real32.birch"
  if (x.query()) {
    #line 112 "src/basic/Real32.birch"
    libbirch_line_(112);
    #line 112 "src/basic/Real32.birch"
    return birch::Real32(x.get(), handler_);
  } else {
    #line 114 "src/basic/Real32.birch"
    libbirch_line_(114);
    #line 114 "src/basic/Real32.birch"
    return libbirch::nil;
  }
}

#line 121 "src/basic/Real32.birch"
libbirch::Optional<birch::type::Real32> birch::Real32(const libbirch::Optional<birch::type::Integer16>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 121 "src/basic/Real32.birch"
  libbirch_function_("Real32", "src/basic/Real32.birch", 121);
  #line 122 "src/basic/Real32.birch"
  libbirch_line_(122);
  #line 122 "src/basic/Real32.birch"
  if (x.query()) {
    #line 123 "src/basic/Real32.birch"
    libbirch_line_(123);
    #line 123 "src/basic/Real32.birch"
    return birch::Real32(x.get(), handler_);
  } else {
    #line 125 "src/basic/Real32.birch"
    libbirch_line_(125);
    #line 125 "src/basic/Real32.birch"
    return libbirch::nil;
  }
}

#line 132 "src/basic/Real32.birch"
libbirch::Optional<birch::type::Real32> birch::Real32(const libbirch::Optional<birch::type::Integer8>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 132 "src/basic/Real32.birch"
  libbirch_function_("Real32", "src/basic/Real32.birch", 132);
  #line 133 "src/basic/Real32.birch"
  libbirch_line_(133);
  #line 133 "src/basic/Real32.birch"
  if (x.query()) {
    #line 134 "src/basic/Real32.birch"
    libbirch_line_(134);
    #line 134 "src/basic/Real32.birch"
    return birch::Real32(x.get(), handler_);
  } else {
    #line 136 "src/basic/Real32.birch"
    libbirch_line_(136);
    #line 136 "src/basic/Real32.birch"
    return libbirch::nil;
  }
}

#line 143 "src/basic/Real32.birch"
libbirch::Optional<birch::type::Real32> birch::Real32(const libbirch::Optional<birch::type::String>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 143 "src/basic/Real32.birch"
  libbirch_function_("Real32", "src/basic/Real32.birch", 143);
  #line 144 "src/basic/Real32.birch"
  libbirch_line_(144);
  #line 144 "src/basic/Real32.birch"
  if (x.query()) {
    #line 145 "src/basic/Real32.birch"
    libbirch_line_(145);
    #line 145 "src/basic/Real32.birch"
    return birch::Real32(x.get(), handler_);
  } else {
    #line 147 "src/basic/Real32.birch"
    libbirch_line_(147);
    #line 147 "src/basic/Real32.birch"
    return libbirch::nil;
  }
}

#line 170 "src/basic/Real32.birch"
birch::type::Real32 birch::abs(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 170 "src/basic/Real32.birch"
  libbirch_function_("abs", "src/basic/Real32.birch", 170);
  #line 171 "src/basic/Real32.birch"
return std::abs(x);
  }

#line 179 "src/basic/Real32.birch"
birch::type::Real32 birch::pow(const birch::type::Real32& x, const birch::type::Real32& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 179 "src/basic/Real32.birch"
  libbirch_function_("pow", "src/basic/Real32.birch", 179);
  #line 180 "src/basic/Real32.birch"
return ::powf(x, y);
  }

#line 188 "src/basic/Real32.birch"
birch::type::Real32 birch::mod(const birch::type::Real32& x, const birch::type::Real32& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 188 "src/basic/Real32.birch"
  libbirch_function_("mod", "src/basic/Real32.birch", 188);
  #line 189 "src/basic/Real32.birch"
return ::fmodf(x, y);
  }

#line 197 "src/basic/Real32.birch"
birch::type::Real32 birch::max(const birch::type::Real32& x, const birch::type::Real32& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 197 "src/basic/Real32.birch"
  libbirch_function_("max", "src/basic/Real32.birch", 197);
  #line 198 "src/basic/Real32.birch"
return std::max(x, y);
  }

#line 206 "src/basic/Real32.birch"
birch::type::Real32 birch::min(const birch::type::Real32& x, const birch::type::Real32& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 206 "src/basic/Real32.birch"
  libbirch_function_("min", "src/basic/Real32.birch", 206);
  #line 207 "src/basic/Real32.birch"
return std::min(x, y);
  }

#line 215 "src/basic/Real32.birch"
birch::type::Boolean birch::isinf(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 215 "src/basic/Real32.birch"
  libbirch_function_("isinf", "src/basic/Real32.birch", 215);
  #line 216 "src/basic/Real32.birch"
return std::isinf(x);
  }

#line 224 "src/basic/Real32.birch"
birch::type::Boolean birch::isnan(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 224 "src/basic/Real32.birch"
  libbirch_function_("isnan", "src/basic/Real32.birch", 224);
  #line 225 "src/basic/Real32.birch"
return std::isnan(x);
  }

#line 233 "src/basic/Real32.birch"
birch::type::Boolean birch::isfinite(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 233 "src/basic/Real32.birch"
  libbirch_function_("isfinite", "src/basic/Real32.birch", 233);
  #line 234 "src/basic/Real32.birch"
return std::isfinite(x);
  }

#line 9 "src/basic/Real64.birch"
birch::type::Real64 birch::Real64(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/basic/Real64.birch"
  libbirch_function_("Real64", "src/basic/Real64.birch", 9);
  #line 10 "src/basic/Real64.birch"
  libbirch_line_(10);
  #line 10 "src/basic/Real64.birch"
  return x;
}

#line 16 "src/basic/Real64.birch"
birch::type::Real64 birch::Real64(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/basic/Real64.birch"
  libbirch_function_("Real64", "src/basic/Real64.birch", 16);
  #line 17 "src/basic/Real64.birch"
return static_cast<birch::type::Real64>(x);
  }

#line 25 "src/basic/Real64.birch"
birch::type::Real64 birch::Real64(const birch::type::Integer64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "src/basic/Real64.birch"
  libbirch_function_("Real64", "src/basic/Real64.birch", 25);
  #line 26 "src/basic/Real64.birch"
return static_cast<birch::type::Real64>(x);
  }

#line 34 "src/basic/Real64.birch"
birch::type::Real64 birch::Real64(const birch::type::Integer32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/basic/Real64.birch"
  libbirch_function_("Real64", "src/basic/Real64.birch", 34);
  #line 35 "src/basic/Real64.birch"
return static_cast<birch::type::Real64>(x);
  }

#line 43 "src/basic/Real64.birch"
birch::type::Real64 birch::Real64(const birch::type::Integer16& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "src/basic/Real64.birch"
  libbirch_function_("Real64", "src/basic/Real64.birch", 43);
  #line 44 "src/basic/Real64.birch"
return static_cast<birch::type::Real64>(x);
  }

#line 52 "src/basic/Real64.birch"
birch::type::Real64 birch::Real64(const birch::type::Integer8& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "src/basic/Real64.birch"
  libbirch_function_("Real64", "src/basic/Real64.birch", 52);
  #line 53 "src/basic/Real64.birch"
return static_cast<birch::type::Real64>(x);
  }

#line 61 "src/basic/Real64.birch"
birch::type::Real64 birch::Real64(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "src/basic/Real64.birch"
  libbirch_function_("Real64", "src/basic/Real64.birch", 61);
  #line 62 "src/basic/Real64.birch"
  libbirch_line_(62);
  #line 62 "src/basic/Real64.birch"
  if (x) {
    #line 63 "src/basic/Real64.birch"
    libbirch_line_(63);
    #line 63 "src/basic/Real64.birch"
    return birch::Real64(1.0, handler_);
  } else {
    #line 65 "src/basic/Real64.birch"
    libbirch_line_(65);
    #line 65 "src/basic/Real64.birch"
    return birch::Real64(0.0, handler_);
  }
}

#line 72 "src/basic/Real64.birch"
birch::type::Real64 birch::Real64(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "src/basic/Real64.birch"
  libbirch_function_("Real64", "src/basic/Real64.birch", 72);
  #line 73 "src/basic/Real64.birch"
return ::strtod(x.c_str(), nullptr);
  }

#line 81 "src/basic/Real64.birch"
libbirch::Optional<birch::type::Real64> birch::Real64(const libbirch::Optional<birch::type::Real64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "src/basic/Real64.birch"
  libbirch_function_("Real64", "src/basic/Real64.birch", 81);
  #line 82 "src/basic/Real64.birch"
  libbirch_line_(82);
  #line 82 "src/basic/Real64.birch"
  return x;
}

#line 88 "src/basic/Real64.birch"
libbirch::Optional<birch::type::Real64> birch::Real64(const libbirch::Optional<birch::type::Real32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 88 "src/basic/Real64.birch"
  libbirch_function_("Real64", "src/basic/Real64.birch", 88);
  #line 89 "src/basic/Real64.birch"
  libbirch_line_(89);
  #line 89 "src/basic/Real64.birch"
  if (x.query()) {
    #line 90 "src/basic/Real64.birch"
    libbirch_line_(90);
    #line 90 "src/basic/Real64.birch"
    return birch::Real64(x.get(), handler_);
  } else {
    #line 92 "src/basic/Real64.birch"
    libbirch_line_(92);
    #line 92 "src/basic/Real64.birch"
    return libbirch::nil;
  }
}

#line 99 "src/basic/Real64.birch"
libbirch::Optional<birch::type::Real64> birch::Real64(const libbirch::Optional<birch::type::Integer64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 99 "src/basic/Real64.birch"
  libbirch_function_("Real64", "src/basic/Real64.birch", 99);
  #line 100 "src/basic/Real64.birch"
  libbirch_line_(100);
  #line 100 "src/basic/Real64.birch"
  if (x.query()) {
    #line 101 "src/basic/Real64.birch"
    libbirch_line_(101);
    #line 101 "src/basic/Real64.birch"
    return birch::Real64(x.get(), handler_);
  } else {
    #line 103 "src/basic/Real64.birch"
    libbirch_line_(103);
    #line 103 "src/basic/Real64.birch"
    return libbirch::nil;
  }
}

#line 110 "src/basic/Real64.birch"
libbirch::Optional<birch::type::Real64> birch::Real64(const libbirch::Optional<birch::type::Integer32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 110 "src/basic/Real64.birch"
  libbirch_function_("Real64", "src/basic/Real64.birch", 110);
  #line 111 "src/basic/Real64.birch"
  libbirch_line_(111);
  #line 111 "src/basic/Real64.birch"
  if (x.query()) {
    #line 112 "src/basic/Real64.birch"
    libbirch_line_(112);
    #line 112 "src/basic/Real64.birch"
    return birch::Real64(x.get(), handler_);
  } else {
    #line 114 "src/basic/Real64.birch"
    libbirch_line_(114);
    #line 114 "src/basic/Real64.birch"
    return libbirch::nil;
  }
}

#line 121 "src/basic/Real64.birch"
libbirch::Optional<birch::type::Real64> birch::Real64(const libbirch::Optional<birch::type::Integer16>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 121 "src/basic/Real64.birch"
  libbirch_function_("Real64", "src/basic/Real64.birch", 121);
  #line 122 "src/basic/Real64.birch"
  libbirch_line_(122);
  #line 122 "src/basic/Real64.birch"
  if (x.query()) {
    #line 123 "src/basic/Real64.birch"
    libbirch_line_(123);
    #line 123 "src/basic/Real64.birch"
    return birch::Real64(x.get(), handler_);
  } else {
    #line 125 "src/basic/Real64.birch"
    libbirch_line_(125);
    #line 125 "src/basic/Real64.birch"
    return libbirch::nil;
  }
}

#line 132 "src/basic/Real64.birch"
libbirch::Optional<birch::type::Real64> birch::Real64(const libbirch::Optional<birch::type::Integer8>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 132 "src/basic/Real64.birch"
  libbirch_function_("Real64", "src/basic/Real64.birch", 132);
  #line 133 "src/basic/Real64.birch"
  libbirch_line_(133);
  #line 133 "src/basic/Real64.birch"
  if (x.query()) {
    #line 134 "src/basic/Real64.birch"
    libbirch_line_(134);
    #line 134 "src/basic/Real64.birch"
    return birch::Real64(x.get(), handler_);
  } else {
    #line 136 "src/basic/Real64.birch"
    libbirch_line_(136);
    #line 136 "src/basic/Real64.birch"
    return libbirch::nil;
  }
}

#line 143 "src/basic/Real64.birch"
libbirch::Optional<birch::type::Real64> birch::Real64(const libbirch::Optional<birch::type::String>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 143 "src/basic/Real64.birch"
  libbirch_function_("Real64", "src/basic/Real64.birch", 143);
  #line 144 "src/basic/Real64.birch"
  libbirch_line_(144);
  #line 144 "src/basic/Real64.birch"
  if (x.query()) {
    #line 145 "src/basic/Real64.birch"
    libbirch_line_(145);
    #line 145 "src/basic/Real64.birch"
    return birch::Real64(x.get(), handler_);
  } else {
    #line 147 "src/basic/Real64.birch"
    libbirch_line_(147);
    #line 147 "src/basic/Real64.birch"
    return libbirch::nil;
  }
}

#line 170 "src/basic/Real64.birch"
birch::type::Real64 birch::abs(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 170 "src/basic/Real64.birch"
  libbirch_function_("abs", "src/basic/Real64.birch", 170);
  #line 171 "src/basic/Real64.birch"
return std::abs(x);
  }

#line 179 "src/basic/Real64.birch"
birch::type::Real64 birch::pow(const birch::type::Real64& x, const birch::type::Real64& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 179 "src/basic/Real64.birch"
  libbirch_function_("pow", "src/basic/Real64.birch", 179);
  #line 180 "src/basic/Real64.birch"
return ::pow(x, y);
  }

#line 188 "src/basic/Real64.birch"
birch::type::Real64 birch::mod(const birch::type::Real64& x, const birch::type::Real64& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 188 "src/basic/Real64.birch"
  libbirch_function_("mod", "src/basic/Real64.birch", 188);
  #line 189 "src/basic/Real64.birch"
return ::fmod(x, y);
  }

#line 197 "src/basic/Real64.birch"
birch::type::Real64 birch::max(const birch::type::Real64& x, const birch::type::Real64& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 197 "src/basic/Real64.birch"
  libbirch_function_("max", "src/basic/Real64.birch", 197);
  #line 198 "src/basic/Real64.birch"
return std::max(x, y);
  }

#line 206 "src/basic/Real64.birch"
birch::type::Real64 birch::min(const birch::type::Real64& x, const birch::type::Real64& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 206 "src/basic/Real64.birch"
  libbirch_function_("min", "src/basic/Real64.birch", 206);
  #line 207 "src/basic/Real64.birch"
return std::min(x, y);
  }

#line 215 "src/basic/Real64.birch"
birch::type::Boolean birch::isinf(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 215 "src/basic/Real64.birch"
  libbirch_function_("isinf", "src/basic/Real64.birch", 215);
  #line 216 "src/basic/Real64.birch"
return std::isinf(x);
  }

#line 224 "src/basic/Real64.birch"
birch::type::Boolean birch::isnan(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 224 "src/basic/Real64.birch"
  libbirch_function_("isnan", "src/basic/Real64.birch", 224);
  #line 225 "src/basic/Real64.birch"
return std::isnan(x);
  }

#line 233 "src/basic/Real64.birch"
birch::type::Boolean birch::isfinite(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 233 "src/basic/Real64.birch"
  libbirch_function_("isfinite", "src/basic/Real64.birch", 233);
  #line 234 "src/basic/Real64.birch"
return std::isfinite(x);
  }

#line 9 "src/basic/String.birch"
birch::type::String birch::String(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "src/basic/String.birch"
  libbirch_function_("String", "src/basic/String.birch", 9);
  #line 10 "src/basic/String.birch"
  libbirch_line_(10);
  #line 10 "src/basic/String.birch"
  if (x) {
    #line 11 "src/basic/String.birch"
    libbirch_line_(11);
    #line 11 "src/basic/String.birch"
    return birch::type::String("true");
  } else {
    #line 13 "src/basic/String.birch"
    libbirch_line_(13);
    #line 13 "src/basic/String.birch"
    return birch::type::String("false");
  }
}

#line 20 "src/basic/String.birch"
birch::type::String birch::String(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "src/basic/String.birch"
  libbirch_function_("String", "src/basic/String.birch", 20);
  #line 21 "src/basic/String.birch"
std::stringstream buf;
  if (x == floor(x)) {
    buf << (int64_t)x << ".0";
  } else {
    buf << std::scientific << std::setprecision(14) << x;
  }
  return buf.str();
  }

#line 35 "src/basic/String.birch"
birch::type::String birch::String(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "src/basic/String.birch"
  libbirch_function_("String", "src/basic/String.birch", 35);
  #line 36 "src/basic/String.birch"
std::stringstream buf;
  if (x == floor(x)) {
    buf << (int64_t)x << ".0";
  } else {
    buf << std::scientific << std::setprecision(6) << x;
  }
  return buf.str();
  }

#line 50 "src/basic/String.birch"
birch::type::String birch::String(const birch::type::Integer64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "src/basic/String.birch"
  libbirch_function_("String", "src/basic/String.birch", 50);
  #line 51 "src/basic/String.birch"
return std::to_string(x);
  }

#line 59 "src/basic/String.birch"
birch::type::String birch::String(const birch::type::Integer32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "src/basic/String.birch"
  libbirch_function_("String", "src/basic/String.birch", 59);
  #line 60 "src/basic/String.birch"
return std::to_string(x);
  }

#line 68 "src/basic/String.birch"
birch::type::String birch::String(const birch::type::Integer16& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 68 "src/basic/String.birch"
  libbirch_function_("String", "src/basic/String.birch", 68);
  #line 69 "src/basic/String.birch"
return std::to_string(x);
  }

#line 77 "src/basic/String.birch"
birch::type::String birch::String(const birch::type::Integer8& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 77 "src/basic/String.birch"
  libbirch_function_("String", "src/basic/String.birch", 77);
  #line 78 "src/basic/String.birch"
return std::to_string(x);
  }

#line 86 "src/basic/String.birch"
birch::type::String birch::String(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 86 "src/basic/String.birch"
  libbirch_function_("String", "src/basic/String.birch", 86);
  #line 87 "src/basic/String.birch"
  libbirch_line_(87);
  #line 87 "src/basic/String.birch"
  return x;
}

#line 93 "src/basic/String.birch"
libbirch::Optional<birch::type::String> birch::String(const libbirch::Optional<birch::type::Boolean>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 93 "src/basic/String.birch"
  libbirch_function_("String", "src/basic/String.birch", 93);
  #line 94 "src/basic/String.birch"
  libbirch_line_(94);
  #line 94 "src/basic/String.birch"
  if (x.query()) {
    #line 95 "src/basic/String.birch"
    libbirch_line_(95);
    #line 95 "src/basic/String.birch"
    return birch::String(x.get(), handler_);
  } else {
    #line 97 "src/basic/String.birch"
    libbirch_line_(97);
    #line 97 "src/basic/String.birch"
    return libbirch::nil;
  }
}

#line 104 "src/basic/String.birch"
libbirch::Optional<birch::type::String> birch::String(const libbirch::Optional<birch::type::Real64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 104 "src/basic/String.birch"
  libbirch_function_("String", "src/basic/String.birch", 104);
  #line 105 "src/basic/String.birch"
  libbirch_line_(105);
  #line 105 "src/basic/String.birch"
  if (x.query()) {
    #line 106 "src/basic/String.birch"
    libbirch_line_(106);
    #line 106 "src/basic/String.birch"
    return birch::String(x.get(), handler_);
  } else {
    #line 108 "src/basic/String.birch"
    libbirch_line_(108);
    #line 108 "src/basic/String.birch"
    return libbirch::nil;
  }
}

#line 115 "src/basic/String.birch"
libbirch::Optional<birch::type::String> birch::String(const libbirch::Optional<birch::type::Real32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 115 "src/basic/String.birch"
  libbirch_function_("String", "src/basic/String.birch", 115);
  #line 116 "src/basic/String.birch"
  libbirch_line_(116);
  #line 116 "src/basic/String.birch"
  if (x.query()) {
    #line 117 "src/basic/String.birch"
    libbirch_line_(117);
    #line 117 "src/basic/String.birch"
    return birch::String(x.get(), handler_);
  } else {
    #line 119 "src/basic/String.birch"
    libbirch_line_(119);
    #line 119 "src/basic/String.birch"
    return libbirch::nil;
  }
}

#line 126 "src/basic/String.birch"
libbirch::Optional<birch::type::String> birch::String(const libbirch::Optional<birch::type::Integer64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 126 "src/basic/String.birch"
  libbirch_function_("String", "src/basic/String.birch", 126);
  #line 127 "src/basic/String.birch"
  libbirch_line_(127);
  #line 127 "src/basic/String.birch"
  if (x.query()) {
    #line 128 "src/basic/String.birch"
    libbirch_line_(128);
    #line 128 "src/basic/String.birch"
    return birch::String(x.get(), handler_);
  } else {
    #line 130 "src/basic/String.birch"
    libbirch_line_(130);
    #line 130 "src/basic/String.birch"
    return libbirch::nil;
  }
}

#line 137 "src/basic/String.birch"
libbirch::Optional<birch::type::String> birch::String(const libbirch::Optional<birch::type::Integer32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 137 "src/basic/String.birch"
  libbirch_function_("String", "src/basic/String.birch", 137);
  #line 138 "src/basic/String.birch"
  libbirch_line_(138);
  #line 138 "src/basic/String.birch"
  if (x.query()) {
    #line 139 "src/basic/String.birch"
    libbirch_line_(139);
    #line 139 "src/basic/String.birch"
    return birch::String(x.get(), handler_);
  } else {
    #line 141 "src/basic/String.birch"
    libbirch_line_(141);
    #line 141 "src/basic/String.birch"
    return libbirch::nil;
  }
}

#line 148 "src/basic/String.birch"
libbirch::Optional<birch::type::String> birch::String(const libbirch::Optional<birch::type::Integer16>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 148 "src/basic/String.birch"
  libbirch_function_("String", "src/basic/String.birch", 148);
  #line 149 "src/basic/String.birch"
  libbirch_line_(149);
  #line 149 "src/basic/String.birch"
  if (x.query()) {
    #line 150 "src/basic/String.birch"
    libbirch_line_(150);
    #line 150 "src/basic/String.birch"
    return birch::String(x.get(), handler_);
  } else {
    #line 152 "src/basic/String.birch"
    libbirch_line_(152);
    #line 152 "src/basic/String.birch"
    return libbirch::nil;
  }
}

#line 159 "src/basic/String.birch"
libbirch::Optional<birch::type::String> birch::String(const libbirch::Optional<birch::type::Integer8>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 159 "src/basic/String.birch"
  libbirch_function_("String", "src/basic/String.birch", 159);
  #line 160 "src/basic/String.birch"
  libbirch_line_(160);
  #line 160 "src/basic/String.birch"
  if (x.query()) {
    #line 161 "src/basic/String.birch"
    libbirch_line_(161);
    #line 161 "src/basic/String.birch"
    return birch::String(x.get(), handler_);
  } else {
    #line 163 "src/basic/String.birch"
    libbirch_line_(163);
    #line 163 "src/basic/String.birch"
    return libbirch::nil;
  }
}

#line 170 "src/basic/String.birch"
libbirch::Optional<birch::type::String> birch::String(const libbirch::Optional<birch::type::String>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 170 "src/basic/String.birch"
  libbirch_function_("String", "src/basic/String.birch", 170);
  #line 171 "src/basic/String.birch"
  libbirch_line_(171);
  #line 171 "src/basic/String.birch"
  return x;
}

#line 177 "src/basic/String.birch"
birch::type::Boolean birch::operator>(const birch::type::String& x, const birch::type::String& y) {
  #line 177 "src/basic/String.birch"
  libbirch_function_(">", "src/basic/String.birch", 177);
  #line 178 "src/basic/String.birch"
return x.compare(y) > 0;
  }

#line 186 "src/basic/String.birch"
birch::type::Boolean birch::operator<(const birch::type::String& x, const birch::type::String& y) {
  #line 186 "src/basic/String.birch"
  libbirch_function_("<", "src/basic/String.birch", 186);
  #line 187 "src/basic/String.birch"
return x.compare(y) < 0;
  }

#line 195 "src/basic/String.birch"
birch::type::Boolean birch::operator>=(const birch::type::String& x, const birch::type::String& y) {
  #line 195 "src/basic/String.birch"
  libbirch_function_(">=", "src/basic/String.birch", 195);
  #line 196 "src/basic/String.birch"
return x.compare(y) >= 0;
  }

#line 204 "src/basic/String.birch"
birch::type::Boolean birch::operator<=(const birch::type::String& x, const birch::type::String& y) {
  #line 204 "src/basic/String.birch"
  libbirch_function_("<=", "src/basic/String.birch", 204);
  #line 205 "src/basic/String.birch"
return x.compare(y) <= 0;
  }

#line 213 "src/basic/String.birch"
birch::type::Boolean birch::operator==(const birch::type::String& x, const birch::type::String& y) {
  #line 213 "src/basic/String.birch"
  libbirch_function_("==", "src/basic/String.birch", 213);
  #line 214 "src/basic/String.birch"
return x.compare(y) == 0;
  }

#line 222 "src/basic/String.birch"
birch::type::Boolean birch::operator!=(const birch::type::String& x, const birch::type::String& y) {
  #line 222 "src/basic/String.birch"
  libbirch_function_("!=", "src/basic/String.birch", 222);
  #line 223 "src/basic/String.birch"
return x.compare(y) != 0;
  }

#line 236 "src/basic/String.birch"
birch::type::String birch::operator+(const birch::type::String& x, const birch::type::Boolean& y) {
  #line 236 "src/basic/String.birch"
  libbirch_function_("+", "src/basic/String.birch", 236);
  #line 237 "src/basic/String.birch"
  libbirch_line_(237);
  #line 237 "src/basic/String.birch"
  return x + birch::String(y);
}

#line 243 "src/basic/String.birch"
birch::type::String birch::operator+(const birch::type::String& x, const birch::type::Real& y) {
  #line 243 "src/basic/String.birch"
  libbirch_function_("+", "src/basic/String.birch", 243);
  #line 244 "src/basic/String.birch"
  libbirch_line_(244);
  #line 244 "src/basic/String.birch"
  return x + birch::String(y);
}

#line 250 "src/basic/String.birch"
birch::type::String birch::operator+(const birch::type::String& x, const birch::type::Integer& y) {
  #line 250 "src/basic/String.birch"
  libbirch_function_("+", "src/basic/String.birch", 250);
  #line 251 "src/basic/String.birch"
  libbirch_line_(251);
  #line 251 "src/basic/String.birch"
  return x + birch::String(y);
}

#line 257 "src/basic/String.birch"
birch::type::String birch::operator+(const birch::type::String& x, const libbirch::DefaultArray<birch::type::Boolean,1>& y) {
  #line 257 "src/basic/String.birch"
  libbirch_function_("+", "src/basic/String.birch", 257);
  #line 258 "src/basic/String.birch"
  libbirch_line_(258);
  #line 258 "src/basic/String.birch"
  return x + birch::String(y);
}

#line 264 "src/basic/String.birch"
birch::type::String birch::operator+(const birch::type::String& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 264 "src/basic/String.birch"
  libbirch_function_("+", "src/basic/String.birch", 264);
  #line 265 "src/basic/String.birch"
  libbirch_line_(265);
  #line 265 "src/basic/String.birch"
  return x + birch::String(y);
}

#line 271 "src/basic/String.birch"
birch::type::String birch::operator+(const birch::type::String& x, const libbirch::DefaultArray<birch::type::Integer,1>& y) {
  #line 271 "src/basic/String.birch"
  libbirch_function_("+", "src/basic/String.birch", 271);
  #line 272 "src/basic/String.birch"
  libbirch_line_(272);
  #line 272 "src/basic/String.birch"
  return x + birch::String(y);
}

#line 278 "src/basic/String.birch"
birch::type::String birch::operator+(const birch::type::String& x, const libbirch::DefaultArray<birch::type::Boolean,2>& y) {
  #line 278 "src/basic/String.birch"
  libbirch_function_("+", "src/basic/String.birch", 278);
  #line 279 "src/basic/String.birch"
  libbirch_line_(279);
  #line 279 "src/basic/String.birch"
  return x + birch::String(y);
}

#line 285 "src/basic/String.birch"
birch::type::String birch::operator+(const birch::type::String& x, const libbirch::DefaultArray<birch::type::Real,2>& y) {
  #line 285 "src/basic/String.birch"
  libbirch_function_("+", "src/basic/String.birch", 285);
  #line 286 "src/basic/String.birch"
  libbirch_line_(286);
  #line 286 "src/basic/String.birch"
  return x + birch::String(y);
}

#line 292 "src/basic/String.birch"
birch::type::String birch::operator+(const birch::type::String& x, const libbirch::DefaultArray<birch::type::Integer,2>& y) {
  #line 292 "src/basic/String.birch"
  libbirch_function_("+", "src/basic/String.birch", 292);
  #line 293 "src/basic/String.birch"
  libbirch_line_(293);
  #line 293 "src/basic/String.birch"
  return x + birch::String(y);
}

#line 299 "src/basic/String.birch"
birch::type::String birch::operator+(const birch::type::Boolean& x, const birch::type::String& y) {
  #line 299 "src/basic/String.birch"
  libbirch_function_("+", "src/basic/String.birch", 299);
  #line 300 "src/basic/String.birch"
  libbirch_line_(300);
  #line 300 "src/basic/String.birch"
  return birch::String(x) + y;
}

#line 306 "src/basic/String.birch"
birch::type::String birch::operator+(const birch::type::Real& x, const birch::type::String& y) {
  #line 306 "src/basic/String.birch"
  libbirch_function_("+", "src/basic/String.birch", 306);
  #line 307 "src/basic/String.birch"
  libbirch_line_(307);
  #line 307 "src/basic/String.birch"
  return birch::String(x) + y;
}

#line 313 "src/basic/String.birch"
birch::type::String birch::operator+(const birch::type::Integer& x, const birch::type::String& y) {
  #line 313 "src/basic/String.birch"
  libbirch_function_("+", "src/basic/String.birch", 313);
  #line 314 "src/basic/String.birch"
  libbirch_line_(314);
  #line 314 "src/basic/String.birch"
  return birch::String(x) + y;
}

#line 320 "src/basic/String.birch"
birch::type::String birch::operator+(const libbirch::DefaultArray<birch::type::Boolean,1>& x, const birch::type::String& y) {
  #line 320 "src/basic/String.birch"
  libbirch_function_("+", "src/basic/String.birch", 320);
  #line 321 "src/basic/String.birch"
  libbirch_line_(321);
  #line 321 "src/basic/String.birch"
  return birch::String(x) + y;
}

#line 327 "src/basic/String.birch"
birch::type::String birch::operator+(const libbirch::DefaultArray<birch::type::Real,1>& x, const birch::type::String& y) {
  #line 327 "src/basic/String.birch"
  libbirch_function_("+", "src/basic/String.birch", 327);
  #line 328 "src/basic/String.birch"
  libbirch_line_(328);
  #line 328 "src/basic/String.birch"
  return birch::String(x) + y;
}

#line 334 "src/basic/String.birch"
birch::type::String birch::operator+(const libbirch::DefaultArray<birch::type::Integer,1>& x, const birch::type::String& y) {
  #line 334 "src/basic/String.birch"
  libbirch_function_("+", "src/basic/String.birch", 334);
  #line 335 "src/basic/String.birch"
  libbirch_line_(335);
  #line 335 "src/basic/String.birch"
  return birch::String(x) + y;
}

#line 341 "src/basic/String.birch"
birch::type::String birch::operator+(const libbirch::DefaultArray<birch::type::Boolean,2>& x, const birch::type::String& y) {
  #line 341 "src/basic/String.birch"
  libbirch_function_("+", "src/basic/String.birch", 341);
  #line 342 "src/basic/String.birch"
  libbirch_line_(342);
  #line 342 "src/basic/String.birch"
  return birch::String(x) + y;
}

#line 348 "src/basic/String.birch"
birch::type::String birch::operator+(const libbirch::DefaultArray<birch::type::Real,2>& x, const birch::type::String& y) {
  #line 348 "src/basic/String.birch"
  libbirch_function_("+", "src/basic/String.birch", 348);
  #line 349 "src/basic/String.birch"
  libbirch_line_(349);
  #line 349 "src/basic/String.birch"
  return birch::String(x) + y;
}

#line 355 "src/basic/String.birch"
birch::type::String birch::operator+(const libbirch::DefaultArray<birch::type::Integer,2>& x, const birch::type::String& y) {
  #line 355 "src/basic/String.birch"
  libbirch_function_("+", "src/basic/String.birch", 355);
  #line 356 "src/basic/String.birch"
  libbirch_line_(356);
  #line 356 "src/basic/String.birch"
  return birch::String(x) + y;
}

#line 362 "src/basic/String.birch"
birch::type::Integer birch::length(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 362 "src/basic/String.birch"
  libbirch_function_("length", "src/basic/String.birch", 362);
  #line 363 "src/basic/String.birch"
return x.length();
  }

#line 371 "src/basic/String.birch"
birch::type::Integer birch::length(const libbirch::DefaultArray<birch::type::String,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 371 "src/basic/String.birch"
  libbirch_function_("length", "src/basic/String.birch", 371);
  #line 372 "src/basic/String.birch"
return x.rows();
  }

