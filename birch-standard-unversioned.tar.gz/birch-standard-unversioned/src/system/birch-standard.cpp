#line 1 "src/system/filesystem.birch"

#if defined(HAVE_FILESYSTEM)
#include <filesystem>
namespace fs = std::filesystem;
#elif defined(HAVE_EXPERIMENTAL_FILESYSTEM)
#include <experimental/filesystem>
namespace fs = std::experimental::filesystem;
#else
#include "boost/filesystem.hpp"
namespace fs = boost::filesystem;
#endif
#line 14 "src/system/filesystem.birch"
birch::type::Integer& birch::READ() {
  #line 14 "src/system/filesystem.birch"
  static birch::type::Integer result = birch::type::Integer(1);
  #line 14 "src/system/filesystem.birch"
  return result;
}

#line 15 "src/system/filesystem.birch"
birch::type::Integer& birch::WRITE() {
  #line 15 "src/system/filesystem.birch"
  static birch::type::Integer result = birch::type::Integer(2);
  #line 15 "src/system/filesystem.birch"
  return result;
}

#line 16 "src/system/filesystem.birch"
birch::type::Integer& birch::APPEND() {
  #line 16 "src/system/filesystem.birch"
  static birch::type::Integer result = birch::type::Integer(3);
  #line 16 "src/system/filesystem.birch"
  return result;
}

#line 23 "src/system/filesystem.birch"
void birch::mkdir(const birch::type::String& path) {
  #line 23 "src/system/filesystem.birch"
  libbirch_function_("mkdir", "src/system/filesystem.birch", 23);
  #line 24 "src/system/filesystem.birch"

  fs::path p = path;
  if (!fs::is_directory(p)) {
    p = p.parent_path();
  }
  fs::create_directories(p);
  }

#line 43 "src/system/filesystem.birch"
birch::type::File birch::fopen(const birch::type::String& path) {
  #line 43 "src/system/filesystem.birch"
  libbirch_function_("fopen", "src/system/filesystem.birch", 43);
  #line 44 "src/system/filesystem.birch"
  libbirch_line_(44);
  #line 44 "src/system/filesystem.birch"
  return birch::fopen(path, birch::READ());
}

#line 59 "src/system/filesystem.birch"
birch::type::File birch::fopen(const birch::type::String& path, const birch::type::Integer& mode) {
  #line 59 "src/system/filesystem.birch"
  libbirch_function_("fopen", "src/system/filesystem.birch", 59);
  #line 60 "src/system/filesystem.birch"
  libbirch_line_(60);
  #line 60 "src/system/filesystem.birch"
  libbirch_assert_(mode == birch::READ() || mode == birch::WRITE() || mode == birch::APPEND());
  #line 61 "src/system/filesystem.birch"
  libbirch_line_(61);
  #line 61 "src/system/filesystem.birch"
  birch::type::String s = libbirch::make<birch::type::String>();
  #line 62 "src/system/filesystem.birch"
  libbirch_line_(62);
  #line 62 "src/system/filesystem.birch"
  if (mode == birch::READ()) {
    #line 63 "src/system/filesystem.birch"
    libbirch_line_(63);
    #line 63 "src/system/filesystem.birch"
    s = birch::type::String("r");
  } else {
    #line 64 "src/system/filesystem.birch"
    libbirch_line_(64);
    #line 64 "src/system/filesystem.birch"
    if (mode == birch::WRITE()) {
      #line 65 "src/system/filesystem.birch"
      libbirch_line_(65);
      #line 65 "src/system/filesystem.birch"
      s = birch::type::String("w");
      #line 66 "src/system/filesystem.birch"

    fs::path p = path;
    if (!p.parent_path().empty()) {
      fs::create_directories(p.parent_path());
    }
        } else {
      #line 72 "src/system/filesystem.birch"
      libbirch_line_(72);
      #line 72 "src/system/filesystem.birch"
      if (mode == birch::APPEND()) {
        #line 73 "src/system/filesystem.birch"
        libbirch_line_(73);
        #line 73 "src/system/filesystem.birch"
        s = birch::type::String("a");
      }
    }
  }
  #line 75 "src/system/filesystem.birch"

  auto f = ::fopen(path.c_str(), s.c_str());
  if (!f) {
    birch::error("could not open file " + path + ".");
  }
  lockf(fileno(f), F_LOCK, 0);
  return f;
  }

#line 88 "src/system/filesystem.birch"
void birch::fflush(const birch::type::File& file) {
  #line 88 "src/system/filesystem.birch"
  libbirch_function_("fflush", "src/system/filesystem.birch", 88);
  #line 89 "src/system/filesystem.birch"

  ::fflush(file);
  }

#line 97 "src/system/filesystem.birch"
birch::type::Boolean birch::feof(const birch::type::File& file) {
  #line 97 "src/system/filesystem.birch"
  libbirch_function_("feof", "src/system/filesystem.birch", 97);
  #line 98 "src/system/filesystem.birch"

  return ::feof(file);
  }

#line 106 "src/system/filesystem.birch"
void birch::fclose(const birch::type::File& file) {
  #line 106 "src/system/filesystem.birch"
  libbirch_function_("fclose", "src/system/filesystem.birch", 106);
  #line 107 "src/system/filesystem.birch"

  ::fclose(file);
  }

#line 115 "src/system/filesystem.birch"
birch::type::String birch::extension(const birch::type::String& path) {
  #line 115 "src/system/filesystem.birch"
  libbirch_function_("extension", "src/system/filesystem.birch", 115);
  #line 116 "src/system/filesystem.birch"
  libbirch_line_(116);
  #line 116 "src/system/filesystem.birch"
  birch::type::String ext = libbirch::make<birch::type::String>();
  #line 117 "src/system/filesystem.birch"

  fs::path f(path);
  ext = f.extension().string();
    #line 121 "src/system/filesystem.birch"
  libbirch_line_(121);
  #line 121 "src/system/filesystem.birch"
  return ext;
}

#line 4 "src/system/stdio.birch"
birch::type::File birch::getStdIn() {
  #line 4 "src/system/stdio.birch"
  libbirch_function_("getStdIn", "src/system/stdio.birch", 4);
  #line 5 "src/system/stdio.birch"

  return ::stdin;
  }

#line 13 "src/system/stdio.birch"
birch::type::File birch::getStdOut() {
  #line 13 "src/system/stdio.birch"
  libbirch_function_("getStdOut", "src/system/stdio.birch", 13);
  #line 14 "src/system/stdio.birch"

  return ::stdout;
  }

#line 22 "src/system/stdio.birch"
birch::type::File birch::getStdErr() {
  #line 22 "src/system/stdio.birch"
  libbirch_function_("getStdErr", "src/system/stdio.birch", 22);
  #line 23 "src/system/stdio.birch"

  return ::stderr;
  }

#line 31 "src/system/stdio.birch"
libbirch::Shared<birch::type::InputStream>& birch::stdin() {
  #line 31 "src/system/stdio.birch"
  static libbirch::Shared<birch::type::InputStream> result = birch::InputStream(birch::getStdIn());
  #line 31 "src/system/stdio.birch"
  return result;
}

#line 36 "src/system/stdio.birch"
libbirch::Shared<birch::type::OutputStream>& birch::stdout() {
  #line 36 "src/system/stdio.birch"
  static libbirch::Shared<birch::type::OutputStream> result = birch::OutputStream(birch::getStdOut());
  #line 36 "src/system/stdio.birch"
  return result;
}

#line 41 "src/system/stdio.birch"
libbirch::Shared<birch::type::OutputStream>& birch::stderr() {
  #line 41 "src/system/stdio.birch"
  static libbirch::Shared<birch::type::OutputStream> result = birch::OutputStream(birch::getStdErr());
  #line 41 "src/system/stdio.birch"
  return result;
}

#line 1 "src/system/system.birch"

#ifdef __FreeBSD__
#include <sys/wait.h>  /* For WIF.. */
#endif
#line 14 "src/system/system.birch"
birch::type::Integer birch::system(const birch::type::String& cmd) {
  #line 14 "src/system/system.birch"
  libbirch_function_("system", "src/system/system.birch", 14);
  #line 15 "src/system/system.birch"

  int code;
  int status = std::system(cmd.c_str());
  if (WIFEXITED(status)) {
    code = WEXITSTATUS(status);
  } else if (WIFSIGNALED(status)) {
    code = WTERMSIG(status);
  } else if (WIFSTOPPED(status)) {
    code = WSTOPSIG(status);
  } else {
    code = status;
  }
  return code;
  }

#line 36 "src/system/system.birch"
void birch::exit(const birch::type::Integer& code) {
  #line 36 "src/system/system.birch"
  libbirch_function_("exit", "src/system/system.birch", 36);
  #line 37 "src/system/system.birch"

  std::exit(code);
  }

