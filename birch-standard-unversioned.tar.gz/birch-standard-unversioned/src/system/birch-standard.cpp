#line 1 "src/system/filesystem.birch"

#include "boost/filesystem.hpp"
#line 5 "src/system/filesystem.birch"
birch::type::Integer& birch::READ() {
  #line 5 "src/system/filesystem.birch"
  static birch::type::Integer result = birch::type::Integer(1);
  #line 5 "src/system/filesystem.birch"
  return result;
}

#line 6 "src/system/filesystem.birch"
birch::type::Integer& birch::WRITE() {
  #line 6 "src/system/filesystem.birch"
  static birch::type::Integer result = birch::type::Integer(2);
  #line 6 "src/system/filesystem.birch"
  return result;
}

#line 7 "src/system/filesystem.birch"
birch::type::Integer& birch::APPEND() {
  #line 7 "src/system/filesystem.birch"
  static birch::type::Integer result = birch::type::Integer(3);
  #line 7 "src/system/filesystem.birch"
  return result;
}

#line 14 "src/system/filesystem.birch"
void birch::mkdir(const birch::type::String& path, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/system/filesystem.birch"
  libbirch_function_("mkdir", "src/system/filesystem.birch", 14);
  #line 15 "src/system/filesystem.birch"

  boost::filesystem::path p = path;
  if (!boost::filesystem::is_directory(p)) {
    p = p.parent_path();
  }
  boost::filesystem::create_directories(p);
  }

#line 34 "src/system/filesystem.birch"
birch::type::File birch::fopen(const birch::type::String& path, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "src/system/filesystem.birch"
  libbirch_function_("fopen", "src/system/filesystem.birch", 34);
  #line 35 "src/system/filesystem.birch"
  libbirch_line_(35);
  #line 35 "src/system/filesystem.birch"
  return birch::fopen(path, birch::READ(), handler_);
}

#line 50 "src/system/filesystem.birch"
birch::type::File birch::fopen(const birch::type::String& path, const birch::type::Integer& mode, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "src/system/filesystem.birch"
  libbirch_function_("fopen", "src/system/filesystem.birch", 50);
  #line 51 "src/system/filesystem.birch"
  libbirch_line_(51);
  #line 51 "src/system/filesystem.birch"
  libbirch_assert_(mode == birch::READ() || mode == birch::WRITE() || mode == birch::APPEND());
  #line 52 "src/system/filesystem.birch"
  libbirch_line_(52);
  #line 52 "src/system/filesystem.birch"
  birch::type::String s;
  #line 53 "src/system/filesystem.birch"
  libbirch_line_(53);
  #line 53 "src/system/filesystem.birch"
  if (mode == birch::READ()) {
    #line 54 "src/system/filesystem.birch"
    libbirch_line_(54);
    #line 54 "src/system/filesystem.birch"
    s = birch::type::String("r");
  } else {
    #line 55 "src/system/filesystem.birch"
    libbirch_line_(55);
    #line 55 "src/system/filesystem.birch"
    if (mode == birch::WRITE()) {
      #line 56 "src/system/filesystem.birch"
      libbirch_line_(56);
      #line 56 "src/system/filesystem.birch"
      s = birch::type::String("w");
      #line 57 "src/system/filesystem.birch"

    boost::filesystem::path p = path;
    if (!p.parent_path().empty()) {
      boost::filesystem::create_directories(p.parent_path());
    }
        } else {
      #line 63 "src/system/filesystem.birch"
      libbirch_line_(63);
      #line 63 "src/system/filesystem.birch"
      if (mode == birch::APPEND()) {
        #line 64 "src/system/filesystem.birch"
        libbirch_line_(64);
        #line 64 "src/system/filesystem.birch"
        s = birch::type::String("a");
      }
    }
  }
  #line 66 "src/system/filesystem.birch"

  auto f = ::fopen(path.c_str(), s.c_str());
  if (!f) {
    birch::error("could not open file " + path + ".");
  }
  lockf(fileno(f), F_LOCK, 0);
  return f;
  }

#line 79 "src/system/filesystem.birch"
void birch::fflush(const birch::type::File& file, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 79 "src/system/filesystem.birch"
  libbirch_function_("fflush", "src/system/filesystem.birch", 79);
  #line 80 "src/system/filesystem.birch"

  ::fflush(file);
  }

#line 88 "src/system/filesystem.birch"
void birch::fclose(const birch::type::File& file, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 88 "src/system/filesystem.birch"
  libbirch_function_("fclose", "src/system/filesystem.birch", 88);
  #line 89 "src/system/filesystem.birch"

  ::fclose(file);
  }

#line 97 "src/system/filesystem.birch"
birch::type::String birch::extension(const birch::type::String& path, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 97 "src/system/filesystem.birch"
  libbirch_function_("extension", "src/system/filesystem.birch", 97);
  #line 98 "src/system/filesystem.birch"
  libbirch_line_(98);
  #line 98 "src/system/filesystem.birch"
  birch::type::String ext;
  #line 99 "src/system/filesystem.birch"

  boost::filesystem::path f(path);
  ext = f.extension().string();
    #line 103 "src/system/filesystem.birch"
  libbirch_line_(103);
  #line 103 "src/system/filesystem.birch"
  return ext;
}

#line 4 "src/system/stdio.birch"
birch::type::File birch::getStdIn(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 4 "src/system/stdio.birch"
  libbirch_function_("getStdIn", "src/system/stdio.birch", 4);
  #line 5 "src/system/stdio.birch"

  return ::stdin;
  }

#line 13 "src/system/stdio.birch"
birch::type::File birch::getStdOut(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 13 "src/system/stdio.birch"
  libbirch_function_("getStdOut", "src/system/stdio.birch", 13);
  #line 14 "src/system/stdio.birch"

  return ::stdout;
  }

#line 22 "src/system/stdio.birch"
birch::type::File birch::getStdErr(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "src/system/stdio.birch"
  libbirch_function_("getStdErr", "src/system/stdio.birch", 22);
  #line 23 "src/system/stdio.birch"

  return ::stderr;
  }

#line 31 "src/system/stdio.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InputStream>>& birch::stdin() {
  #line 31 "src/system/stdio.birch"
  static libbirch::Lazy<libbirch::Shared<birch::type::InputStream>> result = birch::InputStream(birch::getStdIn());
  #line 31 "src/system/stdio.birch"
  return result;
}

#line 36 "src/system/stdio.birch"
libbirch::Lazy<libbirch::Shared<birch::type::OutputStream>>& birch::stdout() {
  #line 36 "src/system/stdio.birch"
  static libbirch::Lazy<libbirch::Shared<birch::type::OutputStream>> result = birch::OutputStream(birch::getStdOut());
  #line 36 "src/system/stdio.birch"
  return result;
}

#line 41 "src/system/stdio.birch"
libbirch::Lazy<libbirch::Shared<birch::type::OutputStream>>& birch::stderr() {
  #line 41 "src/system/stdio.birch"
  static libbirch::Lazy<libbirch::Shared<birch::type::OutputStream>> result = birch::OutputStream(birch::getStdErr());
  #line 41 "src/system/stdio.birch"
  return result;
}

#line 1 "src/system/system.birch"

#ifdef __FreeBSD__
#include <sys/wait.h>  /* For WIF.. */
#endif
#line 14 "src/system/system.birch"
birch::type::Integer birch::system(const birch::type::String& cmd, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "src/system/system.birch"
  libbirch_function_("system", "src/system/system.birch", 14);
  #line 15 "src/system/system.birch"

  int code;
  int status = std::system(cmd.c_str());
  if (WIFEXITED(status)) {
    code = WEXITSTATUS(status);
  } else if (WIFSIGNALED(status)) {
    code = WTERMSIG(status);
  } else if (WIFSTOPPED(status)) {
    code = WSTOPSIG(status);
  } else {
    code = status;
  }
  return code;
  }

#line 36 "src/system/system.birch"
void birch::exit(const birch::type::Integer& code, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "src/system/system.birch"
  libbirch_function_("exit", "src/system/system.birch", 36);
  #line 37 "src/system/system.birch"

  std::exit(code);
  }

