#line 15 "birch/model/Model.birch"
birch::type::Model::Model(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 15 "birch/model/Model.birch"
    super_type_() {
  //
}

#line 19 "birch/model/Model.birch"
void birch::type::Model::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "birch/model/Model.birch"
  libbirch_function_("simulate", "birch/model/Model.birch", 19);
}

#line 26 "birch/model/Model.birch"
void birch::type::Model::simulate(const birch::type::Integer& t, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "birch/model/Model.birch"
  libbirch_function_("simulate", "birch/model/Model.birch", 26);
}

#line 33 "birch/model/Model.birch"
void birch::type::Model::forecast(const birch::type::Integer& t, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "birch/model/Model.birch"
  libbirch_function_("forecast", "birch/model/Model.birch", 33);
}

#line 41 "birch/model/Model.birch"
birch::type::Integer birch::type::Model::size(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "birch/model/Model.birch"
  libbirch_function_("size", "birch/model/Model.birch", 41);
  #line 42 "birch/model/Model.birch"
  libbirch_line_(42);
  #line 42 "birch/model/Model.birch"
  return birch::type::Integer(0);
}

