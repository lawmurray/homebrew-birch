#line 4 "birch/distribution/AddBoundedDiscrete.birch"
birch::type::AddBoundedDiscrete::AddBoundedDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>& x1, const libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>& x2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/AddBoundedDiscrete.birch"
    super_type_(),
    #line 9 "birch/distribution/AddBoundedDiscrete.birch"
    x1(x1),
    #line 14 "birch/distribution/AddBoundedDiscrete.birch"
    x2(x2),
    #line 19 "birch/distribution/AddBoundedDiscrete.birch"
    x(),
    #line 24 "birch/distribution/AddBoundedDiscrete.birch"
    x0(),
    #line 30 "birch/distribution/AddBoundedDiscrete.birch"
    z(),
    #line 35 "birch/distribution/AddBoundedDiscrete.birch"
    Z(),
    #line 43 "birch/distribution/AddBoundedDiscrete.birch"
    alreadyUpdated(false) {
  //
}

#line 45 "birch/distribution/AddBoundedDiscrete.birch"
void birch::type::AddBoundedDiscrete::enumerate(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "birch/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("enumerate", "birch/distribution/AddBoundedDiscrete.birch", 45);
  #line 46 "birch/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(46);
  #line 46 "birch/distribution/AddBoundedDiscrete.birch"
  if (!this_()->x.query() || this_()->x.get() != x) {
    #line 47 "birch/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(47);
    #line 47 "birch/distribution/AddBoundedDiscrete.birch"
    auto l = birch::max(this_()->x1->lower(handler_).get(), x - this_()->x2->upper(handler_).get(), handler_);
    #line 48 "birch/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(48);
    #line 48 "birch/distribution/AddBoundedDiscrete.birch"
    auto u = birch::min(this_()->x1->upper(handler_).get(), x - this_()->x2->lower(handler_).get(), handler_);
    #line 50 "birch/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(50);
    #line 50 "birch/distribution/AddBoundedDiscrete.birch"
    this_()->x0 = l;
    #line 51 "birch/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(51);
    #line 51 "birch/distribution/AddBoundedDiscrete.birch"
    this_()->Z = 0.0;
    #line 52 "birch/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(52);
    #line 52 "birch/distribution/AddBoundedDiscrete.birch"
    if (l <= u) {
      #line 54 "birch/distribution/AddBoundedDiscrete.birch"
      libbirch_line_(54);
      #line 54 "birch/distribution/AddBoundedDiscrete.birch"
      this_()->z = birch::vector(0.0, u - l + birch::type::Integer(1), handler_);
      #line 55 "birch/distribution/AddBoundedDiscrete.birch"
      libbirch_line_(55);
      #line 55 "birch/distribution/AddBoundedDiscrete.birch"
      for (auto n = l; n <= u; ++n) {
        #line 56 "birch/distribution/AddBoundedDiscrete.birch"
        libbirch_line_(56);
        #line 56 "birch/distribution/AddBoundedDiscrete.birch"
        this_()->z.set(libbirch::make_slice(n - l + birch::type::Integer(1) - 1), birch::exp(this_()->x1->logpdf(n, handler_) + this_()->x2->logpdf(x - n, handler_), handler_));
        #line 57 "birch/distribution/AddBoundedDiscrete.birch"
        libbirch_line_(57);
        #line 57 "birch/distribution/AddBoundedDiscrete.birch"
        this_()->Z = this_()->Z + this_()->z.get(libbirch::make_slice(n - l + birch::type::Integer(1) - 1));
      }
    }
    #line 60 "birch/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(60);
    #line 60 "birch/distribution/AddBoundedDiscrete.birch"
    this_()->x = x;
  }
}

#line 68 "birch/distribution/AddBoundedDiscrete.birch"
birch::type::Integer birch::type::AddBoundedDiscrete::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 68 "birch/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("simulate", "birch/distribution/AddBoundedDiscrete.birch", 68);
  #line 69 "birch/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(69);
  #line 69 "birch/distribution/AddBoundedDiscrete.birch"
  if (this_()->value.query()) {
    #line 70 "birch/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(70);
    #line 70 "birch/distribution/AddBoundedDiscrete.birch"
    return birch::simulate_delta(this_()->value.get(), handler_);
  } else {
    #line 72 "birch/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(72);
    #line 72 "birch/distribution/AddBoundedDiscrete.birch"
    return birch::simulate_delta(this_()->x1->simulate(handler_) + this_()->x2->simulate(handler_), handler_);
  }
}

#line 84 "birch/distribution/AddBoundedDiscrete.birch"
birch::type::Real birch::type::AddBoundedDiscrete::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 84 "birch/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("logpdf", "birch/distribution/AddBoundedDiscrete.birch", 84);
  #line 85 "birch/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(85);
  #line 85 "birch/distribution/AddBoundedDiscrete.birch"
  if (this_()->value.query()) {
    #line 86 "birch/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(86);
    #line 86 "birch/distribution/AddBoundedDiscrete.birch"
    return birch::logpdf_delta(x, this_()->value.get(), handler_);
  } else {
    #line 88 "birch/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(88);
    #line 88 "birch/distribution/AddBoundedDiscrete.birch"
    this_()->enumerate(x, handler_);
    #line 89 "birch/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(89);
    #line 89 "birch/distribution/AddBoundedDiscrete.birch"
    return birch::log(this_()->Z, handler_);
  }
}

#line 102 "birch/distribution/AddBoundedDiscrete.birch"
void birch::type::AddBoundedDiscrete::update(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 102 "birch/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("update", "birch/distribution/AddBoundedDiscrete.birch", 102);
  #line 103 "birch/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(103);
  #line 103 "birch/distribution/AddBoundedDiscrete.birch"
  if (!this_()->alreadyUpdated) {
    #line 105 "birch/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(105);
    #line 105 "birch/distribution/AddBoundedDiscrete.birch"
    this_()->enumerate(x, handler_);
    #line 106 "birch/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(106);
    #line 106 "birch/distribution/AddBoundedDiscrete.birch"
    auto n = birch::simulate_categorical(this_()->z, this_()->Z, handler_) + this_()->x0 - birch::type::Integer(1);
    #line 107 "birch/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(107);
    #line 107 "birch/distribution/AddBoundedDiscrete.birch"
    this_()->x1->clamp(n, handler_);
    #line 108 "birch/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(108);
    #line 108 "birch/distribution/AddBoundedDiscrete.birch"
    this_()->x2->clamp(x - n, handler_);
    #line 109 "birch/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(109);
    #line 109 "birch/distribution/AddBoundedDiscrete.birch"
    this_()->alreadyUpdated = true;
  }
}

#line 117 "birch/distribution/AddBoundedDiscrete.birch"
libbirch::Optional<birch::type::Real> birch::type::AddBoundedDiscrete::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 117 "birch/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("cdf", "birch/distribution/AddBoundedDiscrete.birch", 117);
  #line 118 "birch/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(118);
  #line 118 "birch/distribution/AddBoundedDiscrete.birch"
  auto P = 0.0;
  #line 119 "birch/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(119);
  #line 119 "birch/distribution/AddBoundedDiscrete.birch"
  for (auto n = this_()->lower(handler_).get(); n <= x; ++n) {
    #line 120 "birch/distribution/AddBoundedDiscrete.birch"
    libbirch_line_(120);
    #line 120 "birch/distribution/AddBoundedDiscrete.birch"
    P = P + this_()->pdf(n, handler_);
  }
  #line 122 "birch/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(122);
  #line 122 "birch/distribution/AddBoundedDiscrete.birch"
  return P;
}

#line 125 "birch/distribution/AddBoundedDiscrete.birch"
libbirch::Optional<birch::type::Integer> birch::type::AddBoundedDiscrete::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 125 "birch/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("lower", "birch/distribution/AddBoundedDiscrete.birch", 125);
  #line 126 "birch/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(126);
  #line 126 "birch/distribution/AddBoundedDiscrete.birch"
  return this_()->x1->lower(handler_).get() + this_()->x2->lower(handler_).get();
}

#line 129 "birch/distribution/AddBoundedDiscrete.birch"
libbirch::Optional<birch::type::Integer> birch::type::AddBoundedDiscrete::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 129 "birch/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("upper", "birch/distribution/AddBoundedDiscrete.birch", 129);
  #line 130 "birch/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(130);
  #line 130 "birch/distribution/AddBoundedDiscrete.birch"
  return this_()->x1->upper(handler_).get() + this_()->x2->upper(handler_).get();
}

#line 133 "birch/distribution/AddBoundedDiscrete.birch"
void birch::type::AddBoundedDiscrete::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 133 "birch/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("link", "birch/distribution/AddBoundedDiscrete.birch", 133);
}

#line 139 "birch/distribution/AddBoundedDiscrete.birch"
void birch::type::AddBoundedDiscrete::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 139 "birch/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("unlink", "birch/distribution/AddBoundedDiscrete.birch", 139);
}

#line 146 "birch/distribution/AddBoundedDiscrete.birch"
libbirch::Lazy<libbirch::Shared<birch::type::AddBoundedDiscrete>> birch::AddBoundedDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>& x1, const libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>& x2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 146 "birch/distribution/AddBoundedDiscrete.birch"
  libbirch_function_("AddBoundedDiscrete", "birch/distribution/AddBoundedDiscrete.birch", 146);
  #line 148 "birch/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(148);
  #line 148 "birch/distribution/AddBoundedDiscrete.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::AddBoundedDiscrete>> m(x1, x2);
  #line 149 "birch/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(149);
  #line 149 "birch/distribution/AddBoundedDiscrete.birch"
  m->link(handler_);
  #line 150 "birch/distribution/AddBoundedDiscrete.birch"
  libbirch_line_(150);
  #line 150 "birch/distribution/AddBoundedDiscrete.birch"
  return m;
}

#line 1 "birch/distribution/Bernoulli.birch"
birch::type::Bernoulli::Bernoulli(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/distribution/Bernoulli.birch"
    super_type_(),
    #line 8 "birch/distribution/Bernoulli.birch"
    _u0961(_u0961) {
  //
}

#line 10 "birch/distribution/Bernoulli.birch"
birch::type::Boolean birch::type::Bernoulli::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "birch/distribution/Bernoulli.birch"
  libbirch_function_("supportsLazy", "birch/distribution/Bernoulli.birch", 10);
  #line 11 "birch/distribution/Bernoulli.birch"
  libbirch_line_(11);
  #line 11 "birch/distribution/Bernoulli.birch"
  return true;
}

#line 14 "birch/distribution/Bernoulli.birch"
birch::type::Boolean birch::type::Bernoulli::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "birch/distribution/Bernoulli.birch"
  libbirch_function_("simulate", "birch/distribution/Bernoulli.birch", 14);
  #line 15 "birch/distribution/Bernoulli.birch"
  libbirch_line_(15);
  #line 15 "birch/distribution/Bernoulli.birch"
  return birch::simulate_bernoulli(this_()->_u0961->value(handler_), handler_);
}

#line 18 "birch/distribution/Bernoulli.birch"
libbirch::Optional<birch::type::Boolean> birch::type::Bernoulli::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "birch/distribution/Bernoulli.birch"
  libbirch_function_("simulateLazy", "birch/distribution/Bernoulli.birch", 18);
  #line 19 "birch/distribution/Bernoulli.birch"
  libbirch_line_(19);
  #line 19 "birch/distribution/Bernoulli.birch"
  return birch::simulate_bernoulli(this_()->_u0961->get(handler_), handler_);
}

#line 22 "birch/distribution/Bernoulli.birch"
birch::type::Real birch::type::Bernoulli::logpdf(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "birch/distribution/Bernoulli.birch"
  libbirch_function_("logpdf", "birch/distribution/Bernoulli.birch", 22);
  #line 23 "birch/distribution/Bernoulli.birch"
  libbirch_line_(23);
  #line 23 "birch/distribution/Bernoulli.birch"
  return birch::logpdf_bernoulli(x, this_()->_u0961->value(handler_), handler_);
}

#line 26 "birch/distribution/Bernoulli.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::Bernoulli::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Boolean>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "birch/distribution/Bernoulli.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/Bernoulli.birch", 26);
  #line 27 "birch/distribution/Bernoulli.birch"
  libbirch_line_(27);
  #line 27 "birch/distribution/Bernoulli.birch"
  return birch::logpdf_lazy_bernoulli(x, this_()->_u0961, handler_);
}

#line 30 "birch/distribution/Bernoulli.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Boolean>>> birch::type::Bernoulli::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "birch/distribution/Bernoulli.birch"
  libbirch_function_("graft", "birch/distribution/Bernoulli.birch", 30);
  #line 31 "birch/distribution/Bernoulli.birch"
  libbirch_line_(31);
  #line 31 "birch/distribution/Bernoulli.birch"
  this_()->prune(handler_);
  #line 32 "birch/distribution/Bernoulli.birch"
  libbirch_line_(32);
  #line 32 "birch/distribution/Bernoulli.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Beta>>> m;
  #line 33 "birch/distribution/Bernoulli.birch"
  libbirch_line_(33);
  #line 33 "birch/distribution/Bernoulli.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Boolean>>> r = shared_from_this_();
  #line 36 "birch/distribution/Bernoulli.birch"
  libbirch_line_(36);
  #line 36 "birch/distribution/Bernoulli.birch"
  if ((m = this_()->_u0961->graftBeta(handler_)).query()) {
    #line 37 "birch/distribution/Bernoulli.birch"
    libbirch_line_(37);
    #line 37 "birch/distribution/Bernoulli.birch"
    r = birch::BetaBernoulli(m.get(), handler_);
  }
  #line 40 "birch/distribution/Bernoulli.birch"
  libbirch_line_(40);
  #line 40 "birch/distribution/Bernoulli.birch"
  return r;
}

#line 43 "birch/distribution/Bernoulli.birch"
void birch::type::Bernoulli::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "birch/distribution/Bernoulli.birch"
  libbirch_function_("write", "birch/distribution/Bernoulli.birch", 43);
  #line 44 "birch/distribution/Bernoulli.birch"
  libbirch_line_(44);
  #line 44 "birch/distribution/Bernoulli.birch"
  this_()->prune(handler_);
  #line 45 "birch/distribution/Bernoulli.birch"
  libbirch_line_(45);
  #line 45 "birch/distribution/Bernoulli.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Bernoulli"), handler_);
  #line 46 "birch/distribution/Bernoulli.birch"
  libbirch_line_(46);
  #line 46 "birch/distribution/Bernoulli.birch"
  buffer->set(birch::type::String("ρ"), this_()->_u0961, handler_);
}

#line 53 "birch/distribution/Bernoulli.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Bernoulli>> birch::Bernoulli(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "birch/distribution/Bernoulli.birch"
  libbirch_function_("Bernoulli", "birch/distribution/Bernoulli.birch", 53);
  #line 54 "birch/distribution/Bernoulli.birch"
  libbirch_line_(54);
  #line 54 "birch/distribution/Bernoulli.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Bernoulli>>>(_u0961, handler_);
}

#line 60 "birch/distribution/Bernoulli.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Bernoulli>> birch::Bernoulli(const birch::type::Real& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "birch/distribution/Bernoulli.birch"
  libbirch_function_("Bernoulli", "birch/distribution/Bernoulli.birch", 60);
  #line 61 "birch/distribution/Bernoulli.birch"
  libbirch_line_(61);
  #line 61 "birch/distribution/Bernoulli.birch"
  return birch::Bernoulli(birch::box(_u0961, handler_), handler_);
}

#line 4 "birch/distribution/Beta.birch"
birch::type::Beta::Beta(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/Beta.birch"
    super_type_(),
    #line 9 "birch/distribution/Beta.birch"
    _u0945(_u0945),
    #line 14 "birch/distribution/Beta.birch"
    _u0946(_u0946) {
  //
}

#line 16 "birch/distribution/Beta.birch"
birch::type::Boolean birch::type::Beta::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "birch/distribution/Beta.birch"
  libbirch_function_("supportsLazy", "birch/distribution/Beta.birch", 16);
  #line 17 "birch/distribution/Beta.birch"
  libbirch_line_(17);
  #line 17 "birch/distribution/Beta.birch"
  return true;
}

#line 20 "birch/distribution/Beta.birch"
birch::type::Real birch::type::Beta::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "birch/distribution/Beta.birch"
  libbirch_function_("simulate", "birch/distribution/Beta.birch", 20);
  #line 21 "birch/distribution/Beta.birch"
  libbirch_line_(21);
  #line 21 "birch/distribution/Beta.birch"
  return birch::simulate_beta(this_()->_u0945->value(handler_), this_()->_u0946->value(handler_), handler_);
}

#line 24 "birch/distribution/Beta.birch"
libbirch::Optional<birch::type::Real> birch::type::Beta::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "birch/distribution/Beta.birch"
  libbirch_function_("simulateLazy", "birch/distribution/Beta.birch", 24);
  #line 25 "birch/distribution/Beta.birch"
  libbirch_line_(25);
  #line 25 "birch/distribution/Beta.birch"
  return birch::simulate_beta(this_()->_u0945->get(handler_), this_()->_u0946->get(handler_), handler_);
}

#line 28 "birch/distribution/Beta.birch"
birch::type::Real birch::type::Beta::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "birch/distribution/Beta.birch"
  libbirch_function_("logpdf", "birch/distribution/Beta.birch", 28);
  #line 29 "birch/distribution/Beta.birch"
  libbirch_line_(29);
  #line 29 "birch/distribution/Beta.birch"
  return birch::logpdf_beta(x, this_()->_u0945->value(handler_), this_()->_u0946->value(handler_), handler_);
}

#line 32 "birch/distribution/Beta.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::Beta::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "birch/distribution/Beta.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/Beta.birch", 32);
  #line 33 "birch/distribution/Beta.birch"
  libbirch_line_(33);
  #line 33 "birch/distribution/Beta.birch"
  return birch::logpdf_lazy_beta(x, this_()->_u0945, this_()->_u0946, handler_);
}

#line 36 "birch/distribution/Beta.birch"
libbirch::Optional<birch::type::Real> birch::type::Beta::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "birch/distribution/Beta.birch"
  libbirch_function_("cdf", "birch/distribution/Beta.birch", 36);
  #line 37 "birch/distribution/Beta.birch"
  libbirch_line_(37);
  #line 37 "birch/distribution/Beta.birch"
  return birch::cdf_beta(x, this_()->_u0945->value(handler_), this_()->_u0946->value(handler_), handler_);
}

#line 40 "birch/distribution/Beta.birch"
libbirch::Optional<birch::type::Real> birch::type::Beta::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "birch/distribution/Beta.birch"
  libbirch_function_("quantile", "birch/distribution/Beta.birch", 40);
  #line 41 "birch/distribution/Beta.birch"
  libbirch_line_(41);
  #line 41 "birch/distribution/Beta.birch"
  return birch::quantile_beta(P, this_()->_u0945->value(handler_), this_()->_u0946->value(handler_), handler_);
}

#line 44 "birch/distribution/Beta.birch"
libbirch::Optional<birch::type::Real> birch::type::Beta::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "birch/distribution/Beta.birch"
  libbirch_function_("lower", "birch/distribution/Beta.birch", 44);
  #line 45 "birch/distribution/Beta.birch"
  libbirch_line_(45);
  #line 45 "birch/distribution/Beta.birch"
  return 0.0;
}

#line 48 "birch/distribution/Beta.birch"
libbirch::Optional<birch::type::Real> birch::type::Beta::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "birch/distribution/Beta.birch"
  libbirch_function_("upper", "birch/distribution/Beta.birch", 48);
  #line 49 "birch/distribution/Beta.birch"
  libbirch_line_(49);
  #line 49 "birch/distribution/Beta.birch"
  return 1.0;
}

#line 52 "birch/distribution/Beta.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Beta>>> birch::type::Beta::graftBeta(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "birch/distribution/Beta.birch"
  libbirch_function_("graftBeta", "birch/distribution/Beta.birch", 52);
  #line 53 "birch/distribution/Beta.birch"
  libbirch_line_(53);
  #line 53 "birch/distribution/Beta.birch"
  this_()->prune(handler_);
  #line 54 "birch/distribution/Beta.birch"
  libbirch_line_(54);
  #line 54 "birch/distribution/Beta.birch"
  return shared_from_this_();
}

#line 57 "birch/distribution/Beta.birch"
void birch::type::Beta::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 57 "birch/distribution/Beta.birch"
  libbirch_function_("write", "birch/distribution/Beta.birch", 57);
  #line 58 "birch/distribution/Beta.birch"
  libbirch_line_(58);
  #line 58 "birch/distribution/Beta.birch"
  this_()->prune(handler_);
  #line 59 "birch/distribution/Beta.birch"
  libbirch_line_(59);
  #line 59 "birch/distribution/Beta.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Beta"), handler_);
  #line 60 "birch/distribution/Beta.birch"
  libbirch_line_(60);
  #line 60 "birch/distribution/Beta.birch"
  buffer->set(birch::type::String("α"), this_()->_u0945, handler_);
  #line 61 "birch/distribution/Beta.birch"
  libbirch_line_(61);
  #line 61 "birch/distribution/Beta.birch"
  buffer->set(birch::type::String("β"), this_()->_u0946, handler_);
}

#line 68 "birch/distribution/Beta.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Beta>> birch::Beta(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 68 "birch/distribution/Beta.birch"
  libbirch_function_("Beta", "birch/distribution/Beta.birch", 68);
  #line 69 "birch/distribution/Beta.birch"
  libbirch_line_(69);
  #line 69 "birch/distribution/Beta.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Beta>>>(_u0945, _u0946, handler_);
}

#line 75 "birch/distribution/Beta.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Beta>> birch::Beta(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 75 "birch/distribution/Beta.birch"
  libbirch_function_("Beta", "birch/distribution/Beta.birch", 75);
  #line 76 "birch/distribution/Beta.birch"
  libbirch_line_(76);
  #line 76 "birch/distribution/Beta.birch"
  return birch::Beta(_u0945, birch::box(_u0946, handler_), handler_);
}

#line 82 "birch/distribution/Beta.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Beta>> birch::Beta(const birch::type::Real& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 82 "birch/distribution/Beta.birch"
  libbirch_function_("Beta", "birch/distribution/Beta.birch", 82);
  #line 83 "birch/distribution/Beta.birch"
  libbirch_line_(83);
  #line 83 "birch/distribution/Beta.birch"
  return birch::Beta(birch::box(_u0945, handler_), _u0946, handler_);
}

#line 89 "birch/distribution/Beta.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Beta>> birch::Beta(const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 89 "birch/distribution/Beta.birch"
  libbirch_function_("Beta", "birch/distribution/Beta.birch", 89);
  #line 90 "birch/distribution/Beta.birch"
  libbirch_line_(90);
  #line 90 "birch/distribution/Beta.birch"
  return birch::Beta(birch::box(_u0945, handler_), birch::box(_u0946, handler_), handler_);
}

#line 4 "birch/distribution/BetaBernoulli.birch"
birch::type::BetaBernoulli::BetaBernoulli(const libbirch::Lazy<libbirch::Shared<birch::type::Beta>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/BetaBernoulli.birch"
    super_type_(),
    #line 8 "birch/distribution/BetaBernoulli.birch"
    _u0961(_u0961) {
  //
}

#line 10 "birch/distribution/BetaBernoulli.birch"
birch::type::Boolean birch::type::BetaBernoulli::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "birch/distribution/BetaBernoulli.birch"
  libbirch_function_("supportsLazy", "birch/distribution/BetaBernoulli.birch", 10);
  #line 11 "birch/distribution/BetaBernoulli.birch"
  libbirch_line_(11);
  #line 11 "birch/distribution/BetaBernoulli.birch"
  return true;
}

#line 14 "birch/distribution/BetaBernoulli.birch"
birch::type::Boolean birch::type::BetaBernoulli::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "birch/distribution/BetaBernoulli.birch"
  libbirch_function_("simulate", "birch/distribution/BetaBernoulli.birch", 14);
  #line 15 "birch/distribution/BetaBernoulli.birch"
  libbirch_line_(15);
  #line 15 "birch/distribution/BetaBernoulli.birch"
  return birch::simulate_beta_bernoulli(this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0946->value(handler_), handler_);
}

#line 18 "birch/distribution/BetaBernoulli.birch"
libbirch::Optional<birch::type::Boolean> birch::type::BetaBernoulli::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "birch/distribution/BetaBernoulli.birch"
  libbirch_function_("simulateLazy", "birch/distribution/BetaBernoulli.birch", 18);
  #line 19 "birch/distribution/BetaBernoulli.birch"
  libbirch_line_(19);
  #line 19 "birch/distribution/BetaBernoulli.birch"
  return birch::simulate_beta_bernoulli(this_()->_u0961->_u0945->get(handler_), this_()->_u0961->_u0946->get(handler_), handler_);
}

#line 22 "birch/distribution/BetaBernoulli.birch"
birch::type::Real birch::type::BetaBernoulli::logpdf(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "birch/distribution/BetaBernoulli.birch"
  libbirch_function_("logpdf", "birch/distribution/BetaBernoulli.birch", 22);
  #line 23 "birch/distribution/BetaBernoulli.birch"
  libbirch_line_(23);
  #line 23 "birch/distribution/BetaBernoulli.birch"
  return birch::logpdf_beta_bernoulli(x, this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0946->value(handler_), handler_);
}

#line 26 "birch/distribution/BetaBernoulli.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::BetaBernoulli::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Boolean>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "birch/distribution/BetaBernoulli.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/BetaBernoulli.birch", 26);
  #line 27 "birch/distribution/BetaBernoulli.birch"
  libbirch_line_(27);
  #line 27 "birch/distribution/BetaBernoulli.birch"
  return birch::logpdf_lazy_beta_bernoulli(x, this_()->_u0961->_u0945, this_()->_u0961->_u0946, handler_);
}

#line 30 "birch/distribution/BetaBernoulli.birch"
void birch::type::BetaBernoulli::update(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "birch/distribution/BetaBernoulli.birch"
  libbirch_function_("update", "birch/distribution/BetaBernoulli.birch", 30);
  #line 31 "birch/distribution/BetaBernoulli.birch"
  libbirch_line_(31);
  #line 31 "birch/distribution/BetaBernoulli.birch"
  libbirch::tie(this_()->_u0961->_u0945, this_()->_u0961->_u0946) = birch::box(birch::update_beta_bernoulli(x, this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0946->value(handler_), handler_), handler_);
}

#line 34 "birch/distribution/BetaBernoulli.birch"
void birch::type::BetaBernoulli::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Boolean>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "birch/distribution/BetaBernoulli.birch"
  libbirch_function_("updateLazy", "birch/distribution/BetaBernoulli.birch", 34);
  #line 35 "birch/distribution/BetaBernoulli.birch"
  libbirch_line_(35);
  #line 35 "birch/distribution/BetaBernoulli.birch"
  libbirch::tie(this_()->_u0961->_u0945, this_()->_u0961->_u0946) = birch::update_lazy_beta_bernoulli(x, this_()->_u0961->_u0945, this_()->_u0961->_u0946, handler_);
}

#line 38 "birch/distribution/BetaBernoulli.birch"
void birch::type::BetaBernoulli::downdate(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "birch/distribution/BetaBernoulli.birch"
  libbirch_function_("downdate", "birch/distribution/BetaBernoulli.birch", 38);
  #line 39 "birch/distribution/BetaBernoulli.birch"
  libbirch_line_(39);
  #line 39 "birch/distribution/BetaBernoulli.birch"
  libbirch::tie(this_()->_u0961->_u0945, this_()->_u0961->_u0946) = birch::box(birch::downdate_beta_bernoulli(x, this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0946->value(handler_), handler_), handler_);
}

#line 42 "birch/distribution/BetaBernoulli.birch"
void birch::type::BetaBernoulli::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "birch/distribution/BetaBernoulli.birch"
  libbirch_function_("link", "birch/distribution/BetaBernoulli.birch", 42);
  #line 43 "birch/distribution/BetaBernoulli.birch"
  libbirch_line_(43);
  #line 43 "birch/distribution/BetaBernoulli.birch"
  this_()->_u0961->setChild(shared_from_this_(), handler_);
}

#line 46 "birch/distribution/BetaBernoulli.birch"
void birch::type::BetaBernoulli::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "birch/distribution/BetaBernoulli.birch"
  libbirch_function_("unlink", "birch/distribution/BetaBernoulli.birch", 46);
  #line 47 "birch/distribution/BetaBernoulli.birch"
  libbirch_line_(47);
  #line 47 "birch/distribution/BetaBernoulli.birch"
  this_()->_u0961->releaseChild(shared_from_this_(), handler_);
}

#line 51 "birch/distribution/BetaBernoulli.birch"
libbirch::Lazy<libbirch::Shared<birch::type::BetaBernoulli>> birch::BetaBernoulli(const libbirch::Lazy<libbirch::Shared<birch::type::Beta>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 51 "birch/distribution/BetaBernoulli.birch"
  libbirch_function_("BetaBernoulli", "birch/distribution/BetaBernoulli.birch", 51);
  #line 52 "birch/distribution/BetaBernoulli.birch"
  libbirch_line_(52);
  #line 52 "birch/distribution/BetaBernoulli.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::BetaBernoulli>> m(_u0961);
  #line 53 "birch/distribution/BetaBernoulli.birch"
  libbirch_line_(53);
  #line 53 "birch/distribution/BetaBernoulli.birch"
  m->link(handler_);
  #line 54 "birch/distribution/BetaBernoulli.birch"
  libbirch_line_(54);
  #line 54 "birch/distribution/BetaBernoulli.birch"
  return m;
}

#line 4 "birch/distribution/BetaBinomial.birch"
birch::type::BetaBinomial::BetaBinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& n, const libbirch::Lazy<libbirch::Shared<birch::type::Beta>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/BetaBinomial.birch"
    super_type_(),
    #line 8 "birch/distribution/BetaBinomial.birch"
    n(n),
    #line 13 "birch/distribution/BetaBinomial.birch"
    _u0961(_u0961) {
  //
}

#line 15 "birch/distribution/BetaBinomial.birch"
birch::type::Boolean birch::type::BetaBinomial::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "birch/distribution/BetaBinomial.birch"
  libbirch_function_("supportsLazy", "birch/distribution/BetaBinomial.birch", 15);
  #line 16 "birch/distribution/BetaBinomial.birch"
  libbirch_line_(16);
  #line 16 "birch/distribution/BetaBinomial.birch"
  return true;
}

#line 19 "birch/distribution/BetaBinomial.birch"
birch::type::Integer birch::type::BetaBinomial::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "birch/distribution/BetaBinomial.birch"
  libbirch_function_("simulate", "birch/distribution/BetaBinomial.birch", 19);
  #line 20 "birch/distribution/BetaBinomial.birch"
  libbirch_line_(20);
  #line 20 "birch/distribution/BetaBinomial.birch"
  if (this_()->value.query()) {
    #line 21 "birch/distribution/BetaBinomial.birch"
    libbirch_line_(21);
    #line 21 "birch/distribution/BetaBinomial.birch"
    return this_()->value.get();
  } else {
    #line 23 "birch/distribution/BetaBinomial.birch"
    libbirch_line_(23);
    #line 23 "birch/distribution/BetaBinomial.birch"
    return birch::simulate_beta_binomial(this_()->n->value(handler_), this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0946->value(handler_), handler_);
  }
}

#line 27 "birch/distribution/BetaBinomial.birch"
libbirch::Optional<birch::type::Integer> birch::type::BetaBinomial::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "birch/distribution/BetaBinomial.birch"
  libbirch_function_("simulateLazy", "birch/distribution/BetaBinomial.birch", 27);
  #line 28 "birch/distribution/BetaBinomial.birch"
  libbirch_line_(28);
  #line 28 "birch/distribution/BetaBinomial.birch"
  if (this_()->value.query()) {
    #line 29 "birch/distribution/BetaBinomial.birch"
    libbirch_line_(29);
    #line 29 "birch/distribution/BetaBinomial.birch"
    return this_()->value.get();
  } else {
    #line 31 "birch/distribution/BetaBinomial.birch"
    libbirch_line_(31);
    #line 31 "birch/distribution/BetaBinomial.birch"
    return birch::simulate_beta_binomial(this_()->n->get(handler_), this_()->_u0961->_u0945->get(handler_), this_()->_u0961->_u0946->get(handler_), handler_);
  }
}

#line 35 "birch/distribution/BetaBinomial.birch"
birch::type::Real birch::type::BetaBinomial::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "birch/distribution/BetaBinomial.birch"
  libbirch_function_("logpdf", "birch/distribution/BetaBinomial.birch", 35);
  #line 36 "birch/distribution/BetaBinomial.birch"
  libbirch_line_(36);
  #line 36 "birch/distribution/BetaBinomial.birch"
  return birch::logpdf_beta_binomial(x, this_()->n->value(handler_), this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0946->value(handler_), handler_);
}

#line 39 "birch/distribution/BetaBinomial.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::BetaBinomial::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "birch/distribution/BetaBinomial.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/BetaBinomial.birch", 39);
  #line 40 "birch/distribution/BetaBinomial.birch"
  libbirch_line_(40);
  #line 40 "birch/distribution/BetaBinomial.birch"
  return birch::logpdf_lazy_beta_binomial(x, this_()->n, this_()->_u0961->_u0945, this_()->_u0961->_u0946, handler_);
}

#line 43 "birch/distribution/BetaBinomial.birch"
void birch::type::BetaBinomial::update(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "birch/distribution/BetaBinomial.birch"
  libbirch_function_("update", "birch/distribution/BetaBinomial.birch", 43);
  #line 44 "birch/distribution/BetaBinomial.birch"
  libbirch_line_(44);
  #line 44 "birch/distribution/BetaBinomial.birch"
  libbirch::tie(this_()->_u0961->_u0945, this_()->_u0961->_u0946) = birch::box(birch::update_beta_binomial(x, this_()->n->value(handler_), this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0946->value(handler_), handler_), handler_);
}

#line 47 "birch/distribution/BetaBinomial.birch"
void birch::type::BetaBinomial::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "birch/distribution/BetaBinomial.birch"
  libbirch_function_("updateLazy", "birch/distribution/BetaBinomial.birch", 47);
  #line 48 "birch/distribution/BetaBinomial.birch"
  libbirch_line_(48);
  #line 48 "birch/distribution/BetaBinomial.birch"
  libbirch::tie(this_()->_u0961->_u0945, this_()->_u0961->_u0946) = birch::update_lazy_beta_binomial(x, this_()->n, this_()->_u0961->_u0945, this_()->_u0961->_u0946, handler_);
}

#line 51 "birch/distribution/BetaBinomial.birch"
void birch::type::BetaBinomial::downdate(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 51 "birch/distribution/BetaBinomial.birch"
  libbirch_function_("downdate", "birch/distribution/BetaBinomial.birch", 51);
  #line 52 "birch/distribution/BetaBinomial.birch"
  libbirch_line_(52);
  #line 52 "birch/distribution/BetaBinomial.birch"
  libbirch::tie(this_()->_u0961->_u0945, this_()->_u0961->_u0946) = birch::box(birch::downdate_beta_binomial(x, this_()->n->value(handler_), this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0946->value(handler_), handler_), handler_);
}

#line 55 "birch/distribution/BetaBinomial.birch"
libbirch::Optional<birch::type::Real> birch::type::BetaBinomial::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 55 "birch/distribution/BetaBinomial.birch"
  libbirch_function_("cdf", "birch/distribution/BetaBinomial.birch", 55);
  #line 56 "birch/distribution/BetaBinomial.birch"
  libbirch_line_(56);
  #line 56 "birch/distribution/BetaBinomial.birch"
  return birch::cdf_beta_binomial(x, this_()->n->value(handler_), this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0946->value(handler_), handler_);
}

#line 59 "birch/distribution/BetaBinomial.birch"
libbirch::Optional<birch::type::Integer> birch::type::BetaBinomial::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "birch/distribution/BetaBinomial.birch"
  libbirch_function_("lower", "birch/distribution/BetaBinomial.birch", 59);
  #line 60 "birch/distribution/BetaBinomial.birch"
  libbirch_line_(60);
  #line 60 "birch/distribution/BetaBinomial.birch"
  return birch::type::Integer(0);
}

#line 63 "birch/distribution/BetaBinomial.birch"
libbirch::Optional<birch::type::Integer> birch::type::BetaBinomial::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 63 "birch/distribution/BetaBinomial.birch"
  libbirch_function_("upper", "birch/distribution/BetaBinomial.birch", 63);
  #line 64 "birch/distribution/BetaBinomial.birch"
  libbirch_line_(64);
  #line 64 "birch/distribution/BetaBinomial.birch"
  return this_()->n->value(handler_);
}

#line 67 "birch/distribution/BetaBinomial.birch"
void birch::type::BetaBinomial::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 67 "birch/distribution/BetaBinomial.birch"
  libbirch_function_("link", "birch/distribution/BetaBinomial.birch", 67);
  #line 68 "birch/distribution/BetaBinomial.birch"
  libbirch_line_(68);
  #line 68 "birch/distribution/BetaBinomial.birch"
  this_()->_u0961->setChild(shared_from_this_(), handler_);
}

#line 71 "birch/distribution/BetaBinomial.birch"
void birch::type::BetaBinomial::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 71 "birch/distribution/BetaBinomial.birch"
  libbirch_function_("unlink", "birch/distribution/BetaBinomial.birch", 71);
  #line 72 "birch/distribution/BetaBinomial.birch"
  libbirch_line_(72);
  #line 72 "birch/distribution/BetaBinomial.birch"
  this_()->_u0961->releaseChild(shared_from_this_(), handler_);
}

#line 76 "birch/distribution/BetaBinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::BetaBinomial>> birch::BetaBinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& n, const libbirch::Lazy<libbirch::Shared<birch::type::Beta>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "birch/distribution/BetaBinomial.birch"
  libbirch_function_("BetaBinomial", "birch/distribution/BetaBinomial.birch", 76);
  #line 77 "birch/distribution/BetaBinomial.birch"
  libbirch_line_(77);
  #line 77 "birch/distribution/BetaBinomial.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::BetaBinomial>> m(n, _u0961);
  #line 78 "birch/distribution/BetaBinomial.birch"
  libbirch_line_(78);
  #line 78 "birch/distribution/BetaBinomial.birch"
  m->link(handler_);
  #line 79 "birch/distribution/BetaBinomial.birch"
  libbirch_line_(79);
  #line 79 "birch/distribution/BetaBinomial.birch"
  return m;
}

#line 4 "birch/distribution/BetaNegativeBinomial.birch"
birch::type::BetaNegativeBinomial::BetaNegativeBinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Beta>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/BetaNegativeBinomial.birch"
    super_type_(),
    #line 8 "birch/distribution/BetaNegativeBinomial.birch"
    k(k),
    #line 13 "birch/distribution/BetaNegativeBinomial.birch"
    _u0961(_u0961) {
  //
}

#line 15 "birch/distribution/BetaNegativeBinomial.birch"
birch::type::Boolean birch::type::BetaNegativeBinomial::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("supportsLazy", "birch/distribution/BetaNegativeBinomial.birch", 15);
  #line 16 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(16);
  #line 16 "birch/distribution/BetaNegativeBinomial.birch"
  return true;
}

#line 19 "birch/distribution/BetaNegativeBinomial.birch"
birch::type::Integer birch::type::BetaNegativeBinomial::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("simulate", "birch/distribution/BetaNegativeBinomial.birch", 19);
  #line 20 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(20);
  #line 20 "birch/distribution/BetaNegativeBinomial.birch"
  if (this_()->value.query()) {
    #line 21 "birch/distribution/BetaNegativeBinomial.birch"
    libbirch_line_(21);
    #line 21 "birch/distribution/BetaNegativeBinomial.birch"
    return this_()->value.get();
  } else {
    #line 23 "birch/distribution/BetaNegativeBinomial.birch"
    libbirch_line_(23);
    #line 23 "birch/distribution/BetaNegativeBinomial.birch"
    return birch::simulate_beta_negative_binomial(this_()->k->value(handler_), this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0946->value(handler_), handler_);
  }
}

#line 27 "birch/distribution/BetaNegativeBinomial.birch"
libbirch::Optional<birch::type::Integer> birch::type::BetaNegativeBinomial::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("simulateLazy", "birch/distribution/BetaNegativeBinomial.birch", 27);
  #line 28 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(28);
  #line 28 "birch/distribution/BetaNegativeBinomial.birch"
  if (this_()->value.query()) {
    #line 29 "birch/distribution/BetaNegativeBinomial.birch"
    libbirch_line_(29);
    #line 29 "birch/distribution/BetaNegativeBinomial.birch"
    return this_()->value.get();
  } else {
    #line 31 "birch/distribution/BetaNegativeBinomial.birch"
    libbirch_line_(31);
    #line 31 "birch/distribution/BetaNegativeBinomial.birch"
    return birch::simulate_beta_negative_binomial(this_()->k->get(handler_), this_()->_u0961->_u0945->get(handler_), this_()->_u0961->_u0946->get(handler_), handler_);
  }
}

#line 35 "birch/distribution/BetaNegativeBinomial.birch"
birch::type::Real birch::type::BetaNegativeBinomial::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("logpdf", "birch/distribution/BetaNegativeBinomial.birch", 35);
  #line 36 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(36);
  #line 36 "birch/distribution/BetaNegativeBinomial.birch"
  return birch::logpdf_beta_negative_binomial(x, this_()->k->value(handler_), this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0946->value(handler_), handler_);
}

#line 39 "birch/distribution/BetaNegativeBinomial.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::BetaNegativeBinomial::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/BetaNegativeBinomial.birch", 39);
  #line 40 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(40);
  #line 40 "birch/distribution/BetaNegativeBinomial.birch"
  return birch::logpdf_lazy_beta_negative_binomial(x, this_()->k, this_()->_u0961->_u0945, this_()->_u0961->_u0946, handler_);
}

#line 43 "birch/distribution/BetaNegativeBinomial.birch"
void birch::type::BetaNegativeBinomial::update(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("update", "birch/distribution/BetaNegativeBinomial.birch", 43);
  #line 44 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(44);
  #line 44 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch::tie(this_()->_u0961->_u0945, this_()->_u0961->_u0946) = birch::box(birch::update_beta_negative_binomial(x, this_()->k->value(handler_), this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0946->value(handler_), handler_), handler_);
}

#line 47 "birch/distribution/BetaNegativeBinomial.birch"
void birch::type::BetaNegativeBinomial::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("updateLazy", "birch/distribution/BetaNegativeBinomial.birch", 47);
  #line 48 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(48);
  #line 48 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch::tie(this_()->_u0961->_u0945, this_()->_u0961->_u0946) = birch::update_lazy_beta_negative_binomial(x, this_()->k, this_()->_u0961->_u0945, this_()->_u0961->_u0946, handler_);
}

#line 51 "birch/distribution/BetaNegativeBinomial.birch"
void birch::type::BetaNegativeBinomial::downdate(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 51 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("downdate", "birch/distribution/BetaNegativeBinomial.birch", 51);
  #line 52 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(52);
  #line 52 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch::tie(this_()->_u0961->_u0945, this_()->_u0961->_u0946) = birch::box(birch::downdate_beta_negative_binomial(x, this_()->k->value(handler_), this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0946->value(handler_), handler_), handler_);
}

#line 55 "birch/distribution/BetaNegativeBinomial.birch"
libbirch::Optional<birch::type::Integer> birch::type::BetaNegativeBinomial::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 55 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("lower", "birch/distribution/BetaNegativeBinomial.birch", 55);
  #line 56 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(56);
  #line 56 "birch/distribution/BetaNegativeBinomial.birch"
  return birch::type::Integer(0);
}

#line 59 "birch/distribution/BetaNegativeBinomial.birch"
void birch::type::BetaNegativeBinomial::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("link", "birch/distribution/BetaNegativeBinomial.birch", 59);
  #line 60 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(60);
  #line 60 "birch/distribution/BetaNegativeBinomial.birch"
  this_()->_u0961->setChild(shared_from_this_(), handler_);
}

#line 63 "birch/distribution/BetaNegativeBinomial.birch"
void birch::type::BetaNegativeBinomial::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 63 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("unlink", "birch/distribution/BetaNegativeBinomial.birch", 63);
  #line 64 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(64);
  #line 64 "birch/distribution/BetaNegativeBinomial.birch"
  this_()->_u0961->releaseChild(shared_from_this_(), handler_);
}

#line 68 "birch/distribution/BetaNegativeBinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::BetaNegativeBinomial>> birch::BetaNegativeBinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Beta>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 68 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_function_("BetaNegativeBinomial", "birch/distribution/BetaNegativeBinomial.birch", 68);
  #line 70 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(70);
  #line 70 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::BetaNegativeBinomial>> m(k, _u0961);
  #line 71 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(71);
  #line 71 "birch/distribution/BetaNegativeBinomial.birch"
  m->link(handler_);
  #line 72 "birch/distribution/BetaNegativeBinomial.birch"
  libbirch_line_(72);
  #line 72 "birch/distribution/BetaNegativeBinomial.birch"
  return m;
}

#line 1 "birch/distribution/Binomial.birch"
birch::type::Binomial::Binomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& n, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/distribution/Binomial.birch"
    super_type_(),
    #line 8 "birch/distribution/Binomial.birch"
    n(n),
    #line 13 "birch/distribution/Binomial.birch"
    _u0961(_u0961) {
  //
}

#line 15 "birch/distribution/Binomial.birch"
birch::type::Boolean birch::type::Binomial::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "birch/distribution/Binomial.birch"
  libbirch_function_("supportsLazy", "birch/distribution/Binomial.birch", 15);
  #line 16 "birch/distribution/Binomial.birch"
  libbirch_line_(16);
  #line 16 "birch/distribution/Binomial.birch"
  return true;
}

#line 19 "birch/distribution/Binomial.birch"
birch::type::Integer birch::type::Binomial::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "birch/distribution/Binomial.birch"
  libbirch_function_("simulate", "birch/distribution/Binomial.birch", 19);
  #line 20 "birch/distribution/Binomial.birch"
  libbirch_line_(20);
  #line 20 "birch/distribution/Binomial.birch"
  if (this_()->value.query()) {
    #line 21 "birch/distribution/Binomial.birch"
    libbirch_line_(21);
    #line 21 "birch/distribution/Binomial.birch"
    return this_()->value.get();
  } else {
    #line 23 "birch/distribution/Binomial.birch"
    libbirch_line_(23);
    #line 23 "birch/distribution/Binomial.birch"
    return birch::simulate_binomial(this_()->n->value(handler_), this_()->_u0961->value(handler_), handler_);
  }
}

#line 27 "birch/distribution/Binomial.birch"
libbirch::Optional<birch::type::Integer> birch::type::Binomial::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "birch/distribution/Binomial.birch"
  libbirch_function_("simulateLazy", "birch/distribution/Binomial.birch", 27);
  #line 28 "birch/distribution/Binomial.birch"
  libbirch_line_(28);
  #line 28 "birch/distribution/Binomial.birch"
  if (this_()->value.query()) {
    #line 29 "birch/distribution/Binomial.birch"
    libbirch_line_(29);
    #line 29 "birch/distribution/Binomial.birch"
    return this_()->value.get();
  } else {
    #line 31 "birch/distribution/Binomial.birch"
    libbirch_line_(31);
    #line 31 "birch/distribution/Binomial.birch"
    return birch::simulate_binomial(this_()->n->get(handler_), this_()->_u0961->get(handler_), handler_);
  }
}

#line 35 "birch/distribution/Binomial.birch"
birch::type::Real birch::type::Binomial::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "birch/distribution/Binomial.birch"
  libbirch_function_("logpdf", "birch/distribution/Binomial.birch", 35);
  #line 36 "birch/distribution/Binomial.birch"
  libbirch_line_(36);
  #line 36 "birch/distribution/Binomial.birch"
  return birch::logpdf_binomial(x, this_()->n->value(handler_), this_()->_u0961->value(handler_), handler_);
}

#line 39 "birch/distribution/Binomial.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::Binomial::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "birch/distribution/Binomial.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/Binomial.birch", 39);
  #line 40 "birch/distribution/Binomial.birch"
  libbirch_line_(40);
  #line 40 "birch/distribution/Binomial.birch"
  return birch::logpdf_lazy_binomial(x, this_()->n, this_()->_u0961, handler_);
}

#line 43 "birch/distribution/Binomial.birch"
libbirch::Optional<birch::type::Real> birch::type::Binomial::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "birch/distribution/Binomial.birch"
  libbirch_function_("cdf", "birch/distribution/Binomial.birch", 43);
  #line 44 "birch/distribution/Binomial.birch"
  libbirch_line_(44);
  #line 44 "birch/distribution/Binomial.birch"
  return birch::cdf_binomial(x, this_()->n->value(handler_), this_()->_u0961->value(handler_), handler_);
}

#line 47 "birch/distribution/Binomial.birch"
libbirch::Optional<birch::type::Integer> birch::type::Binomial::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "birch/distribution/Binomial.birch"
  libbirch_function_("quantile", "birch/distribution/Binomial.birch", 47);
  #line 48 "birch/distribution/Binomial.birch"
  libbirch_line_(48);
  #line 48 "birch/distribution/Binomial.birch"
  return birch::quantile_binomial(P, this_()->n->value(handler_), this_()->_u0961->value(handler_), handler_);
}

#line 51 "birch/distribution/Binomial.birch"
libbirch::Optional<birch::type::Integer> birch::type::Binomial::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 51 "birch/distribution/Binomial.birch"
  libbirch_function_("lower", "birch/distribution/Binomial.birch", 51);
  #line 52 "birch/distribution/Binomial.birch"
  libbirch_line_(52);
  #line 52 "birch/distribution/Binomial.birch"
  return birch::type::Integer(0);
}

#line 55 "birch/distribution/Binomial.birch"
libbirch::Optional<birch::type::Integer> birch::type::Binomial::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 55 "birch/distribution/Binomial.birch"
  libbirch_function_("upper", "birch/distribution/Binomial.birch", 55);
  #line 56 "birch/distribution/Binomial.birch"
  libbirch_line_(56);
  #line 56 "birch/distribution/Binomial.birch"
  return this_()->n->value(handler_);
}

#line 59 "birch/distribution/Binomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> birch::type::Binomial::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "birch/distribution/Binomial.birch"
  libbirch_function_("graft", "birch/distribution/Binomial.birch", 59);
  #line 60 "birch/distribution/Binomial.birch"
  libbirch_line_(60);
  #line 60 "birch/distribution/Binomial.birch"
  this_()->prune(handler_);
  #line 61 "birch/distribution/Binomial.birch"
  libbirch_line_(61);
  #line 61 "birch/distribution/Binomial.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Beta>>> m;
  #line 62 "birch/distribution/Binomial.birch"
  libbirch_line_(62);
  #line 62 "birch/distribution/Binomial.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> r = shared_from_this_();
  #line 65 "birch/distribution/Binomial.birch"
  libbirch_line_(65);
  #line 65 "birch/distribution/Binomial.birch"
  if ((m = this_()->_u0961->graftBeta(handler_)).query()) {
    #line 66 "birch/distribution/Binomial.birch"
    libbirch_line_(66);
    #line 66 "birch/distribution/Binomial.birch"
    r = birch::BetaBinomial(this_()->n, m.get(), handler_);
  }
  #line 69 "birch/distribution/Binomial.birch"
  libbirch_line_(69);
  #line 69 "birch/distribution/Binomial.birch"
  return r;
}

#line 72 "birch/distribution/Binomial.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>> birch::type::Binomial::graftDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "birch/distribution/Binomial.birch"
  libbirch_function_("graftDiscrete", "birch/distribution/Binomial.birch", 72);
  #line 73 "birch/distribution/Binomial.birch"
  libbirch_line_(73);
  #line 73 "birch/distribution/Binomial.birch"
  return libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>>(this_()->graft(handler_));
}

#line 76 "birch/distribution/Binomial.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>> birch::type::Binomial::graftBoundedDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "birch/distribution/Binomial.birch"
  libbirch_function_("graftBoundedDiscrete", "birch/distribution/Binomial.birch", 76);
  #line 77 "birch/distribution/Binomial.birch"
  libbirch_line_(77);
  #line 77 "birch/distribution/Binomial.birch"
  return libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>>(this_()->graft(handler_));
}

#line 80 "birch/distribution/Binomial.birch"
void birch::type::Binomial::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 80 "birch/distribution/Binomial.birch"
  libbirch_function_("write", "birch/distribution/Binomial.birch", 80);
  #line 81 "birch/distribution/Binomial.birch"
  libbirch_line_(81);
  #line 81 "birch/distribution/Binomial.birch"
  this_()->prune(handler_);
  #line 82 "birch/distribution/Binomial.birch"
  libbirch_line_(82);
  #line 82 "birch/distribution/Binomial.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Binomial"), handler_);
  #line 83 "birch/distribution/Binomial.birch"
  libbirch_line_(83);
  #line 83 "birch/distribution/Binomial.birch"
  buffer->set(birch::type::String("n"), this_()->n, handler_);
  #line 84 "birch/distribution/Binomial.birch"
  libbirch_line_(84);
  #line 84 "birch/distribution/Binomial.birch"
  buffer->set(birch::type::String("ρ"), this_()->_u0961, handler_);
}

#line 91 "birch/distribution/Binomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Binomial>> birch::Binomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& n, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 91 "birch/distribution/Binomial.birch"
  libbirch_function_("Binomial", "birch/distribution/Binomial.birch", 91);
  #line 92 "birch/distribution/Binomial.birch"
  libbirch_line_(92);
  #line 92 "birch/distribution/Binomial.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Binomial>>>(n, _u0961, handler_);
}

#line 98 "birch/distribution/Binomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Binomial>> birch::Binomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& n, const birch::type::Real& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 98 "birch/distribution/Binomial.birch"
  libbirch_function_("Binomial", "birch/distribution/Binomial.birch", 98);
  #line 99 "birch/distribution/Binomial.birch"
  libbirch_line_(99);
  #line 99 "birch/distribution/Binomial.birch"
  return birch::Binomial(n, birch::box(_u0961, handler_), handler_);
}

#line 105 "birch/distribution/Binomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Binomial>> birch::Binomial(const birch::type::Integer& n, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 105 "birch/distribution/Binomial.birch"
  libbirch_function_("Binomial", "birch/distribution/Binomial.birch", 105);
  #line 106 "birch/distribution/Binomial.birch"
  libbirch_line_(106);
  #line 106 "birch/distribution/Binomial.birch"
  return birch::Binomial(birch::box(n, handler_), _u0961, handler_);
}

#line 112 "birch/distribution/Binomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Binomial>> birch::Binomial(const birch::type::Integer& n, const birch::type::Real& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 112 "birch/distribution/Binomial.birch"
  libbirch_function_("Binomial", "birch/distribution/Binomial.birch", 112);
  #line 113 "birch/distribution/Binomial.birch"
  libbirch_line_(113);
  #line 113 "birch/distribution/Binomial.birch"
  return birch::Binomial(birch::box(n, handler_), birch::box(_u0961, handler_), handler_);
}

#line 4 "birch/distribution/BoundedDiscrete.birch"
birch::type::BoundedDiscrete::BoundedDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/BoundedDiscrete.birch"
    super_type_() {
  //
}

#line 8 "birch/distribution/BoundedDiscrete.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>> birch::type::BoundedDiscrete::graftBoundedDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 8 "birch/distribution/BoundedDiscrete.birch"
  libbirch_function_("graftBoundedDiscrete", "birch/distribution/BoundedDiscrete.birch", 8);
  #line 9 "birch/distribution/BoundedDiscrete.birch"
  libbirch_line_(9);
  #line 9 "birch/distribution/BoundedDiscrete.birch"
  this_()->prune(handler_);
  #line 10 "birch/distribution/BoundedDiscrete.birch"
  libbirch_line_(10);
  #line 10 "birch/distribution/BoundedDiscrete.birch"
  return shared_from_this_();
}

#line 1 "birch/distribution/Categorical.birch"
birch::type::Categorical::Categorical(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/distribution/Categorical.birch"
    super_type_(),
    #line 8 "birch/distribution/Categorical.birch"
    _u0961(_u0961) {
  //
}

#line 10 "birch/distribution/Categorical.birch"
birch::type::Boolean birch::type::Categorical::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "birch/distribution/Categorical.birch"
  libbirch_function_("supportsLazy", "birch/distribution/Categorical.birch", 10);
  #line 11 "birch/distribution/Categorical.birch"
  libbirch_line_(11);
  #line 11 "birch/distribution/Categorical.birch"
  return false;
}

#line 14 "birch/distribution/Categorical.birch"
birch::type::Integer birch::type::Categorical::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "birch/distribution/Categorical.birch"
  libbirch_function_("simulate", "birch/distribution/Categorical.birch", 14);
  #line 15 "birch/distribution/Categorical.birch"
  libbirch_line_(15);
  #line 15 "birch/distribution/Categorical.birch"
  return birch::simulate_categorical(this_()->_u0961->value(handler_), handler_);
}

#line 22 "birch/distribution/Categorical.birch"
birch::type::Real birch::type::Categorical::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "birch/distribution/Categorical.birch"
  libbirch_function_("logpdf", "birch/distribution/Categorical.birch", 22);
  #line 23 "birch/distribution/Categorical.birch"
  libbirch_line_(23);
  #line 23 "birch/distribution/Categorical.birch"
  return birch::logpdf_categorical(x, this_()->_u0961->value(handler_), handler_);
}

#line 30 "birch/distribution/Categorical.birch"
libbirch::Optional<birch::type::Real> birch::type::Categorical::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "birch/distribution/Categorical.birch"
  libbirch_function_("cdf", "birch/distribution/Categorical.birch", 30);
  #line 31 "birch/distribution/Categorical.birch"
  libbirch_line_(31);
  #line 31 "birch/distribution/Categorical.birch"
  return birch::cdf_categorical(x, this_()->_u0961->value(handler_), handler_);
}

#line 34 "birch/distribution/Categorical.birch"
libbirch::Optional<birch::type::Integer> birch::type::Categorical::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "birch/distribution/Categorical.birch"
  libbirch_function_("quantile", "birch/distribution/Categorical.birch", 34);
  #line 35 "birch/distribution/Categorical.birch"
  libbirch_line_(35);
  #line 35 "birch/distribution/Categorical.birch"
  return birch::quantile_categorical(P, this_()->_u0961->value(handler_), handler_);
}

#line 38 "birch/distribution/Categorical.birch"
libbirch::Optional<birch::type::Integer> birch::type::Categorical::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "birch/distribution/Categorical.birch"
  libbirch_function_("lower", "birch/distribution/Categorical.birch", 38);
  #line 39 "birch/distribution/Categorical.birch"
  libbirch_line_(39);
  #line 39 "birch/distribution/Categorical.birch"
  return birch::type::Integer(1);
}

#line 42 "birch/distribution/Categorical.birch"
libbirch::Optional<birch::type::Integer> birch::type::Categorical::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "birch/distribution/Categorical.birch"
  libbirch_function_("upper", "birch/distribution/Categorical.birch", 42);
  #line 43 "birch/distribution/Categorical.birch"
  libbirch_line_(43);
  #line 43 "birch/distribution/Categorical.birch"
  return this_()->_u0961->rows(handler_);
}

#line 46 "birch/distribution/Categorical.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> birch::type::Categorical::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "birch/distribution/Categorical.birch"
  libbirch_function_("graft", "birch/distribution/Categorical.birch", 46);
  #line 47 "birch/distribution/Categorical.birch"
  libbirch_line_(47);
  #line 47 "birch/distribution/Categorical.birch"
  this_()->prune(handler_);
  #line 48 "birch/distribution/Categorical.birch"
  libbirch_line_(48);
  #line 48 "birch/distribution/Categorical.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Dirichlet>>> m1;
  #line 49 "birch/distribution/Categorical.birch"
  libbirch_line_(49);
  #line 49 "birch/distribution/Categorical.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Restaurant>>> m2;
  #line 50 "birch/distribution/Categorical.birch"
  libbirch_line_(50);
  #line 50 "birch/distribution/Categorical.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> r = shared_from_this_();
  #line 53 "birch/distribution/Categorical.birch"
  libbirch_line_(53);
  #line 53 "birch/distribution/Categorical.birch"
  if ((m1 = this_()->_u0961->graftDirichlet(handler_)).query()) {
    #line 54 "birch/distribution/Categorical.birch"
    libbirch_line_(54);
    #line 54 "birch/distribution/Categorical.birch"
    r = birch::DirichletCategorical(m1.get(), handler_);
  } else {
    #line 55 "birch/distribution/Categorical.birch"
    libbirch_line_(55);
    #line 55 "birch/distribution/Categorical.birch"
    if ((m2 = this_()->_u0961->graftRestaurant(handler_)).query()) {
      #line 56 "birch/distribution/Categorical.birch"
      libbirch_line_(56);
      #line 56 "birch/distribution/Categorical.birch"
      r = birch::RestaurantCategorical(m2.get(), handler_);
    }
  }
  #line 59 "birch/distribution/Categorical.birch"
  libbirch_line_(59);
  #line 59 "birch/distribution/Categorical.birch"
  return r;
}

#line 62 "birch/distribution/Categorical.birch"
void birch::type::Categorical::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 62 "birch/distribution/Categorical.birch"
  libbirch_function_("write", "birch/distribution/Categorical.birch", 62);
  #line 63 "birch/distribution/Categorical.birch"
  libbirch_line_(63);
  #line 63 "birch/distribution/Categorical.birch"
  this_()->prune(handler_);
  #line 64 "birch/distribution/Categorical.birch"
  libbirch_line_(64);
  #line 64 "birch/distribution/Categorical.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Categorical"), handler_);
  #line 65 "birch/distribution/Categorical.birch"
  libbirch_line_(65);
  #line 65 "birch/distribution/Categorical.birch"
  buffer->set(birch::type::String("ρ"), this_()->_u0961, handler_);
}

#line 72 "birch/distribution/Categorical.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Categorical>> birch::Categorical(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "birch/distribution/Categorical.birch"
  libbirch_function_("Categorical", "birch/distribution/Categorical.birch", 72);
  #line 73 "birch/distribution/Categorical.birch"
  libbirch_line_(73);
  #line 73 "birch/distribution/Categorical.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Categorical>>>(_u0961, handler_);
}

#line 79 "birch/distribution/Categorical.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Categorical>> birch::Categorical(const libbirch::DefaultArray<birch::type::Real,1>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 79 "birch/distribution/Categorical.birch"
  libbirch_function_("Categorical", "birch/distribution/Categorical.birch", 79);
  #line 80 "birch/distribution/Categorical.birch"
  libbirch_line_(80);
  #line 80 "birch/distribution/Categorical.birch"
  return birch::Categorical(birch::box(_u0961, handler_), handler_);
}

#line 7 "birch/distribution/DelayDistribution.birch"
birch::type::DelayDistribution::DelayDistribution(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 7 "birch/distribution/DelayDistribution.birch"
    super_type_(),
    #line 11 "birch/distribution/DelayDistribution.birch"
    child() {
  //
}

#line 21 "birch/distribution/DelayDistribution.birch"
void birch::type::DelayDistribution::prune(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "birch/distribution/DelayDistribution.birch"
  libbirch_function_("prune", "birch/distribution/DelayDistribution.birch", 21);
  #line 22 "birch/distribution/DelayDistribution.birch"
  libbirch_line_(22);
  #line 22 "birch/distribution/DelayDistribution.birch"
  if (this_()->child.query()) {
    #line 23 "birch/distribution/DelayDistribution.birch"
    libbirch_line_(23);
    #line 23 "birch/distribution/DelayDistribution.birch"
    this_()->child.get()->realize(handler_);
  }
}

#line 34 "birch/distribution/DelayDistribution.birch"
void birch::type::DelayDistribution::setChild(const libbirch::Lazy<libbirch::Shared<birch::type::DelayDistribution>>& child, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "birch/distribution/DelayDistribution.birch"
  libbirch_function_("setChild", "birch/distribution/DelayDistribution.birch", 34);
  #line 35 "birch/distribution/DelayDistribution.birch"
  libbirch_line_(35);
  #line 35 "birch/distribution/DelayDistribution.birch"
  libbirch_assert_(!this_()->child.query() || this_()->child.get() == child);
  #line 36 "birch/distribution/DelayDistribution.birch"
  libbirch_line_(36);
  #line 36 "birch/distribution/DelayDistribution.birch"
  this_()->child = child;
}

#line 46 "birch/distribution/DelayDistribution.birch"
void birch::type::DelayDistribution::releaseChild(const libbirch::Lazy<libbirch::Shared<birch::type::DelayDistribution>>& child, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "birch/distribution/DelayDistribution.birch"
  libbirch_function_("releaseChild", "birch/distribution/DelayDistribution.birch", 46);
  #line 47 "birch/distribution/DelayDistribution.birch"
  libbirch_line_(47);
  #line 47 "birch/distribution/DelayDistribution.birch"
  libbirch_assert_(!this_()->child.query() || this_()->child.get() == child);
  #line 48 "birch/distribution/DelayDistribution.birch"
  libbirch_line_(48);
  #line 48 "birch/distribution/DelayDistribution.birch"
  this_()->child = libbirch::nil;
}

#line 54 "birch/distribution/DelayDistribution.birch"
void birch::type::DelayDistribution::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "birch/distribution/DelayDistribution.birch"
  libbirch_function_("link", "birch/distribution/DelayDistribution.birch", 54);
}

#line 61 "birch/distribution/DelayDistribution.birch"
void birch::type::DelayDistribution::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "birch/distribution/DelayDistribution.birch"
  libbirch_function_("unlink", "birch/distribution/DelayDistribution.birch", 61);
}

#line 1 "birch/distribution/Delta.birch"
birch::type::Delta::Delta(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/distribution/Delta.birch"
    super_type_(),
    #line 9 "birch/distribution/Delta.birch"
    _u0956(_u0956) {
  //
}

#line 11 "birch/distribution/Delta.birch"
birch::type::Boolean birch::type::Delta::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "birch/distribution/Delta.birch"
  libbirch_function_("supportsLazy", "birch/distribution/Delta.birch", 11);
  #line 12 "birch/distribution/Delta.birch"
  libbirch_line_(12);
  #line 12 "birch/distribution/Delta.birch"
  return false;
}

#line 15 "birch/distribution/Delta.birch"
birch::type::Integer birch::type::Delta::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "birch/distribution/Delta.birch"
  libbirch_function_("simulate", "birch/distribution/Delta.birch", 15);
  #line 16 "birch/distribution/Delta.birch"
  libbirch_line_(16);
  #line 16 "birch/distribution/Delta.birch"
  if (this_()->value.query()) {
    #line 17 "birch/distribution/Delta.birch"
    libbirch_line_(17);
    #line 17 "birch/distribution/Delta.birch"
    return this_()->value.get();
  } else {
    #line 19 "birch/distribution/Delta.birch"
    libbirch_line_(19);
    #line 19 "birch/distribution/Delta.birch"
    return birch::simulate_delta(this_()->_u0956->value(handler_), handler_);
  }
}

#line 31 "birch/distribution/Delta.birch"
birch::type::Real birch::type::Delta::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "birch/distribution/Delta.birch"
  libbirch_function_("logpdf", "birch/distribution/Delta.birch", 31);
  #line 32 "birch/distribution/Delta.birch"
  libbirch_line_(32);
  #line 32 "birch/distribution/Delta.birch"
  return birch::logpdf_delta(x, this_()->_u0956->value(handler_), handler_);
}

#line 39 "birch/distribution/Delta.birch"
libbirch::Optional<birch::type::Integer> birch::type::Delta::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "birch/distribution/Delta.birch"
  libbirch_function_("lower", "birch/distribution/Delta.birch", 39);
  #line 40 "birch/distribution/Delta.birch"
  libbirch_line_(40);
  #line 40 "birch/distribution/Delta.birch"
  return this_()->_u0956->value(handler_);
}

#line 43 "birch/distribution/Delta.birch"
libbirch::Optional<birch::type::Integer> birch::type::Delta::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "birch/distribution/Delta.birch"
  libbirch_function_("upper", "birch/distribution/Delta.birch", 43);
  #line 44 "birch/distribution/Delta.birch"
  libbirch_line_(44);
  #line 44 "birch/distribution/Delta.birch"
  return this_()->_u0956->value(handler_);
}

#line 47 "birch/distribution/Delta.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> birch::type::Delta::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "birch/distribution/Delta.birch"
  libbirch_function_("graft", "birch/distribution/Delta.birch", 47);
  #line 48 "birch/distribution/Delta.birch"
  libbirch_line_(48);
  #line 48 "birch/distribution/Delta.birch"
  this_()->prune(handler_);
  #line 49 "birch/distribution/Delta.birch"
  libbirch_line_(49);
  #line 49 "birch/distribution/Delta.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>> m;
  #line 50 "birch/distribution/Delta.birch"
  libbirch_line_(50);
  #line 50 "birch/distribution/Delta.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> r = shared_from_this_();
  #line 53 "birch/distribution/Delta.birch"
  libbirch_line_(53);
  #line 53 "birch/distribution/Delta.birch"
  if ((m = this_()->_u0956->graftDiscrete(handler_)).query()) {
    #line 54 "birch/distribution/Delta.birch"
    libbirch_line_(54);
    #line 54 "birch/distribution/Delta.birch"
    r = birch::DiscreteDelta(m.get(), handler_);
  }
  #line 57 "birch/distribution/Delta.birch"
  libbirch_line_(57);
  #line 57 "birch/distribution/Delta.birch"
  return r;
}

#line 60 "birch/distribution/Delta.birch"
void birch::type::Delta::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "birch/distribution/Delta.birch"
  libbirch_function_("write", "birch/distribution/Delta.birch", 60);
  #line 61 "birch/distribution/Delta.birch"
  libbirch_line_(61);
  #line 61 "birch/distribution/Delta.birch"
  this_()->prune(handler_);
  #line 62 "birch/distribution/Delta.birch"
  libbirch_line_(62);
  #line 62 "birch/distribution/Delta.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Delta"), handler_);
  #line 63 "birch/distribution/Delta.birch"
  libbirch_line_(63);
  #line 63 "birch/distribution/Delta.birch"
  buffer->set(birch::type::String("μ"), this_()->_u0956, handler_);
}

#line 72 "birch/distribution/Delta.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Delta>> birch::Delta(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "birch/distribution/Delta.birch"
  libbirch_function_("Delta", "birch/distribution/Delta.birch", 72);
  #line 73 "birch/distribution/Delta.birch"
  libbirch_line_(73);
  #line 73 "birch/distribution/Delta.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Delta>>>(_u0956, handler_);
}

#line 81 "birch/distribution/Delta.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Delta>> birch::Delta(const birch::type::Integer& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "birch/distribution/Delta.birch"
  libbirch_function_("Delta", "birch/distribution/Delta.birch", 81);
  #line 82 "birch/distribution/Delta.birch"
  libbirch_line_(82);
  #line 82 "birch/distribution/Delta.birch"
  return birch::Delta(birch::box(_u0956, handler_), handler_);
}

#line 4 "birch/distribution/Dirichlet.birch"
birch::type::Dirichlet::Dirichlet(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/Dirichlet.birch"
    super_type_(),
    #line 8 "birch/distribution/Dirichlet.birch"
    _u0945(_u0945) {
  //
}

#line 10 "birch/distribution/Dirichlet.birch"
birch::type::Boolean birch::type::Dirichlet::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "birch/distribution/Dirichlet.birch"
  libbirch_function_("supportsLazy", "birch/distribution/Dirichlet.birch", 10);
  #line 11 "birch/distribution/Dirichlet.birch"
  libbirch_line_(11);
  #line 11 "birch/distribution/Dirichlet.birch"
  return false;
}

#line 14 "birch/distribution/Dirichlet.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::Dirichlet::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "birch/distribution/Dirichlet.birch"
  libbirch_function_("simulate", "birch/distribution/Dirichlet.birch", 14);
  #line 15 "birch/distribution/Dirichlet.birch"
  libbirch_line_(15);
  #line 15 "birch/distribution/Dirichlet.birch"
  return birch::simulate_dirichlet(this_()->_u0945->value(handler_), handler_);
}

#line 22 "birch/distribution/Dirichlet.birch"
birch::type::Real birch::type::Dirichlet::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "birch/distribution/Dirichlet.birch"
  libbirch_function_("logpdf", "birch/distribution/Dirichlet.birch", 22);
  #line 23 "birch/distribution/Dirichlet.birch"
  libbirch_line_(23);
  #line 23 "birch/distribution/Dirichlet.birch"
  return birch::logpdf_dirichlet(x, this_()->_u0945->value(handler_), handler_);
}

#line 30 "birch/distribution/Dirichlet.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Dirichlet>>> birch::type::Dirichlet::graftDirichlet(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "birch/distribution/Dirichlet.birch"
  libbirch_function_("graftDirichlet", "birch/distribution/Dirichlet.birch", 30);
  #line 31 "birch/distribution/Dirichlet.birch"
  libbirch_line_(31);
  #line 31 "birch/distribution/Dirichlet.birch"
  this_()->prune(handler_);
  #line 32 "birch/distribution/Dirichlet.birch"
  libbirch_line_(32);
  #line 32 "birch/distribution/Dirichlet.birch"
  return shared_from_this_();
}

#line 35 "birch/distribution/Dirichlet.birch"
void birch::type::Dirichlet::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "birch/distribution/Dirichlet.birch"
  libbirch_function_("write", "birch/distribution/Dirichlet.birch", 35);
  #line 36 "birch/distribution/Dirichlet.birch"
  libbirch_line_(36);
  #line 36 "birch/distribution/Dirichlet.birch"
  this_()->prune(handler_);
  #line 37 "birch/distribution/Dirichlet.birch"
  libbirch_line_(37);
  #line 37 "birch/distribution/Dirichlet.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Dirichlet"), handler_);
  #line 38 "birch/distribution/Dirichlet.birch"
  libbirch_line_(38);
  #line 38 "birch/distribution/Dirichlet.birch"
  buffer->set(birch::type::String("α"), this_()->_u0945, handler_);
}

#line 45 "birch/distribution/Dirichlet.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Dirichlet>> birch::Dirichlet(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "birch/distribution/Dirichlet.birch"
  libbirch_function_("Dirichlet", "birch/distribution/Dirichlet.birch", 45);
  #line 46 "birch/distribution/Dirichlet.birch"
  libbirch_line_(46);
  #line 46 "birch/distribution/Dirichlet.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Dirichlet>>>(_u0945, handler_);
}

#line 52 "birch/distribution/Dirichlet.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Dirichlet>> birch::Dirichlet(const libbirch::DefaultArray<birch::type::Real,1>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "birch/distribution/Dirichlet.birch"
  libbirch_function_("Dirichlet", "birch/distribution/Dirichlet.birch", 52);
  #line 53 "birch/distribution/Dirichlet.birch"
  libbirch_line_(53);
  #line 53 "birch/distribution/Dirichlet.birch"
  return birch::Dirichlet(birch::box(_u0945, handler_), handler_);
}

#line 4 "birch/distribution/DirichletCategorical.birch"
birch::type::DirichletCategorical::DirichletCategorical(const libbirch::Lazy<libbirch::Shared<birch::type::Dirichlet>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/DirichletCategorical.birch"
    super_type_(),
    #line 8 "birch/distribution/DirichletCategorical.birch"
    _u0961(_u0961) {
  //
}

#line 10 "birch/distribution/DirichletCategorical.birch"
birch::type::Boolean birch::type::DirichletCategorical::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "birch/distribution/DirichletCategorical.birch"
  libbirch_function_("supportsLazy", "birch/distribution/DirichletCategorical.birch", 10);
  #line 11 "birch/distribution/DirichletCategorical.birch"
  libbirch_line_(11);
  #line 11 "birch/distribution/DirichletCategorical.birch"
  return false;
}

#line 14 "birch/distribution/DirichletCategorical.birch"
birch::type::Integer birch::type::DirichletCategorical::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "birch/distribution/DirichletCategorical.birch"
  libbirch_function_("simulate", "birch/distribution/DirichletCategorical.birch", 14);
  #line 15 "birch/distribution/DirichletCategorical.birch"
  libbirch_line_(15);
  #line 15 "birch/distribution/DirichletCategorical.birch"
  return birch::simulate_dirichlet_categorical(this_()->_u0961->_u0945->value(handler_), handler_);
}

#line 22 "birch/distribution/DirichletCategorical.birch"
birch::type::Real birch::type::DirichletCategorical::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "birch/distribution/DirichletCategorical.birch"
  libbirch_function_("logpdf", "birch/distribution/DirichletCategorical.birch", 22);
  #line 23 "birch/distribution/DirichletCategorical.birch"
  libbirch_line_(23);
  #line 23 "birch/distribution/DirichletCategorical.birch"
  return birch::logpdf_dirichlet_categorical(x, this_()->_u0961->_u0945->value(handler_), handler_);
}

#line 30 "birch/distribution/DirichletCategorical.birch"
void birch::type::DirichletCategorical::update(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "birch/distribution/DirichletCategorical.birch"
  libbirch_function_("update", "birch/distribution/DirichletCategorical.birch", 30);
  #line 31 "birch/distribution/DirichletCategorical.birch"
  libbirch_line_(31);
  #line 31 "birch/distribution/DirichletCategorical.birch"
  this_()->_u0961->_u0945 = birch::box(birch::update_dirichlet_categorical(x, this_()->_u0961->_u0945->value(handler_), handler_), handler_);
}

#line 38 "birch/distribution/DirichletCategorical.birch"
void birch::type::DirichletCategorical::downdate(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "birch/distribution/DirichletCategorical.birch"
  libbirch_function_("downdate", "birch/distribution/DirichletCategorical.birch", 38);
  #line 39 "birch/distribution/DirichletCategorical.birch"
  libbirch_line_(39);
  #line 39 "birch/distribution/DirichletCategorical.birch"
  this_()->_u0961->_u0945 = birch::box(birch::downdate_dirichlet_categorical(x, this_()->_u0961->_u0945->value(handler_), handler_), handler_);
}

#line 42 "birch/distribution/DirichletCategorical.birch"
libbirch::Optional<birch::type::Integer> birch::type::DirichletCategorical::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "birch/distribution/DirichletCategorical.birch"
  libbirch_function_("lower", "birch/distribution/DirichletCategorical.birch", 42);
  #line 43 "birch/distribution/DirichletCategorical.birch"
  libbirch_line_(43);
  #line 43 "birch/distribution/DirichletCategorical.birch"
  return birch::type::Integer(1);
}

#line 46 "birch/distribution/DirichletCategorical.birch"
libbirch::Optional<birch::type::Integer> birch::type::DirichletCategorical::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "birch/distribution/DirichletCategorical.birch"
  libbirch_function_("upper", "birch/distribution/DirichletCategorical.birch", 46);
  #line 47 "birch/distribution/DirichletCategorical.birch"
  libbirch_line_(47);
  #line 47 "birch/distribution/DirichletCategorical.birch"
  return this_()->_u0961->_u0945->rows(handler_);
}

#line 50 "birch/distribution/DirichletCategorical.birch"
void birch::type::DirichletCategorical::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "birch/distribution/DirichletCategorical.birch"
  libbirch_function_("link", "birch/distribution/DirichletCategorical.birch", 50);
  #line 51 "birch/distribution/DirichletCategorical.birch"
  libbirch_line_(51);
  #line 51 "birch/distribution/DirichletCategorical.birch"
  this_()->_u0961->setChild(shared_from_this_(), handler_);
}

#line 54 "birch/distribution/DirichletCategorical.birch"
void birch::type::DirichletCategorical::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "birch/distribution/DirichletCategorical.birch"
  libbirch_function_("unlink", "birch/distribution/DirichletCategorical.birch", 54);
  #line 55 "birch/distribution/DirichletCategorical.birch"
  libbirch_line_(55);
  #line 55 "birch/distribution/DirichletCategorical.birch"
  this_()->_u0961->releaseChild(shared_from_this_(), handler_);
}

#line 59 "birch/distribution/DirichletCategorical.birch"
libbirch::Lazy<libbirch::Shared<birch::type::DirichletCategorical>> birch::DirichletCategorical(const libbirch::Lazy<libbirch::Shared<birch::type::Dirichlet>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "birch/distribution/DirichletCategorical.birch"
  libbirch_function_("DirichletCategorical", "birch/distribution/DirichletCategorical.birch", 59);
  #line 60 "birch/distribution/DirichletCategorical.birch"
  libbirch_line_(60);
  #line 60 "birch/distribution/DirichletCategorical.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::DirichletCategorical>> m(_u0961);
  #line 61 "birch/distribution/DirichletCategorical.birch"
  libbirch_line_(61);
  #line 61 "birch/distribution/DirichletCategorical.birch"
  m->link(handler_);
  #line 62 "birch/distribution/DirichletCategorical.birch"
  libbirch_line_(62);
  #line 62 "birch/distribution/DirichletCategorical.birch"
  return m;
}

#line 4 "birch/distribution/DirichletMultinomial.birch"
birch::type::DirichletMultinomial::DirichletMultinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& n, const libbirch::Lazy<libbirch::Shared<birch::type::Dirichlet>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/DirichletMultinomial.birch"
    super_type_(),
    #line 9 "birch/distribution/DirichletMultinomial.birch"
    n(n),
    #line 14 "birch/distribution/DirichletMultinomial.birch"
    _u0961(_u0961) {
  //
}

#line 16 "birch/distribution/DirichletMultinomial.birch"
birch::type::Boolean birch::type::DirichletMultinomial::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "birch/distribution/DirichletMultinomial.birch"
  libbirch_function_("supportsLazy", "birch/distribution/DirichletMultinomial.birch", 16);
  #line 17 "birch/distribution/DirichletMultinomial.birch"
  libbirch_line_(17);
  #line 17 "birch/distribution/DirichletMultinomial.birch"
  return false;
}

#line 20 "birch/distribution/DirichletMultinomial.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::type::DirichletMultinomial::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "birch/distribution/DirichletMultinomial.birch"
  libbirch_function_("simulate", "birch/distribution/DirichletMultinomial.birch", 20);
  #line 21 "birch/distribution/DirichletMultinomial.birch"
  libbirch_line_(21);
  #line 21 "birch/distribution/DirichletMultinomial.birch"
  return birch::simulate_dirichlet_multinomial(this_()->n->value(handler_), this_()->_u0961->_u0945->value(handler_), handler_);
}

#line 28 "birch/distribution/DirichletMultinomial.birch"
birch::type::Real birch::type::DirichletMultinomial::logpdf(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "birch/distribution/DirichletMultinomial.birch"
  libbirch_function_("logpdf", "birch/distribution/DirichletMultinomial.birch", 28);
  #line 29 "birch/distribution/DirichletMultinomial.birch"
  libbirch_line_(29);
  #line 29 "birch/distribution/DirichletMultinomial.birch"
  return birch::logpdf_dirichlet_multinomial(x, this_()->n->value(handler_), this_()->_u0961->_u0945->value(handler_), handler_);
}

#line 36 "birch/distribution/DirichletMultinomial.birch"
void birch::type::DirichletMultinomial::update(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "birch/distribution/DirichletMultinomial.birch"
  libbirch_function_("update", "birch/distribution/DirichletMultinomial.birch", 36);
  #line 37 "birch/distribution/DirichletMultinomial.birch"
  libbirch_line_(37);
  #line 37 "birch/distribution/DirichletMultinomial.birch"
  this_()->_u0961->_u0945 = birch::box(birch::update_dirichlet_multinomial(x, this_()->n->value(handler_), this_()->_u0961->_u0945->value(handler_), handler_), handler_);
}

#line 44 "birch/distribution/DirichletMultinomial.birch"
void birch::type::DirichletMultinomial::downdate(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "birch/distribution/DirichletMultinomial.birch"
  libbirch_function_("downdate", "birch/distribution/DirichletMultinomial.birch", 44);
  #line 45 "birch/distribution/DirichletMultinomial.birch"
  libbirch_line_(45);
  #line 45 "birch/distribution/DirichletMultinomial.birch"
  this_()->_u0961->_u0945 = birch::box(birch::downdate_dirichlet_multinomial(x, this_()->n->value(handler_), this_()->_u0961->_u0945->value(handler_), handler_), handler_);
}

#line 48 "birch/distribution/DirichletMultinomial.birch"
void birch::type::DirichletMultinomial::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "birch/distribution/DirichletMultinomial.birch"
  libbirch_function_("link", "birch/distribution/DirichletMultinomial.birch", 48);
  #line 49 "birch/distribution/DirichletMultinomial.birch"
  libbirch_line_(49);
  #line 49 "birch/distribution/DirichletMultinomial.birch"
  this_()->_u0961->setChild(shared_from_this_(), handler_);
}

#line 52 "birch/distribution/DirichletMultinomial.birch"
void birch::type::DirichletMultinomial::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "birch/distribution/DirichletMultinomial.birch"
  libbirch_function_("unlink", "birch/distribution/DirichletMultinomial.birch", 52);
  #line 53 "birch/distribution/DirichletMultinomial.birch"
  libbirch_line_(53);
  #line 53 "birch/distribution/DirichletMultinomial.birch"
  this_()->_u0961->releaseChild(shared_from_this_(), handler_);
}

#line 57 "birch/distribution/DirichletMultinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::DirichletMultinomial>> birch::DirichletMultinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& n, const libbirch::Lazy<libbirch::Shared<birch::type::Dirichlet>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 57 "birch/distribution/DirichletMultinomial.birch"
  libbirch_function_("DirichletMultinomial", "birch/distribution/DirichletMultinomial.birch", 57);
  #line 59 "birch/distribution/DirichletMultinomial.birch"
  libbirch_line_(59);
  #line 59 "birch/distribution/DirichletMultinomial.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::DirichletMultinomial>> m(n, _u0961);
  #line 60 "birch/distribution/DirichletMultinomial.birch"
  libbirch_line_(60);
  #line 60 "birch/distribution/DirichletMultinomial.birch"
  m->link(handler_);
  #line 61 "birch/distribution/DirichletMultinomial.birch"
  libbirch_line_(61);
  #line 61 "birch/distribution/DirichletMultinomial.birch"
  return m;
}

#line 4 "birch/distribution/Discrete.birch"
birch::type::Discrete::Discrete(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/Discrete.birch"
    super_type_(),
    #line 8 "birch/distribution/Discrete.birch"
    value() {
  //
}

#line 15 "birch/distribution/Discrete.birch"
void birch::type::Discrete::clamp(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "birch/distribution/Discrete.birch"
  libbirch_function_("clamp", "birch/distribution/Discrete.birch", 15);
  #line 16 "birch/distribution/Discrete.birch"
  libbirch_line_(16);
  #line 16 "birch/distribution/Discrete.birch"
  libbirch_assert_(!this_()->value.query() || this_()->value.get() == x);
  #line 17 "birch/distribution/Discrete.birch"
  libbirch_line_(17);
  #line 17 "birch/distribution/Discrete.birch"
  this_()->value = x;
}

#line 20 "birch/distribution/Discrete.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>> birch::type::Discrete::graftDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "birch/distribution/Discrete.birch"
  libbirch_function_("graftDiscrete", "birch/distribution/Discrete.birch", 20);
  #line 21 "birch/distribution/Discrete.birch"
  libbirch_line_(21);
  #line 21 "birch/distribution/Discrete.birch"
  this_()->prune(handler_);
  #line 22 "birch/distribution/Discrete.birch"
  libbirch_line_(22);
  #line 22 "birch/distribution/Discrete.birch"
  return shared_from_this_();
}

#line 4 "birch/distribution/DiscreteDelta.birch"
birch::type::DiscreteDelta::DiscreteDelta(const libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/DiscreteDelta.birch"
    super_type_(),
    #line 8 "birch/distribution/DiscreteDelta.birch"
    _u0956(_u0956) {
  //
}

#line 10 "birch/distribution/DiscreteDelta.birch"
birch::type::Boolean birch::type::DiscreteDelta::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "birch/distribution/DiscreteDelta.birch"
  libbirch_function_("supportsLazy", "birch/distribution/DiscreteDelta.birch", 10);
  #line 11 "birch/distribution/DiscreteDelta.birch"
  libbirch_line_(11);
  #line 11 "birch/distribution/DiscreteDelta.birch"
  return false;
}

#line 14 "birch/distribution/DiscreteDelta.birch"
birch::type::Integer birch::type::DiscreteDelta::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "birch/distribution/DiscreteDelta.birch"
  libbirch_function_("simulate", "birch/distribution/DiscreteDelta.birch", 14);
  #line 15 "birch/distribution/DiscreteDelta.birch"
  libbirch_line_(15);
  #line 15 "birch/distribution/DiscreteDelta.birch"
  if (this_()->value.query()) {
    #line 16 "birch/distribution/DiscreteDelta.birch"
    libbirch_line_(16);
    #line 16 "birch/distribution/DiscreteDelta.birch"
    return birch::simulate_delta(this_()->value.get(), handler_);
  } else {
    #line 18 "birch/distribution/DiscreteDelta.birch"
    libbirch_line_(18);
    #line 18 "birch/distribution/DiscreteDelta.birch"
    return birch::simulate_delta(this_()->_u0956->simulate(handler_), handler_);
  }
}

#line 30 "birch/distribution/DiscreteDelta.birch"
birch::type::Real birch::type::DiscreteDelta::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "birch/distribution/DiscreteDelta.birch"
  libbirch_function_("logpdf", "birch/distribution/DiscreteDelta.birch", 30);
  #line 31 "birch/distribution/DiscreteDelta.birch"
  libbirch_line_(31);
  #line 31 "birch/distribution/DiscreteDelta.birch"
  if (this_()->value.query()) {
    #line 32 "birch/distribution/DiscreteDelta.birch"
    libbirch_line_(32);
    #line 32 "birch/distribution/DiscreteDelta.birch"
    return birch::logpdf_delta(x, this_()->value.get(), handler_);
  } else {
    #line 34 "birch/distribution/DiscreteDelta.birch"
    libbirch_line_(34);
    #line 34 "birch/distribution/DiscreteDelta.birch"
    return this_()->_u0956->logpdf(x, handler_);
  }
}

#line 46 "birch/distribution/DiscreteDelta.birch"
void birch::type::DiscreteDelta::update(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "birch/distribution/DiscreteDelta.birch"
  libbirch_function_("update", "birch/distribution/DiscreteDelta.birch", 46);
  #line 47 "birch/distribution/DiscreteDelta.birch"
  libbirch_line_(47);
  #line 47 "birch/distribution/DiscreteDelta.birch"
  this_()->_u0956->clamp(x, handler_);
}

#line 54 "birch/distribution/DiscreteDelta.birch"
libbirch::Optional<birch::type::Real> birch::type::DiscreteDelta::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "birch/distribution/DiscreteDelta.birch"
  libbirch_function_("cdf", "birch/distribution/DiscreteDelta.birch", 54);
  #line 55 "birch/distribution/DiscreteDelta.birch"
  libbirch_line_(55);
  #line 55 "birch/distribution/DiscreteDelta.birch"
  return this_()->_u0956->cdf(x, handler_);
}

#line 58 "birch/distribution/DiscreteDelta.birch"
libbirch::Optional<birch::type::Integer> birch::type::DiscreteDelta::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "birch/distribution/DiscreteDelta.birch"
  libbirch_function_("lower", "birch/distribution/DiscreteDelta.birch", 58);
  #line 59 "birch/distribution/DiscreteDelta.birch"
  libbirch_line_(59);
  #line 59 "birch/distribution/DiscreteDelta.birch"
  return this_()->_u0956->lower(handler_);
}

#line 62 "birch/distribution/DiscreteDelta.birch"
libbirch::Optional<birch::type::Integer> birch::type::DiscreteDelta::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 62 "birch/distribution/DiscreteDelta.birch"
  libbirch_function_("upper", "birch/distribution/DiscreteDelta.birch", 62);
  #line 63 "birch/distribution/DiscreteDelta.birch"
  libbirch_line_(63);
  #line 63 "birch/distribution/DiscreteDelta.birch"
  return this_()->_u0956->upper(handler_);
}

#line 66 "birch/distribution/DiscreteDelta.birch"
void birch::type::DiscreteDelta::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "birch/distribution/DiscreteDelta.birch"
  libbirch_function_("link", "birch/distribution/DiscreteDelta.birch", 66);
}

#line 71 "birch/distribution/DiscreteDelta.birch"
void birch::type::DiscreteDelta::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 71 "birch/distribution/DiscreteDelta.birch"
  libbirch_function_("unlink", "birch/distribution/DiscreteDelta.birch", 71);
}

#line 77 "birch/distribution/DiscreteDelta.birch"
libbirch::Lazy<libbirch::Shared<birch::type::DiscreteDelta>> birch::DiscreteDelta(const libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 77 "birch/distribution/DiscreteDelta.birch"
  libbirch_function_("DiscreteDelta", "birch/distribution/DiscreteDelta.birch", 77);
  #line 78 "birch/distribution/DiscreteDelta.birch"
  libbirch_line_(78);
  #line 78 "birch/distribution/DiscreteDelta.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::DiscreteDelta>> m(_u0956);
  #line 79 "birch/distribution/DiscreteDelta.birch"
  libbirch_line_(79);
  #line 79 "birch/distribution/DiscreteDelta.birch"
  m->link(handler_);
  #line 80 "birch/distribution/DiscreteDelta.birch"
  libbirch_line_(80);
  #line 80 "birch/distribution/DiscreteDelta.birch"
  return m;
}

#line 1 "birch/distribution/Exponential.birch"
birch::type::Exponential::Exponential(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/distribution/Exponential.birch"
    super_type_(),
    #line 8 "birch/distribution/Exponential.birch"
    _u0955(_u0955) {
  //
}

#line 10 "birch/distribution/Exponential.birch"
birch::type::Boolean birch::type::Exponential::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "birch/distribution/Exponential.birch"
  libbirch_function_("supportsLazy", "birch/distribution/Exponential.birch", 10);
  #line 11 "birch/distribution/Exponential.birch"
  libbirch_line_(11);
  #line 11 "birch/distribution/Exponential.birch"
  return true;
}

#line 14 "birch/distribution/Exponential.birch"
birch::type::Real birch::type::Exponential::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "birch/distribution/Exponential.birch"
  libbirch_function_("simulate", "birch/distribution/Exponential.birch", 14);
  #line 15 "birch/distribution/Exponential.birch"
  libbirch_line_(15);
  #line 15 "birch/distribution/Exponential.birch"
  return birch::simulate_exponential(this_()->_u0955->value(handler_), handler_);
}

#line 18 "birch/distribution/Exponential.birch"
libbirch::Optional<birch::type::Real> birch::type::Exponential::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "birch/distribution/Exponential.birch"
  libbirch_function_("simulateLazy", "birch/distribution/Exponential.birch", 18);
  #line 19 "birch/distribution/Exponential.birch"
  libbirch_line_(19);
  #line 19 "birch/distribution/Exponential.birch"
  return birch::simulate_exponential(this_()->_u0955->get(handler_), handler_);
}

#line 22 "birch/distribution/Exponential.birch"
birch::type::Real birch::type::Exponential::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "birch/distribution/Exponential.birch"
  libbirch_function_("logpdf", "birch/distribution/Exponential.birch", 22);
  #line 23 "birch/distribution/Exponential.birch"
  libbirch_line_(23);
  #line 23 "birch/distribution/Exponential.birch"
  return birch::logpdf_exponential(x, this_()->_u0955->value(handler_), handler_);
}

#line 26 "birch/distribution/Exponential.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::Exponential::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "birch/distribution/Exponential.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/Exponential.birch", 26);
  #line 27 "birch/distribution/Exponential.birch"
  libbirch_line_(27);
  #line 27 "birch/distribution/Exponential.birch"
  return birch::logpdf_lazy_exponential(x, this_()->_u0955, handler_);
}

#line 30 "birch/distribution/Exponential.birch"
libbirch::Optional<birch::type::Real> birch::type::Exponential::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "birch/distribution/Exponential.birch"
  libbirch_function_("cdf", "birch/distribution/Exponential.birch", 30);
  #line 31 "birch/distribution/Exponential.birch"
  libbirch_line_(31);
  #line 31 "birch/distribution/Exponential.birch"
  return birch::cdf_exponential(x, this_()->_u0955->value(handler_), handler_);
}

#line 34 "birch/distribution/Exponential.birch"
libbirch::Optional<birch::type::Real> birch::type::Exponential::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "birch/distribution/Exponential.birch"
  libbirch_function_("quantile", "birch/distribution/Exponential.birch", 34);
  #line 35 "birch/distribution/Exponential.birch"
  libbirch_line_(35);
  #line 35 "birch/distribution/Exponential.birch"
  return birch::quantile_exponential(P, this_()->_u0955->value(handler_), handler_);
}

#line 38 "birch/distribution/Exponential.birch"
libbirch::Optional<birch::type::Real> birch::type::Exponential::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "birch/distribution/Exponential.birch"
  libbirch_function_("lower", "birch/distribution/Exponential.birch", 38);
  #line 39 "birch/distribution/Exponential.birch"
  libbirch_line_(39);
  #line 39 "birch/distribution/Exponential.birch"
  return 0.0;
}

#line 42 "birch/distribution/Exponential.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> birch::type::Exponential::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "birch/distribution/Exponential.birch"
  libbirch_function_("graft", "birch/distribution/Exponential.birch", 42);
  #line 43 "birch/distribution/Exponential.birch"
  libbirch_line_(43);
  #line 43 "birch/distribution/Exponential.birch"
  this_()->prune(handler_);
  #line 44 "birch/distribution/Exponential.birch"
  libbirch_line_(44);
  #line 44 "birch/distribution/Exponential.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>>>>> m1;
  #line 45 "birch/distribution/Exponential.birch"
  libbirch_line_(45);
  #line 45 "birch/distribution/Exponential.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>> m2;
  #line 46 "birch/distribution/Exponential.birch"
  libbirch_line_(46);
  #line 46 "birch/distribution/Exponential.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> r = shared_from_this_();
  #line 49 "birch/distribution/Exponential.birch"
  libbirch_line_(49);
  #line 49 "birch/distribution/Exponential.birch"
  if ((m1 = this_()->_u0955->graftScaledGamma(handler_)).query()) {
    #line 50 "birch/distribution/Exponential.birch"
    libbirch_line_(50);
    #line 50 "birch/distribution/Exponential.birch"
    r = birch::ScaledGammaExponential(m1.get()->a, m1.get()->x, handler_);
  } else {
    #line 51 "birch/distribution/Exponential.birch"
    libbirch_line_(51);
    #line 51 "birch/distribution/Exponential.birch"
    if ((m2 = this_()->_u0955->graftGamma(handler_)).query()) {
      #line 52 "birch/distribution/Exponential.birch"
      libbirch_line_(52);
      #line 52 "birch/distribution/Exponential.birch"
      r = birch::GammaExponential(m2.get(), handler_);
    }
  }
  #line 55 "birch/distribution/Exponential.birch"
  libbirch_line_(55);
  #line 55 "birch/distribution/Exponential.birch"
  return r;
}

#line 58 "birch/distribution/Exponential.birch"
void birch::type::Exponential::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "birch/distribution/Exponential.birch"
  libbirch_function_("write", "birch/distribution/Exponential.birch", 58);
  #line 59 "birch/distribution/Exponential.birch"
  libbirch_line_(59);
  #line 59 "birch/distribution/Exponential.birch"
  this_()->prune(handler_);
  #line 60 "birch/distribution/Exponential.birch"
  libbirch_line_(60);
  #line 60 "birch/distribution/Exponential.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Exponential"), handler_);
  #line 61 "birch/distribution/Exponential.birch"
  libbirch_line_(61);
  #line 61 "birch/distribution/Exponential.birch"
  buffer->set(birch::type::String("λ"), this_()->_u0955, handler_);
}

#line 68 "birch/distribution/Exponential.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Exponential>> birch::Exponential(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 68 "birch/distribution/Exponential.birch"
  libbirch_function_("Exponential", "birch/distribution/Exponential.birch", 68);
  #line 69 "birch/distribution/Exponential.birch"
  libbirch_line_(69);
  #line 69 "birch/distribution/Exponential.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Exponential>>>(_u0955, handler_);
}

#line 75 "birch/distribution/Exponential.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Exponential>> birch::Exponential(const birch::type::Real& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 75 "birch/distribution/Exponential.birch"
  libbirch_function_("Exponential", "birch/distribution/Exponential.birch", 75);
  #line 76 "birch/distribution/Exponential.birch"
  libbirch_line_(76);
  #line 76 "birch/distribution/Exponential.birch"
  return birch::Exponential(birch::box(_u0955, handler_), handler_);
}

#line 1 "birch/distribution/Gamma.birch"
birch::type::Gamma::Gamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/distribution/Gamma.birch"
    super_type_(),
    #line 8 "birch/distribution/Gamma.birch"
    k(k),
    #line 13 "birch/distribution/Gamma.birch"
    _u0952(_u0952) {
  //
}

#line 15 "birch/distribution/Gamma.birch"
birch::type::Boolean birch::type::Gamma::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "birch/distribution/Gamma.birch"
  libbirch_function_("supportsLazy", "birch/distribution/Gamma.birch", 15);
  #line 16 "birch/distribution/Gamma.birch"
  libbirch_line_(16);
  #line 16 "birch/distribution/Gamma.birch"
  return true;
}

#line 19 "birch/distribution/Gamma.birch"
birch::type::Real birch::type::Gamma::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "birch/distribution/Gamma.birch"
  libbirch_function_("simulate", "birch/distribution/Gamma.birch", 19);
  #line 20 "birch/distribution/Gamma.birch"
  libbirch_line_(20);
  #line 20 "birch/distribution/Gamma.birch"
  return birch::simulate_gamma(this_()->k->value(handler_), this_()->_u0952->value(handler_), handler_);
}

#line 23 "birch/distribution/Gamma.birch"
libbirch::Optional<birch::type::Real> birch::type::Gamma::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "birch/distribution/Gamma.birch"
  libbirch_function_("simulateLazy", "birch/distribution/Gamma.birch", 23);
  #line 24 "birch/distribution/Gamma.birch"
  libbirch_line_(24);
  #line 24 "birch/distribution/Gamma.birch"
  return birch::simulate_gamma(this_()->k->get(handler_), this_()->_u0952->get(handler_), handler_);
}

#line 27 "birch/distribution/Gamma.birch"
birch::type::Real birch::type::Gamma::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "birch/distribution/Gamma.birch"
  libbirch_function_("logpdf", "birch/distribution/Gamma.birch", 27);
  #line 28 "birch/distribution/Gamma.birch"
  libbirch_line_(28);
  #line 28 "birch/distribution/Gamma.birch"
  return birch::logpdf_gamma(x, this_()->k->value(handler_), this_()->_u0952->value(handler_), handler_);
}

#line 31 "birch/distribution/Gamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::Gamma::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "birch/distribution/Gamma.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/Gamma.birch", 31);
  #line 32 "birch/distribution/Gamma.birch"
  libbirch_line_(32);
  #line 32 "birch/distribution/Gamma.birch"
  return birch::logpdf_lazy_gamma(x, this_()->k, this_()->_u0952, handler_);
}

#line 35 "birch/distribution/Gamma.birch"
libbirch::Optional<birch::type::Real> birch::type::Gamma::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "birch/distribution/Gamma.birch"
  libbirch_function_("cdf", "birch/distribution/Gamma.birch", 35);
  #line 36 "birch/distribution/Gamma.birch"
  libbirch_line_(36);
  #line 36 "birch/distribution/Gamma.birch"
  return birch::cdf_gamma(x, this_()->k->value(handler_), this_()->_u0952->value(handler_), handler_);
}

#line 39 "birch/distribution/Gamma.birch"
libbirch::Optional<birch::type::Real> birch::type::Gamma::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "birch/distribution/Gamma.birch"
  libbirch_function_("quantile", "birch/distribution/Gamma.birch", 39);
  #line 40 "birch/distribution/Gamma.birch"
  libbirch_line_(40);
  #line 40 "birch/distribution/Gamma.birch"
  return birch::quantile_gamma(P, this_()->k->value(handler_), this_()->_u0952->value(handler_), handler_);
}

#line 43 "birch/distribution/Gamma.birch"
libbirch::Optional<birch::type::Real> birch::type::Gamma::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "birch/distribution/Gamma.birch"
  libbirch_function_("lower", "birch/distribution/Gamma.birch", 43);
  #line 44 "birch/distribution/Gamma.birch"
  libbirch_line_(44);
  #line 44 "birch/distribution/Gamma.birch"
  return 0.0;
}

#line 47 "birch/distribution/Gamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> birch::type::Gamma::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "birch/distribution/Gamma.birch"
  libbirch_function_("graft", "birch/distribution/Gamma.birch", 47);
  #line 48 "birch/distribution/Gamma.birch"
  libbirch_line_(48);
  #line 48 "birch/distribution/Gamma.birch"
  this_()->prune(handler_);
  #line 49 "birch/distribution/Gamma.birch"
  libbirch_line_(49);
  #line 49 "birch/distribution/Gamma.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>> _u09521;
  #line 50 "birch/distribution/Gamma.birch"
  libbirch_line_(50);
  #line 50 "birch/distribution/Gamma.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> r = shared_from_this_();
  #line 53 "birch/distribution/Gamma.birch"
  libbirch_line_(53);
  #line 53 "birch/distribution/Gamma.birch"
  if ((_u09521 = this_()->_u0952->graftInverseGamma(handler_)).query()) {
    #line 54 "birch/distribution/Gamma.birch"
    libbirch_line_(54);
    #line 54 "birch/distribution/Gamma.birch"
    r = birch::InverseGammaGamma(this_()->k, _u09521.get(), handler_);
  }
  #line 57 "birch/distribution/Gamma.birch"
  libbirch_line_(57);
  #line 57 "birch/distribution/Gamma.birch"
  return r;
}

#line 60 "birch/distribution/Gamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>> birch::type::Gamma::graftGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "birch/distribution/Gamma.birch"
  libbirch_function_("graftGamma", "birch/distribution/Gamma.birch", 60);
  #line 61 "birch/distribution/Gamma.birch"
  libbirch_line_(61);
  #line 61 "birch/distribution/Gamma.birch"
  this_()->prune(handler_);
  #line 62 "birch/distribution/Gamma.birch"
  libbirch_line_(62);
  #line 62 "birch/distribution/Gamma.birch"
  return shared_from_this_();
}

#line 65 "birch/distribution/Gamma.birch"
void birch::type::Gamma::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "birch/distribution/Gamma.birch"
  libbirch_function_("write", "birch/distribution/Gamma.birch", 65);
  #line 66 "birch/distribution/Gamma.birch"
  libbirch_line_(66);
  #line 66 "birch/distribution/Gamma.birch"
  this_()->prune(handler_);
  #line 67 "birch/distribution/Gamma.birch"
  libbirch_line_(67);
  #line 67 "birch/distribution/Gamma.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Gamma"), handler_);
  #line 68 "birch/distribution/Gamma.birch"
  libbirch_line_(68);
  #line 68 "birch/distribution/Gamma.birch"
  buffer->set(birch::type::String("k"), this_()->k, handler_);
  #line 69 "birch/distribution/Gamma.birch"
  libbirch_line_(69);
  #line 69 "birch/distribution/Gamma.birch"
  buffer->set(birch::type::String("θ"), this_()->_u0952, handler_);
}

#line 76 "birch/distribution/Gamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Gamma>> birch::Gamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "birch/distribution/Gamma.birch"
  libbirch_function_("Gamma", "birch/distribution/Gamma.birch", 76);
  #line 77 "birch/distribution/Gamma.birch"
  libbirch_line_(77);
  #line 77 "birch/distribution/Gamma.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>>(k, _u0952, handler_);
}

#line 83 "birch/distribution/Gamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Gamma>> birch::Gamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const birch::type::Real& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 83 "birch/distribution/Gamma.birch"
  libbirch_function_("Gamma", "birch/distribution/Gamma.birch", 83);
  #line 84 "birch/distribution/Gamma.birch"
  libbirch_line_(84);
  #line 84 "birch/distribution/Gamma.birch"
  return birch::Gamma(k, birch::box(_u0952, handler_), handler_);
}

#line 90 "birch/distribution/Gamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Gamma>> birch::Gamma(const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 90 "birch/distribution/Gamma.birch"
  libbirch_function_("Gamma", "birch/distribution/Gamma.birch", 90);
  #line 91 "birch/distribution/Gamma.birch"
  libbirch_line_(91);
  #line 91 "birch/distribution/Gamma.birch"
  return birch::Gamma(birch::box(k, handler_), _u0952, handler_);
}

#line 97 "birch/distribution/Gamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Gamma>> birch::Gamma(const birch::type::Real& k, const birch::type::Real& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 97 "birch/distribution/Gamma.birch"
  libbirch_function_("Gamma", "birch/distribution/Gamma.birch", 97);
  #line 98 "birch/distribution/Gamma.birch"
  libbirch_line_(98);
  #line 98 "birch/distribution/Gamma.birch"
  return birch::Gamma(birch::box(k, handler_), birch::box(_u0952, handler_), handler_);
}

#line 4 "birch/distribution/GammaExponential.birch"
birch::type::GammaExponential::GammaExponential(const libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/GammaExponential.birch"
    super_type_(),
    #line 8 "birch/distribution/GammaExponential.birch"
    _u0955(_u0955) {
  //
}

#line 10 "birch/distribution/GammaExponential.birch"
birch::type::Boolean birch::type::GammaExponential::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "birch/distribution/GammaExponential.birch"
  libbirch_function_("supportsLazy", "birch/distribution/GammaExponential.birch", 10);
  #line 11 "birch/distribution/GammaExponential.birch"
  libbirch_line_(11);
  #line 11 "birch/distribution/GammaExponential.birch"
  return true;
}

#line 14 "birch/distribution/GammaExponential.birch"
birch::type::Real birch::type::GammaExponential::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "birch/distribution/GammaExponential.birch"
  libbirch_function_("simulate", "birch/distribution/GammaExponential.birch", 14);
  #line 15 "birch/distribution/GammaExponential.birch"
  libbirch_line_(15);
  #line 15 "birch/distribution/GammaExponential.birch"
  return birch::simulate_lomax(1.0 / this_()->_u0955->_u0952->value(handler_), this_()->_u0955->k->value(handler_), handler_);
}

#line 18 "birch/distribution/GammaExponential.birch"
libbirch::Optional<birch::type::Real> birch::type::GammaExponential::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "birch/distribution/GammaExponential.birch"
  libbirch_function_("simulateLazy", "birch/distribution/GammaExponential.birch", 18);
  #line 19 "birch/distribution/GammaExponential.birch"
  libbirch_line_(19);
  #line 19 "birch/distribution/GammaExponential.birch"
  return birch::simulate_lomax(1.0 / this_()->_u0955->_u0952->get(handler_), this_()->_u0955->k->get(handler_), handler_);
}

#line 22 "birch/distribution/GammaExponential.birch"
birch::type::Real birch::type::GammaExponential::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "birch/distribution/GammaExponential.birch"
  libbirch_function_("logpdf", "birch/distribution/GammaExponential.birch", 22);
  #line 23 "birch/distribution/GammaExponential.birch"
  libbirch_line_(23);
  #line 23 "birch/distribution/GammaExponential.birch"
  return birch::logpdf_lomax(x, 1.0 / this_()->_u0955->_u0952->value(handler_), this_()->_u0955->k->value(handler_), handler_);
}

#line 26 "birch/distribution/GammaExponential.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::GammaExponential::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "birch/distribution/GammaExponential.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/GammaExponential.birch", 26);
  #line 27 "birch/distribution/GammaExponential.birch"
  libbirch_line_(27);
  #line 27 "birch/distribution/GammaExponential.birch"
  return birch::logpdf_lazy_lomax(x, 1.0 / this_()->_u0955->_u0952, this_()->_u0955->k, handler_);
}

#line 30 "birch/distribution/GammaExponential.birch"
void birch::type::GammaExponential::update(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "birch/distribution/GammaExponential.birch"
  libbirch_function_("update", "birch/distribution/GammaExponential.birch", 30);
  #line 31 "birch/distribution/GammaExponential.birch"
  libbirch_line_(31);
  #line 31 "birch/distribution/GammaExponential.birch"
  libbirch::tie(this_()->_u0955->k, this_()->_u0955->_u0952) = birch::box(birch::update_gamma_exponential(x, this_()->_u0955->k->value(handler_), this_()->_u0955->_u0952->value(handler_), handler_), handler_);
}

#line 34 "birch/distribution/GammaExponential.birch"
void birch::type::GammaExponential::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "birch/distribution/GammaExponential.birch"
  libbirch_function_("updateLazy", "birch/distribution/GammaExponential.birch", 34);
  #line 35 "birch/distribution/GammaExponential.birch"
  libbirch_line_(35);
  #line 35 "birch/distribution/GammaExponential.birch"
  libbirch::tie(this_()->_u0955->k, this_()->_u0955->_u0952) = birch::update_lazy_gamma_exponential(x, this_()->_u0955->k, this_()->_u0955->_u0952, handler_);
}

#line 38 "birch/distribution/GammaExponential.birch"
void birch::type::GammaExponential::downdate(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "birch/distribution/GammaExponential.birch"
  libbirch_function_("downdate", "birch/distribution/GammaExponential.birch", 38);
  #line 39 "birch/distribution/GammaExponential.birch"
  libbirch_line_(39);
  #line 39 "birch/distribution/GammaExponential.birch"
  libbirch::tie(this_()->_u0955->k, this_()->_u0955->_u0952) = birch::box(birch::downdate_gamma_exponential(x, this_()->_u0955->k->value(handler_), this_()->_u0955->_u0952->value(handler_), handler_), handler_);
}

#line 42 "birch/distribution/GammaExponential.birch"
libbirch::Optional<birch::type::Real> birch::type::GammaExponential::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "birch/distribution/GammaExponential.birch"
  libbirch_function_("cdf", "birch/distribution/GammaExponential.birch", 42);
  #line 43 "birch/distribution/GammaExponential.birch"
  libbirch_line_(43);
  #line 43 "birch/distribution/GammaExponential.birch"
  return birch::cdf_lomax(x, 1.0 / this_()->_u0955->_u0952->value(handler_), this_()->_u0955->k->value(handler_), handler_);
}

#line 46 "birch/distribution/GammaExponential.birch"
libbirch::Optional<birch::type::Real> birch::type::GammaExponential::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "birch/distribution/GammaExponential.birch"
  libbirch_function_("quantile", "birch/distribution/GammaExponential.birch", 46);
  #line 47 "birch/distribution/GammaExponential.birch"
  libbirch_line_(47);
  #line 47 "birch/distribution/GammaExponential.birch"
  return birch::quantile_lomax(P, 1.0 / this_()->_u0955->_u0952->value(handler_), this_()->_u0955->k->value(handler_), handler_);
}

#line 50 "birch/distribution/GammaExponential.birch"
libbirch::Optional<birch::type::Real> birch::type::GammaExponential::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "birch/distribution/GammaExponential.birch"
  libbirch_function_("lower", "birch/distribution/GammaExponential.birch", 50);
  #line 51 "birch/distribution/GammaExponential.birch"
  libbirch_line_(51);
  #line 51 "birch/distribution/GammaExponential.birch"
  return 0.0;
}

#line 54 "birch/distribution/GammaExponential.birch"
void birch::type::GammaExponential::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "birch/distribution/GammaExponential.birch"
  libbirch_function_("link", "birch/distribution/GammaExponential.birch", 54);
  #line 55 "birch/distribution/GammaExponential.birch"
  libbirch_line_(55);
  #line 55 "birch/distribution/GammaExponential.birch"
  this_()->_u0955->setChild(shared_from_this_(), handler_);
}

#line 58 "birch/distribution/GammaExponential.birch"
void birch::type::GammaExponential::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "birch/distribution/GammaExponential.birch"
  libbirch_function_("unlink", "birch/distribution/GammaExponential.birch", 58);
  #line 59 "birch/distribution/GammaExponential.birch"
  libbirch_line_(59);
  #line 59 "birch/distribution/GammaExponential.birch"
  this_()->_u0955->releaseChild(shared_from_this_(), handler_);
}

#line 63 "birch/distribution/GammaExponential.birch"
libbirch::Lazy<libbirch::Shared<birch::type::GammaExponential>> birch::GammaExponential(const libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 63 "birch/distribution/GammaExponential.birch"
  libbirch_function_("GammaExponential", "birch/distribution/GammaExponential.birch", 63);
  #line 64 "birch/distribution/GammaExponential.birch"
  libbirch_line_(64);
  #line 64 "birch/distribution/GammaExponential.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::GammaExponential>> m(_u0955);
  #line 65 "birch/distribution/GammaExponential.birch"
  libbirch_line_(65);
  #line 65 "birch/distribution/GammaExponential.birch"
  m->link(handler_);
  #line 66 "birch/distribution/GammaExponential.birch"
  libbirch_line_(66);
  #line 66 "birch/distribution/GammaExponential.birch"
  return m;
}

#line 4 "birch/distribution/GammaPoisson.birch"
birch::type::GammaPoisson::GammaPoisson(const libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/GammaPoisson.birch"
    super_type_(),
    #line 8 "birch/distribution/GammaPoisson.birch"
    _u0955(_u0955) {
  //
}

#line 10 "birch/distribution/GammaPoisson.birch"
birch::type::Boolean birch::type::GammaPoisson::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "birch/distribution/GammaPoisson.birch"
  libbirch_function_("supportsLazy", "birch/distribution/GammaPoisson.birch", 10);
  #line 11 "birch/distribution/GammaPoisson.birch"
  libbirch_line_(11);
  #line 11 "birch/distribution/GammaPoisson.birch"
  return true;
}

#line 14 "birch/distribution/GammaPoisson.birch"
birch::type::Integer birch::type::GammaPoisson::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "birch/distribution/GammaPoisson.birch"
  libbirch_function_("simulate", "birch/distribution/GammaPoisson.birch", 14);
  #line 15 "birch/distribution/GammaPoisson.birch"
  libbirch_line_(15);
  #line 15 "birch/distribution/GammaPoisson.birch"
  if (this_()->value.query()) {
    #line 16 "birch/distribution/GammaPoisson.birch"
    libbirch_line_(16);
    #line 16 "birch/distribution/GammaPoisson.birch"
    return this_()->value.get();
  } else {
    #line 18 "birch/distribution/GammaPoisson.birch"
    libbirch_line_(18);
    #line 18 "birch/distribution/GammaPoisson.birch"
    return birch::simulate_gamma_poisson(this_()->_u0955->k->value(handler_), this_()->_u0955->_u0952->value(handler_), handler_);
  }
}

#line 22 "birch/distribution/GammaPoisson.birch"
libbirch::Optional<birch::type::Integer> birch::type::GammaPoisson::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "birch/distribution/GammaPoisson.birch"
  libbirch_function_("simulateLazy", "birch/distribution/GammaPoisson.birch", 22);
  #line 23 "birch/distribution/GammaPoisson.birch"
  libbirch_line_(23);
  #line 23 "birch/distribution/GammaPoisson.birch"
  if (this_()->value.query()) {
    #line 24 "birch/distribution/GammaPoisson.birch"
    libbirch_line_(24);
    #line 24 "birch/distribution/GammaPoisson.birch"
    return this_()->value.get();
  } else {
    #line 26 "birch/distribution/GammaPoisson.birch"
    libbirch_line_(26);
    #line 26 "birch/distribution/GammaPoisson.birch"
    return birch::simulate_gamma_poisson(this_()->_u0955->k->get(handler_), this_()->_u0955->_u0952->get(handler_), handler_);
  }
}

#line 30 "birch/distribution/GammaPoisson.birch"
birch::type::Real birch::type::GammaPoisson::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "birch/distribution/GammaPoisson.birch"
  libbirch_function_("logpdf", "birch/distribution/GammaPoisson.birch", 30);
  #line 31 "birch/distribution/GammaPoisson.birch"
  libbirch_line_(31);
  #line 31 "birch/distribution/GammaPoisson.birch"
  return birch::logpdf_gamma_poisson(x, this_()->_u0955->k->value(handler_), this_()->_u0955->_u0952->value(handler_), handler_);
}

#line 34 "birch/distribution/GammaPoisson.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::GammaPoisson::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "birch/distribution/GammaPoisson.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/GammaPoisson.birch", 34);
  #line 35 "birch/distribution/GammaPoisson.birch"
  libbirch_line_(35);
  #line 35 "birch/distribution/GammaPoisson.birch"
  return birch::logpdf_lazy_gamma_poisson(x, this_()->_u0955->k, this_()->_u0955->_u0952, handler_);
}

#line 38 "birch/distribution/GammaPoisson.birch"
void birch::type::GammaPoisson::update(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "birch/distribution/GammaPoisson.birch"
  libbirch_function_("update", "birch/distribution/GammaPoisson.birch", 38);
  #line 39 "birch/distribution/GammaPoisson.birch"
  libbirch_line_(39);
  #line 39 "birch/distribution/GammaPoisson.birch"
  libbirch::tie(this_()->_u0955->k, this_()->_u0955->_u0952) = birch::box(birch::update_gamma_poisson(x, this_()->_u0955->k->value(handler_), this_()->_u0955->_u0952->value(handler_), handler_), handler_);
}

#line 42 "birch/distribution/GammaPoisson.birch"
void birch::type::GammaPoisson::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "birch/distribution/GammaPoisson.birch"
  libbirch_function_("updateLazy", "birch/distribution/GammaPoisson.birch", 42);
  #line 43 "birch/distribution/GammaPoisson.birch"
  libbirch_line_(43);
  #line 43 "birch/distribution/GammaPoisson.birch"
  libbirch::tie(this_()->_u0955->k, this_()->_u0955->_u0952) = birch::update_lazy_gamma_poisson(x, this_()->_u0955->k, this_()->_u0955->_u0952, handler_);
}

#line 46 "birch/distribution/GammaPoisson.birch"
void birch::type::GammaPoisson::downdate(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "birch/distribution/GammaPoisson.birch"
  libbirch_function_("downdate", "birch/distribution/GammaPoisson.birch", 46);
  #line 47 "birch/distribution/GammaPoisson.birch"
  libbirch_line_(47);
  #line 47 "birch/distribution/GammaPoisson.birch"
  libbirch::tie(this_()->_u0955->k, this_()->_u0955->_u0952) = birch::box(birch::downdate_gamma_poisson(x, this_()->_u0955->k->value(handler_), this_()->_u0955->_u0952->value(handler_), handler_), handler_);
}

#line 50 "birch/distribution/GammaPoisson.birch"
libbirch::Optional<birch::type::Real> birch::type::GammaPoisson::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "birch/distribution/GammaPoisson.birch"
  libbirch_function_("cdf", "birch/distribution/GammaPoisson.birch", 50);
  #line 51 "birch/distribution/GammaPoisson.birch"
  libbirch_line_(51);
  #line 51 "birch/distribution/GammaPoisson.birch"
  return birch::cdf_gamma_poisson(x, this_()->_u0955->k->value(handler_), this_()->_u0955->_u0952->value(handler_), handler_);
}

#line 54 "birch/distribution/GammaPoisson.birch"
libbirch::Optional<birch::type::Integer> birch::type::GammaPoisson::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "birch/distribution/GammaPoisson.birch"
  libbirch_function_("quantile", "birch/distribution/GammaPoisson.birch", 54);
  #line 55 "birch/distribution/GammaPoisson.birch"
  libbirch_line_(55);
  #line 55 "birch/distribution/GammaPoisson.birch"
  return birch::quantile_gamma_poisson(P, this_()->_u0955->k->value(handler_), this_()->_u0955->_u0952->value(handler_), handler_);
}

#line 58 "birch/distribution/GammaPoisson.birch"
libbirch::Optional<birch::type::Integer> birch::type::GammaPoisson::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "birch/distribution/GammaPoisson.birch"
  libbirch_function_("lower", "birch/distribution/GammaPoisson.birch", 58);
  #line 59 "birch/distribution/GammaPoisson.birch"
  libbirch_line_(59);
  #line 59 "birch/distribution/GammaPoisson.birch"
  return birch::type::Integer(0);
}

#line 62 "birch/distribution/GammaPoisson.birch"
void birch::type::GammaPoisson::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 62 "birch/distribution/GammaPoisson.birch"
  libbirch_function_("link", "birch/distribution/GammaPoisson.birch", 62);
  #line 63 "birch/distribution/GammaPoisson.birch"
  libbirch_line_(63);
  #line 63 "birch/distribution/GammaPoisson.birch"
  this_()->_u0955->setChild(shared_from_this_(), handler_);
}

#line 66 "birch/distribution/GammaPoisson.birch"
void birch::type::GammaPoisson::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "birch/distribution/GammaPoisson.birch"
  libbirch_function_("unlink", "birch/distribution/GammaPoisson.birch", 66);
  #line 67 "birch/distribution/GammaPoisson.birch"
  libbirch_line_(67);
  #line 67 "birch/distribution/GammaPoisson.birch"
  this_()->_u0955->releaseChild(shared_from_this_(), handler_);
}

#line 71 "birch/distribution/GammaPoisson.birch"
libbirch::Lazy<libbirch::Shared<birch::type::GammaPoisson>> birch::GammaPoisson(const libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 71 "birch/distribution/GammaPoisson.birch"
  libbirch_function_("GammaPoisson", "birch/distribution/GammaPoisson.birch", 71);
  #line 72 "birch/distribution/GammaPoisson.birch"
  libbirch_line_(72);
  #line 72 "birch/distribution/GammaPoisson.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::GammaPoisson>> m(_u0955);
  #line 73 "birch/distribution/GammaPoisson.birch"
  libbirch_line_(73);
  #line 73 "birch/distribution/GammaPoisson.birch"
  m->link(handler_);
  #line 74 "birch/distribution/GammaPoisson.birch"
  libbirch_line_(74);
  #line 74 "birch/distribution/GammaPoisson.birch"
  return m;
}

#line 1 "birch/distribution/Gaussian.birch"
birch::type::Gaussian::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/distribution/Gaussian.birch"
    super_type_(),
    #line 9 "birch/distribution/Gaussian.birch"
    _u0956(_u0956),
    #line 14 "birch/distribution/Gaussian.birch"
    _u09632(_u09632) {
  //
}

#line 16 "birch/distribution/Gaussian.birch"
birch::type::Boolean birch::type::Gaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "birch/distribution/Gaussian.birch"
  libbirch_function_("supportsLazy", "birch/distribution/Gaussian.birch", 16);
  #line 17 "birch/distribution/Gaussian.birch"
  libbirch_line_(17);
  #line 17 "birch/distribution/Gaussian.birch"
  return true;
}

#line 20 "birch/distribution/Gaussian.birch"
birch::type::Real birch::type::Gaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "birch/distribution/Gaussian.birch"
  libbirch_function_("simulate", "birch/distribution/Gaussian.birch", 20);
  #line 21 "birch/distribution/Gaussian.birch"
  libbirch_line_(21);
  #line 21 "birch/distribution/Gaussian.birch"
  return birch::simulate_gaussian(this_()->_u0956->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 24 "birch/distribution/Gaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::Gaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "birch/distribution/Gaussian.birch"
  libbirch_function_("simulateLazy", "birch/distribution/Gaussian.birch", 24);
  #line 25 "birch/distribution/Gaussian.birch"
  libbirch_line_(25);
  #line 25 "birch/distribution/Gaussian.birch"
  return birch::simulate_gaussian(this_()->_u0956->get(handler_), this_()->_u09632->get(handler_), handler_);
}

#line 28 "birch/distribution/Gaussian.birch"
birch::type::Real birch::type::Gaussian::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "birch/distribution/Gaussian.birch"
  libbirch_function_("logpdf", "birch/distribution/Gaussian.birch", 28);
  #line 29 "birch/distribution/Gaussian.birch"
  libbirch_line_(29);
  #line 29 "birch/distribution/Gaussian.birch"
  return birch::logpdf_gaussian(x, this_()->_u0956->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 32 "birch/distribution/Gaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::Gaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "birch/distribution/Gaussian.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/Gaussian.birch", 32);
  #line 33 "birch/distribution/Gaussian.birch"
  libbirch_line_(33);
  #line 33 "birch/distribution/Gaussian.birch"
  return birch::logpdf_lazy_gaussian(x, this_()->_u0956, this_()->_u09632, handler_);
}

#line 36 "birch/distribution/Gaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::Gaussian::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "birch/distribution/Gaussian.birch"
  libbirch_function_("cdf", "birch/distribution/Gaussian.birch", 36);
  #line 37 "birch/distribution/Gaussian.birch"
  libbirch_line_(37);
  #line 37 "birch/distribution/Gaussian.birch"
  return birch::cdf_gaussian(x, this_()->_u0956->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 40 "birch/distribution/Gaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::Gaussian::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "birch/distribution/Gaussian.birch"
  libbirch_function_("quantile", "birch/distribution/Gaussian.birch", 40);
  #line 41 "birch/distribution/Gaussian.birch"
  libbirch_line_(41);
  #line 41 "birch/distribution/Gaussian.birch"
  return birch::quantile_gaussian(P, this_()->_u0956->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 44 "birch/distribution/Gaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> birch::type::Gaussian::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "birch/distribution/Gaussian.birch"
  libbirch_function_("graft", "birch/distribution/Gaussian.birch", 44);
  #line 45 "birch/distribution/Gaussian.birch"
  libbirch_line_(45);
  #line 45 "birch/distribution/Gaussian.birch"
  this_()->prune(handler_);
  #line 46 "birch/distribution/Gaussian.birch"
  libbirch_line_(46);
  #line 46 "birch/distribution/Gaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>>>>> m1;
  #line 47 "birch/distribution/Gaussian.birch"
  libbirch_line_(47);
  #line 47 "birch/distribution/Gaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> m2;
  #line 48 "birch/distribution/Gaussian.birch"
  libbirch_line_(48);
  #line 48 "birch/distribution/Gaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>> m3;
  #line 49 "birch/distribution/Gaussian.birch"
  libbirch_line_(49);
  #line 49 "birch/distribution/Gaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>>>>> m4;
  #line 50 "birch/distribution/Gaussian.birch"
  libbirch_line_(50);
  #line 50 "birch/distribution/Gaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> m5;
  #line 51 "birch/distribution/Gaussian.birch"
  libbirch_line_(51);
  #line 51 "birch/distribution/Gaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>> m6;
  #line 52 "birch/distribution/Gaussian.birch"
  libbirch_line_(52);
  #line 52 "birch/distribution/Gaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>> s2;
  #line 53 "birch/distribution/Gaussian.birch"
  libbirch_line_(53);
  #line 53 "birch/distribution/Gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> r = shared_from_this_();
  #line 56 "birch/distribution/Gaussian.birch"
  libbirch_line_(56);
  #line 56 "birch/distribution/Gaussian.birch"
  auto compare = this_()->_u09632->distribution(handler_);
  #line 57 "birch/distribution/Gaussian.birch"
  libbirch_line_(57);
  #line 57 "birch/distribution/Gaussian.birch"
  if (compare.query() && (m1 = this_()->_u0956->graftLinearNormalInverseGamma(compare.get(), handler_)).query()) {
    #line 58 "birch/distribution/Gaussian.birch"
    libbirch_line_(58);
    #line 58 "birch/distribution/Gaussian.birch"
    r = birch::LinearNormalInverseGammaGaussian(m1.get()->a, m1.get()->x, m1.get()->c, handler_);
  } else {
    #line 59 "birch/distribution/Gaussian.birch"
    libbirch_line_(59);
    #line 59 "birch/distribution/Gaussian.birch"
    if (compare.query() && (m2 = this_()->_u0956->graftDotNormalInverseGamma(compare.get(), handler_)).query()) {
      #line 60 "birch/distribution/Gaussian.birch"
      libbirch_line_(60);
      #line 60 "birch/distribution/Gaussian.birch"
      r = birch::LinearMultivariateNormalInverseGammaGaussian(m2.get()->a, m2.get()->x, m2.get()->c, handler_);
    } else {
      #line 61 "birch/distribution/Gaussian.birch"
      libbirch_line_(61);
      #line 61 "birch/distribution/Gaussian.birch"
      if (compare.query() && (m3 = this_()->_u0956->graftNormalInverseGamma(compare.get(), handler_)).query()) {
        #line 62 "birch/distribution/Gaussian.birch"
        libbirch_line_(62);
        #line 62 "birch/distribution/Gaussian.birch"
        r = birch::NormalInverseGammaGaussian(m3.get(), handler_);
      } else {
        #line 63 "birch/distribution/Gaussian.birch"
        libbirch_line_(63);
        #line 63 "birch/distribution/Gaussian.birch"
        if ((m4 = this_()->_u0956->graftLinearGaussian(handler_)).query()) {
          #line 64 "birch/distribution/Gaussian.birch"
          libbirch_line_(64);
          #line 64 "birch/distribution/Gaussian.birch"
          r = birch::LinearGaussianGaussian(m4.get()->a, m4.get()->x, m4.get()->c, this_()->_u09632, handler_);
        } else {
          #line 65 "birch/distribution/Gaussian.birch"
          libbirch_line_(65);
          #line 65 "birch/distribution/Gaussian.birch"
          if ((m5 = this_()->_u0956->graftDotGaussian(handler_)).query()) {
            #line 66 "birch/distribution/Gaussian.birch"
            libbirch_line_(66);
            #line 66 "birch/distribution/Gaussian.birch"
            r = birch::LinearMultivariateGaussianGaussian(m5.get()->a, m5.get()->x, m5.get()->c, this_()->_u09632, handler_);
          } else {
            #line 67 "birch/distribution/Gaussian.birch"
            libbirch_line_(67);
            #line 67 "birch/distribution/Gaussian.birch"
            if ((m6 = this_()->_u0956->graftGaussian(handler_)).query()) {
              #line 68 "birch/distribution/Gaussian.birch"
              libbirch_line_(68);
              #line 68 "birch/distribution/Gaussian.birch"
              r = birch::GaussianGaussian(m6.get(), this_()->_u09632, handler_);
            } else {
              #line 69 "birch/distribution/Gaussian.birch"
              libbirch_line_(69);
              #line 69 "birch/distribution/Gaussian.birch"
              if ((s2 = this_()->_u09632->graftInverseGamma(handler_)).query()) {
                #line 70 "birch/distribution/Gaussian.birch"
                libbirch_line_(70);
                #line 70 "birch/distribution/Gaussian.birch"
                r = birch::NormalInverseGamma(this_()->_u0956, birch::box(1.0, handler_), s2.get(), handler_);
              }
            }
          }
        }
      }
    }
  }
  #line 73 "birch/distribution/Gaussian.birch"
  libbirch_line_(73);
  #line 73 "birch/distribution/Gaussian.birch"
  return r;
}

#line 76 "birch/distribution/Gaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>> birch::type::Gaussian::graftGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "birch/distribution/Gaussian.birch"
  libbirch_function_("graftGaussian", "birch/distribution/Gaussian.birch", 76);
  #line 77 "birch/distribution/Gaussian.birch"
  libbirch_line_(77);
  #line 77 "birch/distribution/Gaussian.birch"
  this_()->prune(handler_);
  #line 78 "birch/distribution/Gaussian.birch"
  libbirch_line_(78);
  #line 78 "birch/distribution/Gaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>>>>> m1;
  #line 79 "birch/distribution/Gaussian.birch"
  libbirch_line_(79);
  #line 79 "birch/distribution/Gaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformDot<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> m2;
  #line 80 "birch/distribution/Gaussian.birch"
  libbirch_line_(80);
  #line 80 "birch/distribution/Gaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>> m3;
  #line 81 "birch/distribution/Gaussian.birch"
  libbirch_line_(81);
  #line 81 "birch/distribution/Gaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>> r = shared_from_this_();
  #line 84 "birch/distribution/Gaussian.birch"
  libbirch_line_(84);
  #line 84 "birch/distribution/Gaussian.birch"
  if ((m1 = this_()->_u0956->graftLinearGaussian(handler_)).query()) {
    #line 85 "birch/distribution/Gaussian.birch"
    libbirch_line_(85);
    #line 85 "birch/distribution/Gaussian.birch"
    r = birch::LinearGaussianGaussian(m1.get()->a, m1.get()->x, m1.get()->c, this_()->_u09632, handler_);
  } else {
    #line 86 "birch/distribution/Gaussian.birch"
    libbirch_line_(86);
    #line 86 "birch/distribution/Gaussian.birch"
    if ((m2 = this_()->_u0956->graftDotGaussian(handler_)).query()) {
      #line 87 "birch/distribution/Gaussian.birch"
      libbirch_line_(87);
      #line 87 "birch/distribution/Gaussian.birch"
      r = birch::LinearMultivariateGaussianGaussian(m2.get()->a, m2.get()->x, m2.get()->c, this_()->_u09632, handler_);
    } else {
      #line 88 "birch/distribution/Gaussian.birch"
      libbirch_line_(88);
      #line 88 "birch/distribution/Gaussian.birch"
      if ((m3 = this_()->_u0956->graftGaussian(handler_)).query()) {
        #line 89 "birch/distribution/Gaussian.birch"
        libbirch_line_(89);
        #line 89 "birch/distribution/Gaussian.birch"
        r = birch::GaussianGaussian(m3.get(), this_()->_u09632, handler_);
      }
    }
  }
  #line 92 "birch/distribution/Gaussian.birch"
  libbirch_line_(92);
  #line 92 "birch/distribution/Gaussian.birch"
  return r;
}

#line 95 "birch/distribution/Gaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>> birch::type::Gaussian::graftNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "birch/distribution/Gaussian.birch"
  libbirch_function_("graftNormalInverseGamma", "birch/distribution/Gaussian.birch", 95);
  #line 97 "birch/distribution/Gaussian.birch"
  libbirch_line_(97);
  #line 97 "birch/distribution/Gaussian.birch"
  this_()->prune(handler_);
  #line 98 "birch/distribution/Gaussian.birch"
  libbirch_line_(98);
  #line 98 "birch/distribution/Gaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>> s1;
  #line 99 "birch/distribution/Gaussian.birch"
  libbirch_line_(99);
  #line 99 "birch/distribution/Gaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>> r;
  #line 102 "birch/distribution/Gaussian.birch"
  libbirch_line_(102);
  #line 102 "birch/distribution/Gaussian.birch"
  if ((s1 = this_()->_u09632->graftInverseGamma(handler_)).query() && s1.get() == compare) {
    #line 103 "birch/distribution/Gaussian.birch"
    libbirch_line_(103);
    #line 103 "birch/distribution/Gaussian.birch"
    r = birch::NormalInverseGamma(this_()->_u0956, birch::box(1.0, handler_), s1.get(), handler_);
  }
  #line 106 "birch/distribution/Gaussian.birch"
  libbirch_line_(106);
  #line 106 "birch/distribution/Gaussian.birch"
  return r;
}

#line 109 "birch/distribution/Gaussian.birch"
void birch::type::Gaussian::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 109 "birch/distribution/Gaussian.birch"
  libbirch_function_("write", "birch/distribution/Gaussian.birch", 109);
  #line 110 "birch/distribution/Gaussian.birch"
  libbirch_line_(110);
  #line 110 "birch/distribution/Gaussian.birch"
  this_()->prune(handler_);
  #line 111 "birch/distribution/Gaussian.birch"
  libbirch_line_(111);
  #line 111 "birch/distribution/Gaussian.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Gaussian"), handler_);
  #line 112 "birch/distribution/Gaussian.birch"
  libbirch_line_(112);
  #line 112 "birch/distribution/Gaussian.birch"
  buffer->set(birch::type::String("μ"), this_()->_u0956->value(handler_), handler_);
  #line 113 "birch/distribution/Gaussian.birch"
  libbirch_line_(113);
  #line 113 "birch/distribution/Gaussian.birch"
  buffer->set(birch::type::String("σ2"), this_()->_u09632->value(handler_), handler_);
}

#line 120 "birch/distribution/Gaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 120 "birch/distribution/Gaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/Gaussian.birch", 120);
  #line 121 "birch/distribution/Gaussian.birch"
  libbirch_line_(121);
  #line 121 "birch/distribution/Gaussian.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>>(_u0956, _u09632, handler_);
}

#line 127 "birch/distribution/Gaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 127 "birch/distribution/Gaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/Gaussian.birch", 127);
  #line 128 "birch/distribution/Gaussian.birch"
  libbirch_line_(128);
  #line 128 "birch/distribution/Gaussian.birch"
  return birch::Gaussian(_u0956, birch::box(_u09632, handler_), handler_);
}

#line 134 "birch/distribution/Gaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>> birch::Gaussian(const birch::type::Real& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 134 "birch/distribution/Gaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/Gaussian.birch", 134);
  #line 135 "birch/distribution/Gaussian.birch"
  libbirch_line_(135);
  #line 135 "birch/distribution/Gaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), _u09632, handler_);
}

#line 141 "birch/distribution/Gaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>> birch::Gaussian(const birch::type::Real& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 141 "birch/distribution/Gaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/Gaussian.birch", 141);
  #line 142 "birch/distribution/Gaussian.birch"
  libbirch_line_(142);
  #line 142 "birch/distribution/Gaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), birch::box(_u09632, handler_), handler_);
}

#line 4 "birch/distribution/GaussianGaussian.birch"
birch::type::GaussianGaussian::GaussianGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>& m, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& s2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/GaussianGaussian.birch"
    super_type_(m->_u0956, m->_u09632 + s2),
    #line 9 "birch/distribution/GaussianGaussian.birch"
    m(m),
    #line 14 "birch/distribution/GaussianGaussian.birch"
    s2(s2) {
  //
}

#line 16 "birch/distribution/GaussianGaussian.birch"
void birch::type::GaussianGaussian::update(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "birch/distribution/GaussianGaussian.birch"
  libbirch_function_("update", "birch/distribution/GaussianGaussian.birch", 16);
  #line 17 "birch/distribution/GaussianGaussian.birch"
  libbirch_line_(17);
  #line 17 "birch/distribution/GaussianGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u09632) = birch::box(birch::update_gaussian_gaussian(x, this_()->m->_u0956->value(handler_), this_()->m->_u09632->value(handler_), this_()->s2->value(handler_), handler_), handler_);
}

#line 20 "birch/distribution/GaussianGaussian.birch"
void birch::type::GaussianGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "birch/distribution/GaussianGaussian.birch"
  libbirch_function_("updateLazy", "birch/distribution/GaussianGaussian.birch", 20);
  #line 21 "birch/distribution/GaussianGaussian.birch"
  libbirch_line_(21);
  #line 21 "birch/distribution/GaussianGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u09632) = birch::update_lazy_gaussian_gaussian(x, this_()->m->_u0956, this_()->m->_u09632, this_()->s2, handler_);
}

#line 24 "birch/distribution/GaussianGaussian.birch"
void birch::type::GaussianGaussian::downdate(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "birch/distribution/GaussianGaussian.birch"
  libbirch_function_("downdate", "birch/distribution/GaussianGaussian.birch", 24);
  #line 25 "birch/distribution/GaussianGaussian.birch"
  libbirch_line_(25);
  #line 25 "birch/distribution/GaussianGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u09632) = birch::box(birch::downdate_gaussian_gaussian(x, this_()->m->_u0956->value(handler_), this_()->m->_u09632->value(handler_), this_()->s2->value(handler_), handler_), handler_);
}

#line 28 "birch/distribution/GaussianGaussian.birch"
void birch::type::GaussianGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "birch/distribution/GaussianGaussian.birch"
  libbirch_function_("link", "birch/distribution/GaussianGaussian.birch", 28);
  #line 29 "birch/distribution/GaussianGaussian.birch"
  libbirch_line_(29);
  #line 29 "birch/distribution/GaussianGaussian.birch"
  this_()->m->setChild(shared_from_this_(), handler_);
}

#line 32 "birch/distribution/GaussianGaussian.birch"
void birch::type::GaussianGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "birch/distribution/GaussianGaussian.birch"
  libbirch_function_("unlink", "birch/distribution/GaussianGaussian.birch", 32);
  #line 33 "birch/distribution/GaussianGaussian.birch"
  libbirch_line_(33);
  #line 33 "birch/distribution/GaussianGaussian.birch"
  this_()->m->releaseChild(shared_from_this_(), handler_);
}

#line 37 "birch/distribution/GaussianGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::GaussianGaussian>> birch::GaussianGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "birch/distribution/GaussianGaussian.birch"
  libbirch_function_("GaussianGaussian", "birch/distribution/GaussianGaussian.birch", 37);
  #line 38 "birch/distribution/GaussianGaussian.birch"
  libbirch_line_(38);
  #line 38 "birch/distribution/GaussianGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::GaussianGaussian>> m(_u0956, _u09632);
  #line 39 "birch/distribution/GaussianGaussian.birch"
  libbirch_line_(39);
  #line 39 "birch/distribution/GaussianGaussian.birch"
  m->link(handler_);
  #line 40 "birch/distribution/GaussianGaussian.birch"
  libbirch_line_(40);
  #line 40 "birch/distribution/GaussianGaussian.birch"
  return m;
}

#line 4 "birch/distribution/Geometric.birch"
libbirch::Lazy<libbirch::Shared<birch::type::NegativeBinomial>> birch::Geometric(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 4 "birch/distribution/Geometric.birch"
  libbirch_function_("Geometric", "birch/distribution/Geometric.birch", 4);
  #line 5 "birch/distribution/Geometric.birch"
  libbirch_line_(5);
  #line 5 "birch/distribution/Geometric.birch"
  return birch::NegativeBinomial(birch::box(birch::type::Integer(1), handler_), _u0961, handler_);
}

#line 11 "birch/distribution/Geometric.birch"
libbirch::Lazy<libbirch::Shared<birch::type::NegativeBinomial>> birch::Geometric(const birch::type::Real& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "birch/distribution/Geometric.birch"
  libbirch_function_("Geometric", "birch/distribution/Geometric.birch", 11);
  #line 12 "birch/distribution/Geometric.birch"
  libbirch_line_(12);
  #line 12 "birch/distribution/Geometric.birch"
  return birch::Geometric(birch::box(_u0961, handler_), handler_);
}

#line 5 "birch/distribution/IdenticalGaussian.birch"
birch::type::IdenticalGaussian::IdenticalGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 5 "birch/distribution/IdenticalGaussian.birch"
    super_type_(),
    #line 10 "birch/distribution/IdenticalGaussian.birch"
    _u0956(_u0956),
    #line 15 "birch/distribution/IdenticalGaussian.birch"
    _u09632(_u09632) {
  //
}

#line 17 "birch/distribution/IdenticalGaussian.birch"
birch::type::Integer birch::type::IdenticalGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 17 "birch/distribution/IdenticalGaussian.birch"
  libbirch_function_("rows", "birch/distribution/IdenticalGaussian.birch", 17);
  #line 18 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(18);
  #line 18 "birch/distribution/IdenticalGaussian.birch"
  return this_()->_u0956->rows(handler_);
}

#line 21 "birch/distribution/IdenticalGaussian.birch"
birch::type::Boolean birch::type::IdenticalGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "birch/distribution/IdenticalGaussian.birch"
  libbirch_function_("supportsLazy", "birch/distribution/IdenticalGaussian.birch", 21);
  #line 22 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(22);
  #line 22 "birch/distribution/IdenticalGaussian.birch"
  return true;
}

#line 25 "birch/distribution/IdenticalGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::IdenticalGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "birch/distribution/IdenticalGaussian.birch"
  libbirch_function_("simulate", "birch/distribution/IdenticalGaussian.birch", 25);
  #line 26 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(26);
  #line 26 "birch/distribution/IdenticalGaussian.birch"
  return birch::simulate_multivariate_gaussian(this_()->_u0956->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 29 "birch/distribution/IdenticalGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::IdenticalGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "birch/distribution/IdenticalGaussian.birch"
  libbirch_function_("simulateLazy", "birch/distribution/IdenticalGaussian.birch", 29);
  #line 30 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(30);
  #line 30 "birch/distribution/IdenticalGaussian.birch"
  return birch::simulate_multivariate_gaussian(this_()->_u0956->get(handler_), this_()->_u09632->get(handler_), handler_);
}

#line 33 "birch/distribution/IdenticalGaussian.birch"
birch::type::Real birch::type::IdenticalGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "birch/distribution/IdenticalGaussian.birch"
  libbirch_function_("logpdf", "birch/distribution/IdenticalGaussian.birch", 33);
  #line 34 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(34);
  #line 34 "birch/distribution/IdenticalGaussian.birch"
  return birch::logpdf_multivariate_gaussian(x, this_()->_u0956->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 37 "birch/distribution/IdenticalGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::IdenticalGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "birch/distribution/IdenticalGaussian.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/IdenticalGaussian.birch", 37);
  #line 38 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(38);
  #line 38 "birch/distribution/IdenticalGaussian.birch"
  return birch::logpdf_lazy_multivariate_gaussian(x, this_()->_u0956, this_()->_u09632, handler_);
}

#line 41 "birch/distribution/IdenticalGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>> birch::type::IdenticalGaussian::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "birch/distribution/IdenticalGaussian.birch"
  libbirch_function_("graft", "birch/distribution/IdenticalGaussian.birch", 41);
  #line 42 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(42);
  #line 42 "birch/distribution/IdenticalGaussian.birch"
  this_()->prune(handler_);
  #line 43 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(43);
  #line 43 "birch/distribution/IdenticalGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>> s1;
  #line 44 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(44);
  #line 44 "birch/distribution/IdenticalGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>>>>> m1;
  #line 45 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(45);
  #line 45 "birch/distribution/IdenticalGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>> m2;
  #line 46 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(46);
  #line 46 "birch/distribution/IdenticalGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> m3;
  #line 47 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(47);
  #line 47 "birch/distribution/IdenticalGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>> m4;
  #line 48 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(48);
  #line 48 "birch/distribution/IdenticalGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>> r = shared_from_this_();
  #line 51 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(51);
  #line 51 "birch/distribution/IdenticalGaussian.birch"
  auto compare = this_()->_u09632->distribution(handler_);
  #line 52 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(52);
  #line 52 "birch/distribution/IdenticalGaussian.birch"
  if (compare.query() && (m1 = this_()->_u0956->graftLinearMultivariateNormalInverseGamma(compare.get(), handler_)).query()) {
    #line 53 "birch/distribution/IdenticalGaussian.birch"
    libbirch_line_(53);
    #line 53 "birch/distribution/IdenticalGaussian.birch"
    r = birch::LinearMultivariateNormalInverseGammaMultivariateGaussian(m1.get()->A, m1.get()->x, m1.get()->c, handler_);
  } else {
    #line 54 "birch/distribution/IdenticalGaussian.birch"
    libbirch_line_(54);
    #line 54 "birch/distribution/IdenticalGaussian.birch"
    if (compare.query() && (m2 = this_()->_u0956->graftMultivariateNormalInverseGamma(compare.get(), handler_)).query()) {
      #line 55 "birch/distribution/IdenticalGaussian.birch"
      libbirch_line_(55);
      #line 55 "birch/distribution/IdenticalGaussian.birch"
      r = birch::MultivariateNormalInverseGammaMultivariateGaussian(m2.get(), handler_);
    } else {
      #line 56 "birch/distribution/IdenticalGaussian.birch"
      libbirch_line_(56);
      #line 56 "birch/distribution/IdenticalGaussian.birch"
      if ((m3 = this_()->_u0956->graftLinearMultivariateGaussian(handler_)).query()) {
        #line 57 "birch/distribution/IdenticalGaussian.birch"
        libbirch_line_(57);
        #line 57 "birch/distribution/IdenticalGaussian.birch"
        r = birch::LinearMultivariateGaussianMultivariateGaussian(m3.get()->A, m3.get()->x, m3.get()->c, birch::llt(birch::diagonal(this_()->_u09632, m3.get()->rows(handler_), handler_), handler_), handler_);
      } else {
        #line 59 "birch/distribution/IdenticalGaussian.birch"
        libbirch_line_(59);
        #line 59 "birch/distribution/IdenticalGaussian.birch"
        if ((m4 = this_()->_u0956->graftMultivariateGaussian(handler_)).query()) {
          #line 60 "birch/distribution/IdenticalGaussian.birch"
          libbirch_line_(60);
          #line 60 "birch/distribution/IdenticalGaussian.birch"
          r = birch::MultivariateGaussianMultivariateGaussian(m4.get(), birch::llt(birch::diagonal(this_()->_u09632, m4.get()->rows(handler_), handler_), handler_), handler_);
        } else {
          #line 62 "birch/distribution/IdenticalGaussian.birch"
          libbirch_line_(62);
          #line 62 "birch/distribution/IdenticalGaussian.birch"
          if ((s1 = this_()->_u09632->graftInverseGamma(handler_)).query()) {
            #line 63 "birch/distribution/IdenticalGaussian.birch"
            libbirch_line_(63);
            #line 63 "birch/distribution/IdenticalGaussian.birch"
            r = birch::MultivariateNormalInverseGamma(this_()->_u0956, birch::box(birch::llt(birch::identity(this_()->_u0956->rows(handler_), handler_), handler_), handler_), s1.get(), handler_);
          }
        }
      }
    }
  }
  #line 66 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(66);
  #line 66 "birch/distribution/IdenticalGaussian.birch"
  return r;
}

#line 69 "birch/distribution/IdenticalGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>> birch::type::IdenticalGaussian::graftMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "birch/distribution/IdenticalGaussian.birch"
  libbirch_function_("graftMultivariateGaussian", "birch/distribution/IdenticalGaussian.birch", 69);
  #line 70 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(70);
  #line 70 "birch/distribution/IdenticalGaussian.birch"
  this_()->prune(handler_);
  #line 71 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(71);
  #line 71 "birch/distribution/IdenticalGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> m1;
  #line 72 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(72);
  #line 72 "birch/distribution/IdenticalGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>> m2;
  #line 73 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(73);
  #line 73 "birch/distribution/IdenticalGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>> r;
  #line 76 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(76);
  #line 76 "birch/distribution/IdenticalGaussian.birch"
  if ((m1 = this_()->_u0956->graftLinearMultivariateGaussian(handler_)).query()) {
    #line 77 "birch/distribution/IdenticalGaussian.birch"
    libbirch_line_(77);
    #line 77 "birch/distribution/IdenticalGaussian.birch"
    r = birch::LinearMultivariateGaussianMultivariateGaussian(m1.get()->A, m1.get()->x, m1.get()->c, birch::llt(birch::diagonal(this_()->_u09632, m1.get()->c->rows(handler_), handler_), handler_), handler_);
  } else {
    #line 79 "birch/distribution/IdenticalGaussian.birch"
    libbirch_line_(79);
    #line 79 "birch/distribution/IdenticalGaussian.birch"
    if ((m2 = this_()->_u0956->graftMultivariateGaussian(handler_)).query()) {
      #line 80 "birch/distribution/IdenticalGaussian.birch"
      libbirch_line_(80);
      #line 80 "birch/distribution/IdenticalGaussian.birch"
      r = birch::MultivariateGaussianMultivariateGaussian(m2.get(), birch::llt(birch::diagonal(this_()->_u09632, m2.get()->rows(handler_), handler_), handler_), handler_);
    } else {
      #line 83 "birch/distribution/IdenticalGaussian.birch"
      libbirch_line_(83);
      #line 83 "birch/distribution/IdenticalGaussian.birch"
      r = birch::Gaussian(this_()->_u0956, birch::diagonal(this_()->_u09632, this_()->_u0956->rows(handler_), handler_), handler_);
    }
  }
  #line 86 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(86);
  #line 86 "birch/distribution/IdenticalGaussian.birch"
  return r;
}

#line 89 "birch/distribution/IdenticalGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>> birch::type::IdenticalGaussian::graftMultivariateNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 89 "birch/distribution/IdenticalGaussian.birch"
  libbirch_function_("graftMultivariateNormalInverseGamma", "birch/distribution/IdenticalGaussian.birch", 89);
  #line 91 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(91);
  #line 91 "birch/distribution/IdenticalGaussian.birch"
  this_()->prune(handler_);
  #line 92 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(92);
  #line 92 "birch/distribution/IdenticalGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>> s1;
  #line 93 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(93);
  #line 93 "birch/distribution/IdenticalGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>> r;
  #line 95 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(95);
  #line 95 "birch/distribution/IdenticalGaussian.birch"
  if ((s1 = this_()->_u09632->graftInverseGamma(handler_)).query() && s1.get() == compare) {
    #line 96 "birch/distribution/IdenticalGaussian.birch"
    libbirch_line_(96);
    #line 96 "birch/distribution/IdenticalGaussian.birch"
    r = birch::MultivariateNormalInverseGamma(this_()->_u0956, birch::box(birch::llt(birch::identity(this_()->_u0956->rows(handler_), handler_), handler_), handler_), s1.get(), handler_);
  }
  #line 99 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(99);
  #line 99 "birch/distribution/IdenticalGaussian.birch"
  return r;
}

#line 107 "birch/distribution/IdenticalGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IdenticalGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 107 "birch/distribution/IdenticalGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IdenticalGaussian.birch", 107);
  #line 109 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(109);
  #line 109 "birch/distribution/IdenticalGaussian.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::IdenticalGaussian>>>(_u0956, _u09632, handler_);
}

#line 116 "birch/distribution/IdenticalGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IdenticalGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 116 "birch/distribution/IdenticalGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IdenticalGaussian.birch", 116);
  #line 117 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(117);
  #line 117 "birch/distribution/IdenticalGaussian.birch"
  return birch::Gaussian(_u0956, birch::box(_u09632, handler_), handler_);
}

#line 124 "birch/distribution/IdenticalGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IdenticalGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 124 "birch/distribution/IdenticalGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IdenticalGaussian.birch", 124);
  #line 125 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(125);
  #line 125 "birch/distribution/IdenticalGaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), _u09632, handler_);
}

#line 132 "birch/distribution/IdenticalGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IdenticalGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 132 "birch/distribution/IdenticalGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IdenticalGaussian.birch", 132);
  #line 133 "birch/distribution/IdenticalGaussian.birch"
  libbirch_line_(133);
  #line 133 "birch/distribution/IdenticalGaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), birch::box(_u09632, handler_), handler_);
}

#line 4 "birch/distribution/IndependentColumnMatrixGaussian.birch"
birch::type::IndependentColumnMatrixGaussian::IndependentColumnMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& v, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/IndependentColumnMatrixGaussian.birch"
    super_type_(),
    #line 9 "birch/distribution/IndependentColumnMatrixGaussian.birch"
    M(M),
    #line 14 "birch/distribution/IndependentColumnMatrixGaussian.birch"
    U(U),
    #line 19 "birch/distribution/IndependentColumnMatrixGaussian.birch"
    _u09632(v) {
  //
}

#line 21 "birch/distribution/IndependentColumnMatrixGaussian.birch"
birch::type::Integer birch::type::IndependentColumnMatrixGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("rows", "birch/distribution/IndependentColumnMatrixGaussian.birch", 21);
  #line 22 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(22);
  #line 22 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return this_()->M->rows(handler_);
}

#line 25 "birch/distribution/IndependentColumnMatrixGaussian.birch"
birch::type::Integer birch::type::IndependentColumnMatrixGaussian::columns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("columns", "birch/distribution/IndependentColumnMatrixGaussian.birch", 25);
  #line 26 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(26);
  #line 26 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return this_()->M->columns(handler_);
}

#line 29 "birch/distribution/IndependentColumnMatrixGaussian.birch"
birch::type::Boolean birch::type::IndependentColumnMatrixGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("supportsLazy", "birch/distribution/IndependentColumnMatrixGaussian.birch", 29);
  #line 30 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(30);
  #line 30 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return true;
}

#line 33 "birch/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::IndependentColumnMatrixGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("simulate", "birch/distribution/IndependentColumnMatrixGaussian.birch", 33);
  #line 34 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(34);
  #line 34 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::simulate_matrix_gaussian(this_()->M->value(handler_), this_()->U->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 37 "birch/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::IndependentColumnMatrixGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("simulateLazy", "birch/distribution/IndependentColumnMatrixGaussian.birch", 37);
  #line 38 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(38);
  #line 38 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::simulate_matrix_gaussian(this_()->M->get(handler_), this_()->U->get(handler_), this_()->_u09632->get(handler_), handler_);
}

#line 41 "birch/distribution/IndependentColumnMatrixGaussian.birch"
birch::type::Real birch::type::IndependentColumnMatrixGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("logpdf", "birch/distribution/IndependentColumnMatrixGaussian.birch", 41);
  #line 42 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(42);
  #line 42 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::logpdf_matrix_gaussian(x, this_()->M->value(handler_), this_()->U->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 45 "birch/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::IndependentColumnMatrixGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/IndependentColumnMatrixGaussian.birch", 45);
  #line 46 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(46);
  #line 46 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::logpdf_lazy_matrix_gaussian(x, this_()->M, this_()->U, this_()->_u09632, handler_);
}

#line 49 "birch/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>> birch::type::IndependentColumnMatrixGaussian::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("graft", "birch/distribution/IndependentColumnMatrixGaussian.birch", 49);
  #line 50 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(50);
  #line 50 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  this_()->prune(handler_);
  #line 51 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(51);
  #line 51 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::IndependentInverseGamma>>> s1;
  #line 52 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(52);
  #line 52 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>> r = shared_from_this_();
  #line 55 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(55);
  #line 55 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  if ((s1 = this_()->_u09632->graftIndependentInverseGamma(handler_)).query()) {
    #line 56 "birch/distribution/IndependentColumnMatrixGaussian.birch"
    libbirch_line_(56);
    #line 56 "birch/distribution/IndependentColumnMatrixGaussian.birch"
    r = birch::MatrixNormalInverseGamma(this_()->M, this_()->U, s1.get(), handler_);
  } else {
    #line 58 "birch/distribution/IndependentColumnMatrixGaussian.birch"
    libbirch_line_(58);
    #line 58 "birch/distribution/IndependentColumnMatrixGaussian.birch"
    r = birch::Gaussian(this_()->M, this_()->U, birch::diagonal(this_()->_u09632, handler_), handler_);
  }
  #line 61 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(61);
  #line 61 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return r;
}

#line 64 "birch/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>> birch::type::IndependentColumnMatrixGaussian::graftMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("graftMatrixGaussian", "birch/distribution/IndependentColumnMatrixGaussian.birch", 64);
  #line 65 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(65);
  #line 65 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  this_()->prune(handler_);
  #line 66 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(66);
  #line 66 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(this_()->M, this_()->U, birch::diagonal(this_()->_u09632, handler_), handler_);
}

#line 69 "birch/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>> birch::type::IndependentColumnMatrixGaussian::graftMatrixNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("graftMatrixNormalInverseGamma", "birch/distribution/IndependentColumnMatrixGaussian.birch", 69);
  #line 71 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(71);
  #line 71 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  this_()->prune(handler_);
  #line 72 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(72);
  #line 72 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::IndependentInverseGamma>>> s1;
  #line 73 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(73);
  #line 73 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>> r;
  #line 76 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(76);
  #line 76 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  if ((s1 = this_()->_u09632->graftIndependentInverseGamma(handler_)).query() && s1.get() == compare) {
    #line 77 "birch/distribution/IndependentColumnMatrixGaussian.birch"
    libbirch_line_(77);
    #line 77 "birch/distribution/IndependentColumnMatrixGaussian.birch"
    r = birch::MatrixNormalInverseGamma(this_()->M, this_()->U, s1.get(), handler_);
  }
  #line 80 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(80);
  #line 80 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return r;
}

#line 87 "birch/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 87 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentColumnMatrixGaussian.birch", 87);
  #line 89 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(89);
  #line 89 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>>>(M, U, _u09632, handler_);
}

#line 95 "birch/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentColumnMatrixGaussian.birch", 95);
  #line 97 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(97);
  #line 97 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::box(_u09632, handler_), handler_);
}

#line 103 "birch/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const birch::type::LLT& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 103 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentColumnMatrixGaussian.birch", 103);
  #line 105 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(105);
  #line 105 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(M, birch::box(U, handler_), _u09632, handler_);
}

#line 111 "birch/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const birch::type::LLT& U, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 111 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentColumnMatrixGaussian.birch", 111);
  #line 113 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(113);
  #line 113 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(M, birch::box(U, handler_), birch::box(_u09632, handler_), handler_);
}

#line 119 "birch/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 119 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentColumnMatrixGaussian.birch", 119);
  #line 121 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(121);
  #line 121 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(birch::box(M, handler_), U, _u09632, handler_);
}

#line 127 "birch/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 127 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentColumnMatrixGaussian.birch", 127);
  #line 129 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(129);
  #line 129 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(birch::box(M, handler_), U, birch::box(_u09632, handler_), handler_);
}

#line 135 "birch/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 135 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentColumnMatrixGaussian.birch", 135);
  #line 137 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(137);
  #line 137 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(birch::box(M, handler_), birch::box(U, handler_), _u09632, handler_);
}

#line 143 "birch/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 143 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentColumnMatrixGaussian.birch", 143);
  #line 145 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(145);
  #line 145 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(birch::box(M, handler_), birch::box(U, handler_), birch::box(_u09632, handler_), handler_);
}

#line 154 "birch/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 154 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentColumnMatrixGaussian.birch", 154);
  #line 156 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(156);
  #line 156 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), _u09632, handler_);
}

#line 162 "birch/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& U, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 162 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentColumnMatrixGaussian.birch", 162);
  #line 164 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(164);
  #line 164 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), _u09632, handler_);
}

#line 170 "birch/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 170 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentColumnMatrixGaussian.birch", 170);
  #line 172 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(172);
  #line 172 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), _u09632, handler_);
}

#line 178 "birch/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 178 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentColumnMatrixGaussian.birch", 178);
  #line 180 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(180);
  #line 180 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), _u09632, handler_);
}

#line 186 "birch/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 186 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentColumnMatrixGaussian.birch", 186);
  #line 188 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(188);
  #line 188 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), _u09632, handler_);
}

#line 194 "birch/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& U, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 194 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentColumnMatrixGaussian.birch", 194);
  #line 196 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(196);
  #line 196 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), _u09632, handler_);
}

#line 202 "birch/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 202 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentColumnMatrixGaussian.birch", 202);
  #line 204 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(204);
  #line 204 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), _u09632, handler_);
}

#line 210 "birch/distribution/IndependentColumnMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentColumnMatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 210 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentColumnMatrixGaussian.birch", 210);
  #line 212 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  libbirch_line_(212);
  #line 212 "birch/distribution/IndependentColumnMatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), _u09632, handler_);
}

#line 36 "birch/distribution/IndependentInverseGamma.birch"
birch::type::IndependentInverseGamma::IndependentInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 36 "birch/distribution/IndependentInverseGamma.birch"
    super_type_(),
    #line 41 "birch/distribution/IndependentInverseGamma.birch"
    _u0945(_u0945),
    #line 46 "birch/distribution/IndependentInverseGamma.birch"
    _u0946(_u0946) {
  //
}

#line 48 "birch/distribution/IndependentInverseGamma.birch"
birch::type::Integer birch::type::IndependentInverseGamma::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_function_("rows", "birch/distribution/IndependentInverseGamma.birch", 48);
  #line 49 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_line_(49);
  #line 49 "birch/distribution/IndependentInverseGamma.birch"
  return this_()->_u0946->rows(handler_);
}

#line 52 "birch/distribution/IndependentInverseGamma.birch"
birch::type::Boolean birch::type::IndependentInverseGamma::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_function_("supportsLazy", "birch/distribution/IndependentInverseGamma.birch", 52);
  #line 53 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_line_(53);
  #line 53 "birch/distribution/IndependentInverseGamma.birch"
  return false;
}

#line 56 "birch/distribution/IndependentInverseGamma.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::IndependentInverseGamma::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 56 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_function_("simulate", "birch/distribution/IndependentInverseGamma.birch", 56);
  #line 57 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_line_(57);
  #line 57 "birch/distribution/IndependentInverseGamma.birch"
  return birch::transform<birch::type::Real>(this_()->_u0946->value(handler_), std::function<birch::type::Real(birch::type::Real,const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_
)>([=](const birch::type::Real& b, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr) {
    #line 59 "birch/distribution/IndependentInverseGamma.birch"
    libbirch_line_(59);
    #line 59 "birch/distribution/IndependentInverseGamma.birch"
    return birch::simulate_inverse_gamma(this_()->_u0945->value(handler_), b, handler_);
  }), handler_);
}

#line 67 "birch/distribution/IndependentInverseGamma.birch"
birch::type::Real birch::type::IndependentInverseGamma::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 67 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_function_("logpdf", "birch/distribution/IndependentInverseGamma.birch", 67);
  #line 68 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_line_(68);
  #line 68 "birch/distribution/IndependentInverseGamma.birch"
  return birch::transform_reduce<birch::type::Real>(x, this_()->_u0946->value(handler_), 0.0, std::function<birch::type::Real(birch::type::Real,birch::type::Real,const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_
)>([=](const birch::type::Real& a, const birch::type::Real& b, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr) {
    #line 70 "birch/distribution/IndependentInverseGamma.birch"
    libbirch_line_(70);
    #line 70 "birch/distribution/IndependentInverseGamma.birch"
    return a + b;
  }), std::function<birch::type::Real(birch::type::Real,birch::type::Real,const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_
)>([=](const birch::type::Real& x, const birch::type::Real& b, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr) {
    #line 73 "birch/distribution/IndependentInverseGamma.birch"
    libbirch_line_(73);
    #line 73 "birch/distribution/IndependentInverseGamma.birch"
    return birch::logpdf_inverse_gamma(x, this_()->_u0945->value(handler_), b, handler_);
  }), handler_);
}

#line 81 "birch/distribution/IndependentInverseGamma.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::IndependentInverseGamma::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_function_("lower", "birch/distribution/IndependentInverseGamma.birch", 81);
  #line 82 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_line_(82);
  #line 82 "birch/distribution/IndependentInverseGamma.birch"
  return birch::vector(0.0, this_()->_u0946->rows(handler_), handler_);
}

#line 85 "birch/distribution/IndependentInverseGamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::IndependentInverseGamma>>> birch::type::IndependentInverseGamma::graftIndependentInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 85 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_function_("graftIndependentInverseGamma", "birch/distribution/IndependentInverseGamma.birch", 85);
  #line 86 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_line_(86);
  #line 86 "birch/distribution/IndependentInverseGamma.birch"
  this_()->prune(handler_);
  #line 87 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_line_(87);
  #line 87 "birch/distribution/IndependentInverseGamma.birch"
  return shared_from_this_();
}

#line 90 "birch/distribution/IndependentInverseGamma.birch"
void birch::type::IndependentInverseGamma::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 90 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_function_("write", "birch/distribution/IndependentInverseGamma.birch", 90);
  #line 91 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_line_(91);
  #line 91 "birch/distribution/IndependentInverseGamma.birch"
  this_()->prune(handler_);
  #line 92 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_line_(92);
  #line 92 "birch/distribution/IndependentInverseGamma.birch"
  buffer->set(birch::type::String("class"), birch::type::String("IndependentInverseGamma"), handler_);
  #line 93 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_line_(93);
  #line 93 "birch/distribution/IndependentInverseGamma.birch"
  buffer->set(birch::type::String("α"), this_()->_u0945, handler_);
  #line 94 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_line_(94);
  #line 94 "birch/distribution/IndependentInverseGamma.birch"
  buffer->set(birch::type::String("β"), this_()->_u0946, handler_);
}

#line 101 "birch/distribution/IndependentInverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentInverseGamma>> birch::InverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 101 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_function_("InverseGamma", "birch/distribution/IndependentInverseGamma.birch", 101);
  #line 103 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_line_(103);
  #line 103 "birch/distribution/IndependentInverseGamma.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::IndependentInverseGamma>>>(_u0945, _u0946, handler_);
}

#line 109 "birch/distribution/IndependentInverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentInverseGamma>> birch::InverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::DefaultArray<birch::type::Real,1>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 109 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_function_("InverseGamma", "birch/distribution/IndependentInverseGamma.birch", 109);
  #line 111 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_line_(111);
  #line 111 "birch/distribution/IndependentInverseGamma.birch"
  return birch::InverseGamma(_u0945, birch::box(_u0946, handler_), handler_);
}

#line 117 "birch/distribution/IndependentInverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentInverseGamma>> birch::InverseGamma(const birch::type::Real& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 117 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_function_("InverseGamma", "birch/distribution/IndependentInverseGamma.birch", 117);
  #line 119 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_line_(119);
  #line 119 "birch/distribution/IndependentInverseGamma.birch"
  return birch::InverseGamma(birch::box(_u0945, handler_), _u0946, handler_);
}

#line 125 "birch/distribution/IndependentInverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentInverseGamma>> birch::InverseGamma(const birch::type::Real& _u0945, const libbirch::DefaultArray<birch::type::Real,1>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 125 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_function_("InverseGamma", "birch/distribution/IndependentInverseGamma.birch", 125);
  #line 126 "birch/distribution/IndependentInverseGamma.birch"
  libbirch_line_(126);
  #line 126 "birch/distribution/IndependentInverseGamma.birch"
  return birch::InverseGamma(birch::box(_u0945, handler_), birch::box(_u0946, handler_), handler_);
}

#line 4 "birch/distribution/IndependentMatrixGaussian.birch"
birch::type::IndependentMatrixGaussian::IndependentMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& v, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/IndependentMatrixGaussian.birch"
    super_type_(),
    #line 9 "birch/distribution/IndependentMatrixGaussian.birch"
    M(M),
    #line 14 "birch/distribution/IndependentMatrixGaussian.birch"
    _u09632(v) {
  //
}

#line 16 "birch/distribution/IndependentMatrixGaussian.birch"
birch::type::Integer birch::type::IndependentMatrixGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("rows", "birch/distribution/IndependentMatrixGaussian.birch", 16);
  #line 17 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(17);
  #line 17 "birch/distribution/IndependentMatrixGaussian.birch"
  return this_()->M->rows(handler_);
}

#line 20 "birch/distribution/IndependentMatrixGaussian.birch"
birch::type::Integer birch::type::IndependentMatrixGaussian::columns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("columns", "birch/distribution/IndependentMatrixGaussian.birch", 20);
  #line 21 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(21);
  #line 21 "birch/distribution/IndependentMatrixGaussian.birch"
  return this_()->M->columns(handler_);
}

#line 24 "birch/distribution/IndependentMatrixGaussian.birch"
birch::type::Boolean birch::type::IndependentMatrixGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("supportsLazy", "birch/distribution/IndependentMatrixGaussian.birch", 24);
  #line 25 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(25);
  #line 25 "birch/distribution/IndependentMatrixGaussian.birch"
  return true;
}

#line 28 "birch/distribution/IndependentMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::IndependentMatrixGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("simulate", "birch/distribution/IndependentMatrixGaussian.birch", 28);
  #line 29 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(29);
  #line 29 "birch/distribution/IndependentMatrixGaussian.birch"
  return birch::simulate_matrix_gaussian(this_()->M->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 32 "birch/distribution/IndependentMatrixGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::IndependentMatrixGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("simulateLazy", "birch/distribution/IndependentMatrixGaussian.birch", 32);
  #line 33 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(33);
  #line 33 "birch/distribution/IndependentMatrixGaussian.birch"
  return birch::simulate_matrix_gaussian(this_()->M->get(handler_), this_()->_u09632->get(handler_), handler_);
}

#line 36 "birch/distribution/IndependentMatrixGaussian.birch"
birch::type::Real birch::type::IndependentMatrixGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("logpdf", "birch/distribution/IndependentMatrixGaussian.birch", 36);
  #line 37 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(37);
  #line 37 "birch/distribution/IndependentMatrixGaussian.birch"
  return birch::logpdf_matrix_gaussian(x, this_()->M->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 40 "birch/distribution/IndependentMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::IndependentMatrixGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/IndependentMatrixGaussian.birch", 40);
  #line 41 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(41);
  #line 41 "birch/distribution/IndependentMatrixGaussian.birch"
  return birch::logpdf_lazy_matrix_gaussian(x, this_()->M, this_()->_u09632, handler_);
}

#line 44 "birch/distribution/IndependentMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>> birch::type::IndependentMatrixGaussian::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("graft", "birch/distribution/IndependentMatrixGaussian.birch", 44);
  #line 45 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(45);
  #line 45 "birch/distribution/IndependentMatrixGaussian.birch"
  this_()->prune(handler_);
  #line 46 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(46);
  #line 46 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::IndependentInverseGamma>>> s1;
  #line 47 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(47);
  #line 47 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>>>>> m1;
  #line 48 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(48);
  #line 48 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>> m2;
  #line 49 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(49);
  #line 49 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>> r = shared_from_this_();
  #line 52 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(52);
  #line 52 "birch/distribution/IndependentMatrixGaussian.birch"
  auto compare = this_()->_u09632->distribution(handler_);
  #line 53 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(53);
  #line 53 "birch/distribution/IndependentMatrixGaussian.birch"
  if (compare.query() && (m1 = this_()->M->graftLinearMatrixNormalInverseGamma(compare.get(), handler_)).query()) {
    #line 54 "birch/distribution/IndependentMatrixGaussian.birch"
    libbirch_line_(54);
    #line 54 "birch/distribution/IndependentMatrixGaussian.birch"
    r = birch::LinearMatrixNormalInverseGammaMatrixGaussian(m1.get()->A, m1.get()->X, m1.get()->C, handler_);
  } else {
    #line 55 "birch/distribution/IndependentMatrixGaussian.birch"
    libbirch_line_(55);
    #line 55 "birch/distribution/IndependentMatrixGaussian.birch"
    if (compare.query() && (m2 = this_()->M->graftMatrixNormalInverseGamma(compare.get(), handler_)).query()) {
      #line 56 "birch/distribution/IndependentMatrixGaussian.birch"
      libbirch_line_(56);
      #line 56 "birch/distribution/IndependentMatrixGaussian.birch"
      r = birch::MatrixNormalInverseGammaMatrixGaussian(m2.get(), handler_);
    } else {
      #line 57 "birch/distribution/IndependentMatrixGaussian.birch"
      libbirch_line_(57);
      #line 57 "birch/distribution/IndependentMatrixGaussian.birch"
      if ((s1 = this_()->_u09632->graftIndependentInverseGamma(handler_)).query()) {
        #line 58 "birch/distribution/IndependentMatrixGaussian.birch"
        libbirch_line_(58);
        #line 58 "birch/distribution/IndependentMatrixGaussian.birch"
        r = birch::MatrixNormalInverseGamma(this_()->M, birch::box(birch::llt(birch::identity(this_()->M->rows(handler_), handler_), handler_), handler_), s1.get(), handler_);
      }
    }
  }
  #line 61 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(61);
  #line 61 "birch/distribution/IndependentMatrixGaussian.birch"
  return r;
}

#line 64 "birch/distribution/IndependentMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>> birch::type::IndependentMatrixGaussian::graftMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("graftMatrixGaussian", "birch/distribution/IndependentMatrixGaussian.birch", 64);
  #line 65 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(65);
  #line 65 "birch/distribution/IndependentMatrixGaussian.birch"
  this_()->prune(handler_);
  #line 66 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(66);
  #line 66 "birch/distribution/IndependentMatrixGaussian.birch"
  return birch::Gaussian(this_()->M, birch::box(birch::llt(birch::identity(this_()->M->rows(handler_), handler_), handler_), handler_), birch::diagonal(this_()->_u09632, handler_), handler_);
}

#line 69 "birch/distribution/IndependentMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>> birch::type::IndependentMatrixGaussian::graftMatrixNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("graftMatrixNormalInverseGamma", "birch/distribution/IndependentMatrixGaussian.birch", 69);
  #line 71 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(71);
  #line 71 "birch/distribution/IndependentMatrixGaussian.birch"
  this_()->prune(handler_);
  #line 72 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(72);
  #line 72 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::IndependentInverseGamma>>> s1;
  #line 73 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(73);
  #line 73 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>> r;
  #line 76 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(76);
  #line 76 "birch/distribution/IndependentMatrixGaussian.birch"
  if ((s1 = this_()->_u09632->graftIndependentInverseGamma(handler_)).query() && s1.get() == compare) {
    #line 77 "birch/distribution/IndependentMatrixGaussian.birch"
    libbirch_line_(77);
    #line 77 "birch/distribution/IndependentMatrixGaussian.birch"
    r = birch::MatrixNormalInverseGamma(this_()->M, birch::box(birch::llt(birch::identity(this_()->M->rows(handler_), handler_), handler_), handler_), s1.get(), handler_);
  }
  #line 80 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(80);
  #line 80 "birch/distribution/IndependentMatrixGaussian.birch"
  return r;
}

#line 87 "birch/distribution/IndependentMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 87 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentMatrixGaussian.birch", 87);
  #line 89 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(89);
  #line 89 "birch/distribution/IndependentMatrixGaussian.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::IndependentMatrixGaussian>>>(M, _u09632, handler_);
}

#line 95 "birch/distribution/IndependentMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentMatrixGaussian.birch", 95);
  #line 97 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(97);
  #line 97 "birch/distribution/IndependentMatrixGaussian.birch"
  return birch::Gaussian(M, birch::box(_u09632, handler_), handler_);
}

#line 103 "birch/distribution/IndependentMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentMatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 103 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentMatrixGaussian.birch", 103);
  #line 105 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(105);
  #line 105 "birch/distribution/IndependentMatrixGaussian.birch"
  return birch::Gaussian(birch::box(M, handler_), _u09632, handler_);
}

#line 111 "birch/distribution/IndependentMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentMatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::DefaultArray<birch::type::Real,1>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 111 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentMatrixGaussian.birch", 111);
  #line 112 "birch/distribution/IndependentMatrixGaussian.birch"
  libbirch_line_(112);
  #line 112 "birch/distribution/IndependentMatrixGaussian.birch"
  return birch::Gaussian(birch::box(M, handler_), birch::box(_u09632, handler_), handler_);
}

#line 4 "birch/distribution/IndependentRowMatrixGaussian.birch"
birch::type::IndependentRowMatrixGaussian::IndependentRowMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/IndependentRowMatrixGaussian.birch"
    super_type_(),
    #line 9 "birch/distribution/IndependentRowMatrixGaussian.birch"
    M(M),
    #line 14 "birch/distribution/IndependentRowMatrixGaussian.birch"
    V(V) {
  //
}

#line 16 "birch/distribution/IndependentRowMatrixGaussian.birch"
birch::type::Integer birch::type::IndependentRowMatrixGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("rows", "birch/distribution/IndependentRowMatrixGaussian.birch", 16);
  #line 17 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(17);
  #line 17 "birch/distribution/IndependentRowMatrixGaussian.birch"
  return this_()->M->rows(handler_);
}

#line 20 "birch/distribution/IndependentRowMatrixGaussian.birch"
birch::type::Integer birch::type::IndependentRowMatrixGaussian::columns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("columns", "birch/distribution/IndependentRowMatrixGaussian.birch", 20);
  #line 21 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(21);
  #line 21 "birch/distribution/IndependentRowMatrixGaussian.birch"
  return this_()->M->columns(handler_);
}

#line 24 "birch/distribution/IndependentRowMatrixGaussian.birch"
birch::type::Boolean birch::type::IndependentRowMatrixGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("supportsLazy", "birch/distribution/IndependentRowMatrixGaussian.birch", 24);
  #line 25 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(25);
  #line 25 "birch/distribution/IndependentRowMatrixGaussian.birch"
  return true;
}

#line 28 "birch/distribution/IndependentRowMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::IndependentRowMatrixGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("simulate", "birch/distribution/IndependentRowMatrixGaussian.birch", 28);
  #line 29 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(29);
  #line 29 "birch/distribution/IndependentRowMatrixGaussian.birch"
  return birch::simulate_matrix_gaussian(this_()->M->value(handler_), this_()->V->value(handler_), handler_);
}

#line 32 "birch/distribution/IndependentRowMatrixGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::IndependentRowMatrixGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("simulateLazy", "birch/distribution/IndependentRowMatrixGaussian.birch", 32);
  #line 33 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(33);
  #line 33 "birch/distribution/IndependentRowMatrixGaussian.birch"
  return birch::simulate_matrix_gaussian(this_()->M->get(handler_), this_()->V->get(handler_), handler_);
}

#line 36 "birch/distribution/IndependentRowMatrixGaussian.birch"
birch::type::Real birch::type::IndependentRowMatrixGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,2>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("logpdf", "birch/distribution/IndependentRowMatrixGaussian.birch", 36);
  #line 37 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(37);
  #line 37 "birch/distribution/IndependentRowMatrixGaussian.birch"
  return birch::logpdf_matrix_gaussian(x, this_()->M->value(handler_), this_()->V->value(handler_), handler_);
}

#line 40 "birch/distribution/IndependentRowMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::IndependentRowMatrixGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/IndependentRowMatrixGaussian.birch", 40);
  #line 41 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(41);
  #line 41 "birch/distribution/IndependentRowMatrixGaussian.birch"
  return birch::logpdf_lazy_matrix_gaussian(x, this_()->M, this_()->V, handler_);
}

#line 44 "birch/distribution/IndependentRowMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>> birch::type::IndependentRowMatrixGaussian::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("graft", "birch/distribution/IndependentRowMatrixGaussian.birch", 44);
  #line 45 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(45);
  #line 45 "birch/distribution/IndependentRowMatrixGaussian.birch"
  this_()->prune(handler_);
  #line 46 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(46);
  #line 46 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>>> s1;
  #line 47 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(47);
  #line 47 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMatrix<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>>>>> m1;
  #line 48 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(48);
  #line 48 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>> m2;
  #line 49 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(49);
  #line 49 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>> r = shared_from_this_();
  #line 52 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(52);
  #line 52 "birch/distribution/IndependentRowMatrixGaussian.birch"
  auto compare = this_()->V->distribution(handler_);
  #line 53 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(53);
  #line 53 "birch/distribution/IndependentRowMatrixGaussian.birch"
  if (compare.query() && (m1 = this_()->M->graftLinearMatrixNormalInverseWishart(compare.get(), handler_)).query()) {
    #line 54 "birch/distribution/IndependentRowMatrixGaussian.birch"
    libbirch_line_(54);
    #line 54 "birch/distribution/IndependentRowMatrixGaussian.birch"
    r = birch::LinearMatrixNormalInverseWishartMatrixGaussian(m1.get()->A, m1.get()->X, m1.get()->C, handler_);
  } else {
    #line 55 "birch/distribution/IndependentRowMatrixGaussian.birch"
    libbirch_line_(55);
    #line 55 "birch/distribution/IndependentRowMatrixGaussian.birch"
    if (compare.query() && (m2 = this_()->M->graftMatrixNormalInverseWishart(compare.get(), handler_)).query()) {
      #line 56 "birch/distribution/IndependentRowMatrixGaussian.birch"
      libbirch_line_(56);
      #line 56 "birch/distribution/IndependentRowMatrixGaussian.birch"
      r = birch::MatrixNormalInverseWishartMatrixGaussian(m2.get(), handler_);
    } else {
      #line 57 "birch/distribution/IndependentRowMatrixGaussian.birch"
      libbirch_line_(57);
      #line 57 "birch/distribution/IndependentRowMatrixGaussian.birch"
      if ((s1 = this_()->V->graftInverseWishart(handler_)).query()) {
        #line 58 "birch/distribution/IndependentRowMatrixGaussian.birch"
        libbirch_line_(58);
        #line 58 "birch/distribution/IndependentRowMatrixGaussian.birch"
        r = birch::MatrixNormalInverseWishart(this_()->M, birch::box(birch::llt(birch::identity(this_()->M->rows(handler_), handler_), handler_), handler_), s1.get(), handler_);
      }
    }
  }
  #line 61 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(61);
  #line 61 "birch/distribution/IndependentRowMatrixGaussian.birch"
  return r;
}

#line 64 "birch/distribution/IndependentRowMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>> birch::type::IndependentRowMatrixGaussian::graftMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("graftMatrixGaussian", "birch/distribution/IndependentRowMatrixGaussian.birch", 64);
  #line 65 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(65);
  #line 65 "birch/distribution/IndependentRowMatrixGaussian.birch"
  this_()->prune(handler_);
  #line 66 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(66);
  #line 66 "birch/distribution/IndependentRowMatrixGaussian.birch"
  return birch::Gaussian(this_()->M, birch::box(birch::llt(birch::identity(this_()->M->rows(handler_), handler_), handler_), handler_), this_()->V, handler_);
}

#line 69 "birch/distribution/IndependentRowMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>> birch::type::IndependentRowMatrixGaussian::graftMatrixNormalInverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::LLT>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("graftMatrixNormalInverseWishart", "birch/distribution/IndependentRowMatrixGaussian.birch", 69);
  #line 71 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(71);
  #line 71 "birch/distribution/IndependentRowMatrixGaussian.birch"
  this_()->prune(handler_);
  #line 72 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(72);
  #line 72 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>>> s1;
  #line 73 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(73);
  #line 73 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>> r;
  #line 76 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(76);
  #line 76 "birch/distribution/IndependentRowMatrixGaussian.birch"
  if ((s1 = this_()->V->graftInverseWishart(handler_)).query() && s1.get() == compare) {
    #line 77 "birch/distribution/IndependentRowMatrixGaussian.birch"
    libbirch_line_(77);
    #line 77 "birch/distribution/IndependentRowMatrixGaussian.birch"
    r = birch::MatrixNormalInverseWishart(this_()->M, birch::box(birch::llt(birch::identity(this_()->M->rows(handler_), handler_), handler_), handler_), s1.get(), handler_);
  }
  #line 80 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(80);
  #line 80 "birch/distribution/IndependentRowMatrixGaussian.birch"
  return r;
}

#line 87 "birch/distribution/IndependentRowMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentRowMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 87 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentRowMatrixGaussian.birch", 87);
  #line 89 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(89);
  #line 89 "birch/distribution/IndependentRowMatrixGaussian.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::IndependentRowMatrixGaussian>>>(M, V, handler_);
}

#line 95 "birch/distribution/IndependentRowMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentRowMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const birch::type::LLT& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentRowMatrixGaussian.birch", 95);
  #line 97 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(97);
  #line 97 "birch/distribution/IndependentRowMatrixGaussian.birch"
  return birch::Gaussian(M, birch::box(V, handler_), handler_);
}

#line 103 "birch/distribution/IndependentRowMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentRowMatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 103 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentRowMatrixGaussian.birch", 103);
  #line 105 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(105);
  #line 105 "birch/distribution/IndependentRowMatrixGaussian.birch"
  return birch::Gaussian(birch::box(M, handler_), V, handler_);
}

#line 111 "birch/distribution/IndependentRowMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentRowMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 111 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentRowMatrixGaussian.birch", 111);
  #line 113 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(113);
  #line 113 "birch/distribution/IndependentRowMatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(V, handler_), handler_);
}

#line 119 "birch/distribution/IndependentRowMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentRowMatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::DefaultArray<birch::type::Real,2>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 119 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentRowMatrixGaussian.birch", 119);
  #line 121 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(121);
  #line 121 "birch/distribution/IndependentRowMatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(V, handler_), handler_);
}

#line 127 "birch/distribution/IndependentRowMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentRowMatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 127 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/IndependentRowMatrixGaussian.birch", 127);
  #line 129 "birch/distribution/IndependentRowMatrixGaussian.birch"
  libbirch_line_(129);
  #line 129 "birch/distribution/IndependentRowMatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(V, handler_), handler_);
}

#line 4 "birch/distribution/IndependentUniform.birch"
birch::type::IndependentUniform::IndependentUniform(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& l, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/IndependentUniform.birch"
    super_type_(),
    #line 9 "birch/distribution/IndependentUniform.birch"
    l(l),
    #line 14 "birch/distribution/IndependentUniform.birch"
    u(u) {
  //
}

#line 16 "birch/distribution/IndependentUniform.birch"
birch::type::Integer birch::type::IndependentUniform::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "birch/distribution/IndependentUniform.birch"
  libbirch_function_("rows", "birch/distribution/IndependentUniform.birch", 16);
  #line 17 "birch/distribution/IndependentUniform.birch"
  libbirch_line_(17);
  #line 17 "birch/distribution/IndependentUniform.birch"
  return this_()->l->rows(handler_);
}

#line 20 "birch/distribution/IndependentUniform.birch"
birch::type::Boolean birch::type::IndependentUniform::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "birch/distribution/IndependentUniform.birch"
  libbirch_function_("supportsLazy", "birch/distribution/IndependentUniform.birch", 20);
  #line 21 "birch/distribution/IndependentUniform.birch"
  libbirch_line_(21);
  #line 21 "birch/distribution/IndependentUniform.birch"
  return false;
}

#line 24 "birch/distribution/IndependentUniform.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::IndependentUniform::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "birch/distribution/IndependentUniform.birch"
  libbirch_function_("simulate", "birch/distribution/IndependentUniform.birch", 24);
  #line 25 "birch/distribution/IndependentUniform.birch"
  libbirch_line_(25);
  #line 25 "birch/distribution/IndependentUniform.birch"
  return birch::simulate_independent_uniform(this_()->l->value(handler_), this_()->u->value(handler_), handler_);
}

#line 32 "birch/distribution/IndependentUniform.birch"
birch::type::Real birch::type::IndependentUniform::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "birch/distribution/IndependentUniform.birch"
  libbirch_function_("logpdf", "birch/distribution/IndependentUniform.birch", 32);
  #line 33 "birch/distribution/IndependentUniform.birch"
  libbirch_line_(33);
  #line 33 "birch/distribution/IndependentUniform.birch"
  return birch::logpdf_independent_uniform(x, this_()->l->value(handler_), this_()->u->value(handler_), handler_);
}

#line 40 "birch/distribution/IndependentUniform.birch"
void birch::type::IndependentUniform::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "birch/distribution/IndependentUniform.birch"
  libbirch_function_("write", "birch/distribution/IndependentUniform.birch", 40);
  #line 41 "birch/distribution/IndependentUniform.birch"
  libbirch_line_(41);
  #line 41 "birch/distribution/IndependentUniform.birch"
  this_()->prune(handler_);
  #line 42 "birch/distribution/IndependentUniform.birch"
  libbirch_line_(42);
  #line 42 "birch/distribution/IndependentUniform.birch"
  buffer->set(birch::type::String("class"), birch::type::String("IndependentUniform"), handler_);
  #line 43 "birch/distribution/IndependentUniform.birch"
  libbirch_line_(43);
  #line 43 "birch/distribution/IndependentUniform.birch"
  buffer->set(birch::type::String("l"), this_()->l, handler_);
  #line 44 "birch/distribution/IndependentUniform.birch"
  libbirch_line_(44);
  #line 44 "birch/distribution/IndependentUniform.birch"
  buffer->set(birch::type::String("u"), this_()->u, handler_);
}

#line 52 "birch/distribution/IndependentUniform.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentUniform>> birch::Uniform(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& l, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "birch/distribution/IndependentUniform.birch"
  libbirch_function_("Uniform", "birch/distribution/IndependentUniform.birch", 52);
  #line 54 "birch/distribution/IndependentUniform.birch"
  libbirch_line_(54);
  #line 54 "birch/distribution/IndependentUniform.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::IndependentUniform>>>(l, u, handler_);
}

#line 61 "birch/distribution/IndependentUniform.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentUniform>> birch::Uniform(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& l, const libbirch::DefaultArray<birch::type::Real,1>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "birch/distribution/IndependentUniform.birch"
  libbirch_function_("Uniform", "birch/distribution/IndependentUniform.birch", 61);
  #line 62 "birch/distribution/IndependentUniform.birch"
  libbirch_line_(62);
  #line 62 "birch/distribution/IndependentUniform.birch"
  return birch::Uniform(l, birch::box(u, handler_), handler_);
}

#line 69 "birch/distribution/IndependentUniform.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentUniform>> birch::Uniform(const libbirch::DefaultArray<birch::type::Real,1>& l, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "birch/distribution/IndependentUniform.birch"
  libbirch_function_("Uniform", "birch/distribution/IndependentUniform.birch", 69);
  #line 70 "birch/distribution/IndependentUniform.birch"
  libbirch_line_(70);
  #line 70 "birch/distribution/IndependentUniform.birch"
  return birch::Uniform(birch::box(l, handler_), u, handler_);
}

#line 77 "birch/distribution/IndependentUniform.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentUniform>> birch::Uniform(const libbirch::DefaultArray<birch::type::Real,1>& l, const libbirch::DefaultArray<birch::type::Real,1>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 77 "birch/distribution/IndependentUniform.birch"
  libbirch_function_("Uniform", "birch/distribution/IndependentUniform.birch", 77);
  #line 78 "birch/distribution/IndependentUniform.birch"
  libbirch_line_(78);
  #line 78 "birch/distribution/IndependentUniform.birch"
  return birch::Uniform(birch::box(l, handler_), birch::box(u, handler_), handler_);
}

#line 5 "birch/distribution/IndependentUniformInteger.birch"
birch::type::IndependentUniformInteger::IndependentUniformInteger(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Integer,1>>>>& l, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Integer,1>>>>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 5 "birch/distribution/IndependentUniformInteger.birch"
    super_type_(),
    #line 10 "birch/distribution/IndependentUniformInteger.birch"
    l(l),
    #line 15 "birch/distribution/IndependentUniformInteger.birch"
    u(u) {
  //
}

#line 17 "birch/distribution/IndependentUniformInteger.birch"
birch::type::Integer birch::type::IndependentUniformInteger::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 17 "birch/distribution/IndependentUniformInteger.birch"
  libbirch_function_("rows", "birch/distribution/IndependentUniformInteger.birch", 17);
  #line 18 "birch/distribution/IndependentUniformInteger.birch"
  libbirch_line_(18);
  #line 18 "birch/distribution/IndependentUniformInteger.birch"
  return this_()->l->rows(handler_);
}

#line 21 "birch/distribution/IndependentUniformInteger.birch"
birch::type::Boolean birch::type::IndependentUniformInteger::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "birch/distribution/IndependentUniformInteger.birch"
  libbirch_function_("supportsLazy", "birch/distribution/IndependentUniformInteger.birch", 21);
  #line 22 "birch/distribution/IndependentUniformInteger.birch"
  libbirch_line_(22);
  #line 22 "birch/distribution/IndependentUniformInteger.birch"
  return false;
}

#line 25 "birch/distribution/IndependentUniformInteger.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::type::IndependentUniformInteger::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "birch/distribution/IndependentUniformInteger.birch"
  libbirch_function_("simulate", "birch/distribution/IndependentUniformInteger.birch", 25);
  #line 26 "birch/distribution/IndependentUniformInteger.birch"
  libbirch_line_(26);
  #line 26 "birch/distribution/IndependentUniformInteger.birch"
  return birch::simulate_independent_uniform_int(this_()->l->value(handler_), this_()->u->value(handler_), handler_);
}

#line 33 "birch/distribution/IndependentUniformInteger.birch"
birch::type::Real birch::type::IndependentUniformInteger::logpdf(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "birch/distribution/IndependentUniformInteger.birch"
  libbirch_function_("logpdf", "birch/distribution/IndependentUniformInteger.birch", 33);
  #line 34 "birch/distribution/IndependentUniformInteger.birch"
  libbirch_line_(34);
  #line 34 "birch/distribution/IndependentUniformInteger.birch"
  return birch::logpdf_independent_uniform_int(x, this_()->l->value(handler_), this_()->u->value(handler_), handler_);
}

#line 41 "birch/distribution/IndependentUniformInteger.birch"
void birch::type::IndependentUniformInteger::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "birch/distribution/IndependentUniformInteger.birch"
  libbirch_function_("write", "birch/distribution/IndependentUniformInteger.birch", 41);
  #line 42 "birch/distribution/IndependentUniformInteger.birch"
  libbirch_line_(42);
  #line 42 "birch/distribution/IndependentUniformInteger.birch"
  this_()->prune(handler_);
  #line 43 "birch/distribution/IndependentUniformInteger.birch"
  libbirch_line_(43);
  #line 43 "birch/distribution/IndependentUniformInteger.birch"
  buffer->set(birch::type::String("class"), birch::type::String("IndependentUniformInteger"), handler_);
  #line 44 "birch/distribution/IndependentUniformInteger.birch"
  libbirch_line_(44);
  #line 44 "birch/distribution/IndependentUniformInteger.birch"
  buffer->set(birch::type::String("l"), this_()->l, handler_);
  #line 45 "birch/distribution/IndependentUniformInteger.birch"
  libbirch_line_(45);
  #line 45 "birch/distribution/IndependentUniformInteger.birch"
  buffer->set(birch::type::String("u"), this_()->u, handler_);
}

#line 53 "birch/distribution/IndependentUniformInteger.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentUniformInteger>> birch::Uniform(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Integer,1>>>>& l, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Integer,1>>>>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "birch/distribution/IndependentUniformInteger.birch"
  libbirch_function_("Uniform", "birch/distribution/IndependentUniformInteger.birch", 53);
  #line 55 "birch/distribution/IndependentUniformInteger.birch"
  libbirch_line_(55);
  #line 55 "birch/distribution/IndependentUniformInteger.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::IndependentUniformInteger>>>(l, u, handler_);
}

#line 62 "birch/distribution/IndependentUniformInteger.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentUniformInteger>> birch::Uniform(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Integer,1>>>>& l, const libbirch::DefaultArray<birch::type::Integer,1>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 62 "birch/distribution/IndependentUniformInteger.birch"
  libbirch_function_("Uniform", "birch/distribution/IndependentUniformInteger.birch", 62);
  #line 64 "birch/distribution/IndependentUniformInteger.birch"
  libbirch_line_(64);
  #line 64 "birch/distribution/IndependentUniformInteger.birch"
  return birch::Uniform(l, birch::box(u, handler_), handler_);
}

#line 71 "birch/distribution/IndependentUniformInteger.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentUniformInteger>> birch::Uniform(const libbirch::DefaultArray<birch::type::Integer,1>& l, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Integer,1>>>>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 71 "birch/distribution/IndependentUniformInteger.birch"
  libbirch_function_("Uniform", "birch/distribution/IndependentUniformInteger.birch", 71);
  #line 73 "birch/distribution/IndependentUniformInteger.birch"
  libbirch_line_(73);
  #line 73 "birch/distribution/IndependentUniformInteger.birch"
  return birch::Uniform(birch::box(l, handler_), u, handler_);
}

#line 80 "birch/distribution/IndependentUniformInteger.birch"
libbirch::Lazy<libbirch::Shared<birch::type::IndependentUniformInteger>> birch::Uniform(const libbirch::DefaultArray<birch::type::Integer,1>& l, const libbirch::DefaultArray<birch::type::Integer,1>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 80 "birch/distribution/IndependentUniformInteger.birch"
  libbirch_function_("Uniform", "birch/distribution/IndependentUniformInteger.birch", 80);
  #line 81 "birch/distribution/IndependentUniformInteger.birch"
  libbirch_line_(81);
  #line 81 "birch/distribution/IndependentUniformInteger.birch"
  return birch::Uniform(birch::box(l, handler_), birch::box(u, handler_), handler_);
}

#line 4 "birch/distribution/InverseGamma.birch"
birch::type::InverseGamma::InverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/InverseGamma.birch"
    super_type_(),
    #line 9 "birch/distribution/InverseGamma.birch"
    _u0945(_u0945),
    #line 14 "birch/distribution/InverseGamma.birch"
    _u0946(_u0946) {
  //
}

#line 16 "birch/distribution/InverseGamma.birch"
birch::type::Boolean birch::type::InverseGamma::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "birch/distribution/InverseGamma.birch"
  libbirch_function_("supportsLazy", "birch/distribution/InverseGamma.birch", 16);
  #line 17 "birch/distribution/InverseGamma.birch"
  libbirch_line_(17);
  #line 17 "birch/distribution/InverseGamma.birch"
  return true;
}

#line 20 "birch/distribution/InverseGamma.birch"
birch::type::Real birch::type::InverseGamma::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "birch/distribution/InverseGamma.birch"
  libbirch_function_("simulate", "birch/distribution/InverseGamma.birch", 20);
  #line 21 "birch/distribution/InverseGamma.birch"
  libbirch_line_(21);
  #line 21 "birch/distribution/InverseGamma.birch"
  return birch::simulate_inverse_gamma(this_()->_u0945->value(handler_), this_()->_u0946->value(handler_), handler_);
}

#line 24 "birch/distribution/InverseGamma.birch"
libbirch::Optional<birch::type::Real> birch::type::InverseGamma::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "birch/distribution/InverseGamma.birch"
  libbirch_function_("simulateLazy", "birch/distribution/InverseGamma.birch", 24);
  #line 25 "birch/distribution/InverseGamma.birch"
  libbirch_line_(25);
  #line 25 "birch/distribution/InverseGamma.birch"
  return birch::simulate_inverse_gamma(this_()->_u0945->get(handler_), this_()->_u0946->get(handler_), handler_);
}

#line 28 "birch/distribution/InverseGamma.birch"
birch::type::Real birch::type::InverseGamma::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "birch/distribution/InverseGamma.birch"
  libbirch_function_("logpdf", "birch/distribution/InverseGamma.birch", 28);
  #line 29 "birch/distribution/InverseGamma.birch"
  libbirch_line_(29);
  #line 29 "birch/distribution/InverseGamma.birch"
  return birch::logpdf_inverse_gamma(x, this_()->_u0945->value(handler_), this_()->_u0946->value(handler_), handler_);
}

#line 32 "birch/distribution/InverseGamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::InverseGamma::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "birch/distribution/InverseGamma.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/InverseGamma.birch", 32);
  #line 33 "birch/distribution/InverseGamma.birch"
  libbirch_line_(33);
  #line 33 "birch/distribution/InverseGamma.birch"
  return birch::logpdf_lazy_inverse_gamma(x, this_()->_u0945, this_()->_u0946, handler_);
}

#line 36 "birch/distribution/InverseGamma.birch"
libbirch::Optional<birch::type::Real> birch::type::InverseGamma::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "birch/distribution/InverseGamma.birch"
  libbirch_function_("cdf", "birch/distribution/InverseGamma.birch", 36);
  #line 37 "birch/distribution/InverseGamma.birch"
  libbirch_line_(37);
  #line 37 "birch/distribution/InverseGamma.birch"
  return birch::cdf_inverse_gamma(x, this_()->_u0945->value(handler_), this_()->_u0946->value(handler_), handler_);
}

#line 40 "birch/distribution/InverseGamma.birch"
libbirch::Optional<birch::type::Real> birch::type::InverseGamma::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "birch/distribution/InverseGamma.birch"
  libbirch_function_("quantile", "birch/distribution/InverseGamma.birch", 40);
  #line 41 "birch/distribution/InverseGamma.birch"
  libbirch_line_(41);
  #line 41 "birch/distribution/InverseGamma.birch"
  return birch::quantile_inverse_gamma(P, this_()->_u0945->value(handler_), this_()->_u0946->value(handler_), handler_);
}

#line 44 "birch/distribution/InverseGamma.birch"
libbirch::Optional<birch::type::Real> birch::type::InverseGamma::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "birch/distribution/InverseGamma.birch"
  libbirch_function_("lower", "birch/distribution/InverseGamma.birch", 44);
  #line 45 "birch/distribution/InverseGamma.birch"
  libbirch_line_(45);
  #line 45 "birch/distribution/InverseGamma.birch"
  return 0.0;
}

#line 48 "birch/distribution/InverseGamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>> birch::type::InverseGamma::graftInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "birch/distribution/InverseGamma.birch"
  libbirch_function_("graftInverseGamma", "birch/distribution/InverseGamma.birch", 48);
  #line 49 "birch/distribution/InverseGamma.birch"
  libbirch_line_(49);
  #line 49 "birch/distribution/InverseGamma.birch"
  this_()->prune(handler_);
  #line 50 "birch/distribution/InverseGamma.birch"
  libbirch_line_(50);
  #line 50 "birch/distribution/InverseGamma.birch"
  return shared_from_this_();
}

#line 53 "birch/distribution/InverseGamma.birch"
void birch::type::InverseGamma::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "birch/distribution/InverseGamma.birch"
  libbirch_function_("write", "birch/distribution/InverseGamma.birch", 53);
  #line 54 "birch/distribution/InverseGamma.birch"
  libbirch_line_(54);
  #line 54 "birch/distribution/InverseGamma.birch"
  this_()->prune(handler_);
  #line 55 "birch/distribution/InverseGamma.birch"
  libbirch_line_(55);
  #line 55 "birch/distribution/InverseGamma.birch"
  buffer->set(birch::type::String("class"), birch::type::String("InverseGamma"), handler_);
  #line 56 "birch/distribution/InverseGamma.birch"
  libbirch_line_(56);
  #line 56 "birch/distribution/InverseGamma.birch"
  buffer->set(birch::type::String("α"), this_()->_u0945, handler_);
  #line 57 "birch/distribution/InverseGamma.birch"
  libbirch_line_(57);
  #line 57 "birch/distribution/InverseGamma.birch"
  buffer->set(birch::type::String("β"), this_()->_u0946, handler_);
}

#line 64 "birch/distribution/InverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>> birch::InverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "birch/distribution/InverseGamma.birch"
  libbirch_function_("InverseGamma", "birch/distribution/InverseGamma.birch", 64);
  #line 66 "birch/distribution/InverseGamma.birch"
  libbirch_line_(66);
  #line 66 "birch/distribution/InverseGamma.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>>(_u0945, _u0946, handler_);
}

#line 72 "birch/distribution/InverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>> birch::InverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "birch/distribution/InverseGamma.birch"
  libbirch_function_("InverseGamma", "birch/distribution/InverseGamma.birch", 72);
  #line 73 "birch/distribution/InverseGamma.birch"
  libbirch_line_(73);
  #line 73 "birch/distribution/InverseGamma.birch"
  return birch::InverseGamma(_u0945, birch::box(_u0946, handler_), handler_);
}

#line 79 "birch/distribution/InverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>> birch::InverseGamma(const birch::type::Real& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 79 "birch/distribution/InverseGamma.birch"
  libbirch_function_("InverseGamma", "birch/distribution/InverseGamma.birch", 79);
  #line 80 "birch/distribution/InverseGamma.birch"
  libbirch_line_(80);
  #line 80 "birch/distribution/InverseGamma.birch"
  return birch::InverseGamma(birch::box(_u0945, handler_), _u0946, handler_);
}

#line 86 "birch/distribution/InverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>> birch::InverseGamma(const birch::type::Real& _u0945, const birch::type::Real& _u0946, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 86 "birch/distribution/InverseGamma.birch"
  libbirch_function_("InverseGamma", "birch/distribution/InverseGamma.birch", 86);
  #line 87 "birch/distribution/InverseGamma.birch"
  libbirch_line_(87);
  #line 87 "birch/distribution/InverseGamma.birch"
  return birch::InverseGamma(birch::box(_u0945, handler_), birch::box(_u0946, handler_), handler_);
}

#line 4 "birch/distribution/InverseGammaGamma.birch"
birch::type::InverseGammaGamma::InverseGammaGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/InverseGammaGamma.birch"
    super_type_(),
    #line 9 "birch/distribution/InverseGammaGamma.birch"
    k(k),
    #line 14 "birch/distribution/InverseGammaGamma.birch"
    _u0952(_u0952) {
  //
}

#line 16 "birch/distribution/InverseGammaGamma.birch"
birch::type::Boolean birch::type::InverseGammaGamma::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "birch/distribution/InverseGammaGamma.birch"
  libbirch_function_("supportsLazy", "birch/distribution/InverseGammaGamma.birch", 16);
  #line 17 "birch/distribution/InverseGammaGamma.birch"
  libbirch_line_(17);
  #line 17 "birch/distribution/InverseGammaGamma.birch"
  return true;
}

#line 20 "birch/distribution/InverseGammaGamma.birch"
birch::type::Real birch::type::InverseGammaGamma::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "birch/distribution/InverseGammaGamma.birch"
  libbirch_function_("simulate", "birch/distribution/InverseGammaGamma.birch", 20);
  #line 21 "birch/distribution/InverseGammaGamma.birch"
  libbirch_line_(21);
  #line 21 "birch/distribution/InverseGammaGamma.birch"
  return birch::simulate_inverse_gamma_gamma(this_()->k->value(handler_), this_()->_u0952->_u0945->value(handler_), this_()->_u0952->_u0946->value(handler_), handler_);
}

#line 24 "birch/distribution/InverseGammaGamma.birch"
libbirch::Optional<birch::type::Real> birch::type::InverseGammaGamma::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "birch/distribution/InverseGammaGamma.birch"
  libbirch_function_("simulateLazy", "birch/distribution/InverseGammaGamma.birch", 24);
  #line 25 "birch/distribution/InverseGammaGamma.birch"
  libbirch_line_(25);
  #line 25 "birch/distribution/InverseGammaGamma.birch"
  return birch::simulate_inverse_gamma_gamma(this_()->k->get(handler_), this_()->_u0952->_u0945->get(handler_), this_()->_u0952->_u0946->get(handler_), handler_);
}

#line 28 "birch/distribution/InverseGammaGamma.birch"
birch::type::Real birch::type::InverseGammaGamma::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "birch/distribution/InverseGammaGamma.birch"
  libbirch_function_("logpdf", "birch/distribution/InverseGammaGamma.birch", 28);
  #line 29 "birch/distribution/InverseGammaGamma.birch"
  libbirch_line_(29);
  #line 29 "birch/distribution/InverseGammaGamma.birch"
  return birch::logpdf_inverse_gamma_gamma(x, this_()->k->value(handler_), this_()->_u0952->_u0945->value(handler_), this_()->_u0952->_u0946->value(handler_), handler_);
}

#line 32 "birch/distribution/InverseGammaGamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::InverseGammaGamma::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "birch/distribution/InverseGammaGamma.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/InverseGammaGamma.birch", 32);
  #line 33 "birch/distribution/InverseGammaGamma.birch"
  libbirch_line_(33);
  #line 33 "birch/distribution/InverseGammaGamma.birch"
  return birch::logpdf_lazy_inverse_gamma_gamma(x, this_()->k, this_()->_u0952->_u0945, this_()->_u0952->_u0946, handler_);
}

#line 36 "birch/distribution/InverseGammaGamma.birch"
void birch::type::InverseGammaGamma::update(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "birch/distribution/InverseGammaGamma.birch"
  libbirch_function_("update", "birch/distribution/InverseGammaGamma.birch", 36);
  #line 37 "birch/distribution/InverseGammaGamma.birch"
  libbirch_line_(37);
  #line 37 "birch/distribution/InverseGammaGamma.birch"
  libbirch::tie(this_()->_u0952->_u0945, this_()->_u0952->_u0946) = birch::box(birch::update_inverse_gamma_gamma(x, this_()->k->value(handler_), this_()->_u0952->_u0945->value(handler_), this_()->_u0952->_u0946->value(handler_), handler_), handler_);
}

#line 40 "birch/distribution/InverseGammaGamma.birch"
void birch::type::InverseGammaGamma::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "birch/distribution/InverseGammaGamma.birch"
  libbirch_function_("updateLazy", "birch/distribution/InverseGammaGamma.birch", 40);
  #line 41 "birch/distribution/InverseGammaGamma.birch"
  libbirch_line_(41);
  #line 41 "birch/distribution/InverseGammaGamma.birch"
  libbirch::tie(this_()->_u0952->_u0945, this_()->_u0952->_u0946) = birch::update_lazy_inverse_gamma_gamma(x, this_()->k, this_()->_u0952->_u0945, this_()->_u0952->_u0946, handler_);
}

#line 44 "birch/distribution/InverseGammaGamma.birch"
void birch::type::InverseGammaGamma::downdate(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "birch/distribution/InverseGammaGamma.birch"
  libbirch_function_("downdate", "birch/distribution/InverseGammaGamma.birch", 44);
  #line 45 "birch/distribution/InverseGammaGamma.birch"
  libbirch_line_(45);
  #line 45 "birch/distribution/InverseGammaGamma.birch"
  libbirch::tie(this_()->_u0952->_u0945, this_()->_u0952->_u0946) = birch::box(birch::downdate_inverse_gamma_gamma(x, this_()->k->value(handler_), this_()->_u0952->_u0945->value(handler_), this_()->_u0952->_u0946->value(handler_), handler_), handler_);
}

#line 48 "birch/distribution/InverseGammaGamma.birch"
libbirch::Optional<birch::type::Real> birch::type::InverseGammaGamma::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "birch/distribution/InverseGammaGamma.birch"
  libbirch_function_("cdf", "birch/distribution/InverseGammaGamma.birch", 48);
  #line 49 "birch/distribution/InverseGammaGamma.birch"
  libbirch_line_(49);
  #line 49 "birch/distribution/InverseGammaGamma.birch"
  return birch::cdf_inverse_gamma_gamma(x, this_()->k->value(handler_), this_()->_u0952->_u0945->value(handler_), this_()->_u0952->_u0946->value(handler_), handler_);
}

#line 52 "birch/distribution/InverseGammaGamma.birch"
libbirch::Optional<birch::type::Real> birch::type::InverseGammaGamma::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "birch/distribution/InverseGammaGamma.birch"
  libbirch_function_("lower", "birch/distribution/InverseGammaGamma.birch", 52);
  #line 53 "birch/distribution/InverseGammaGamma.birch"
  libbirch_line_(53);
  #line 53 "birch/distribution/InverseGammaGamma.birch"
  return 0.0;
}

#line 56 "birch/distribution/InverseGammaGamma.birch"
void birch::type::InverseGammaGamma::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 56 "birch/distribution/InverseGammaGamma.birch"
  libbirch_function_("link", "birch/distribution/InverseGammaGamma.birch", 56);
  #line 57 "birch/distribution/InverseGammaGamma.birch"
  libbirch_line_(57);
  #line 57 "birch/distribution/InverseGammaGamma.birch"
  this_()->_u0952->setChild(shared_from_this_(), handler_);
}

#line 60 "birch/distribution/InverseGammaGamma.birch"
void birch::type::InverseGammaGamma::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "birch/distribution/InverseGammaGamma.birch"
  libbirch_function_("unlink", "birch/distribution/InverseGammaGamma.birch", 60);
  #line 61 "birch/distribution/InverseGammaGamma.birch"
  libbirch_line_(61);
  #line 61 "birch/distribution/InverseGammaGamma.birch"
  this_()->_u0952->releaseChild(shared_from_this_(), handler_);
}

#line 65 "birch/distribution/InverseGammaGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseGammaGamma>> birch::InverseGammaGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "birch/distribution/InverseGammaGamma.birch"
  libbirch_function_("InverseGammaGamma", "birch/distribution/InverseGammaGamma.birch", 65);
  #line 67 "birch/distribution/InverseGammaGamma.birch"
  libbirch_line_(67);
  #line 67 "birch/distribution/InverseGammaGamma.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::InverseGammaGamma>> m(k, _u0952);
  #line 68 "birch/distribution/InverseGammaGamma.birch"
  libbirch_line_(68);
  #line 68 "birch/distribution/InverseGammaGamma.birch"
  m->link(handler_);
  #line 69 "birch/distribution/InverseGammaGamma.birch"
  libbirch_line_(69);
  #line 69 "birch/distribution/InverseGammaGamma.birch"
  return m;
}

#line 30 "birch/distribution/InverseWishart.birch"
birch::type::InverseWishart::InverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 30 "birch/distribution/InverseWishart.birch"
    super_type_(),
    #line 35 "birch/distribution/InverseWishart.birch"
    _u0936(_u0936),
    #line 40 "birch/distribution/InverseWishart.birch"
    k(k) {
  //
}

#line 42 "birch/distribution/InverseWishart.birch"
birch::type::Integer birch::type::InverseWishart::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "birch/distribution/InverseWishart.birch"
  libbirch_function_("rows", "birch/distribution/InverseWishart.birch", 42);
  #line 43 "birch/distribution/InverseWishart.birch"
  libbirch_line_(43);
  #line 43 "birch/distribution/InverseWishart.birch"
  return this_()->_u0936->rows(handler_);
}

#line 46 "birch/distribution/InverseWishart.birch"
birch::type::Integer birch::type::InverseWishart::columns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "birch/distribution/InverseWishart.birch"
  libbirch_function_("columns", "birch/distribution/InverseWishart.birch", 46);
  #line 47 "birch/distribution/InverseWishart.birch"
  libbirch_line_(47);
  #line 47 "birch/distribution/InverseWishart.birch"
  return this_()->_u0936->columns(handler_);
}

#line 50 "birch/distribution/InverseWishart.birch"
birch::type::Boolean birch::type::InverseWishart::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "birch/distribution/InverseWishart.birch"
  libbirch_function_("supportsLazy", "birch/distribution/InverseWishart.birch", 50);
  #line 51 "birch/distribution/InverseWishart.birch"
  libbirch_line_(51);
  #line 51 "birch/distribution/InverseWishart.birch"
  return true;
}

#line 54 "birch/distribution/InverseWishart.birch"
birch::type::LLT birch::type::InverseWishart::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "birch/distribution/InverseWishart.birch"
  libbirch_function_("simulate", "birch/distribution/InverseWishart.birch", 54);
  #line 55 "birch/distribution/InverseWishart.birch"
  libbirch_line_(55);
  #line 55 "birch/distribution/InverseWishart.birch"
  return birch::simulate_inverse_wishart(this_()->_u0936->value(handler_), this_()->k->value(handler_), handler_);
}

#line 58 "birch/distribution/InverseWishart.birch"
libbirch::Optional<birch::type::LLT> birch::type::InverseWishart::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "birch/distribution/InverseWishart.birch"
  libbirch_function_("simulateLazy", "birch/distribution/InverseWishart.birch", 58);
  #line 59 "birch/distribution/InverseWishart.birch"
  libbirch_line_(59);
  #line 59 "birch/distribution/InverseWishart.birch"
  return birch::simulate_inverse_wishart(this_()->_u0936->get(handler_), this_()->k->get(handler_), handler_);
}

#line 62 "birch/distribution/InverseWishart.birch"
birch::type::Real birch::type::InverseWishart::logpdf(const birch::type::LLT& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 62 "birch/distribution/InverseWishart.birch"
  libbirch_function_("logpdf", "birch/distribution/InverseWishart.birch", 62);
  #line 63 "birch/distribution/InverseWishart.birch"
  libbirch_line_(63);
  #line 63 "birch/distribution/InverseWishart.birch"
  return birch::logpdf_inverse_wishart(X, this_()->_u0936->value(handler_), this_()->k->value(handler_), handler_);
}

#line 66 "birch/distribution/InverseWishart.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::InverseWishart::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "birch/distribution/InverseWishart.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/InverseWishart.birch", 66);
  #line 67 "birch/distribution/InverseWishart.birch"
  libbirch_line_(67);
  #line 67 "birch/distribution/InverseWishart.birch"
  return birch::logpdf_lazy_inverse_wishart(X, this_()->_u0936, this_()->k, handler_);
}

#line 70 "birch/distribution/InverseWishart.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>>> birch::type::InverseWishart::graftInverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "birch/distribution/InverseWishart.birch"
  libbirch_function_("graftInverseWishart", "birch/distribution/InverseWishart.birch", 70);
  #line 71 "birch/distribution/InverseWishart.birch"
  libbirch_line_(71);
  #line 71 "birch/distribution/InverseWishart.birch"
  this_()->prune(handler_);
  #line 72 "birch/distribution/InverseWishart.birch"
  libbirch_line_(72);
  #line 72 "birch/distribution/InverseWishart.birch"
  return shared_from_this_();
}

#line 75 "birch/distribution/InverseWishart.birch"
void birch::type::InverseWishart::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 75 "birch/distribution/InverseWishart.birch"
  libbirch_function_("write", "birch/distribution/InverseWishart.birch", 75);
  #line 76 "birch/distribution/InverseWishart.birch"
  libbirch_line_(76);
  #line 76 "birch/distribution/InverseWishart.birch"
  this_()->prune(handler_);
  #line 77 "birch/distribution/InverseWishart.birch"
  libbirch_line_(77);
  #line 77 "birch/distribution/InverseWishart.birch"
  buffer->set(birch::type::String("class"), birch::type::String("InverseWishart"), handler_);
  #line 78 "birch/distribution/InverseWishart.birch"
  libbirch_line_(78);
  #line 78 "birch/distribution/InverseWishart.birch"
  buffer->set(birch::type::String("Ψ"), this_()->_u0936, handler_);
  #line 79 "birch/distribution/InverseWishart.birch"
  libbirch_line_(79);
  #line 79 "birch/distribution/InverseWishart.birch"
  buffer->set(birch::type::String("k"), this_()->k, handler_);
}

#line 86 "birch/distribution/InverseWishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>> birch::InverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 86 "birch/distribution/InverseWishart.birch"
  libbirch_function_("InverseWishart", "birch/distribution/InverseWishart.birch", 86);
  #line 88 "birch/distribution/InverseWishart.birch"
  libbirch_line_(88);
  #line 88 "birch/distribution/InverseWishart.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>>>(_u0936, k, handler_);
}

#line 94 "birch/distribution/InverseWishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>> birch::InverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 94 "birch/distribution/InverseWishart.birch"
  libbirch_function_("InverseWishart", "birch/distribution/InverseWishart.birch", 94);
  #line 95 "birch/distribution/InverseWishart.birch"
  libbirch_line_(95);
  #line 95 "birch/distribution/InverseWishart.birch"
  return birch::InverseWishart(_u0936, birch::box(k, handler_), handler_);
}

#line 101 "birch/distribution/InverseWishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>> birch::InverseWishart(const birch::type::LLT& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 101 "birch/distribution/InverseWishart.birch"
  libbirch_function_("InverseWishart", "birch/distribution/InverseWishart.birch", 101);
  #line 102 "birch/distribution/InverseWishart.birch"
  libbirch_line_(102);
  #line 102 "birch/distribution/InverseWishart.birch"
  return birch::InverseWishart(birch::box(_u0936, handler_), k, handler_);
}

#line 108 "birch/distribution/InverseWishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>> birch::InverseWishart(const birch::type::LLT& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 108 "birch/distribution/InverseWishart.birch"
  libbirch_function_("InverseWishart", "birch/distribution/InverseWishart.birch", 108);
  #line 109 "birch/distribution/InverseWishart.birch"
  libbirch_line_(109);
  #line 109 "birch/distribution/InverseWishart.birch"
  return birch::InverseWishart(birch::box(_u0936, handler_), birch::box(k, handler_), handler_);
}

#line 115 "birch/distribution/InverseWishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>> birch::InverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 115 "birch/distribution/InverseWishart.birch"
  libbirch_function_("InverseWishart", "birch/distribution/InverseWishart.birch", 115);
  #line 117 "birch/distribution/InverseWishart.birch"
  libbirch_line_(117);
  #line 117 "birch/distribution/InverseWishart.birch"
  return birch::InverseWishart(birch::llt(_u0936, handler_), k, handler_);
}

#line 123 "birch/distribution/InverseWishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>> birch::InverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 123 "birch/distribution/InverseWishart.birch"
  libbirch_function_("InverseWishart", "birch/distribution/InverseWishart.birch", 123);
  #line 124 "birch/distribution/InverseWishart.birch"
  libbirch_line_(124);
  #line 124 "birch/distribution/InverseWishart.birch"
  return birch::InverseWishart(birch::llt(_u0936, handler_), k, handler_);
}

#line 130 "birch/distribution/InverseWishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>> birch::InverseWishart(const libbirch::DefaultArray<birch::type::Real,2>& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 130 "birch/distribution/InverseWishart.birch"
  libbirch_function_("InverseWishart", "birch/distribution/InverseWishart.birch", 130);
  #line 131 "birch/distribution/InverseWishart.birch"
  libbirch_line_(131);
  #line 131 "birch/distribution/InverseWishart.birch"
  return birch::InverseWishart(birch::llt(_u0936, handler_), k, handler_);
}

#line 137 "birch/distribution/InverseWishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>> birch::InverseWishart(const libbirch::DefaultArray<birch::type::Real,2>& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 137 "birch/distribution/InverseWishart.birch"
  libbirch_function_("InverseWishart", "birch/distribution/InverseWishart.birch", 137);
  #line 138 "birch/distribution/InverseWishart.birch"
  libbirch_line_(138);
  #line 138 "birch/distribution/InverseWishart.birch"
  return birch::InverseWishart(birch::llt(_u0936, handler_), k, handler_);
}

#line 5 "birch/distribution/LinearBoundedDiscrete.birch"
birch::type::LinearBoundedDiscrete::LinearBoundedDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 5 "birch/distribution/LinearBoundedDiscrete.birch"
    super_type_(),
    #line 10 "birch/distribution/LinearBoundedDiscrete.birch"
    a(a),
    #line 15 "birch/distribution/LinearBoundedDiscrete.birch"
    _u0956(_u0956),
    #line 20 "birch/distribution/LinearBoundedDiscrete.birch"
    c(c) {
  //
}

#line 22 "birch/distribution/LinearBoundedDiscrete.birch"
birch::type::Boolean birch::type::LinearBoundedDiscrete::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "birch/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("supportsLazy", "birch/distribution/LinearBoundedDiscrete.birch", 22);
  #line 23 "birch/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(23);
  #line 23 "birch/distribution/LinearBoundedDiscrete.birch"
  return false;
}

#line 26 "birch/distribution/LinearBoundedDiscrete.birch"
birch::type::Integer birch::type::LinearBoundedDiscrete::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "birch/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("simulate", "birch/distribution/LinearBoundedDiscrete.birch", 26);
  #line 27 "birch/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(27);
  #line 27 "birch/distribution/LinearBoundedDiscrete.birch"
  if (this_()->value.query()) {
    #line 28 "birch/distribution/LinearBoundedDiscrete.birch"
    libbirch_line_(28);
    #line 28 "birch/distribution/LinearBoundedDiscrete.birch"
    return birch::simulate_delta(this_()->value.get(), handler_);
  } else {
    #line 30 "birch/distribution/LinearBoundedDiscrete.birch"
    libbirch_line_(30);
    #line 30 "birch/distribution/LinearBoundedDiscrete.birch"
    return birch::simulate_delta(this_()->a->value(handler_) * this_()->_u0956->simulate(handler_) + this_()->c->value(handler_), handler_);
  }
}

#line 42 "birch/distribution/LinearBoundedDiscrete.birch"
birch::type::Real birch::type::LinearBoundedDiscrete::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "birch/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("logpdf", "birch/distribution/LinearBoundedDiscrete.birch", 42);
  #line 43 "birch/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(43);
  #line 43 "birch/distribution/LinearBoundedDiscrete.birch"
  if (this_()->value.query()) {
    #line 44 "birch/distribution/LinearBoundedDiscrete.birch"
    libbirch_line_(44);
    #line 44 "birch/distribution/LinearBoundedDiscrete.birch"
    return birch::logpdf_delta(x, this_()->value.get(), handler_);
  } else {
    #line 46 "birch/distribution/LinearBoundedDiscrete.birch"
    libbirch_line_(46);
    #line 46 "birch/distribution/LinearBoundedDiscrete.birch"
    return this_()->_u0956->logpdf((x - this_()->c->value(handler_)) / this_()->a->value(handler_), handler_) - birch::log(birch::abs(birch::Real(this_()->a->value(handler_), handler_), handler_), handler_);
  }
}

#line 58 "birch/distribution/LinearBoundedDiscrete.birch"
void birch::type::LinearBoundedDiscrete::update(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "birch/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("update", "birch/distribution/LinearBoundedDiscrete.birch", 58);
  #line 59 "birch/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(59);
  #line 59 "birch/distribution/LinearBoundedDiscrete.birch"
  this_()->_u0956->clamp((x - this_()->c->value(handler_)) / this_()->a->value(handler_), handler_);
}

#line 66 "birch/distribution/LinearBoundedDiscrete.birch"
libbirch::Optional<birch::type::Real> birch::type::LinearBoundedDiscrete::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "birch/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("cdf", "birch/distribution/LinearBoundedDiscrete.birch", 66);
  #line 67 "birch/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(67);
  #line 67 "birch/distribution/LinearBoundedDiscrete.birch"
  return this_()->_u0956->cdf((x - this_()->c->value(handler_)) / this_()->a->value(handler_), handler_);
}

#line 70 "birch/distribution/LinearBoundedDiscrete.birch"
libbirch::Optional<birch::type::Integer> birch::type::LinearBoundedDiscrete::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "birch/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("lower", "birch/distribution/LinearBoundedDiscrete.birch", 70);
  #line 71 "birch/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(71);
  #line 71 "birch/distribution/LinearBoundedDiscrete.birch"
  auto a = this_()->a->value(handler_);
  #line 72 "birch/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(72);
  #line 72 "birch/distribution/LinearBoundedDiscrete.birch"
  if (a > birch::type::Integer(0)) {
    #line 73 "birch/distribution/LinearBoundedDiscrete.birch"
    libbirch_line_(73);
    #line 73 "birch/distribution/LinearBoundedDiscrete.birch"
    return a * this_()->_u0956->lower(handler_).get() + this_()->c->value(handler_);
  } else {
    #line 75 "birch/distribution/LinearBoundedDiscrete.birch"
    libbirch_line_(75);
    #line 75 "birch/distribution/LinearBoundedDiscrete.birch"
    return a * this_()->_u0956->upper(handler_).get() + this_()->c->value(handler_);
  }
}

#line 79 "birch/distribution/LinearBoundedDiscrete.birch"
libbirch::Optional<birch::type::Integer> birch::type::LinearBoundedDiscrete::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 79 "birch/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("upper", "birch/distribution/LinearBoundedDiscrete.birch", 79);
  #line 80 "birch/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(80);
  #line 80 "birch/distribution/LinearBoundedDiscrete.birch"
  auto a = this_()->a->value(handler_);
  #line 81 "birch/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(81);
  #line 81 "birch/distribution/LinearBoundedDiscrete.birch"
  if (a > birch::type::Integer(0)) {
    #line 82 "birch/distribution/LinearBoundedDiscrete.birch"
    libbirch_line_(82);
    #line 82 "birch/distribution/LinearBoundedDiscrete.birch"
    return a * this_()->_u0956->upper(handler_).get() + this_()->c->value(handler_);
  } else {
    #line 84 "birch/distribution/LinearBoundedDiscrete.birch"
    libbirch_line_(84);
    #line 84 "birch/distribution/LinearBoundedDiscrete.birch"
    return a * this_()->_u0956->lower(handler_).get() + this_()->c->value(handler_);
  }
}

#line 88 "birch/distribution/LinearBoundedDiscrete.birch"
void birch::type::LinearBoundedDiscrete::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 88 "birch/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("link", "birch/distribution/LinearBoundedDiscrete.birch", 88);
}

#line 93 "birch/distribution/LinearBoundedDiscrete.birch"
void birch::type::LinearBoundedDiscrete::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 93 "birch/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("unlink", "birch/distribution/LinearBoundedDiscrete.birch", 93);
}

#line 99 "birch/distribution/LinearBoundedDiscrete.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LinearBoundedDiscrete>> birch::LinearBoundedDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 99 "birch/distribution/LinearBoundedDiscrete.birch"
  libbirch_function_("LinearBoundedDiscrete", "birch/distribution/LinearBoundedDiscrete.birch", 99);
  #line 101 "birch/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(101);
  #line 101 "birch/distribution/LinearBoundedDiscrete.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::LinearBoundedDiscrete>> m(a, _u0956, c);
  #line 102 "birch/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(102);
  #line 102 "birch/distribution/LinearBoundedDiscrete.birch"
  m->link(handler_);
  #line 103 "birch/distribution/LinearBoundedDiscrete.birch"
  libbirch_line_(103);
  #line 103 "birch/distribution/LinearBoundedDiscrete.birch"
  return m;
}

#line 5 "birch/distribution/LinearDiscrete.birch"
birch::type::LinearDiscrete::LinearDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 5 "birch/distribution/LinearDiscrete.birch"
    super_type_(),
    #line 10 "birch/distribution/LinearDiscrete.birch"
    a(a),
    #line 15 "birch/distribution/LinearDiscrete.birch"
    _u0956(_u0956),
    #line 20 "birch/distribution/LinearDiscrete.birch"
    c(c) {
  //
}

#line 22 "birch/distribution/LinearDiscrete.birch"
birch::type::Boolean birch::type::LinearDiscrete::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "birch/distribution/LinearDiscrete.birch"
  libbirch_function_("supportsLazy", "birch/distribution/LinearDiscrete.birch", 22);
  #line 23 "birch/distribution/LinearDiscrete.birch"
  libbirch_line_(23);
  #line 23 "birch/distribution/LinearDiscrete.birch"
  return false;
}

#line 26 "birch/distribution/LinearDiscrete.birch"
birch::type::Integer birch::type::LinearDiscrete::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "birch/distribution/LinearDiscrete.birch"
  libbirch_function_("simulate", "birch/distribution/LinearDiscrete.birch", 26);
  #line 27 "birch/distribution/LinearDiscrete.birch"
  libbirch_line_(27);
  #line 27 "birch/distribution/LinearDiscrete.birch"
  if (this_()->value.query()) {
    #line 28 "birch/distribution/LinearDiscrete.birch"
    libbirch_line_(28);
    #line 28 "birch/distribution/LinearDiscrete.birch"
    return birch::simulate_delta(this_()->value.get(), handler_);
  } else {
    #line 30 "birch/distribution/LinearDiscrete.birch"
    libbirch_line_(30);
    #line 30 "birch/distribution/LinearDiscrete.birch"
    return birch::simulate_delta(this_()->a->value(handler_) * this_()->_u0956->simulate(handler_) + this_()->c->value(handler_), handler_);
  }
}

#line 42 "birch/distribution/LinearDiscrete.birch"
birch::type::Real birch::type::LinearDiscrete::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "birch/distribution/LinearDiscrete.birch"
  libbirch_function_("logpdf", "birch/distribution/LinearDiscrete.birch", 42);
  #line 43 "birch/distribution/LinearDiscrete.birch"
  libbirch_line_(43);
  #line 43 "birch/distribution/LinearDiscrete.birch"
  if (this_()->value.query()) {
    #line 44 "birch/distribution/LinearDiscrete.birch"
    libbirch_line_(44);
    #line 44 "birch/distribution/LinearDiscrete.birch"
    return birch::logpdf_delta(x, this_()->value.get(), handler_);
  } else {
    #line 46 "birch/distribution/LinearDiscrete.birch"
    libbirch_line_(46);
    #line 46 "birch/distribution/LinearDiscrete.birch"
    return this_()->_u0956->logpdf((x - this_()->c->value(handler_)) / this_()->a->value(handler_), handler_) - birch::log(birch::abs(birch::Real(this_()->a->value(handler_), handler_), handler_), handler_);
  }
}

#line 58 "birch/distribution/LinearDiscrete.birch"
void birch::type::LinearDiscrete::update(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "birch/distribution/LinearDiscrete.birch"
  libbirch_function_("update", "birch/distribution/LinearDiscrete.birch", 58);
  #line 59 "birch/distribution/LinearDiscrete.birch"
  libbirch_line_(59);
  #line 59 "birch/distribution/LinearDiscrete.birch"
  this_()->_u0956->clamp((x - this_()->c->value(handler_)) / this_()->a->value(handler_), handler_);
}

#line 66 "birch/distribution/LinearDiscrete.birch"
libbirch::Optional<birch::type::Real> birch::type::LinearDiscrete::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "birch/distribution/LinearDiscrete.birch"
  libbirch_function_("cdf", "birch/distribution/LinearDiscrete.birch", 66);
  #line 67 "birch/distribution/LinearDiscrete.birch"
  libbirch_line_(67);
  #line 67 "birch/distribution/LinearDiscrete.birch"
  return this_()->_u0956->cdf((x - this_()->c->value(handler_)) / this_()->a->value(handler_), handler_);
}

#line 70 "birch/distribution/LinearDiscrete.birch"
libbirch::Optional<birch::type::Integer> birch::type::LinearDiscrete::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "birch/distribution/LinearDiscrete.birch"
  libbirch_function_("lower", "birch/distribution/LinearDiscrete.birch", 70);
  #line 71 "birch/distribution/LinearDiscrete.birch"
  libbirch_line_(71);
  #line 71 "birch/distribution/LinearDiscrete.birch"
  auto l = this_()->_u0956->lower(handler_);
  #line 72 "birch/distribution/LinearDiscrete.birch"
  libbirch_line_(72);
  #line 72 "birch/distribution/LinearDiscrete.birch"
  if (l.query()) {
    #line 73 "birch/distribution/LinearDiscrete.birch"
    libbirch_line_(73);
    #line 73 "birch/distribution/LinearDiscrete.birch"
    l = this_()->a->value(handler_) * l.get() + this_()->c->value(handler_);
  }
  #line 75 "birch/distribution/LinearDiscrete.birch"
  libbirch_line_(75);
  #line 75 "birch/distribution/LinearDiscrete.birch"
  return l;
}

#line 78 "birch/distribution/LinearDiscrete.birch"
libbirch::Optional<birch::type::Integer> birch::type::LinearDiscrete::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 78 "birch/distribution/LinearDiscrete.birch"
  libbirch_function_("upper", "birch/distribution/LinearDiscrete.birch", 78);
  #line 79 "birch/distribution/LinearDiscrete.birch"
  libbirch_line_(79);
  #line 79 "birch/distribution/LinearDiscrete.birch"
  auto u = this_()->_u0956->upper(handler_);
  #line 80 "birch/distribution/LinearDiscrete.birch"
  libbirch_line_(80);
  #line 80 "birch/distribution/LinearDiscrete.birch"
  if (u.query()) {
    #line 81 "birch/distribution/LinearDiscrete.birch"
    libbirch_line_(81);
    #line 81 "birch/distribution/LinearDiscrete.birch"
    u = this_()->a->value(handler_) * u.get() + this_()->c->value(handler_);
  }
  #line 83 "birch/distribution/LinearDiscrete.birch"
  libbirch_line_(83);
  #line 83 "birch/distribution/LinearDiscrete.birch"
  return u;
}

#line 86 "birch/distribution/LinearDiscrete.birch"
void birch::type::LinearDiscrete::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 86 "birch/distribution/LinearDiscrete.birch"
  libbirch_function_("link", "birch/distribution/LinearDiscrete.birch", 86);
}

#line 91 "birch/distribution/LinearDiscrete.birch"
void birch::type::LinearDiscrete::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 91 "birch/distribution/LinearDiscrete.birch"
  libbirch_function_("unlink", "birch/distribution/LinearDiscrete.birch", 91);
}

#line 97 "birch/distribution/LinearDiscrete.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LinearDiscrete>> birch::LinearDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Discrete>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 97 "birch/distribution/LinearDiscrete.birch"
  libbirch_function_("LinearDiscrete", "birch/distribution/LinearDiscrete.birch", 97);
  #line 99 "birch/distribution/LinearDiscrete.birch"
  libbirch_line_(99);
  #line 99 "birch/distribution/LinearDiscrete.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::LinearDiscrete>> m(a, _u0956, c);
  #line 100 "birch/distribution/LinearDiscrete.birch"
  libbirch_line_(100);
  #line 100 "birch/distribution/LinearDiscrete.birch"
  m->link(handler_);
  #line 101 "birch/distribution/LinearDiscrete.birch"
  libbirch_line_(101);
  #line 101 "birch/distribution/LinearDiscrete.birch"
  return m;
}

#line 4 "birch/distribution/LinearGaussianGaussian.birch"
birch::type::LinearGaussianGaussian::LinearGaussianGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>& m, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& s2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/LinearGaussianGaussian.birch"
    super_type_(a * m->_u0956 + c, a * a * m->_u09632 + s2),
    #line 10 "birch/distribution/LinearGaussianGaussian.birch"
    a(a),
    #line 15 "birch/distribution/LinearGaussianGaussian.birch"
    m(m),
    #line 20 "birch/distribution/LinearGaussianGaussian.birch"
    c(c),
    #line 25 "birch/distribution/LinearGaussianGaussian.birch"
    s2(s2) {
  //
}

#line 27 "birch/distribution/LinearGaussianGaussian.birch"
void birch::type::LinearGaussianGaussian::update(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "birch/distribution/LinearGaussianGaussian.birch"
  libbirch_function_("update", "birch/distribution/LinearGaussianGaussian.birch", 27);
  #line 28 "birch/distribution/LinearGaussianGaussian.birch"
  libbirch_line_(28);
  #line 28 "birch/distribution/LinearGaussianGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u09632) = birch::box(birch::update_linear_gaussian_gaussian(x, this_()->a->value(handler_), this_()->m->_u0956->value(handler_), this_()->m->_u09632->value(handler_), this_()->c->value(handler_), this_()->s2->value(handler_), handler_), handler_);
}

#line 31 "birch/distribution/LinearGaussianGaussian.birch"
void birch::type::LinearGaussianGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "birch/distribution/LinearGaussianGaussian.birch"
  libbirch_function_("updateLazy", "birch/distribution/LinearGaussianGaussian.birch", 31);
  #line 32 "birch/distribution/LinearGaussianGaussian.birch"
  libbirch_line_(32);
  #line 32 "birch/distribution/LinearGaussianGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u09632) = birch::update_lazy_linear_gaussian_gaussian(x, this_()->a, this_()->m->_u0956, this_()->m->_u09632, this_()->c, this_()->s2, handler_);
}

#line 35 "birch/distribution/LinearGaussianGaussian.birch"
void birch::type::LinearGaussianGaussian::downdate(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "birch/distribution/LinearGaussianGaussian.birch"
  libbirch_function_("downdate", "birch/distribution/LinearGaussianGaussian.birch", 35);
  #line 36 "birch/distribution/LinearGaussianGaussian.birch"
  libbirch_line_(36);
  #line 36 "birch/distribution/LinearGaussianGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u09632) = birch::box(birch::downdate_linear_gaussian_gaussian(x, this_()->a->value(handler_), this_()->m->_u0956->value(handler_), this_()->m->_u09632->value(handler_), this_()->c->value(handler_), this_()->s2->value(handler_), handler_), handler_);
}

#line 39 "birch/distribution/LinearGaussianGaussian.birch"
void birch::type::LinearGaussianGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "birch/distribution/LinearGaussianGaussian.birch"
  libbirch_function_("link", "birch/distribution/LinearGaussianGaussian.birch", 39);
  #line 40 "birch/distribution/LinearGaussianGaussian.birch"
  libbirch_line_(40);
  #line 40 "birch/distribution/LinearGaussianGaussian.birch"
  this_()->m->setChild(shared_from_this_(), handler_);
}

#line 43 "birch/distribution/LinearGaussianGaussian.birch"
void birch::type::LinearGaussianGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "birch/distribution/LinearGaussianGaussian.birch"
  libbirch_function_("unlink", "birch/distribution/LinearGaussianGaussian.birch", 43);
  #line 44 "birch/distribution/LinearGaussianGaussian.birch"
  libbirch_line_(44);
  #line 44 "birch/distribution/LinearGaussianGaussian.birch"
  this_()->m->releaseChild(shared_from_this_(), handler_);
}

#line 48 "birch/distribution/LinearGaussianGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LinearGaussianGaussian>> birch::LinearGaussianGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "birch/distribution/LinearGaussianGaussian.birch"
  libbirch_function_("LinearGaussianGaussian", "birch/distribution/LinearGaussianGaussian.birch", 48);
  #line 50 "birch/distribution/LinearGaussianGaussian.birch"
  libbirch_line_(50);
  #line 50 "birch/distribution/LinearGaussianGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::LinearGaussianGaussian>> m(a, _u0956, c, _u09632);
  #line 51 "birch/distribution/LinearGaussianGaussian.birch"
  libbirch_line_(51);
  #line 51 "birch/distribution/LinearGaussianGaussian.birch"
  m->link(handler_);
  #line 52 "birch/distribution/LinearGaussianGaussian.birch"
  libbirch_line_(52);
  #line 52 "birch/distribution/LinearGaussianGaussian.birch"
  return m;
}

#line 5 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::LinearMatrixNormalInverseGammaMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& A, const libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& C, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 5 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
    super_type_(),
    #line 11 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
    A(A),
    #line 16 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
    M(M),
    #line 21 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
    C(C) {
  //
}

#line 23 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::Integer birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("rows", "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 23);
  #line 24 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(24);
  #line 24 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return this_()->C->rows(handler_);
}

#line 27 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::Integer birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::columns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("columns", "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 27);
  #line 28 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(28);
  #line 28 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return this_()->C->columns(handler_);
}

#line 31 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::Boolean birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("supportsLazy", "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 31);
  #line 32 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(32);
  #line 32 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return true;
}

#line 35 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("simulate", "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 35);
  #line 36 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(36);
  #line 36 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return birch::simulate_linear_matrix_normal_inverse_gamma_matrix_gaussian(this_()->A->value(handler_), this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->C->value(handler_), this_()->M->_u0945->value(handler_), this_()->M->_u0947->value(handler_), handler_);
}

#line 40 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("simulateLazy", "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 40);
  #line 41 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(41);
  #line 41 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return birch::simulate_linear_matrix_normal_inverse_gamma_matrix_gaussian(this_()->A->get(handler_), this_()->M->N->get(handler_), this_()->M->_u0923->get(handler_), this_()->C->get(handler_), this_()->M->_u0945->get(handler_), this_()->M->_u0947->get(handler_), handler_);
}

#line 45 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::Real birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("logpdf", "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 45);
  #line 46 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(46);
  #line 46 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return birch::logpdf_linear_matrix_normal_inverse_gamma_matrix_gaussian(X, this_()->A->value(handler_), this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->C->value(handler_), this_()->M->_u0945->value(handler_), this_()->M->_u0947->value(handler_), handler_);
}

#line 50 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 50);
  #line 51 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(51);
  #line 51 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return birch::logpdf_lazy_linear_matrix_normal_inverse_gamma_matrix_gaussian(X, this_()->A, this_()->M->N, this_()->M->_u0923, this_()->C, this_()->M->_u0945, this_()->M->_u0947, handler_);
}

#line 55 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
void birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::update(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 55 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("update", "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 55);
  #line 56 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(56);
  #line 56 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::tie(this_()->M->N, this_()->M->_u0923, this_()->M->_u0945, this_()->M->_u0947) = birch::box(birch::update_linear_matrix_normal_inverse_gamma_matrix_gaussian(X, this_()->A->value(handler_), this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->C->value(handler_), this_()->M->_u0945->value(handler_), this_()->M->_u0947->value(handler_), handler_), handler_);
}

#line 60 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
void birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("updateLazy", "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 60);
  #line 61 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(61);
  #line 61 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::tie(this_()->M->N, this_()->M->_u0923, this_()->M->_u0945, this_()->M->_u0947) = birch::update_lazy_linear_matrix_normal_inverse_gamma_matrix_gaussian(X, this_()->A, this_()->M->N, this_()->M->_u0923, this_()->C, this_()->M->_u0945, this_()->M->_u0947, handler_);
}

#line 65 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
void birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::downdate(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("downdate", "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 65);
  #line 66 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(66);
  #line 66 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::tie(this_()->M->N, this_()->M->_u0923, this_()->M->_u0945, this_()->M->_u0947) = birch::box(birch::downdate_linear_matrix_normal_inverse_gamma_matrix_gaussian(X, this_()->A->value(handler_), this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->C->value(handler_), this_()->M->_u0945->value(handler_), this_()->M->_u0947->value(handler_), handler_), handler_);
}

#line 70 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
void birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("link", "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 70);
  #line 71 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(71);
  #line 71 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->M->setChild(shared_from_this_(), handler_);
}

#line 74 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
void birch::type::LinearMatrixNormalInverseGammaMatrixGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 74 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("unlink", "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 74);
  #line 75 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(75);
  #line 75 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->M->releaseChild(shared_from_this_(), handler_);
}

#line 79 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LinearMatrixNormalInverseGammaMatrixGaussian>> birch::LinearMatrixNormalInverseGammaMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& A, const libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& C, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 79 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("LinearMatrixNormalInverseGammaMatrixGaussian", "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch", 79);
  #line 82 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(82);
  #line 82 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::LinearMatrixNormalInverseGammaMatrixGaussian>> m(A, M, C);
  #line 83 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(83);
  #line 83 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  m->link(handler_);
  #line 84 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(84);
  #line 84 "birch/distribution/LinearMatrixNormalInverseGammaMatrixGaussian.birch"
  return m;
}

#line 5 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::LinearMatrixNormalInverseWishartMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& A, const libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& C, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 5 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
    super_type_(),
    #line 11 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
    A(A),
    #line 16 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
    M(M),
    #line 21 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
    C(C) {
  //
}

#line 23 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Integer birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("rows", "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 23);
  #line 24 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(24);
  #line 24 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return this_()->C->rows(handler_);
}

#line 27 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Integer birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::columns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("columns", "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 27);
  #line 28 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(28);
  #line 28 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return this_()->C->columns(handler_);
}

#line 31 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Boolean birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("supportsLazy", "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 31);
  #line 32 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(32);
  #line 32 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return true;
}

#line 35 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("simulate", "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 35);
  #line 36 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(36);
  #line 36 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return birch::simulate_linear_matrix_normal_inverse_wishart_matrix_gaussian(this_()->A->value(handler_), this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->C->value(handler_), this_()->M->V->_u0936->value(handler_), this_()->M->V->k->value(handler_), handler_);
}

#line 40 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("simulateLazy", "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 40);
  #line 41 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(41);
  #line 41 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return birch::simulate_linear_matrix_normal_inverse_wishart_matrix_gaussian(this_()->A->get(handler_), this_()->M->N->get(handler_), this_()->M->_u0923->get(handler_), this_()->C->get(handler_), this_()->M->V->_u0936->get(handler_), this_()->M->V->k->get(handler_), handler_);
}

#line 45 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Real birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("logpdf", "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 45);
  #line 46 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(46);
  #line 46 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return birch::logpdf_linear_matrix_normal_inverse_wishart_matrix_gaussian(X, this_()->A->value(handler_), this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->C->value(handler_), this_()->M->V->_u0936->value(handler_), this_()->M->V->k->value(handler_), handler_);
}

#line 50 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 50);
  #line 51 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(51);
  #line 51 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return birch::logpdf_lazy_linear_matrix_normal_inverse_wishart_matrix_gaussian(X, this_()->A, this_()->M->N, this_()->M->_u0923, this_()->C, this_()->M->V->_u0936, this_()->M->V->k, handler_);
}

#line 55 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::update(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 55 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("update", "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 55);
  #line 56 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(56);
  #line 56 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::tie(this_()->M->N, this_()->M->_u0923, this_()->M->V->_u0936, this_()->M->V->k) = birch::box(birch::update_linear_matrix_normal_inverse_wishart_matrix_gaussian(X, this_()->A->value(handler_), this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->C->value(handler_), this_()->M->V->_u0936->value(handler_), this_()->M->V->k->value(handler_), handler_), handler_);
}

#line 60 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("updateLazy", "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 60);
  #line 61 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(61);
  #line 61 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::tie(this_()->M->N, this_()->M->_u0923, this_()->M->V->_u0936, this_()->M->V->k) = birch::update_lazy_linear_matrix_normal_inverse_wishart_matrix_gaussian(X, this_()->A, this_()->M->N, this_()->M->_u0923, this_()->C, this_()->M->V->_u0936, this_()->M->V->k, handler_);
}

#line 65 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::downdate(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("downdate", "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 65);
  #line 66 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(66);
  #line 66 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::tie(this_()->M->N, this_()->M->_u0923, this_()->M->V->_u0936, this_()->M->V->k) = birch::box(birch::downdate_linear_matrix_normal_inverse_wishart_matrix_gaussian(X, this_()->A->value(handler_), this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->C->value(handler_), this_()->M->V->_u0936->value(handler_), this_()->M->V->k->value(handler_), handler_), handler_);
}

#line 70 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("link", "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 70);
  #line 71 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(71);
  #line 71 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->M->setChild(shared_from_this_(), handler_);
}

#line 74 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::LinearMatrixNormalInverseWishartMatrixGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 74 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("unlink", "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 74);
  #line 75 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(75);
  #line 75 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->M->releaseChild(shared_from_this_(), handler_);
}

#line 79 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LinearMatrixNormalInverseWishartMatrixGaussian>> birch::LinearMatrixNormalInverseWishartMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& A, const libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& C, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 79 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("LinearMatrixNormalInverseWishartMatrixGaussian", "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch", 79);
  #line 82 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(82);
  #line 82 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::LinearMatrixNormalInverseWishartMatrixGaussian>> m(A, M, C);
  #line 83 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(83);
  #line 83 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  m->link(handler_);
  #line 84 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(84);
  #line 84 "birch/distribution/LinearMatrixNormalInverseWishartMatrixGaussian.birch"
  return m;
}

#line 4 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
birch::type::LinearMultivariateGaussianGaussian::LinearMultivariateGaussianGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>& m, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& s2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
    super_type_(birch::dot(a, m->_u0956, handler_) + c, birch::dot(a, birch::canonical(m->_u0931, handler_) * a, handler_) + s2),
    #line 10 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
    a(a),
    #line 15 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
    m(m),
    #line 20 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
    c(c),
    #line 25 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
    s2(s2) {
  //
}

#line 27 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
void birch::type::LinearMultivariateGaussianGaussian::update(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_function_("update", "birch/distribution/LinearMultivariateGaussianGaussian.birch", 27);
  #line 28 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_line_(28);
  #line 28 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u0931) = birch::box(birch::update_linear_multivariate_gaussian_gaussian(x, this_()->a->value(handler_), this_()->m->_u0956->value(handler_), this_()->m->_u0931->value(handler_), this_()->c->value(handler_), this_()->s2->value(handler_), handler_), handler_);
}

#line 32 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
void birch::type::LinearMultivariateGaussianGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_function_("updateLazy", "birch/distribution/LinearMultivariateGaussianGaussian.birch", 32);
  #line 33 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_line_(33);
  #line 33 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u0931) = birch::update_lazy_linear_multivariate_gaussian_gaussian(x, this_()->a, this_()->m->_u0956, this_()->m->_u0931, this_()->c, this_()->s2, handler_);
}

#line 37 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
void birch::type::LinearMultivariateGaussianGaussian::downdate(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_function_("downdate", "birch/distribution/LinearMultivariateGaussianGaussian.birch", 37);
  #line 38 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_line_(38);
  #line 38 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u0931) = birch::box(birch::downdate_linear_multivariate_gaussian_gaussian(x, this_()->a->value(handler_), this_()->m->_u0956->value(handler_), this_()->m->_u0931->value(handler_), this_()->c->value(handler_), this_()->s2->value(handler_), handler_), handler_);
}

#line 42 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
void birch::type::LinearMultivariateGaussianGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_function_("link", "birch/distribution/LinearMultivariateGaussianGaussian.birch", 42);
  #line 43 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_line_(43);
  #line 43 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
  this_()->m->setChild(shared_from_this_(), handler_);
}

#line 46 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
void birch::type::LinearMultivariateGaussianGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_function_("unlink", "birch/distribution/LinearMultivariateGaussianGaussian.birch", 46);
  #line 47 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_line_(47);
  #line 47 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
  this_()->m->releaseChild(shared_from_this_(), handler_);
}

#line 51 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LinearMultivariateGaussianGaussian>> birch::LinearMultivariateGaussianGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 51 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_function_("LinearMultivariateGaussianGaussian", "birch/distribution/LinearMultivariateGaussianGaussian.birch", 51);
  #line 54 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_line_(54);
  #line 54 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::LinearMultivariateGaussianGaussian>> m(a, _u0956, c, _u09632);
  #line 55 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_line_(55);
  #line 55 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
  m->link(handler_);
  #line 56 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
  libbirch_line_(56);
  #line 56 "birch/distribution/LinearMultivariateGaussianGaussian.birch"
  return m;
}

#line 4 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
birch::type::LinearMultivariateGaussianMultivariateGaussian::LinearMultivariateGaussianMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& A, const libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>& m, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& S, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
    super_type_(A * m->_u0956 + c, birch::llt(A * birch::canonical(m->_u0931, handler_) * birch::transpose(A, handler_) + birch::canonical(S, handler_), handler_)),
    #line 11 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
    A(A),
    #line 16 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
    m(m),
    #line 21 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
    c(c),
    #line 26 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
    S(S) {
  //
}

#line 28 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
void birch::type::LinearMultivariateGaussianMultivariateGaussian::update(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("update", "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch", 28);
  #line 29 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(29);
  #line 29 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u0931) = birch::box(birch::update_linear_multivariate_gaussian_multivariate_gaussian(x, this_()->A->value(handler_), this_()->m->_u0956->value(handler_), this_()->m->_u0931->value(handler_), this_()->c->value(handler_), this_()->S->value(handler_), handler_), handler_);
}

#line 33 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
void birch::type::LinearMultivariateGaussianMultivariateGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("updateLazy", "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch", 33);
  #line 34 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(34);
  #line 34 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u0931) = birch::update_lazy_linear_multivariate_gaussian_multivariate_gaussian(x, this_()->A, this_()->m->_u0956, this_()->m->_u0931, this_()->c, this_()->S, handler_);
}

#line 38 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
void birch::type::LinearMultivariateGaussianMultivariateGaussian::downdate(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("downdate", "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch", 38);
  #line 39 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(39);
  #line 39 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u0931) = birch::box(birch::downdate_linear_multivariate_gaussian_multivariate_gaussian(x, this_()->A->value(handler_), this_()->m->_u0956->value(handler_), this_()->m->_u0931->value(handler_), this_()->c->value(handler_), this_()->S->value(handler_), handler_), handler_);
}

#line 43 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
void birch::type::LinearMultivariateGaussianMultivariateGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("link", "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch", 43);
  #line 44 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(44);
  #line 44 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  this_()->m->setChild(shared_from_this_(), handler_);
}

#line 47 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
void birch::type::LinearMultivariateGaussianMultivariateGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("unlink", "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch", 47);
  #line 48 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(48);
  #line 48 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  this_()->m->releaseChild(shared_from_this_(), handler_);
}

#line 52 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LinearMultivariateGaussianMultivariateGaussian>> birch::LinearMultivariateGaussianMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& A, const libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("LinearMultivariateGaussianMultivariateGaussian", "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch", 52);
  #line 56 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(56);
  #line 56 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::LinearMultivariateGaussianMultivariateGaussian>> m(A, _u0956, c, _u0931);
  #line 57 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(57);
  #line 57 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  m->link(handler_);
  #line 58 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(58);
  #line 58 "birch/distribution/LinearMultivariateGaussianMultivariateGaussian.birch"
  return m;
}

#line 4 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
birch::type::LinearMultivariateNormalInverseGammaGaussian::LinearMultivariateNormalInverseGammaGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
    super_type_(),
    #line 10 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
    a(a),
    #line 15 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
    _u0956(_u0956),
    #line 20 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
    c(c) {
  //
}

#line 22 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
birch::type::Integer birch::type::LinearMultivariateNormalInverseGammaGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("rows", "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 22);
  #line 23 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(23);
  #line 23 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return this_()->c->rows(handler_);
}

#line 26 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
birch::type::Boolean birch::type::LinearMultivariateNormalInverseGammaGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("supportsLazy", "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 26);
  #line 27 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(27);
  #line 27 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return true;
}

#line 30 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
birch::type::Real birch::type::LinearMultivariateNormalInverseGammaGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("simulate", "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 30);
  #line 31 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(31);
  #line 31 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return birch::simulate_linear_multivariate_normal_inverse_gamma_gaussian(this_()->a->value(handler_), this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_);
}

#line 36 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::LinearMultivariateNormalInverseGammaGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("simulateLazy", "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 36);
  #line 37 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(37);
  #line 37 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return birch::simulate_linear_multivariate_normal_inverse_gamma_gaussian(this_()->a->get(handler_), this_()->_u0956->_u0957->get(handler_), this_()->_u0956->_u0923->get(handler_), this_()->c->get(handler_), this_()->_u0956->_u0945->get(handler_), this_()->_u0956->_u0947->get(handler_), handler_);
}

#line 42 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
birch::type::Real birch::type::LinearMultivariateNormalInverseGammaGaussian::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("logpdf", "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 42);
  #line 43 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(43);
  #line 43 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return birch::logpdf_linear_multivariate_normal_inverse_gamma_gaussian(x, this_()->a->value(handler_), this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_);
}

#line 48 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::LinearMultivariateNormalInverseGammaGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 48);
  #line 49 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(49);
  #line 49 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return birch::logpdf_lazy_linear_multivariate_normal_inverse_gamma_gaussian(x, this_()->a, this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->c, this_()->_u0956->_u0945, this_()->_u0956->_u0947, handler_);
}

#line 53 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaGaussian::update(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("update", "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 53);
  #line 54 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(54);
  #line 54 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->_u0956->_u0945, this_()->_u0956->_u0947) = birch::box(birch::update_linear_multivariate_normal_inverse_gamma_gaussian(x, this_()->a->value(handler_), this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_), handler_);
}

#line 59 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("updateLazy", "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 59);
  #line 60 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(60);
  #line 60 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->_u0956->_u0945, this_()->_u0956->_u0947) = birch::update_lazy_linear_multivariate_normal_inverse_gamma_gaussian(x, this_()->a, this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->c, this_()->_u0956->_u0945, this_()->_u0956->_u0947, handler_);
}

#line 64 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaGaussian::downdate(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("downdate", "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 64);
  #line 65 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(65);
  #line 65 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->_u0956->_u0945, this_()->_u0956->_u0947) = birch::box(birch::downdate_linear_multivariate_normal_inverse_gamma_gaussian(x, this_()->a->value(handler_), this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_), handler_);
}

#line 70 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::LinearMultivariateNormalInverseGammaGaussian::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("cdf", "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 70);
  #line 71 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(71);
  #line 71 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return birch::cdf_linear_multivariate_normal_inverse_gamma_gaussian(x, this_()->a->value(handler_), this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_);
}

#line 76 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::LinearMultivariateNormalInverseGammaGaussian::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("quantile", "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 76);
  #line 77 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(77);
  #line 77 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return birch::quantile_linear_multivariate_normal_inverse_gamma_gaussian(P, this_()->a->value(handler_), this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_);
}

#line 82 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 82 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("link", "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 82);
  #line 83 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(83);
  #line 83 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  this_()->_u0956->setChild(shared_from_this_(), handler_);
}

#line 86 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 86 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("unlink", "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 86);
  #line 87 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(87);
  #line 87 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  this_()->_u0956->releaseChild(shared_from_this_(), handler_);
}

#line 91 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LinearMultivariateNormalInverseGammaGaussian>> birch::LinearMultivariateNormalInverseGammaGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 91 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_function_("LinearMultivariateNormalInverseGammaGaussian", "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch", 91);
  #line 94 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(94);
  #line 94 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::LinearMultivariateNormalInverseGammaGaussian>> m(a, _u0956, c);
  #line 95 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(95);
  #line 95 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  m->link(handler_);
  #line 96 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  libbirch_line_(96);
  #line 96 "birch/distribution/LinearMultivariateNormalInverseGammaGaussian.birch"
  return m;
}

#line 5 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::LinearMultivariateNormalInverseGammaMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& A, const libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 5 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    super_type_(),
    #line 11 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    A(A),
    #line 16 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    _u0956(_u0956),
    #line 21 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
    c(c) {
  //
}

#line 23 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::Integer birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("rows", "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 23);
  #line 24 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(24);
  #line 24 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return this_()->c->rows(handler_);
}

#line 27 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::Boolean birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("supportsLazy", "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 27);
  #line 28 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(28);
  #line 28 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return true;
}

#line 31 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("simulate", "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 31);
  #line 32 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(32);
  #line 32 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return birch::simulate_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(this_()->A->value(handler_), this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_);
}

#line 36 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("simulateLazy", "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 36);
  #line 37 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(37);
  #line 37 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return birch::simulate_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(this_()->A->get(handler_), this_()->_u0956->_u0957->get(handler_), this_()->_u0956->_u0923->get(handler_), this_()->c->get(handler_), this_()->_u0956->_u0945->get(handler_), this_()->_u0956->_u0947->get(handler_), handler_);
}

#line 41 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::Real birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("logpdf", "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 41);
  #line 42 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(42);
  #line 42 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return birch::logpdf_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this_()->A->value(handler_), this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_);
}

#line 46 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 46);
  #line 47 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(47);
  #line 47 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return birch::logpdf_lazy_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this_()->A, this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->c, this_()->_u0956->_u0945, this_()->_u0956->_u0947, handler_);
}

#line 51 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::update(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 51 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("update", "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 51);
  #line 52 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(52);
  #line 52 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->_u0956->_u0945, this_()->_u0956->_u0947) = birch::box(birch::update_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this_()->A->value(handler_), this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_), handler_);
}

#line 56 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 56 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("updateLazy", "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 56);
  #line 57 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(57);
  #line 57 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->_u0956->_u0945, this_()->_u0956->_u0947) = birch::update_lazy_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this_()->A, this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->c, this_()->_u0956->_u0945, this_()->_u0956->_u0947, handler_);
}

#line 61 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::downdate(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("downdate", "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 61);
  #line 62 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(62);
  #line 62 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->_u0956->_u0945, this_()->_u0956->_u0947) = birch::box(birch::downdate_linear_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this_()->A->value(handler_), this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_), handler_);
}

#line 66 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("link", "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 66);
  #line 67 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(67);
  #line 67 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  this_()->_u0956->setChild(shared_from_this_(), handler_);
}

#line 70 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("unlink", "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 70);
  #line 71 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(71);
  #line 71 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  this_()->_u0956->releaseChild(shared_from_this_(), handler_);
}

#line 75 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian>> birch::LinearMultivariateNormalInverseGammaMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& A, const libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 75 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("LinearMultivariateNormalInverseGammaMultivariateGaussian", "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch", 75);
  #line 79 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(79);
  #line 79 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::LinearMultivariateNormalInverseGammaMultivariateGaussian>> m(A, _u0956, c);
  #line 80 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(80);
  #line 80 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  m->link(handler_);
  #line 81 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(81);
  #line 81 "birch/distribution/LinearMultivariateNormalInverseGammaMultivariateGaussian.birch"
  return m;
}

#line 4 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
birch::type::LinearNormalInverseGammaGaussian::LinearNormalInverseGammaGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
    super_type_(),
    #line 9 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
    a(a),
    #line 14 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
    _u0956(_u0956),
    #line 19 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
    c(c) {
  //
}

#line 21 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
birch::type::Boolean birch::type::LinearNormalInverseGammaGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("supportsLazy", "birch/distribution/LinearNormalInverseGammaGaussian.birch", 21);
  #line 22 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(22);
  #line 22 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  return true;
}

#line 25 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
birch::type::Real birch::type::LinearNormalInverseGammaGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("simulate", "birch/distribution/LinearNormalInverseGammaGaussian.birch", 25);
  #line 26 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(26);
  #line 26 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  return birch::simulate_linear_normal_inverse_gamma_gaussian(this_()->a->value(handler_), this_()->_u0956->_u0956->value(handler_), 1.0 / this_()->_u0956->_u0955->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u09632->_u0945->value(handler_), this_()->_u0956->_u09632->_u0946->value(handler_), handler_);
}

#line 31 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::LinearNormalInverseGammaGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("simulateLazy", "birch/distribution/LinearNormalInverseGammaGaussian.birch", 31);
  #line 32 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(32);
  #line 32 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  return birch::simulate_linear_normal_inverse_gamma_gaussian(this_()->a->get(handler_), this_()->_u0956->_u0956->get(handler_), 1.0 / this_()->_u0956->_u0955->get(handler_), this_()->c->get(handler_), this_()->_u0956->_u09632->_u0945->get(handler_), this_()->_u0956->_u09632->_u0946->get(handler_), handler_);
}

#line 36 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
birch::type::Real birch::type::LinearNormalInverseGammaGaussian::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("logpdf", "birch/distribution/LinearNormalInverseGammaGaussian.birch", 36);
  #line 37 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(37);
  #line 37 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  return birch::logpdf_linear_normal_inverse_gamma_gaussian(x, this_()->a->value(handler_), this_()->_u0956->_u0956->value(handler_), 1.0 / this_()->_u0956->_u0955->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u09632->_u0945->value(handler_), this_()->_u0956->_u09632->_u0946->value(handler_), handler_);
}

#line 42 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::LinearNormalInverseGammaGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/LinearNormalInverseGammaGaussian.birch", 42);
  #line 43 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(43);
  #line 43 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  return birch::logpdf_lazy_linear_normal_inverse_gamma_gaussian(x, this_()->a, this_()->_u0956->_u0956, 1.0 / this_()->_u0956->_u0955, this_()->c, this_()->_u0956->_u09632->_u0945, this_()->_u0956->_u09632->_u0946, handler_);
}

#line 47 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
void birch::type::LinearNormalInverseGammaGaussian::update(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("update", "birch/distribution/LinearNormalInverseGammaGaussian.birch", 47);
  #line 48 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(48);
  #line 48 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0956, this_()->_u0956->_u0955, this_()->_u0956->_u09632->_u0945, this_()->_u0956->_u09632->_u0946) = birch::box(birch::update_linear_normal_inverse_gamma_gaussian(x, this_()->a->value(handler_), this_()->_u0956->_u0956->value(handler_), this_()->_u0956->_u0955->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u09632->_u0945->value(handler_), this_()->_u0956->_u09632->_u0946->value(handler_), handler_), handler_);
}

#line 53 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
void birch::type::LinearNormalInverseGammaGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("updateLazy", "birch/distribution/LinearNormalInverseGammaGaussian.birch", 53);
  #line 54 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(54);
  #line 54 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0956, this_()->_u0956->_u0955, this_()->_u0956->_u09632->_u0945, this_()->_u0956->_u09632->_u0946) = birch::update_lazy_linear_normal_inverse_gamma_gaussian(x, this_()->a, this_()->_u0956->_u0956, this_()->_u0956->_u0955, this_()->c, this_()->_u0956->_u09632->_u0945, this_()->_u0956->_u09632->_u0946, handler_);
}

#line 58 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
void birch::type::LinearNormalInverseGammaGaussian::downdate(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("downdate", "birch/distribution/LinearNormalInverseGammaGaussian.birch", 58);
  #line 59 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(59);
  #line 59 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0956, this_()->_u0956->_u0955, this_()->_u0956->_u09632->_u0945, this_()->_u0956->_u09632->_u0946) = birch::box(birch::downdate_linear_normal_inverse_gamma_gaussian(x, this_()->a->value(handler_), this_()->_u0956->_u0956->value(handler_), this_()->_u0956->_u0955->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u09632->_u0945->value(handler_), this_()->_u0956->_u09632->_u0946->value(handler_), handler_), handler_);
}

#line 64 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::LinearNormalInverseGammaGaussian::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("cdf", "birch/distribution/LinearNormalInverseGammaGaussian.birch", 64);
  #line 65 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(65);
  #line 65 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  return birch::cdf_linear_normal_inverse_gamma_gaussian(x, this_()->a->value(handler_), this_()->_u0956->_u0956->value(handler_), 1.0 / this_()->_u0956->_u0955->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u09632->_u0945->value(handler_), this_()->_u0956->_u09632->_u0946->value(handler_), handler_);
}

#line 70 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::LinearNormalInverseGammaGaussian::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("quantile", "birch/distribution/LinearNormalInverseGammaGaussian.birch", 70);
  #line 71 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(71);
  #line 71 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  return birch::quantile_linear_normal_inverse_gamma_gaussian(P, this_()->a->value(handler_), this_()->_u0956->_u0956->value(handler_), 1.0 / this_()->_u0956->_u0955->value(handler_), this_()->c->value(handler_), this_()->_u0956->_u09632->_u0945->value(handler_), this_()->_u0956->_u09632->_u0946->value(handler_), handler_);
}

#line 76 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
void birch::type::LinearNormalInverseGammaGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("link", "birch/distribution/LinearNormalInverseGammaGaussian.birch", 76);
  #line 77 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(77);
  #line 77 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  this_()->_u0956->setChild(shared_from_this_(), handler_);
}

#line 80 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
void birch::type::LinearNormalInverseGammaGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 80 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("unlink", "birch/distribution/LinearNormalInverseGammaGaussian.birch", 80);
  #line 81 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(81);
  #line 81 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  this_()->_u0956->releaseChild(shared_from_this_(), handler_);
}

#line 85 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::LinearNormalInverseGammaGaussian>> birch::LinearNormalInverseGammaGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& c, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 85 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_function_("LinearNormalInverseGammaGaussian", "birch/distribution/LinearNormalInverseGammaGaussian.birch", 85);
  #line 88 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(88);
  #line 88 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::LinearNormalInverseGammaGaussian>> m(a, _u0956, c);
  #line 89 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(89);
  #line 89 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  m->link(handler_);
  #line 90 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  libbirch_line_(90);
  #line 90 "birch/distribution/LinearNormalInverseGammaGaussian.birch"
  return m;
}

#line 1 "birch/distribution/MatrixGaussian.birch"
birch::type::MatrixGaussian::MatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/distribution/MatrixGaussian.birch"
    super_type_(),
    #line 13 "birch/distribution/MatrixGaussian.birch"
    M(M),
    #line 18 "birch/distribution/MatrixGaussian.birch"
    U(U),
    #line 23 "birch/distribution/MatrixGaussian.birch"
    V(V) {
  //
}

#line 25 "birch/distribution/MatrixGaussian.birch"
birch::type::Integer birch::type::MatrixGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("rows", "birch/distribution/MatrixGaussian.birch", 25);
  #line 26 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(26);
  #line 26 "birch/distribution/MatrixGaussian.birch"
  return this_()->M->rows(handler_);
}

#line 29 "birch/distribution/MatrixGaussian.birch"
birch::type::Integer birch::type::MatrixGaussian::columns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("columns", "birch/distribution/MatrixGaussian.birch", 29);
  #line 30 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(30);
  #line 30 "birch/distribution/MatrixGaussian.birch"
  return this_()->M->columns(handler_);
}

#line 33 "birch/distribution/MatrixGaussian.birch"
birch::type::Boolean birch::type::MatrixGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("supportsLazy", "birch/distribution/MatrixGaussian.birch", 33);
  #line 34 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(34);
  #line 34 "birch/distribution/MatrixGaussian.birch"
  return true;
}

#line 37 "birch/distribution/MatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("simulate", "birch/distribution/MatrixGaussian.birch", 37);
  #line 38 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(38);
  #line 38 "birch/distribution/MatrixGaussian.birch"
  return birch::simulate_matrix_gaussian(this_()->M->value(handler_), this_()->U->value(handler_), this_()->V->value(handler_), handler_);
}

#line 41 "birch/distribution/MatrixGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::MatrixGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("simulateLazy", "birch/distribution/MatrixGaussian.birch", 41);
  #line 42 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(42);
  #line 42 "birch/distribution/MatrixGaussian.birch"
  return birch::simulate_matrix_gaussian(this_()->M->get(handler_), this_()->U->get(handler_), this_()->V->get(handler_), handler_);
}

#line 45 "birch/distribution/MatrixGaussian.birch"
birch::type::Real birch::type::MatrixGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("logpdf", "birch/distribution/MatrixGaussian.birch", 45);
  #line 46 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(46);
  #line 46 "birch/distribution/MatrixGaussian.birch"
  return birch::logpdf_matrix_gaussian(X, this_()->M->value(handler_), this_()->U->value(handler_), this_()->V->value(handler_), handler_);
}

#line 49 "birch/distribution/MatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::MatrixGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/MatrixGaussian.birch", 49);
  #line 50 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(50);
  #line 50 "birch/distribution/MatrixGaussian.birch"
  return birch::logpdf_lazy_matrix_gaussian(X, this_()->M, this_()->U, this_()->V, handler_);
}

#line 53 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>> birch::type::MatrixGaussian::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("graft", "birch/distribution/MatrixGaussian.birch", 53);
  #line 54 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(54);
  #line 54 "birch/distribution/MatrixGaussian.birch"
  this_()->prune(handler_);
  #line 55 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(55);
  #line 55 "birch/distribution/MatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>>> s1;
  #line 56 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(56);
  #line 56 "birch/distribution/MatrixGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,2>>>> r = shared_from_this_();
  #line 59 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(59);
  #line 59 "birch/distribution/MatrixGaussian.birch"
  if ((s1 = this_()->V->graftInverseWishart(handler_)).query()) {
    #line 60 "birch/distribution/MatrixGaussian.birch"
    libbirch_line_(60);
    #line 60 "birch/distribution/MatrixGaussian.birch"
    r = birch::MatrixNormalInverseWishart(this_()->M, this_()->U, s1.get(), handler_);
  }
  #line 63 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(63);
  #line 63 "birch/distribution/MatrixGaussian.birch"
  return r;
}

#line 66 "birch/distribution/MatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>> birch::type::MatrixGaussian::graftMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("graftMatrixGaussian", "birch/distribution/MatrixGaussian.birch", 66);
  #line 67 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(67);
  #line 67 "birch/distribution/MatrixGaussian.birch"
  this_()->prune(handler_);
  #line 68 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(68);
  #line 68 "birch/distribution/MatrixGaussian.birch"
  return shared_from_this_();
}

#line 71 "birch/distribution/MatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>> birch::type::MatrixGaussian::graftMatrixNormalInverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::LLT>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 71 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("graftMatrixNormalInverseWishart", "birch/distribution/MatrixGaussian.birch", 71);
  #line 73 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(73);
  #line 73 "birch/distribution/MatrixGaussian.birch"
  this_()->prune(handler_);
  #line 74 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(74);
  #line 74 "birch/distribution/MatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>>> s1;
  #line 75 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(75);
  #line 75 "birch/distribution/MatrixGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>> r;
  #line 78 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(78);
  #line 78 "birch/distribution/MatrixGaussian.birch"
  if ((s1 = this_()->V->graftInverseWishart(handler_)).query() && s1.get() == compare) {
    #line 79 "birch/distribution/MatrixGaussian.birch"
    libbirch_line_(79);
    #line 79 "birch/distribution/MatrixGaussian.birch"
    r = birch::MatrixNormalInverseWishart(this_()->M, this_()->U, s1.get(), handler_);
  }
  #line 82 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(82);
  #line 82 "birch/distribution/MatrixGaussian.birch"
  return r;
}

#line 85 "birch/distribution/MatrixGaussian.birch"
void birch::type::MatrixGaussian::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 85 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("write", "birch/distribution/MatrixGaussian.birch", 85);
  #line 86 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(86);
  #line 86 "birch/distribution/MatrixGaussian.birch"
  this_()->prune(handler_);
  #line 87 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(87);
  #line 87 "birch/distribution/MatrixGaussian.birch"
  buffer->set(birch::type::String("class"), birch::type::String("MatrixGaussian"), handler_);
  #line 88 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(88);
  #line 88 "birch/distribution/MatrixGaussian.birch"
  buffer->set(birch::type::String("M"), this_()->M, handler_);
  #line 89 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(89);
  #line 89 "birch/distribution/MatrixGaussian.birch"
  buffer->set(birch::type::String("U"), this_()->U, handler_);
  #line 90 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(90);
  #line 90 "birch/distribution/MatrixGaussian.birch"
  buffer->set(birch::type::String("V"), this_()->V, handler_);
}

#line 97 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 97 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 97);
  #line 99 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(99);
  #line 99 "birch/distribution/MatrixGaussian.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>>>(M, U, V, handler_);
}

#line 105 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const birch::type::LLT& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 105 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 105);
  #line 107 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(107);
  #line 107 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::box(V, handler_), handler_);
}

#line 113 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const birch::type::LLT& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 113 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 113);
  #line 115 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(115);
  #line 115 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::box(U, handler_), V, handler_);
}

#line 121 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const birch::type::LLT& U, const birch::type::LLT& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 121 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 121);
  #line 123 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(123);
  #line 123 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::box(U, handler_), birch::box(V, handler_), handler_);
}

#line 129 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 129 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 129);
  #line 131 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(131);
  #line 131 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(birch::box(M, handler_), U, V, handler_);
}

#line 137 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const birch::type::LLT& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 137 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 137);
  #line 138 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(138);
  #line 138 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(birch::box(M, handler_), U, birch::box(V, handler_), handler_);
}

#line 144 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 144 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 144);
  #line 145 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(145);
  #line 145 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(birch::box(M, handler_), birch::box(U, handler_), V, handler_);
}

#line 151 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const birch::type::LLT& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 151 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 151);
  #line 152 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(152);
  #line 152 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(birch::box(M, handler_), birch::box(U, handler_), birch::box(V, handler_), handler_);
}

#line 158 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 158 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 158);
  #line 160 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(160);
  #line 160 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), V, handler_);
}

#line 166 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& U, const birch::type::LLT& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 166 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 166);
  #line 168 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(168);
  #line 168 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), V, handler_);
}

#line 174 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 174 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 174);
  #line 176 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(176);
  #line 176 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), V, handler_);
}

#line 182 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const birch::type::LLT& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 182 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 182);
  #line 184 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(184);
  #line 184 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), V, handler_);
}

#line 190 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 190 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 190);
  #line 192 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(192);
  #line 192 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), V, handler_);
}

#line 198 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& U, const birch::type::LLT& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 198 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 198);
  #line 199 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(199);
  #line 199 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), V, handler_);
}

#line 205 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 205 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 205);
  #line 206 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(206);
  #line 206 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), V, handler_);
}

#line 212 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const birch::type::LLT& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 212 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 212);
  #line 213 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(213);
  #line 213 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), V, handler_);
}

#line 219 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 219 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 219);
  #line 221 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(221);
  #line 221 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::llt(V, handler_), handler_);
}

#line 227 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::DefaultArray<birch::type::Real,2>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 227 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 227);
  #line 229 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(229);
  #line 229 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::llt(V, handler_), handler_);
}

#line 235 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const birch::type::LLT& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 235 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 235);
  #line 237 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(237);
  #line 237 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::llt(V, handler_), handler_);
}

#line 243 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const birch::type::LLT& U, const libbirch::DefaultArray<birch::type::Real,2>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 243 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 243);
  #line 245 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(245);
  #line 245 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::llt(V, handler_), handler_);
}

#line 251 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 251 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 251);
  #line 253 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(253);
  #line 253 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::llt(V, handler_), handler_);
}

#line 259 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::DefaultArray<birch::type::Real,2>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 259 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 259);
  #line 261 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(261);
  #line 261 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::llt(V, handler_), handler_);
}

#line 267 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 267 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 267);
  #line 269 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(269);
  #line 269 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::llt(V, handler_), handler_);
}

#line 275 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const birch::type::LLT& U, const libbirch::DefaultArray<birch::type::Real,2>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 275 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 275);
  #line 276 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(276);
  #line 276 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, U, birch::llt(V, handler_), handler_);
}

#line 282 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 282 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 282);
  #line 284 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(284);
  #line 284 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), birch::llt(V, handler_), handler_);
}

#line 290 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& U, const libbirch::DefaultArray<birch::type::Real,2>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 290 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 290);
  #line 292 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(292);
  #line 292 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), birch::llt(V, handler_), handler_);
}

#line 298 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 298 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 298);
  #line 300 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(300);
  #line 300 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), birch::llt(V, handler_), handler_);
}

#line 306 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::DefaultArray<birch::type::Real,2>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 306 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 306);
  #line 308 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(308);
  #line 308 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), birch::llt(V, handler_), handler_);
}

#line 314 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 314 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 314);
  #line 316 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(316);
  #line 316 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), birch::llt(V, handler_), handler_);
}

#line 322 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& U, const libbirch::DefaultArray<birch::type::Real,2>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 322 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 322);
  #line 324 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(324);
  #line 324 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), birch::llt(V, handler_), handler_);
}

#line 330 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 330 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 330);
  #line 332 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(332);
  #line 332 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), birch::llt(V, handler_), handler_);
}

#line 338 "birch/distribution/MatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,2>& M, const libbirch::DefaultArray<birch::type::Real,2>& U, const libbirch::DefaultArray<birch::type::Real,2>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 338 "birch/distribution/MatrixGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MatrixGaussian.birch", 338);
  #line 339 "birch/distribution/MatrixGaussian.birch"
  libbirch_line_(339);
  #line 339 "birch/distribution/MatrixGaussian.birch"
  return birch::Gaussian(M, birch::llt(U, handler_), birch::llt(V, handler_), handler_);
}

#line 4 "birch/distribution/MatrixNormalInverseGamma.birch"
birch::type::MatrixNormalInverseGamma::MatrixNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::IndependentInverseGamma>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/MatrixNormalInverseGamma.birch"
    super_type_(),
    #line 10 "birch/distribution/MatrixNormalInverseGamma.birch"
    _u0923(birch::inv(_u0931, handler_)),
    #line 15 "birch/distribution/MatrixNormalInverseGamma.birch"
    N(birch::canonical(_u0923, handler_) * M),
    #line 20 "birch/distribution/MatrixNormalInverseGamma.birch"
    _u0945(_u09632->_u0945),
    #line 25 "birch/distribution/MatrixNormalInverseGamma.birch"
    _u0947(_u09632->_u0946 + 0.5 * birch::diagonal(birch::transpose(N, handler_) * M, handler_)),
    #line 30 "birch/distribution/MatrixNormalInverseGamma.birch"
    _u09632(_u09632) {
  //
}

#line 32 "birch/distribution/MatrixNormalInverseGamma.birch"
birch::type::Integer birch::type::MatrixNormalInverseGamma::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("rows", "birch/distribution/MatrixNormalInverseGamma.birch", 32);
  #line 33 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(33);
  #line 33 "birch/distribution/MatrixNormalInverseGamma.birch"
  return this_()->N->rows(handler_);
}

#line 36 "birch/distribution/MatrixNormalInverseGamma.birch"
birch::type::Integer birch::type::MatrixNormalInverseGamma::columns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("columns", "birch/distribution/MatrixNormalInverseGamma.birch", 36);
  #line 37 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(37);
  #line 37 "birch/distribution/MatrixNormalInverseGamma.birch"
  return this_()->N->columns(handler_);
}

#line 40 "birch/distribution/MatrixNormalInverseGamma.birch"
birch::type::Boolean birch::type::MatrixNormalInverseGamma::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("supportsLazy", "birch/distribution/MatrixNormalInverseGamma.birch", 40);
  #line 41 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(41);
  #line 41 "birch/distribution/MatrixNormalInverseGamma.birch"
  return true;
}

#line 44 "birch/distribution/MatrixNormalInverseGamma.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixNormalInverseGamma::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("simulate", "birch/distribution/MatrixNormalInverseGamma.birch", 44);
  #line 45 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(45);
  #line 45 "birch/distribution/MatrixNormalInverseGamma.birch"
  return birch::simulate_matrix_normal_inverse_gamma(this_()->N->value(handler_), this_()->_u0923->value(handler_), this_()->_u0945->value(handler_), birch::gamma_to_beta(this_()->_u0947->value(handler_), this_()->N->value(handler_), this_()->_u0923->value(handler_), handler_), handler_);
}

#line 49 "birch/distribution/MatrixNormalInverseGamma.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::MatrixNormalInverseGamma::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("simulateLazy", "birch/distribution/MatrixNormalInverseGamma.birch", 49);
  #line 50 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(50);
  #line 50 "birch/distribution/MatrixNormalInverseGamma.birch"
  return birch::simulate_matrix_normal_inverse_gamma(this_()->N->get(handler_), this_()->_u0923->get(handler_), this_()->_u0945->get(handler_), birch::gamma_to_beta(this_()->_u0947->get(handler_), this_()->N->get(handler_), this_()->_u0923->get(handler_), handler_), handler_);
}

#line 54 "birch/distribution/MatrixNormalInverseGamma.birch"
birch::type::Real birch::type::MatrixNormalInverseGamma::logpdf(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("logpdf", "birch/distribution/MatrixNormalInverseGamma.birch", 54);
  #line 55 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(55);
  #line 55 "birch/distribution/MatrixNormalInverseGamma.birch"
  return birch::logpdf_matrix_normal_inverse_gamma(X, this_()->N->value(handler_), this_()->_u0923->value(handler_), this_()->_u0945->value(handler_), birch::gamma_to_beta(this_()->_u0947->value(handler_), this_()->N->value(handler_), this_()->_u0923->value(handler_), handler_), handler_);
}

#line 59 "birch/distribution/MatrixNormalInverseGamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::MatrixNormalInverseGamma::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/MatrixNormalInverseGamma.birch", 59);
  #line 60 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(60);
  #line 60 "birch/distribution/MatrixNormalInverseGamma.birch"
  return birch::logpdf_lazy_matrix_normal_inverse_gamma(X, this_()->N, this_()->_u0923, this_()->_u0945, birch::gamma_to_beta(this_()->_u0947, this_()->N, this_()->_u0923, handler_), handler_);
}

#line 64 "birch/distribution/MatrixNormalInverseGamma.birch"
void birch::type::MatrixNormalInverseGamma::update(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("update", "birch/distribution/MatrixNormalInverseGamma.birch", 64);
  #line 65 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(65);
  #line 65 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch::tie(this_()->_u09632->_u0945, this_()->_u09632->_u0946) = birch::box(birch::update_matrix_normal_inverse_gamma(X, this_()->N->value(handler_), this_()->_u0923->value(handler_), this_()->_u0945->value(handler_), birch::gamma_to_beta(this_()->_u0947->value(handler_), this_()->N->value(handler_), this_()->_u0923->value(handler_), handler_), handler_), handler_);
}

#line 70 "birch/distribution/MatrixNormalInverseGamma.birch"
void birch::type::MatrixNormalInverseGamma::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("updateLazy", "birch/distribution/MatrixNormalInverseGamma.birch", 70);
  #line 71 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(71);
  #line 71 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch::tie(this_()->_u09632->_u0945, this_()->_u09632->_u0946) = birch::update_lazy_matrix_normal_inverse_gamma(X, this_()->N, this_()->_u0923, this_()->_u0945, birch::gamma_to_beta(this_()->_u0947, this_()->N, this_()->_u0923, handler_), handler_);
}

#line 75 "birch/distribution/MatrixNormalInverseGamma.birch"
void birch::type::MatrixNormalInverseGamma::downdate(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 75 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("downdate", "birch/distribution/MatrixNormalInverseGamma.birch", 75);
  #line 76 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(76);
  #line 76 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch::tie(this_()->_u09632->_u0945, this_()->_u09632->_u0946) = birch::box(birch::downdate_matrix_normal_inverse_gamma(X, this_()->N->value(handler_), this_()->_u0923->value(handler_), this_()->_u0945->value(handler_), birch::gamma_to_beta(this_()->_u0947->value(handler_), this_()->N->value(handler_), this_()->_u0923->value(handler_), handler_), handler_), handler_);
}

#line 81 "birch/distribution/MatrixNormalInverseGamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>> birch::type::MatrixNormalInverseGamma::graftMatrixNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("graftMatrixNormalInverseGamma", "birch/distribution/MatrixNormalInverseGamma.birch", 81);
  #line 83 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(83);
  #line 83 "birch/distribution/MatrixNormalInverseGamma.birch"
  this_()->prune(handler_);
  #line 84 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(84);
  #line 84 "birch/distribution/MatrixNormalInverseGamma.birch"
  if (this_()->_u09632 == compare) {
    #line 85 "birch/distribution/MatrixNormalInverseGamma.birch"
    libbirch_line_(85);
    #line 85 "birch/distribution/MatrixNormalInverseGamma.birch"
    return shared_from_this_();
  } else {
    #line 87 "birch/distribution/MatrixNormalInverseGamma.birch"
    libbirch_line_(87);
    #line 87 "birch/distribution/MatrixNormalInverseGamma.birch"
    return libbirch::nil;
  }
}

#line 91 "birch/distribution/MatrixNormalInverseGamma.birch"
void birch::type::MatrixNormalInverseGamma::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 91 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("link", "birch/distribution/MatrixNormalInverseGamma.birch", 91);
  #line 92 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(92);
  #line 92 "birch/distribution/MatrixNormalInverseGamma.birch"
  this_()->_u09632->setChild(shared_from_this_(), handler_);
}

#line 95 "birch/distribution/MatrixNormalInverseGamma.birch"
void birch::type::MatrixNormalInverseGamma::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("unlink", "birch/distribution/MatrixNormalInverseGamma.birch", 95);
  #line 96 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(96);
  #line 96 "birch/distribution/MatrixNormalInverseGamma.birch"
  this_()->_u09632->releaseChild(shared_from_this_(), handler_);
}

#line 99 "birch/distribution/MatrixNormalInverseGamma.birch"
void birch::type::MatrixNormalInverseGamma::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 99 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("write", "birch/distribution/MatrixNormalInverseGamma.birch", 99);
  #line 100 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(100);
  #line 100 "birch/distribution/MatrixNormalInverseGamma.birch"
  this_()->prune(handler_);
  #line 101 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(101);
  #line 101 "birch/distribution/MatrixNormalInverseGamma.birch"
  buffer->set(birch::type::String("class"), birch::type::String("MatrixNormalInverseGamma"), handler_);
  #line 102 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(102);
  #line 102 "birch/distribution/MatrixNormalInverseGamma.birch"
  buffer->set(birch::type::String("M"), birch::solve(this_()->_u0923->value(handler_), this_()->N->value(handler_), handler_), handler_);
  #line 103 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(103);
  #line 103 "birch/distribution/MatrixNormalInverseGamma.birch"
  buffer->set(birch::type::String("Σ"), birch::inv(this_()->_u0923->value(handler_), handler_), handler_);
  #line 104 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(104);
  #line 104 "birch/distribution/MatrixNormalInverseGamma.birch"
  buffer->set(birch::type::String("α"), this_()->_u0945, handler_);
  #line 105 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(105);
  #line 105 "birch/distribution/MatrixNormalInverseGamma.birch"
  buffer->set(birch::type::String("β"), birch::gamma_to_beta(this_()->_u0947->value(handler_), this_()->N->value(handler_), this_()->_u0923->value(handler_), handler_), handler_);
}

#line 109 "birch/distribution/MatrixNormalInverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>> birch::MatrixNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::IndependentInverseGamma>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 109 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("MatrixNormalInverseGamma", "birch/distribution/MatrixNormalInverseGamma.birch", 109);
  #line 111 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(111);
  #line 111 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>> m(M, _u0931, _u09632);
  #line 112 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(112);
  #line 112 "birch/distribution/MatrixNormalInverseGamma.birch"
  m->link(handler_);
  #line 113 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(113);
  #line 113 "birch/distribution/MatrixNormalInverseGamma.birch"
  return m;
}

#line 120 "birch/distribution/MatrixNormalInverseGamma.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::gamma_to_beta(const libbirch::DefaultArray<birch::type::Real,1>& _u0947, const libbirch::DefaultArray<birch::type::Real,2>& N, const birch::type::LLT& _u0923, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 120 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("gamma_to_beta", "birch/distribution/MatrixNormalInverseGamma.birch", 120);
  #line 121 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(121);
  #line 121 "birch/distribution/MatrixNormalInverseGamma.birch"
  return _u0947 - 0.5 * birch::diagonal(birch::transpose(N, handler_) * birch::solve(_u0923, N, handler_), handler_);
}

#line 124 "birch/distribution/MatrixNormalInverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>> birch::gamma_to_beta(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0947, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& N, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0923, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 124 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_function_("gamma_to_beta", "birch/distribution/MatrixNormalInverseGamma.birch", 124);
  #line 126 "birch/distribution/MatrixNormalInverseGamma.birch"
  libbirch_line_(126);
  #line 126 "birch/distribution/MatrixNormalInverseGamma.birch"
  return _u0947 - 0.5 * birch::diagonal(birch::transpose(N, handler_) * birch::solve(_u0923, N, handler_), handler_);
}

#line 4 "birch/distribution/MatrixNormalInverseWishart.birch"
birch::type::MatrixNormalInverseWishart::MatrixNormalInverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/MatrixNormalInverseWishart.birch"
    super_type_(),
    #line 9 "birch/distribution/MatrixNormalInverseWishart.birch"
    _u0923(birch::inv(U, handler_)),
    #line 14 "birch/distribution/MatrixNormalInverseWishart.birch"
    N(birch::canonical(_u0923, handler_) * M),
    #line 19 "birch/distribution/MatrixNormalInverseWishart.birch"
    V(V) {
  //
}

#line 21 "birch/distribution/MatrixNormalInverseWishart.birch"
birch::type::Integer birch::type::MatrixNormalInverseWishart::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("rows", "birch/distribution/MatrixNormalInverseWishart.birch", 21);
  #line 22 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(22);
  #line 22 "birch/distribution/MatrixNormalInverseWishart.birch"
  return this_()->N->rows(handler_);
}

#line 25 "birch/distribution/MatrixNormalInverseWishart.birch"
birch::type::Integer birch::type::MatrixNormalInverseWishart::columns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("columns", "birch/distribution/MatrixNormalInverseWishart.birch", 25);
  #line 26 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(26);
  #line 26 "birch/distribution/MatrixNormalInverseWishart.birch"
  return this_()->N->columns(handler_);
}

#line 29 "birch/distribution/MatrixNormalInverseWishart.birch"
birch::type::Boolean birch::type::MatrixNormalInverseWishart::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("supportsLazy", "birch/distribution/MatrixNormalInverseWishart.birch", 29);
  #line 30 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(30);
  #line 30 "birch/distribution/MatrixNormalInverseWishart.birch"
  return true;
}

#line 33 "birch/distribution/MatrixNormalInverseWishart.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixNormalInverseWishart::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("simulate", "birch/distribution/MatrixNormalInverseWishart.birch", 33);
  #line 34 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(34);
  #line 34 "birch/distribution/MatrixNormalInverseWishart.birch"
  return birch::simulate_matrix_normal_inverse_wishart(this_()->N->value(handler_), this_()->_u0923->value(handler_), this_()->V->_u0936->value(handler_), this_()->V->k->value(handler_), handler_);
}

#line 37 "birch/distribution/MatrixNormalInverseWishart.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::MatrixNormalInverseWishart::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("simulateLazy", "birch/distribution/MatrixNormalInverseWishart.birch", 37);
  #line 38 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(38);
  #line 38 "birch/distribution/MatrixNormalInverseWishart.birch"
  return birch::simulate_matrix_normal_inverse_wishart(this_()->N->get(handler_), this_()->_u0923->get(handler_), this_()->V->_u0936->get(handler_), this_()->V->k->get(handler_), handler_);
}

#line 41 "birch/distribution/MatrixNormalInverseWishart.birch"
birch::type::Real birch::type::MatrixNormalInverseWishart::logpdf(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("logpdf", "birch/distribution/MatrixNormalInverseWishart.birch", 41);
  #line 42 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(42);
  #line 42 "birch/distribution/MatrixNormalInverseWishart.birch"
  return birch::logpdf_matrix_normal_inverse_wishart(X, this_()->N->value(handler_), this_()->_u0923->value(handler_), this_()->V->_u0936->value(handler_), this_()->V->k->value(handler_), handler_);
}

#line 45 "birch/distribution/MatrixNormalInverseWishart.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::MatrixNormalInverseWishart::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/MatrixNormalInverseWishart.birch", 45);
  #line 46 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(46);
  #line 46 "birch/distribution/MatrixNormalInverseWishart.birch"
  return birch::logpdf_lazy_matrix_normal_inverse_wishart(X, this_()->N, this_()->_u0923, this_()->V->_u0936, this_()->V->k, handler_);
}

#line 49 "birch/distribution/MatrixNormalInverseWishart.birch"
void birch::type::MatrixNormalInverseWishart::update(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("update", "birch/distribution/MatrixNormalInverseWishart.birch", 49);
  #line 50 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(50);
  #line 50 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch::tie(this_()->V->_u0936, this_()->V->k) = birch::box(birch::update_matrix_normal_inverse_wishart(X, this_()->N->value(handler_), this_()->_u0923->value(handler_), this_()->V->_u0936->value(handler_), this_()->V->k->value(handler_), handler_), handler_);
}

#line 53 "birch/distribution/MatrixNormalInverseWishart.birch"
void birch::type::MatrixNormalInverseWishart::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("updateLazy", "birch/distribution/MatrixNormalInverseWishart.birch", 53);
  #line 54 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(54);
  #line 54 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch::tie(this_()->V->_u0936, this_()->V->k) = birch::update_lazy_matrix_normal_inverse_wishart(X, this_()->N, this_()->_u0923, this_()->V->_u0936, this_()->V->k, handler_);
}

#line 57 "birch/distribution/MatrixNormalInverseWishart.birch"
void birch::type::MatrixNormalInverseWishart::downdate(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 57 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("downdate", "birch/distribution/MatrixNormalInverseWishart.birch", 57);
  #line 58 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(58);
  #line 58 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch::tie(this_()->V->_u0936, this_()->V->k) = birch::box(birch::downdate_matrix_normal_inverse_wishart(X, this_()->N->value(handler_), this_()->_u0923->value(handler_), this_()->V->_u0936->value(handler_), this_()->V->k->value(handler_), handler_), handler_);
}

#line 61 "birch/distribution/MatrixNormalInverseWishart.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>> birch::type::MatrixNormalInverseWishart::graftMatrixNormalInverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::LLT>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("graftMatrixNormalInverseWishart", "birch/distribution/MatrixNormalInverseWishart.birch", 61);
  #line 63 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(63);
  #line 63 "birch/distribution/MatrixNormalInverseWishart.birch"
  this_()->prune(handler_);
  #line 64 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(64);
  #line 64 "birch/distribution/MatrixNormalInverseWishart.birch"
  if (this_()->V == compare) {
    #line 65 "birch/distribution/MatrixNormalInverseWishart.birch"
    libbirch_line_(65);
    #line 65 "birch/distribution/MatrixNormalInverseWishart.birch"
    return shared_from_this_();
  } else {
    #line 67 "birch/distribution/MatrixNormalInverseWishart.birch"
    libbirch_line_(67);
    #line 67 "birch/distribution/MatrixNormalInverseWishart.birch"
    return libbirch::nil;
  }
}

#line 71 "birch/distribution/MatrixNormalInverseWishart.birch"
void birch::type::MatrixNormalInverseWishart::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 71 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("link", "birch/distribution/MatrixNormalInverseWishart.birch", 71);
  #line 72 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(72);
  #line 72 "birch/distribution/MatrixNormalInverseWishart.birch"
  this_()->V->setChild(shared_from_this_(), handler_);
}

#line 75 "birch/distribution/MatrixNormalInverseWishart.birch"
void birch::type::MatrixNormalInverseWishart::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 75 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("unlink", "birch/distribution/MatrixNormalInverseWishart.birch", 75);
  #line 76 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(76);
  #line 76 "birch/distribution/MatrixNormalInverseWishart.birch"
  this_()->V->releaseChild(shared_from_this_(), handler_);
}

#line 79 "birch/distribution/MatrixNormalInverseWishart.birch"
void birch::type::MatrixNormalInverseWishart::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 79 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("write", "birch/distribution/MatrixNormalInverseWishart.birch", 79);
  #line 80 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(80);
  #line 80 "birch/distribution/MatrixNormalInverseWishart.birch"
  this_()->prune(handler_);
  #line 81 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(81);
  #line 81 "birch/distribution/MatrixNormalInverseWishart.birch"
  buffer->set(birch::type::String("class"), birch::type::String("MatrixNormalInverseWishart"), handler_);
  #line 82 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(82);
  #line 82 "birch/distribution/MatrixNormalInverseWishart.birch"
  buffer->set(birch::type::String("M"), birch::solve(this_()->_u0923->value(handler_), this_()->N->value(handler_), handler_), handler_);
  #line 83 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(83);
  #line 83 "birch/distribution/MatrixNormalInverseWishart.birch"
  buffer->set(birch::type::String("Σ"), birch::inv(this_()->_u0923->value(handler_), handler_), handler_);
  #line 84 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(84);
  #line 84 "birch/distribution/MatrixNormalInverseWishart.birch"
  buffer->set(birch::type::String("Ψ"), this_()->V->_u0936->value(handler_), handler_);
  #line 85 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(85);
  #line 85 "birch/distribution/MatrixNormalInverseWishart.birch"
  buffer->set(birch::type::String("k"), this_()->V->k->value(handler_), handler_);
}

#line 89 "birch/distribution/MatrixNormalInverseWishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>> birch::MatrixNormalInverseWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& U, const libbirch::Lazy<libbirch::Shared<birch::type::InverseWishart>>& V, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 89 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_function_("MatrixNormalInverseWishart", "birch/distribution/MatrixNormalInverseWishart.birch", 89);
  #line 91 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(91);
  #line 91 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>> m(M, U, V);
  #line 92 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(92);
  #line 92 "birch/distribution/MatrixNormalInverseWishart.birch"
  m->link(handler_);
  #line 93 "birch/distribution/MatrixNormalInverseWishart.birch"
  libbirch_line_(93);
  #line 93 "birch/distribution/MatrixNormalInverseWishart.birch"
  return m;
}

#line 4 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::MatrixNormalInverseGammaMatrixGaussian::MatrixNormalInverseGammaMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
    super_type_(),
    #line 9 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
    M(M) {
  //
}

#line 11 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::Integer birch::type::MatrixNormalInverseGammaMatrixGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("rows", "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 11);
  #line 12 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(12);
  #line 12 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  auto M = this_()->M;
  #line 13 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(13);
  #line 13 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  return M->rows(handler_);
}

#line 16 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::Integer birch::type::MatrixNormalInverseGammaMatrixGaussian::columns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("columns", "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 16);
  #line 17 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(17);
  #line 17 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  auto M = this_()->M;
  #line 18 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(18);
  #line 18 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  return M->columns(handler_);
}

#line 21 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::Boolean birch::type::MatrixNormalInverseGammaMatrixGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("supportsLazy", "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 21);
  #line 22 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(22);
  #line 22 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  return true;
}

#line 25 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixNormalInverseGammaMatrixGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("simulate", "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 25);
  #line 26 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(26);
  #line 26 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  return birch::simulate_matrix_normal_inverse_gamma_matrix_gaussian(this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->M->_u0945->value(handler_), this_()->M->_u0947->value(handler_), handler_);
}

#line 30 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::MatrixNormalInverseGammaMatrixGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("simulateLazy", "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 30);
  #line 31 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(31);
  #line 31 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  return birch::simulate_matrix_normal_inverse_gamma_matrix_gaussian(this_()->M->N->get(handler_), this_()->M->_u0923->get(handler_), this_()->M->_u0945->get(handler_), this_()->M->_u0947->get(handler_), handler_);
}

#line 35 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
birch::type::Real birch::type::MatrixNormalInverseGammaMatrixGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("logpdf", "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 35);
  #line 36 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(36);
  #line 36 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  return birch::logpdf_matrix_normal_inverse_gamma_matrix_gaussian(X, this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->M->_u0945->value(handler_), this_()->M->_u0947->value(handler_), handler_);
}

#line 40 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::MatrixNormalInverseGammaMatrixGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 40);
  #line 41 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(41);
  #line 41 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  return birch::logpdf_lazy_matrix_normal_inverse_gamma_matrix_gaussian(X, this_()->M->N, this_()->M->_u0923, this_()->M->_u0945, this_()->M->_u0947, handler_);
}

#line 45 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
void birch::type::MatrixNormalInverseGammaMatrixGaussian::update(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("update", "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 45);
  #line 46 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(46);
  #line 46 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::tie(this_()->M->N, this_()->M->_u0923, this_()->M->_u0945, this_()->M->_u0947) = birch::box(birch::update_matrix_normal_inverse_gamma_matrix_gaussian(X, this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->M->_u0945->value(handler_), this_()->M->_u0947->value(handler_), handler_), handler_);
}

#line 50 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
void birch::type::MatrixNormalInverseGammaMatrixGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("updateLazy", "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 50);
  #line 51 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(51);
  #line 51 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::tie(this_()->M->N, this_()->M->_u0923, this_()->M->_u0945, this_()->M->_u0947) = birch::update_lazy_matrix_normal_inverse_gamma_matrix_gaussian(X, this_()->M->N, this_()->M->_u0923, this_()->M->_u0945, this_()->M->_u0947, handler_);
}

#line 55 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
void birch::type::MatrixNormalInverseGammaMatrixGaussian::downdate(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 55 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("downdate", "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 55);
  #line 56 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(56);
  #line 56 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::tie(this_()->M->N, this_()->M->_u0923, this_()->M->_u0945, this_()->M->_u0947) = birch::box(birch::downdate_matrix_normal_inverse_gamma_matrix_gaussian(X, this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->M->_u0945->value(handler_), this_()->M->_u0947->value(handler_), handler_), handler_);
}

#line 60 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
void birch::type::MatrixNormalInverseGammaMatrixGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("link", "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 60);
  #line 61 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(61);
  #line 61 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->M->setChild(shared_from_this_(), handler_);
}

#line 64 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
void birch::type::MatrixNormalInverseGammaMatrixGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("unlink", "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 64);
  #line 65 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(65);
  #line 65 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  this_()->M->releaseChild(shared_from_this_(), handler_);
}

#line 69 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGammaMatrixGaussian>> birch::MatrixNormalInverseGammaMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGamma>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_function_("MatrixNormalInverseGammaMatrixGaussian", "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch", 69);
  #line 71 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(71);
  #line 71 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseGammaMatrixGaussian>> m(M);
  #line 72 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(72);
  #line 72 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  m->link(handler_);
  #line 73 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  libbirch_line_(73);
  #line 73 "birch/distribution/MatrixNormalInverseGammaMatrixGaussian.birch"
  return m;
}

#line 4 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::MatrixNormalInverseWishartMatrixGaussian::MatrixNormalInverseWishartMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
    super_type_(),
    #line 9 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
    M(M) {
  //
}

#line 11 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Integer birch::type::MatrixNormalInverseWishartMatrixGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("rows", "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 11);
  #line 12 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(12);
  #line 12 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  return this_()->M->rows(handler_);
}

#line 15 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Integer birch::type::MatrixNormalInverseWishartMatrixGaussian::columns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("columns", "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 15);
  #line 16 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(16);
  #line 16 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  return this_()->M->columns(handler_);
}

#line 19 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Boolean birch::type::MatrixNormalInverseWishartMatrixGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("supportsLazy", "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 19);
  #line 20 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(20);
  #line 20 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  return true;
}

#line 23 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::DefaultArray<birch::type::Real,2> birch::type::MatrixNormalInverseWishartMatrixGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("simulate", "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 23);
  #line 24 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(24);
  #line 24 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  return birch::simulate_matrix_normal_inverse_wishart_matrix_gaussian(this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->M->V->_u0936->value(handler_), this_()->M->V->k->value(handler_), handler_);
}

#line 28 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,2>> birch::type::MatrixNormalInverseWishartMatrixGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("simulateLazy", "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 28);
  #line 29 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(29);
  #line 29 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  return birch::simulate_matrix_normal_inverse_wishart_matrix_gaussian(this_()->M->N->get(handler_), this_()->M->_u0923->get(handler_), this_()->M->V->_u0936->get(handler_), this_()->M->V->k->get(handler_), handler_);
}

#line 33 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
birch::type::Real birch::type::MatrixNormalInverseWishartMatrixGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("logpdf", "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 33);
  #line 34 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(34);
  #line 34 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  return birch::logpdf_matrix_normal_inverse_wishart_matrix_gaussian(X, this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->M->V->_u0936->value(handler_), this_()->M->V->k->value(handler_), handler_);
}

#line 38 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::MatrixNormalInverseWishartMatrixGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 38);
  #line 39 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(39);
  #line 39 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  return birch::logpdf_lazy_matrix_normal_inverse_wishart_matrix_gaussian(X, this_()->M->N, this_()->M->_u0923, this_()->M->V->_u0936, this_()->M->V->k, handler_);
}

#line 43 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::MatrixNormalInverseWishartMatrixGaussian::update(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("update", "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 43);
  #line 44 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(44);
  #line 44 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::tie(this_()->M->N, this_()->M->_u0923, this_()->M->V->_u0936, this_()->M->V->k) = birch::box(birch::update_matrix_normal_inverse_wishart_matrix_gaussian(X, this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->M->V->_u0936->value(handler_), this_()->M->V->k->value(handler_), handler_), handler_);
}

#line 48 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::MatrixNormalInverseWishartMatrixGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("updateLazy", "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 48);
  #line 49 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(49);
  #line 49 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::tie(this_()->M->N, this_()->M->_u0923, this_()->M->V->_u0936, this_()->M->V->k) = birch::update_lazy_matrix_normal_inverse_wishart_matrix_gaussian(X, this_()->M->N, this_()->M->_u0923, this_()->M->V->_u0936, this_()->M->V->k, handler_);
}

#line 53 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::MatrixNormalInverseWishartMatrixGaussian::downdate(const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("downdate", "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 53);
  #line 54 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(54);
  #line 54 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::tie(this_()->M->N, this_()->M->_u0923, this_()->M->V->_u0936, this_()->M->V->k) = birch::box(birch::downdate_matrix_normal_inverse_wishart_matrix_gaussian(X, this_()->M->N->value(handler_), this_()->M->_u0923->value(handler_), this_()->M->V->_u0936->value(handler_), this_()->M->V->k->value(handler_), handler_), handler_);
}

#line 58 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::MatrixNormalInverseWishartMatrixGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("link", "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 58);
  #line 59 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(59);
  #line 59 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->M->setChild(shared_from_this_(), handler_);
}

#line 62 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
void birch::type::MatrixNormalInverseWishartMatrixGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 62 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("unlink", "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 62);
  #line 63 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(63);
  #line 63 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  this_()->M->releaseChild(shared_from_this_(), handler_);
}

#line 67 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishartMatrixGaussian>> birch::MatrixNormalInverseWishartMatrixGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishart>>& M, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 67 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_function_("MatrixNormalInverseWishartMatrixGaussian", "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch", 67);
  #line 70 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(70);
  #line 70 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::MatrixNormalInverseWishartMatrixGaussian>> m(M);
  #line 71 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(71);
  #line 71 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  m->link(handler_);
  #line 72 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  libbirch_line_(72);
  #line 72 "birch/distribution/MatrixNormalInverseWishartMatrixGaussian.birch"
  return m;
}

#line 1 "birch/distribution/Multinomial.birch"
birch::type::Multinomial::Multinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& n, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/distribution/Multinomial.birch"
    super_type_(),
    #line 9 "birch/distribution/Multinomial.birch"
    n(n),
    #line 14 "birch/distribution/Multinomial.birch"
    _u0961(_u0961) {
  //
}

#line 16 "birch/distribution/Multinomial.birch"
birch::type::Integer birch::type::Multinomial::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "birch/distribution/Multinomial.birch"
  libbirch_function_("rows", "birch/distribution/Multinomial.birch", 16);
  #line 17 "birch/distribution/Multinomial.birch"
  libbirch_line_(17);
  #line 17 "birch/distribution/Multinomial.birch"
  return this_()->_u0961->rows(handler_);
}

#line 20 "birch/distribution/Multinomial.birch"
birch::type::Boolean birch::type::Multinomial::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "birch/distribution/Multinomial.birch"
  libbirch_function_("supportsLazy", "birch/distribution/Multinomial.birch", 20);
  #line 21 "birch/distribution/Multinomial.birch"
  libbirch_line_(21);
  #line 21 "birch/distribution/Multinomial.birch"
  return false;
}

#line 24 "birch/distribution/Multinomial.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::type::Multinomial::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "birch/distribution/Multinomial.birch"
  libbirch_function_("simulate", "birch/distribution/Multinomial.birch", 24);
  #line 25 "birch/distribution/Multinomial.birch"
  libbirch_line_(25);
  #line 25 "birch/distribution/Multinomial.birch"
  return birch::simulate_multinomial(this_()->n->value(handler_), this_()->_u0961->value(handler_), handler_);
}

#line 32 "birch/distribution/Multinomial.birch"
birch::type::Real birch::type::Multinomial::logpdf(const libbirch::DefaultArray<birch::type::Integer,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "birch/distribution/Multinomial.birch"
  libbirch_function_("logpdf", "birch/distribution/Multinomial.birch", 32);
  #line 33 "birch/distribution/Multinomial.birch"
  libbirch_line_(33);
  #line 33 "birch/distribution/Multinomial.birch"
  return birch::logpdf_multinomial(x, this_()->n->value(handler_), this_()->_u0961->value(handler_), handler_);
}

#line 40 "birch/distribution/Multinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Integer,1>>>> birch::type::Multinomial::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "birch/distribution/Multinomial.birch"
  libbirch_function_("graft", "birch/distribution/Multinomial.birch", 40);
  #line 41 "birch/distribution/Multinomial.birch"
  libbirch_line_(41);
  #line 41 "birch/distribution/Multinomial.birch"
  this_()->prune(handler_);
  #line 42 "birch/distribution/Multinomial.birch"
  libbirch_line_(42);
  #line 42 "birch/distribution/Multinomial.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Dirichlet>>> m;
  #line 43 "birch/distribution/Multinomial.birch"
  libbirch_line_(43);
  #line 43 "birch/distribution/Multinomial.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Integer,1>>>> r = shared_from_this_();
  #line 46 "birch/distribution/Multinomial.birch"
  libbirch_line_(46);
  #line 46 "birch/distribution/Multinomial.birch"
  if ((m = this_()->_u0961->graftDirichlet(handler_)).query()) {
    #line 47 "birch/distribution/Multinomial.birch"
    libbirch_line_(47);
    #line 47 "birch/distribution/Multinomial.birch"
    r = birch::DirichletMultinomial(this_()->n, m.get(), handler_);
  }
  #line 50 "birch/distribution/Multinomial.birch"
  libbirch_line_(50);
  #line 50 "birch/distribution/Multinomial.birch"
  return r;
}

#line 53 "birch/distribution/Multinomial.birch"
void birch::type::Multinomial::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "birch/distribution/Multinomial.birch"
  libbirch_function_("write", "birch/distribution/Multinomial.birch", 53);
  #line 54 "birch/distribution/Multinomial.birch"
  libbirch_line_(54);
  #line 54 "birch/distribution/Multinomial.birch"
  this_()->prune(handler_);
  #line 55 "birch/distribution/Multinomial.birch"
  libbirch_line_(55);
  #line 55 "birch/distribution/Multinomial.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Multinomial"), handler_);
  #line 56 "birch/distribution/Multinomial.birch"
  libbirch_line_(56);
  #line 56 "birch/distribution/Multinomial.birch"
  buffer->set(birch::type::String("n"), this_()->n, handler_);
  #line 57 "birch/distribution/Multinomial.birch"
  libbirch_line_(57);
  #line 57 "birch/distribution/Multinomial.birch"
  buffer->set(birch::type::String("ρ"), this_()->_u0961, handler_);
}

#line 64 "birch/distribution/Multinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Multinomial>> birch::Multinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& n, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "birch/distribution/Multinomial.birch"
  libbirch_function_("Multinomial", "birch/distribution/Multinomial.birch", 64);
  #line 66 "birch/distribution/Multinomial.birch"
  libbirch_line_(66);
  #line 66 "birch/distribution/Multinomial.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Multinomial>>>(n, _u0961, handler_);
}

#line 72 "birch/distribution/Multinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Multinomial>> birch::Multinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& n, const libbirch::DefaultArray<birch::type::Real,1>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "birch/distribution/Multinomial.birch"
  libbirch_function_("Multinomial", "birch/distribution/Multinomial.birch", 72);
  #line 73 "birch/distribution/Multinomial.birch"
  libbirch_line_(73);
  #line 73 "birch/distribution/Multinomial.birch"
  return birch::Multinomial(n, birch::box(_u0961, handler_), handler_);
}

#line 79 "birch/distribution/Multinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Multinomial>> birch::Multinomial(const birch::type::Integer& n, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 79 "birch/distribution/Multinomial.birch"
  libbirch_function_("Multinomial", "birch/distribution/Multinomial.birch", 79);
  #line 80 "birch/distribution/Multinomial.birch"
  libbirch_line_(80);
  #line 80 "birch/distribution/Multinomial.birch"
  return birch::Multinomial(birch::box(n, handler_), _u0961, handler_);
}

#line 86 "birch/distribution/Multinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Multinomial>> birch::Multinomial(const birch::type::Integer& n, const libbirch::DefaultArray<birch::type::Real,1>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 86 "birch/distribution/Multinomial.birch"
  libbirch_function_("Multinomial", "birch/distribution/Multinomial.birch", 86);
  #line 87 "birch/distribution/Multinomial.birch"
  libbirch_line_(87);
  #line 87 "birch/distribution/Multinomial.birch"
  return birch::Multinomial(birch::box(n, handler_), birch::box(_u0961, handler_), handler_);
}

#line 1 "birch/distribution/MultivariateGaussian.birch"
birch::type::MultivariateGaussian::MultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/distribution/MultivariateGaussian.birch"
    super_type_(),
    #line 13 "birch/distribution/MultivariateGaussian.birch"
    _u0956(_u0956),
    #line 18 "birch/distribution/MultivariateGaussian.birch"
    _u0931(_u0931) {
  //
}

#line 20 "birch/distribution/MultivariateGaussian.birch"
birch::type::Integer birch::type::MultivariateGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "birch/distribution/MultivariateGaussian.birch"
  libbirch_function_("rows", "birch/distribution/MultivariateGaussian.birch", 20);
  #line 21 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(21);
  #line 21 "birch/distribution/MultivariateGaussian.birch"
  return this_()->_u0956->rows(handler_);
}

#line 24 "birch/distribution/MultivariateGaussian.birch"
birch::type::Boolean birch::type::MultivariateGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "birch/distribution/MultivariateGaussian.birch"
  libbirch_function_("supportsLazy", "birch/distribution/MultivariateGaussian.birch", 24);
  #line 25 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(25);
  #line 25 "birch/distribution/MultivariateGaussian.birch"
  return true;
}

#line 28 "birch/distribution/MultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "birch/distribution/MultivariateGaussian.birch"
  libbirch_function_("simulate", "birch/distribution/MultivariateGaussian.birch", 28);
  #line 29 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(29);
  #line 29 "birch/distribution/MultivariateGaussian.birch"
  return birch::simulate_multivariate_gaussian(this_()->_u0956->value(handler_), this_()->_u0931->value(handler_), handler_);
}

#line 32 "birch/distribution/MultivariateGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::MultivariateGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "birch/distribution/MultivariateGaussian.birch"
  libbirch_function_("simulateLazy", "birch/distribution/MultivariateGaussian.birch", 32);
  #line 33 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(33);
  #line 33 "birch/distribution/MultivariateGaussian.birch"
  return birch::simulate_multivariate_gaussian(this_()->_u0956->get(handler_), this_()->_u0931->get(handler_), handler_);
}

#line 36 "birch/distribution/MultivariateGaussian.birch"
birch::type::Real birch::type::MultivariateGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "birch/distribution/MultivariateGaussian.birch"
  libbirch_function_("logpdf", "birch/distribution/MultivariateGaussian.birch", 36);
  #line 37 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(37);
  #line 37 "birch/distribution/MultivariateGaussian.birch"
  return birch::logpdf_multivariate_gaussian(x, this_()->_u0956->value(handler_), this_()->_u0931->value(handler_), handler_);
}

#line 40 "birch/distribution/MultivariateGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::MultivariateGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "birch/distribution/MultivariateGaussian.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/MultivariateGaussian.birch", 40);
  #line 41 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(41);
  #line 41 "birch/distribution/MultivariateGaussian.birch"
  return birch::logpdf_lazy_multivariate_gaussian(x, this_()->_u0956, this_()->_u0931, handler_);
}

#line 44 "birch/distribution/MultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>> birch::type::MultivariateGaussian::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "birch/distribution/MultivariateGaussian.birch"
  libbirch_function_("graft", "birch/distribution/MultivariateGaussian.birch", 44);
  #line 45 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(45);
  #line 45 "birch/distribution/MultivariateGaussian.birch"
  this_()->prune(handler_);
  #line 46 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(46);
  #line 46 "birch/distribution/MultivariateGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> m1;
  #line 47 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(47);
  #line 47 "birch/distribution/MultivariateGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>> m2;
  #line 48 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(48);
  #line 48 "birch/distribution/MultivariateGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>> r = shared_from_this_();
  #line 51 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(51);
  #line 51 "birch/distribution/MultivariateGaussian.birch"
  if ((m1 = this_()->_u0956->graftLinearMultivariateGaussian(handler_)).query()) {
    #line 52 "birch/distribution/MultivariateGaussian.birch"
    libbirch_line_(52);
    #line 52 "birch/distribution/MultivariateGaussian.birch"
    r = birch::LinearMultivariateGaussianMultivariateGaussian(m1.get()->A, m1.get()->x, m1.get()->c, this_()->_u0931, handler_);
  } else {
    #line 53 "birch/distribution/MultivariateGaussian.birch"
    libbirch_line_(53);
    #line 53 "birch/distribution/MultivariateGaussian.birch"
    if ((m2 = this_()->_u0956->graftMultivariateGaussian(handler_)).query()) {
      #line 54 "birch/distribution/MultivariateGaussian.birch"
      libbirch_line_(54);
      #line 54 "birch/distribution/MultivariateGaussian.birch"
      r = birch::MultivariateGaussianMultivariateGaussian(m2.get(), this_()->_u0931, handler_);
    }
  }
  #line 57 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(57);
  #line 57 "birch/distribution/MultivariateGaussian.birch"
  return r;
}

#line 60 "birch/distribution/MultivariateGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>> birch::type::MultivariateGaussian::graftMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "birch/distribution/MultivariateGaussian.birch"
  libbirch_function_("graftMultivariateGaussian", "birch/distribution/MultivariateGaussian.birch", 60);
  #line 61 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(61);
  #line 61 "birch/distribution/MultivariateGaussian.birch"
  this_()->prune(handler_);
  #line 62 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(62);
  #line 62 "birch/distribution/MultivariateGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinearMultivariate<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>>>> m1;
  #line 63 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(63);
  #line 63 "birch/distribution/MultivariateGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>> m2;
  #line 64 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(64);
  #line 64 "birch/distribution/MultivariateGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>> r = shared_from_this_();
  #line 67 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(67);
  #line 67 "birch/distribution/MultivariateGaussian.birch"
  if ((m1 = this_()->_u0956->graftLinearMultivariateGaussian(handler_)).query()) {
    #line 68 "birch/distribution/MultivariateGaussian.birch"
    libbirch_line_(68);
    #line 68 "birch/distribution/MultivariateGaussian.birch"
    r = birch::LinearMultivariateGaussianMultivariateGaussian(m1.get()->A, m1.get()->x, m1.get()->c, this_()->_u0931, handler_);
  } else {
    #line 69 "birch/distribution/MultivariateGaussian.birch"
    libbirch_line_(69);
    #line 69 "birch/distribution/MultivariateGaussian.birch"
    if ((m2 = this_()->_u0956->graftMultivariateGaussian(handler_)).query()) {
      #line 70 "birch/distribution/MultivariateGaussian.birch"
      libbirch_line_(70);
      #line 70 "birch/distribution/MultivariateGaussian.birch"
      r = birch::MultivariateGaussianMultivariateGaussian(m2.get(), this_()->_u0931, handler_);
    }
  }
  #line 73 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(73);
  #line 73 "birch/distribution/MultivariateGaussian.birch"
  return r;
}

#line 76 "birch/distribution/MultivariateGaussian.birch"
void birch::type::MultivariateGaussian::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "birch/distribution/MultivariateGaussian.birch"
  libbirch_function_("write", "birch/distribution/MultivariateGaussian.birch", 76);
  #line 77 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(77);
  #line 77 "birch/distribution/MultivariateGaussian.birch"
  this_()->prune(handler_);
  #line 78 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(78);
  #line 78 "birch/distribution/MultivariateGaussian.birch"
  buffer->set(birch::type::String("class"), birch::type::String("MultivariateGaussian"), handler_);
  #line 79 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(79);
  #line 79 "birch/distribution/MultivariateGaussian.birch"
  buffer->set(birch::type::String("μ"), this_()->_u0956, handler_);
  #line 80 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(80);
  #line 80 "birch/distribution/MultivariateGaussian.birch"
  buffer->set(birch::type::String("Σ"), this_()->_u0931, handler_);
}

#line 87 "birch/distribution/MultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 87 "birch/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MultivariateGaussian.birch", 87);
  #line 89 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(89);
  #line 89 "birch/distribution/MultivariateGaussian.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>>(_u0956, _u0931, handler_);
}

#line 95 "birch/distribution/MultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const birch::type::LLT& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "birch/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MultivariateGaussian.birch", 95);
  #line 96 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(96);
  #line 96 "birch/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::box(_u0931, handler_), handler_);
}

#line 102 "birch/distribution/MultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 102 "birch/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MultivariateGaussian.birch", 102);
  #line 103 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(103);
  #line 103 "birch/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), _u0931, handler_);
}

#line 109 "birch/distribution/MultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const birch::type::LLT& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 109 "birch/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MultivariateGaussian.birch", 109);
  #line 110 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(110);
  #line 110 "birch/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), birch::box(_u0931, handler_), handler_);
}

#line 116 "birch/distribution/MultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 116 "birch/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MultivariateGaussian.birch", 116);
  #line 118 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(118);
  #line 118 "birch/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931, handler_), handler_);
}

#line 124 "birch/distribution/MultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::DefaultArray<birch::type::Real,2>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 124 "birch/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MultivariateGaussian.birch", 124);
  #line 126 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(126);
  #line 126 "birch/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931, handler_), handler_);
}

#line 132 "birch/distribution/MultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 132 "birch/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MultivariateGaussian.birch", 132);
  #line 134 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(134);
  #line 134 "birch/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931, handler_), handler_);
}

#line 140 "birch/distribution/MultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::DefaultArray<birch::type::Real,2>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 140 "birch/distribution/MultivariateGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/MultivariateGaussian.birch", 140);
  #line 141 "birch/distribution/MultivariateGaussian.birch"
  libbirch_line_(141);
  #line 141 "birch/distribution/MultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931, handler_), handler_);
}

#line 4 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
birch::type::MultivariateGaussianMultivariateGaussian::MultivariateGaussianMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>& m, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& S, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
    super_type_(m->_u0956, birch::llt(birch::canonical(m->_u0931, handler_) + birch::canonical(S, handler_), handler_)),
    #line 10 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
    m(m),
    #line 15 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
    S(S) {
  //
}

#line 17 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
void birch::type::MultivariateGaussianMultivariateGaussian::update(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 17 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("update", "birch/distribution/MultivariateGaussianMultivariateGaussian.birch", 17);
  #line 18 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(18);
  #line 18 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u0931) = birch::box(birch::update_multivariate_gaussian_multivariate_gaussian(x, this_()->m->_u0956->value(handler_), this_()->m->_u0931->value(handler_), this_()->S->value(handler_), handler_), handler_);
}

#line 21 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
void birch::type::MultivariateGaussianMultivariateGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("updateLazy", "birch/distribution/MultivariateGaussianMultivariateGaussian.birch", 21);
  #line 22 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(22);
  #line 22 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u0931) = birch::update_lazy_multivariate_gaussian_multivariate_gaussian(x, this_()->m->_u0956, this_()->m->_u0931, this_()->S, handler_);
}

#line 25 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
void birch::type::MultivariateGaussianMultivariateGaussian::downdate(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("downdate", "birch/distribution/MultivariateGaussianMultivariateGaussian.birch", 25);
  #line 26 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(26);
  #line 26 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch::tie(this_()->m->_u0956, this_()->m->_u0931) = birch::box(birch::downdate_multivariate_gaussian_multivariate_gaussian(x, this_()->m->_u0956->value(handler_), this_()->m->_u0931->value(handler_), this_()->S->value(handler_), handler_), handler_);
}

#line 29 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
void birch::type::MultivariateGaussianMultivariateGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("link", "birch/distribution/MultivariateGaussianMultivariateGaussian.birch", 29);
  #line 30 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(30);
  #line 30 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
  this_()->m->setChild(shared_from_this_(), handler_);
}

#line 33 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
void birch::type::MultivariateGaussianMultivariateGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("unlink", "birch/distribution/MultivariateGaussianMultivariateGaussian.birch", 33);
  #line 34 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(34);
  #line 34 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
  this_()->m->releaseChild(shared_from_this_(), handler_);
}

#line 38 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussianMultivariateGaussian>> birch::MultivariateGaussianMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_function_("MultivariateGaussianMultivariateGaussian", "birch/distribution/MultivariateGaussianMultivariateGaussian.birch", 38);
  #line 40 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(40);
  #line 40 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussianMultivariateGaussian>> m(_u0956, _u0931);
  #line 41 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(41);
  #line 41 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
  m->link(handler_);
  #line 42 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
  libbirch_line_(42);
  #line 42 "birch/distribution/MultivariateGaussianMultivariateGaussian.birch"
  return m;
}

#line 29 "birch/distribution/MultivariateNormalInverseGamma.birch"
birch::type::MultivariateNormalInverseGamma::MultivariateNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 29 "birch/distribution/MultivariateNormalInverseGamma.birch"
    super_type_(),
    #line 34 "birch/distribution/MultivariateNormalInverseGamma.birch"
    _u0923(birch::inv(_u0931, handler_)),
    #line 39 "birch/distribution/MultivariateNormalInverseGamma.birch"
    _u0957(birch::canonical(_u0923, handler_) * _u0956),
    #line 44 "birch/distribution/MultivariateNormalInverseGamma.birch"
    _u0945(_u09632->_u0945),
    #line 49 "birch/distribution/MultivariateNormalInverseGamma.birch"
    _u0947(_u09632->_u0946 + 0.5 * birch::dot(_u0956, _u0957, handler_)),
    #line 54 "birch/distribution/MultivariateNormalInverseGamma.birch"
    _u09632(_u09632) {
  //
}

#line 56 "birch/distribution/MultivariateNormalInverseGamma.birch"
birch::type::Integer birch::type::MultivariateNormalInverseGamma::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 56 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("rows", "birch/distribution/MultivariateNormalInverseGamma.birch", 56);
  #line 57 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(57);
  #line 57 "birch/distribution/MultivariateNormalInverseGamma.birch"
  return this_()->_u0957->rows(handler_);
}

#line 60 "birch/distribution/MultivariateNormalInverseGamma.birch"
birch::type::Boolean birch::type::MultivariateNormalInverseGamma::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("supportsLazy", "birch/distribution/MultivariateNormalInverseGamma.birch", 60);
  #line 61 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(61);
  #line 61 "birch/distribution/MultivariateNormalInverseGamma.birch"
  return true;
}

#line 64 "birch/distribution/MultivariateNormalInverseGamma.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateNormalInverseGamma::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("simulate", "birch/distribution/MultivariateNormalInverseGamma.birch", 64);
  #line 65 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(65);
  #line 65 "birch/distribution/MultivariateNormalInverseGamma.birch"
  return birch::simulate_multivariate_normal_inverse_gamma(this_()->_u0957->value(handler_), this_()->_u0923->value(handler_), this_()->_u0945->value(handler_), birch::gamma_to_beta(this_()->_u0947->value(handler_), this_()->_u0957->value(handler_), this_()->_u0923->value(handler_), handler_), handler_);
}

#line 69 "birch/distribution/MultivariateNormalInverseGamma.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::MultivariateNormalInverseGamma::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("simulateLazy", "birch/distribution/MultivariateNormalInverseGamma.birch", 69);
  #line 70 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(70);
  #line 70 "birch/distribution/MultivariateNormalInverseGamma.birch"
  return birch::simulate_multivariate_normal_inverse_gamma(this_()->_u0957->get(handler_), this_()->_u0923->get(handler_), this_()->_u0945->get(handler_), birch::gamma_to_beta(this_()->_u0947->get(handler_), this_()->_u0957->get(handler_), this_()->_u0923->get(handler_), handler_), handler_);
}

#line 74 "birch/distribution/MultivariateNormalInverseGamma.birch"
birch::type::Real birch::type::MultivariateNormalInverseGamma::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 74 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("logpdf", "birch/distribution/MultivariateNormalInverseGamma.birch", 74);
  #line 75 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(75);
  #line 75 "birch/distribution/MultivariateNormalInverseGamma.birch"
  return birch::logpdf_multivariate_normal_inverse_gamma(x, this_()->_u0957->value(handler_), this_()->_u0923->value(handler_), this_()->_u0945->value(handler_), birch::gamma_to_beta(this_()->_u0947->value(handler_), this_()->_u0957->value(handler_), this_()->_u0923->value(handler_), handler_), handler_);
}

#line 79 "birch/distribution/MultivariateNormalInverseGamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::MultivariateNormalInverseGamma::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 79 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/MultivariateNormalInverseGamma.birch", 79);
  #line 80 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(80);
  #line 80 "birch/distribution/MultivariateNormalInverseGamma.birch"
  return birch::logpdf_lazy_multivariate_normal_inverse_gamma(x, this_()->_u0957, this_()->_u0923, this_()->_u0945, birch::gamma_to_beta(this_()->_u0947, this_()->_u0957, this_()->_u0923, handler_), handler_);
}

#line 84 "birch/distribution/MultivariateNormalInverseGamma.birch"
void birch::type::MultivariateNormalInverseGamma::update(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 84 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("update", "birch/distribution/MultivariateNormalInverseGamma.birch", 84);
  #line 85 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(85);
  #line 85 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch::tie(this_()->_u09632->_u0945, this_()->_u09632->_u0946) = birch::box(birch::update_multivariate_normal_inverse_gamma(x, this_()->_u0957->value(handler_), this_()->_u0923->value(handler_), this_()->_u0945->value(handler_), birch::gamma_to_beta(this_()->_u0947->value(handler_), this_()->_u0957->value(handler_), this_()->_u0923->value(handler_), handler_), handler_), handler_);
}

#line 89 "birch/distribution/MultivariateNormalInverseGamma.birch"
void birch::type::MultivariateNormalInverseGamma::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 89 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("updateLazy", "birch/distribution/MultivariateNormalInverseGamma.birch", 89);
  #line 90 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(90);
  #line 90 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch::tie(this_()->_u09632->_u0945, this_()->_u09632->_u0946) = birch::update_lazy_multivariate_normal_inverse_gamma(x, this_()->_u0957, this_()->_u0923, this_()->_u0945, birch::gamma_to_beta(this_()->_u0947, this_()->_u0957, this_()->_u0923, handler_), handler_);
}

#line 94 "birch/distribution/MultivariateNormalInverseGamma.birch"
void birch::type::MultivariateNormalInverseGamma::downdate(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 94 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("downdate", "birch/distribution/MultivariateNormalInverseGamma.birch", 94);
  #line 95 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(95);
  #line 95 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch::tie(this_()->_u09632->_u0945, this_()->_u09632->_u0946) = birch::box(birch::downdate_multivariate_normal_inverse_gamma(x, this_()->_u0957->value(handler_), this_()->_u0923->value(handler_), this_()->_u0945->value(handler_), birch::gamma_to_beta(this_()->_u0947->value(handler_), this_()->_u0957->value(handler_), this_()->_u0923->value(handler_), handler_), handler_), handler_);
}

#line 99 "birch/distribution/MultivariateNormalInverseGamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>> birch::type::MultivariateNormalInverseGamma::graftMultivariateNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 99 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("graftMultivariateNormalInverseGamma", "birch/distribution/MultivariateNormalInverseGamma.birch", 99);
  #line 101 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(101);
  #line 101 "birch/distribution/MultivariateNormalInverseGamma.birch"
  this_()->prune(handler_);
  #line 102 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(102);
  #line 102 "birch/distribution/MultivariateNormalInverseGamma.birch"
  if (this_()->_u09632 == compare) {
    #line 103 "birch/distribution/MultivariateNormalInverseGamma.birch"
    libbirch_line_(103);
    #line 103 "birch/distribution/MultivariateNormalInverseGamma.birch"
    return shared_from_this_();
  } else {
    #line 105 "birch/distribution/MultivariateNormalInverseGamma.birch"
    libbirch_line_(105);
    #line 105 "birch/distribution/MultivariateNormalInverseGamma.birch"
    return libbirch::nil;
  }
}

#line 109 "birch/distribution/MultivariateNormalInverseGamma.birch"
void birch::type::MultivariateNormalInverseGamma::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 109 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("link", "birch/distribution/MultivariateNormalInverseGamma.birch", 109);
  #line 110 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(110);
  #line 110 "birch/distribution/MultivariateNormalInverseGamma.birch"
  this_()->_u09632->setChild(shared_from_this_(), handler_);
}

#line 113 "birch/distribution/MultivariateNormalInverseGamma.birch"
void birch::type::MultivariateNormalInverseGamma::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 113 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("unlink", "birch/distribution/MultivariateNormalInverseGamma.birch", 113);
  #line 114 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(114);
  #line 114 "birch/distribution/MultivariateNormalInverseGamma.birch"
  this_()->_u09632->releaseChild(shared_from_this_(), handler_);
}

#line 117 "birch/distribution/MultivariateNormalInverseGamma.birch"
void birch::type::MultivariateNormalInverseGamma::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 117 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("write", "birch/distribution/MultivariateNormalInverseGamma.birch", 117);
  #line 118 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(118);
  #line 118 "birch/distribution/MultivariateNormalInverseGamma.birch"
  this_()->prune(handler_);
  #line 119 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(119);
  #line 119 "birch/distribution/MultivariateNormalInverseGamma.birch"
  buffer->set(birch::type::String("class"), birch::type::String("MultivariateNormalInverseGamma"), handler_);
  #line 120 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(120);
  #line 120 "birch/distribution/MultivariateNormalInverseGamma.birch"
  buffer->set(birch::type::String("μ"), birch::solve(this_()->_u0923->value(handler_), this_()->_u0957->value(handler_), handler_), handler_);
  #line 121 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(121);
  #line 121 "birch/distribution/MultivariateNormalInverseGamma.birch"
  buffer->set(birch::type::String("Σ"), birch::inv(this_()->_u0923->value(handler_), handler_), handler_);
  #line 122 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(122);
  #line 122 "birch/distribution/MultivariateNormalInverseGamma.birch"
  buffer->set(birch::type::String("α"), this_()->_u0945->value(handler_), handler_);
  #line 123 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(123);
  #line 123 "birch/distribution/MultivariateNormalInverseGamma.birch"
  buffer->set(birch::type::String("β"), birch::gamma_to_beta(this_()->_u0947->value(handler_), this_()->_u0957->value(handler_), this_()->_u0923->value(handler_), handler_), handler_);
}

#line 127 "birch/distribution/MultivariateNormalInverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>> birch::MultivariateNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 127 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("MultivariateNormalInverseGamma", "birch/distribution/MultivariateNormalInverseGamma.birch", 127);
  #line 129 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(129);
  #line 129 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>> m(_u0956, _u0931, _u09632);
  #line 130 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(130);
  #line 130 "birch/distribution/MultivariateNormalInverseGamma.birch"
  m->link(handler_);
  #line 131 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(131);
  #line 131 "birch/distribution/MultivariateNormalInverseGamma.birch"
  return m;
}

#line 138 "birch/distribution/MultivariateNormalInverseGamma.birch"
birch::type::Real birch::gamma_to_beta(const birch::type::Real& _u0947, const libbirch::DefaultArray<birch::type::Real,1>& _u0957, const birch::type::LLT& _u0923, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 138 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("gamma_to_beta", "birch/distribution/MultivariateNormalInverseGamma.birch", 138);
  #line 139 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(139);
  #line 139 "birch/distribution/MultivariateNormalInverseGamma.birch"
  return _u0947 - 0.5 * birch::dot(_u0957, birch::solve(_u0923, _u0957, handler_), handler_);
}

#line 146 "birch/distribution/MultivariateNormalInverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>> birch::gamma_to_beta(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0947, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0923, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 146 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_function_("gamma_to_beta", "birch/distribution/MultivariateNormalInverseGamma.birch", 146);
  #line 148 "birch/distribution/MultivariateNormalInverseGamma.birch"
  libbirch_line_(148);
  #line 148 "birch/distribution/MultivariateNormalInverseGamma.birch"
  return _u0947 - 0.5 * birch::dot(_u0957, birch::solve(_u0923, _u0957, handler_), handler_);
}

#line 4 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::MultivariateNormalInverseGammaMultivariateGaussian::MultivariateNormalInverseGammaMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
    super_type_(),
    #line 9 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
    _u0956(_u0956) {
  //
}

#line 11 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::Integer birch::type::MultivariateNormalInverseGammaMultivariateGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("rows", "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 11);
  #line 12 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(12);
  #line 12 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  return this_()->_u0956->rows(handler_);
}

#line 15 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::Boolean birch::type::MultivariateNormalInverseGammaMultivariateGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("supportsLazy", "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 15);
  #line 16 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(16);
  #line 16 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  return true;
}

#line 19 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::MultivariateNormalInverseGammaMultivariateGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("simulate", "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 19);
  #line 20 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(20);
  #line 20 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  return birch::simulate_multivariate_normal_inverse_gamma_multivariate_gaussian(this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_);
}

#line 24 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::MultivariateNormalInverseGammaMultivariateGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("simulateLazy", "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 24);
  #line 25 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(25);
  #line 25 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  return birch::simulate_multivariate_normal_inverse_gamma_multivariate_gaussian(this_()->_u0956->_u0957->get(handler_), this_()->_u0956->_u0923->get(handler_), this_()->_u0956->_u0945->get(handler_), this_()->_u0956->_u0947->get(handler_), handler_);
}

#line 29 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
birch::type::Real birch::type::MultivariateNormalInverseGammaMultivariateGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("logpdf", "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 29);
  #line 30 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(30);
  #line 30 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  return birch::logpdf_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_);
}

#line 34 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::MultivariateNormalInverseGammaMultivariateGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 34);
  #line 35 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(35);
  #line 35 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  return birch::logpdf_lazy_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->_u0956->_u0945, this_()->_u0956->_u0947, handler_);
}

#line 39 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::MultivariateNormalInverseGammaMultivariateGaussian::update(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("update", "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 39);
  #line 40 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(40);
  #line 40 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->_u0956->_u0945, this_()->_u0956->_u0947) = birch::box(birch::update_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_), handler_);
}

#line 44 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::MultivariateNormalInverseGammaMultivariateGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("updateLazy", "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 44);
  #line 45 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(45);
  #line 45 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->_u0956->_u0945, this_()->_u0956->_u0947) = birch::update_lazy_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->_u0956->_u0945, this_()->_u0956->_u0947, handler_);
}

#line 49 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::MultivariateNormalInverseGammaMultivariateGaussian::downdate(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("downdate", "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 49);
  #line 50 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(50);
  #line 50 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0957, this_()->_u0956->_u0923, this_()->_u0956->_u0945, this_()->_u0956->_u0947) = birch::box(birch::downdate_multivariate_normal_inverse_gamma_multivariate_gaussian(x, this_()->_u0956->_u0957->value(handler_), this_()->_u0956->_u0923->value(handler_), this_()->_u0956->_u0945->value(handler_), this_()->_u0956->_u0947->value(handler_), handler_), handler_);
}

#line 54 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::MultivariateNormalInverseGammaMultivariateGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("link", "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 54);
  #line 55 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(55);
  #line 55 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  this_()->_u0956->setChild(shared_from_this_(), handler_);
}

#line 58 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
void birch::type::MultivariateNormalInverseGammaMultivariateGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("unlink", "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 58);
  #line 59 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(59);
  #line 59 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  this_()->_u0956->releaseChild(shared_from_this_(), handler_);
}

#line 63 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGammaMultivariateGaussian>> birch::MultivariateNormalInverseGammaMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 63 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_function_("MultivariateNormalInverseGammaMultivariateGaussian", "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch", 63);
  #line 66 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(66);
  #line 66 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGammaMultivariateGaussian>> m(_u0956);
  #line 67 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(67);
  #line 67 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  m->link(handler_);
  #line 68 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  libbirch_line_(68);
  #line 68 "birch/distribution/MultivariateNormalInverseGammaMultivariateGaussian.birch"
  return m;
}

#line 1 "birch/distribution/NegativeBinomial.birch"
birch::type::NegativeBinomial::NegativeBinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/distribution/NegativeBinomial.birch"
    super_type_(),
    #line 9 "birch/distribution/NegativeBinomial.birch"
    k(k),
    #line 14 "birch/distribution/NegativeBinomial.birch"
    _u0961(_u0961) {
  //
}

#line 16 "birch/distribution/NegativeBinomial.birch"
birch::type::Boolean birch::type::NegativeBinomial::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "birch/distribution/NegativeBinomial.birch"
  libbirch_function_("supportsLazy", "birch/distribution/NegativeBinomial.birch", 16);
  #line 17 "birch/distribution/NegativeBinomial.birch"
  libbirch_line_(17);
  #line 17 "birch/distribution/NegativeBinomial.birch"
  return true;
}

#line 20 "birch/distribution/NegativeBinomial.birch"
birch::type::Integer birch::type::NegativeBinomial::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "birch/distribution/NegativeBinomial.birch"
  libbirch_function_("simulate", "birch/distribution/NegativeBinomial.birch", 20);
  #line 21 "birch/distribution/NegativeBinomial.birch"
  libbirch_line_(21);
  #line 21 "birch/distribution/NegativeBinomial.birch"
  if (this_()->value.query()) {
    #line 22 "birch/distribution/NegativeBinomial.birch"
    libbirch_line_(22);
    #line 22 "birch/distribution/NegativeBinomial.birch"
    return this_()->value.get();
  } else {
    #line 24 "birch/distribution/NegativeBinomial.birch"
    libbirch_line_(24);
    #line 24 "birch/distribution/NegativeBinomial.birch"
    return birch::simulate_negative_binomial(this_()->k->value(handler_), this_()->_u0961->value(handler_), handler_);
  }
}

#line 28 "birch/distribution/NegativeBinomial.birch"
libbirch::Optional<birch::type::Integer> birch::type::NegativeBinomial::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "birch/distribution/NegativeBinomial.birch"
  libbirch_function_("simulateLazy", "birch/distribution/NegativeBinomial.birch", 28);
  #line 29 "birch/distribution/NegativeBinomial.birch"
  libbirch_line_(29);
  #line 29 "birch/distribution/NegativeBinomial.birch"
  if (this_()->value.query()) {
    #line 30 "birch/distribution/NegativeBinomial.birch"
    libbirch_line_(30);
    #line 30 "birch/distribution/NegativeBinomial.birch"
    return this_()->value.get();
  } else {
    #line 32 "birch/distribution/NegativeBinomial.birch"
    libbirch_line_(32);
    #line 32 "birch/distribution/NegativeBinomial.birch"
    return birch::simulate_negative_binomial(this_()->k->get(handler_), this_()->_u0961->get(handler_), handler_);
  }
}

#line 36 "birch/distribution/NegativeBinomial.birch"
birch::type::Real birch::type::NegativeBinomial::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "birch/distribution/NegativeBinomial.birch"
  libbirch_function_("logpdf", "birch/distribution/NegativeBinomial.birch", 36);
  #line 37 "birch/distribution/NegativeBinomial.birch"
  libbirch_line_(37);
  #line 37 "birch/distribution/NegativeBinomial.birch"
  return birch::logpdf_negative_binomial(x, this_()->k->value(handler_), this_()->_u0961->value(handler_), handler_);
}

#line 40 "birch/distribution/NegativeBinomial.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::NegativeBinomial::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "birch/distribution/NegativeBinomial.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/NegativeBinomial.birch", 40);
  #line 41 "birch/distribution/NegativeBinomial.birch"
  libbirch_line_(41);
  #line 41 "birch/distribution/NegativeBinomial.birch"
  return birch::logpdf_lazy_negative_binomial(x, this_()->k, this_()->_u0961, handler_);
}

#line 44 "birch/distribution/NegativeBinomial.birch"
libbirch::Optional<birch::type::Real> birch::type::NegativeBinomial::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "birch/distribution/NegativeBinomial.birch"
  libbirch_function_("cdf", "birch/distribution/NegativeBinomial.birch", 44);
  #line 45 "birch/distribution/NegativeBinomial.birch"
  libbirch_line_(45);
  #line 45 "birch/distribution/NegativeBinomial.birch"
  return birch::cdf_negative_binomial(x, this_()->k->value(handler_), this_()->_u0961->value(handler_), handler_);
}

#line 48 "birch/distribution/NegativeBinomial.birch"
libbirch::Optional<birch::type::Integer> birch::type::NegativeBinomial::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "birch/distribution/NegativeBinomial.birch"
  libbirch_function_("quantile", "birch/distribution/NegativeBinomial.birch", 48);
  #line 49 "birch/distribution/NegativeBinomial.birch"
  libbirch_line_(49);
  #line 49 "birch/distribution/NegativeBinomial.birch"
  return birch::quantile_negative_binomial(P, this_()->k->value(handler_), this_()->_u0961->value(handler_), handler_);
}

#line 52 "birch/distribution/NegativeBinomial.birch"
libbirch::Optional<birch::type::Integer> birch::type::NegativeBinomial::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "birch/distribution/NegativeBinomial.birch"
  libbirch_function_("lower", "birch/distribution/NegativeBinomial.birch", 52);
  #line 53 "birch/distribution/NegativeBinomial.birch"
  libbirch_line_(53);
  #line 53 "birch/distribution/NegativeBinomial.birch"
  return birch::type::Integer(0);
}

#line 56 "birch/distribution/NegativeBinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> birch::type::NegativeBinomial::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 56 "birch/distribution/NegativeBinomial.birch"
  libbirch_function_("graft", "birch/distribution/NegativeBinomial.birch", 56);
  #line 57 "birch/distribution/NegativeBinomial.birch"
  libbirch_line_(57);
  #line 57 "birch/distribution/NegativeBinomial.birch"
  this_()->prune(handler_);
  #line 58 "birch/distribution/NegativeBinomial.birch"
  libbirch_line_(58);
  #line 58 "birch/distribution/NegativeBinomial.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Beta>>> _u09611;
  #line 59 "birch/distribution/NegativeBinomial.birch"
  libbirch_line_(59);
  #line 59 "birch/distribution/NegativeBinomial.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> r = shared_from_this_();
  #line 62 "birch/distribution/NegativeBinomial.birch"
  libbirch_line_(62);
  #line 62 "birch/distribution/NegativeBinomial.birch"
  if ((_u09611 = this_()->_u0961->graftBeta(handler_)).query()) {
    #line 63 "birch/distribution/NegativeBinomial.birch"
    libbirch_line_(63);
    #line 63 "birch/distribution/NegativeBinomial.birch"
    r = birch::BetaNegativeBinomial(this_()->k, _u09611.get(), handler_);
  }
  #line 66 "birch/distribution/NegativeBinomial.birch"
  libbirch_line_(66);
  #line 66 "birch/distribution/NegativeBinomial.birch"
  return r;
}

#line 69 "birch/distribution/NegativeBinomial.birch"
void birch::type::NegativeBinomial::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "birch/distribution/NegativeBinomial.birch"
  libbirch_function_("write", "birch/distribution/NegativeBinomial.birch", 69);
  #line 70 "birch/distribution/NegativeBinomial.birch"
  libbirch_line_(70);
  #line 70 "birch/distribution/NegativeBinomial.birch"
  this_()->prune(handler_);
  #line 71 "birch/distribution/NegativeBinomial.birch"
  libbirch_line_(71);
  #line 71 "birch/distribution/NegativeBinomial.birch"
  buffer->set(birch::type::String("class"), birch::type::String("NegativeBinomial"), handler_);
  #line 72 "birch/distribution/NegativeBinomial.birch"
  libbirch_line_(72);
  #line 72 "birch/distribution/NegativeBinomial.birch"
  buffer->set(birch::type::String("k"), this_()->k, handler_);
  #line 73 "birch/distribution/NegativeBinomial.birch"
  libbirch_line_(73);
  #line 73 "birch/distribution/NegativeBinomial.birch"
  buffer->set(birch::type::String("ρ"), this_()->_u0961, handler_);
}

#line 80 "birch/distribution/NegativeBinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::NegativeBinomial>> birch::NegativeBinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 80 "birch/distribution/NegativeBinomial.birch"
  libbirch_function_("NegativeBinomial", "birch/distribution/NegativeBinomial.birch", 80);
  #line 82 "birch/distribution/NegativeBinomial.birch"
  libbirch_line_(82);
  #line 82 "birch/distribution/NegativeBinomial.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::NegativeBinomial>>>(k, _u0961, handler_);
}

#line 88 "birch/distribution/NegativeBinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::NegativeBinomial>> birch::NegativeBinomial(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& k, const birch::type::Real& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 88 "birch/distribution/NegativeBinomial.birch"
  libbirch_function_("NegativeBinomial", "birch/distribution/NegativeBinomial.birch", 88);
  #line 89 "birch/distribution/NegativeBinomial.birch"
  libbirch_line_(89);
  #line 89 "birch/distribution/NegativeBinomial.birch"
  return birch::NegativeBinomial(k, birch::box(_u0961, handler_), handler_);
}

#line 95 "birch/distribution/NegativeBinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::NegativeBinomial>> birch::NegativeBinomial(const birch::type::Integer& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "birch/distribution/NegativeBinomial.birch"
  libbirch_function_("NegativeBinomial", "birch/distribution/NegativeBinomial.birch", 95);
  #line 96 "birch/distribution/NegativeBinomial.birch"
  libbirch_line_(96);
  #line 96 "birch/distribution/NegativeBinomial.birch"
  return birch::NegativeBinomial(birch::box(k, handler_), _u0961, handler_);
}

#line 102 "birch/distribution/NegativeBinomial.birch"
libbirch::Lazy<libbirch::Shared<birch::type::NegativeBinomial>> birch::NegativeBinomial(const birch::type::Integer& k, const birch::type::Real& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 102 "birch/distribution/NegativeBinomial.birch"
  libbirch_function_("NegativeBinomial", "birch/distribution/NegativeBinomial.birch", 102);
  #line 103 "birch/distribution/NegativeBinomial.birch"
  libbirch_line_(103);
  #line 103 "birch/distribution/NegativeBinomial.birch"
  return birch::NegativeBinomial(birch::box(k, handler_), birch::box(_u0961, handler_), handler_);
}

#line 28 "birch/distribution/NormalInverseGamma.birch"
birch::type::NormalInverseGamma::NormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a2, const libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 28 "birch/distribution/NormalInverseGamma.birch"
    super_type_(),
    #line 33 "birch/distribution/NormalInverseGamma.birch"
    _u0956(_u0956),
    #line 38 "birch/distribution/NormalInverseGamma.birch"
    _u0955(1.0 / a2),
    #line 43 "birch/distribution/NormalInverseGamma.birch"
    _u09632(_u09632) {
  //
}

#line 45 "birch/distribution/NormalInverseGamma.birch"
birch::type::Boolean birch::type::NormalInverseGamma::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "birch/distribution/NormalInverseGamma.birch"
  libbirch_function_("supportsLazy", "birch/distribution/NormalInverseGamma.birch", 45);
  #line 46 "birch/distribution/NormalInverseGamma.birch"
  libbirch_line_(46);
  #line 46 "birch/distribution/NormalInverseGamma.birch"
  return true;
}

#line 49 "birch/distribution/NormalInverseGamma.birch"
birch::type::Real birch::type::NormalInverseGamma::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "birch/distribution/NormalInverseGamma.birch"
  libbirch_function_("simulate", "birch/distribution/NormalInverseGamma.birch", 49);
  #line 50 "birch/distribution/NormalInverseGamma.birch"
  libbirch_line_(50);
  #line 50 "birch/distribution/NormalInverseGamma.birch"
  return birch::simulate_normal_inverse_gamma(this_()->_u0956->value(handler_), 1.0 / this_()->_u0955->value(handler_), this_()->_u09632->_u0945->value(handler_), this_()->_u09632->_u0946->value(handler_), handler_);
}

#line 53 "birch/distribution/NormalInverseGamma.birch"
libbirch::Optional<birch::type::Real> birch::type::NormalInverseGamma::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "birch/distribution/NormalInverseGamma.birch"
  libbirch_function_("simulateLazy", "birch/distribution/NormalInverseGamma.birch", 53);
  #line 54 "birch/distribution/NormalInverseGamma.birch"
  libbirch_line_(54);
  #line 54 "birch/distribution/NormalInverseGamma.birch"
  return birch::simulate_normal_inverse_gamma(this_()->_u0956->get(handler_), 1.0 / this_()->_u0955->get(handler_), this_()->_u09632->_u0945->get(handler_), this_()->_u09632->_u0946->get(handler_), handler_);
}

#line 57 "birch/distribution/NormalInverseGamma.birch"
birch::type::Real birch::type::NormalInverseGamma::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 57 "birch/distribution/NormalInverseGamma.birch"
  libbirch_function_("logpdf", "birch/distribution/NormalInverseGamma.birch", 57);
  #line 58 "birch/distribution/NormalInverseGamma.birch"
  libbirch_line_(58);
  #line 58 "birch/distribution/NormalInverseGamma.birch"
  return birch::logpdf_normal_inverse_gamma(x, this_()->_u0956->value(handler_), 1.0 / this_()->_u0955->value(handler_), this_()->_u09632->_u0945->value(handler_), this_()->_u09632->_u0946->value(handler_), handler_);
}

#line 61 "birch/distribution/NormalInverseGamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::NormalInverseGamma::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "birch/distribution/NormalInverseGamma.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/NormalInverseGamma.birch", 61);
  #line 62 "birch/distribution/NormalInverseGamma.birch"
  libbirch_line_(62);
  #line 62 "birch/distribution/NormalInverseGamma.birch"
  return birch::logpdf_lazy_normal_inverse_gamma(x, this_()->_u0956, 1.0 / this_()->_u0955, this_()->_u09632->_u0945, this_()->_u09632->_u0946, handler_);
}

#line 65 "birch/distribution/NormalInverseGamma.birch"
void birch::type::NormalInverseGamma::update(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "birch/distribution/NormalInverseGamma.birch"
  libbirch_function_("update", "birch/distribution/NormalInverseGamma.birch", 65);
  #line 66 "birch/distribution/NormalInverseGamma.birch"
  libbirch_line_(66);
  #line 66 "birch/distribution/NormalInverseGamma.birch"
  libbirch::tie(this_()->_u09632->_u0945, this_()->_u09632->_u0946) = birch::box(birch::update_normal_inverse_gamma(x, this_()->_u0956->value(handler_), this_()->_u0955->value(handler_), this_()->_u09632->_u0945->value(handler_), this_()->_u09632->_u0946->value(handler_), handler_), handler_);
}

#line 69 "birch/distribution/NormalInverseGamma.birch"
void birch::type::NormalInverseGamma::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "birch/distribution/NormalInverseGamma.birch"
  libbirch_function_("updateLazy", "birch/distribution/NormalInverseGamma.birch", 69);
  #line 70 "birch/distribution/NormalInverseGamma.birch"
  libbirch_line_(70);
  #line 70 "birch/distribution/NormalInverseGamma.birch"
  libbirch::tie(this_()->_u09632->_u0945, this_()->_u09632->_u0946) = birch::update_lazy_normal_inverse_gamma(x, this_()->_u0956, this_()->_u0955, this_()->_u09632->_u0945, this_()->_u09632->_u0946, handler_);
}

#line 73 "birch/distribution/NormalInverseGamma.birch"
void birch::type::NormalInverseGamma::downdate(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 73 "birch/distribution/NormalInverseGamma.birch"
  libbirch_function_("downdate", "birch/distribution/NormalInverseGamma.birch", 73);
  #line 74 "birch/distribution/NormalInverseGamma.birch"
  libbirch_line_(74);
  #line 74 "birch/distribution/NormalInverseGamma.birch"
  libbirch::tie(this_()->_u09632->_u0945, this_()->_u09632->_u0946) = birch::box(birch::downdate_normal_inverse_gamma(x, this_()->_u0956->value(handler_), this_()->_u0955->value(handler_), this_()->_u09632->_u0945->value(handler_), this_()->_u09632->_u0946->value(handler_), handler_), handler_);
}

#line 77 "birch/distribution/NormalInverseGamma.birch"
libbirch::Optional<birch::type::Real> birch::type::NormalInverseGamma::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 77 "birch/distribution/NormalInverseGamma.birch"
  libbirch_function_("cdf", "birch/distribution/NormalInverseGamma.birch", 77);
  #line 78 "birch/distribution/NormalInverseGamma.birch"
  libbirch_line_(78);
  #line 78 "birch/distribution/NormalInverseGamma.birch"
  return birch::cdf_normal_inverse_gamma(x, this_()->_u0956->value(handler_), 1.0 / this_()->_u0955->value(handler_), this_()->_u09632->_u0945->value(handler_), this_()->_u09632->_u0946->value(handler_), handler_);
}

#line 81 "birch/distribution/NormalInverseGamma.birch"
libbirch::Optional<birch::type::Real> birch::type::NormalInverseGamma::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "birch/distribution/NormalInverseGamma.birch"
  libbirch_function_("quantile", "birch/distribution/NormalInverseGamma.birch", 81);
  #line 82 "birch/distribution/NormalInverseGamma.birch"
  libbirch_line_(82);
  #line 82 "birch/distribution/NormalInverseGamma.birch"
  return birch::quantile_normal_inverse_gamma(P, this_()->_u0956->value(handler_), 1.0 / this_()->_u0955->value(handler_), this_()->_u09632->_u0945->value(handler_), this_()->_u09632->_u0946->value(handler_), handler_);
}

#line 85 "birch/distribution/NormalInverseGamma.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>> birch::type::NormalInverseGamma::graftNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 85 "birch/distribution/NormalInverseGamma.birch"
  libbirch_function_("graftNormalInverseGamma", "birch/distribution/NormalInverseGamma.birch", 85);
  #line 87 "birch/distribution/NormalInverseGamma.birch"
  libbirch_line_(87);
  #line 87 "birch/distribution/NormalInverseGamma.birch"
  this_()->prune(handler_);
  #line 88 "birch/distribution/NormalInverseGamma.birch"
  libbirch_line_(88);
  #line 88 "birch/distribution/NormalInverseGamma.birch"
  if (this_()->_u09632 == compare) {
    #line 89 "birch/distribution/NormalInverseGamma.birch"
    libbirch_line_(89);
    #line 89 "birch/distribution/NormalInverseGamma.birch"
    return shared_from_this_();
  } else {
    #line 91 "birch/distribution/NormalInverseGamma.birch"
    libbirch_line_(91);
    #line 91 "birch/distribution/NormalInverseGamma.birch"
    return libbirch::nil;
  }
}

#line 95 "birch/distribution/NormalInverseGamma.birch"
void birch::type::NormalInverseGamma::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "birch/distribution/NormalInverseGamma.birch"
  libbirch_function_("link", "birch/distribution/NormalInverseGamma.birch", 95);
  #line 96 "birch/distribution/NormalInverseGamma.birch"
  libbirch_line_(96);
  #line 96 "birch/distribution/NormalInverseGamma.birch"
  this_()->_u09632->setChild(shared_from_this_(), handler_);
}

#line 99 "birch/distribution/NormalInverseGamma.birch"
void birch::type::NormalInverseGamma::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 99 "birch/distribution/NormalInverseGamma.birch"
  libbirch_function_("unlink", "birch/distribution/NormalInverseGamma.birch", 99);
  #line 100 "birch/distribution/NormalInverseGamma.birch"
  libbirch_line_(100);
  #line 100 "birch/distribution/NormalInverseGamma.birch"
  this_()->_u09632->releaseChild(shared_from_this_(), handler_);
}

#line 103 "birch/distribution/NormalInverseGamma.birch"
void birch::type::NormalInverseGamma::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 103 "birch/distribution/NormalInverseGamma.birch"
  libbirch_function_("write", "birch/distribution/NormalInverseGamma.birch", 103);
  #line 104 "birch/distribution/NormalInverseGamma.birch"
  libbirch_line_(104);
  #line 104 "birch/distribution/NormalInverseGamma.birch"
  this_()->prune(handler_);
  #line 105 "birch/distribution/NormalInverseGamma.birch"
  libbirch_line_(105);
  #line 105 "birch/distribution/NormalInverseGamma.birch"
  buffer->set(birch::type::String("class"), birch::type::String("NormalInverseGamma"), handler_);
  #line 106 "birch/distribution/NormalInverseGamma.birch"
  libbirch_line_(106);
  #line 106 "birch/distribution/NormalInverseGamma.birch"
  buffer->set(birch::type::String("μ"), this_()->_u0956, handler_);
  #line 107 "birch/distribution/NormalInverseGamma.birch"
  libbirch_line_(107);
  #line 107 "birch/distribution/NormalInverseGamma.birch"
  buffer->set(birch::type::String("a2"), 1.0 / this_()->_u0955, handler_);
  #line 108 "birch/distribution/NormalInverseGamma.birch"
  libbirch_line_(108);
  #line 108 "birch/distribution/NormalInverseGamma.birch"
  buffer->set(birch::type::String("α"), this_()->_u09632->_u0945, handler_);
  #line 109 "birch/distribution/NormalInverseGamma.birch"
  libbirch_line_(109);
  #line 109 "birch/distribution/NormalInverseGamma.birch"
  buffer->set(birch::type::String("β"), this_()->_u09632->_u0946, handler_);
}

#line 113 "birch/distribution/NormalInverseGamma.birch"
libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>> birch::NormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a2, const libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 113 "birch/distribution/NormalInverseGamma.birch"
  libbirch_function_("NormalInverseGamma", "birch/distribution/NormalInverseGamma.birch", 113);
  #line 115 "birch/distribution/NormalInverseGamma.birch"
  libbirch_line_(115);
  #line 115 "birch/distribution/NormalInverseGamma.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>> m(_u0956, a2, _u09632);
  #line 116 "birch/distribution/NormalInverseGamma.birch"
  libbirch_line_(116);
  #line 116 "birch/distribution/NormalInverseGamma.birch"
  m->link(handler_);
  #line 117 "birch/distribution/NormalInverseGamma.birch"
  libbirch_line_(117);
  #line 117 "birch/distribution/NormalInverseGamma.birch"
  return m;
}

#line 4 "birch/distribution/NormalInverseGammaGaussian.birch"
birch::type::NormalInverseGammaGaussian::NormalInverseGammaGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/NormalInverseGammaGaussian.birch"
    super_type_(),
    #line 9 "birch/distribution/NormalInverseGammaGaussian.birch"
    _u0956(_u0956) {
  //
}

#line 11 "birch/distribution/NormalInverseGammaGaussian.birch"
birch::type::Boolean birch::type::NormalInverseGammaGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 11 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("supportsLazy", "birch/distribution/NormalInverseGammaGaussian.birch", 11);
  #line 12 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(12);
  #line 12 "birch/distribution/NormalInverseGammaGaussian.birch"
  return true;
}

#line 15 "birch/distribution/NormalInverseGammaGaussian.birch"
birch::type::Real birch::type::NormalInverseGammaGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("simulate", "birch/distribution/NormalInverseGammaGaussian.birch", 15);
  #line 16 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(16);
  #line 16 "birch/distribution/NormalInverseGammaGaussian.birch"
  return birch::simulate_normal_inverse_gamma_gaussian(this_()->_u0956->_u0956->value(handler_), 1.0 / this_()->_u0956->_u0955->value(handler_), this_()->_u0956->_u09632->_u0945->value(handler_), this_()->_u0956->_u09632->_u0946->value(handler_), handler_);
}

#line 20 "birch/distribution/NormalInverseGammaGaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::NormalInverseGammaGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("simulateLazy", "birch/distribution/NormalInverseGammaGaussian.birch", 20);
  #line 21 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(21);
  #line 21 "birch/distribution/NormalInverseGammaGaussian.birch"
  return birch::simulate_normal_inverse_gamma_gaussian(this_()->_u0956->_u0956->get(handler_), 1.0 / this_()->_u0956->_u0955->get(handler_), this_()->_u0956->_u09632->_u0945->get(handler_), this_()->_u0956->_u09632->_u0946->get(handler_), handler_);
}

#line 25 "birch/distribution/NormalInverseGammaGaussian.birch"
birch::type::Real birch::type::NormalInverseGammaGaussian::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("logpdf", "birch/distribution/NormalInverseGammaGaussian.birch", 25);
  #line 26 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(26);
  #line 26 "birch/distribution/NormalInverseGammaGaussian.birch"
  return birch::logpdf_normal_inverse_gamma_gaussian(x, this_()->_u0956->_u0956->value(handler_), 1.0 / this_()->_u0956->_u0955->value(handler_), this_()->_u0956->_u09632->_u0945->value(handler_), this_()->_u0956->_u09632->_u0946->value(handler_), handler_);
}

#line 30 "birch/distribution/NormalInverseGammaGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::NormalInverseGammaGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/NormalInverseGammaGaussian.birch", 30);
  #line 31 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(31);
  #line 31 "birch/distribution/NormalInverseGammaGaussian.birch"
  return birch::logpdf_lazy_normal_inverse_gamma_gaussian(x, this_()->_u0956->_u0956, 1.0 / this_()->_u0956->_u0955, this_()->_u0956->_u09632->_u0945, this_()->_u0956->_u09632->_u0946, handler_);
}

#line 35 "birch/distribution/NormalInverseGammaGaussian.birch"
void birch::type::NormalInverseGammaGaussian::update(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("update", "birch/distribution/NormalInverseGammaGaussian.birch", 35);
  #line 36 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(36);
  #line 36 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0956, this_()->_u0956->_u0955, this_()->_u0956->_u09632->_u0945, this_()->_u0956->_u09632->_u0946) = birch::box(birch::update_normal_inverse_gamma_gaussian(x, this_()->_u0956->_u0956->value(handler_), this_()->_u0956->_u0955->value(handler_), this_()->_u0956->_u09632->_u0945->value(handler_), this_()->_u0956->_u09632->_u0946->value(handler_), handler_), handler_);
}

#line 40 "birch/distribution/NormalInverseGammaGaussian.birch"
void birch::type::NormalInverseGammaGaussian::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("updateLazy", "birch/distribution/NormalInverseGammaGaussian.birch", 40);
  #line 41 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(41);
  #line 41 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0956, this_()->_u0956->_u0955, this_()->_u0956->_u09632->_u0945, this_()->_u0956->_u09632->_u0946) = birch::update_lazy_normal_inverse_gamma_gaussian(x, this_()->_u0956->_u0956, this_()->_u0956->_u0955, this_()->_u0956->_u09632->_u0945, this_()->_u0956->_u09632->_u0946, handler_);
}

#line 45 "birch/distribution/NormalInverseGammaGaussian.birch"
void birch::type::NormalInverseGammaGaussian::downdate(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("downdate", "birch/distribution/NormalInverseGammaGaussian.birch", 45);
  #line 46 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(46);
  #line 46 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch::tie(this_()->_u0956->_u0956, this_()->_u0956->_u0955, this_()->_u0956->_u09632->_u0945, this_()->_u0956->_u09632->_u0946) = birch::box(birch::downdate_normal_inverse_gamma_gaussian(x, this_()->_u0956->_u0956->value(handler_), this_()->_u0956->_u0955->value(handler_), this_()->_u0956->_u09632->_u0945->value(handler_), this_()->_u0956->_u09632->_u0946->value(handler_), handler_), handler_);
}

#line 50 "birch/distribution/NormalInverseGammaGaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::NormalInverseGammaGaussian::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("cdf", "birch/distribution/NormalInverseGammaGaussian.birch", 50);
  #line 51 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(51);
  #line 51 "birch/distribution/NormalInverseGammaGaussian.birch"
  return birch::cdf_normal_inverse_gamma_gaussian(x, this_()->_u0956->_u0956->value(handler_), 1.0 / this_()->_u0956->_u0955->value(handler_), this_()->_u0956->_u09632->_u0945->value(handler_), this_()->_u0956->_u09632->_u0946->value(handler_), handler_);
}

#line 55 "birch/distribution/NormalInverseGammaGaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::NormalInverseGammaGaussian::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 55 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("quantile", "birch/distribution/NormalInverseGammaGaussian.birch", 55);
  #line 56 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(56);
  #line 56 "birch/distribution/NormalInverseGammaGaussian.birch"
  return birch::quantile_normal_inverse_gamma_gaussian(P, this_()->_u0956->_u0956->value(handler_), 1.0 / this_()->_u0956->_u0955->value(handler_), this_()->_u0956->_u09632->_u0945->value(handler_), this_()->_u0956->_u09632->_u0946->value(handler_), handler_);
}

#line 60 "birch/distribution/NormalInverseGammaGaussian.birch"
void birch::type::NormalInverseGammaGaussian::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("link", "birch/distribution/NormalInverseGammaGaussian.birch", 60);
  #line 61 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(61);
  #line 61 "birch/distribution/NormalInverseGammaGaussian.birch"
  this_()->_u0956->setChild(shared_from_this_(), handler_);
}

#line 64 "birch/distribution/NormalInverseGammaGaussian.birch"
void birch::type::NormalInverseGammaGaussian::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("unlink", "birch/distribution/NormalInverseGammaGaussian.birch", 64);
  #line 65 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(65);
  #line 65 "birch/distribution/NormalInverseGammaGaussian.birch"
  this_()->_u0956->releaseChild(shared_from_this_(), handler_);
}

#line 69 "birch/distribution/NormalInverseGammaGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGammaGaussian>> birch::NormalInverseGammaGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_function_("NormalInverseGammaGaussian", "birch/distribution/NormalInverseGammaGaussian.birch", 69);
  #line 71 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(71);
  #line 71 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGammaGaussian>> m(_u0956);
  #line 72 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(72);
  #line 72 "birch/distribution/NormalInverseGammaGaussian.birch"
  m->link(handler_);
  #line 73 "birch/distribution/NormalInverseGammaGaussian.birch"
  libbirch_line_(73);
  #line 73 "birch/distribution/NormalInverseGammaGaussian.birch"
  return m;
}

#line 1 "birch/distribution/Poisson.birch"
birch::type::Poisson::Poisson(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/distribution/Poisson.birch"
    super_type_(),
    #line 8 "birch/distribution/Poisson.birch"
    _u0955(_u0955) {
  //
}

#line 10 "birch/distribution/Poisson.birch"
birch::type::Boolean birch::type::Poisson::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "birch/distribution/Poisson.birch"
  libbirch_function_("supportsLazy", "birch/distribution/Poisson.birch", 10);
  #line 11 "birch/distribution/Poisson.birch"
  libbirch_line_(11);
  #line 11 "birch/distribution/Poisson.birch"
  return true;
}

#line 14 "birch/distribution/Poisson.birch"
birch::type::Integer birch::type::Poisson::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "birch/distribution/Poisson.birch"
  libbirch_function_("simulate", "birch/distribution/Poisson.birch", 14);
  #line 15 "birch/distribution/Poisson.birch"
  libbirch_line_(15);
  #line 15 "birch/distribution/Poisson.birch"
  if (this_()->value.query()) {
    #line 16 "birch/distribution/Poisson.birch"
    libbirch_line_(16);
    #line 16 "birch/distribution/Poisson.birch"
    return this_()->value.get();
  } else {
    #line 18 "birch/distribution/Poisson.birch"
    libbirch_line_(18);
    #line 18 "birch/distribution/Poisson.birch"
    return birch::simulate_poisson(this_()->_u0955->value(handler_), handler_);
  }
}

#line 22 "birch/distribution/Poisson.birch"
libbirch::Optional<birch::type::Integer> birch::type::Poisson::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "birch/distribution/Poisson.birch"
  libbirch_function_("simulateLazy", "birch/distribution/Poisson.birch", 22);
  #line 23 "birch/distribution/Poisson.birch"
  libbirch_line_(23);
  #line 23 "birch/distribution/Poisson.birch"
  if (this_()->value.query()) {
    #line 24 "birch/distribution/Poisson.birch"
    libbirch_line_(24);
    #line 24 "birch/distribution/Poisson.birch"
    return this_()->value.get();
  } else {
    #line 26 "birch/distribution/Poisson.birch"
    libbirch_line_(26);
    #line 26 "birch/distribution/Poisson.birch"
    return birch::simulate_poisson(this_()->_u0955->get(handler_), handler_);
  }
}

#line 30 "birch/distribution/Poisson.birch"
birch::type::Real birch::type::Poisson::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "birch/distribution/Poisson.birch"
  libbirch_function_("logpdf", "birch/distribution/Poisson.birch", 30);
  #line 31 "birch/distribution/Poisson.birch"
  libbirch_line_(31);
  #line 31 "birch/distribution/Poisson.birch"
  return birch::logpdf_poisson(x, this_()->_u0955->value(handler_), handler_);
}

#line 34 "birch/distribution/Poisson.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::Poisson::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "birch/distribution/Poisson.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/Poisson.birch", 34);
  #line 35 "birch/distribution/Poisson.birch"
  libbirch_line_(35);
  #line 35 "birch/distribution/Poisson.birch"
  return birch::logpdf_lazy_poisson(x, this_()->_u0955, handler_);
}

#line 38 "birch/distribution/Poisson.birch"
libbirch::Optional<birch::type::Real> birch::type::Poisson::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "birch/distribution/Poisson.birch"
  libbirch_function_("cdf", "birch/distribution/Poisson.birch", 38);
  #line 39 "birch/distribution/Poisson.birch"
  libbirch_line_(39);
  #line 39 "birch/distribution/Poisson.birch"
  return birch::cdf_poisson(x, this_()->_u0955->value(handler_), handler_);
}

#line 42 "birch/distribution/Poisson.birch"
libbirch::Optional<birch::type::Integer> birch::type::Poisson::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "birch/distribution/Poisson.birch"
  libbirch_function_("quantile", "birch/distribution/Poisson.birch", 42);
  #line 43 "birch/distribution/Poisson.birch"
  libbirch_line_(43);
  #line 43 "birch/distribution/Poisson.birch"
  return birch::quantile_poisson(P, this_()->_u0955->value(handler_), handler_);
}

#line 46 "birch/distribution/Poisson.birch"
libbirch::Optional<birch::type::Integer> birch::type::Poisson::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "birch/distribution/Poisson.birch"
  libbirch_function_("lower", "birch/distribution/Poisson.birch", 46);
  #line 47 "birch/distribution/Poisson.birch"
  libbirch_line_(47);
  #line 47 "birch/distribution/Poisson.birch"
  return birch::type::Integer(0);
}

#line 50 "birch/distribution/Poisson.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> birch::type::Poisson::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "birch/distribution/Poisson.birch"
  libbirch_function_("graft", "birch/distribution/Poisson.birch", 50);
  #line 51 "birch/distribution/Poisson.birch"
  libbirch_line_(51);
  #line 51 "birch/distribution/Poisson.birch"
  this_()->prune(handler_);
  #line 52 "birch/distribution/Poisson.birch"
  libbirch_line_(52);
  #line 52 "birch/distribution/Poisson.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::TransformLinear<libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>>>>> m1;
  #line 53 "birch/distribution/Poisson.birch"
  libbirch_line_(53);
  #line 53 "birch/distribution/Poisson.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>> m2;
  #line 54 "birch/distribution/Poisson.birch"
  libbirch_line_(54);
  #line 54 "birch/distribution/Poisson.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Integer>>> r = shared_from_this_();
  #line 57 "birch/distribution/Poisson.birch"
  libbirch_line_(57);
  #line 57 "birch/distribution/Poisson.birch"
  if ((m1 = this_()->_u0955->graftScaledGamma(handler_)).query()) {
    #line 58 "birch/distribution/Poisson.birch"
    libbirch_line_(58);
    #line 58 "birch/distribution/Poisson.birch"
    r = birch::ScaledGammaPoisson(m1.get()->a, m1.get()->x, handler_);
  } else {
    #line 59 "birch/distribution/Poisson.birch"
    libbirch_line_(59);
    #line 59 "birch/distribution/Poisson.birch"
    if ((m2 = this_()->_u0955->graftGamma(handler_)).query()) {
      #line 60 "birch/distribution/Poisson.birch"
      libbirch_line_(60);
      #line 60 "birch/distribution/Poisson.birch"
      r = birch::GammaPoisson(m2.get(), handler_);
    }
  }
  #line 63 "birch/distribution/Poisson.birch"
  libbirch_line_(63);
  #line 63 "birch/distribution/Poisson.birch"
  return r;
}

#line 66 "birch/distribution/Poisson.birch"
void birch::type::Poisson::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "birch/distribution/Poisson.birch"
  libbirch_function_("write", "birch/distribution/Poisson.birch", 66);
  #line 67 "birch/distribution/Poisson.birch"
  libbirch_line_(67);
  #line 67 "birch/distribution/Poisson.birch"
  this_()->prune(handler_);
  #line 68 "birch/distribution/Poisson.birch"
  libbirch_line_(68);
  #line 68 "birch/distribution/Poisson.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Poisson"), handler_);
  #line 69 "birch/distribution/Poisson.birch"
  libbirch_line_(69);
  #line 69 "birch/distribution/Poisson.birch"
  buffer->set(birch::type::String("λ"), this_()->_u0955->value(handler_), handler_);
}

#line 76 "birch/distribution/Poisson.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Poisson>> birch::Poisson(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "birch/distribution/Poisson.birch"
  libbirch_function_("Poisson", "birch/distribution/Poisson.birch", 76);
  #line 77 "birch/distribution/Poisson.birch"
  libbirch_line_(77);
  #line 77 "birch/distribution/Poisson.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Poisson>>>(_u0955, handler_);
}

#line 83 "birch/distribution/Poisson.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Poisson>> birch::Poisson(const birch::type::Real& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 83 "birch/distribution/Poisson.birch"
  libbirch_function_("Poisson", "birch/distribution/Poisson.birch", 83);
  #line 84 "birch/distribution/Poisson.birch"
  libbirch_line_(84);
  #line 84 "birch/distribution/Poisson.birch"
  return birch::Poisson(birch::box(_u0955, handler_), handler_);
}

#line 8 "birch/distribution/Restaurant.birch"
birch::type::Restaurant::Restaurant(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 8 "birch/distribution/Restaurant.birch"
    super_type_(),
    #line 13 "birch/distribution/Restaurant.birch"
    _u0945(_u0945),
    #line 18 "birch/distribution/Restaurant.birch"
    _u0952(_u0952),
    #line 23 "birch/distribution/Restaurant.birch"
    n(),
    #line 28 "birch/distribution/Restaurant.birch"
    K(birch::type::Integer(0)),
    #line 33 "birch/distribution/Restaurant.birch"
    N(birch::type::Integer(0)) {
  //
}

#line 35 "birch/distribution/Restaurant.birch"
birch::type::Boolean birch::type::Restaurant::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "birch/distribution/Restaurant.birch"
  libbirch_function_("supportsLazy", "birch/distribution/Restaurant.birch", 35);
  #line 36 "birch/distribution/Restaurant.birch"
  libbirch_line_(36);
  #line 36 "birch/distribution/Restaurant.birch"
  return false;
}

#line 39 "birch/distribution/Restaurant.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::Restaurant::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "birch/distribution/Restaurant.birch"
  libbirch_function_("simulate", "birch/distribution/Restaurant.birch", 39);
  #line 40 "birch/distribution/Restaurant.birch"
  libbirch_line_(40);
  #line 40 "birch/distribution/Restaurant.birch"
  libbirch_assert_(false);
  #line 41 "birch/distribution/Restaurant.birch"
  libbirch_line_(41);
  #line 41 "birch/distribution/Restaurant.birch"
  return birch::vector(0.0, birch::type::Integer(0), handler_);
}

#line 44 "birch/distribution/Restaurant.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::Restaurant::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "birch/distribution/Restaurant.birch"
  libbirch_function_("simulateLazy", "birch/distribution/Restaurant.birch", 44);
  #line 45 "birch/distribution/Restaurant.birch"
  libbirch_line_(45);
  #line 45 "birch/distribution/Restaurant.birch"
  libbirch_assert_(false);
  #line 46 "birch/distribution/Restaurant.birch"
  libbirch_line_(46);
  #line 46 "birch/distribution/Restaurant.birch"
  return birch::vector(0.0, birch::type::Integer(0), handler_);
}

#line 49 "birch/distribution/Restaurant.birch"
birch::type::Real birch::type::Restaurant::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "birch/distribution/Restaurant.birch"
  libbirch_function_("logpdf", "birch/distribution/Restaurant.birch", 49);
  #line 50 "birch/distribution/Restaurant.birch"
  libbirch_line_(50);
  #line 50 "birch/distribution/Restaurant.birch"
  libbirch_assert_(false);
  #line 51 "birch/distribution/Restaurant.birch"
  libbirch_line_(51);
  #line 51 "birch/distribution/Restaurant.birch"
  return 0.0;
}

#line 54 "birch/distribution/Restaurant.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::Restaurant::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "birch/distribution/Restaurant.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/Restaurant.birch", 54);
  #line 55 "birch/distribution/Restaurant.birch"
  libbirch_line_(55);
  #line 55 "birch/distribution/Restaurant.birch"
  libbirch_assert_(false);
  #line 56 "birch/distribution/Restaurant.birch"
  libbirch_line_(56);
  #line 56 "birch/distribution/Restaurant.birch"
  return birch::box(0.0, handler_);
}

#line 59 "birch/distribution/Restaurant.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Restaurant>>> birch::type::Restaurant::graftRestaurant(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "birch/distribution/Restaurant.birch"
  libbirch_function_("graftRestaurant", "birch/distribution/Restaurant.birch", 59);
  #line 60 "birch/distribution/Restaurant.birch"
  libbirch_line_(60);
  #line 60 "birch/distribution/Restaurant.birch"
  this_()->prune(handler_);
  #line 61 "birch/distribution/Restaurant.birch"
  libbirch_line_(61);
  #line 61 "birch/distribution/Restaurant.birch"
  return shared_from_this_();
}

#line 64 "birch/distribution/Restaurant.birch"
void birch::type::Restaurant::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "birch/distribution/Restaurant.birch"
  libbirch_function_("write", "birch/distribution/Restaurant.birch", 64);
  #line 65 "birch/distribution/Restaurant.birch"
  libbirch_line_(65);
  #line 65 "birch/distribution/Restaurant.birch"
  this_()->prune(handler_);
  #line 66 "birch/distribution/Restaurant.birch"
  libbirch_line_(66);
  #line 66 "birch/distribution/Restaurant.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Restaurant"), handler_);
  #line 67 "birch/distribution/Restaurant.birch"
  libbirch_line_(67);
  #line 67 "birch/distribution/Restaurant.birch"
  buffer->set(birch::type::String("α"), this_()->_u0945, handler_);
  #line 68 "birch/distribution/Restaurant.birch"
  libbirch_line_(68);
  #line 68 "birch/distribution/Restaurant.birch"
  buffer->set(birch::type::String("θ"), this_()->_u0952, handler_);
  #line 69 "birch/distribution/Restaurant.birch"
  libbirch_line_(69);
  #line 69 "birch/distribution/Restaurant.birch"
  buffer->set(birch::type::String("n"), this_()->n, handler_);
}

#line 76 "birch/distribution/Restaurant.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Restaurant>> birch::Restaurant(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "birch/distribution/Restaurant.birch"
  libbirch_function_("Restaurant", "birch/distribution/Restaurant.birch", 76);
  #line 77 "birch/distribution/Restaurant.birch"
  libbirch_line_(77);
  #line 77 "birch/distribution/Restaurant.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Restaurant>>>(_u0945, _u0952, handler_);
}

#line 83 "birch/distribution/Restaurant.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Restaurant>> birch::Restaurant(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0945, const birch::type::Real& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 83 "birch/distribution/Restaurant.birch"
  libbirch_function_("Restaurant", "birch/distribution/Restaurant.birch", 83);
  #line 84 "birch/distribution/Restaurant.birch"
  libbirch_line_(84);
  #line 84 "birch/distribution/Restaurant.birch"
  return birch::Restaurant(_u0945, birch::box(_u0952, handler_), handler_);
}

#line 90 "birch/distribution/Restaurant.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Restaurant>> birch::Restaurant(const birch::type::Real& _u0945, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 90 "birch/distribution/Restaurant.birch"
  libbirch_function_("Restaurant", "birch/distribution/Restaurant.birch", 90);
  #line 91 "birch/distribution/Restaurant.birch"
  libbirch_line_(91);
  #line 91 "birch/distribution/Restaurant.birch"
  return birch::Restaurant(birch::box(_u0945, handler_), _u0952, handler_);
}

#line 97 "birch/distribution/Restaurant.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Restaurant>> birch::Restaurant(const birch::type::Real& _u0945, const birch::type::Real& _u0952, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 97 "birch/distribution/Restaurant.birch"
  libbirch_function_("Restaurant", "birch/distribution/Restaurant.birch", 97);
  #line 98 "birch/distribution/Restaurant.birch"
  libbirch_line_(98);
  #line 98 "birch/distribution/Restaurant.birch"
  return birch::Restaurant(birch::box(_u0945, handler_), birch::box(_u0952, handler_), handler_);
}

#line 4 "birch/distribution/RestaurantCategorical.birch"
birch::type::RestaurantCategorical::RestaurantCategorical(const libbirch::Lazy<libbirch::Shared<birch::type::Restaurant>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/RestaurantCategorical.birch"
    super_type_(),
    #line 8 "birch/distribution/RestaurantCategorical.birch"
    _u0961(_u0961) {
  //
}

#line 10 "birch/distribution/RestaurantCategorical.birch"
birch::type::Boolean birch::type::RestaurantCategorical::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 10 "birch/distribution/RestaurantCategorical.birch"
  libbirch_function_("supportsLazy", "birch/distribution/RestaurantCategorical.birch", 10);
  #line 11 "birch/distribution/RestaurantCategorical.birch"
  libbirch_line_(11);
  #line 11 "birch/distribution/RestaurantCategorical.birch"
  return false;
}

#line 14 "birch/distribution/RestaurantCategorical.birch"
birch::type::Integer birch::type::RestaurantCategorical::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 14 "birch/distribution/RestaurantCategorical.birch"
  libbirch_function_("simulate", "birch/distribution/RestaurantCategorical.birch", 14);
  #line 15 "birch/distribution/RestaurantCategorical.birch"
  libbirch_line_(15);
  #line 15 "birch/distribution/RestaurantCategorical.birch"
  return birch::simulate_crp_categorical(this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0952->value(handler_), this_()->_u0961->n, this_()->_u0961->N, handler_);
}

#line 22 "birch/distribution/RestaurantCategorical.birch"
birch::type::Real birch::type::RestaurantCategorical::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "birch/distribution/RestaurantCategorical.birch"
  libbirch_function_("logpdf", "birch/distribution/RestaurantCategorical.birch", 22);
  #line 23 "birch/distribution/RestaurantCategorical.birch"
  libbirch_line_(23);
  #line 23 "birch/distribution/RestaurantCategorical.birch"
  return birch::logpdf_crp_categorical(x, this_()->_u0961->_u0945->value(handler_), this_()->_u0961->_u0952->value(handler_), this_()->_u0961->n, this_()->_u0961->N, handler_);
}

#line 30 "birch/distribution/RestaurantCategorical.birch"
void birch::type::RestaurantCategorical::update(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "birch/distribution/RestaurantCategorical.birch"
  libbirch_function_("update", "birch/distribution/RestaurantCategorical.birch", 30);
  #line 32 "birch/distribution/RestaurantCategorical.birch"
  libbirch_line_(32);
  #line 32 "birch/distribution/RestaurantCategorical.birch"
  libbirch_assert_(x <= this_()->_u0961->K + birch::type::Integer(1));
  #line 33 "birch/distribution/RestaurantCategorical.birch"
  libbirch_line_(33);
  #line 33 "birch/distribution/RestaurantCategorical.birch"
  if (x == this_()->_u0961->K + birch::type::Integer(1)) {
    #line 34 "birch/distribution/RestaurantCategorical.birch"
    libbirch_line_(34);
    #line 34 "birch/distribution/RestaurantCategorical.birch"
    libbirch::DefaultArray<birch::type::Integer,1> n1(libbirch::make_shape(this_()->_u0961->K + birch::type::Integer(1)));
    #line 35 "birch/distribution/RestaurantCategorical.birch"
    libbirch_line_(35);
    #line 35 "birch/distribution/RestaurantCategorical.birch"
    n1.set(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, this_()->_u0961->K - 1)), this_()->_u0961->n);
    #line 36 "birch/distribution/RestaurantCategorical.birch"
    libbirch_line_(36);
    #line 36 "birch/distribution/RestaurantCategorical.birch"
    n1.set(libbirch::make_slice(x - 1), birch::type::Integer(1));
    #line 37 "birch/distribution/RestaurantCategorical.birch"
    libbirch_line_(37);
    #line 37 "birch/distribution/RestaurantCategorical.birch"
    this_()->_u0961->n = n1;
    #line 38 "birch/distribution/RestaurantCategorical.birch"
    libbirch_line_(38);
    #line 38 "birch/distribution/RestaurantCategorical.birch"
    this_()->_u0961->K = this_()->_u0961->K + birch::type::Integer(1);
  } else {
    #line 40 "birch/distribution/RestaurantCategorical.birch"
    libbirch_line_(40);
    #line 40 "birch/distribution/RestaurantCategorical.birch"
    this_()->_u0961->n.set(libbirch::make_slice(x - 1), this_()->_u0961->n.get(libbirch::make_slice(x - 1)) + birch::type::Integer(1));
  }
  #line 42 "birch/distribution/RestaurantCategorical.birch"
  libbirch_line_(42);
  #line 42 "birch/distribution/RestaurantCategorical.birch"
  this_()->_u0961->N = this_()->_u0961->N + birch::type::Integer(1);
}

#line 49 "birch/distribution/RestaurantCategorical.birch"
void birch::type::RestaurantCategorical::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "birch/distribution/RestaurantCategorical.birch"
  libbirch_function_("link", "birch/distribution/RestaurantCategorical.birch", 49);
  #line 50 "birch/distribution/RestaurantCategorical.birch"
  libbirch_line_(50);
  #line 50 "birch/distribution/RestaurantCategorical.birch"
  this_()->_u0961->setChild(shared_from_this_(), handler_);
}

#line 53 "birch/distribution/RestaurantCategorical.birch"
void birch::type::RestaurantCategorical::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "birch/distribution/RestaurantCategorical.birch"
  libbirch_function_("unlink", "birch/distribution/RestaurantCategorical.birch", 53);
  #line 54 "birch/distribution/RestaurantCategorical.birch"
  libbirch_line_(54);
  #line 54 "birch/distribution/RestaurantCategorical.birch"
  this_()->_u0961->releaseChild(shared_from_this_(), handler_);
}

#line 58 "birch/distribution/RestaurantCategorical.birch"
libbirch::Lazy<libbirch::Shared<birch::type::RestaurantCategorical>> birch::RestaurantCategorical(const libbirch::Lazy<libbirch::Shared<birch::type::Restaurant>>& _u0961, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "birch/distribution/RestaurantCategorical.birch"
  libbirch_function_("RestaurantCategorical", "birch/distribution/RestaurantCategorical.birch", 58);
  #line 59 "birch/distribution/RestaurantCategorical.birch"
  libbirch_line_(59);
  #line 59 "birch/distribution/RestaurantCategorical.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::RestaurantCategorical>> m(_u0961);
  #line 60 "birch/distribution/RestaurantCategorical.birch"
  libbirch_line_(60);
  #line 60 "birch/distribution/RestaurantCategorical.birch"
  m->link(handler_);
  #line 61 "birch/distribution/RestaurantCategorical.birch"
  libbirch_line_(61);
  #line 61 "birch/distribution/RestaurantCategorical.birch"
  return m;
}

#line 5 "birch/distribution/ScalarGaussian.birch"
birch::type::ScalarGaussian::ScalarGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09642, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 5 "birch/distribution/ScalarGaussian.birch"
    super_type_(),
    #line 10 "birch/distribution/ScalarGaussian.birch"
    _u0956(_u0956),
    #line 15 "birch/distribution/ScalarGaussian.birch"
    _u09632(_u09632),
    #line 20 "birch/distribution/ScalarGaussian.birch"
    _u09642(_u09642) {
  //
}

#line 22 "birch/distribution/ScalarGaussian.birch"
birch::type::Boolean birch::type::ScalarGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "birch/distribution/ScalarGaussian.birch"
  libbirch_function_("supportsLazy", "birch/distribution/ScalarGaussian.birch", 22);
  #line 23 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(23);
  #line 23 "birch/distribution/ScalarGaussian.birch"
  return true;
}

#line 26 "birch/distribution/ScalarGaussian.birch"
birch::type::Real birch::type::ScalarGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "birch/distribution/ScalarGaussian.birch"
  libbirch_function_("simulate", "birch/distribution/ScalarGaussian.birch", 26);
  #line 27 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(27);
  #line 27 "birch/distribution/ScalarGaussian.birch"
  return birch::simulate_gaussian(this_()->_u0956->value(handler_), this_()->_u09632->value(handler_) * this_()->_u09642->value(handler_), handler_);
}

#line 30 "birch/distribution/ScalarGaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::ScalarGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "birch/distribution/ScalarGaussian.birch"
  libbirch_function_("simulateLazy", "birch/distribution/ScalarGaussian.birch", 30);
  #line 31 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(31);
  #line 31 "birch/distribution/ScalarGaussian.birch"
  return birch::simulate_gaussian(this_()->_u0956->get(handler_), this_()->_u09632->get(handler_) * this_()->_u09642->get(handler_), handler_);
}

#line 34 "birch/distribution/ScalarGaussian.birch"
birch::type::Real birch::type::ScalarGaussian::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "birch/distribution/ScalarGaussian.birch"
  libbirch_function_("logpdf", "birch/distribution/ScalarGaussian.birch", 34);
  #line 35 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(35);
  #line 35 "birch/distribution/ScalarGaussian.birch"
  return birch::logpdf_gaussian(x, this_()->_u0956->value(handler_), this_()->_u09632->value(handler_) * this_()->_u09642->value(handler_), handler_);
}

#line 38 "birch/distribution/ScalarGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::ScalarGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "birch/distribution/ScalarGaussian.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/ScalarGaussian.birch", 38);
  #line 39 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(39);
  #line 39 "birch/distribution/ScalarGaussian.birch"
  return birch::logpdf_lazy_gaussian(x, this_()->_u0956, this_()->_u09632 * this_()->_u09642, handler_);
}

#line 42 "birch/distribution/ScalarGaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::ScalarGaussian::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "birch/distribution/ScalarGaussian.birch"
  libbirch_function_("cdf", "birch/distribution/ScalarGaussian.birch", 42);
  #line 43 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(43);
  #line 43 "birch/distribution/ScalarGaussian.birch"
  return birch::cdf_gaussian(x, this_()->_u0956->value(handler_), this_()->_u09632->value(handler_) * this_()->_u09642->value(handler_), handler_);
}

#line 46 "birch/distribution/ScalarGaussian.birch"
libbirch::Optional<birch::type::Real> birch::type::ScalarGaussian::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "birch/distribution/ScalarGaussian.birch"
  libbirch_function_("quantile", "birch/distribution/ScalarGaussian.birch", 46);
  #line 47 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(47);
  #line 47 "birch/distribution/ScalarGaussian.birch"
  return birch::quantile_gaussian(P, this_()->_u0956->value(handler_), this_()->_u09632->value(handler_) * this_()->_u09642->value(handler_), handler_);
}

#line 50 "birch/distribution/ScalarGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> birch::type::ScalarGaussian::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "birch/distribution/ScalarGaussian.birch"
  libbirch_function_("graft", "birch/distribution/ScalarGaussian.birch", 50);
  #line 51 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(51);
  #line 51 "birch/distribution/ScalarGaussian.birch"
  this_()->prune(handler_);
  #line 52 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(52);
  #line 52 "birch/distribution/ScalarGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>> s1;
  #line 53 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(53);
  #line 53 "birch/distribution/ScalarGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>> r = shared_from_this_();
  #line 56 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(56);
  #line 56 "birch/distribution/ScalarGaussian.birch"
  if ((s1 = this_()->_u09632->graftInverseGamma(handler_)).query()) {
    #line 57 "birch/distribution/ScalarGaussian.birch"
    libbirch_line_(57);
    #line 57 "birch/distribution/ScalarGaussian.birch"
    r = birch::NormalInverseGamma(this_()->_u0956, this_()->_u09642, s1.get(), handler_);
  } else {
    #line 58 "birch/distribution/ScalarGaussian.birch"
    libbirch_line_(58);
    #line 58 "birch/distribution/ScalarGaussian.birch"
    if ((s1 = this_()->_u09642->graftInverseGamma(handler_)).query()) {
      #line 59 "birch/distribution/ScalarGaussian.birch"
      libbirch_line_(59);
      #line 59 "birch/distribution/ScalarGaussian.birch"
      r = birch::NormalInverseGamma(this_()->_u0956, this_()->_u09632, s1.get(), handler_);
    }
  }
  #line 62 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(62);
  #line 62 "birch/distribution/ScalarGaussian.birch"
  return r;
}

#line 65 "birch/distribution/ScalarGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Gaussian>>> birch::type::ScalarGaussian::graftGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "birch/distribution/ScalarGaussian.birch"
  libbirch_function_("graftGaussian", "birch/distribution/ScalarGaussian.birch", 65);
  #line 66 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(66);
  #line 66 "birch/distribution/ScalarGaussian.birch"
  this_()->prune(handler_);
  #line 67 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(67);
  #line 67 "birch/distribution/ScalarGaussian.birch"
  return birch::Gaussian(this_()->_u0956, this_()->_u09632 * this_()->_u09642, handler_);
}

#line 70 "birch/distribution/ScalarGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>> birch::type::ScalarGaussian::graftNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "birch/distribution/ScalarGaussian.birch"
  libbirch_function_("graftNormalInverseGamma", "birch/distribution/ScalarGaussian.birch", 70);
  #line 72 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(72);
  #line 72 "birch/distribution/ScalarGaussian.birch"
  this_()->prune(handler_);
  #line 73 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(73);
  #line 73 "birch/distribution/ScalarGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>> s1;
  #line 74 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(74);
  #line 74 "birch/distribution/ScalarGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::NormalInverseGamma>>> r;
  #line 77 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(77);
  #line 77 "birch/distribution/ScalarGaussian.birch"
  if ((s1 = this_()->_u09632->graftInverseGamma(handler_)).query() && s1.get() == compare) {
    #line 78 "birch/distribution/ScalarGaussian.birch"
    libbirch_line_(78);
    #line 78 "birch/distribution/ScalarGaussian.birch"
    r = birch::NormalInverseGamma(this_()->_u0956, this_()->_u09642, s1.get(), handler_);
  } else {
    #line 79 "birch/distribution/ScalarGaussian.birch"
    libbirch_line_(79);
    #line 79 "birch/distribution/ScalarGaussian.birch"
    if ((s1 = this_()->_u09642->graftInverseGamma(handler_)).query() && s1.get() == compare) {
      #line 80 "birch/distribution/ScalarGaussian.birch"
      libbirch_line_(80);
      #line 80 "birch/distribution/ScalarGaussian.birch"
      r = birch::NormalInverseGamma(this_()->_u0956, this_()->_u09632, s1.get(), handler_);
    }
  }
  #line 83 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(83);
  #line 83 "birch/distribution/ScalarGaussian.birch"
  return r;
}

#line 92 "birch/distribution/ScalarGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09642, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 92 "birch/distribution/ScalarGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/ScalarGaussian.birch", 92);
  #line 94 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(94);
  #line 94 "birch/distribution/ScalarGaussian.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::ScalarGaussian>>>(_u0956, _u09632, _u09642, handler_);
}

#line 102 "birch/distribution/ScalarGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const birch::type::Real& _u09642, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 102 "birch/distribution/ScalarGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/ScalarGaussian.birch", 102);
  #line 104 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(104);
  #line 104 "birch/distribution/ScalarGaussian.birch"
  return birch::Gaussian(_u0956, _u09632, birch::box(_u09642, handler_), handler_);
}

#line 112 "birch/distribution/ScalarGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09642, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 112 "birch/distribution/ScalarGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/ScalarGaussian.birch", 112);
  #line 114 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(114);
  #line 114 "birch/distribution/ScalarGaussian.birch"
  return birch::Gaussian(_u0956, birch::box(_u09632, handler_), _u09642, handler_);
}

#line 122 "birch/distribution/ScalarGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const birch::type::Real& _u09632, const birch::type::Real& _u09642, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 122 "birch/distribution/ScalarGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/ScalarGaussian.birch", 122);
  #line 124 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(124);
  #line 124 "birch/distribution/ScalarGaussian.birch"
  return birch::Gaussian(_u0956, birch::box(_u09632, handler_), birch::box(_u09642, handler_), handler_);
}

#line 132 "birch/distribution/ScalarGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarGaussian>> birch::Gaussian(const birch::type::Real& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09642, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 132 "birch/distribution/ScalarGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/ScalarGaussian.birch", 132);
  #line 134 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(134);
  #line 134 "birch/distribution/ScalarGaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), _u09632, _u09642, handler_);
}

#line 142 "birch/distribution/ScalarGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarGaussian>> birch::Gaussian(const birch::type::Real& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const birch::type::Real& _u09642, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 142 "birch/distribution/ScalarGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/ScalarGaussian.birch", 142);
  #line 144 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(144);
  #line 144 "birch/distribution/ScalarGaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), _u09632, birch::box(_u09642, handler_), handler_);
}

#line 152 "birch/distribution/ScalarGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarGaussian>> birch::Gaussian(const birch::type::Real& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09642, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 152 "birch/distribution/ScalarGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/ScalarGaussian.birch", 152);
  #line 154 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(154);
  #line 154 "birch/distribution/ScalarGaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), birch::box(_u09632, handler_), _u09642, handler_);
}

#line 162 "birch/distribution/ScalarGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarGaussian>> birch::Gaussian(const birch::type::Real& _u0956, const birch::type::Real& _u09632, const birch::type::Real& _u09642, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 162 "birch/distribution/ScalarGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/ScalarGaussian.birch", 162);
  #line 163 "birch/distribution/ScalarGaussian.birch"
  libbirch_line_(163);
  #line 163 "birch/distribution/ScalarGaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), birch::box(_u09632, handler_), birch::box(_u09642, handler_), handler_);
}

#line 5 "birch/distribution/ScalarMultivariateGaussian.birch"
birch::type::ScalarMultivariateGaussian::ScalarMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 5 "birch/distribution/ScalarMultivariateGaussian.birch"
    super_type_(),
    #line 10 "birch/distribution/ScalarMultivariateGaussian.birch"
    _u0956(_u0956),
    #line 15 "birch/distribution/ScalarMultivariateGaussian.birch"
    _u0931(_u0931),
    #line 20 "birch/distribution/ScalarMultivariateGaussian.birch"
    _u09632(_u09632) {
  //
}

#line 22 "birch/distribution/ScalarMultivariateGaussian.birch"
birch::type::Integer birch::type::ScalarMultivariateGaussian::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 22 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("rows", "birch/distribution/ScalarMultivariateGaussian.birch", 22);
  #line 23 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(23);
  #line 23 "birch/distribution/ScalarMultivariateGaussian.birch"
  return this_()->_u0956->rows(handler_);
}

#line 26 "birch/distribution/ScalarMultivariateGaussian.birch"
birch::type::Boolean birch::type::ScalarMultivariateGaussian::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("supportsLazy", "birch/distribution/ScalarMultivariateGaussian.birch", 26);
  #line 27 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(27);
  #line 27 "birch/distribution/ScalarMultivariateGaussian.birch"
  return true;
}

#line 30 "birch/distribution/ScalarMultivariateGaussian.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::type::ScalarMultivariateGaussian::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("simulate", "birch/distribution/ScalarMultivariateGaussian.birch", 30);
  #line 31 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(31);
  #line 31 "birch/distribution/ScalarMultivariateGaussian.birch"
  return birch::simulate_multivariate_gaussian(this_()->_u0956->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 34 "birch/distribution/ScalarMultivariateGaussian.birch"
libbirch::Optional<libbirch::DefaultArray<birch::type::Real,1>> birch::type::ScalarMultivariateGaussian::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("simulateLazy", "birch/distribution/ScalarMultivariateGaussian.birch", 34);
  #line 35 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(35);
  #line 35 "birch/distribution/ScalarMultivariateGaussian.birch"
  return birch::simulate_multivariate_gaussian(this_()->_u0956->get(handler_), this_()->_u09632->get(handler_), handler_);
}

#line 38 "birch/distribution/ScalarMultivariateGaussian.birch"
birch::type::Real birch::type::ScalarMultivariateGaussian::logpdf(const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("logpdf", "birch/distribution/ScalarMultivariateGaussian.birch", 38);
  #line 39 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(39);
  #line 39 "birch/distribution/ScalarMultivariateGaussian.birch"
  return birch::logpdf_multivariate_gaussian(x, this_()->_u0956->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 42 "birch/distribution/ScalarMultivariateGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::ScalarMultivariateGaussian::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 42 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/ScalarMultivariateGaussian.birch", 42);
  #line 43 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(43);
  #line 43 "birch/distribution/ScalarMultivariateGaussian.birch"
  return birch::logpdf_lazy_multivariate_gaussian(x, this_()->_u0956, this_()->_u09632, handler_);
}

#line 46 "birch/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>> birch::type::ScalarMultivariateGaussian::graft(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 46 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("graft", "birch/distribution/ScalarMultivariateGaussian.birch", 46);
  #line 47 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(47);
  #line 47 "birch/distribution/ScalarMultivariateGaussian.birch"
  this_()->prune(handler_);
  #line 48 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(48);
  #line 48 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>> s1;
  #line 49 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(49);
  #line 49 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Distribution<libbirch::DefaultArray<birch::type::Real,1>>>> r = shared_from_this_();
  #line 52 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(52);
  #line 52 "birch/distribution/ScalarMultivariateGaussian.birch"
  if ((s1 = this_()->_u09632->graftInverseGamma(handler_)).query()) {
    #line 53 "birch/distribution/ScalarMultivariateGaussian.birch"
    libbirch_line_(53);
    #line 53 "birch/distribution/ScalarMultivariateGaussian.birch"
    r = birch::MultivariateNormalInverseGamma(this_()->_u0956, this_()->_u0931, s1.get(), handler_);
  }
  #line 56 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(56);
  #line 56 "birch/distribution/ScalarMultivariateGaussian.birch"
  return r;
}

#line 59 "birch/distribution/ScalarMultivariateGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateGaussian>>> birch::type::ScalarMultivariateGaussian::graftMultivariateGaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("graftMultivariateGaussian", "birch/distribution/ScalarMultivariateGaussian.birch", 59);
  #line 60 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(60);
  #line 60 "birch/distribution/ScalarMultivariateGaussian.birch"
  this_()->prune(handler_);
  #line 61 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(61);
  #line 61 "birch/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(this_()->_u0956, birch::canonical(this_()->_u0931, handler_) * this_()->_u09632, handler_);
}

#line 64 "birch/distribution/ScalarMultivariateGaussian.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>> birch::type::ScalarMultivariateGaussian::graftMultivariateNormalInverseGamma(const libbirch::Lazy<libbirch::Shared<birch::type::Distribution<birch::type::Real>>>& compare, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("graftMultivariateNormalInverseGamma", "birch/distribution/ScalarMultivariateGaussian.birch", 64);
  #line 66 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(66);
  #line 66 "birch/distribution/ScalarMultivariateGaussian.birch"
  this_()->prune(handler_);
  #line 67 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(67);
  #line 67 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::InverseGamma>>> s1;
  #line 68 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(68);
  #line 68 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::MultivariateNormalInverseGamma>>> r;
  #line 71 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(71);
  #line 71 "birch/distribution/ScalarMultivariateGaussian.birch"
  if ((s1 = this_()->_u09632->graftInverseGamma(handler_)).query() && s1.get() == compare) {
    #line 72 "birch/distribution/ScalarMultivariateGaussian.birch"
    libbirch_line_(72);
    #line 72 "birch/distribution/ScalarMultivariateGaussian.birch"
    r = birch::MultivariateNormalInverseGamma(this_()->_u0956, this_()->_u0931, s1.get(), handler_);
  }
  #line 75 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(75);
  #line 75 "birch/distribution/ScalarMultivariateGaussian.birch"
  return r;
}

#line 85 "birch/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 85 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/ScalarMultivariateGaussian.birch", 85);
  #line 87 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(87);
  #line 87 "birch/distribution/ScalarMultivariateGaussian.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>>>(_u0956, _u0931, _u09632, handler_);
}

#line 96 "birch/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 96 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/ScalarMultivariateGaussian.birch", 96);
  #line 98 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(98);
  #line 98 "birch/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(_u0956, _u0931, birch::box(_u09632, handler_), handler_);
}

#line 107 "birch/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const birch::type::LLT& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 107 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/ScalarMultivariateGaussian.birch", 107);
  #line 109 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(109);
  #line 109 "birch/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::box(_u0931, handler_), _u09632, handler_);
}

#line 118 "birch/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const birch::type::LLT& _u0931, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 118 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/ScalarMultivariateGaussian.birch", 118);
  #line 120 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(120);
  #line 120 "birch/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::box(_u0931, handler_), birch::box(_u09632, handler_), handler_);
}

#line 129 "birch/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 129 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/ScalarMultivariateGaussian.birch", 129);
  #line 131 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(131);
  #line 131 "birch/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), _u0931, _u09632, handler_);
}

#line 140 "birch/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0931, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 140 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/ScalarMultivariateGaussian.birch", 140);
  #line 142 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(142);
  #line 142 "birch/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), _u0931, birch::box(_u09632, handler_), handler_);
}

#line 151 "birch/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const birch::type::LLT& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 151 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/ScalarMultivariateGaussian.birch", 151);
  #line 153 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(153);
  #line 153 "birch/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), birch::box(_u0931, handler_), _u09632, handler_);
}

#line 162 "birch/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const birch::type::LLT& _u0931, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 162 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/ScalarMultivariateGaussian.birch", 162);
  #line 163 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(163);
  #line 163 "birch/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(birch::box(_u0956, handler_), birch::box(_u0931, handler_), birch::box(_u09632, handler_), handler_);
}

#line 172 "birch/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 172 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/ScalarMultivariateGaussian.birch", 172);
  #line 174 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(174);
  #line 174 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> m(_u0956, birch::llt(_u0931, handler_), _u09632);
  #line 175 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(175);
  #line 175 "birch/distribution/ScalarMultivariateGaussian.birch"
  return m;
}

#line 184 "birch/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& _u0931, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 184 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/ScalarMultivariateGaussian.birch", 184);
  #line 186 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(186);
  #line 186 "birch/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931, handler_), _u09632, handler_);
}

#line 195 "birch/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::DefaultArray<birch::type::Real,2>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 195 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/ScalarMultivariateGaussian.birch", 195);
  #line 197 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(197);
  #line 197 "birch/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931, handler_), _u09632, handler_);
}

#line 206 "birch/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,1>>>>& _u0956, const libbirch::DefaultArray<birch::type::Real,2>& _u0931, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 206 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/ScalarMultivariateGaussian.birch", 206);
  #line 208 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(208);
  #line 208 "birch/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931, handler_), _u09632, handler_);
}

#line 217 "birch/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 217 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/ScalarMultivariateGaussian.birch", 217);
  #line 219 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(219);
  #line 219 "birch/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931, handler_), _u09632, handler_);
}

#line 228 "birch/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& _u0931, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 228 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/ScalarMultivariateGaussian.birch", 228);
  #line 230 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(230);
  #line 230 "birch/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931, handler_), _u09632, handler_);
}

#line 239 "birch/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::DefaultArray<birch::type::Real,2>& _u0931, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 239 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/ScalarMultivariateGaussian.birch", 239);
  #line 241 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(241);
  #line 241 "birch/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931, handler_), _u09632, handler_);
}

#line 250 "birch/distribution/ScalarMultivariateGaussian.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScalarMultivariateGaussian>> birch::Gaussian(const libbirch::DefaultArray<birch::type::Real,1>& _u0956, const libbirch::DefaultArray<birch::type::Real,2>& _u0931, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 250 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_function_("Gaussian", "birch/distribution/ScalarMultivariateGaussian.birch", 250);
  #line 252 "birch/distribution/ScalarMultivariateGaussian.birch"
  libbirch_line_(252);
  #line 252 "birch/distribution/ScalarMultivariateGaussian.birch"
  return birch::Gaussian(_u0956, birch::llt(_u0931, handler_), _u09632, handler_);
}

#line 1 "birch/distribution/ScaledGammaExponential.birch"
birch::type::ScaledGammaExponential::ScaledGammaExponential(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/distribution/ScaledGammaExponential.birch"
    super_type_(),
    #line 9 "birch/distribution/ScaledGammaExponential.birch"
    a(a),
    #line 14 "birch/distribution/ScaledGammaExponential.birch"
    _u0955(_u0955) {
  //
}

#line 16 "birch/distribution/ScaledGammaExponential.birch"
birch::type::Boolean birch::type::ScaledGammaExponential::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_function_("supportsLazy", "birch/distribution/ScaledGammaExponential.birch", 16);
  #line 17 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_line_(17);
  #line 17 "birch/distribution/ScaledGammaExponential.birch"
  return true;
}

#line 20 "birch/distribution/ScaledGammaExponential.birch"
birch::type::Real birch::type::ScaledGammaExponential::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_function_("simulate", "birch/distribution/ScaledGammaExponential.birch", 20);
  #line 21 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_line_(21);
  #line 21 "birch/distribution/ScaledGammaExponential.birch"
  return birch::simulate_lomax(1.0 / (this_()->a->value(handler_) * this_()->_u0955->_u0952->value(handler_)), this_()->_u0955->k->value(handler_), handler_);
}

#line 24 "birch/distribution/ScaledGammaExponential.birch"
libbirch::Optional<birch::type::Real> birch::type::ScaledGammaExponential::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_function_("simulateLazy", "birch/distribution/ScaledGammaExponential.birch", 24);
  #line 25 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_line_(25);
  #line 25 "birch/distribution/ScaledGammaExponential.birch"
  return birch::simulate_lomax(1.0 / (this_()->a->get(handler_) * this_()->_u0955->_u0952->get(handler_)), this_()->_u0955->k->get(handler_), handler_);
}

#line 28 "birch/distribution/ScaledGammaExponential.birch"
birch::type::Real birch::type::ScaledGammaExponential::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_function_("logpdf", "birch/distribution/ScaledGammaExponential.birch", 28);
  #line 29 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_line_(29);
  #line 29 "birch/distribution/ScaledGammaExponential.birch"
  return birch::logpdf_lomax(x, 1.0 / (this_()->a->value(handler_) * this_()->_u0955->_u0952->value(handler_)), this_()->_u0955->k->value(handler_), handler_);
}

#line 32 "birch/distribution/ScaledGammaExponential.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::ScaledGammaExponential::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/ScaledGammaExponential.birch", 32);
  #line 33 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_line_(33);
  #line 33 "birch/distribution/ScaledGammaExponential.birch"
  return birch::logpdf_lazy_lomax(x, 1.0 / (this_()->a * this_()->_u0955->_u0952), this_()->_u0955->k, handler_);
}

#line 36 "birch/distribution/ScaledGammaExponential.birch"
void birch::type::ScaledGammaExponential::update(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_function_("update", "birch/distribution/ScaledGammaExponential.birch", 36);
  #line 37 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_line_(37);
  #line 37 "birch/distribution/ScaledGammaExponential.birch"
  libbirch::tie(this_()->_u0955->k, this_()->_u0955->_u0952) = birch::box(birch::update_scaled_gamma_exponential(x, this_()->a->value(handler_), this_()->_u0955->k->value(handler_), this_()->_u0955->_u0952->value(handler_), handler_), handler_);
}

#line 41 "birch/distribution/ScaledGammaExponential.birch"
void birch::type::ScaledGammaExponential::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_function_("updateLazy", "birch/distribution/ScaledGammaExponential.birch", 41);
  #line 42 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_line_(42);
  #line 42 "birch/distribution/ScaledGammaExponential.birch"
  libbirch::tie(this_()->_u0955->k, this_()->_u0955->_u0952) = birch::update_lazy_scaled_gamma_exponential(x, this_()->a, this_()->_u0955->k, this_()->_u0955->_u0952, handler_);
}

#line 45 "birch/distribution/ScaledGammaExponential.birch"
void birch::type::ScaledGammaExponential::downdate(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_function_("downdate", "birch/distribution/ScaledGammaExponential.birch", 45);
  #line 46 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_line_(46);
  #line 46 "birch/distribution/ScaledGammaExponential.birch"
  libbirch::tie(this_()->_u0955->k, this_()->_u0955->_u0952) = birch::box(birch::downdate_scaled_gamma_exponential(x, this_()->a->value(handler_), this_()->_u0955->k->value(handler_), this_()->_u0955->_u0952->value(handler_), handler_), handler_);
}

#line 50 "birch/distribution/ScaledGammaExponential.birch"
libbirch::Optional<birch::type::Real> birch::type::ScaledGammaExponential::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_function_("cdf", "birch/distribution/ScaledGammaExponential.birch", 50);
  #line 51 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_line_(51);
  #line 51 "birch/distribution/ScaledGammaExponential.birch"
  return birch::cdf_lomax(x, 1.0 / (this_()->a->value(handler_) * this_()->_u0955->_u0952->value(handler_)), this_()->_u0955->k->value(handler_), handler_);
}

#line 54 "birch/distribution/ScaledGammaExponential.birch"
libbirch::Optional<birch::type::Real> birch::type::ScaledGammaExponential::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_function_("quantile", "birch/distribution/ScaledGammaExponential.birch", 54);
  #line 55 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_line_(55);
  #line 55 "birch/distribution/ScaledGammaExponential.birch"
  return birch::quantile_lomax(P, 1.0 / (this_()->a->value(handler_) * this_()->_u0955->_u0952->value(handler_)), this_()->_u0955->k->value(handler_), handler_);
}

#line 58 "birch/distribution/ScaledGammaExponential.birch"
libbirch::Optional<birch::type::Real> birch::type::ScaledGammaExponential::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_function_("lower", "birch/distribution/ScaledGammaExponential.birch", 58);
  #line 59 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_line_(59);
  #line 59 "birch/distribution/ScaledGammaExponential.birch"
  return 0.0;
}

#line 62 "birch/distribution/ScaledGammaExponential.birch"
void birch::type::ScaledGammaExponential::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 62 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_function_("link", "birch/distribution/ScaledGammaExponential.birch", 62);
  #line 63 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_line_(63);
  #line 63 "birch/distribution/ScaledGammaExponential.birch"
  this_()->_u0955->setChild(shared_from_this_(), handler_);
}

#line 66 "birch/distribution/ScaledGammaExponential.birch"
void birch::type::ScaledGammaExponential::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_function_("unlink", "birch/distribution/ScaledGammaExponential.birch", 66);
  #line 67 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_line_(67);
  #line 67 "birch/distribution/ScaledGammaExponential.birch"
  this_()->_u0955->releaseChild(shared_from_this_(), handler_);
}

#line 71 "birch/distribution/ScaledGammaExponential.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScaledGammaExponential>> birch::ScaledGammaExponential(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 71 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_function_("ScaledGammaExponential", "birch/distribution/ScaledGammaExponential.birch", 71);
  #line 73 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_line_(73);
  #line 73 "birch/distribution/ScaledGammaExponential.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::ScaledGammaExponential>> m(a, _u0955);
  #line 74 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_line_(74);
  #line 74 "birch/distribution/ScaledGammaExponential.birch"
  m->link(handler_);
  #line 75 "birch/distribution/ScaledGammaExponential.birch"
  libbirch_line_(75);
  #line 75 "birch/distribution/ScaledGammaExponential.birch"
  return m;
}

#line 4 "birch/distribution/ScaledGammaPoisson.birch"
birch::type::ScaledGammaPoisson::ScaledGammaPoisson(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/ScaledGammaPoisson.birch"
    super_type_(),
    #line 8 "birch/distribution/ScaledGammaPoisson.birch"
    a(a),
    #line 13 "birch/distribution/ScaledGammaPoisson.birch"
    _u0955(_u0955) {
  //
}

#line 15 "birch/distribution/ScaledGammaPoisson.birch"
birch::type::Boolean birch::type::ScaledGammaPoisson::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("supportsLazy", "birch/distribution/ScaledGammaPoisson.birch", 15);
  #line 16 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(16);
  #line 16 "birch/distribution/ScaledGammaPoisson.birch"
  return true;
}

#line 19 "birch/distribution/ScaledGammaPoisson.birch"
birch::type::Integer birch::type::ScaledGammaPoisson::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 19 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("simulate", "birch/distribution/ScaledGammaPoisson.birch", 19);
  #line 20 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(20);
  #line 20 "birch/distribution/ScaledGammaPoisson.birch"
  if (this_()->value.query()) {
    #line 21 "birch/distribution/ScaledGammaPoisson.birch"
    libbirch_line_(21);
    #line 21 "birch/distribution/ScaledGammaPoisson.birch"
    return this_()->value.get();
  } else {
    #line 23 "birch/distribution/ScaledGammaPoisson.birch"
    libbirch_line_(23);
    #line 23 "birch/distribution/ScaledGammaPoisson.birch"
    return birch::simulate_gamma_poisson(this_()->_u0955->k->value(handler_), this_()->a->value(handler_) * this_()->_u0955->_u0952->value(handler_), handler_);
  }
}

#line 27 "birch/distribution/ScaledGammaPoisson.birch"
libbirch::Optional<birch::type::Integer> birch::type::ScaledGammaPoisson::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("simulateLazy", "birch/distribution/ScaledGammaPoisson.birch", 27);
  #line 28 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(28);
  #line 28 "birch/distribution/ScaledGammaPoisson.birch"
  if (this_()->value.query()) {
    #line 29 "birch/distribution/ScaledGammaPoisson.birch"
    libbirch_line_(29);
    #line 29 "birch/distribution/ScaledGammaPoisson.birch"
    return this_()->value.get();
  } else {
    #line 31 "birch/distribution/ScaledGammaPoisson.birch"
    libbirch_line_(31);
    #line 31 "birch/distribution/ScaledGammaPoisson.birch"
    return birch::simulate_gamma_poisson(this_()->_u0955->k->get(handler_), this_()->a->get(handler_) * this_()->_u0955->_u0952->get(handler_), handler_);
  }
}

#line 35 "birch/distribution/ScaledGammaPoisson.birch"
birch::type::Real birch::type::ScaledGammaPoisson::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("logpdf", "birch/distribution/ScaledGammaPoisson.birch", 35);
  #line 36 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(36);
  #line 36 "birch/distribution/ScaledGammaPoisson.birch"
  return birch::logpdf_gamma_poisson(x, this_()->_u0955->k->value(handler_), this_()->a->value(handler_) * this_()->_u0955->_u0952->value(handler_), handler_);
}

#line 39 "birch/distribution/ScaledGammaPoisson.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::ScaledGammaPoisson::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/ScaledGammaPoisson.birch", 39);
  #line 40 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(40);
  #line 40 "birch/distribution/ScaledGammaPoisson.birch"
  return birch::logpdf_lazy_gamma_poisson(x, this_()->_u0955->k, this_()->a * this_()->_u0955->_u0952, handler_);
}

#line 43 "birch/distribution/ScaledGammaPoisson.birch"
void birch::type::ScaledGammaPoisson::update(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("update", "birch/distribution/ScaledGammaPoisson.birch", 43);
  #line 44 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(44);
  #line 44 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch::tie(this_()->_u0955->k, this_()->_u0955->_u0952) = birch::box(birch::update_scaled_gamma_poisson(x, this_()->a->value(handler_), this_()->_u0955->k->value(handler_), this_()->_u0955->_u0952->value(handler_), handler_), handler_);
}

#line 48 "birch/distribution/ScaledGammaPoisson.birch"
void birch::type::ScaledGammaPoisson::updateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("updateLazy", "birch/distribution/ScaledGammaPoisson.birch", 48);
  #line 49 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(49);
  #line 49 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch::tie(this_()->_u0955->k, this_()->_u0955->_u0952) = birch::update_lazy_scaled_gamma_poisson(x, this_()->a, this_()->_u0955->k, this_()->_u0955->_u0952, handler_);
}

#line 52 "birch/distribution/ScaledGammaPoisson.birch"
void birch::type::ScaledGammaPoisson::downdate(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("downdate", "birch/distribution/ScaledGammaPoisson.birch", 52);
  #line 53 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(53);
  #line 53 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch::tie(this_()->_u0955->k, this_()->_u0955->_u0952) = birch::box(birch::downdate_scaled_gamma_poisson(x, this_()->a->value(handler_), this_()->_u0955->k->value(handler_), this_()->_u0955->_u0952->value(handler_), handler_), handler_);
}

#line 57 "birch/distribution/ScaledGammaPoisson.birch"
libbirch::Optional<birch::type::Real> birch::type::ScaledGammaPoisson::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 57 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("cdf", "birch/distribution/ScaledGammaPoisson.birch", 57);
  #line 58 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(58);
  #line 58 "birch/distribution/ScaledGammaPoisson.birch"
  return birch::cdf_gamma_poisson(x, this_()->_u0955->k->value(handler_), this_()->a->value(handler_) * this_()->_u0955->_u0952->value(handler_), handler_);
}

#line 61 "birch/distribution/ScaledGammaPoisson.birch"
libbirch::Optional<birch::type::Integer> birch::type::ScaledGammaPoisson::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("quantile", "birch/distribution/ScaledGammaPoisson.birch", 61);
  #line 62 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(62);
  #line 62 "birch/distribution/ScaledGammaPoisson.birch"
  return birch::quantile_gamma_poisson(P, this_()->_u0955->k->value(handler_), this_()->a->value(handler_) * this_()->_u0955->_u0952->value(handler_), handler_);
}

#line 65 "birch/distribution/ScaledGammaPoisson.birch"
libbirch::Optional<birch::type::Integer> birch::type::ScaledGammaPoisson::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("lower", "birch/distribution/ScaledGammaPoisson.birch", 65);
  #line 66 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(66);
  #line 66 "birch/distribution/ScaledGammaPoisson.birch"
  return birch::type::Integer(0);
}

#line 69 "birch/distribution/ScaledGammaPoisson.birch"
void birch::type::ScaledGammaPoisson::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("link", "birch/distribution/ScaledGammaPoisson.birch", 69);
  #line 70 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(70);
  #line 70 "birch/distribution/ScaledGammaPoisson.birch"
  this_()->_u0955->setChild(shared_from_this_(), handler_);
}

#line 73 "birch/distribution/ScaledGammaPoisson.birch"
void birch::type::ScaledGammaPoisson::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 73 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("unlink", "birch/distribution/ScaledGammaPoisson.birch", 73);
  #line 74 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(74);
  #line 74 "birch/distribution/ScaledGammaPoisson.birch"
  this_()->_u0955->releaseChild(shared_from_this_(), handler_);
}

#line 78 "birch/distribution/ScaledGammaPoisson.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ScaledGammaPoisson>> birch::ScaledGammaPoisson(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& a, const libbirch::Lazy<libbirch::Shared<birch::type::Gamma>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 78 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_function_("ScaledGammaPoisson", "birch/distribution/ScaledGammaPoisson.birch", 78);
  #line 80 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(80);
  #line 80 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::ScaledGammaPoisson>> m(a, _u0955);
  #line 81 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(81);
  #line 81 "birch/distribution/ScaledGammaPoisson.birch"
  m->link(handler_);
  #line 82 "birch/distribution/ScaledGammaPoisson.birch"
  libbirch_line_(82);
  #line 82 "birch/distribution/ScaledGammaPoisson.birch"
  return m;
}

#line 4 "birch/distribution/Student.birch"
birch::type::Student::Student(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/Student.birch"
    super_type_(),
    #line 9 "birch/distribution/Student.birch"
    _u0957(_u0957),
    #line 14 "birch/distribution/Student.birch"
    _u0956(_u0956),
    #line 19 "birch/distribution/Student.birch"
    _u09632(_u09632) {
  //
}

#line 21 "birch/distribution/Student.birch"
birch::type::Boolean birch::type::Student::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "birch/distribution/Student.birch"
  libbirch_function_("supportsLazy", "birch/distribution/Student.birch", 21);
  #line 22 "birch/distribution/Student.birch"
  libbirch_line_(22);
  #line 22 "birch/distribution/Student.birch"
  return true;
}

#line 25 "birch/distribution/Student.birch"
birch::type::Real birch::type::Student::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "birch/distribution/Student.birch"
  libbirch_function_("simulate", "birch/distribution/Student.birch", 25);
  #line 26 "birch/distribution/Student.birch"
  libbirch_line_(26);
  #line 26 "birch/distribution/Student.birch"
  return birch::simulate_student_t(this_()->_u0957->value(handler_), this_()->_u0956->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 29 "birch/distribution/Student.birch"
libbirch::Optional<birch::type::Real> birch::type::Student::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "birch/distribution/Student.birch"
  libbirch_function_("simulateLazy", "birch/distribution/Student.birch", 29);
  #line 30 "birch/distribution/Student.birch"
  libbirch_line_(30);
  #line 30 "birch/distribution/Student.birch"
  return birch::simulate_student_t(this_()->_u0957->get(handler_), this_()->_u0956->get(handler_), this_()->_u09632->get(handler_), handler_);
}

#line 33 "birch/distribution/Student.birch"
birch::type::Real birch::type::Student::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 33 "birch/distribution/Student.birch"
  libbirch_function_("logpdf", "birch/distribution/Student.birch", 33);
  #line 34 "birch/distribution/Student.birch"
  libbirch_line_(34);
  #line 34 "birch/distribution/Student.birch"
  return birch::logpdf_student_t(x, this_()->_u0957->value(handler_), this_()->_u0956->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 37 "birch/distribution/Student.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::Student::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "birch/distribution/Student.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/Student.birch", 37);
  #line 38 "birch/distribution/Student.birch"
  libbirch_line_(38);
  #line 38 "birch/distribution/Student.birch"
  return birch::logpdf_lazy_student_t(x, this_()->_u0957, this_()->_u0956, this_()->_u09632, handler_);
}

#line 41 "birch/distribution/Student.birch"
libbirch::Optional<birch::type::Real> birch::type::Student::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "birch/distribution/Student.birch"
  libbirch_function_("cdf", "birch/distribution/Student.birch", 41);
  #line 42 "birch/distribution/Student.birch"
  libbirch_line_(42);
  #line 42 "birch/distribution/Student.birch"
  return birch::cdf_student_t(x, this_()->_u0957->value(handler_), this_()->_u0956->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 45 "birch/distribution/Student.birch"
libbirch::Optional<birch::type::Real> birch::type::Student::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "birch/distribution/Student.birch"
  libbirch_function_("quantile", "birch/distribution/Student.birch", 45);
  #line 46 "birch/distribution/Student.birch"
  libbirch_line_(46);
  #line 46 "birch/distribution/Student.birch"
  return birch::quantile_student_t(P, this_()->_u0957->value(handler_), this_()->_u0956->value(handler_), this_()->_u09632->value(handler_), handler_);
}

#line 49 "birch/distribution/Student.birch"
void birch::type::Student::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "birch/distribution/Student.birch"
  libbirch_function_("write", "birch/distribution/Student.birch", 49);
  #line 50 "birch/distribution/Student.birch"
  libbirch_line_(50);
  #line 50 "birch/distribution/Student.birch"
  this_()->prune(handler_);
  #line 51 "birch/distribution/Student.birch"
  libbirch_line_(51);
  #line 51 "birch/distribution/Student.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Student"), handler_);
  #line 52 "birch/distribution/Student.birch"
  libbirch_line_(52);
  #line 52 "birch/distribution/Student.birch"
  buffer->set(birch::type::String("ν"), this_()->_u0957, handler_);
  #line 53 "birch/distribution/Student.birch"
  libbirch_line_(53);
  #line 53 "birch/distribution/Student.birch"
  buffer->set(birch::type::String("μ"), this_()->_u0956, handler_);
  #line 54 "birch/distribution/Student.birch"
  libbirch_line_(54);
  #line 54 "birch/distribution/Student.birch"
  buffer->set(birch::type::String("σ2"), this_()->_u09632, handler_);
}

#line 61 "birch/distribution/Student.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Student>> birch::Student(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "birch/distribution/Student.birch"
  libbirch_function_("Student", "birch/distribution/Student.birch", 61);
  #line 63 "birch/distribution/Student.birch"
  libbirch_line_(63);
  #line 63 "birch/distribution/Student.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Student>>>(_u0957, _u0956, _u09632, handler_);
}

#line 69 "birch/distribution/Student.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Student>> birch::Student(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "birch/distribution/Student.birch"
  libbirch_function_("Student", "birch/distribution/Student.birch", 69);
  #line 70 "birch/distribution/Student.birch"
  libbirch_line_(70);
  #line 70 "birch/distribution/Student.birch"
  return birch::Student(_u0957, birch::box(0.0, handler_), birch::box(1.0, handler_), handler_);
}

#line 76 "birch/distribution/Student.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Student>> birch::Student(const birch::type::Real& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "birch/distribution/Student.birch"
  libbirch_function_("Student", "birch/distribution/Student.birch", 76);
  #line 77 "birch/distribution/Student.birch"
  libbirch_line_(77);
  #line 77 "birch/distribution/Student.birch"
  return birch::Student(birch::box(_u0957, handler_), birch::box(0.0, handler_), birch::box(1.0, handler_), handler_);
}

#line 83 "birch/distribution/Student.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Student>> birch::Student(const birch::type::Real& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 83 "birch/distribution/Student.birch"
  libbirch_function_("Student", "birch/distribution/Student.birch", 83);
  #line 84 "birch/distribution/Student.birch"
  libbirch_line_(84);
  #line 84 "birch/distribution/Student.birch"
  return birch::Student(birch::box(_u0957, handler_), _u0956, _u09632, handler_);
}

#line 90 "birch/distribution/Student.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Student>> birch::Student(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0957, const birch::type::Real& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 90 "birch/distribution/Student.birch"
  libbirch_function_("Student", "birch/distribution/Student.birch", 90);
  #line 91 "birch/distribution/Student.birch"
  libbirch_line_(91);
  #line 91 "birch/distribution/Student.birch"
  return birch::Student(_u0957, birch::box(_u0956, handler_), _u09632, handler_);
}

#line 97 "birch/distribution/Student.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Student>> birch::Student(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 97 "birch/distribution/Student.birch"
  libbirch_function_("Student", "birch/distribution/Student.birch", 97);
  #line 98 "birch/distribution/Student.birch"
  libbirch_line_(98);
  #line 98 "birch/distribution/Student.birch"
  return birch::Student(_u0957, _u0956, birch::box(_u09632, handler_), handler_);
}

#line 104 "birch/distribution/Student.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Student>> birch::Student(const birch::type::Real& _u0957, const birch::type::Real& _u0956, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 104 "birch/distribution/Student.birch"
  libbirch_function_("Student", "birch/distribution/Student.birch", 104);
  #line 105 "birch/distribution/Student.birch"
  libbirch_line_(105);
  #line 105 "birch/distribution/Student.birch"
  return birch::Student(birch::box(_u0957, handler_), birch::box(_u0956, handler_), _u09632, handler_);
}

#line 111 "birch/distribution/Student.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Student>> birch::Student(const birch::type::Real& _u0957, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 111 "birch/distribution/Student.birch"
  libbirch_function_("Student", "birch/distribution/Student.birch", 111);
  #line 112 "birch/distribution/Student.birch"
  libbirch_line_(112);
  #line 112 "birch/distribution/Student.birch"
  return birch::Student(birch::box(_u0957, handler_), _u0956, birch::box(_u09632, handler_), handler_);
}

#line 118 "birch/distribution/Student.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Student>> birch::Student(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0957, const birch::type::Real& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 118 "birch/distribution/Student.birch"
  libbirch_function_("Student", "birch/distribution/Student.birch", 118);
  #line 119 "birch/distribution/Student.birch"
  libbirch_line_(119);
  #line 119 "birch/distribution/Student.birch"
  return birch::Student(_u0957, birch::box(_u0956, handler_), birch::box(_u09632, handler_), handler_);
}

#line 125 "birch/distribution/Student.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Student>> birch::Student(const birch::type::Real& _u0957, const birch::type::Real& _u0956, const birch::type::Real& _u09632, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 125 "birch/distribution/Student.birch"
  libbirch_function_("Student", "birch/distribution/Student.birch", 125);
  #line 126 "birch/distribution/Student.birch"
  libbirch_line_(126);
  #line 126 "birch/distribution/Student.birch"
  return birch::Student(birch::box(_u0957, handler_), birch::box(_u0956, handler_), birch::box(_u09632, handler_), handler_);
}

#line 5 "birch/distribution/SubtractBoundedDiscrete.birch"
birch::type::SubtractBoundedDiscrete::SubtractBoundedDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>& x1, const libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>& x2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 5 "birch/distribution/SubtractBoundedDiscrete.birch"
    super_type_(),
    #line 10 "birch/distribution/SubtractBoundedDiscrete.birch"
    x1(x1),
    #line 15 "birch/distribution/SubtractBoundedDiscrete.birch"
    x2(x2),
    #line 20 "birch/distribution/SubtractBoundedDiscrete.birch"
    x(),
    #line 25 "birch/distribution/SubtractBoundedDiscrete.birch"
    x0(),
    #line 30 "birch/distribution/SubtractBoundedDiscrete.birch"
    z(),
    #line 35 "birch/distribution/SubtractBoundedDiscrete.birch"
    Z(),
    #line 43 "birch/distribution/SubtractBoundedDiscrete.birch"
    alreadyUpdated(false) {
  //
}

#line 45 "birch/distribution/SubtractBoundedDiscrete.birch"
void birch::type::SubtractBoundedDiscrete::enumerate(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("enumerate", "birch/distribution/SubtractBoundedDiscrete.birch", 45);
  #line 46 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(46);
  #line 46 "birch/distribution/SubtractBoundedDiscrete.birch"
  if (!this_()->x.query() || this_()->x.get() != x) {
    #line 47 "birch/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(47);
    #line 47 "birch/distribution/SubtractBoundedDiscrete.birch"
    auto l = birch::max(this_()->x1->lower(handler_).get(), this_()->x2->lower(handler_).get() + x, handler_);
    #line 48 "birch/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(48);
    #line 48 "birch/distribution/SubtractBoundedDiscrete.birch"
    auto u = birch::min(this_()->x1->upper(handler_).get(), this_()->x2->upper(handler_).get() + x, handler_);
    #line 50 "birch/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(50);
    #line 50 "birch/distribution/SubtractBoundedDiscrete.birch"
    this_()->x0 = l;
    #line 51 "birch/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(51);
    #line 51 "birch/distribution/SubtractBoundedDiscrete.birch"
    this_()->Z = 0.0;
    #line 52 "birch/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(52);
    #line 52 "birch/distribution/SubtractBoundedDiscrete.birch"
    if (l <= u) {
      #line 54 "birch/distribution/SubtractBoundedDiscrete.birch"
      libbirch_line_(54);
      #line 54 "birch/distribution/SubtractBoundedDiscrete.birch"
      this_()->z = birch::vector(0.0, u - l + birch::type::Integer(1), handler_);
      #line 55 "birch/distribution/SubtractBoundedDiscrete.birch"
      libbirch_line_(55);
      #line 55 "birch/distribution/SubtractBoundedDiscrete.birch"
      for (auto n = l; n <= u; ++n) {
        #line 56 "birch/distribution/SubtractBoundedDiscrete.birch"
        libbirch_line_(56);
        #line 56 "birch/distribution/SubtractBoundedDiscrete.birch"
        this_()->z.set(libbirch::make_slice(n - l + birch::type::Integer(1) - 1), this_()->x1->pdf(n, handler_) * this_()->x2->pdf(n - x, handler_));
        #line 57 "birch/distribution/SubtractBoundedDiscrete.birch"
        libbirch_line_(57);
        #line 57 "birch/distribution/SubtractBoundedDiscrete.birch"
        this_()->Z = this_()->Z + this_()->z.get(libbirch::make_slice(n - l + birch::type::Integer(1) - 1));
      }
    }
    #line 60 "birch/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(60);
    #line 60 "birch/distribution/SubtractBoundedDiscrete.birch"
    this_()->x = x;
  }
}

#line 64 "birch/distribution/SubtractBoundedDiscrete.birch"
birch::type::Boolean birch::type::SubtractBoundedDiscrete::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 64 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("supportsLazy", "birch/distribution/SubtractBoundedDiscrete.birch", 64);
  #line 65 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(65);
  #line 65 "birch/distribution/SubtractBoundedDiscrete.birch"
  return false;
}

#line 68 "birch/distribution/SubtractBoundedDiscrete.birch"
birch::type::Integer birch::type::SubtractBoundedDiscrete::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 68 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("simulate", "birch/distribution/SubtractBoundedDiscrete.birch", 68);
  #line 69 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(69);
  #line 69 "birch/distribution/SubtractBoundedDiscrete.birch"
  if (this_()->value.query()) {
    #line 70 "birch/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(70);
    #line 70 "birch/distribution/SubtractBoundedDiscrete.birch"
    return birch::simulate_delta(this_()->value.get(), handler_);
  } else {
    #line 72 "birch/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(72);
    #line 72 "birch/distribution/SubtractBoundedDiscrete.birch"
    return birch::simulate_delta(this_()->x1->simulate(handler_) - this_()->x2->simulate(handler_), handler_);
  }
}

#line 84 "birch/distribution/SubtractBoundedDiscrete.birch"
birch::type::Real birch::type::SubtractBoundedDiscrete::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 84 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("logpdf", "birch/distribution/SubtractBoundedDiscrete.birch", 84);
  #line 85 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(85);
  #line 85 "birch/distribution/SubtractBoundedDiscrete.birch"
  if (this_()->value.query()) {
    #line 86 "birch/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(86);
    #line 86 "birch/distribution/SubtractBoundedDiscrete.birch"
    return birch::logpdf_delta(x, this_()->value.get(), handler_);
  } else {
    #line 88 "birch/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(88);
    #line 88 "birch/distribution/SubtractBoundedDiscrete.birch"
    this_()->enumerate(x, handler_);
    #line 89 "birch/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(89);
    #line 89 "birch/distribution/SubtractBoundedDiscrete.birch"
    return birch::log(this_()->Z, handler_);
  }
}

#line 102 "birch/distribution/SubtractBoundedDiscrete.birch"
void birch::type::SubtractBoundedDiscrete::update(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 102 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("update", "birch/distribution/SubtractBoundedDiscrete.birch", 102);
  #line 103 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(103);
  #line 103 "birch/distribution/SubtractBoundedDiscrete.birch"
  if (!this_()->alreadyUpdated) {
    #line 105 "birch/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(105);
    #line 105 "birch/distribution/SubtractBoundedDiscrete.birch"
    this_()->enumerate(x, handler_);
    #line 106 "birch/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(106);
    #line 106 "birch/distribution/SubtractBoundedDiscrete.birch"
    auto n = birch::simulate_categorical(this_()->z, this_()->Z, handler_) + this_()->x0 - birch::type::Integer(1);
    #line 107 "birch/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(107);
    #line 107 "birch/distribution/SubtractBoundedDiscrete.birch"
    this_()->x1->clamp(n, handler_);
    #line 108 "birch/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(108);
    #line 108 "birch/distribution/SubtractBoundedDiscrete.birch"
    this_()->x2->clamp(n - x, handler_);
    #line 109 "birch/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(109);
    #line 109 "birch/distribution/SubtractBoundedDiscrete.birch"
    this_()->alreadyUpdated = true;
  }
}

#line 117 "birch/distribution/SubtractBoundedDiscrete.birch"
libbirch::Optional<birch::type::Real> birch::type::SubtractBoundedDiscrete::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 117 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("cdf", "birch/distribution/SubtractBoundedDiscrete.birch", 117);
  #line 118 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(118);
  #line 118 "birch/distribution/SubtractBoundedDiscrete.birch"
  auto P = 0.0;
  #line 119 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(119);
  #line 119 "birch/distribution/SubtractBoundedDiscrete.birch"
  for (auto n = this_()->lower(handler_).get(); n <= x; ++n) {
    #line 120 "birch/distribution/SubtractBoundedDiscrete.birch"
    libbirch_line_(120);
    #line 120 "birch/distribution/SubtractBoundedDiscrete.birch"
    P = P + this_()->pdf(n, handler_);
  }
  #line 122 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(122);
  #line 122 "birch/distribution/SubtractBoundedDiscrete.birch"
  return P;
}

#line 125 "birch/distribution/SubtractBoundedDiscrete.birch"
libbirch::Optional<birch::type::Integer> birch::type::SubtractBoundedDiscrete::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 125 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("lower", "birch/distribution/SubtractBoundedDiscrete.birch", 125);
  #line 126 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(126);
  #line 126 "birch/distribution/SubtractBoundedDiscrete.birch"
  return this_()->x1->lower(handler_).get() - this_()->x2->upper(handler_).get();
}

#line 129 "birch/distribution/SubtractBoundedDiscrete.birch"
libbirch::Optional<birch::type::Integer> birch::type::SubtractBoundedDiscrete::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 129 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("upper", "birch/distribution/SubtractBoundedDiscrete.birch", 129);
  #line 130 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(130);
  #line 130 "birch/distribution/SubtractBoundedDiscrete.birch"
  return this_()->x1->upper(handler_).get() - this_()->x2->lower(handler_).get();
}

#line 133 "birch/distribution/SubtractBoundedDiscrete.birch"
void birch::type::SubtractBoundedDiscrete::link(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 133 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("link", "birch/distribution/SubtractBoundedDiscrete.birch", 133);
}

#line 139 "birch/distribution/SubtractBoundedDiscrete.birch"
void birch::type::SubtractBoundedDiscrete::unlink(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 139 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("unlink", "birch/distribution/SubtractBoundedDiscrete.birch", 139);
}

#line 146 "birch/distribution/SubtractBoundedDiscrete.birch"
libbirch::Lazy<libbirch::Shared<birch::type::SubtractBoundedDiscrete>> birch::SubtractBoundedDiscrete(const libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>& x1, const libbirch::Lazy<libbirch::Shared<birch::type::BoundedDiscrete>>& x2, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 146 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch_function_("SubtractBoundedDiscrete", "birch/distribution/SubtractBoundedDiscrete.birch", 146);
  #line 148 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(148);
  #line 148 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::SubtractBoundedDiscrete>> m(x1, x2);
  #line 149 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(149);
  #line 149 "birch/distribution/SubtractBoundedDiscrete.birch"
  m->link(handler_);
  #line 150 "birch/distribution/SubtractBoundedDiscrete.birch"
  libbirch_line_(150);
  #line 150 "birch/distribution/SubtractBoundedDiscrete.birch"
  return m;
}

#line 4 "birch/distribution/Uniform.birch"
birch::type::Uniform::Uniform(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& l, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/Uniform.birch"
    super_type_(),
    #line 9 "birch/distribution/Uniform.birch"
    l(l),
    #line 14 "birch/distribution/Uniform.birch"
    u(u) {
  //
}

#line 16 "birch/distribution/Uniform.birch"
birch::type::Boolean birch::type::Uniform::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "birch/distribution/Uniform.birch"
  libbirch_function_("supportsLazy", "birch/distribution/Uniform.birch", 16);
  #line 17 "birch/distribution/Uniform.birch"
  libbirch_line_(17);
  #line 17 "birch/distribution/Uniform.birch"
  return false;
}

#line 20 "birch/distribution/Uniform.birch"
birch::type::Real birch::type::Uniform::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "birch/distribution/Uniform.birch"
  libbirch_function_("simulate", "birch/distribution/Uniform.birch", 20);
  #line 21 "birch/distribution/Uniform.birch"
  libbirch_line_(21);
  #line 21 "birch/distribution/Uniform.birch"
  return birch::simulate_uniform(this_()->l->value(handler_), this_()->u->value(handler_), handler_);
}

#line 28 "birch/distribution/Uniform.birch"
birch::type::Real birch::type::Uniform::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "birch/distribution/Uniform.birch"
  libbirch_function_("logpdf", "birch/distribution/Uniform.birch", 28);
  #line 29 "birch/distribution/Uniform.birch"
  libbirch_line_(29);
  #line 29 "birch/distribution/Uniform.birch"
  return birch::logpdf_uniform(x, this_()->l->value(handler_), this_()->u->value(handler_), handler_);
}

#line 36 "birch/distribution/Uniform.birch"
libbirch::Optional<birch::type::Real> birch::type::Uniform::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "birch/distribution/Uniform.birch"
  libbirch_function_("cdf", "birch/distribution/Uniform.birch", 36);
  #line 37 "birch/distribution/Uniform.birch"
  libbirch_line_(37);
  #line 37 "birch/distribution/Uniform.birch"
  return birch::cdf_uniform(x, this_()->l->value(handler_), this_()->u->value(handler_), handler_);
}

#line 40 "birch/distribution/Uniform.birch"
libbirch::Optional<birch::type::Real> birch::type::Uniform::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "birch/distribution/Uniform.birch"
  libbirch_function_("quantile", "birch/distribution/Uniform.birch", 40);
  #line 41 "birch/distribution/Uniform.birch"
  libbirch_line_(41);
  #line 41 "birch/distribution/Uniform.birch"
  return birch::quantile_uniform(P, this_()->l->value(handler_), this_()->u->value(handler_), handler_);
}

#line 44 "birch/distribution/Uniform.birch"
libbirch::Optional<birch::type::Real> birch::type::Uniform::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "birch/distribution/Uniform.birch"
  libbirch_function_("lower", "birch/distribution/Uniform.birch", 44);
  #line 45 "birch/distribution/Uniform.birch"
  libbirch_line_(45);
  #line 45 "birch/distribution/Uniform.birch"
  return this_()->l->value(handler_);
}

#line 48 "birch/distribution/Uniform.birch"
libbirch::Optional<birch::type::Real> birch::type::Uniform::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "birch/distribution/Uniform.birch"
  libbirch_function_("upper", "birch/distribution/Uniform.birch", 48);
  #line 49 "birch/distribution/Uniform.birch"
  libbirch_line_(49);
  #line 49 "birch/distribution/Uniform.birch"
  return this_()->u->value(handler_);
}

#line 52 "birch/distribution/Uniform.birch"
void birch::type::Uniform::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "birch/distribution/Uniform.birch"
  libbirch_function_("write", "birch/distribution/Uniform.birch", 52);
  #line 53 "birch/distribution/Uniform.birch"
  libbirch_line_(53);
  #line 53 "birch/distribution/Uniform.birch"
  this_()->prune(handler_);
  #line 54 "birch/distribution/Uniform.birch"
  libbirch_line_(54);
  #line 54 "birch/distribution/Uniform.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Uniform"), handler_);
  #line 55 "birch/distribution/Uniform.birch"
  libbirch_line_(55);
  #line 55 "birch/distribution/Uniform.birch"
  buffer->set(birch::type::String("l"), this_()->l, handler_);
  #line 56 "birch/distribution/Uniform.birch"
  libbirch_line_(56);
  #line 56 "birch/distribution/Uniform.birch"
  buffer->set(birch::type::String("u"), this_()->u, handler_);
}

#line 63 "birch/distribution/Uniform.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Uniform>> birch::Uniform(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& l, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 63 "birch/distribution/Uniform.birch"
  libbirch_function_("Uniform", "birch/distribution/Uniform.birch", 63);
  #line 64 "birch/distribution/Uniform.birch"
  libbirch_line_(64);
  #line 64 "birch/distribution/Uniform.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Uniform>>>(l, u, handler_);
}

#line 70 "birch/distribution/Uniform.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Uniform>> birch::Uniform(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& l, const birch::type::Real& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "birch/distribution/Uniform.birch"
  libbirch_function_("Uniform", "birch/distribution/Uniform.birch", 70);
  #line 71 "birch/distribution/Uniform.birch"
  libbirch_line_(71);
  #line 71 "birch/distribution/Uniform.birch"
  return birch::Uniform(l, birch::box(u, handler_), handler_);
}

#line 77 "birch/distribution/Uniform.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Uniform>> birch::Uniform(const birch::type::Real& l, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 77 "birch/distribution/Uniform.birch"
  libbirch_function_("Uniform", "birch/distribution/Uniform.birch", 77);
  #line 78 "birch/distribution/Uniform.birch"
  libbirch_line_(78);
  #line 78 "birch/distribution/Uniform.birch"
  return birch::Uniform(birch::box(l, handler_), u, handler_);
}

#line 84 "birch/distribution/Uniform.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Uniform>> birch::Uniform(const birch::type::Real& l, const birch::type::Real& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 84 "birch/distribution/Uniform.birch"
  libbirch_function_("Uniform", "birch/distribution/Uniform.birch", 84);
  #line 85 "birch/distribution/Uniform.birch"
  libbirch_line_(85);
  #line 85 "birch/distribution/Uniform.birch"
  return birch::Uniform(birch::box(l, handler_), birch::box(u, handler_), handler_);
}

#line 4 "birch/distribution/UniformInteger.birch"
birch::type::UniformInteger::UniformInteger(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& l, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/UniformInteger.birch"
    super_type_(),
    #line 9 "birch/distribution/UniformInteger.birch"
    l(l),
    #line 14 "birch/distribution/UniformInteger.birch"
    u(u) {
  //
}

#line 16 "birch/distribution/UniformInteger.birch"
birch::type::Boolean birch::type::UniformInteger::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "birch/distribution/UniformInteger.birch"
  libbirch_function_("supportsLazy", "birch/distribution/UniformInteger.birch", 16);
  #line 17 "birch/distribution/UniformInteger.birch"
  libbirch_line_(17);
  #line 17 "birch/distribution/UniformInteger.birch"
  return false;
}

#line 20 "birch/distribution/UniformInteger.birch"
birch::type::Integer birch::type::UniformInteger::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "birch/distribution/UniformInteger.birch"
  libbirch_function_("simulate", "birch/distribution/UniformInteger.birch", 20);
  #line 21 "birch/distribution/UniformInteger.birch"
  libbirch_line_(21);
  #line 21 "birch/distribution/UniformInteger.birch"
  if (this_()->value.query()) {
    #line 22 "birch/distribution/UniformInteger.birch"
    libbirch_line_(22);
    #line 22 "birch/distribution/UniformInteger.birch"
    return this_()->value.get();
  } else {
    #line 24 "birch/distribution/UniformInteger.birch"
    libbirch_line_(24);
    #line 24 "birch/distribution/UniformInteger.birch"
    return birch::simulate_uniform_int(this_()->l->value(handler_), this_()->u->value(handler_), handler_);
  }
}

#line 36 "birch/distribution/UniformInteger.birch"
birch::type::Real birch::type::UniformInteger::logpdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "birch/distribution/UniformInteger.birch"
  libbirch_function_("logpdf", "birch/distribution/UniformInteger.birch", 36);
  #line 37 "birch/distribution/UniformInteger.birch"
  libbirch_line_(37);
  #line 37 "birch/distribution/UniformInteger.birch"
  return birch::logpdf_uniform_int(x, this_()->l->value(handler_), this_()->u->value(handler_), handler_);
}

#line 44 "birch/distribution/UniformInteger.birch"
libbirch::Optional<birch::type::Real> birch::type::UniformInteger::cdf(const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "birch/distribution/UniformInteger.birch"
  libbirch_function_("cdf", "birch/distribution/UniformInteger.birch", 44);
  #line 45 "birch/distribution/UniformInteger.birch"
  libbirch_line_(45);
  #line 45 "birch/distribution/UniformInteger.birch"
  return birch::cdf_uniform_int(x, this_()->l->value(handler_), this_()->u->value(handler_), handler_);
}

#line 48 "birch/distribution/UniformInteger.birch"
libbirch::Optional<birch::type::Integer> birch::type::UniformInteger::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "birch/distribution/UniformInteger.birch"
  libbirch_function_("quantile", "birch/distribution/UniformInteger.birch", 48);
  #line 49 "birch/distribution/UniformInteger.birch"
  libbirch_line_(49);
  #line 49 "birch/distribution/UniformInteger.birch"
  return birch::quantile_uniform_int(P, this_()->l->value(handler_), this_()->u->value(handler_), handler_);
}

#line 52 "birch/distribution/UniformInteger.birch"
libbirch::Optional<birch::type::Integer> birch::type::UniformInteger::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "birch/distribution/UniformInteger.birch"
  libbirch_function_("lower", "birch/distribution/UniformInteger.birch", 52);
  #line 53 "birch/distribution/UniformInteger.birch"
  libbirch_line_(53);
  #line 53 "birch/distribution/UniformInteger.birch"
  return this_()->l->value(handler_);
}

#line 56 "birch/distribution/UniformInteger.birch"
libbirch::Optional<birch::type::Integer> birch::type::UniformInteger::upper(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 56 "birch/distribution/UniformInteger.birch"
  libbirch_function_("upper", "birch/distribution/UniformInteger.birch", 56);
  #line 57 "birch/distribution/UniformInteger.birch"
  libbirch_line_(57);
  #line 57 "birch/distribution/UniformInteger.birch"
  return this_()->u->value(handler_);
}

#line 60 "birch/distribution/UniformInteger.birch"
void birch::type::UniformInteger::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "birch/distribution/UniformInteger.birch"
  libbirch_function_("write", "birch/distribution/UniformInteger.birch", 60);
  #line 61 "birch/distribution/UniformInteger.birch"
  libbirch_line_(61);
  #line 61 "birch/distribution/UniformInteger.birch"
  this_()->prune(handler_);
  #line 62 "birch/distribution/UniformInteger.birch"
  libbirch_line_(62);
  #line 62 "birch/distribution/UniformInteger.birch"
  buffer->set(birch::type::String("class"), birch::type::String("UniformInteger"), handler_);
  #line 63 "birch/distribution/UniformInteger.birch"
  libbirch_line_(63);
  #line 63 "birch/distribution/UniformInteger.birch"
  buffer->set(birch::type::String("l"), this_()->l, handler_);
  #line 64 "birch/distribution/UniformInteger.birch"
  libbirch_line_(64);
  #line 64 "birch/distribution/UniformInteger.birch"
  buffer->set(birch::type::String("u"), this_()->u, handler_);
}

#line 71 "birch/distribution/UniformInteger.birch"
libbirch::Lazy<libbirch::Shared<birch::type::UniformInteger>> birch::Uniform(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& l, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 71 "birch/distribution/UniformInteger.birch"
  libbirch_function_("Uniform", "birch/distribution/UniformInteger.birch", 71);
  #line 73 "birch/distribution/UniformInteger.birch"
  libbirch_line_(73);
  #line 73 "birch/distribution/UniformInteger.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::UniformInteger>>>(l, u, handler_);
}

#line 79 "birch/distribution/UniformInteger.birch"
libbirch::Lazy<libbirch::Shared<birch::type::UniformInteger>> birch::Uniform(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& l, const birch::type::Integer& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 79 "birch/distribution/UniformInteger.birch"
  libbirch_function_("Uniform", "birch/distribution/UniformInteger.birch", 79);
  #line 80 "birch/distribution/UniformInteger.birch"
  libbirch_line_(80);
  #line 80 "birch/distribution/UniformInteger.birch"
  return birch::Uniform(l, birch::box(u, handler_), handler_);
}

#line 86 "birch/distribution/UniformInteger.birch"
libbirch::Lazy<libbirch::Shared<birch::type::UniformInteger>> birch::Uniform(const birch::type::Integer& l, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Integer>>>& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 86 "birch/distribution/UniformInteger.birch"
  libbirch_function_("Uniform", "birch/distribution/UniformInteger.birch", 86);
  #line 87 "birch/distribution/UniformInteger.birch"
  libbirch_line_(87);
  #line 87 "birch/distribution/UniformInteger.birch"
  return birch::Uniform(birch::box(l, handler_), u, handler_);
}

#line 93 "birch/distribution/UniformInteger.birch"
libbirch::Lazy<libbirch::Shared<birch::type::UniformInteger>> birch::Uniform(const birch::type::Integer& l, const birch::type::Integer& u, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 93 "birch/distribution/UniformInteger.birch"
  libbirch_function_("Uniform", "birch/distribution/UniformInteger.birch", 93);
  #line 94 "birch/distribution/UniformInteger.birch"
  libbirch_line_(94);
  #line 94 "birch/distribution/UniformInteger.birch"
  return birch::Uniform(birch::box(l, handler_), birch::box(u, handler_), handler_);
}

#line 4 "birch/distribution/Weibull.birch"
birch::type::Weibull::Weibull(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/Weibull.birch"
    super_type_(),
    #line 9 "birch/distribution/Weibull.birch"
    k(k),
    #line 14 "birch/distribution/Weibull.birch"
    _u0955(_u0955) {
  //
}

#line 16 "birch/distribution/Weibull.birch"
birch::type::Boolean birch::type::Weibull::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "birch/distribution/Weibull.birch"
  libbirch_function_("supportsLazy", "birch/distribution/Weibull.birch", 16);
  #line 17 "birch/distribution/Weibull.birch"
  libbirch_line_(17);
  #line 17 "birch/distribution/Weibull.birch"
  return true;
}

#line 20 "birch/distribution/Weibull.birch"
birch::type::Real birch::type::Weibull::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "birch/distribution/Weibull.birch"
  libbirch_function_("simulate", "birch/distribution/Weibull.birch", 20);
  #line 21 "birch/distribution/Weibull.birch"
  libbirch_line_(21);
  #line 21 "birch/distribution/Weibull.birch"
  return birch::simulate_weibull(this_()->k->value(handler_), this_()->_u0955->value(handler_), handler_);
}

#line 24 "birch/distribution/Weibull.birch"
libbirch::Optional<birch::type::Real> birch::type::Weibull::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "birch/distribution/Weibull.birch"
  libbirch_function_("simulateLazy", "birch/distribution/Weibull.birch", 24);
  #line 25 "birch/distribution/Weibull.birch"
  libbirch_line_(25);
  #line 25 "birch/distribution/Weibull.birch"
  return birch::simulate_weibull(this_()->k->get(handler_), this_()->_u0955->get(handler_), handler_);
}

#line 28 "birch/distribution/Weibull.birch"
birch::type::Real birch::type::Weibull::logpdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "birch/distribution/Weibull.birch"
  libbirch_function_("logpdf", "birch/distribution/Weibull.birch", 28);
  #line 29 "birch/distribution/Weibull.birch"
  libbirch_line_(29);
  #line 29 "birch/distribution/Weibull.birch"
  return birch::logpdf_weibull(x, this_()->k->value(handler_), this_()->_u0955->value(handler_), handler_);
}

#line 32 "birch/distribution/Weibull.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::Weibull::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "birch/distribution/Weibull.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/Weibull.birch", 32);
  #line 33 "birch/distribution/Weibull.birch"
  libbirch_line_(33);
  #line 33 "birch/distribution/Weibull.birch"
  return birch::logpdf_lazy_weibull(x, this_()->k, this_()->_u0955, handler_);
}

#line 36 "birch/distribution/Weibull.birch"
libbirch::Optional<birch::type::Real> birch::type::Weibull::cdf(const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "birch/distribution/Weibull.birch"
  libbirch_function_("cdf", "birch/distribution/Weibull.birch", 36);
  #line 37 "birch/distribution/Weibull.birch"
  libbirch_line_(37);
  #line 37 "birch/distribution/Weibull.birch"
  return birch::cdf_weibull(x, this_()->k->value(handler_), this_()->_u0955->value(handler_), handler_);
}

#line 40 "birch/distribution/Weibull.birch"
libbirch::Optional<birch::type::Real> birch::type::Weibull::quantile(const birch::type::Real& P, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "birch/distribution/Weibull.birch"
  libbirch_function_("quantile", "birch/distribution/Weibull.birch", 40);
  #line 41 "birch/distribution/Weibull.birch"
  libbirch_line_(41);
  #line 41 "birch/distribution/Weibull.birch"
  return birch::quantile_weibull(P, this_()->k->value(handler_), this_()->_u0955->value(handler_), handler_);
}

#line 44 "birch/distribution/Weibull.birch"
libbirch::Optional<birch::type::Real> birch::type::Weibull::lower(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "birch/distribution/Weibull.birch"
  libbirch_function_("lower", "birch/distribution/Weibull.birch", 44);
  #line 45 "birch/distribution/Weibull.birch"
  libbirch_line_(45);
  #line 45 "birch/distribution/Weibull.birch"
  return 0.0;
}

#line 48 "birch/distribution/Weibull.birch"
void birch::type::Weibull::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "birch/distribution/Weibull.birch"
  libbirch_function_("write", "birch/distribution/Weibull.birch", 48);
  #line 49 "birch/distribution/Weibull.birch"
  libbirch_line_(49);
  #line 49 "birch/distribution/Weibull.birch"
  this_()->prune(handler_);
  #line 50 "birch/distribution/Weibull.birch"
  libbirch_line_(50);
  #line 50 "birch/distribution/Weibull.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Weibull"), handler_);
  #line 51 "birch/distribution/Weibull.birch"
  libbirch_line_(51);
  #line 51 "birch/distribution/Weibull.birch"
  buffer->set(birch::type::String("k"), this_()->k, handler_);
  #line 52 "birch/distribution/Weibull.birch"
  libbirch_line_(52);
  #line 52 "birch/distribution/Weibull.birch"
  buffer->set(birch::type::String("λ"), this_()->_u0955, handler_);
}

#line 59 "birch/distribution/Weibull.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Weibull>> birch::Weibull(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "birch/distribution/Weibull.birch"
  libbirch_function_("Weibull", "birch/distribution/Weibull.birch", 59);
  #line 60 "birch/distribution/Weibull.birch"
  libbirch_line_(60);
  #line 60 "birch/distribution/Weibull.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Weibull>>>(k, _u0955, handler_);
}

#line 66 "birch/distribution/Weibull.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Weibull>> birch::Weibull(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const birch::type::Real& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 66 "birch/distribution/Weibull.birch"
  libbirch_function_("Weibull", "birch/distribution/Weibull.birch", 66);
  #line 67 "birch/distribution/Weibull.birch"
  libbirch_line_(67);
  #line 67 "birch/distribution/Weibull.birch"
  return birch::Weibull(k, birch::box(_u0955, handler_), handler_);
}

#line 73 "birch/distribution/Weibull.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Weibull>> birch::Weibull(const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 73 "birch/distribution/Weibull.birch"
  libbirch_function_("Weibull", "birch/distribution/Weibull.birch", 73);
  #line 74 "birch/distribution/Weibull.birch"
  libbirch_line_(74);
  #line 74 "birch/distribution/Weibull.birch"
  return birch::Weibull(birch::box(k, handler_), _u0955, handler_);
}

#line 80 "birch/distribution/Weibull.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Weibull>> birch::Weibull(const birch::type::Real& k, const birch::type::Real& _u0955, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 80 "birch/distribution/Weibull.birch"
  libbirch_function_("Weibull", "birch/distribution/Weibull.birch", 80);
  #line 81 "birch/distribution/Weibull.birch"
  libbirch_line_(81);
  #line 81 "birch/distribution/Weibull.birch"
  return birch::Weibull(birch::box(k, handler_), birch::box(_u0955, handler_), handler_);
}

#line 4 "birch/distribution/Wishart.birch"
birch::type::Wishart::Wishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/distribution/Wishart.birch"
    super_type_(),
    #line 9 "birch/distribution/Wishart.birch"
    _u0936(_u0936),
    #line 14 "birch/distribution/Wishart.birch"
    k(k) {
  //
}

#line 16 "birch/distribution/Wishart.birch"
birch::type::Integer birch::type::Wishart::rows(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "birch/distribution/Wishart.birch"
  libbirch_function_("rows", "birch/distribution/Wishart.birch", 16);
  #line 17 "birch/distribution/Wishart.birch"
  libbirch_line_(17);
  #line 17 "birch/distribution/Wishart.birch"
  return this_()->_u0936->rows(handler_);
}

#line 20 "birch/distribution/Wishart.birch"
birch::type::Integer birch::type::Wishart::columns(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "birch/distribution/Wishart.birch"
  libbirch_function_("columns", "birch/distribution/Wishart.birch", 20);
  #line 21 "birch/distribution/Wishart.birch"
  libbirch_line_(21);
  #line 21 "birch/distribution/Wishart.birch"
  return this_()->_u0936->columns(handler_);
}

#line 24 "birch/distribution/Wishart.birch"
birch::type::Boolean birch::type::Wishart::supportsLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "birch/distribution/Wishart.birch"
  libbirch_function_("supportsLazy", "birch/distribution/Wishart.birch", 24);
  #line 25 "birch/distribution/Wishart.birch"
  libbirch_line_(25);
  #line 25 "birch/distribution/Wishart.birch"
  return true;
}

#line 28 "birch/distribution/Wishart.birch"
birch::type::LLT birch::type::Wishart::simulate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "birch/distribution/Wishart.birch"
  libbirch_function_("simulate", "birch/distribution/Wishart.birch", 28);
  #line 29 "birch/distribution/Wishart.birch"
  libbirch_line_(29);
  #line 29 "birch/distribution/Wishart.birch"
  return birch::simulate_wishart(this_()->_u0936->value(handler_), this_()->k->value(handler_), handler_);
}

#line 32 "birch/distribution/Wishart.birch"
libbirch::Optional<birch::type::LLT> birch::type::Wishart::simulateLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 32 "birch/distribution/Wishart.birch"
  libbirch_function_("simulateLazy", "birch/distribution/Wishart.birch", 32);
  #line 33 "birch/distribution/Wishart.birch"
  libbirch_line_(33);
  #line 33 "birch/distribution/Wishart.birch"
  return birch::simulate_wishart(this_()->_u0936->get(handler_), this_()->k->get(handler_), handler_);
}

#line 36 "birch/distribution/Wishart.birch"
birch::type::Real birch::type::Wishart::logpdf(const birch::type::LLT& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "birch/distribution/Wishart.birch"
  libbirch_function_("logpdf", "birch/distribution/Wishart.birch", 36);
  #line 37 "birch/distribution/Wishart.birch"
  libbirch_line_(37);
  #line 37 "birch/distribution/Wishart.birch"
  return birch::logpdf_wishart(X, this_()->_u0936->value(handler_), this_()->k->value(handler_), handler_);
}

#line 40 "birch/distribution/Wishart.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>> birch::type::Wishart::logpdfLazy(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "birch/distribution/Wishart.birch"
  libbirch_function_("logpdfLazy", "birch/distribution/Wishart.birch", 40);
  #line 41 "birch/distribution/Wishart.birch"
  libbirch_line_(41);
  #line 41 "birch/distribution/Wishart.birch"
  return birch::logpdf_lazy_wishart(X, this_()->_u0936, this_()->k, handler_);
}

#line 44 "birch/distribution/Wishart.birch"
libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Wishart>>> birch::type::Wishart::graftWishart(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "birch/distribution/Wishart.birch"
  libbirch_function_("graftWishart", "birch/distribution/Wishart.birch", 44);
  #line 45 "birch/distribution/Wishart.birch"
  libbirch_line_(45);
  #line 45 "birch/distribution/Wishart.birch"
  this_()->prune(handler_);
  #line 46 "birch/distribution/Wishart.birch"
  libbirch_line_(46);
  #line 46 "birch/distribution/Wishart.birch"
  return shared_from_this_();
}

#line 49 "birch/distribution/Wishart.birch"
void birch::type::Wishart::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 49 "birch/distribution/Wishart.birch"
  libbirch_function_("write", "birch/distribution/Wishart.birch", 49);
  #line 50 "birch/distribution/Wishart.birch"
  libbirch_line_(50);
  #line 50 "birch/distribution/Wishart.birch"
  this_()->prune(handler_);
  #line 51 "birch/distribution/Wishart.birch"
  libbirch_line_(51);
  #line 51 "birch/distribution/Wishart.birch"
  buffer->set(birch::type::String("class"), birch::type::String("Wishart"), handler_);
  #line 52 "birch/distribution/Wishart.birch"
  libbirch_line_(52);
  #line 52 "birch/distribution/Wishart.birch"
  buffer->set(birch::type::String("Ψ"), this_()->_u0936, handler_);
  #line 53 "birch/distribution/Wishart.birch"
  libbirch_line_(53);
  #line 53 "birch/distribution/Wishart.birch"
  buffer->set(birch::type::String("k"), this_()->k, handler_);
}

#line 60 "birch/distribution/Wishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Wishart>> birch::Wishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 60 "birch/distribution/Wishart.birch"
  libbirch_function_("Wishart", "birch/distribution/Wishart.birch", 60);
  #line 61 "birch/distribution/Wishart.birch"
  libbirch_line_(61);
  #line 61 "birch/distribution/Wishart.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Wishart>>>(_u0936, k, handler_);
}

#line 67 "birch/distribution/Wishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Wishart>> birch::Wishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::LLT>>>& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 67 "birch/distribution/Wishart.birch"
  libbirch_function_("Wishart", "birch/distribution/Wishart.birch", 67);
  #line 68 "birch/distribution/Wishart.birch"
  libbirch_line_(68);
  #line 68 "birch/distribution/Wishart.birch"
  return birch::Wishart(_u0936, birch::box(k, handler_), handler_);
}

#line 74 "birch/distribution/Wishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Wishart>> birch::Wishart(const birch::type::LLT& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 74 "birch/distribution/Wishart.birch"
  libbirch_function_("Wishart", "birch/distribution/Wishart.birch", 74);
  #line 75 "birch/distribution/Wishart.birch"
  libbirch_line_(75);
  #line 75 "birch/distribution/Wishart.birch"
  return birch::Wishart(birch::box(_u0936, handler_), k, handler_);
}

#line 81 "birch/distribution/Wishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Wishart>> birch::Wishart(const birch::type::LLT& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "birch/distribution/Wishart.birch"
  libbirch_function_("Wishart", "birch/distribution/Wishart.birch", 81);
  #line 82 "birch/distribution/Wishart.birch"
  libbirch_line_(82);
  #line 82 "birch/distribution/Wishart.birch"
  return birch::Wishart(birch::box(_u0936, handler_), birch::box(k, handler_), handler_);
}

#line 88 "birch/distribution/Wishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Wishart>> birch::Wishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 88 "birch/distribution/Wishart.birch"
  libbirch_function_("Wishart", "birch/distribution/Wishart.birch", 88);
  #line 89 "birch/distribution/Wishart.birch"
  libbirch_line_(89);
  #line 89 "birch/distribution/Wishart.birch"
  return birch::Wishart(birch::llt(_u0936, handler_), k, handler_);
}

#line 95 "birch/distribution/Wishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Wishart>> birch::Wishart(const libbirch::Lazy<libbirch::Shared<birch::type::Expression<libbirch::DefaultArray<birch::type::Real,2>>>>& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "birch/distribution/Wishart.birch"
  libbirch_function_("Wishart", "birch/distribution/Wishart.birch", 95);
  #line 96 "birch/distribution/Wishart.birch"
  libbirch_line_(96);
  #line 96 "birch/distribution/Wishart.birch"
  return birch::Wishart(birch::llt(_u0936, handler_), k, handler_);
}

#line 102 "birch/distribution/Wishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Wishart>> birch::Wishart(const libbirch::DefaultArray<birch::type::Real,2>& _u0936, const libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 102 "birch/distribution/Wishart.birch"
  libbirch_function_("Wishart", "birch/distribution/Wishart.birch", 102);
  #line 103 "birch/distribution/Wishart.birch"
  libbirch_line_(103);
  #line 103 "birch/distribution/Wishart.birch"
  return birch::Wishart(birch::llt(_u0936, handler_), k, handler_);
}

#line 109 "birch/distribution/Wishart.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Wishart>> birch::Wishart(const libbirch::DefaultArray<birch::type::Real,2>& _u0936, const birch::type::Real& k, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 109 "birch/distribution/Wishart.birch"
  libbirch_function_("Wishart", "birch/distribution/Wishart.birch", 109);
  #line 110 "birch/distribution/Wishart.birch"
  libbirch_line_(110);
  #line 110 "birch/distribution/Wishart.birch"
  return birch::Wishart(birch::llt(_u0936, handler_), k, handler_);
}

