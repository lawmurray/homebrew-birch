#line 5 "birch/test/basic/test_deep_clone_alias.birch"
int birch::test_deep_clone_alias(int argc_, char** argv_) {
  #line 5 "birch/test/basic/test_deep_clone_alias.birch"
  libbirch_function_("test_deep_clone_alias", "birch/test/basic/test_deep_clone_alias.birch", 5);
  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 7 "birch/test/basic/test_deep_clone_alias.birch"
  libbirch_line_(7);
  #line 7 "birch/test/basic/test_deep_clone_alias.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::List<birch::type::Integer>>> x;
  #line 8 "birch/test/basic/test_deep_clone_alias.birch"
  libbirch_line_(8);
  #line 8 "birch/test/basic/test_deep_clone_alias.birch"
  x->pushBack(birch::type::Integer(1), handler_);
  #line 9 "birch/test/basic/test_deep_clone_alias.birch"
  libbirch_line_(9);
  #line 9 "birch/test/basic/test_deep_clone_alias.birch"
  x->pushBack(birch::type::Integer(2), handler_);
  #line 12 "birch/test/basic/test_deep_clone_alias.birch"
  libbirch_line_(12);
  #line 12 "birch/test/basic/test_deep_clone_alias.birch"
  auto z = x;
  #line 15 "birch/test/basic/test_deep_clone_alias.birch"
  libbirch_line_(15);
  #line 15 "birch/test/basic/test_deep_clone_alias.birch"
  auto y = birch::clone(x, handler_);
  #line 18 "birch/test/basic/test_deep_clone_alias.birch"
  libbirch_line_(18);
  #line 18 "birch/test/basic/test_deep_clone_alias.birch"
  x->set(birch::type::Integer(1), birch::type::Integer(3), handler_);
  #line 19 "birch/test/basic/test_deep_clone_alias.birch"
  libbirch_line_(19);
  #line 19 "birch/test/basic/test_deep_clone_alias.birch"
  x->set(birch::type::Integer(2), birch::type::Integer(4), handler_);
  #line 22 "birch/test/basic/test_deep_clone_alias.birch"
  libbirch_line_(22);
  #line 22 "birch/test/basic/test_deep_clone_alias.birch"
  if (z->get(birch::type::Integer(1), handler_) != birch::type::Integer(3) || z->get(birch::type::Integer(2), handler_) != birch::type::Integer(4)) {
    #line 23 "birch/test/basic/test_deep_clone_alias.birch"
    libbirch_line_(23);
    #line 23 "birch/test/basic/test_deep_clone_alias.birch"
    birch::exit(birch::type::Integer(1), handler_);
  }
  #line 5 "birch/test/basic/test_deep_clone_alias.birch"
  libbirch_line_(5);
  #line 5 "birch/test/basic/test_deep_clone_alias.birch"
  return 0;
}

#line 4 "birch/test/basic/test_deep_clone_chain.birch"
int birch::test_deep_clone_chain(int argc_, char** argv_) {
  #line 4 "birch/test/basic/test_deep_clone_chain.birch"
  libbirch_function_("test_deep_clone_chain", "birch/test/basic/test_deep_clone_chain.birch", 4);
  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "birch/test/basic/test_deep_clone_chain.birch"
  libbirch_line_(5);
  #line 5 "birch/test/basic/test_deep_clone_chain.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::DeepCloneNode>> x;
  #line 6 "birch/test/basic/test_deep_clone_chain.birch"
  libbirch_line_(6);
  #line 6 "birch/test/basic/test_deep_clone_chain.birch"
  x->a = birch::type::Integer(1);
  #line 9 "birch/test/basic/test_deep_clone_chain.birch"
  libbirch_line_(9);
  #line 9 "birch/test/basic/test_deep_clone_chain.birch"
  auto y = birch::clone(x, handler_);
  #line 10 "birch/test/basic/test_deep_clone_chain.birch"
  libbirch_line_(10);
  #line 10 "birch/test/basic/test_deep_clone_chain.birch"
  y->a = birch::type::Integer(2);
  #line 13 "birch/test/basic/test_deep_clone_chain.birch"
  libbirch_line_(13);
  #line 13 "birch/test/basic/test_deep_clone_chain.birch"
  auto z = birch::clone(y, handler_);
  #line 16 "birch/test/basic/test_deep_clone_chain.birch"
  libbirch_line_(16);
  #line 16 "birch/test/basic/test_deep_clone_chain.birch"
  x = z;
  #line 17 "birch/test/basic/test_deep_clone_chain.birch"
  libbirch_line_(17);
  #line 17 "birch/test/basic/test_deep_clone_chain.birch"
  y = z;
  #line 20 "birch/test/basic/test_deep_clone_chain.birch"
  libbirch_line_(20);
  #line 20 "birch/test/basic/test_deep_clone_chain.birch"
  if (z->a != birch::type::Integer(2)) {
    #line 21 "birch/test/basic/test_deep_clone_chain.birch"
    libbirch_line_(21);
    #line 21 "birch/test/basic/test_deep_clone_chain.birch"
    birch::exit(birch::type::Integer(1), handler_);
  }
  #line 4 "birch/test/basic/test_deep_clone_chain.birch"
  libbirch_line_(4);
  #line 4 "birch/test/basic/test_deep_clone_chain.birch"
  return 0;
}

#line 23 "birch/test/basic/test_deep_clone_chain.birch"
birch::type::DeepCloneNode::DeepCloneNode(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 23 "birch/test/basic/test_deep_clone_chain.birch"
    super_type_(),
    #line 26 "birch/test/basic/test_deep_clone_chain.birch"
    a() {
  //
}

#line 23 "birch/test/basic/test_deep_clone_chain.birch"
birch::type::DeepCloneNode* birch::type::make_DeepCloneNode_() {
  #line 23 "birch/test/basic/test_deep_clone_chain.birch"
  return new birch::type::DeepCloneNode();
  #line 23 "birch/test/basic/test_deep_clone_chain.birch"
}

#line 5 "birch/test/basic/test_deep_clone_modify_dst.birch"
int birch::test_deep_clone_modify_dst(int argc_, char** argv_) {
  #line 5 "birch/test/basic/test_deep_clone_modify_dst.birch"
  libbirch_function_("test_deep_clone_modify_dst", "birch/test/basic/test_deep_clone_modify_dst.birch", 5);
  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 7 "birch/test/basic/test_deep_clone_modify_dst.birch"
  libbirch_line_(7);
  #line 7 "birch/test/basic/test_deep_clone_modify_dst.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::List<birch::type::Integer>>> x;
  #line 8 "birch/test/basic/test_deep_clone_modify_dst.birch"
  libbirch_line_(8);
  #line 8 "birch/test/basic/test_deep_clone_modify_dst.birch"
  x->pushBack(birch::type::Integer(1), handler_);
  #line 9 "birch/test/basic/test_deep_clone_modify_dst.birch"
  libbirch_line_(9);
  #line 9 "birch/test/basic/test_deep_clone_modify_dst.birch"
  x->pushBack(birch::type::Integer(2), handler_);
  #line 12 "birch/test/basic/test_deep_clone_modify_dst.birch"
  libbirch_line_(12);
  #line 12 "birch/test/basic/test_deep_clone_modify_dst.birch"
  auto y = birch::clone(x, handler_);
  #line 15 "birch/test/basic/test_deep_clone_modify_dst.birch"
  libbirch_line_(15);
  #line 15 "birch/test/basic/test_deep_clone_modify_dst.birch"
  y->set(birch::type::Integer(1), birch::type::Integer(3), handler_);
  #line 16 "birch/test/basic/test_deep_clone_modify_dst.birch"
  libbirch_line_(16);
  #line 16 "birch/test/basic/test_deep_clone_modify_dst.birch"
  y->set(birch::type::Integer(2), birch::type::Integer(4), handler_);
  #line 19 "birch/test/basic/test_deep_clone_modify_dst.birch"
  libbirch_line_(19);
  #line 19 "birch/test/basic/test_deep_clone_modify_dst.birch"
  if (x->get(birch::type::Integer(1), handler_) != birch::type::Integer(1) || x->get(birch::type::Integer(2), handler_) != birch::type::Integer(2)) {
    #line 20 "birch/test/basic/test_deep_clone_modify_dst.birch"
    libbirch_line_(20);
    #line 20 "birch/test/basic/test_deep_clone_modify_dst.birch"
    birch::exit(birch::type::Integer(1), handler_);
  }
  #line 5 "birch/test/basic/test_deep_clone_modify_dst.birch"
  libbirch_line_(5);
  #line 5 "birch/test/basic/test_deep_clone_modify_dst.birch"
  return 0;
}

#line 5 "birch/test/basic/test_deep_clone_modify_src.birch"
int birch::test_deep_clone_modify_src(int argc_, char** argv_) {
  #line 5 "birch/test/basic/test_deep_clone_modify_src.birch"
  libbirch_function_("test_deep_clone_modify_src", "birch/test/basic/test_deep_clone_modify_src.birch", 5);
  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 7 "birch/test/basic/test_deep_clone_modify_src.birch"
  libbirch_line_(7);
  #line 7 "birch/test/basic/test_deep_clone_modify_src.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::List<birch::type::Integer>>> x;
  #line 8 "birch/test/basic/test_deep_clone_modify_src.birch"
  libbirch_line_(8);
  #line 8 "birch/test/basic/test_deep_clone_modify_src.birch"
  x->pushBack(birch::type::Integer(1), handler_);
  #line 9 "birch/test/basic/test_deep_clone_modify_src.birch"
  libbirch_line_(9);
  #line 9 "birch/test/basic/test_deep_clone_modify_src.birch"
  x->pushBack(birch::type::Integer(2), handler_);
  #line 12 "birch/test/basic/test_deep_clone_modify_src.birch"
  libbirch_line_(12);
  #line 12 "birch/test/basic/test_deep_clone_modify_src.birch"
  auto y = birch::clone(x, handler_);
  #line 15 "birch/test/basic/test_deep_clone_modify_src.birch"
  libbirch_line_(15);
  #line 15 "birch/test/basic/test_deep_clone_modify_src.birch"
  x->set(birch::type::Integer(1), birch::type::Integer(3), handler_);
  #line 16 "birch/test/basic/test_deep_clone_modify_src.birch"
  libbirch_line_(16);
  #line 16 "birch/test/basic/test_deep_clone_modify_src.birch"
  x->set(birch::type::Integer(2), birch::type::Integer(4), handler_);
  #line 19 "birch/test/basic/test_deep_clone_modify_src.birch"
  libbirch_line_(19);
  #line 19 "birch/test/basic/test_deep_clone_modify_src.birch"
  if (y->get(birch::type::Integer(1), handler_) != birch::type::Integer(1) || y->get(birch::type::Integer(2), handler_) != birch::type::Integer(2)) {
    #line 20 "birch/test/basic/test_deep_clone_modify_src.birch"
    libbirch_line_(20);
    #line 20 "birch/test/basic/test_deep_clone_modify_src.birch"
    birch::exit(birch::type::Integer(1), handler_);
  }
  #line 5 "birch/test/basic/test_deep_clone_modify_src.birch"
  libbirch_line_(5);
  #line 5 "birch/test/basic/test_deep_clone_modify_src.birch"
  return 0;
}

#line 4 "birch/test/basic/test_ragged_array.birch"
int birch::test_ragged_array(int argc_, char** argv_) {
  #line 4 "birch/test/basic/test_ragged_array.birch"
  libbirch_function_("test_ragged_array", "birch/test/basic/test_ragged_array.birch", 4);
  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "birch/test/basic/test_ragged_array.birch"
  libbirch_line_(5);
  #line 5 "birch/test/basic/test_ragged_array.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::RaggedArray<birch::type::Integer>>> o;
  #line 7 "birch/test/basic/test_ragged_array.birch"
  libbirch_line_(7);
  #line 7 "birch/test/basic/test_ragged_array.birch"
  o->pushBack(handler_);
  #line 8 "birch/test/basic/test_ragged_array.birch"
  libbirch_line_(8);
  #line 8 "birch/test/basic/test_ragged_array.birch"
  o->pushBack(birch::type::Integer(1), birch::type::Integer(1), handler_);
  #line 9 "birch/test/basic/test_ragged_array.birch"
  libbirch_line_(9);
  #line 9 "birch/test/basic/test_ragged_array.birch"
  o->pushBack(birch::type::Integer(1), birch::type::Integer(2), handler_);
  #line 10 "birch/test/basic/test_ragged_array.birch"
  libbirch_line_(10);
  #line 10 "birch/test/basic/test_ragged_array.birch"
  o->pushBack(birch::type::Integer(1), birch::type::Integer(3), handler_);
  #line 11 "birch/test/basic/test_ragged_array.birch"
  libbirch_line_(11);
  #line 11 "birch/test/basic/test_ragged_array.birch"
  o->pushBack(handler_);
  #line 12 "birch/test/basic/test_ragged_array.birch"
  libbirch_line_(12);
  #line 12 "birch/test/basic/test_ragged_array.birch"
  o->pushBack(birch::type::Integer(2), birch::type::Integer(4), handler_);
  #line 13 "birch/test/basic/test_ragged_array.birch"
  libbirch_line_(13);
  #line 13 "birch/test/basic/test_ragged_array.birch"
  o->pushBack(handler_);
  #line 14 "birch/test/basic/test_ragged_array.birch"
  libbirch_line_(14);
  #line 14 "birch/test/basic/test_ragged_array.birch"
  o->pushBack(birch::type::Integer(3), birch::type::Integer(5), handler_);
  #line 15 "birch/test/basic/test_ragged_array.birch"
  libbirch_line_(15);
  #line 15 "birch/test/basic/test_ragged_array.birch"
  if (!birch::check_ragged_array(o, libbirch::make_array({ birch::type::Integer(3), birch::type::Integer(1), birch::type::Integer(1) }), libbirch::make_array({ birch::type::Integer(1), birch::type::Integer(2), birch::type::Integer(3), birch::type::Integer(4), birch::type::Integer(5) }), handler_)) {
    #line 16 "birch/test/basic/test_ragged_array.birch"
    libbirch_line_(16);
    #line 16 "birch/test/basic/test_ragged_array.birch"
    birch::exit(birch::type::Integer(1), handler_);
  }
  #line 19 "birch/test/basic/test_ragged_array.birch"
  libbirch_line_(19);
  #line 19 "birch/test/basic/test_ragged_array.birch"
  o->pushBack(birch::type::Integer(2), birch::type::Integer(6), handler_);
  #line 20 "birch/test/basic/test_ragged_array.birch"
  libbirch_line_(20);
  #line 20 "birch/test/basic/test_ragged_array.birch"
  if (!birch::check_ragged_array(o, libbirch::make_array({ birch::type::Integer(3), birch::type::Integer(2), birch::type::Integer(1) }), libbirch::make_array({ birch::type::Integer(1), birch::type::Integer(2), birch::type::Integer(3), birch::type::Integer(4), birch::type::Integer(6), birch::type::Integer(5) }), handler_)) {
    #line 21 "birch/test/basic/test_ragged_array.birch"
    libbirch_line_(21);
    #line 21 "birch/test/basic/test_ragged_array.birch"
    birch::exit(birch::type::Integer(1), handler_);
  }
  #line 4 "birch/test/basic/test_ragged_array.birch"
  libbirch_line_(4);
  #line 4 "birch/test/basic/test_ragged_array.birch"
  return 0;
}

#line 25 "birch/test/basic/test_ragged_array.birch"
birch::type::Boolean birch::check_ragged_array(const libbirch::Lazy<libbirch::Shared<birch::type::RaggedArray<birch::type::Integer>>>& o, const libbirch::DefaultArray<birch::type::Integer,1>& sizes, const libbirch::DefaultArray<birch::type::Integer,1>& values, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "birch/test/basic/test_ragged_array.birch"
  libbirch_function_("check_ragged_array", "birch/test/basic/test_ragged_array.birch", 25);
  #line 27 "birch/test/basic/test_ragged_array.birch"
  libbirch_line_(27);
  #line 27 "birch/test/basic/test_ragged_array.birch"
  auto result = true;
  #line 30 "birch/test/basic/test_ragged_array.birch"
  libbirch_line_(30);
  #line 30 "birch/test/basic/test_ragged_array.birch"
  if (o->size(handler_) != birch::length(sizes, handler_)) {
    #line 31 "birch/test/basic/test_ragged_array.birch"
    libbirch_line_(31);
    #line 31 "birch/test/basic/test_ragged_array.birch"
    birch::stderr()->print(birch::type::String("incorrect total size\n"), handler_);
    #line 32 "birch/test/basic/test_ragged_array.birch"
    libbirch_line_(32);
    #line 32 "birch/test/basic/test_ragged_array.birch"
    result = false;
  }
  #line 36 "birch/test/basic/test_ragged_array.birch"
  libbirch_line_(36);
  #line 36 "birch/test/basic/test_ragged_array.birch"
  for (auto i = birch::type::Integer(1); i <= birch::length(sizes, handler_); ++i) {
    #line 37 "birch/test/basic/test_ragged_array.birch"
    libbirch_line_(37);
    #line 37 "birch/test/basic/test_ragged_array.birch"
    if (o->size(i, handler_) != sizes.get(libbirch::make_slice(i - 1))) {
      #line 38 "birch/test/basic/test_ragged_array.birch"
      libbirch_line_(38);
      #line 38 "birch/test/basic/test_ragged_array.birch"
      birch::stderr()->print(birch::type::String("incorrect row size\n"), handler_);
      #line 39 "birch/test/basic/test_ragged_array.birch"
      libbirch_line_(39);
      #line 39 "birch/test/basic/test_ragged_array.birch"
      result = false;
    }
  }
  #line 44 "birch/test/basic/test_ragged_array.birch"
  libbirch_line_(44);
  #line 44 "birch/test/basic/test_ragged_array.birch"
  auto k = birch::type::Integer(1);
  #line 45 "birch/test/basic/test_ragged_array.birch"
  libbirch_line_(45);
  #line 45 "birch/test/basic/test_ragged_array.birch"
  for (auto i = birch::type::Integer(1); i <= o->size(handler_); ++i) {
    #line 46 "birch/test/basic/test_ragged_array.birch"
    libbirch_line_(46);
    #line 46 "birch/test/basic/test_ragged_array.birch"
    for (auto j = birch::type::Integer(1); j <= o->size(i, handler_); ++j) {
      #line 47 "birch/test/basic/test_ragged_array.birch"
      libbirch_line_(47);
      #line 47 "birch/test/basic/test_ragged_array.birch"
      if (o->get(i, j, handler_) != values.get(libbirch::make_slice(k - 1))) {
        #line 48 "birch/test/basic/test_ragged_array.birch"
        libbirch_line_(48);
        #line 48 "birch/test/basic/test_ragged_array.birch"
        birch::stderr()->print(birch::type::String("incorrect value\n"), handler_);
        #line 49 "birch/test/basic/test_ragged_array.birch"
        libbirch_line_(49);
        #line 49 "birch/test/basic/test_ragged_array.birch"
        result = false;
      }
      #line 51 "birch/test/basic/test_ragged_array.birch"
      libbirch_line_(51);
      #line 51 "birch/test/basic/test_ragged_array.birch"
      k = k + birch::type::Integer(1);
    }
  }
  #line 55 "birch/test/basic/test_ragged_array.birch"
  libbirch_line_(55);
  #line 55 "birch/test/basic/test_ragged_array.birch"
  return result;
}

#line 4 "birch/test/basic/test_array.birch"
int birch::test_array(int argc_, char** argv_) {
  #line 4 "birch/test/basic/test_array.birch"
  libbirch_function_("test_array", "birch/test/basic/test_array.birch", 4);
  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 5 "birch/test/basic/test_array.birch"
  libbirch_line_(5);
  #line 5 "birch/test/basic/test_array.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Array<birch::type::Integer>>> o;
  #line 7 "birch/test/basic/test_array.birch"
  libbirch_line_(7);
  #line 7 "birch/test/basic/test_array.birch"
  o->pushBack(birch::type::Integer(1), handler_);
  #line 8 "birch/test/basic/test_array.birch"
  libbirch_line_(8);
  #line 8 "birch/test/basic/test_array.birch"
  o->pushBack(birch::type::Integer(2), handler_);
  #line 9 "birch/test/basic/test_array.birch"
  libbirch_line_(9);
  #line 9 "birch/test/basic/test_array.birch"
  o->pushBack(birch::type::Integer(4), handler_);
  #line 10 "birch/test/basic/test_array.birch"
  libbirch_line_(10);
  #line 10 "birch/test/basic/test_array.birch"
  o->pushBack(birch::type::Integer(5), handler_);
  #line 11 "birch/test/basic/test_array.birch"
  libbirch_line_(11);
  #line 11 "birch/test/basic/test_array.birch"
  if (!birch::check_array(o, libbirch::make_array({ birch::type::Integer(1), birch::type::Integer(2), birch::type::Integer(4), birch::type::Integer(5) }), handler_)) {
    #line 12 "birch/test/basic/test_array.birch"
    libbirch_line_(12);
    #line 12 "birch/test/basic/test_array.birch"
    birch::exit(birch::type::Integer(1), handler_);
  }
  #line 15 "birch/test/basic/test_array.birch"
  libbirch_line_(15);
  #line 15 "birch/test/basic/test_array.birch"
  o->insert(birch::type::Integer(3), birch::type::Integer(3), handler_);
  #line 16 "birch/test/basic/test_array.birch"
  libbirch_line_(16);
  #line 16 "birch/test/basic/test_array.birch"
  if (!birch::check_array(o, libbirch::make_array({ birch::type::Integer(1), birch::type::Integer(2), birch::type::Integer(3), birch::type::Integer(4), birch::type::Integer(5) }), handler_)) {
    #line 17 "birch/test/basic/test_array.birch"
    libbirch_line_(17);
    #line 17 "birch/test/basic/test_array.birch"
    birch::exit(birch::type::Integer(1), handler_);
  }
  #line 20 "birch/test/basic/test_array.birch"
  libbirch_line_(20);
  #line 20 "birch/test/basic/test_array.birch"
  o->erase(birch::type::Integer(4), handler_);
  #line 21 "birch/test/basic/test_array.birch"
  libbirch_line_(21);
  #line 21 "birch/test/basic/test_array.birch"
  if (!birch::check_array(o, libbirch::make_array({ birch::type::Integer(1), birch::type::Integer(2), birch::type::Integer(3), birch::type::Integer(5) }), handler_)) {
    #line 22 "birch/test/basic/test_array.birch"
    libbirch_line_(22);
    #line 22 "birch/test/basic/test_array.birch"
    birch::exit(birch::type::Integer(1), handler_);
  }
  #line 25 "birch/test/basic/test_array.birch"
  libbirch_line_(25);
  #line 25 "birch/test/basic/test_array.birch"
  if (o->front(handler_) != birch::type::Integer(1)) {
    #line 26 "birch/test/basic/test_array.birch"
    libbirch_line_(26);
    #line 26 "birch/test/basic/test_array.birch"
    birch::exit(birch::type::Integer(1), handler_);
  }
  #line 29 "birch/test/basic/test_array.birch"
  libbirch_line_(29);
  #line 29 "birch/test/basic/test_array.birch"
  if (o->back(handler_) != birch::type::Integer(5)) {
    #line 30 "birch/test/basic/test_array.birch"
    libbirch_line_(30);
    #line 30 "birch/test/basic/test_array.birch"
    birch::exit(birch::type::Integer(1), handler_);
  }
  #line 4 "birch/test/basic/test_array.birch"
  libbirch_line_(4);
  #line 4 "birch/test/basic/test_array.birch"
  return 0;
}

#line 34 "birch/test/basic/test_array.birch"
birch::type::Boolean birch::check_array(const libbirch::Lazy<libbirch::Shared<birch::type::Array<birch::type::Integer>>>& o, const libbirch::DefaultArray<birch::type::Integer,1>& values, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "birch/test/basic/test_array.birch"
  libbirch_function_("check_array", "birch/test/basic/test_array.birch", 34);
  #line 35 "birch/test/basic/test_array.birch"
  libbirch_line_(35);
  #line 35 "birch/test/basic/test_array.birch"
  auto result = true;
  #line 38 "birch/test/basic/test_array.birch"
  libbirch_line_(38);
  #line 38 "birch/test/basic/test_array.birch"
  if (o->size(handler_) != birch::length(values, handler_)) {
    #line 39 "birch/test/basic/test_array.birch"
    libbirch_line_(39);
    #line 39 "birch/test/basic/test_array.birch"
    birch::stderr()->print(birch::type::String("incorrect total size\n"), handler_);
    #line 40 "birch/test/basic/test_array.birch"
    libbirch_line_(40);
    #line 40 "birch/test/basic/test_array.birch"
    result = false;
  }
  #line 44 "birch/test/basic/test_array.birch"
  libbirch_line_(44);
  #line 44 "birch/test/basic/test_array.birch"
  for (auto i = birch::type::Integer(1); i <= o->size(handler_); ++i) {
    #line 45 "birch/test/basic/test_array.birch"
    libbirch_line_(45);
    #line 45 "birch/test/basic/test_array.birch"
    if (o->get(i, handler_) != values.get(libbirch::make_slice(i - 1))) {
      #line 46 "birch/test/basic/test_array.birch"
      libbirch_line_(46);
      #line 46 "birch/test/basic/test_array.birch"
      birch::stderr()->print(birch::type::String("incorrect value\n"), handler_);
      #line 47 "birch/test/basic/test_array.birch"
      libbirch_line_(47);
      #line 47 "birch/test/basic/test_array.birch"
      result = false;
    }
  }
  #line 51 "birch/test/basic/test_array.birch"
  libbirch_line_(51);
  #line 51 "birch/test/basic/test_array.birch"
  return result;
}

