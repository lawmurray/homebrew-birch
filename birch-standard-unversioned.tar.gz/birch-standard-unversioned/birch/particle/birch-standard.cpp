#line 1 "birch/particle/ConditionalParticle.birch"
birch::type::ConditionalParticle::ConditionalParticle(const libbirch::Lazy<libbirch::Shared<birch::type::Model>>& m, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/particle/ConditionalParticle.birch"
    super_type_(m),
    #line 20 "birch/particle/ConditionalParticle.birch"
    trace() {
  //
}

#line 26 "birch/particle/ConditionalParticle.birch"
libbirch::Lazy<libbirch::Shared<birch::type::ConditionalParticle>> birch::ConditionalParticle(const libbirch::Lazy<libbirch::Shared<birch::type::Model>>& m, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "birch/particle/ConditionalParticle.birch"
  libbirch_function_("ConditionalParticle", "birch/particle/ConditionalParticle.birch", 26);
  #line 27 "birch/particle/ConditionalParticle.birch"
  libbirch_line_(27);
  #line 27 "birch/particle/ConditionalParticle.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::ConditionalParticle>>>(m, handler_);
}

#line 1 "birch/particle/MoveParticle.birch"
birch::type::MoveParticle::MoveParticle(const libbirch::Lazy<libbirch::Shared<birch::type::Model>>& m, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/particle/MoveParticle.birch"
    super_type_(m),
    #line 20 "birch/particle/MoveParticle.birch"
    zs(),
    #line 26 "birch/particle/MoveParticle.birch"
    ps(),
    #line 31 "birch/particle/MoveParticle.birch"
    _u0960(0.0) {
  //
}

#line 36 "birch/particle/MoveParticle.birch"
birch::type::Integer birch::type::MoveParticle::size(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "birch/particle/MoveParticle.birch"
  libbirch_function_("size", "birch/particle/MoveParticle.birch", 36);
  #line 37 "birch/particle/MoveParticle.birch"
  libbirch_line_(37);
  #line 37 "birch/particle/MoveParticle.birch"
  return this_()->zs->size(handler_);
}

#line 48 "birch/particle/MoveParticle.birch"
birch::type::Real birch::type::MoveParticle::augment(const birch::type::Integer& t, const libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Expression<birch::type::Real>>>>& z, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "birch/particle/MoveParticle.birch"
  libbirch_function_("augment", "birch/particle/MoveParticle.birch", 48);
  #line 50 "birch/particle/MoveParticle.birch"
  libbirch_line_(50);
  #line 50 "birch/particle/MoveParticle.birch"
  auto z_prime_ = z;
  #line 51 "birch/particle/MoveParticle.birch"
  libbirch_line_(51);
  #line 51 "birch/particle/MoveParticle.birch"
  if (!z_prime_.query()) {
    #line 52 "birch/particle/MoveParticle.birch"
    libbirch_line_(52);
    #line 52 "birch/particle/MoveParticle.birch"
    z_prime_ = birch::box(0.0, handler_);
  }
  #line 54 "birch/particle/MoveParticle.birch"
  libbirch_line_(54);
  #line 54 "birch/particle/MoveParticle.birch"
  auto w = z_prime_.get()->pilot(t, handler_);
  #line 55 "birch/particle/MoveParticle.birch"
  libbirch_line_(55);
  #line 55 "birch/particle/MoveParticle.birch"
  this_()->_u0960 = this_()->_u0960 + w;
  #line 56 "birch/particle/MoveParticle.birch"
  libbirch_line_(56);
  #line 56 "birch/particle/MoveParticle.birch"
  this_()->zs->pushBack(z_prime_.get(), handler_);
  #line 59 "birch/particle/MoveParticle.birch"
  libbirch_line_(59);
  #line 59 "birch/particle/MoveParticle.birch"
  auto p = z_prime_.get()->prior(handler_);
  #line 60 "birch/particle/MoveParticle.birch"
  libbirch_line_(60);
  #line 60 "birch/particle/MoveParticle.birch"
  if (!p.query()) {
    #line 61 "birch/particle/MoveParticle.birch"
    libbirch_line_(61);
    #line 61 "birch/particle/MoveParticle.birch"
    p = birch::box(0.0, handler_);
  }
  #line 63 "birch/particle/MoveParticle.birch"
  libbirch_line_(63);
  #line 63 "birch/particle/MoveParticle.birch"
  this_()->_u0960 = this_()->_u0960 + p.get()->pilot(t, handler_);
  #line 64 "birch/particle/MoveParticle.birch"
  libbirch_line_(64);
  #line 64 "birch/particle/MoveParticle.birch"
  this_()->ps->pushBack(p.get(), handler_);
  #line 66 "birch/particle/MoveParticle.birch"
  libbirch_line_(66);
  #line 66 "birch/particle/MoveParticle.birch"
  return w;
}

#line 72 "birch/particle/MoveParticle.birch"
void birch::type::MoveParticle::truncate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "birch/particle/MoveParticle.birch"
  libbirch_function_("truncate", "birch/particle/MoveParticle.birch", 72);
  #line 76 "birch/particle/MoveParticle.birch"
  libbirch_line_(76);
  #line 76 "birch/particle/MoveParticle.birch"
  if (!this_()->zs->empty(handler_)) {
    #line 77 "birch/particle/MoveParticle.birch"
    libbirch_line_(77);
    #line 77 "birch/particle/MoveParticle.birch"
    this_()->_u0960 = this_()->_u0960 - this_()->zs->front(handler_)->get(handler_);
    #line 78 "birch/particle/MoveParticle.birch"
    libbirch_line_(78);
    #line 78 "birch/particle/MoveParticle.birch"
    this_()->zs->popFront(handler_);
  }
  #line 80 "birch/particle/MoveParticle.birch"
  libbirch_line_(80);
  #line 80 "birch/particle/MoveParticle.birch"
  if (!this_()->ps->empty(handler_)) {
    #line 81 "birch/particle/MoveParticle.birch"
    libbirch_line_(81);
    #line 81 "birch/particle/MoveParticle.birch"
    this_()->_u0960 = this_()->_u0960 - this_()->ps->front(handler_)->get(handler_);
    #line 82 "birch/particle/MoveParticle.birch"
    libbirch_line_(82);
    #line 82 "birch/particle/MoveParticle.birch"
    this_()->ps->popFront(handler_);
  }
}

#line 89 "birch/particle/MoveParticle.birch"
void birch::type::MoveParticle::grad(const birch::type::Integer& gen, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 89 "birch/particle/MoveParticle.birch"
  libbirch_function_("grad", "birch/particle/MoveParticle.birch", 89);
  #line 90 "birch/particle/MoveParticle.birch"
  libbirch_line_(90);
  #line 90 "birch/particle/MoveParticle.birch"
  auto L = this_()->size(handler_);
  #line 91 "birch/particle/MoveParticle.birch"
  libbirch_line_(91);
  #line 91 "birch/particle/MoveParticle.birch"
  for (auto l = birch::type::Integer(1); l <= L; ++l) {
    #line 92 "birch/particle/MoveParticle.birch"
    libbirch_line_(92);
    #line 92 "birch/particle/MoveParticle.birch"
    this_()->zs->get(l, handler_)->grad(gen, 1.0, handler_);
    #line 93 "birch/particle/MoveParticle.birch"
    libbirch_line_(93);
    #line 93 "birch/particle/MoveParticle.birch"
    this_()->ps->get(l, handler_)->grad(gen, 1.0, handler_);
  }
}

#line 103 "birch/particle/MoveParticle.birch"
void birch::type::MoveParticle::move(const birch::type::Integer& gen, const libbirch::Lazy<libbirch::Shared<birch::type::Kernel>>& _u0954, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 103 "birch/particle/MoveParticle.birch"
  libbirch_function_("move", "birch/particle/MoveParticle.birch", 103);
  #line 104 "birch/particle/MoveParticle.birch"
  libbirch_line_(104);
  #line 104 "birch/particle/MoveParticle.birch"
  auto L = this_()->size(handler_);
  #line 105 "birch/particle/MoveParticle.birch"
  libbirch_line_(105);
  #line 105 "birch/particle/MoveParticle.birch"
  auto _u0960 = 0.0;
  #line 106 "birch/particle/MoveParticle.birch"
  libbirch_line_(106);
  #line 106 "birch/particle/MoveParticle.birch"
  for (auto l = birch::type::Integer(1); l <= L; ++l) {
    #line 107 "birch/particle/MoveParticle.birch"
    libbirch_line_(107);
    #line 107 "birch/particle/MoveParticle.birch"
    _u0960 = _u0960 + this_()->zs->get(l, handler_)->move(gen, _u0954, handler_);
    #line 108 "birch/particle/MoveParticle.birch"
    libbirch_line_(108);
    #line 108 "birch/particle/MoveParticle.birch"
    _u0960 = _u0960 + this_()->ps->get(l, handler_)->move(gen, _u0954, handler_);
  }
  #line 110 "birch/particle/MoveParticle.birch"
  libbirch_line_(110);
  #line 110 "birch/particle/MoveParticle.birch"
  this_()->_u0960 = _u0960;
}

#line 122 "birch/particle/MoveParticle.birch"
birch::type::Real birch::type::MoveParticle::compare(const birch::type::Integer& gen, const libbirch::Lazy<libbirch::Shared<birch::type::MoveParticle>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Kernel>>& _u0954, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 122 "birch/particle/MoveParticle.birch"
  libbirch_function_("compare", "birch/particle/MoveParticle.birch", 122);
  #line 123 "birch/particle/MoveParticle.birch"
  libbirch_line_(123);
  #line 123 "birch/particle/MoveParticle.birch"
  libbirch_assert_(this_()->size(handler_) == x->size(handler_));
  #line 124 "birch/particle/MoveParticle.birch"
  libbirch_line_(124);
  #line 124 "birch/particle/MoveParticle.birch"
  auto L = this_()->size(handler_);
  #line 125 "birch/particle/MoveParticle.birch"
  libbirch_line_(125);
  #line 125 "birch/particle/MoveParticle.birch"
  auto w = 0.0;
  #line 126 "birch/particle/MoveParticle.birch"
  libbirch_line_(126);
  #line 126 "birch/particle/MoveParticle.birch"
  for (auto l = birch::type::Integer(1); l <= L; ++l) {
    #line 127 "birch/particle/MoveParticle.birch"
    libbirch_line_(127);
    #line 127 "birch/particle/MoveParticle.birch"
    w = w + this_()->zs->get(l, handler_)->compare(gen, x->zs->get(l, handler_), _u0954, handler_);
    #line 128 "birch/particle/MoveParticle.birch"
    libbirch_line_(128);
    #line 128 "birch/particle/MoveParticle.birch"
    w = w + this_()->ps->get(l, handler_)->compare(gen, x->ps->get(l, handler_), _u0954, handler_);
  }
  #line 130 "birch/particle/MoveParticle.birch"
  libbirch_line_(130);
  #line 130 "birch/particle/MoveParticle.birch"
  return w;
}

#line 137 "birch/particle/MoveParticle.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MoveParticle>> birch::MoveParticle(const libbirch::Lazy<libbirch::Shared<birch::type::Model>>& m, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 137 "birch/particle/MoveParticle.birch"
  libbirch_function_("MoveParticle", "birch/particle/MoveParticle.birch", 137);
  #line 138 "birch/particle/MoveParticle.birch"
  libbirch_line_(138);
  #line 138 "birch/particle/MoveParticle.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MoveParticle>>>(m, handler_);
}

#line 1 "birch/particle/Particle.birch"
birch::type::Particle::Particle(const libbirch::Lazy<libbirch::Shared<birch::type::Model>>& m, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/particle/Particle.birch"
    super_type_(),
    #line 19 "birch/particle/Particle.birch"
    m(m) {
  //
}

#line 21 "birch/particle/Particle.birch"
void birch::type::Particle::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "birch/particle/Particle.birch"
  libbirch_function_("write", "birch/particle/Particle.birch", 21);
  #line 22 "birch/particle/Particle.birch"
  libbirch_line_(22);
  #line 22 "birch/particle/Particle.birch"
  buffer->set(this_()->m, handler_);
}

#line 29 "birch/particle/Particle.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Particle>> birch::Particle(const libbirch::Lazy<libbirch::Shared<birch::type::Model>>& m, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 29 "birch/particle/Particle.birch"
  libbirch_function_("Particle", "birch/particle/Particle.birch", 29);
  #line 30 "birch/particle/Particle.birch"
  libbirch_line_(30);
  #line 30 "birch/particle/Particle.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::Particle>>>(m, handler_);
}

