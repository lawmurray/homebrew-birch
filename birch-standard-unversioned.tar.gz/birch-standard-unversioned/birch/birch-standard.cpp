#line 20 "birch/filter.birch"
int birch::filter(int argc_, char** argv_) {
  #line 20 "birch/filter.birch"
  libbirch_function_("filter", "birch/filter.birch", 20);
  #line 20 "birch/filter.birch"
  libbirch::Optional<birch::type::String> input;
  #line 20 "birch/filter.birch"
  libbirch::Optional<birch::type::String> output;
  #line 20 "birch/filter.birch"
  libbirch::Optional<birch::type::String> config;
  #line 20 "birch/filter.birch"
  libbirch::Optional<birch::type::String> model;
  #line 20 "birch/filter.birch"
  libbirch::Optional<birch::type::Integer> seed;
  #line 20 "birch/filter.birch"
  birch::type::Boolean quiet = false;
  
  enum {
    inputFLAG_,
    outputFLAG_,
    configFLAG_,
    modelFLAG_,
    seedFLAG_,
    quietFLAG_,
  };
  #line 20 "birch/filter.birch"
  int c_, option_index_;
  #line 20 "birch/filter.birch"
  option long_options_[] = {
    #line 20 "birch/filter.birch"
    {"input", required_argument, 0, inputFLAG_ },
    #line 20 "birch/filter.birch"
    {"output", required_argument, 0, outputFLAG_ },
    #line 20 "birch/filter.birch"
    {"config", required_argument, 0, configFLAG_ },
    #line 20 "birch/filter.birch"
    {"model", required_argument, 0, modelFLAG_ },
    #line 20 "birch/filter.birch"
    {"seed", required_argument, 0, seedFLAG_ },
    #line 20 "birch/filter.birch"
    {"quiet", required_argument, 0, quietFLAG_ },
    #line 20 "birch/filter.birch"
    {0, 0, 0, 0}
  #line 20 "birch/filter.birch"
  };
  #line 20 "birch/filter.birch"
  const char* short_options_ = ":";
  #line 20 "birch/filter.birch"
  ::opterr = 0;
  #line 20 "birch/filter.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 20 "birch/filter.birch"
  while (c_ != -1) {
    #line 20 "birch/filter.birch"
    switch (c_) {
      #line 21 "birch/filter.birch"
      case inputFLAG_:
        #line 21 "birch/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 21 "birch/filter.birch"
        input = birch::String(std::string(::optarg));
        break;
      #line 22 "birch/filter.birch"
      case outputFLAG_:
        #line 22 "birch/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 22 "birch/filter.birch"
        output = birch::String(std::string(::optarg));
        break;
      #line 23 "birch/filter.birch"
      case configFLAG_:
        #line 23 "birch/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 23 "birch/filter.birch"
        config = birch::String(std::string(::optarg));
        break;
      #line 24 "birch/filter.birch"
      case modelFLAG_:
        #line 24 "birch/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 24 "birch/filter.birch"
        model = birch::String(std::string(::optarg));
        break;
      #line 25 "birch/filter.birch"
      case seedFLAG_:
        #line 25 "birch/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 25 "birch/filter.birch"
        seed = birch::Integer(std::string(::optarg));
        break;
      #line 26 "birch/filter.birch"
      case quietFLAG_:
        #line 26 "birch/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 26 "birch/filter.birch"
        quiet = birch::Boolean(std::string(::optarg));
        break;
      #line 20 "birch/filter.birch"
      case '?':
        #line 20 "birch/filter.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 20 "birch/filter.birch"
      case ':':
        #line 20 "birch/filter.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 20 "birch/filter.birch"
      default:
        #line 20 "birch/filter.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 20 "birch/filter.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 28 "birch/filter.birch"
  libbirch_line_(28);
  #line 28 "birch/filter.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> configBuffer;
  #line 29 "birch/filter.birch"
  libbirch_line_(29);
  #line 29 "birch/filter.birch"
  if (config.query()) {
    #line 30 "birch/filter.birch"
    libbirch_line_(30);
    #line 30 "birch/filter.birch"
    auto reader = birch::Reader(config.get(), handler_);
    #line 31 "birch/filter.birch"
    libbirch_line_(31);
    #line 31 "birch/filter.birch"
    configBuffer = reader->scan(handler_);
    #line 32 "birch/filter.birch"
    libbirch_line_(32);
    #line 32 "birch/filter.birch"
    reader->close(handler_);
  }
  #line 36 "birch/filter.birch"
  libbirch_line_(36);
  #line 36 "birch/filter.birch"
  if (seed.query()) {
    #line 37 "birch/filter.birch"
    libbirch_line_(37);
    #line 37 "birch/filter.birch"
    birch::seed(seed.get(), handler_);
  } else {
    #line 38 "birch/filter.birch"
    libbirch_line_(38);
    #line 38 "birch/filter.birch"
    if (config.query()) {
      #line 39 "birch/filter.birch"
      libbirch_line_(39);
      #line 39 "birch/filter.birch"
      auto buffer = configBuffer->getInteger(birch::type::String("seed"), handler_);
      #line 40 "birch/filter.birch"
      libbirch_line_(40);
      #line 40 "birch/filter.birch"
      if (buffer.query()) {
        #line 41 "birch/filter.birch"
        libbirch_line_(41);
        #line 41 "birch/filter.birch"
        birch::seed(buffer.get(), handler_);
      }
    } else {
      #line 44 "birch/filter.birch"
      libbirch_line_(44);
      #line 44 "birch/filter.birch"
      birch::seed(handler_);
    }
  }
  #line 48 "birch/filter.birch"
  libbirch_line_(48);
  #line 48 "birch/filter.birch"
  auto buffer = configBuffer->getObject(birch::type::String("model"), handler_);
  #line 49 "birch/filter.birch"
  libbirch_line_(49);
  #line 49 "birch/filter.birch"
  if (!buffer.query()) {
    #line 50 "birch/filter.birch"
    libbirch_line_(50);
    #line 50 "birch/filter.birch"
    buffer = configBuffer->setObject(birch::type::String("model"), handler_);
  }
  #line 52 "birch/filter.birch"
  libbirch_line_(52);
  #line 52 "birch/filter.birch"
  if (!buffer.get()->getString(birch::type::String("class"), handler_).query() && model.query()) {
    #line 53 "birch/filter.birch"
    libbirch_line_(53);
    #line 53 "birch/filter.birch"
    buffer.get()->setString(birch::type::String("class"), model.get(), handler_);
  }
  #line 55 "birch/filter.birch"
  libbirch_line_(55);
  #line 55 "birch/filter.birch"
  auto archetype = libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::Model>>>(birch::make(buffer, handler_));
  #line 56 "birch/filter.birch"
  libbirch_line_(56);
  #line 56 "birch/filter.birch"
  if (!archetype.query()) {
    #line 57 "birch/filter.birch"
    libbirch_line_(57);
    #line 57 "birch/filter.birch"
    birch::error(birch::type::String("could not create model; the model class should be given as ") + birch::type::String("model.class in the config file, and should derive from Model."), handler_);
  }
  #line 62 "birch/filter.birch"
  libbirch_line_(62);
  #line 62 "birch/filter.birch"
  buffer = configBuffer->getObject(birch::type::String("filter"), handler_);
  #line 63 "birch/filter.birch"
  libbirch_line_(63);
  #line 63 "birch/filter.birch"
  if (!buffer.query()) {
    #line 64 "birch/filter.birch"
    libbirch_line_(64);
    #line 64 "birch/filter.birch"
    buffer = configBuffer->setObject(birch::type::String("filter"), handler_);
  }
  #line 66 "birch/filter.birch"
  libbirch_line_(66);
  #line 66 "birch/filter.birch"
  if (!buffer.get()->getString(birch::type::String("class"), handler_).query()) {
    #line 67 "birch/filter.birch"
    libbirch_line_(67);
    #line 67 "birch/filter.birch"
    buffer.get()->setString(birch::type::String("class"), birch::type::String("ParticleFilter"), handler_);
  }
  #line 69 "birch/filter.birch"
  libbirch_line_(69);
  #line 69 "birch/filter.birch"
  auto filter = libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::ParticleFilter>>>(birch::make(buffer, handler_));
  #line 70 "birch/filter.birch"
  libbirch_line_(70);
  #line 70 "birch/filter.birch"
  if (!filter.query()) {
    #line 71 "birch/filter.birch"
    libbirch_line_(71);
    #line 71 "birch/filter.birch"
    birch::error(birch::type::String("could not create filter; the filter class should be given as ") + birch::type::String("filter.class in the config file, and should derive from ParticleFilter."), handler_);
  }
  #line 76 "birch/filter.birch"
  libbirch_line_(76);
  #line 76 "birch/filter.birch"
  auto inputPath = input;
  #line 77 "birch/filter.birch"
  libbirch_line_(77);
  #line 77 "birch/filter.birch"
  if (!inputPath.query()) {
    #line 78 "birch/filter.birch"
    libbirch_line_(78);
    #line 78 "birch/filter.birch"
    libbirch::optional_assign(inputPath, configBuffer->getString(birch::type::String("input"), handler_));
  }
  #line 80 "birch/filter.birch"
  libbirch_line_(80);
  #line 80 "birch/filter.birch"
  if (inputPath.query() && inputPath.get() != birch::type::String("")) {
    #line 81 "birch/filter.birch"
    libbirch_line_(81);
    #line 81 "birch/filter.birch"
    auto reader = birch::Reader(inputPath.get(), handler_);
    #line 82 "birch/filter.birch"
    libbirch_line_(82);
    #line 82 "birch/filter.birch"
    auto inputBuffer = reader->scan(handler_);
    #line 83 "birch/filter.birch"
    libbirch_line_(83);
    #line 83 "birch/filter.birch"
    reader->close(handler_);
    #line 84 "birch/filter.birch"
    libbirch_line_(84);
    #line 84 "birch/filter.birch"
    inputBuffer->get(archetype.get(), handler_);
  }
  #line 88 "birch/filter.birch"
  libbirch_line_(88);
  #line 88 "birch/filter.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Writer>>> outputWriter;
  #line 89 "birch/filter.birch"
  libbirch_line_(89);
  #line 89 "birch/filter.birch"
  libbirch::Optional<birch::type::String> outputPath = output;
  #line 90 "birch/filter.birch"
  libbirch_line_(90);
  #line 90 "birch/filter.birch"
  if (!outputPath.query()) {
    #line 91 "birch/filter.birch"
    libbirch_line_(91);
    #line 91 "birch/filter.birch"
    libbirch::optional_assign(outputPath, configBuffer->getString(birch::type::String("output"), handler_));
  }
  #line 93 "birch/filter.birch"
  libbirch_line_(93);
  #line 93 "birch/filter.birch"
  if (outputPath.query() && outputPath.get() != birch::type::String("")) {
    #line 94 "birch/filter.birch"
    libbirch_line_(94);
    #line 94 "birch/filter.birch"
    outputWriter = birch::Writer(outputPath.get(), handler_);
    #line 95 "birch/filter.birch"
    libbirch_line_(95);
    #line 95 "birch/filter.birch"
    outputWriter.get()->startSequence(handler_);
  }
  #line 99 "birch/filter.birch"
  libbirch_line_(99);
  #line 99 "birch/filter.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::ProgressBar>> bar;
  #line 100 "birch/filter.birch"
  libbirch_line_(100);
  #line 100 "birch/filter.birch"
  if (!quiet) {
    #line 101 "birch/filter.birch"
    libbirch_line_(101);
    #line 101 "birch/filter.birch"
    bar->update(0.0, handler_);
  }
  #line 105 "birch/filter.birch"
  libbirch_line_(105);
  #line 105 "birch/filter.birch"
  filter.get()->initialize(archetype.get(), handler_);
  #line 106 "birch/filter.birch"
  libbirch_line_(106);
  #line 106 "birch/filter.birch"
  for (auto t = birch::type::Integer(0); t <= filter.get()->size(handler_); ++t) {
    #line 107 "birch/filter.birch"
    libbirch_line_(107);
    #line 107 "birch/filter.birch"
    if (t == birch::type::Integer(0)) {
      #line 108 "birch/filter.birch"
      libbirch_line_(108);
      #line 108 "birch/filter.birch"
      filter.get()->filter(handler_);
    } else {
      #line 110 "birch/filter.birch"
      libbirch_line_(110);
      #line 110 "birch/filter.birch"
      filter.get()->filter(t, handler_);
    }
    #line 114 "birch/filter.birch"
    libbirch_line_(114);
    #line 114 "birch/filter.birch"
    libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> buffer;
    #line 115 "birch/filter.birch"
    libbirch_line_(115);
    #line 115 "birch/filter.birch"
    if (outputWriter.query()) {
      #line 116 "birch/filter.birch"
      libbirch_line_(116);
      #line 116 "birch/filter.birch"
      filter.get()->write(buffer, t, handler_);
    }
    #line 120 "birch/filter.birch"
    libbirch_line_(120);
    #line 120 "birch/filter.birch"
    if (filter.get()->nforecasts > birch::type::Integer(0)) {
      #line 122 "birch/filter.birch"
      libbirch_line_(122);
      #line 122 "birch/filter.birch"
      auto filter_prime_ = birch::clone(filter.get(), handler_);
      #line 125 "birch/filter.birch"
      libbirch_line_(125);
      #line 125 "birch/filter.birch"
      filter_prime_->resample(t, handler_);
      #line 126 "birch/filter.birch"
      libbirch_line_(126);
      #line 126 "birch/filter.birch"
      auto w_prime_ = filter_prime_->w;
      #line 130 "birch/filter.birch"
      libbirch_line_(130);
      #line 130 "birch/filter.birch"
      filter_prime_->delayed = false;
      #line 133 "birch/filter.birch"
      libbirch_line_(133);
      #line 133 "birch/filter.birch"
      auto forecast = buffer->setArray(birch::type::String("forecast"), handler_);
      #line 134 "birch/filter.birch"
      libbirch_line_(134);
      #line 134 "birch/filter.birch"
      for (auto s = (t + birch::type::Integer(1)); s <= (t + filter_prime_->nforecasts); ++s) {
        #line 135 "birch/filter.birch"
        libbirch_line_(135);
        #line 135 "birch/filter.birch"
        filter_prime_->forecast(s, handler_);
        #line 136 "birch/filter.birch"
        libbirch_line_(136);
        #line 136 "birch/filter.birch"
        filter_prime_->reduce(handler_);
        #line 137 "birch/filter.birch"
        libbirch_line_(137);
        #line 137 "birch/filter.birch"
        if (outputWriter.query()) {
          #line 138 "birch/filter.birch"
          libbirch_line_(138);
          #line 138 "birch/filter.birch"
          auto state = forecast->push(handler_);
          #line 139 "birch/filter.birch"
          libbirch_line_(139);
          #line 139 "birch/filter.birch"
          state->set(birch::type::String("sample"), filter_prime_->x, handler_);
          #line 140 "birch/filter.birch"
          libbirch_line_(140);
          #line 140 "birch/filter.birch"
          state->set(birch::type::String("lweight"), w_prime_, handler_);
          #line 141 "birch/filter.birch"
          libbirch_line_(141);
          #line 141 "birch/filter.birch"
          state->set(birch::type::String("lnormalize"), filter_prime_->lnormalize, handler_);
        }
      }
      #line 144 "birch/filter.birch"
      libbirch_line_(144);
      #line 144 "birch/filter.birch"
      birch::collect(handler_);
    }
    #line 146 "birch/filter.birch"
    libbirch_line_(146);
    #line 146 "birch/filter.birch"
    if (outputWriter.query()) {
      #line 147 "birch/filter.birch"
      libbirch_line_(147);
      #line 147 "birch/filter.birch"
      outputWriter.get()->print(buffer, handler_);
      #line 148 "birch/filter.birch"
      libbirch_line_(148);
      #line 148 "birch/filter.birch"
      outputWriter.get()->flush(handler_);
    }
    #line 150 "birch/filter.birch"
    libbirch_line_(150);
    #line 150 "birch/filter.birch"
    if (!quiet) {
      #line 151 "birch/filter.birch"
      libbirch_line_(151);
      #line 151 "birch/filter.birch"
      bar->update((t + 1.0) / (filter.get()->size(handler_) + 1.0), handler_);
    }
  }
  #line 156 "birch/filter.birch"
  libbirch_line_(156);
  #line 156 "birch/filter.birch"
  if (outputWriter.query()) {
    #line 157 "birch/filter.birch"
    libbirch_line_(157);
    #line 157 "birch/filter.birch"
    outputWriter.get()->endSequence(handler_);
    #line 158 "birch/filter.birch"
    libbirch_line_(158);
    #line 158 "birch/filter.birch"
    outputWriter.get()->close(handler_);
  }
  #line 20 "birch/filter.birch"
  libbirch_line_(20);
  #line 20 "birch/filter.birch"
  return 0;
}

#line 20 "birch/sample.birch"
int birch::sample(int argc_, char** argv_) {
  #line 20 "birch/sample.birch"
  libbirch_function_("sample", "birch/sample.birch", 20);
  #line 20 "birch/sample.birch"
  libbirch::Optional<birch::type::String> input;
  #line 20 "birch/sample.birch"
  libbirch::Optional<birch::type::String> output;
  #line 20 "birch/sample.birch"
  libbirch::Optional<birch::type::String> config;
  #line 20 "birch/sample.birch"
  libbirch::Optional<birch::type::String> model;
  #line 20 "birch/sample.birch"
  libbirch::Optional<birch::type::Integer> seed;
  #line 20 "birch/sample.birch"
  birch::type::Boolean quiet = false;
  
  enum {
    inputFLAG_,
    outputFLAG_,
    configFLAG_,
    modelFLAG_,
    seedFLAG_,
    quietFLAG_,
  };
  #line 20 "birch/sample.birch"
  int c_, option_index_;
  #line 20 "birch/sample.birch"
  option long_options_[] = {
    #line 20 "birch/sample.birch"
    {"input", required_argument, 0, inputFLAG_ },
    #line 20 "birch/sample.birch"
    {"output", required_argument, 0, outputFLAG_ },
    #line 20 "birch/sample.birch"
    {"config", required_argument, 0, configFLAG_ },
    #line 20 "birch/sample.birch"
    {"model", required_argument, 0, modelFLAG_ },
    #line 20 "birch/sample.birch"
    {"seed", required_argument, 0, seedFLAG_ },
    #line 20 "birch/sample.birch"
    {"quiet", required_argument, 0, quietFLAG_ },
    #line 20 "birch/sample.birch"
    {0, 0, 0, 0}
  #line 20 "birch/sample.birch"
  };
  #line 20 "birch/sample.birch"
  const char* short_options_ = ":";
  #line 20 "birch/sample.birch"
  ::opterr = 0;
  #line 20 "birch/sample.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 20 "birch/sample.birch"
  while (c_ != -1) {
    #line 20 "birch/sample.birch"
    switch (c_) {
      #line 21 "birch/sample.birch"
      case inputFLAG_:
        #line 21 "birch/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 21 "birch/sample.birch"
        input = birch::String(std::string(::optarg));
        break;
      #line 22 "birch/sample.birch"
      case outputFLAG_:
        #line 22 "birch/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 22 "birch/sample.birch"
        output = birch::String(std::string(::optarg));
        break;
      #line 23 "birch/sample.birch"
      case configFLAG_:
        #line 23 "birch/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 23 "birch/sample.birch"
        config = birch::String(std::string(::optarg));
        break;
      #line 24 "birch/sample.birch"
      case modelFLAG_:
        #line 24 "birch/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 24 "birch/sample.birch"
        model = birch::String(std::string(::optarg));
        break;
      #line 25 "birch/sample.birch"
      case seedFLAG_:
        #line 25 "birch/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 25 "birch/sample.birch"
        seed = birch::Integer(std::string(::optarg));
        break;
      #line 26 "birch/sample.birch"
      case quietFLAG_:
        #line 26 "birch/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 26 "birch/sample.birch"
        quiet = birch::Boolean(std::string(::optarg));
        break;
      #line 20 "birch/sample.birch"
      case '?':
        #line 20 "birch/sample.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 20 "birch/sample.birch"
      case ':':
        #line 20 "birch/sample.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 20 "birch/sample.birch"
      default:
        #line 20 "birch/sample.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 20 "birch/sample.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> handler_(true);

  #line 28 "birch/sample.birch"
  libbirch_line_(28);
  #line 28 "birch/sample.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> configBuffer;
  #line 29 "birch/sample.birch"
  libbirch_line_(29);
  #line 29 "birch/sample.birch"
  if (config.query()) {
    #line 30 "birch/sample.birch"
    libbirch_line_(30);
    #line 30 "birch/sample.birch"
    auto reader = birch::Reader(config.get(), handler_);
    #line 31 "birch/sample.birch"
    libbirch_line_(31);
    #line 31 "birch/sample.birch"
    configBuffer = reader->scan(handler_);
    #line 32 "birch/sample.birch"
    libbirch_line_(32);
    #line 32 "birch/sample.birch"
    reader->close(handler_);
  }
  #line 36 "birch/sample.birch"
  libbirch_line_(36);
  #line 36 "birch/sample.birch"
  if (seed.query()) {
    #line 37 "birch/sample.birch"
    libbirch_line_(37);
    #line 37 "birch/sample.birch"
    birch::seed(seed.get(), handler_);
  } else {
    #line 38 "birch/sample.birch"
    libbirch_line_(38);
    #line 38 "birch/sample.birch"
    if (config.query()) {
      #line 39 "birch/sample.birch"
      libbirch_line_(39);
      #line 39 "birch/sample.birch"
      auto buffer = configBuffer->getInteger(birch::type::String("seed"), handler_);
      #line 40 "birch/sample.birch"
      libbirch_line_(40);
      #line 40 "birch/sample.birch"
      if (buffer.query()) {
        #line 41 "birch/sample.birch"
        libbirch_line_(41);
        #line 41 "birch/sample.birch"
        birch::seed(buffer.get(), handler_);
      }
    } else {
      #line 44 "birch/sample.birch"
      libbirch_line_(44);
      #line 44 "birch/sample.birch"
      birch::seed(handler_);
    }
  }
  #line 48 "birch/sample.birch"
  libbirch_line_(48);
  #line 48 "birch/sample.birch"
  auto buffer = configBuffer->getObject(birch::type::String("model"), handler_);
  #line 49 "birch/sample.birch"
  libbirch_line_(49);
  #line 49 "birch/sample.birch"
  if (!buffer.query()) {
    #line 50 "birch/sample.birch"
    libbirch_line_(50);
    #line 50 "birch/sample.birch"
    buffer = configBuffer->setObject(birch::type::String("model"), handler_);
  }
  #line 52 "birch/sample.birch"
  libbirch_line_(52);
  #line 52 "birch/sample.birch"
  if (!buffer.get()->getString(birch::type::String("class"), handler_).query() && model.query()) {
    #line 53 "birch/sample.birch"
    libbirch_line_(53);
    #line 53 "birch/sample.birch"
    buffer.get()->setString(birch::type::String("class"), model.get(), handler_);
  }
  #line 55 "birch/sample.birch"
  libbirch_line_(55);
  #line 55 "birch/sample.birch"
  auto archetype = libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::Model>>>(birch::make(buffer, handler_));
  #line 56 "birch/sample.birch"
  libbirch_line_(56);
  #line 56 "birch/sample.birch"
  if (!archetype.query()) {
    #line 57 "birch/sample.birch"
    libbirch_line_(57);
    #line 57 "birch/sample.birch"
    birch::error(birch::type::String("could not create model; the model class should be given as ") + birch::type::String("model.class in the config file, and should derive from Model."), handler_);
  }
  #line 62 "birch/sample.birch"
  libbirch_line_(62);
  #line 62 "birch/sample.birch"
  buffer = configBuffer->getObject(birch::type::String("sampler"), handler_);
  #line 63 "birch/sample.birch"
  libbirch_line_(63);
  #line 63 "birch/sample.birch"
  if (!buffer.query()) {
    #line 64 "birch/sample.birch"
    libbirch_line_(64);
    #line 64 "birch/sample.birch"
    buffer = configBuffer->setObject(birch::type::String("sampler"), handler_);
  }
  #line 66 "birch/sample.birch"
  libbirch_line_(66);
  #line 66 "birch/sample.birch"
  if (!buffer.get()->getString(birch::type::String("class"), handler_).query()) {
    #line 67 "birch/sample.birch"
    libbirch_line_(67);
    #line 67 "birch/sample.birch"
    buffer.get()->setString(birch::type::String("class"), birch::type::String("MarginalizedParticleImportanceSampler"), handler_);
  }
  #line 69 "birch/sample.birch"
  libbirch_line_(69);
  #line 69 "birch/sample.birch"
  auto sampler = libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::ParticleSampler>>>(birch::make(buffer, handler_));
  #line 70 "birch/sample.birch"
  libbirch_line_(70);
  #line 70 "birch/sample.birch"
  if (!sampler.query()) {
    #line 71 "birch/sample.birch"
    libbirch_line_(71);
    #line 71 "birch/sample.birch"
    birch::error(birch::type::String("could not create sampler; the sampler class should be given as ") + birch::type::String("sampler.class in the config file, and should derive from ParticleSampler."), handler_);
  }
  #line 76 "birch/sample.birch"
  libbirch_line_(76);
  #line 76 "birch/sample.birch"
  buffer = configBuffer->getObject(birch::type::String("filter"), handler_);
  #line 77 "birch/sample.birch"
  libbirch_line_(77);
  #line 77 "birch/sample.birch"
  if (!buffer.query()) {
    #line 78 "birch/sample.birch"
    libbirch_line_(78);
    #line 78 "birch/sample.birch"
    buffer = configBuffer->setObject(birch::type::String("filter"), handler_);
  }
  #line 80 "birch/sample.birch"
  libbirch_line_(80);
  #line 80 "birch/sample.birch"
  if (!buffer.get()->getString(birch::type::String("class"), handler_).query()) {
    #line 81 "birch/sample.birch"
    libbirch_line_(81);
    #line 81 "birch/sample.birch"
    if (libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::ConditionalParticleSampler>>>(sampler).query()) {
      #line 82 "birch/sample.birch"
      libbirch_line_(82);
      #line 82 "birch/sample.birch"
      buffer.get()->setString(birch::type::String("class"), birch::type::String("ConditionalParticleFilter"), handler_);
    } else {
      #line 84 "birch/sample.birch"
      libbirch_line_(84);
      #line 84 "birch/sample.birch"
      buffer.get()->setString(birch::type::String("class"), birch::type::String("ParticleFilter"), handler_);
    }
  }
  #line 87 "birch/sample.birch"
  libbirch_line_(87);
  #line 87 "birch/sample.birch"
  auto filter = libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::ParticleFilter>>>(birch::make(buffer, handler_));
  #line 88 "birch/sample.birch"
  libbirch_line_(88);
  #line 88 "birch/sample.birch"
  if (!filter.query()) {
    #line 89 "birch/sample.birch"
    libbirch_line_(89);
    #line 89 "birch/sample.birch"
    birch::error(birch::type::String("could not create filter; the filter class should be given as ") + birch::type::String("filter.class in the config file, and should derive from ParticleFilter."), handler_);
  }
  #line 94 "birch/sample.birch"
  libbirch_line_(94);
  #line 94 "birch/sample.birch"
  auto inputPath = input;
  #line 95 "birch/sample.birch"
  libbirch_line_(95);
  #line 95 "birch/sample.birch"
  if (!inputPath.query()) {
    #line 96 "birch/sample.birch"
    libbirch_line_(96);
    #line 96 "birch/sample.birch"
    libbirch::optional_assign(inputPath, configBuffer->getString(birch::type::String("input"), handler_));
  }
  #line 98 "birch/sample.birch"
  libbirch_line_(98);
  #line 98 "birch/sample.birch"
  if (inputPath.query() && inputPath.get() != birch::type::String("")) {
    #line 99 "birch/sample.birch"
    libbirch_line_(99);
    #line 99 "birch/sample.birch"
    auto reader = birch::Reader(inputPath.get(), handler_);
    #line 100 "birch/sample.birch"
    libbirch_line_(100);
    #line 100 "birch/sample.birch"
    auto inputBuffer = reader->scan(handler_);
    #line 101 "birch/sample.birch"
    libbirch_line_(101);
    #line 101 "birch/sample.birch"
    reader->close(handler_);
    #line 102 "birch/sample.birch"
    libbirch_line_(102);
    #line 102 "birch/sample.birch"
    inputBuffer->get(archetype.get(), handler_);
  }
  #line 106 "birch/sample.birch"
  libbirch_line_(106);
  #line 106 "birch/sample.birch"
  libbirch::Optional<libbirch::Lazy<libbirch::Shared<birch::type::Writer>>> outputWriter;
  #line 107 "birch/sample.birch"
  libbirch_line_(107);
  #line 107 "birch/sample.birch"
  libbirch::Optional<birch::type::String> outputPath = output;
  #line 108 "birch/sample.birch"
  libbirch_line_(108);
  #line 108 "birch/sample.birch"
  if (!outputPath.query()) {
    #line 109 "birch/sample.birch"
    libbirch_line_(109);
    #line 109 "birch/sample.birch"
    libbirch::optional_assign(outputPath, configBuffer->getString(birch::type::String("output"), handler_));
  }
  #line 111 "birch/sample.birch"
  libbirch_line_(111);
  #line 111 "birch/sample.birch"
  if (outputPath.query() && outputPath.get() != birch::type::String("")) {
    #line 112 "birch/sample.birch"
    libbirch_line_(112);
    #line 112 "birch/sample.birch"
    outputWriter = birch::Writer(outputPath.get(), handler_);
    #line 113 "birch/sample.birch"
    libbirch_line_(113);
    #line 113 "birch/sample.birch"
    outputWriter.get()->startSequence(handler_);
  }
  #line 117 "birch/sample.birch"
  libbirch_line_(117);
  #line 117 "birch/sample.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::ProgressBar>> bar;
  #line 118 "birch/sample.birch"
  libbirch_line_(118);
  #line 118 "birch/sample.birch"
  if (!quiet) {
    #line 119 "birch/sample.birch"
    libbirch_line_(119);
    #line 119 "birch/sample.birch"
    bar->update(0.0, handler_);
  }
  #line 123 "birch/sample.birch"
  libbirch_line_(123);
  #line 123 "birch/sample.birch"
  sampler.get()->sample(filter.get(), archetype.get(), handler_);
  #line 124 "birch/sample.birch"
  libbirch_line_(124);
  #line 124 "birch/sample.birch"
  for (auto n = birch::type::Integer(1); n <= sampler.get()->size(handler_); ++n) {
    #line 125 "birch/sample.birch"
    libbirch_line_(125);
    #line 125 "birch/sample.birch"
    sampler.get()->sample(filter.get(), archetype.get(), n, handler_);
    #line 127 "birch/sample.birch"
    libbirch_line_(127);
    #line 127 "birch/sample.birch"
    if (outputWriter.query()) {
      #line 128 "birch/sample.birch"
      libbirch_line_(128);
      #line 128 "birch/sample.birch"
      libbirch::Lazy<libbirch::Shared<birch::type::Buffer>> buffer;
      #line 129 "birch/sample.birch"
      libbirch_line_(129);
      #line 129 "birch/sample.birch"
      sampler.get()->write(buffer, n, handler_);
      #line 130 "birch/sample.birch"
      libbirch_line_(130);
      #line 130 "birch/sample.birch"
      outputWriter.get()->print(buffer, handler_);
      #line 131 "birch/sample.birch"
      libbirch_line_(131);
      #line 131 "birch/sample.birch"
      outputWriter.get()->flush(handler_);
    }
    #line 133 "birch/sample.birch"
    libbirch_line_(133);
    #line 133 "birch/sample.birch"
    if (!quiet) {
      #line 134 "birch/sample.birch"
      libbirch_line_(134);
      #line 134 "birch/sample.birch"
      bar->update(birch::Real(n, handler_) / sampler.get()->nsamples, handler_);
    }
  }
  #line 139 "birch/sample.birch"
  libbirch_line_(139);
  #line 139 "birch/sample.birch"
  if (outputWriter.query()) {
    #line 140 "birch/sample.birch"
    libbirch_line_(140);
    #line 140 "birch/sample.birch"
    outputWriter.get()->endSequence(handler_);
    #line 141 "birch/sample.birch"
    libbirch_line_(141);
    #line 141 "birch/sample.birch"
    outputWriter.get()->close(handler_);
  }
  #line 20 "birch/sample.birch"
  libbirch_line_(20);
  #line 20 "birch/sample.birch"
  return 0;
}

