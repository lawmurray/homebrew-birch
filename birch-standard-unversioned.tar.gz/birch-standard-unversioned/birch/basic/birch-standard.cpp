#line 9 "birch/basic/Boolean.birch"
birch::type::Boolean birch::Boolean(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "birch/basic/Boolean.birch"
  libbirch_function_("Boolean", "birch/basic/Boolean.birch", 9);
  #line 10 "birch/basic/Boolean.birch"
  libbirch_line_(10);
  #line 10 "birch/basic/Boolean.birch"
  return x;
}

#line 16 "birch/basic/Boolean.birch"
birch::type::Boolean birch::Boolean(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "birch/basic/Boolean.birch"
  libbirch_function_("Boolean", "birch/basic/Boolean.birch", 16);
  #line 17 "birch/basic/Boolean.birch"
  libbirch_line_(17);
  #line 17 "birch/basic/Boolean.birch"
  return x == birch::type::String("true");
}

#line 23 "birch/basic/Boolean.birch"
libbirch::Optional<birch::type::Boolean> birch::Boolean(const libbirch::Optional<birch::type::Boolean>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "birch/basic/Boolean.birch"
  libbirch_function_("Boolean", "birch/basic/Boolean.birch", 23);
  #line 24 "birch/basic/Boolean.birch"
  libbirch_line_(24);
  #line 24 "birch/basic/Boolean.birch"
  return x;
}

#line 30 "birch/basic/Boolean.birch"
libbirch::Optional<birch::type::Boolean> birch::Boolean(const libbirch::Optional<birch::type::String>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "birch/basic/Boolean.birch"
  libbirch_function_("Boolean", "birch/basic/Boolean.birch", 30);
  #line 31 "birch/basic/Boolean.birch"
  libbirch_line_(31);
  #line 31 "birch/basic/Boolean.birch"
  if (x.query()) {
    #line 32 "birch/basic/Boolean.birch"
    libbirch_line_(32);
    #line 32 "birch/basic/Boolean.birch"
    return birch::Boolean(x.get(), handler_);
  } else {
    #line 34 "birch/basic/Boolean.birch"
    libbirch_line_(34);
    #line 34 "birch/basic/Boolean.birch"
    return libbirch::nil;
  }
}

#line 52 "birch/basic/Boolean.birch"
birch::type::Boolean birch::max(const birch::type::Boolean& x, const birch::type::Boolean& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "birch/basic/Boolean.birch"
  libbirch_function_("max", "birch/basic/Boolean.birch", 52);
  #line 53 "birch/basic/Boolean.birch"
  libbirch_line_(53);
  #line 53 "birch/basic/Boolean.birch"
  return x || y;
}

#line 59 "birch/basic/Boolean.birch"
birch::type::Boolean birch::min(const birch::type::Boolean& x, const birch::type::Boolean& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "birch/basic/Boolean.birch"
  libbirch_function_("min", "birch/basic/Boolean.birch", 59);
  #line 60 "birch/basic/Boolean.birch"
  libbirch_line_(60);
  #line 60 "birch/basic/Boolean.birch"
  return x && y;
}

#line 9 "birch/basic/Integer.birch"
birch::type::Integer birch::Integer(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "birch/basic/Integer.birch"
  libbirch_function_("Integer", "birch/basic/Integer.birch", 9);
  #line 10 "birch/basic/Integer.birch"
  libbirch_line_(10);
  #line 10 "birch/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 16 "birch/basic/Integer.birch"
birch::type::Integer birch::Integer(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "birch/basic/Integer.birch"
  libbirch_function_("Integer", "birch/basic/Integer.birch", 16);
  #line 17 "birch/basic/Integer.birch"
  libbirch_line_(17);
  #line 17 "birch/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 23 "birch/basic/Integer.birch"
birch::type::Integer birch::Integer(const birch::type::Integer64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "birch/basic/Integer.birch"
  libbirch_function_("Integer", "birch/basic/Integer.birch", 23);
  #line 24 "birch/basic/Integer.birch"
  libbirch_line_(24);
  #line 24 "birch/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 30 "birch/basic/Integer.birch"
birch::type::Integer birch::Integer(const birch::type::Integer32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "birch/basic/Integer.birch"
  libbirch_function_("Integer", "birch/basic/Integer.birch", 30);
  #line 31 "birch/basic/Integer.birch"
  libbirch_line_(31);
  #line 31 "birch/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 37 "birch/basic/Integer.birch"
birch::type::Integer birch::Integer(const birch::type::Integer16& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "birch/basic/Integer.birch"
  libbirch_function_("Integer", "birch/basic/Integer.birch", 37);
  #line 38 "birch/basic/Integer.birch"
  libbirch_line_(38);
  #line 38 "birch/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 44 "birch/basic/Integer.birch"
birch::type::Integer birch::Integer(const birch::type::Integer8& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "birch/basic/Integer.birch"
  libbirch_function_("Integer", "birch/basic/Integer.birch", 44);
  #line 45 "birch/basic/Integer.birch"
  libbirch_line_(45);
  #line 45 "birch/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 51 "birch/basic/Integer.birch"
birch::type::Integer birch::Integer(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 51 "birch/basic/Integer.birch"
  libbirch_function_("Integer", "birch/basic/Integer.birch", 51);
  #line 52 "birch/basic/Integer.birch"
  libbirch_line_(52);
  #line 52 "birch/basic/Integer.birch"
  if (x) {
    #line 53 "birch/basic/Integer.birch"
    libbirch_line_(53);
    #line 53 "birch/basic/Integer.birch"
    return birch::Integer(birch::type::Integer(1), handler_);
  } else {
    #line 55 "birch/basic/Integer.birch"
    libbirch_line_(55);
    #line 55 "birch/basic/Integer.birch"
    return birch::Integer(birch::type::Integer(0), handler_);
  }
}

#line 62 "birch/basic/Integer.birch"
birch::type::Integer birch::Integer(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 62 "birch/basic/Integer.birch"
  libbirch_function_("Integer", "birch/basic/Integer.birch", 62);
  #line 63 "birch/basic/Integer.birch"
  libbirch_line_(63);
  #line 63 "birch/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 69 "birch/basic/Integer.birch"
libbirch::Optional<birch::type::Integer> birch::Integer(const libbirch::Optional<birch::type::Real64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "birch/basic/Integer.birch"
  libbirch_function_("Integer", "birch/basic/Integer.birch", 69);
  #line 70 "birch/basic/Integer.birch"
  libbirch_line_(70);
  #line 70 "birch/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 76 "birch/basic/Integer.birch"
libbirch::Optional<birch::type::Integer> birch::Integer(const libbirch::Optional<birch::type::Real32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 76 "birch/basic/Integer.birch"
  libbirch_function_("Integer", "birch/basic/Integer.birch", 76);
  #line 77 "birch/basic/Integer.birch"
  libbirch_line_(77);
  #line 77 "birch/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 83 "birch/basic/Integer.birch"
libbirch::Optional<birch::type::Integer> birch::Integer(const libbirch::Optional<birch::type::Integer64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 83 "birch/basic/Integer.birch"
  libbirch_function_("Integer", "birch/basic/Integer.birch", 83);
  #line 84 "birch/basic/Integer.birch"
  libbirch_line_(84);
  #line 84 "birch/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 90 "birch/basic/Integer.birch"
libbirch::Optional<birch::type::Integer> birch::Integer(const libbirch::Optional<birch::type::Integer32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 90 "birch/basic/Integer.birch"
  libbirch_function_("Integer", "birch/basic/Integer.birch", 90);
  #line 91 "birch/basic/Integer.birch"
  libbirch_line_(91);
  #line 91 "birch/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 97 "birch/basic/Integer.birch"
libbirch::Optional<birch::type::Integer> birch::Integer(const libbirch::Optional<birch::type::Integer16>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 97 "birch/basic/Integer.birch"
  libbirch_function_("Integer", "birch/basic/Integer.birch", 97);
  #line 98 "birch/basic/Integer.birch"
  libbirch_line_(98);
  #line 98 "birch/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 104 "birch/basic/Integer.birch"
libbirch::Optional<birch::type::Integer> birch::Integer(const libbirch::Optional<birch::type::Integer8>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 104 "birch/basic/Integer.birch"
  libbirch_function_("Integer", "birch/basic/Integer.birch", 104);
  #line 105 "birch/basic/Integer.birch"
  libbirch_line_(105);
  #line 105 "birch/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 111 "birch/basic/Integer.birch"
libbirch::Optional<birch::type::Integer> birch::Integer(const libbirch::Optional<birch::type::String>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 111 "birch/basic/Integer.birch"
  libbirch_function_("Integer", "birch/basic/Integer.birch", 111);
  #line 112 "birch/basic/Integer.birch"
  libbirch_line_(112);
  #line 112 "birch/basic/Integer.birch"
  return birch::Integer64(x, handler_);
}

#line 9 "birch/basic/Integer8.birch"
birch::type::Integer8 birch::Integer8(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "birch/basic/Integer8.birch"
  libbirch_function_("Integer8", "birch/basic/Integer8.birch", 9);
  #line 10 "birch/basic/Integer8.birch"
return static_cast<birch::type::Integer8>(x);
  }

#line 18 "birch/basic/Integer8.birch"
birch::type::Integer8 birch::Integer8(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "birch/basic/Integer8.birch"
  libbirch_function_("Integer8", "birch/basic/Integer8.birch", 18);
  #line 19 "birch/basic/Integer8.birch"
return static_cast<birch::type::Integer8>(x);
  }

#line 27 "birch/basic/Integer8.birch"
birch::type::Integer8 birch::Integer8(const birch::type::Integer64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "birch/basic/Integer8.birch"
  libbirch_function_("Integer8", "birch/basic/Integer8.birch", 27);
  #line 28 "birch/basic/Integer8.birch"
return static_cast<birch::type::Integer8>(x);
  }

#line 36 "birch/basic/Integer8.birch"
birch::type::Integer8 birch::Integer8(const birch::type::Integer32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "birch/basic/Integer8.birch"
  libbirch_function_("Integer8", "birch/basic/Integer8.birch", 36);
  #line 37 "birch/basic/Integer8.birch"
return static_cast<birch::type::Integer8>(x);
  }

#line 45 "birch/basic/Integer8.birch"
birch::type::Integer8 birch::Integer8(const birch::type::Integer16& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "birch/basic/Integer8.birch"
  libbirch_function_("Integer8", "birch/basic/Integer8.birch", 45);
  #line 46 "birch/basic/Integer8.birch"
return static_cast<birch::type::Integer8>(x);
  }

#line 54 "birch/basic/Integer8.birch"
birch::type::Integer8 birch::Integer8(const birch::type::Integer8& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 54 "birch/basic/Integer8.birch"
  libbirch_function_("Integer8", "birch/basic/Integer8.birch", 54);
  #line 55 "birch/basic/Integer8.birch"
  libbirch_line_(55);
  #line 55 "birch/basic/Integer8.birch"
  return x;
}

#line 61 "birch/basic/Integer8.birch"
birch::type::Integer8 birch::Integer8(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "birch/basic/Integer8.birch"
  libbirch_function_("Integer8", "birch/basic/Integer8.birch", 61);
  #line 62 "birch/basic/Integer8.birch"
  libbirch_line_(62);
  #line 62 "birch/basic/Integer8.birch"
  if (x) {
    #line 63 "birch/basic/Integer8.birch"
    libbirch_line_(63);
    #line 63 "birch/basic/Integer8.birch"
    return birch::Integer8(birch::type::Integer(1), handler_);
  } else {
    #line 65 "birch/basic/Integer8.birch"
    libbirch_line_(65);
    #line 65 "birch/basic/Integer8.birch"
    return birch::Integer8(birch::type::Integer(0), handler_);
  }
}

#line 72 "birch/basic/Integer8.birch"
birch::type::Integer8 birch::Integer8(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "birch/basic/Integer8.birch"
  libbirch_function_("Integer8", "birch/basic/Integer8.birch", 72);
  #line 73 "birch/basic/Integer8.birch"
return ::atoi(x.c_str());
  }

#line 81 "birch/basic/Integer8.birch"
libbirch::Optional<birch::type::Integer8> birch::Integer8(const libbirch::Optional<birch::type::Real64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "birch/basic/Integer8.birch"
  libbirch_function_("Integer8", "birch/basic/Integer8.birch", 81);
  #line 82 "birch/basic/Integer8.birch"
  libbirch_line_(82);
  #line 82 "birch/basic/Integer8.birch"
  if (x.query()) {
    #line 83 "birch/basic/Integer8.birch"
    libbirch_line_(83);
    #line 83 "birch/basic/Integer8.birch"
    return birch::Integer8(x.get(), handler_);
  } else {
    #line 85 "birch/basic/Integer8.birch"
    libbirch_line_(85);
    #line 85 "birch/basic/Integer8.birch"
    return libbirch::nil;
  }
}

#line 92 "birch/basic/Integer8.birch"
libbirch::Optional<birch::type::Integer8> birch::Integer8(const libbirch::Optional<birch::type::Real32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 92 "birch/basic/Integer8.birch"
  libbirch_function_("Integer8", "birch/basic/Integer8.birch", 92);
  #line 93 "birch/basic/Integer8.birch"
  libbirch_line_(93);
  #line 93 "birch/basic/Integer8.birch"
  if (x.query()) {
    #line 94 "birch/basic/Integer8.birch"
    libbirch_line_(94);
    #line 94 "birch/basic/Integer8.birch"
    return birch::Integer8(x.get(), handler_);
  } else {
    #line 96 "birch/basic/Integer8.birch"
    libbirch_line_(96);
    #line 96 "birch/basic/Integer8.birch"
    return libbirch::nil;
  }
}

#line 103 "birch/basic/Integer8.birch"
libbirch::Optional<birch::type::Integer8> birch::Integer8(const libbirch::Optional<birch::type::Integer64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 103 "birch/basic/Integer8.birch"
  libbirch_function_("Integer8", "birch/basic/Integer8.birch", 103);
  #line 104 "birch/basic/Integer8.birch"
  libbirch_line_(104);
  #line 104 "birch/basic/Integer8.birch"
  if (x.query()) {
    #line 105 "birch/basic/Integer8.birch"
    libbirch_line_(105);
    #line 105 "birch/basic/Integer8.birch"
    return birch::Integer8(x.get(), handler_);
  } else {
    #line 107 "birch/basic/Integer8.birch"
    libbirch_line_(107);
    #line 107 "birch/basic/Integer8.birch"
    return libbirch::nil;
  }
}

#line 114 "birch/basic/Integer8.birch"
libbirch::Optional<birch::type::Integer8> birch::Integer8(const libbirch::Optional<birch::type::Integer32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 114 "birch/basic/Integer8.birch"
  libbirch_function_("Integer8", "birch/basic/Integer8.birch", 114);
  #line 115 "birch/basic/Integer8.birch"
  libbirch_line_(115);
  #line 115 "birch/basic/Integer8.birch"
  if (x.query()) {
    #line 116 "birch/basic/Integer8.birch"
    libbirch_line_(116);
    #line 116 "birch/basic/Integer8.birch"
    return birch::Integer8(x.get(), handler_);
  } else {
    #line 118 "birch/basic/Integer8.birch"
    libbirch_line_(118);
    #line 118 "birch/basic/Integer8.birch"
    return libbirch::nil;
  }
}

#line 125 "birch/basic/Integer8.birch"
libbirch::Optional<birch::type::Integer8> birch::Integer8(const libbirch::Optional<birch::type::Integer16>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 125 "birch/basic/Integer8.birch"
  libbirch_function_("Integer8", "birch/basic/Integer8.birch", 125);
  #line 126 "birch/basic/Integer8.birch"
  libbirch_line_(126);
  #line 126 "birch/basic/Integer8.birch"
  if (x.query()) {
    #line 127 "birch/basic/Integer8.birch"
    libbirch_line_(127);
    #line 127 "birch/basic/Integer8.birch"
    return birch::Integer8(x.get(), handler_);
  } else {
    #line 129 "birch/basic/Integer8.birch"
    libbirch_line_(129);
    #line 129 "birch/basic/Integer8.birch"
    return libbirch::nil;
  }
}

#line 136 "birch/basic/Integer8.birch"
libbirch::Optional<birch::type::Integer8> birch::Integer8(const libbirch::Optional<birch::type::Integer8>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 136 "birch/basic/Integer8.birch"
  libbirch_function_("Integer8", "birch/basic/Integer8.birch", 136);
  #line 137 "birch/basic/Integer8.birch"
  libbirch_line_(137);
  #line 137 "birch/basic/Integer8.birch"
  return x;
}

#line 143 "birch/basic/Integer8.birch"
libbirch::Optional<birch::type::Integer8> birch::Integer8(const libbirch::Optional<birch::type::String>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 143 "birch/basic/Integer8.birch"
  libbirch_function_("Integer8", "birch/basic/Integer8.birch", 143);
  #line 144 "birch/basic/Integer8.birch"
  libbirch_line_(144);
  #line 144 "birch/basic/Integer8.birch"
  if (x.query()) {
    #line 145 "birch/basic/Integer8.birch"
    libbirch_line_(145);
    #line 145 "birch/basic/Integer8.birch"
    return birch::Integer8(x.get(), handler_);
  } else {
    #line 147 "birch/basic/Integer8.birch"
    libbirch_line_(147);
    #line 147 "birch/basic/Integer8.birch"
    return libbirch::nil;
  }
}

#line 170 "birch/basic/Integer8.birch"
birch::type::Integer8 birch::abs(const birch::type::Integer8& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 170 "birch/basic/Integer8.birch"
  libbirch_function_("abs", "birch/basic/Integer8.birch", 170);
  #line 171 "birch/basic/Integer8.birch"
return std::abs(x);
  }

#line 179 "birch/basic/Integer8.birch"
birch::type::Integer8 birch::pow(const birch::type::Integer8& x, const birch::type::Integer8& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 179 "birch/basic/Integer8.birch"
  libbirch_function_("pow", "birch/basic/Integer8.birch", 179);
  #line 180 "birch/basic/Integer8.birch"
return std::pow(x, y);
  }

#line 188 "birch/basic/Integer8.birch"
birch::type::Integer8 birch::mod(const birch::type::Integer8& x, const birch::type::Integer8& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 188 "birch/basic/Integer8.birch"
  libbirch_function_("mod", "birch/basic/Integer8.birch", 188);
  #line 189 "birch/basic/Integer8.birch"
return x % y;
  }

#line 197 "birch/basic/Integer8.birch"
birch::type::Integer8 birch::max(const birch::type::Integer8& x, const birch::type::Integer8& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 197 "birch/basic/Integer8.birch"
  libbirch_function_("max", "birch/basic/Integer8.birch", 197);
  #line 198 "birch/basic/Integer8.birch"
return std::max(x, y);
  }

#line 206 "birch/basic/Integer8.birch"
birch::type::Integer8 birch::min(const birch::type::Integer8& x, const birch::type::Integer8& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 206 "birch/basic/Integer8.birch"
  libbirch_function_("min", "birch/basic/Integer8.birch", 206);
  #line 207 "birch/basic/Integer8.birch"
return std::min(x, y);
  }

#line 9 "birch/basic/Integer16.birch"
birch::type::Integer16 birch::Integer16(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "birch/basic/Integer16.birch"
  libbirch_function_("Integer16", "birch/basic/Integer16.birch", 9);
  #line 10 "birch/basic/Integer16.birch"
return static_cast<birch::type::Integer16>(x);
  }

#line 18 "birch/basic/Integer16.birch"
birch::type::Integer16 birch::Integer16(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "birch/basic/Integer16.birch"
  libbirch_function_("Integer16", "birch/basic/Integer16.birch", 18);
  #line 19 "birch/basic/Integer16.birch"
return static_cast<birch::type::Integer16>(x);
  }

#line 27 "birch/basic/Integer16.birch"
birch::type::Integer16 birch::Integer16(const birch::type::Integer64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "birch/basic/Integer16.birch"
  libbirch_function_("Integer16", "birch/basic/Integer16.birch", 27);
  #line 28 "birch/basic/Integer16.birch"
return static_cast<birch::type::Integer16>(x);
  }

#line 36 "birch/basic/Integer16.birch"
birch::type::Integer16 birch::Integer16(const birch::type::Integer32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "birch/basic/Integer16.birch"
  libbirch_function_("Integer16", "birch/basic/Integer16.birch", 36);
  #line 37 "birch/basic/Integer16.birch"
return static_cast<birch::type::Integer16>(x);
  }

#line 45 "birch/basic/Integer16.birch"
birch::type::Integer16 birch::Integer16(const birch::type::Integer16& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 45 "birch/basic/Integer16.birch"
  libbirch_function_("Integer16", "birch/basic/Integer16.birch", 45);
  #line 46 "birch/basic/Integer16.birch"
  libbirch_line_(46);
  #line 46 "birch/basic/Integer16.birch"
  return x;
}

#line 52 "birch/basic/Integer16.birch"
birch::type::Integer16 birch::Integer16(const birch::type::Integer8& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "birch/basic/Integer16.birch"
  libbirch_function_("Integer16", "birch/basic/Integer16.birch", 52);
  #line 53 "birch/basic/Integer16.birch"
return static_cast<birch::type::Integer8>(x);
  }

#line 61 "birch/basic/Integer16.birch"
birch::type::Integer16 birch::Integer16(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "birch/basic/Integer16.birch"
  libbirch_function_("Integer16", "birch/basic/Integer16.birch", 61);
  #line 62 "birch/basic/Integer16.birch"
  libbirch_line_(62);
  #line 62 "birch/basic/Integer16.birch"
  if (x) {
    #line 63 "birch/basic/Integer16.birch"
    libbirch_line_(63);
    #line 63 "birch/basic/Integer16.birch"
    return birch::Integer16(birch::type::Integer(1), handler_);
  } else {
    #line 65 "birch/basic/Integer16.birch"
    libbirch_line_(65);
    #line 65 "birch/basic/Integer16.birch"
    return birch::Integer16(birch::type::Integer(0), handler_);
  }
}

#line 72 "birch/basic/Integer16.birch"
birch::type::Integer16 birch::Integer16(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "birch/basic/Integer16.birch"
  libbirch_function_("Integer16", "birch/basic/Integer16.birch", 72);
  #line 73 "birch/basic/Integer16.birch"
return ::atoi(x.c_str());
  }

#line 81 "birch/basic/Integer16.birch"
libbirch::Optional<birch::type::Integer16> birch::Integer16(const libbirch::Optional<birch::type::Real64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "birch/basic/Integer16.birch"
  libbirch_function_("Integer16", "birch/basic/Integer16.birch", 81);
  #line 82 "birch/basic/Integer16.birch"
  libbirch_line_(82);
  #line 82 "birch/basic/Integer16.birch"
  if (x.query()) {
    #line 83 "birch/basic/Integer16.birch"
    libbirch_line_(83);
    #line 83 "birch/basic/Integer16.birch"
    return birch::Integer16(x.get(), handler_);
  } else {
    #line 85 "birch/basic/Integer16.birch"
    libbirch_line_(85);
    #line 85 "birch/basic/Integer16.birch"
    return libbirch::nil;
  }
}

#line 92 "birch/basic/Integer16.birch"
libbirch::Optional<birch::type::Integer16> birch::Integer16(const libbirch::Optional<birch::type::Real32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 92 "birch/basic/Integer16.birch"
  libbirch_function_("Integer16", "birch/basic/Integer16.birch", 92);
  #line 93 "birch/basic/Integer16.birch"
  libbirch_line_(93);
  #line 93 "birch/basic/Integer16.birch"
  if (x.query()) {
    #line 94 "birch/basic/Integer16.birch"
    libbirch_line_(94);
    #line 94 "birch/basic/Integer16.birch"
    return birch::Integer16(x.get(), handler_);
  } else {
    #line 96 "birch/basic/Integer16.birch"
    libbirch_line_(96);
    #line 96 "birch/basic/Integer16.birch"
    return libbirch::nil;
  }
}

#line 103 "birch/basic/Integer16.birch"
libbirch::Optional<birch::type::Integer16> birch::Integer16(const libbirch::Optional<birch::type::Integer64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 103 "birch/basic/Integer16.birch"
  libbirch_function_("Integer16", "birch/basic/Integer16.birch", 103);
  #line 104 "birch/basic/Integer16.birch"
  libbirch_line_(104);
  #line 104 "birch/basic/Integer16.birch"
  if (x.query()) {
    #line 105 "birch/basic/Integer16.birch"
    libbirch_line_(105);
    #line 105 "birch/basic/Integer16.birch"
    return birch::Integer16(x.get(), handler_);
  } else {
    #line 107 "birch/basic/Integer16.birch"
    libbirch_line_(107);
    #line 107 "birch/basic/Integer16.birch"
    return libbirch::nil;
  }
}

#line 114 "birch/basic/Integer16.birch"
libbirch::Optional<birch::type::Integer16> birch::Integer16(const libbirch::Optional<birch::type::Integer32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 114 "birch/basic/Integer16.birch"
  libbirch_function_("Integer16", "birch/basic/Integer16.birch", 114);
  #line 115 "birch/basic/Integer16.birch"
  libbirch_line_(115);
  #line 115 "birch/basic/Integer16.birch"
  if (x.query()) {
    #line 116 "birch/basic/Integer16.birch"
    libbirch_line_(116);
    #line 116 "birch/basic/Integer16.birch"
    return birch::Integer16(x.get(), handler_);
  } else {
    #line 118 "birch/basic/Integer16.birch"
    libbirch_line_(118);
    #line 118 "birch/basic/Integer16.birch"
    return libbirch::nil;
  }
}

#line 125 "birch/basic/Integer16.birch"
libbirch::Optional<birch::type::Integer16> birch::Integer16(const libbirch::Optional<birch::type::Integer16>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 125 "birch/basic/Integer16.birch"
  libbirch_function_("Integer16", "birch/basic/Integer16.birch", 125);
  #line 126 "birch/basic/Integer16.birch"
  libbirch_line_(126);
  #line 126 "birch/basic/Integer16.birch"
  return x;
}

#line 132 "birch/basic/Integer16.birch"
libbirch::Optional<birch::type::Integer16> birch::Integer16(const libbirch::Optional<birch::type::Integer8>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 132 "birch/basic/Integer16.birch"
  libbirch_function_("Integer16", "birch/basic/Integer16.birch", 132);
  #line 133 "birch/basic/Integer16.birch"
  libbirch_line_(133);
  #line 133 "birch/basic/Integer16.birch"
  if (x.query()) {
    #line 134 "birch/basic/Integer16.birch"
    libbirch_line_(134);
    #line 134 "birch/basic/Integer16.birch"
    return birch::Integer16(x.get(), handler_);
  } else {
    #line 136 "birch/basic/Integer16.birch"
    libbirch_line_(136);
    #line 136 "birch/basic/Integer16.birch"
    return libbirch::nil;
  }
}

#line 143 "birch/basic/Integer16.birch"
libbirch::Optional<birch::type::Integer16> birch::Integer16(const libbirch::Optional<birch::type::String>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 143 "birch/basic/Integer16.birch"
  libbirch_function_("Integer16", "birch/basic/Integer16.birch", 143);
  #line 144 "birch/basic/Integer16.birch"
  libbirch_line_(144);
  #line 144 "birch/basic/Integer16.birch"
  if (x.query()) {
    #line 145 "birch/basic/Integer16.birch"
    libbirch_line_(145);
    #line 145 "birch/basic/Integer16.birch"
    return birch::Integer16(x.get(), handler_);
  } else {
    #line 147 "birch/basic/Integer16.birch"
    libbirch_line_(147);
    #line 147 "birch/basic/Integer16.birch"
    return libbirch::nil;
  }
}

#line 170 "birch/basic/Integer16.birch"
birch::type::Integer16 birch::abs(const birch::type::Integer16& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 170 "birch/basic/Integer16.birch"
  libbirch_function_("abs", "birch/basic/Integer16.birch", 170);
  #line 171 "birch/basic/Integer16.birch"
return std::abs(x);
  }

#line 179 "birch/basic/Integer16.birch"
birch::type::Integer16 birch::pow(const birch::type::Integer16& x, const birch::type::Integer16& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 179 "birch/basic/Integer16.birch"
  libbirch_function_("pow", "birch/basic/Integer16.birch", 179);
  #line 180 "birch/basic/Integer16.birch"
return std::pow(x, y);
  }

#line 188 "birch/basic/Integer16.birch"
birch::type::Integer16 birch::mod(const birch::type::Integer16& x, const birch::type::Integer16& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 188 "birch/basic/Integer16.birch"
  libbirch_function_("mod", "birch/basic/Integer16.birch", 188);
  #line 189 "birch/basic/Integer16.birch"
return x % y;
  }

#line 197 "birch/basic/Integer16.birch"
birch::type::Integer16 birch::max(const birch::type::Integer16& x, const birch::type::Integer16& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 197 "birch/basic/Integer16.birch"
  libbirch_function_("max", "birch/basic/Integer16.birch", 197);
  #line 198 "birch/basic/Integer16.birch"
return std::max(x, y);
  }

#line 206 "birch/basic/Integer16.birch"
birch::type::Integer16 birch::min(const birch::type::Integer16& x, const birch::type::Integer16& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 206 "birch/basic/Integer16.birch"
  libbirch_function_("min", "birch/basic/Integer16.birch", 206);
  #line 207 "birch/basic/Integer16.birch"
return std::min(x, y);
  }

#line 9 "birch/basic/Integer32.birch"
birch::type::Integer32 birch::Integer32(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "birch/basic/Integer32.birch"
  libbirch_function_("Integer32", "birch/basic/Integer32.birch", 9);
  #line 10 "birch/basic/Integer32.birch"
return static_cast<birch::type::Integer32>(x);
  }

#line 18 "birch/basic/Integer32.birch"
birch::type::Integer32 birch::Integer32(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "birch/basic/Integer32.birch"
  libbirch_function_("Integer32", "birch/basic/Integer32.birch", 18);
  #line 19 "birch/basic/Integer32.birch"
return static_cast<birch::type::Integer32>(x);
  }

#line 27 "birch/basic/Integer32.birch"
birch::type::Integer32 birch::Integer32(const birch::type::Integer64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "birch/basic/Integer32.birch"
  libbirch_function_("Integer32", "birch/basic/Integer32.birch", 27);
  #line 28 "birch/basic/Integer32.birch"
return static_cast<birch::type::Integer32>(x);
  }

#line 36 "birch/basic/Integer32.birch"
birch::type::Integer32 birch::Integer32(const birch::type::Integer32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "birch/basic/Integer32.birch"
  libbirch_function_("Integer32", "birch/basic/Integer32.birch", 36);
  #line 37 "birch/basic/Integer32.birch"
  libbirch_line_(37);
  #line 37 "birch/basic/Integer32.birch"
  return x;
}

#line 43 "birch/basic/Integer32.birch"
birch::type::Integer32 birch::Integer32(const birch::type::Integer16& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "birch/basic/Integer32.birch"
  libbirch_function_("Integer32", "birch/basic/Integer32.birch", 43);
  #line 44 "birch/basic/Integer32.birch"
return static_cast<birch::type::Integer32>(x);
  }

#line 52 "birch/basic/Integer32.birch"
birch::type::Integer32 birch::Integer32(const birch::type::Integer8& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "birch/basic/Integer32.birch"
  libbirch_function_("Integer32", "birch/basic/Integer32.birch", 52);
  #line 53 "birch/basic/Integer32.birch"
return static_cast<birch::type::Integer32>(x);
  }

#line 61 "birch/basic/Integer32.birch"
birch::type::Integer32 birch::Integer32(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "birch/basic/Integer32.birch"
  libbirch_function_("Integer32", "birch/basic/Integer32.birch", 61);
  #line 62 "birch/basic/Integer32.birch"
  libbirch_line_(62);
  #line 62 "birch/basic/Integer32.birch"
  if (x) {
    #line 63 "birch/basic/Integer32.birch"
    libbirch_line_(63);
    #line 63 "birch/basic/Integer32.birch"
    return birch::Integer32(birch::type::Integer(1), handler_);
  } else {
    #line 65 "birch/basic/Integer32.birch"
    libbirch_line_(65);
    #line 65 "birch/basic/Integer32.birch"
    return birch::Integer32(birch::type::Integer(0), handler_);
  }
}

#line 72 "birch/basic/Integer32.birch"
birch::type::Integer32 birch::Integer32(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "birch/basic/Integer32.birch"
  libbirch_function_("Integer32", "birch/basic/Integer32.birch", 72);
  #line 73 "birch/basic/Integer32.birch"
return ::atoi(x.c_str());
  }

#line 81 "birch/basic/Integer32.birch"
libbirch::Optional<birch::type::Integer32> birch::Integer32(const libbirch::Optional<birch::type::Real64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "birch/basic/Integer32.birch"
  libbirch_function_("Integer32", "birch/basic/Integer32.birch", 81);
  #line 82 "birch/basic/Integer32.birch"
  libbirch_line_(82);
  #line 82 "birch/basic/Integer32.birch"
  if (x.query()) {
    #line 83 "birch/basic/Integer32.birch"
    libbirch_line_(83);
    #line 83 "birch/basic/Integer32.birch"
    return birch::Integer32(x.get(), handler_);
  } else {
    #line 85 "birch/basic/Integer32.birch"
    libbirch_line_(85);
    #line 85 "birch/basic/Integer32.birch"
    return libbirch::nil;
  }
}

#line 92 "birch/basic/Integer32.birch"
libbirch::Optional<birch::type::Integer32> birch::Integer32(const libbirch::Optional<birch::type::Real32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 92 "birch/basic/Integer32.birch"
  libbirch_function_("Integer32", "birch/basic/Integer32.birch", 92);
  #line 93 "birch/basic/Integer32.birch"
  libbirch_line_(93);
  #line 93 "birch/basic/Integer32.birch"
  if (x.query()) {
    #line 94 "birch/basic/Integer32.birch"
    libbirch_line_(94);
    #line 94 "birch/basic/Integer32.birch"
    return birch::Integer32(x.get(), handler_);
  } else {
    #line 96 "birch/basic/Integer32.birch"
    libbirch_line_(96);
    #line 96 "birch/basic/Integer32.birch"
    return libbirch::nil;
  }
}

#line 103 "birch/basic/Integer32.birch"
libbirch::Optional<birch::type::Integer32> birch::Integer32(const libbirch::Optional<birch::type::Integer64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 103 "birch/basic/Integer32.birch"
  libbirch_function_("Integer32", "birch/basic/Integer32.birch", 103);
  #line 104 "birch/basic/Integer32.birch"
  libbirch_line_(104);
  #line 104 "birch/basic/Integer32.birch"
  if (x.query()) {
    #line 105 "birch/basic/Integer32.birch"
    libbirch_line_(105);
    #line 105 "birch/basic/Integer32.birch"
    return birch::Integer32(x.get(), handler_);
  } else {
    #line 107 "birch/basic/Integer32.birch"
    libbirch_line_(107);
    #line 107 "birch/basic/Integer32.birch"
    return libbirch::nil;
  }
}

#line 114 "birch/basic/Integer32.birch"
libbirch::Optional<birch::type::Integer32> birch::Integer32(const libbirch::Optional<birch::type::Integer32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 114 "birch/basic/Integer32.birch"
  libbirch_function_("Integer32", "birch/basic/Integer32.birch", 114);
  #line 115 "birch/basic/Integer32.birch"
  libbirch_line_(115);
  #line 115 "birch/basic/Integer32.birch"
  return x;
}

#line 121 "birch/basic/Integer32.birch"
libbirch::Optional<birch::type::Integer32> birch::Integer32(const libbirch::Optional<birch::type::Integer16>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 121 "birch/basic/Integer32.birch"
  libbirch_function_("Integer32", "birch/basic/Integer32.birch", 121);
  #line 122 "birch/basic/Integer32.birch"
  libbirch_line_(122);
  #line 122 "birch/basic/Integer32.birch"
  if (x.query()) {
    #line 123 "birch/basic/Integer32.birch"
    libbirch_line_(123);
    #line 123 "birch/basic/Integer32.birch"
    return birch::Integer32(x.get(), handler_);
  } else {
    #line 125 "birch/basic/Integer32.birch"
    libbirch_line_(125);
    #line 125 "birch/basic/Integer32.birch"
    return libbirch::nil;
  }
}

#line 132 "birch/basic/Integer32.birch"
libbirch::Optional<birch::type::Integer32> birch::Integer32(const libbirch::Optional<birch::type::Integer8>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 132 "birch/basic/Integer32.birch"
  libbirch_function_("Integer32", "birch/basic/Integer32.birch", 132);
  #line 133 "birch/basic/Integer32.birch"
  libbirch_line_(133);
  #line 133 "birch/basic/Integer32.birch"
  if (x.query()) {
    #line 134 "birch/basic/Integer32.birch"
    libbirch_line_(134);
    #line 134 "birch/basic/Integer32.birch"
    return birch::Integer32(x.get(), handler_);
  } else {
    #line 136 "birch/basic/Integer32.birch"
    libbirch_line_(136);
    #line 136 "birch/basic/Integer32.birch"
    return libbirch::nil;
  }
}

#line 143 "birch/basic/Integer32.birch"
libbirch::Optional<birch::type::Integer32> birch::Integer32(const libbirch::Optional<birch::type::String>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 143 "birch/basic/Integer32.birch"
  libbirch_function_("Integer32", "birch/basic/Integer32.birch", 143);
  #line 144 "birch/basic/Integer32.birch"
  libbirch_line_(144);
  #line 144 "birch/basic/Integer32.birch"
  if (x.query()) {
    #line 145 "birch/basic/Integer32.birch"
    libbirch_line_(145);
    #line 145 "birch/basic/Integer32.birch"
    return birch::Integer32(x.get(), handler_);
  } else {
    #line 147 "birch/basic/Integer32.birch"
    libbirch_line_(147);
    #line 147 "birch/basic/Integer32.birch"
    return libbirch::nil;
  }
}

#line 170 "birch/basic/Integer32.birch"
birch::type::Integer32 birch::abs(const birch::type::Integer32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 170 "birch/basic/Integer32.birch"
  libbirch_function_("abs", "birch/basic/Integer32.birch", 170);
  #line 171 "birch/basic/Integer32.birch"
return std::abs(x);
  }

#line 179 "birch/basic/Integer32.birch"
birch::type::Integer32 birch::pow(const birch::type::Integer32& x, const birch::type::Integer32& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 179 "birch/basic/Integer32.birch"
  libbirch_function_("pow", "birch/basic/Integer32.birch", 179);
  #line 180 "birch/basic/Integer32.birch"
return std::pow(x, y);
  }

#line 188 "birch/basic/Integer32.birch"
birch::type::Integer32 birch::mod(const birch::type::Integer32& x, const birch::type::Integer32& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 188 "birch/basic/Integer32.birch"
  libbirch_function_("mod", "birch/basic/Integer32.birch", 188);
  #line 189 "birch/basic/Integer32.birch"
return x % y;
  }

#line 197 "birch/basic/Integer32.birch"
birch::type::Integer32 birch::max(const birch::type::Integer32& x, const birch::type::Integer32& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 197 "birch/basic/Integer32.birch"
  libbirch_function_("max", "birch/basic/Integer32.birch", 197);
  #line 198 "birch/basic/Integer32.birch"
return std::max(x, y);
  }

#line 206 "birch/basic/Integer32.birch"
birch::type::Integer32 birch::min(const birch::type::Integer32& x, const birch::type::Integer32& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 206 "birch/basic/Integer32.birch"
  libbirch_function_("min", "birch/basic/Integer32.birch", 206);
  #line 207 "birch/basic/Integer32.birch"
return std::min(x, y);
  }

#line 9 "birch/basic/Integer64.birch"
birch::type::Integer64 birch::Integer64(const birch::type::Integer64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "birch/basic/Integer64.birch"
  libbirch_function_("Integer64", "birch/basic/Integer64.birch", 9);
  #line 10 "birch/basic/Integer64.birch"
  libbirch_line_(10);
  #line 10 "birch/basic/Integer64.birch"
  return x;
}

#line 16 "birch/basic/Integer64.birch"
birch::type::Integer64 birch::Integer64(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "birch/basic/Integer64.birch"
  libbirch_function_("Integer64", "birch/basic/Integer64.birch", 16);
  #line 17 "birch/basic/Integer64.birch"
return static_cast<birch::type::Integer64>(x);
  }

#line 25 "birch/basic/Integer64.birch"
birch::type::Integer64 birch::Integer64(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "birch/basic/Integer64.birch"
  libbirch_function_("Integer64", "birch/basic/Integer64.birch", 25);
  #line 26 "birch/basic/Integer64.birch"
return static_cast<birch::type::Integer64>(x);
  }

#line 34 "birch/basic/Integer64.birch"
birch::type::Integer64 birch::Integer64(const birch::type::Integer32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "birch/basic/Integer64.birch"
  libbirch_function_("Integer64", "birch/basic/Integer64.birch", 34);
  #line 35 "birch/basic/Integer64.birch"
return static_cast<birch::type::Integer64>(x);
  }

#line 43 "birch/basic/Integer64.birch"
birch::type::Integer64 birch::Integer64(const birch::type::Integer16& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "birch/basic/Integer64.birch"
  libbirch_function_("Integer64", "birch/basic/Integer64.birch", 43);
  #line 44 "birch/basic/Integer64.birch"
return static_cast<birch::type::Integer64>(x);
  }

#line 52 "birch/basic/Integer64.birch"
birch::type::Integer64 birch::Integer64(const birch::type::Integer8& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "birch/basic/Integer64.birch"
  libbirch_function_("Integer64", "birch/basic/Integer64.birch", 52);
  #line 53 "birch/basic/Integer64.birch"
return static_cast<birch::type::Integer64>(x);
  }

#line 61 "birch/basic/Integer64.birch"
birch::type::Integer64 birch::Integer64(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "birch/basic/Integer64.birch"
  libbirch_function_("Integer64", "birch/basic/Integer64.birch", 61);
  #line 62 "birch/basic/Integer64.birch"
  libbirch_line_(62);
  #line 62 "birch/basic/Integer64.birch"
  if (x) {
    #line 63 "birch/basic/Integer64.birch"
    libbirch_line_(63);
    #line 63 "birch/basic/Integer64.birch"
    return birch::Integer64(birch::type::Integer(1), handler_);
  } else {
    #line 65 "birch/basic/Integer64.birch"
    libbirch_line_(65);
    #line 65 "birch/basic/Integer64.birch"
    return birch::Integer64(birch::type::Integer(0), handler_);
  }
}

#line 72 "birch/basic/Integer64.birch"
birch::type::Integer64 birch::Integer64(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "birch/basic/Integer64.birch"
  libbirch_function_("Integer64", "birch/basic/Integer64.birch", 72);
  #line 73 "birch/basic/Integer64.birch"
return ::atol(x.c_str());
  }

#line 81 "birch/basic/Integer64.birch"
libbirch::Optional<birch::type::Integer64> birch::Integer64(const libbirch::Optional<birch::type::Integer64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "birch/basic/Integer64.birch"
  libbirch_function_("Integer64", "birch/basic/Integer64.birch", 81);
  #line 82 "birch/basic/Integer64.birch"
  libbirch_line_(82);
  #line 82 "birch/basic/Integer64.birch"
  return x;
}

#line 88 "birch/basic/Integer64.birch"
libbirch::Optional<birch::type::Integer64> birch::Integer64(const libbirch::Optional<birch::type::Real64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 88 "birch/basic/Integer64.birch"
  libbirch_function_("Integer64", "birch/basic/Integer64.birch", 88);
  #line 89 "birch/basic/Integer64.birch"
  libbirch_line_(89);
  #line 89 "birch/basic/Integer64.birch"
  if (x.query()) {
    #line 90 "birch/basic/Integer64.birch"
    libbirch_line_(90);
    #line 90 "birch/basic/Integer64.birch"
    return birch::Integer64(x.get(), handler_);
  } else {
    #line 92 "birch/basic/Integer64.birch"
    libbirch_line_(92);
    #line 92 "birch/basic/Integer64.birch"
    return libbirch::nil;
  }
}

#line 99 "birch/basic/Integer64.birch"
libbirch::Optional<birch::type::Integer64> birch::Integer64(const libbirch::Optional<birch::type::Real32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 99 "birch/basic/Integer64.birch"
  libbirch_function_("Integer64", "birch/basic/Integer64.birch", 99);
  #line 100 "birch/basic/Integer64.birch"
  libbirch_line_(100);
  #line 100 "birch/basic/Integer64.birch"
  if (x.query()) {
    #line 101 "birch/basic/Integer64.birch"
    libbirch_line_(101);
    #line 101 "birch/basic/Integer64.birch"
    return birch::Integer64(x.get(), handler_);
  } else {
    #line 103 "birch/basic/Integer64.birch"
    libbirch_line_(103);
    #line 103 "birch/basic/Integer64.birch"
    return libbirch::nil;
  }
}

#line 110 "birch/basic/Integer64.birch"
libbirch::Optional<birch::type::Integer64> birch::Integer64(const libbirch::Optional<birch::type::Integer32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 110 "birch/basic/Integer64.birch"
  libbirch_function_("Integer64", "birch/basic/Integer64.birch", 110);
  #line 111 "birch/basic/Integer64.birch"
  libbirch_line_(111);
  #line 111 "birch/basic/Integer64.birch"
  if (x.query()) {
    #line 112 "birch/basic/Integer64.birch"
    libbirch_line_(112);
    #line 112 "birch/basic/Integer64.birch"
    return birch::Integer64(x.get(), handler_);
  } else {
    #line 114 "birch/basic/Integer64.birch"
    libbirch_line_(114);
    #line 114 "birch/basic/Integer64.birch"
    return libbirch::nil;
  }
}

#line 121 "birch/basic/Integer64.birch"
libbirch::Optional<birch::type::Integer64> birch::Integer64(const libbirch::Optional<birch::type::Integer16>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 121 "birch/basic/Integer64.birch"
  libbirch_function_("Integer64", "birch/basic/Integer64.birch", 121);
  #line 122 "birch/basic/Integer64.birch"
  libbirch_line_(122);
  #line 122 "birch/basic/Integer64.birch"
  if (x.query()) {
    #line 123 "birch/basic/Integer64.birch"
    libbirch_line_(123);
    #line 123 "birch/basic/Integer64.birch"
    return birch::Integer64(x.get(), handler_);
  } else {
    #line 125 "birch/basic/Integer64.birch"
    libbirch_line_(125);
    #line 125 "birch/basic/Integer64.birch"
    return libbirch::nil;
  }
}

#line 132 "birch/basic/Integer64.birch"
libbirch::Optional<birch::type::Integer64> birch::Integer64(const libbirch::Optional<birch::type::Integer8>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 132 "birch/basic/Integer64.birch"
  libbirch_function_("Integer64", "birch/basic/Integer64.birch", 132);
  #line 133 "birch/basic/Integer64.birch"
  libbirch_line_(133);
  #line 133 "birch/basic/Integer64.birch"
  if (x.query()) {
    #line 134 "birch/basic/Integer64.birch"
    libbirch_line_(134);
    #line 134 "birch/basic/Integer64.birch"
    return birch::Integer64(x.get(), handler_);
  } else {
    #line 136 "birch/basic/Integer64.birch"
    libbirch_line_(136);
    #line 136 "birch/basic/Integer64.birch"
    return libbirch::nil;
  }
}

#line 143 "birch/basic/Integer64.birch"
libbirch::Optional<birch::type::Integer64> birch::Integer64(const libbirch::Optional<birch::type::String>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 143 "birch/basic/Integer64.birch"
  libbirch_function_("Integer64", "birch/basic/Integer64.birch", 143);
  #line 144 "birch/basic/Integer64.birch"
  libbirch_line_(144);
  #line 144 "birch/basic/Integer64.birch"
  if (x.query()) {
    #line 145 "birch/basic/Integer64.birch"
    libbirch_line_(145);
    #line 145 "birch/basic/Integer64.birch"
    return birch::Integer64(x.get(), handler_);
  } else {
    #line 147 "birch/basic/Integer64.birch"
    libbirch_line_(147);
    #line 147 "birch/basic/Integer64.birch"
    return libbirch::nil;
  }
}

#line 170 "birch/basic/Integer64.birch"
birch::type::Integer64 birch::abs(const birch::type::Integer64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 170 "birch/basic/Integer64.birch"
  libbirch_function_("abs", "birch/basic/Integer64.birch", 170);
  #line 171 "birch/basic/Integer64.birch"
return std::abs(x);
  }

#line 179 "birch/basic/Integer64.birch"
birch::type::Integer64 birch::pow(const birch::type::Integer64& x, const birch::type::Integer64& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 179 "birch/basic/Integer64.birch"
  libbirch_function_("pow", "birch/basic/Integer64.birch", 179);
  #line 180 "birch/basic/Integer64.birch"
return std::pow(x, y);
  }

#line 188 "birch/basic/Integer64.birch"
birch::type::Integer64 birch::mod(const birch::type::Integer64& x, const birch::type::Integer64& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 188 "birch/basic/Integer64.birch"
  libbirch_function_("mod", "birch/basic/Integer64.birch", 188);
  #line 189 "birch/basic/Integer64.birch"
return x % y;
  }

#line 197 "birch/basic/Integer64.birch"
birch::type::Integer64 birch::max(const birch::type::Integer64& x, const birch::type::Integer64& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 197 "birch/basic/Integer64.birch"
  libbirch_function_("max", "birch/basic/Integer64.birch", 197);
  #line 198 "birch/basic/Integer64.birch"
return std::max(x, y);
  }

#line 206 "birch/basic/Integer64.birch"
birch::type::Integer64 birch::min(const birch::type::Integer64& x, const birch::type::Integer64& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 206 "birch/basic/Integer64.birch"
  libbirch_function_("min", "birch/basic/Integer64.birch", 206);
  #line 207 "birch/basic/Integer64.birch"
return std::min(x, y);
  }

#line 9 "birch/basic/LLT.birch"
birch::type::Integer64 birch::rows(const birch::type::LLT& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "birch/basic/LLT.birch"
  libbirch_function_("rows", "birch/basic/LLT.birch", 9);
  #line 10 "birch/basic/LLT.birch"
return X.rows();
  }

#line 18 "birch/basic/LLT.birch"
birch::type::Integer64 birch::columns(const birch::type::LLT& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "birch/basic/LLT.birch"
  libbirch_function_("columns", "birch/basic/LLT.birch", 18);
  #line 19 "birch/basic/LLT.birch"
return X.cols();
  }

#line 58 "birch/basic/LLT.birch"
birch::type::LLT birch::llt(const libbirch::DefaultArray<birch::type::Real,2>& S, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "birch/basic/LLT.birch"
  libbirch_function_("llt", "birch/basic/LLT.birch", 58);
  #line 59 "birch/basic/LLT.birch"
  libbirch_line_(59);
  #line 59 "birch/basic/LLT.birch"
  birch::type::LLT A;
  #line 60 "birch/basic/LLT.birch"
A.compute(S.toEigen());
    #line 63 "birch/basic/LLT.birch"
  libbirch_line_(63);
  #line 63 "birch/basic/LLT.birch"
  return A;
}

#line 70 "birch/basic/LLT.birch"
birch::type::LLT birch::llt(const birch::type::LLT& S, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 70 "birch/basic/LLT.birch"
  libbirch_function_("llt", "birch/basic/LLT.birch", 70);
  #line 71 "birch/basic/LLT.birch"
  libbirch_line_(71);
  #line 71 "birch/basic/LLT.birch"
  return S;
}

#line 84 "birch/basic/LLT.birch"
birch::type::LLT birch::rank_update(const birch::type::LLT& S, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 84 "birch/basic/LLT.birch"
  libbirch_function_("rank_update", "birch/basic/LLT.birch", 84);
  #line 85 "birch/basic/LLT.birch"
  libbirch_line_(85);
  #line 85 "birch/basic/LLT.birch"
  libbirch_assert_(birch::rows(S, handler_) == birch::length(x, handler_));
  #line 86 "birch/basic/LLT.birch"
auto A = S;
  A.rankUpdate(x.toEigen(), 1.0);
  return A;
  }

#line 106 "birch/basic/LLT.birch"
birch::type::LLT birch::rank_update(const birch::type::LLT& S, const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 106 "birch/basic/LLT.birch"
  libbirch_function_("rank_update", "birch/basic/LLT.birch", 106);
  #line 107 "birch/basic/LLT.birch"
  libbirch_line_(107);
  #line 107 "birch/basic/LLT.birch"
  libbirch_assert_(birch::rows(S, handler_) == birch::rows(X, handler_));
  #line 108 "birch/basic/LLT.birch"
  libbirch_line_(108);
  #line 108 "birch/basic/LLT.birch"
  birch::type::LLT A;
  #line 109 "birch/basic/LLT.birch"
A = S;
    #line 112 "birch/basic/LLT.birch"
  libbirch_line_(112);
  #line 112 "birch/basic/LLT.birch"
  auto R = birch::rows(X, handler_);
  #line 113 "birch/basic/LLT.birch"
  libbirch_line_(113);
  #line 113 "birch/basic/LLT.birch"
  auto C = birch::columns(X, handler_);
  #line 114 "birch/basic/LLT.birch"
  libbirch_line_(114);
  #line 114 "birch/basic/LLT.birch"
  for (auto j = birch::type::Integer(1); j <= C; ++j) {
    #line 115 "birch/basic/LLT.birch"
    libbirch_line_(115);
    #line 115 "birch/basic/LLT.birch"
    auto x = X.get(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, R - 1), j - 1));
    #line 116 "birch/basic/LLT.birch"
A.rankUpdate(x.toEigen(), 1.0);
      }
  #line 120 "birch/basic/LLT.birch"
  libbirch_line_(120);
  #line 120 "birch/basic/LLT.birch"
  return A;
}

#line 133 "birch/basic/LLT.birch"
birch::type::LLT birch::rank_downdate(const birch::type::LLT& S, const libbirch::DefaultArray<birch::type::Real,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 133 "birch/basic/LLT.birch"
  libbirch_function_("rank_downdate", "birch/basic/LLT.birch", 133);
  #line 134 "birch/basic/LLT.birch"
  libbirch_line_(134);
  #line 134 "birch/basic/LLT.birch"
  libbirch_assert_(birch::rows(S, handler_) == birch::length(x, handler_));
  #line 135 "birch/basic/LLT.birch"
auto A = S;
  A.rankUpdate(x.toEigen(), -1.0);
  return A;
  }

#line 155 "birch/basic/LLT.birch"
birch::type::LLT birch::rank_downdate(const birch::type::LLT& S, const libbirch::DefaultArray<birch::type::Real,2>& X, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 155 "birch/basic/LLT.birch"
  libbirch_function_("rank_downdate", "birch/basic/LLT.birch", 155);
  #line 156 "birch/basic/LLT.birch"
  libbirch_line_(156);
  #line 156 "birch/basic/LLT.birch"
  libbirch_assert_(birch::rows(S, handler_) == birch::rows(X, handler_));
  #line 157 "birch/basic/LLT.birch"
  libbirch_line_(157);
  #line 157 "birch/basic/LLT.birch"
  birch::type::LLT A;
  #line 158 "birch/basic/LLT.birch"
A = S;
    #line 161 "birch/basic/LLT.birch"
  libbirch_line_(161);
  #line 161 "birch/basic/LLT.birch"
  auto R = birch::rows(X, handler_);
  #line 162 "birch/basic/LLT.birch"
  libbirch_line_(162);
  #line 162 "birch/basic/LLT.birch"
  auto C = birch::columns(X, handler_);
  #line 163 "birch/basic/LLT.birch"
  libbirch_line_(163);
  #line 163 "birch/basic/LLT.birch"
  for (auto j = birch::type::Integer(1); j <= C; ++j) {
    #line 164 "birch/basic/LLT.birch"
    libbirch_line_(164);
    #line 164 "birch/basic/LLT.birch"
    auto x = X.get(libbirch::make_slice(libbirch::make_range(birch::type::Integer(1) - 1, R - 1), j - 1));
    #line 165 "birch/basic/LLT.birch"
A.rankUpdate(x.toEigen(), -1.0);
      }
  #line 169 "birch/basic/LLT.birch"
  libbirch_line_(169);
  #line 169 "birch/basic/LLT.birch"
  return A;
}

#line 175 "birch/basic/LLT.birch"
birch::type::LLT birch::operator+(const birch::type::LLT& x, const birch::type::LLT& y) {
  #line 175 "birch/basic/LLT.birch"
  libbirch_function_("+", "birch/basic/LLT.birch", 175);
  #line 176 "birch/basic/LLT.birch"
return (x.reconstructedMatrix() + y.reconstructedMatrix()).llt();
  }

#line 4 "birch/basic/Object.birch"
birch::type::Object::Object(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 4 "birch/basic/Object.birch"
    super_type_() {
  //
}

#line 8 "birch/basic/Object.birch"
void birch::type::Object::read(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 8 "birch/basic/Object.birch"
  libbirch_function_("read", "birch/basic/Object.birch", 8);
}

#line 15 "birch/basic/Object.birch"
void birch::type::Object::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "birch/basic/Object.birch"
  libbirch_function_("write", "birch/basic/Object.birch", 15);
}

#line 23 "birch/basic/Object.birch"
birch::type::Boolean birch::operator==(const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& y) {
  #line 23 "birch/basic/Object.birch"
  libbirch_function_("==", "birch/basic/Object.birch", 23);
  #line 24 "birch/basic/Object.birch"
return x.get() == y.get();
  }

#line 32 "birch/basic/Object.birch"
birch::type::Boolean birch::operator!=(const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& y) {
  #line 32 "birch/basic/Object.birch"
  libbirch_function_("!=", "birch/basic/Object.birch", 32);
  #line 33 "birch/basic/Object.birch"
  libbirch_line_(33);
  #line 33 "birch/basic/Object.birch"
  return !(x == y);
}

#line 39 "birch/basic/Object.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Object>> birch::Object(const libbirch::Lazy<libbirch::Shared<birch::type::Object>>& o, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 39 "birch/basic/Object.birch"
  libbirch_function_("Object", "birch/basic/Object.birch", 39);
  #line 40 "birch/basic/Object.birch"
  libbirch_line_(40);
  #line 40 "birch/basic/Object.birch"
  return o;
}

#line 9 "birch/basic/Real.birch"
birch::type::Real birch::Real(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "birch/basic/Real.birch"
  libbirch_function_("Real", "birch/basic/Real.birch", 9);
  #line 10 "birch/basic/Real.birch"
  libbirch_line_(10);
  #line 10 "birch/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 16 "birch/basic/Real.birch"
birch::type::Real birch::Real(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "birch/basic/Real.birch"
  libbirch_function_("Real", "birch/basic/Real.birch", 16);
  #line 17 "birch/basic/Real.birch"
  libbirch_line_(17);
  #line 17 "birch/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 23 "birch/basic/Real.birch"
birch::type::Real birch::Real(const birch::type::Integer64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "birch/basic/Real.birch"
  libbirch_function_("Real", "birch/basic/Real.birch", 23);
  #line 24 "birch/basic/Real.birch"
  libbirch_line_(24);
  #line 24 "birch/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 30 "birch/basic/Real.birch"
birch::type::Real birch::Real(const birch::type::Integer32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 30 "birch/basic/Real.birch"
  libbirch_function_("Real", "birch/basic/Real.birch", 30);
  #line 31 "birch/basic/Real.birch"
  libbirch_line_(31);
  #line 31 "birch/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 37 "birch/basic/Real.birch"
birch::type::Real birch::Real(const birch::type::Integer16& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "birch/basic/Real.birch"
  libbirch_function_("Real", "birch/basic/Real.birch", 37);
  #line 38 "birch/basic/Real.birch"
  libbirch_line_(38);
  #line 38 "birch/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 44 "birch/basic/Real.birch"
birch::type::Real birch::Real(const birch::type::Integer8& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "birch/basic/Real.birch"
  libbirch_function_("Real", "birch/basic/Real.birch", 44);
  #line 45 "birch/basic/Real.birch"
  libbirch_line_(45);
  #line 45 "birch/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 51 "birch/basic/Real.birch"
birch::type::Real birch::Real(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 51 "birch/basic/Real.birch"
  libbirch_function_("Real", "birch/basic/Real.birch", 51);
  #line 52 "birch/basic/Real.birch"
  libbirch_line_(52);
  #line 52 "birch/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 58 "birch/basic/Real.birch"
birch::type::Real birch::Real(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 58 "birch/basic/Real.birch"
  libbirch_function_("Real", "birch/basic/Real.birch", 58);
  #line 59 "birch/basic/Real.birch"
  libbirch_line_(59);
  #line 59 "birch/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 65 "birch/basic/Real.birch"
libbirch::Optional<birch::type::Real> birch::Real(const libbirch::Optional<birch::type::Real64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 65 "birch/basic/Real.birch"
  libbirch_function_("Real", "birch/basic/Real.birch", 65);
  #line 66 "birch/basic/Real.birch"
  libbirch_line_(66);
  #line 66 "birch/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 72 "birch/basic/Real.birch"
libbirch::Optional<birch::type::Real> birch::Real(const libbirch::Optional<birch::type::Real32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "birch/basic/Real.birch"
  libbirch_function_("Real", "birch/basic/Real.birch", 72);
  #line 73 "birch/basic/Real.birch"
  libbirch_line_(73);
  #line 73 "birch/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 79 "birch/basic/Real.birch"
libbirch::Optional<birch::type::Real> birch::Real(const libbirch::Optional<birch::type::Integer64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 79 "birch/basic/Real.birch"
  libbirch_function_("Real", "birch/basic/Real.birch", 79);
  #line 80 "birch/basic/Real.birch"
  libbirch_line_(80);
  #line 80 "birch/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 86 "birch/basic/Real.birch"
libbirch::Optional<birch::type::Real> birch::Real(const libbirch::Optional<birch::type::Integer32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 86 "birch/basic/Real.birch"
  libbirch_function_("Real", "birch/basic/Real.birch", 86);
  #line 87 "birch/basic/Real.birch"
  libbirch_line_(87);
  #line 87 "birch/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 93 "birch/basic/Real.birch"
libbirch::Optional<birch::type::Real> birch::Real(const libbirch::Optional<birch::type::Integer16>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 93 "birch/basic/Real.birch"
  libbirch_function_("Real", "birch/basic/Real.birch", 93);
  #line 94 "birch/basic/Real.birch"
  libbirch_line_(94);
  #line 94 "birch/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 100 "birch/basic/Real.birch"
libbirch::Optional<birch::type::Real> birch::Real(const libbirch::Optional<birch::type::Integer8>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 100 "birch/basic/Real.birch"
  libbirch_function_("Real", "birch/basic/Real.birch", 100);
  #line 101 "birch/basic/Real.birch"
  libbirch_line_(101);
  #line 101 "birch/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 107 "birch/basic/Real.birch"
libbirch::Optional<birch::type::Real> birch::Real(const libbirch::Optional<birch::type::String>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 107 "birch/basic/Real.birch"
  libbirch_function_("Real", "birch/basic/Real.birch", 107);
  #line 108 "birch/basic/Real.birch"
  libbirch_line_(108);
  #line 108 "birch/basic/Real.birch"
  return birch::Real64(x, handler_);
}

#line 9 "birch/basic/Real32.birch"
birch::type::Real32 birch::Real32(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "birch/basic/Real32.birch"
  libbirch_function_("Real32", "birch/basic/Real32.birch", 9);
  #line 10 "birch/basic/Real32.birch"
return static_cast<birch::type::Real32>(x);
  }

#line 18 "birch/basic/Real32.birch"
birch::type::Real32 birch::Real32(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "birch/basic/Real32.birch"
  libbirch_function_("Real32", "birch/basic/Real32.birch", 18);
  #line 19 "birch/basic/Real32.birch"
  libbirch_line_(19);
  #line 19 "birch/basic/Real32.birch"
  return x;
}

#line 25 "birch/basic/Real32.birch"
birch::type::Real32 birch::Real32(const birch::type::Integer64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "birch/basic/Real32.birch"
  libbirch_function_("Real32", "birch/basic/Real32.birch", 25);
  #line 26 "birch/basic/Real32.birch"
return static_cast<birch::type::Real32>(x);
  }

#line 34 "birch/basic/Real32.birch"
birch::type::Real32 birch::Real32(const birch::type::Integer32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "birch/basic/Real32.birch"
  libbirch_function_("Real32", "birch/basic/Real32.birch", 34);
  #line 35 "birch/basic/Real32.birch"
return static_cast<birch::type::Real32>(x);
  }

#line 43 "birch/basic/Real32.birch"
birch::type::Real32 birch::Real32(const birch::type::Integer16& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "birch/basic/Real32.birch"
  libbirch_function_("Real32", "birch/basic/Real32.birch", 43);
  #line 44 "birch/basic/Real32.birch"
return static_cast<birch::type::Real32>(x);
  }

#line 52 "birch/basic/Real32.birch"
birch::type::Real32 birch::Real32(const birch::type::Integer8& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "birch/basic/Real32.birch"
  libbirch_function_("Real32", "birch/basic/Real32.birch", 52);
  #line 53 "birch/basic/Real32.birch"
return static_cast<birch::type::Real32>(x);
  }

#line 61 "birch/basic/Real32.birch"
birch::type::Real32 birch::Real32(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "birch/basic/Real32.birch"
  libbirch_function_("Real32", "birch/basic/Real32.birch", 61);
  #line 62 "birch/basic/Real32.birch"
  libbirch_line_(62);
  #line 62 "birch/basic/Real32.birch"
  if (x) {
    #line 63 "birch/basic/Real32.birch"
    libbirch_line_(63);
    #line 63 "birch/basic/Real32.birch"
    return birch::Real32(1.0, handler_);
  } else {
    #line 65 "birch/basic/Real32.birch"
    libbirch_line_(65);
    #line 65 "birch/basic/Real32.birch"
    return birch::Real32(0.0, handler_);
  }
}

#line 72 "birch/basic/Real32.birch"
birch::type::Real32 birch::Real32(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "birch/basic/Real32.birch"
  libbirch_function_("Real32", "birch/basic/Real32.birch", 72);
  #line 73 "birch/basic/Real32.birch"
return ::strtof(x.c_str(), nullptr);
  }

#line 81 "birch/basic/Real32.birch"
libbirch::Optional<birch::type::Real32> birch::Real32(const libbirch::Optional<birch::type::Real64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "birch/basic/Real32.birch"
  libbirch_function_("Real32", "birch/basic/Real32.birch", 81);
  #line 82 "birch/basic/Real32.birch"
  libbirch_line_(82);
  #line 82 "birch/basic/Real32.birch"
  if (x.query()) {
    #line 83 "birch/basic/Real32.birch"
    libbirch_line_(83);
    #line 83 "birch/basic/Real32.birch"
    return birch::Real32(x.get(), handler_);
  } else {
    #line 85 "birch/basic/Real32.birch"
    libbirch_line_(85);
    #line 85 "birch/basic/Real32.birch"
    return libbirch::nil;
  }
}

#line 92 "birch/basic/Real32.birch"
libbirch::Optional<birch::type::Real32> birch::Real32(const libbirch::Optional<birch::type::Real32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 92 "birch/basic/Real32.birch"
  libbirch_function_("Real32", "birch/basic/Real32.birch", 92);
  #line 93 "birch/basic/Real32.birch"
  libbirch_line_(93);
  #line 93 "birch/basic/Real32.birch"
  return x;
}

#line 99 "birch/basic/Real32.birch"
libbirch::Optional<birch::type::Real32> birch::Real32(const libbirch::Optional<birch::type::Integer64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 99 "birch/basic/Real32.birch"
  libbirch_function_("Real32", "birch/basic/Real32.birch", 99);
  #line 100 "birch/basic/Real32.birch"
  libbirch_line_(100);
  #line 100 "birch/basic/Real32.birch"
  if (x.query()) {
    #line 101 "birch/basic/Real32.birch"
    libbirch_line_(101);
    #line 101 "birch/basic/Real32.birch"
    return birch::Real32(x.get(), handler_);
  } else {
    #line 103 "birch/basic/Real32.birch"
    libbirch_line_(103);
    #line 103 "birch/basic/Real32.birch"
    return libbirch::nil;
  }
}

#line 110 "birch/basic/Real32.birch"
libbirch::Optional<birch::type::Real32> birch::Real32(const libbirch::Optional<birch::type::Integer32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 110 "birch/basic/Real32.birch"
  libbirch_function_("Real32", "birch/basic/Real32.birch", 110);
  #line 111 "birch/basic/Real32.birch"
  libbirch_line_(111);
  #line 111 "birch/basic/Real32.birch"
  if (x.query()) {
    #line 112 "birch/basic/Real32.birch"
    libbirch_line_(112);
    #line 112 "birch/basic/Real32.birch"
    return birch::Real32(x.get(), handler_);
  } else {
    #line 114 "birch/basic/Real32.birch"
    libbirch_line_(114);
    #line 114 "birch/basic/Real32.birch"
    return libbirch::nil;
  }
}

#line 121 "birch/basic/Real32.birch"
libbirch::Optional<birch::type::Real32> birch::Real32(const libbirch::Optional<birch::type::Integer16>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 121 "birch/basic/Real32.birch"
  libbirch_function_("Real32", "birch/basic/Real32.birch", 121);
  #line 122 "birch/basic/Real32.birch"
  libbirch_line_(122);
  #line 122 "birch/basic/Real32.birch"
  if (x.query()) {
    #line 123 "birch/basic/Real32.birch"
    libbirch_line_(123);
    #line 123 "birch/basic/Real32.birch"
    return birch::Real32(x.get(), handler_);
  } else {
    #line 125 "birch/basic/Real32.birch"
    libbirch_line_(125);
    #line 125 "birch/basic/Real32.birch"
    return libbirch::nil;
  }
}

#line 132 "birch/basic/Real32.birch"
libbirch::Optional<birch::type::Real32> birch::Real32(const libbirch::Optional<birch::type::Integer8>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 132 "birch/basic/Real32.birch"
  libbirch_function_("Real32", "birch/basic/Real32.birch", 132);
  #line 133 "birch/basic/Real32.birch"
  libbirch_line_(133);
  #line 133 "birch/basic/Real32.birch"
  if (x.query()) {
    #line 134 "birch/basic/Real32.birch"
    libbirch_line_(134);
    #line 134 "birch/basic/Real32.birch"
    return birch::Real32(x.get(), handler_);
  } else {
    #line 136 "birch/basic/Real32.birch"
    libbirch_line_(136);
    #line 136 "birch/basic/Real32.birch"
    return libbirch::nil;
  }
}

#line 143 "birch/basic/Real32.birch"
libbirch::Optional<birch::type::Real32> birch::Real32(const libbirch::Optional<birch::type::String>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 143 "birch/basic/Real32.birch"
  libbirch_function_("Real32", "birch/basic/Real32.birch", 143);
  #line 144 "birch/basic/Real32.birch"
  libbirch_line_(144);
  #line 144 "birch/basic/Real32.birch"
  if (x.query()) {
    #line 145 "birch/basic/Real32.birch"
    libbirch_line_(145);
    #line 145 "birch/basic/Real32.birch"
    return birch::Real32(x.get(), handler_);
  } else {
    #line 147 "birch/basic/Real32.birch"
    libbirch_line_(147);
    #line 147 "birch/basic/Real32.birch"
    return libbirch::nil;
  }
}

#line 170 "birch/basic/Real32.birch"
birch::type::Real32 birch::abs(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 170 "birch/basic/Real32.birch"
  libbirch_function_("abs", "birch/basic/Real32.birch", 170);
  #line 171 "birch/basic/Real32.birch"
return std::abs(x);
  }

#line 179 "birch/basic/Real32.birch"
birch::type::Real32 birch::pow(const birch::type::Real32& x, const birch::type::Real32& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 179 "birch/basic/Real32.birch"
  libbirch_function_("pow", "birch/basic/Real32.birch", 179);
  #line 180 "birch/basic/Real32.birch"
return ::powf(x, y);
  }

#line 188 "birch/basic/Real32.birch"
birch::type::Real32 birch::mod(const birch::type::Real32& x, const birch::type::Real32& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 188 "birch/basic/Real32.birch"
  libbirch_function_("mod", "birch/basic/Real32.birch", 188);
  #line 189 "birch/basic/Real32.birch"
return ::fmodf(x, y);
  }

#line 197 "birch/basic/Real32.birch"
birch::type::Real32 birch::max(const birch::type::Real32& x, const birch::type::Real32& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 197 "birch/basic/Real32.birch"
  libbirch_function_("max", "birch/basic/Real32.birch", 197);
  #line 198 "birch/basic/Real32.birch"
return std::max(x, y);
  }

#line 206 "birch/basic/Real32.birch"
birch::type::Real32 birch::min(const birch::type::Real32& x, const birch::type::Real32& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 206 "birch/basic/Real32.birch"
  libbirch_function_("min", "birch/basic/Real32.birch", 206);
  #line 207 "birch/basic/Real32.birch"
return std::min(x, y);
  }

#line 215 "birch/basic/Real32.birch"
birch::type::Boolean birch::isinf(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 215 "birch/basic/Real32.birch"
  libbirch_function_("isinf", "birch/basic/Real32.birch", 215);
  #line 216 "birch/basic/Real32.birch"
return std::isinf(x);
  }

#line 224 "birch/basic/Real32.birch"
birch::type::Boolean birch::isnan(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 224 "birch/basic/Real32.birch"
  libbirch_function_("isnan", "birch/basic/Real32.birch", 224);
  #line 225 "birch/basic/Real32.birch"
return std::isnan(x);
  }

#line 233 "birch/basic/Real32.birch"
birch::type::Boolean birch::isfinite(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 233 "birch/basic/Real32.birch"
  libbirch_function_("isfinite", "birch/basic/Real32.birch", 233);
  #line 234 "birch/basic/Real32.birch"
return std::isfinite(x);
  }

#line 9 "birch/basic/Real64.birch"
birch::type::Real64 birch::Real64(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "birch/basic/Real64.birch"
  libbirch_function_("Real64", "birch/basic/Real64.birch", 9);
  #line 10 "birch/basic/Real64.birch"
  libbirch_line_(10);
  #line 10 "birch/basic/Real64.birch"
  return x;
}

#line 16 "birch/basic/Real64.birch"
birch::type::Real64 birch::Real64(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "birch/basic/Real64.birch"
  libbirch_function_("Real64", "birch/basic/Real64.birch", 16);
  #line 17 "birch/basic/Real64.birch"
return static_cast<birch::type::Real64>(x);
  }

#line 25 "birch/basic/Real64.birch"
birch::type::Real64 birch::Real64(const birch::type::Integer64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 25 "birch/basic/Real64.birch"
  libbirch_function_("Real64", "birch/basic/Real64.birch", 25);
  #line 26 "birch/basic/Real64.birch"
return static_cast<birch::type::Real64>(x);
  }

#line 34 "birch/basic/Real64.birch"
birch::type::Real64 birch::Real64(const birch::type::Integer32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 34 "birch/basic/Real64.birch"
  libbirch_function_("Real64", "birch/basic/Real64.birch", 34);
  #line 35 "birch/basic/Real64.birch"
return static_cast<birch::type::Real64>(x);
  }

#line 43 "birch/basic/Real64.birch"
birch::type::Real64 birch::Real64(const birch::type::Integer16& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 43 "birch/basic/Real64.birch"
  libbirch_function_("Real64", "birch/basic/Real64.birch", 43);
  #line 44 "birch/basic/Real64.birch"
return static_cast<birch::type::Real64>(x);
  }

#line 52 "birch/basic/Real64.birch"
birch::type::Real64 birch::Real64(const birch::type::Integer8& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 52 "birch/basic/Real64.birch"
  libbirch_function_("Real64", "birch/basic/Real64.birch", 52);
  #line 53 "birch/basic/Real64.birch"
return static_cast<birch::type::Real64>(x);
  }

#line 61 "birch/basic/Real64.birch"
birch::type::Real64 birch::Real64(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 61 "birch/basic/Real64.birch"
  libbirch_function_("Real64", "birch/basic/Real64.birch", 61);
  #line 62 "birch/basic/Real64.birch"
  libbirch_line_(62);
  #line 62 "birch/basic/Real64.birch"
  if (x) {
    #line 63 "birch/basic/Real64.birch"
    libbirch_line_(63);
    #line 63 "birch/basic/Real64.birch"
    return birch::Real64(1.0, handler_);
  } else {
    #line 65 "birch/basic/Real64.birch"
    libbirch_line_(65);
    #line 65 "birch/basic/Real64.birch"
    return birch::Real64(0.0, handler_);
  }
}

#line 72 "birch/basic/Real64.birch"
birch::type::Real64 birch::Real64(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 72 "birch/basic/Real64.birch"
  libbirch_function_("Real64", "birch/basic/Real64.birch", 72);
  #line 73 "birch/basic/Real64.birch"
return ::strtod(x.c_str(), nullptr);
  }

#line 81 "birch/basic/Real64.birch"
libbirch::Optional<birch::type::Real64> birch::Real64(const libbirch::Optional<birch::type::Real64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "birch/basic/Real64.birch"
  libbirch_function_("Real64", "birch/basic/Real64.birch", 81);
  #line 82 "birch/basic/Real64.birch"
  libbirch_line_(82);
  #line 82 "birch/basic/Real64.birch"
  return x;
}

#line 88 "birch/basic/Real64.birch"
libbirch::Optional<birch::type::Real64> birch::Real64(const libbirch::Optional<birch::type::Real32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 88 "birch/basic/Real64.birch"
  libbirch_function_("Real64", "birch/basic/Real64.birch", 88);
  #line 89 "birch/basic/Real64.birch"
  libbirch_line_(89);
  #line 89 "birch/basic/Real64.birch"
  if (x.query()) {
    #line 90 "birch/basic/Real64.birch"
    libbirch_line_(90);
    #line 90 "birch/basic/Real64.birch"
    return birch::Real64(x.get(), handler_);
  } else {
    #line 92 "birch/basic/Real64.birch"
    libbirch_line_(92);
    #line 92 "birch/basic/Real64.birch"
    return libbirch::nil;
  }
}

#line 99 "birch/basic/Real64.birch"
libbirch::Optional<birch::type::Real64> birch::Real64(const libbirch::Optional<birch::type::Integer64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 99 "birch/basic/Real64.birch"
  libbirch_function_("Real64", "birch/basic/Real64.birch", 99);
  #line 100 "birch/basic/Real64.birch"
  libbirch_line_(100);
  #line 100 "birch/basic/Real64.birch"
  if (x.query()) {
    #line 101 "birch/basic/Real64.birch"
    libbirch_line_(101);
    #line 101 "birch/basic/Real64.birch"
    return birch::Real64(x.get(), handler_);
  } else {
    #line 103 "birch/basic/Real64.birch"
    libbirch_line_(103);
    #line 103 "birch/basic/Real64.birch"
    return libbirch::nil;
  }
}

#line 110 "birch/basic/Real64.birch"
libbirch::Optional<birch::type::Real64> birch::Real64(const libbirch::Optional<birch::type::Integer32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 110 "birch/basic/Real64.birch"
  libbirch_function_("Real64", "birch/basic/Real64.birch", 110);
  #line 111 "birch/basic/Real64.birch"
  libbirch_line_(111);
  #line 111 "birch/basic/Real64.birch"
  if (x.query()) {
    #line 112 "birch/basic/Real64.birch"
    libbirch_line_(112);
    #line 112 "birch/basic/Real64.birch"
    return birch::Real64(x.get(), handler_);
  } else {
    #line 114 "birch/basic/Real64.birch"
    libbirch_line_(114);
    #line 114 "birch/basic/Real64.birch"
    return libbirch::nil;
  }
}

#line 121 "birch/basic/Real64.birch"
libbirch::Optional<birch::type::Real64> birch::Real64(const libbirch::Optional<birch::type::Integer16>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 121 "birch/basic/Real64.birch"
  libbirch_function_("Real64", "birch/basic/Real64.birch", 121);
  #line 122 "birch/basic/Real64.birch"
  libbirch_line_(122);
  #line 122 "birch/basic/Real64.birch"
  if (x.query()) {
    #line 123 "birch/basic/Real64.birch"
    libbirch_line_(123);
    #line 123 "birch/basic/Real64.birch"
    return birch::Real64(x.get(), handler_);
  } else {
    #line 125 "birch/basic/Real64.birch"
    libbirch_line_(125);
    #line 125 "birch/basic/Real64.birch"
    return libbirch::nil;
  }
}

#line 132 "birch/basic/Real64.birch"
libbirch::Optional<birch::type::Real64> birch::Real64(const libbirch::Optional<birch::type::Integer8>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 132 "birch/basic/Real64.birch"
  libbirch_function_("Real64", "birch/basic/Real64.birch", 132);
  #line 133 "birch/basic/Real64.birch"
  libbirch_line_(133);
  #line 133 "birch/basic/Real64.birch"
  if (x.query()) {
    #line 134 "birch/basic/Real64.birch"
    libbirch_line_(134);
    #line 134 "birch/basic/Real64.birch"
    return birch::Real64(x.get(), handler_);
  } else {
    #line 136 "birch/basic/Real64.birch"
    libbirch_line_(136);
    #line 136 "birch/basic/Real64.birch"
    return libbirch::nil;
  }
}

#line 143 "birch/basic/Real64.birch"
libbirch::Optional<birch::type::Real64> birch::Real64(const libbirch::Optional<birch::type::String>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 143 "birch/basic/Real64.birch"
  libbirch_function_("Real64", "birch/basic/Real64.birch", 143);
  #line 144 "birch/basic/Real64.birch"
  libbirch_line_(144);
  #line 144 "birch/basic/Real64.birch"
  if (x.query()) {
    #line 145 "birch/basic/Real64.birch"
    libbirch_line_(145);
    #line 145 "birch/basic/Real64.birch"
    return birch::Real64(x.get(), handler_);
  } else {
    #line 147 "birch/basic/Real64.birch"
    libbirch_line_(147);
    #line 147 "birch/basic/Real64.birch"
    return libbirch::nil;
  }
}

#line 170 "birch/basic/Real64.birch"
birch::type::Real64 birch::abs(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 170 "birch/basic/Real64.birch"
  libbirch_function_("abs", "birch/basic/Real64.birch", 170);
  #line 171 "birch/basic/Real64.birch"
return std::abs(x);
  }

#line 179 "birch/basic/Real64.birch"
birch::type::Real64 birch::pow(const birch::type::Real64& x, const birch::type::Real64& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 179 "birch/basic/Real64.birch"
  libbirch_function_("pow", "birch/basic/Real64.birch", 179);
  #line 180 "birch/basic/Real64.birch"
return ::pow(x, y);
  }

#line 188 "birch/basic/Real64.birch"
birch::type::Real64 birch::mod(const birch::type::Real64& x, const birch::type::Real64& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 188 "birch/basic/Real64.birch"
  libbirch_function_("mod", "birch/basic/Real64.birch", 188);
  #line 189 "birch/basic/Real64.birch"
return ::fmod(x, y);
  }

#line 197 "birch/basic/Real64.birch"
birch::type::Real64 birch::max(const birch::type::Real64& x, const birch::type::Real64& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 197 "birch/basic/Real64.birch"
  libbirch_function_("max", "birch/basic/Real64.birch", 197);
  #line 198 "birch/basic/Real64.birch"
return std::max(x, y);
  }

#line 206 "birch/basic/Real64.birch"
birch::type::Real64 birch::min(const birch::type::Real64& x, const birch::type::Real64& y, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 206 "birch/basic/Real64.birch"
  libbirch_function_("min", "birch/basic/Real64.birch", 206);
  #line 207 "birch/basic/Real64.birch"
return std::min(x, y);
  }

#line 215 "birch/basic/Real64.birch"
birch::type::Boolean birch::isinf(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 215 "birch/basic/Real64.birch"
  libbirch_function_("isinf", "birch/basic/Real64.birch", 215);
  #line 216 "birch/basic/Real64.birch"
return std::isinf(x);
  }

#line 224 "birch/basic/Real64.birch"
birch::type::Boolean birch::isnan(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 224 "birch/basic/Real64.birch"
  libbirch_function_("isnan", "birch/basic/Real64.birch", 224);
  #line 225 "birch/basic/Real64.birch"
return std::isnan(x);
  }

#line 233 "birch/basic/Real64.birch"
birch::type::Boolean birch::isfinite(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 233 "birch/basic/Real64.birch"
  libbirch_function_("isfinite", "birch/basic/Real64.birch", 233);
  #line 234 "birch/basic/Real64.birch"
return std::isfinite(x);
  }

#line 9 "birch/basic/String.birch"
birch::type::String birch::String(const birch::type::Boolean& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 9 "birch/basic/String.birch"
  libbirch_function_("String", "birch/basic/String.birch", 9);
  #line 10 "birch/basic/String.birch"
  libbirch_line_(10);
  #line 10 "birch/basic/String.birch"
  if (x) {
    #line 11 "birch/basic/String.birch"
    libbirch_line_(11);
    #line 11 "birch/basic/String.birch"
    return birch::type::String("true");
  } else {
    #line 13 "birch/basic/String.birch"
    libbirch_line_(13);
    #line 13 "birch/basic/String.birch"
    return birch::type::String("false");
  }
}

#line 20 "birch/basic/String.birch"
birch::type::String birch::String(const birch::type::Real64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 20 "birch/basic/String.birch"
  libbirch_function_("String", "birch/basic/String.birch", 20);
  #line 21 "birch/basic/String.birch"
std::stringstream buf;
  if (x == floor(x)) {
    buf << (int64_t)x << ".0";
  } else {
    buf << std::scientific << std::setprecision(14) << x;
  }
  return buf.str();
  }

#line 35 "birch/basic/String.birch"
birch::type::String birch::String(const birch::type::Real32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 35 "birch/basic/String.birch"
  libbirch_function_("String", "birch/basic/String.birch", 35);
  #line 36 "birch/basic/String.birch"
std::stringstream buf;
  if (x == floor(x)) {
    buf << (int64_t)x << ".0";
  } else {
    buf << std::scientific << std::setprecision(6) << x;
  }
  return buf.str();
  }

#line 50 "birch/basic/String.birch"
birch::type::String birch::String(const birch::type::Integer64& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "birch/basic/String.birch"
  libbirch_function_("String", "birch/basic/String.birch", 50);
  #line 51 "birch/basic/String.birch"
return std::to_string(x);
  }

#line 59 "birch/basic/String.birch"
birch::type::String birch::String(const birch::type::Integer32& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 59 "birch/basic/String.birch"
  libbirch_function_("String", "birch/basic/String.birch", 59);
  #line 60 "birch/basic/String.birch"
return std::to_string(x);
  }

#line 68 "birch/basic/String.birch"
birch::type::String birch::String(const birch::type::Integer16& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 68 "birch/basic/String.birch"
  libbirch_function_("String", "birch/basic/String.birch", 68);
  #line 69 "birch/basic/String.birch"
return std::to_string(x);
  }

#line 77 "birch/basic/String.birch"
birch::type::String birch::String(const birch::type::Integer8& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 77 "birch/basic/String.birch"
  libbirch_function_("String", "birch/basic/String.birch", 77);
  #line 78 "birch/basic/String.birch"
return std::to_string(x);
  }

#line 86 "birch/basic/String.birch"
birch::type::String birch::String(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 86 "birch/basic/String.birch"
  libbirch_function_("String", "birch/basic/String.birch", 86);
  #line 87 "birch/basic/String.birch"
  libbirch_line_(87);
  #line 87 "birch/basic/String.birch"
  return x;
}

#line 93 "birch/basic/String.birch"
libbirch::Optional<birch::type::String> birch::String(const libbirch::Optional<birch::type::Boolean>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 93 "birch/basic/String.birch"
  libbirch_function_("String", "birch/basic/String.birch", 93);
  #line 94 "birch/basic/String.birch"
  libbirch_line_(94);
  #line 94 "birch/basic/String.birch"
  if (x.query()) {
    #line 95 "birch/basic/String.birch"
    libbirch_line_(95);
    #line 95 "birch/basic/String.birch"
    return birch::String(x.get(), handler_);
  } else {
    #line 97 "birch/basic/String.birch"
    libbirch_line_(97);
    #line 97 "birch/basic/String.birch"
    return libbirch::nil;
  }
}

#line 104 "birch/basic/String.birch"
libbirch::Optional<birch::type::String> birch::String(const libbirch::Optional<birch::type::Real64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 104 "birch/basic/String.birch"
  libbirch_function_("String", "birch/basic/String.birch", 104);
  #line 105 "birch/basic/String.birch"
  libbirch_line_(105);
  #line 105 "birch/basic/String.birch"
  if (x.query()) {
    #line 106 "birch/basic/String.birch"
    libbirch_line_(106);
    #line 106 "birch/basic/String.birch"
    return birch::String(x.get(), handler_);
  } else {
    #line 108 "birch/basic/String.birch"
    libbirch_line_(108);
    #line 108 "birch/basic/String.birch"
    return libbirch::nil;
  }
}

#line 115 "birch/basic/String.birch"
libbirch::Optional<birch::type::String> birch::String(const libbirch::Optional<birch::type::Real32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 115 "birch/basic/String.birch"
  libbirch_function_("String", "birch/basic/String.birch", 115);
  #line 116 "birch/basic/String.birch"
  libbirch_line_(116);
  #line 116 "birch/basic/String.birch"
  if (x.query()) {
    #line 117 "birch/basic/String.birch"
    libbirch_line_(117);
    #line 117 "birch/basic/String.birch"
    return birch::String(x.get(), handler_);
  } else {
    #line 119 "birch/basic/String.birch"
    libbirch_line_(119);
    #line 119 "birch/basic/String.birch"
    return libbirch::nil;
  }
}

#line 126 "birch/basic/String.birch"
libbirch::Optional<birch::type::String> birch::String(const libbirch::Optional<birch::type::Integer64>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 126 "birch/basic/String.birch"
  libbirch_function_("String", "birch/basic/String.birch", 126);
  #line 127 "birch/basic/String.birch"
  libbirch_line_(127);
  #line 127 "birch/basic/String.birch"
  if (x.query()) {
    #line 128 "birch/basic/String.birch"
    libbirch_line_(128);
    #line 128 "birch/basic/String.birch"
    return birch::String(x.get(), handler_);
  } else {
    #line 130 "birch/basic/String.birch"
    libbirch_line_(130);
    #line 130 "birch/basic/String.birch"
    return libbirch::nil;
  }
}

#line 137 "birch/basic/String.birch"
libbirch::Optional<birch::type::String> birch::String(const libbirch::Optional<birch::type::Integer32>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 137 "birch/basic/String.birch"
  libbirch_function_("String", "birch/basic/String.birch", 137);
  #line 138 "birch/basic/String.birch"
  libbirch_line_(138);
  #line 138 "birch/basic/String.birch"
  if (x.query()) {
    #line 139 "birch/basic/String.birch"
    libbirch_line_(139);
    #line 139 "birch/basic/String.birch"
    return birch::String(x.get(), handler_);
  } else {
    #line 141 "birch/basic/String.birch"
    libbirch_line_(141);
    #line 141 "birch/basic/String.birch"
    return libbirch::nil;
  }
}

#line 148 "birch/basic/String.birch"
libbirch::Optional<birch::type::String> birch::String(const libbirch::Optional<birch::type::Integer16>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 148 "birch/basic/String.birch"
  libbirch_function_("String", "birch/basic/String.birch", 148);
  #line 149 "birch/basic/String.birch"
  libbirch_line_(149);
  #line 149 "birch/basic/String.birch"
  if (x.query()) {
    #line 150 "birch/basic/String.birch"
    libbirch_line_(150);
    #line 150 "birch/basic/String.birch"
    return birch::String(x.get(), handler_);
  } else {
    #line 152 "birch/basic/String.birch"
    libbirch_line_(152);
    #line 152 "birch/basic/String.birch"
    return libbirch::nil;
  }
}

#line 159 "birch/basic/String.birch"
libbirch::Optional<birch::type::String> birch::String(const libbirch::Optional<birch::type::Integer8>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 159 "birch/basic/String.birch"
  libbirch_function_("String", "birch/basic/String.birch", 159);
  #line 160 "birch/basic/String.birch"
  libbirch_line_(160);
  #line 160 "birch/basic/String.birch"
  if (x.query()) {
    #line 161 "birch/basic/String.birch"
    libbirch_line_(161);
    #line 161 "birch/basic/String.birch"
    return birch::String(x.get(), handler_);
  } else {
    #line 163 "birch/basic/String.birch"
    libbirch_line_(163);
    #line 163 "birch/basic/String.birch"
    return libbirch::nil;
  }
}

#line 170 "birch/basic/String.birch"
libbirch::Optional<birch::type::String> birch::String(const libbirch::Optional<birch::type::String>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 170 "birch/basic/String.birch"
  libbirch_function_("String", "birch/basic/String.birch", 170);
  #line 171 "birch/basic/String.birch"
  libbirch_line_(171);
  #line 171 "birch/basic/String.birch"
  return x;
}

#line 177 "birch/basic/String.birch"
birch::type::Boolean birch::operator>(const birch::type::String& x, const birch::type::String& y) {
  #line 177 "birch/basic/String.birch"
  libbirch_function_(">", "birch/basic/String.birch", 177);
  #line 178 "birch/basic/String.birch"
return x.compare(y) > 0;
  }

#line 186 "birch/basic/String.birch"
birch::type::Boolean birch::operator<(const birch::type::String& x, const birch::type::String& y) {
  #line 186 "birch/basic/String.birch"
  libbirch_function_("<", "birch/basic/String.birch", 186);
  #line 187 "birch/basic/String.birch"
return x.compare(y) < 0;
  }

#line 195 "birch/basic/String.birch"
birch::type::Boolean birch::operator>=(const birch::type::String& x, const birch::type::String& y) {
  #line 195 "birch/basic/String.birch"
  libbirch_function_(">=", "birch/basic/String.birch", 195);
  #line 196 "birch/basic/String.birch"
return x.compare(y) >= 0;
  }

#line 204 "birch/basic/String.birch"
birch::type::Boolean birch::operator<=(const birch::type::String& x, const birch::type::String& y) {
  #line 204 "birch/basic/String.birch"
  libbirch_function_("<=", "birch/basic/String.birch", 204);
  #line 205 "birch/basic/String.birch"
return x.compare(y) <= 0;
  }

#line 213 "birch/basic/String.birch"
birch::type::Boolean birch::operator==(const birch::type::String& x, const birch::type::String& y) {
  #line 213 "birch/basic/String.birch"
  libbirch_function_("==", "birch/basic/String.birch", 213);
  #line 214 "birch/basic/String.birch"
return x.compare(y) == 0;
  }

#line 222 "birch/basic/String.birch"
birch::type::Boolean birch::operator!=(const birch::type::String& x, const birch::type::String& y) {
  #line 222 "birch/basic/String.birch"
  libbirch_function_("!=", "birch/basic/String.birch", 222);
  #line 223 "birch/basic/String.birch"
return x.compare(y) != 0;
  }

#line 236 "birch/basic/String.birch"
birch::type::String birch::operator+(const birch::type::String& x, const birch::type::Boolean& y) {
  #line 236 "birch/basic/String.birch"
  libbirch_function_("+", "birch/basic/String.birch", 236);
  #line 237 "birch/basic/String.birch"
  libbirch_line_(237);
  #line 237 "birch/basic/String.birch"
  return x + birch::String(y);
}

#line 243 "birch/basic/String.birch"
birch::type::String birch::operator+(const birch::type::String& x, const birch::type::Real& y) {
  #line 243 "birch/basic/String.birch"
  libbirch_function_("+", "birch/basic/String.birch", 243);
  #line 244 "birch/basic/String.birch"
  libbirch_line_(244);
  #line 244 "birch/basic/String.birch"
  return x + birch::String(y);
}

#line 250 "birch/basic/String.birch"
birch::type::String birch::operator+(const birch::type::String& x, const birch::type::Integer& y) {
  #line 250 "birch/basic/String.birch"
  libbirch_function_("+", "birch/basic/String.birch", 250);
  #line 251 "birch/basic/String.birch"
  libbirch_line_(251);
  #line 251 "birch/basic/String.birch"
  return x + birch::String(y);
}

#line 257 "birch/basic/String.birch"
birch::type::String birch::operator+(const birch::type::String& x, const libbirch::DefaultArray<birch::type::Boolean,1>& y) {
  #line 257 "birch/basic/String.birch"
  libbirch_function_("+", "birch/basic/String.birch", 257);
  #line 258 "birch/basic/String.birch"
  libbirch_line_(258);
  #line 258 "birch/basic/String.birch"
  return x + birch::String(y);
}

#line 264 "birch/basic/String.birch"
birch::type::String birch::operator+(const birch::type::String& x, const libbirch::DefaultArray<birch::type::Real,1>& y) {
  #line 264 "birch/basic/String.birch"
  libbirch_function_("+", "birch/basic/String.birch", 264);
  #line 265 "birch/basic/String.birch"
  libbirch_line_(265);
  #line 265 "birch/basic/String.birch"
  return x + birch::String(y);
}

#line 271 "birch/basic/String.birch"
birch::type::String birch::operator+(const birch::type::String& x, const libbirch::DefaultArray<birch::type::Integer,1>& y) {
  #line 271 "birch/basic/String.birch"
  libbirch_function_("+", "birch/basic/String.birch", 271);
  #line 272 "birch/basic/String.birch"
  libbirch_line_(272);
  #line 272 "birch/basic/String.birch"
  return x + birch::String(y);
}

#line 278 "birch/basic/String.birch"
birch::type::String birch::operator+(const birch::type::String& x, const libbirch::DefaultArray<birch::type::Boolean,2>& y) {
  #line 278 "birch/basic/String.birch"
  libbirch_function_("+", "birch/basic/String.birch", 278);
  #line 279 "birch/basic/String.birch"
  libbirch_line_(279);
  #line 279 "birch/basic/String.birch"
  return x + birch::String(y);
}

#line 285 "birch/basic/String.birch"
birch::type::String birch::operator+(const birch::type::String& x, const libbirch::DefaultArray<birch::type::Real,2>& y) {
  #line 285 "birch/basic/String.birch"
  libbirch_function_("+", "birch/basic/String.birch", 285);
  #line 286 "birch/basic/String.birch"
  libbirch_line_(286);
  #line 286 "birch/basic/String.birch"
  return x + birch::String(y);
}

#line 292 "birch/basic/String.birch"
birch::type::String birch::operator+(const birch::type::String& x, const libbirch::DefaultArray<birch::type::Integer,2>& y) {
  #line 292 "birch/basic/String.birch"
  libbirch_function_("+", "birch/basic/String.birch", 292);
  #line 293 "birch/basic/String.birch"
  libbirch_line_(293);
  #line 293 "birch/basic/String.birch"
  return x + birch::String(y);
}

#line 299 "birch/basic/String.birch"
birch::type::String birch::operator+(const birch::type::Boolean& x, const birch::type::String& y) {
  #line 299 "birch/basic/String.birch"
  libbirch_function_("+", "birch/basic/String.birch", 299);
  #line 300 "birch/basic/String.birch"
  libbirch_line_(300);
  #line 300 "birch/basic/String.birch"
  return birch::String(x) + y;
}

#line 306 "birch/basic/String.birch"
birch::type::String birch::operator+(const birch::type::Real& x, const birch::type::String& y) {
  #line 306 "birch/basic/String.birch"
  libbirch_function_("+", "birch/basic/String.birch", 306);
  #line 307 "birch/basic/String.birch"
  libbirch_line_(307);
  #line 307 "birch/basic/String.birch"
  return birch::String(x) + y;
}

#line 313 "birch/basic/String.birch"
birch::type::String birch::operator+(const birch::type::Integer& x, const birch::type::String& y) {
  #line 313 "birch/basic/String.birch"
  libbirch_function_("+", "birch/basic/String.birch", 313);
  #line 314 "birch/basic/String.birch"
  libbirch_line_(314);
  #line 314 "birch/basic/String.birch"
  return birch::String(x) + y;
}

#line 320 "birch/basic/String.birch"
birch::type::String birch::operator+(const libbirch::DefaultArray<birch::type::Boolean,1>& x, const birch::type::String& y) {
  #line 320 "birch/basic/String.birch"
  libbirch_function_("+", "birch/basic/String.birch", 320);
  #line 321 "birch/basic/String.birch"
  libbirch_line_(321);
  #line 321 "birch/basic/String.birch"
  return birch::String(x) + y;
}

#line 327 "birch/basic/String.birch"
birch::type::String birch::operator+(const libbirch::DefaultArray<birch::type::Real,1>& x, const birch::type::String& y) {
  #line 327 "birch/basic/String.birch"
  libbirch_function_("+", "birch/basic/String.birch", 327);
  #line 328 "birch/basic/String.birch"
  libbirch_line_(328);
  #line 328 "birch/basic/String.birch"
  return birch::String(x) + y;
}

#line 334 "birch/basic/String.birch"
birch::type::String birch::operator+(const libbirch::DefaultArray<birch::type::Integer,1>& x, const birch::type::String& y) {
  #line 334 "birch/basic/String.birch"
  libbirch_function_("+", "birch/basic/String.birch", 334);
  #line 335 "birch/basic/String.birch"
  libbirch_line_(335);
  #line 335 "birch/basic/String.birch"
  return birch::String(x) + y;
}

#line 341 "birch/basic/String.birch"
birch::type::String birch::operator+(const libbirch::DefaultArray<birch::type::Boolean,2>& x, const birch::type::String& y) {
  #line 341 "birch/basic/String.birch"
  libbirch_function_("+", "birch/basic/String.birch", 341);
  #line 342 "birch/basic/String.birch"
  libbirch_line_(342);
  #line 342 "birch/basic/String.birch"
  return birch::String(x) + y;
}

#line 348 "birch/basic/String.birch"
birch::type::String birch::operator+(const libbirch::DefaultArray<birch::type::Real,2>& x, const birch::type::String& y) {
  #line 348 "birch/basic/String.birch"
  libbirch_function_("+", "birch/basic/String.birch", 348);
  #line 349 "birch/basic/String.birch"
  libbirch_line_(349);
  #line 349 "birch/basic/String.birch"
  return birch::String(x) + y;
}

#line 355 "birch/basic/String.birch"
birch::type::String birch::operator+(const libbirch::DefaultArray<birch::type::Integer,2>& x, const birch::type::String& y) {
  #line 355 "birch/basic/String.birch"
  libbirch_function_("+", "birch/basic/String.birch", 355);
  #line 356 "birch/basic/String.birch"
  libbirch_line_(356);
  #line 356 "birch/basic/String.birch"
  return birch::String(x) + y;
}

#line 362 "birch/basic/String.birch"
birch::type::Integer birch::length(const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 362 "birch/basic/String.birch"
  libbirch_function_("length", "birch/basic/String.birch", 362);
  #line 363 "birch/basic/String.birch"
return x.length();
  }

#line 371 "birch/basic/String.birch"
birch::type::Integer birch::length(const libbirch::DefaultArray<birch::type::String,1>& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 371 "birch/basic/String.birch"
  libbirch_function_("length", "birch/basic/String.birch", 371);
  #line 372 "birch/basic/String.birch"
return x.rows();
  }

