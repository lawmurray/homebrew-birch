#line 1 "birch/filter/AliveParticleFilter.birch"
birch::type::AliveParticleFilter::AliveParticleFilter(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/filter/AliveParticleFilter.birch"
    super_type_(),
    #line 22 "birch/filter/AliveParticleFilter.birch"
    p() {
  //
}

#line 24 "birch/filter/AliveParticleFilter.birch"
void birch::type::AliveParticleFilter::propagate(const birch::type::Integer& t, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 24 "birch/filter/AliveParticleFilter.birch"
  libbirch_function_("propagate", "birch/filter/AliveParticleFilter.birch", 24);
  #line 25 "birch/filter/AliveParticleFilter.birch"
  libbirch_line_(25);
  #line 25 "birch/filter/AliveParticleFilter.birch"
  auto play = birch::PlayHandler(this_()->delayed, handler_);
  #line 26 "birch/filter/AliveParticleFilter.birch"
  libbirch_line_(26);
  #line 26 "birch/filter/AliveParticleFilter.birch"
  auto x0 = this_()->x;
  #line 27 "birch/filter/AliveParticleFilter.birch"
  libbirch_line_(27);
  #line 27 "birch/filter/AliveParticleFilter.birch"
  auto w0 = this_()->w;
  #line 28 "birch/filter/AliveParticleFilter.birch"
  libbirch_line_(28);
  #line 28 "birch/filter/AliveParticleFilter.birch"
  this_()->p = birch::vector(birch::type::Integer(0), this_()->nparticles + birch::type::Integer(1), handler_);
  #line 29 "birch/filter/AliveParticleFilter.birch"
  libbirch_line_(29);
  #line 29 "birch/filter/AliveParticleFilter.birch"
  #pragma omp parallel
  {
    #line 29 "birch/filter/AliveParticleFilter.birch"
    libbirch_function_("<parallel for>", "birch/filter/AliveParticleFilter.birch", 29);
    #pragma omp for schedule(static)
    for (auto n = birch::type::Integer(1); n <= this_()->nparticles + birch::type::Integer(1); ++n) {
      #line 30 "birch/filter/AliveParticleFilter.birch"
      libbirch_line_(30);
      #line 30 "birch/filter/AliveParticleFilter.birch"
      if (n <= this_()->nparticles) {
        #line 31 "birch/filter/AliveParticleFilter.birch"
        libbirch_line_(31);
        #line 31 "birch/filter/AliveParticleFilter.birch"
        this_()->x.set(libbirch::make_slice(n - 1), birch::clone(x0.get(libbirch::make_slice(this_()->a.get(libbirch::make_slice(n - 1)) - 1)), handler_));
        #line 32 "birch/filter/AliveParticleFilter.birch"
        libbirch_line_(32);
        #line 32 "birch/filter/AliveParticleFilter.birch"
        auto handler = birch::PlayHandler(this_()->delayed, handler_);
        #line 33 "birch/filter/AliveParticleFilter.birch"
        libbirch_line_(33);
        #line 33 "birch/filter/AliveParticleFilter.birch"
        {
          auto handler_ = (handler);
          #line 34 "birch/filter/AliveParticleFilter.birch"
          libbirch_line_(34);
          #line 34 "birch/filter/AliveParticleFilter.birch"
          this_()->x.get(libbirch::make_slice(n - 1))->m->simulate(t, handler_);
          #line 35 "birch/filter/AliveParticleFilter.birch"
          libbirch_line_(35);
          #line 35 "birch/filter/AliveParticleFilter.birch"
          this_()->w.set(libbirch::make_slice(n - 1), handler->w);
        }
        #line 37 "birch/filter/AliveParticleFilter.birch"
        libbirch_line_(37);
        #line 37 "birch/filter/AliveParticleFilter.birch"
        this_()->p.set(libbirch::make_slice(n - 1), birch::type::Integer(1));
        #line 38 "birch/filter/AliveParticleFilter.birch"
        libbirch_line_(38);
        #line 38 "birch/filter/AliveParticleFilter.birch"
        while (this_()->w.get(libbirch::make_slice(n - 1)) == -birch::inf()) {
          #line 39 "birch/filter/AliveParticleFilter.birch"
          libbirch_line_(39);
          #line 39 "birch/filter/AliveParticleFilter.birch"
          this_()->a.set(libbirch::make_slice(n - 1), birch::ancestor(w0, handler_));
          #line 40 "birch/filter/AliveParticleFilter.birch"
          libbirch_line_(40);
          #line 40 "birch/filter/AliveParticleFilter.birch"
          this_()->x.set(libbirch::make_slice(n - 1), birch::clone(x0.get(libbirch::make_slice(this_()->a.get(libbirch::make_slice(n - 1)) - 1)), handler_));
          #line 41 "birch/filter/AliveParticleFilter.birch"
          libbirch_line_(41);
          #line 41 "birch/filter/AliveParticleFilter.birch"
          this_()->p.set(libbirch::make_slice(n - 1), this_()->p.get(libbirch::make_slice(n - 1)) + birch::type::Integer(1));
          #line 42 "birch/filter/AliveParticleFilter.birch"
          libbirch_line_(42);
          #line 42 "birch/filter/AliveParticleFilter.birch"
          auto handler = birch::PlayHandler(this_()->delayed, handler_);
          #line 43 "birch/filter/AliveParticleFilter.birch"
          libbirch_line_(43);
          #line 43 "birch/filter/AliveParticleFilter.birch"
          {
            auto handler_ = (handler);
            #line 44 "birch/filter/AliveParticleFilter.birch"
            libbirch_line_(44);
            #line 44 "birch/filter/AliveParticleFilter.birch"
            this_()->x.get(libbirch::make_slice(n - 1))->m->simulate(t, handler_);
            #line 45 "birch/filter/AliveParticleFilter.birch"
            libbirch_line_(45);
            #line 45 "birch/filter/AliveParticleFilter.birch"
            this_()->w.set(libbirch::make_slice(n - 1), handler->w);
          }
        }
      } else {
        #line 52 "birch/filter/AliveParticleFilter.birch"
        libbirch_line_(52);
        #line 52 "birch/filter/AliveParticleFilter.birch"
        auto w_prime_ = 0.0;
        #line 53 "birch/filter/AliveParticleFilter.birch"
        libbirch_line_(53);
        #line 53 "birch/filter/AliveParticleFilter.birch"
        this_()->p.set(libbirch::make_slice(n - 1), birch::type::Integer(0));
        #line 54 "birch/filter/AliveParticleFilter.birch"
        libbirch_line_(54);
        #line 54 "birch/filter/AliveParticleFilter.birch"
        do {
          #line 55 "birch/filter/AliveParticleFilter.birch"
          libbirch_line_(55);
          #line 55 "birch/filter/AliveParticleFilter.birch"
          auto a_prime_ = birch::ancestor(w0, handler_);
          #line 56 "birch/filter/AliveParticleFilter.birch"
          libbirch_line_(56);
          #line 56 "birch/filter/AliveParticleFilter.birch"
          auto x_prime_ = birch::clone(x0.get(libbirch::make_slice(a_prime_ - 1)), handler_);
          #line 57 "birch/filter/AliveParticleFilter.birch"
          libbirch_line_(57);
          #line 57 "birch/filter/AliveParticleFilter.birch"
          this_()->p.set(libbirch::make_slice(n - 1), this_()->p.get(libbirch::make_slice(n - 1)) + birch::type::Integer(1));
          #line 58 "birch/filter/AliveParticleFilter.birch"
          libbirch_line_(58);
          #line 58 "birch/filter/AliveParticleFilter.birch"
          auto handler = birch::PlayHandler(this_()->delayed, handler_);
          #line 59 "birch/filter/AliveParticleFilter.birch"
          libbirch_line_(59);
          #line 59 "birch/filter/AliveParticleFilter.birch"
          {
            auto handler_ = (handler);
            #line 60 "birch/filter/AliveParticleFilter.birch"
            libbirch_line_(60);
            #line 60 "birch/filter/AliveParticleFilter.birch"
            x_prime_->m->simulate(t, handler_);
            #line 61 "birch/filter/AliveParticleFilter.birch"
            libbirch_line_(61);
            #line 61 "birch/filter/AliveParticleFilter.birch"
            w_prime_ = handler->w;
          }
        } while (w_prime_ == -birch::inf());
      }
    }
  }
  #line 66 "birch/filter/AliveParticleFilter.birch"
  libbirch_line_(66);
  #line 66 "birch/filter/AliveParticleFilter.birch"
  birch::collect(handler_);
}

#line 69 "birch/filter/AliveParticleFilter.birch"
void birch::type::AliveParticleFilter::resample(const birch::type::Integer& t, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "birch/filter/AliveParticleFilter.birch"
  libbirch_function_("resample", "birch/filter/AliveParticleFilter.birch", 69);
  #line 70 "birch/filter/AliveParticleFilter.birch"
  libbirch_line_(70);
  #line 70 "birch/filter/AliveParticleFilter.birch"
  if (this_()->ess <= this_()->trigger * this_()->nparticles) {
    #line 72 "birch/filter/AliveParticleFilter.birch"
    libbirch_line_(72);
    #line 72 "birch/filter/AliveParticleFilter.birch"
    this_()->a = birch::resample_systematic(this_()->w, handler_);
    #line 73 "birch/filter/AliveParticleFilter.birch"
    libbirch_line_(73);
    #line 73 "birch/filter/AliveParticleFilter.birch"
    this_()->w = birch::vector(0.0, this_()->nparticles, handler_);
  } else {
    #line 76 "birch/filter/AliveParticleFilter.birch"
    libbirch_line_(76);
    #line 76 "birch/filter/AliveParticleFilter.birch"
    this_()->w = this_()->w - birch::vector(this_()->lsum - birch::log(birch::Real(this_()->nparticles, handler_), handler_), this_()->nparticles, handler_);
  }
}

#line 80 "birch/filter/AliveParticleFilter.birch"
void birch::type::AliveParticleFilter::reduce(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 80 "birch/filter/AliveParticleFilter.birch"
  libbirch_function_("reduce", "birch/filter/AliveParticleFilter.birch", 80);
  #line 81 "birch/filter/AliveParticleFilter.birch"
  libbirch_line_(81);
  #line 81 "birch/filter/AliveParticleFilter.birch"
  this_()->super_type_::reduce(handler_);
  #line 82 "birch/filter/AliveParticleFilter.birch"
  libbirch_line_(82);
  #line 82 "birch/filter/AliveParticleFilter.birch"
  this_()->npropagations = birch::sum(this_()->p, handler_);
}

#line 1 "birch/filter/AliveParticleFilter.birch"
birch::type::AliveParticleFilter* birch::type::make_AliveParticleFilter_() {
  #line 1 "birch/filter/AliveParticleFilter.birch"
  return new birch::type::AliveParticleFilter();
  #line 1 "birch/filter/AliveParticleFilter.birch"
}

#line 1 "birch/filter/ConditionalParticleFilter.birch"
birch::type::ConditionalParticleFilter::ConditionalParticleFilter(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/filter/ConditionalParticleFilter.birch"
    super_type_(),
    #line 22 "birch/filter/ConditionalParticleFilter.birch"
    r(),
    #line 30 "birch/filter/ConditionalParticleFilter.birch"
    b(birch::type::Integer(0)),
    #line 35 "birch/filter/ConditionalParticleFilter.birch"
    ancestor(false),
    #line 42 "birch/filter/ConditionalParticleFilter.birch"
    alreadyInitialized(false) {
  //
}

#line 44 "birch/filter/ConditionalParticleFilter.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Particle>> birch::type::ConditionalParticleFilter::particle(const libbirch::Lazy<libbirch::Shared<birch::type::Model>>& archetype, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 44 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_function_("particle", "birch/filter/ConditionalParticleFilter.birch", 44);
  #line 45 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_line_(45);
  #line 45 "birch/filter/ConditionalParticleFilter.birch"
  return birch::ConditionalParticle(archetype, handler_);
}

#line 48 "birch/filter/ConditionalParticleFilter.birch"
void birch::type::ConditionalParticleFilter::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Model>>& archetype, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 48 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_function_("initialize", "birch/filter/ConditionalParticleFilter.birch", 48);
  #line 49 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_line_(49);
  #line 49 "birch/filter/ConditionalParticleFilter.birch"
  this_()->super_type_::initialize(archetype, handler_);
  #line 50 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_line_(50);
  #line 50 "birch/filter/ConditionalParticleFilter.birch"
  this_()->b = birch::type::Integer(1);
}

#line 53 "birch/filter/ConditionalParticleFilter.birch"
void birch::type::ConditionalParticleFilter::filter(const birch::type::Integer& t, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_function_("filter", "birch/filter/ConditionalParticleFilter.birch", 53);
  #line 54 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_line_(54);
  #line 54 "birch/filter/ConditionalParticleFilter.birch"
  if (this_()->r.query() && this_()->ancestor) {
    #line 55 "birch/filter/ConditionalParticleFilter.birch"
    libbirch_line_(55);
    #line 55 "birch/filter/ConditionalParticleFilter.birch"
    this_()->ancestorSample(t, handler_);
  }
  #line 57 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_line_(57);
  #line 57 "birch/filter/ConditionalParticleFilter.birch"
  this_()->resample(t, handler_);
  #line 58 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_line_(58);
  #line 58 "birch/filter/ConditionalParticleFilter.birch"
  this_()->propagate(t, handler_);
  #line 59 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_line_(59);
  #line 59 "birch/filter/ConditionalParticleFilter.birch"
  this_()->reduce(handler_);
}

#line 62 "birch/filter/ConditionalParticleFilter.birch"
void birch::type::ConditionalParticleFilter::ancestorSample(const birch::type::Integer& t, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 62 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_function_("ancestorSample", "birch/filter/ConditionalParticleFilter.birch", 62);
  #line 63 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_line_(63);
  #line 63 "birch/filter/ConditionalParticleFilter.birch"
  auto w_prime_ = this_()->w;
  #line 64 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_line_(64);
  #line 64 "birch/filter/ConditionalParticleFilter.birch"
  #pragma omp parallel
  {
    #line 64 "birch/filter/ConditionalParticleFilter.birch"
    libbirch_function_("<parallel for>", "birch/filter/ConditionalParticleFilter.birch", 64);
    #pragma omp for schedule(guided)
    for (auto n = birch::type::Integer(1); n <= this_()->nparticles; ++n) {
      #line 65 "birch/filter/ConditionalParticleFilter.birch"
      libbirch_line_(65);
      #line 65 "birch/filter/ConditionalParticleFilter.birch"
      auto x_prime_ = birch::clone(this_()->x.get(libbirch::make_slice(n - 1)), handler_);
      #line 66 "birch/filter/ConditionalParticleFilter.birch"
      libbirch_line_(66);
      #line 66 "birch/filter/ConditionalParticleFilter.birch"
      auto r_prime_ = birch::clone(this_()->r.get(), handler_);
      #line 67 "birch/filter/ConditionalParticleFilter.birch"
      libbirch_line_(67);
      #line 67 "birch/filter/ConditionalParticleFilter.birch"
      auto handler = birch::PlayHandler(this_()->delayed, handler_);
      #line 68 "birch/filter/ConditionalParticleFilter.birch"
      libbirch_line_(68);
      #line 68 "birch/filter/ConditionalParticleFilter.birch"
      handler->input = r_prime_;
      #line 69 "birch/filter/ConditionalParticleFilter.birch"
      libbirch_line_(69);
      #line 69 "birch/filter/ConditionalParticleFilter.birch"
      {
        auto handler_ = (handler);
        #line 70 "birch/filter/ConditionalParticleFilter.birch"
        libbirch_line_(70);
        #line 70 "birch/filter/ConditionalParticleFilter.birch"
        x_prime_->m->simulate(t, handler_);
        #line 71 "birch/filter/ConditionalParticleFilter.birch"
        libbirch_line_(71);
        #line 71 "birch/filter/ConditionalParticleFilter.birch"
        w_prime_.set(libbirch::make_slice(n - 1), w_prime_.get(libbirch::make_slice(n - 1)) + handler->w);
      }
    }
  }
  #line 75 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_line_(75);
  #line 75 "birch/filter/ConditionalParticleFilter.birch"
  this_()->b = birch::ancestor(w_prime_, handler_);
}

#line 78 "birch/filter/ConditionalParticleFilter.birch"
void birch::type::ConditionalParticleFilter::propagate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 78 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_function_("propagate", "birch/filter/ConditionalParticleFilter.birch", 78);
  #line 79 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_line_(79);
  #line 79 "birch/filter/ConditionalParticleFilter.birch"
  if (!this_()->alreadyInitialized) {
    #line 80 "birch/filter/ConditionalParticleFilter.birch"
    libbirch_line_(80);
    #line 80 "birch/filter/ConditionalParticleFilter.birch"
    #pragma omp parallel
    {
      #line 80 "birch/filter/ConditionalParticleFilter.birch"
      libbirch_function_("<parallel for>", "birch/filter/ConditionalParticleFilter.birch", 80);
      #pragma omp for schedule(static)
      for (auto n = birch::type::Integer(1); n <= this_()->nparticles; ++n) {
        #line 81 "birch/filter/ConditionalParticleFilter.birch"
        libbirch_line_(81);
        #line 81 "birch/filter/ConditionalParticleFilter.birch"
        auto x = libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::ConditionalParticle>>>(this_()->x.get(libbirch::make_slice(n - 1))).get();
        #line 82 "birch/filter/ConditionalParticleFilter.birch"
        libbirch_line_(82);
        #line 82 "birch/filter/ConditionalParticleFilter.birch"
        auto handler = birch::PlayHandler(this_()->delayed, handler_);
        #line 83 "birch/filter/ConditionalParticleFilter.birch"
        libbirch_line_(83);
        #line 83 "birch/filter/ConditionalParticleFilter.birch"
        if (this_()->r.query() && n == this_()->b) {
          #line 84 "birch/filter/ConditionalParticleFilter.birch"
          libbirch_line_(84);
          #line 84 "birch/filter/ConditionalParticleFilter.birch"
          handler->input = this_()->r.get();
        }
        #line 86 "birch/filter/ConditionalParticleFilter.birch"
        libbirch_line_(86);
        #line 86 "birch/filter/ConditionalParticleFilter.birch"
        handler->output = x->trace;
        #line 87 "birch/filter/ConditionalParticleFilter.birch"
        libbirch_line_(87);
        #line 87 "birch/filter/ConditionalParticleFilter.birch"
        {
          auto handler_ = (handler);
          #line 88 "birch/filter/ConditionalParticleFilter.birch"
          libbirch_line_(88);
          #line 88 "birch/filter/ConditionalParticleFilter.birch"
          x->m->simulate(handler_);
        }
        #line 90 "birch/filter/ConditionalParticleFilter.birch"
        libbirch_line_(90);
        #line 90 "birch/filter/ConditionalParticleFilter.birch"
        this_()->w.set(libbirch::make_slice(n - 1), handler->w);
      }
    }
  }
}

#line 95 "birch/filter/ConditionalParticleFilter.birch"
void birch::type::ConditionalParticleFilter::propagate(const birch::type::Integer& t, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 95 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_function_("propagate", "birch/filter/ConditionalParticleFilter.birch", 95);
  #line 96 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_line_(96);
  #line 96 "birch/filter/ConditionalParticleFilter.birch"
  #pragma omp parallel
  {
    #line 96 "birch/filter/ConditionalParticleFilter.birch"
    libbirch_function_("<parallel for>", "birch/filter/ConditionalParticleFilter.birch", 96);
    #pragma omp for schedule(static)
    for (auto n = birch::type::Integer(1); n <= this_()->nparticles; ++n) {
      #line 97 "birch/filter/ConditionalParticleFilter.birch"
      libbirch_line_(97);
      #line 97 "birch/filter/ConditionalParticleFilter.birch"
      auto x = libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::ConditionalParticle>>>(this_()->x.get(libbirch::make_slice(n - 1))).get();
      #line 98 "birch/filter/ConditionalParticleFilter.birch"
      libbirch_line_(98);
      #line 98 "birch/filter/ConditionalParticleFilter.birch"
      auto handler = birch::PlayHandler(this_()->delayed, handler_);
      #line 99 "birch/filter/ConditionalParticleFilter.birch"
      libbirch_line_(99);
      #line 99 "birch/filter/ConditionalParticleFilter.birch"
      if (this_()->r.query() && n == this_()->b) {
        #line 100 "birch/filter/ConditionalParticleFilter.birch"
        libbirch_line_(100);
        #line 100 "birch/filter/ConditionalParticleFilter.birch"
        handler->input = this_()->r.get();
      }
      #line 102 "birch/filter/ConditionalParticleFilter.birch"
      libbirch_line_(102);
      #line 102 "birch/filter/ConditionalParticleFilter.birch"
      handler->output = x->trace;
      #line 103 "birch/filter/ConditionalParticleFilter.birch"
      libbirch_line_(103);
      #line 103 "birch/filter/ConditionalParticleFilter.birch"
      {
        auto handler_ = (handler);
        #line 104 "birch/filter/ConditionalParticleFilter.birch"
        libbirch_line_(104);
        #line 104 "birch/filter/ConditionalParticleFilter.birch"
        x->m->simulate(t, handler_);
      }
      #line 106 "birch/filter/ConditionalParticleFilter.birch"
      libbirch_line_(106);
      #line 106 "birch/filter/ConditionalParticleFilter.birch"
      this_()->w.set(libbirch::make_slice(n - 1), this_()->w.get(libbirch::make_slice(n - 1)) + handler->w);
    }
  }
}

#line 110 "birch/filter/ConditionalParticleFilter.birch"
void birch::type::ConditionalParticleFilter::resample(const birch::type::Integer& t, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 110 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_function_("resample", "birch/filter/ConditionalParticleFilter.birch", 110);
  #line 111 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_line_(111);
  #line 111 "birch/filter/ConditionalParticleFilter.birch"
  if (this_()->ess <= this_()->trigger * this_()->nparticles) {
    #line 112 "birch/filter/ConditionalParticleFilter.birch"
    libbirch_line_(112);
    #line 112 "birch/filter/ConditionalParticleFilter.birch"
    if (this_()->r.query()) {
      #line 113 "birch/filter/ConditionalParticleFilter.birch"
      libbirch_line_(113);
      #line 113 "birch/filter/ConditionalParticleFilter.birch"
      libbirch::tie(this_()->a, this_()->b) = birch::conditional_resample_multinomial(this_()->w, this_()->b, handler_);
    } else {
      #line 115 "birch/filter/ConditionalParticleFilter.birch"
      libbirch_line_(115);
      #line 115 "birch/filter/ConditionalParticleFilter.birch"
      this_()->a = birch::resample_multinomial(this_()->w, handler_);
    }
    #line 117 "birch/filter/ConditionalParticleFilter.birch"
    libbirch_line_(117);
    #line 117 "birch/filter/ConditionalParticleFilter.birch"
    this_()->w = birch::vector(0.0, this_()->nparticles, handler_);
    #line 118 "birch/filter/ConditionalParticleFilter.birch"
    libbirch_line_(118);
    #line 118 "birch/filter/ConditionalParticleFilter.birch"
    #pragma omp parallel
    {
      #line 118 "birch/filter/ConditionalParticleFilter.birch"
      libbirch_function_("<parallel for>", "birch/filter/ConditionalParticleFilter.birch", 118);
      #pragma omp for schedule(guided)
      for (auto n = birch::type::Integer(1); n <= this_()->nparticles; ++n) {
        #line 119 "birch/filter/ConditionalParticleFilter.birch"
        libbirch_line_(119);
        #line 119 "birch/filter/ConditionalParticleFilter.birch"
        if (this_()->a.get(libbirch::make_slice(n - 1)) != n) {
          #line 120 "birch/filter/ConditionalParticleFilter.birch"
          libbirch_line_(120);
          #line 120 "birch/filter/ConditionalParticleFilter.birch"
          this_()->x.set(libbirch::make_slice(n - 1), birch::clone(this_()->x.get(libbirch::make_slice(this_()->a.get(libbirch::make_slice(n - 1)) - 1)), handler_));
        }
      }
    }
    #line 123 "birch/filter/ConditionalParticleFilter.birch"
    libbirch_line_(123);
    #line 123 "birch/filter/ConditionalParticleFilter.birch"
    birch::collect(handler_);
  } else {
    #line 126 "birch/filter/ConditionalParticleFilter.birch"
    libbirch_line_(126);
    #line 126 "birch/filter/ConditionalParticleFilter.birch"
    this_()->w = this_()->w - birch::vector(this_()->lsum - birch::log(birch::Real(this_()->nparticles, handler_), handler_), this_()->nparticles, handler_);
  }
}

#line 130 "birch/filter/ConditionalParticleFilter.birch"
void birch::type::ConditionalParticleFilter::read(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 130 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_function_("read", "birch/filter/ConditionalParticleFilter.birch", 130);
  #line 131 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_line_(131);
  #line 131 "birch/filter/ConditionalParticleFilter.birch"
  this_()->super_type_::read(buffer, handler_);
  #line 132 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_line_(132);
  #line 132 "birch/filter/ConditionalParticleFilter.birch"
  libbirch::optional_assign(this_()->ancestor, buffer->get(birch::type::String("ancestor"), this_()->ancestor, handler_));
}

#line 135 "birch/filter/ConditionalParticleFilter.birch"
void birch::type::ConditionalParticleFilter::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 135 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_function_("write", "birch/filter/ConditionalParticleFilter.birch", 135);
  #line 136 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_line_(136);
  #line 136 "birch/filter/ConditionalParticleFilter.birch"
  this_()->super_type_::write(buffer, handler_);
  #line 137 "birch/filter/ConditionalParticleFilter.birch"
  libbirch_line_(137);
  #line 137 "birch/filter/ConditionalParticleFilter.birch"
  buffer->set(birch::type::String("ancestor"), this_()->ancestor, handler_);
}

#line 1 "birch/filter/ConditionalParticleFilter.birch"
birch::type::ConditionalParticleFilter* birch::type::make_ConditionalParticleFilter_() {
  #line 1 "birch/filter/ConditionalParticleFilter.birch"
  return new birch::type::ConditionalParticleFilter();
  #line 1 "birch/filter/ConditionalParticleFilter.birch"
}

#line 1 "birch/filter/MoveParticleFilter.birch"
birch::type::MoveParticleFilter::MoveParticleFilter(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/filter/MoveParticleFilter.birch"
    super_type_(),
    #line 19 "birch/filter/MoveParticleFilter.birch"
    naccepts(),
    #line 24 "birch/filter/MoveParticleFilter.birch"
    scale(0.1),
    #line 29 "birch/filter/MoveParticleFilter.birch"
    nmoves(birch::type::Integer(1)),
    #line 34 "birch/filter/MoveParticleFilter.birch"
    nlags(birch::type::Integer(1)) {
  //
}

#line 36 "birch/filter/MoveParticleFilter.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Particle>> birch::type::MoveParticleFilter::particle(const libbirch::Lazy<libbirch::Shared<birch::type::Model>>& archetype, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 36 "birch/filter/MoveParticleFilter.birch"
  libbirch_function_("particle", "birch/filter/MoveParticleFilter.birch", 36);
  #line 37 "birch/filter/MoveParticleFilter.birch"
  libbirch_line_(37);
  #line 37 "birch/filter/MoveParticleFilter.birch"
  return birch::MoveParticle(archetype, handler_);
}

#line 40 "birch/filter/MoveParticleFilter.birch"
void birch::type::MoveParticleFilter::filter(const birch::type::Integer& t, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 40 "birch/filter/MoveParticleFilter.birch"
  libbirch_function_("filter", "birch/filter/MoveParticleFilter.birch", 40);
  #line 41 "birch/filter/MoveParticleFilter.birch"
  libbirch_line_(41);
  #line 41 "birch/filter/MoveParticleFilter.birch"
  this_()->resample(t, handler_);
  #line 42 "birch/filter/MoveParticleFilter.birch"
  libbirch_line_(42);
  #line 42 "birch/filter/MoveParticleFilter.birch"
  this_()->move(t, handler_);
  #line 43 "birch/filter/MoveParticleFilter.birch"
  libbirch_line_(43);
  #line 43 "birch/filter/MoveParticleFilter.birch"
  this_()->propagate(t, handler_);
  #line 44 "birch/filter/MoveParticleFilter.birch"
  libbirch_line_(44);
  #line 44 "birch/filter/MoveParticleFilter.birch"
  this_()->reduce(handler_);
}

#line 47 "birch/filter/MoveParticleFilter.birch"
void birch::type::MoveParticleFilter::propagate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 47 "birch/filter/MoveParticleFilter.birch"
  libbirch_function_("propagate", "birch/filter/MoveParticleFilter.birch", 47);
  #line 48 "birch/filter/MoveParticleFilter.birch"
  libbirch_line_(48);
  #line 48 "birch/filter/MoveParticleFilter.birch"
  #pragma omp parallel
  {
    #line 48 "birch/filter/MoveParticleFilter.birch"
    libbirch_function_("<parallel for>", "birch/filter/MoveParticleFilter.birch", 48);
    #pragma omp for schedule(static)
    for (auto n = birch::type::Integer(1); n <= this_()->nparticles; ++n) {
      #line 49 "birch/filter/MoveParticleFilter.birch"
      libbirch_line_(49);
      #line 49 "birch/filter/MoveParticleFilter.birch"
      auto x = libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::MoveParticle>>>(this_()->x.get(libbirch::make_slice(n - 1))).get();
      #line 50 "birch/filter/MoveParticleFilter.birch"
      libbirch_line_(50);
      #line 50 "birch/filter/MoveParticleFilter.birch"
      auto handler = birch::MoveHandler(this_()->delayed, handler_);
      #line 51 "birch/filter/MoveParticleFilter.birch"
      libbirch_line_(51);
      #line 51 "birch/filter/MoveParticleFilter.birch"
      {
        auto handler_ = (handler);
        #line 52 "birch/filter/MoveParticleFilter.birch"
        libbirch_line_(52);
        #line 52 "birch/filter/MoveParticleFilter.birch"
        x->m->simulate(handler_);
        #line 53 "birch/filter/MoveParticleFilter.birch"
        libbirch_line_(53);
        #line 53 "birch/filter/MoveParticleFilter.birch"
        this_()->w.set(libbirch::make_slice(n - 1), this_()->w.get(libbirch::make_slice(n - 1)) + handler->w);
      }
      #line 55 "birch/filter/MoveParticleFilter.birch"
      libbirch_line_(55);
      #line 55 "birch/filter/MoveParticleFilter.birch"
      this_()->w.set(libbirch::make_slice(n - 1), this_()->w.get(libbirch::make_slice(n - 1)) + x->augment(birch::type::Integer(0), handler->z, handler_));
      #line 56 "birch/filter/MoveParticleFilter.birch"
      libbirch_line_(56);
      #line 56 "birch/filter/MoveParticleFilter.birch"
      while (x->size(handler_) > this_()->nlags) {
        #line 57 "birch/filter/MoveParticleFilter.birch"
        libbirch_line_(57);
        #line 57 "birch/filter/MoveParticleFilter.birch"
        x->truncate(handler_);
      }
    }
  }
}

#line 62 "birch/filter/MoveParticleFilter.birch"
void birch::type::MoveParticleFilter::propagate(const birch::type::Integer& t, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 62 "birch/filter/MoveParticleFilter.birch"
  libbirch_function_("propagate", "birch/filter/MoveParticleFilter.birch", 62);
  #line 63 "birch/filter/MoveParticleFilter.birch"
  libbirch_line_(63);
  #line 63 "birch/filter/MoveParticleFilter.birch"
  #pragma omp parallel
  {
    #line 63 "birch/filter/MoveParticleFilter.birch"
    libbirch_function_("<parallel for>", "birch/filter/MoveParticleFilter.birch", 63);
    #pragma omp for schedule(static)
    for (auto n = birch::type::Integer(1); n <= this_()->nparticles; ++n) {
      #line 64 "birch/filter/MoveParticleFilter.birch"
      libbirch_line_(64);
      #line 64 "birch/filter/MoveParticleFilter.birch"
      auto x = libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::MoveParticle>>>(this_()->x.get(libbirch::make_slice(n - 1))).get();
      #line 65 "birch/filter/MoveParticleFilter.birch"
      libbirch_line_(65);
      #line 65 "birch/filter/MoveParticleFilter.birch"
      auto handler = birch::MoveHandler(this_()->delayed, handler_);
      #line 66 "birch/filter/MoveParticleFilter.birch"
      libbirch_line_(66);
      #line 66 "birch/filter/MoveParticleFilter.birch"
      {
        auto handler_ = (handler);
        #line 67 "birch/filter/MoveParticleFilter.birch"
        libbirch_line_(67);
        #line 67 "birch/filter/MoveParticleFilter.birch"
        x->m->simulate(t, handler_);
        #line 68 "birch/filter/MoveParticleFilter.birch"
        libbirch_line_(68);
        #line 68 "birch/filter/MoveParticleFilter.birch"
        this_()->w.set(libbirch::make_slice(n - 1), this_()->w.get(libbirch::make_slice(n - 1)) + handler->w);
      }
      #line 70 "birch/filter/MoveParticleFilter.birch"
      libbirch_line_(70);
      #line 70 "birch/filter/MoveParticleFilter.birch"
      this_()->w.set(libbirch::make_slice(n - 1), this_()->w.get(libbirch::make_slice(n - 1)) + x->augment(t, handler->z, handler_));
      #line 71 "birch/filter/MoveParticleFilter.birch"
      libbirch_line_(71);
      #line 71 "birch/filter/MoveParticleFilter.birch"
      while (x->size(handler_) > this_()->nlags) {
        #line 72 "birch/filter/MoveParticleFilter.birch"
        libbirch_line_(72);
        #line 72 "birch/filter/MoveParticleFilter.birch"
        x->truncate(handler_);
      }
    }
  }
}

#line 77 "birch/filter/MoveParticleFilter.birch"
void birch::type::MoveParticleFilter::move(const birch::type::Integer& t, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 77 "birch/filter/MoveParticleFilter.birch"
  libbirch_function_("move", "birch/filter/MoveParticleFilter.birch", 77);
  #line 78 "birch/filter/MoveParticleFilter.birch"
  libbirch_line_(78);
  #line 78 "birch/filter/MoveParticleFilter.birch"
  this_()->naccepts = birch::vector(birch::type::Integer(0), this_()->nparticles, handler_);
  #line 79 "birch/filter/MoveParticleFilter.birch"
  libbirch_line_(79);
  #line 79 "birch/filter/MoveParticleFilter.birch"
  if (this_()->ess <= this_()->trigger * this_()->nparticles && this_()->nlags > birch::type::Integer(0) && this_()->nmoves > birch::type::Integer(0)) {
    #line 80 "birch/filter/MoveParticleFilter.birch"
    libbirch_line_(80);
    #line 80 "birch/filter/MoveParticleFilter.birch"
    libbirch::Lazy<libbirch::Shared<birch::type::LangevinKernel>> _u0954;
    #line 81 "birch/filter/MoveParticleFilter.birch"
    libbirch_line_(81);
    #line 81 "birch/filter/MoveParticleFilter.birch"
    _u0954->scale = this_()->scale / birch::pow(t, birch::type::Integer(2), handler_);
    #line 82 "birch/filter/MoveParticleFilter.birch"
    libbirch_line_(82);
    #line 82 "birch/filter/MoveParticleFilter.birch"
    #pragma omp parallel
    {
      #line 82 "birch/filter/MoveParticleFilter.birch"
      libbirch_function_("<parallel for>", "birch/filter/MoveParticleFilter.birch", 82);
      #pragma omp for schedule(static)
      for (auto n = birch::type::Integer(1); n <= this_()->nparticles; ++n) {
        #line 83 "birch/filter/MoveParticleFilter.birch"
        libbirch_line_(83);
        #line 83 "birch/filter/MoveParticleFilter.birch"
        auto x = libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::MoveParticle>>>(birch::clone(this_()->x.get(libbirch::make_slice(n - 1)), handler_)).get();
        #line 84 "birch/filter/MoveParticleFilter.birch"
        libbirch_line_(84);
        #line 84 "birch/filter/MoveParticleFilter.birch"
        x->grad(t - this_()->nlags, handler_);
        #line 85 "birch/filter/MoveParticleFilter.birch"
        libbirch_line_(85);
        #line 85 "birch/filter/MoveParticleFilter.birch"
        for (auto m = birch::type::Integer(1); m <= this_()->nmoves; ++m) {
          #line 86 "birch/filter/MoveParticleFilter.birch"
          libbirch_line_(86);
          #line 86 "birch/filter/MoveParticleFilter.birch"
          auto x_prime_ = birch::clone(x, handler_);
          #line 87 "birch/filter/MoveParticleFilter.birch"
          libbirch_line_(87);
          #line 87 "birch/filter/MoveParticleFilter.birch"
          x_prime_->move(t - this_()->nlags, _u0954, handler_);
          #line 88 "birch/filter/MoveParticleFilter.birch"
          libbirch_line_(88);
          #line 88 "birch/filter/MoveParticleFilter.birch"
          x_prime_->grad(t - this_()->nlags, handler_);
          #line 89 "birch/filter/MoveParticleFilter.birch"
          libbirch_line_(89);
          #line 89 "birch/filter/MoveParticleFilter.birch"
          auto _u0945 = x_prime_->_u0960 - x->_u0960 + x_prime_->compare(t - this_()->nlags, x, _u0954, handler_);
          #line 90 "birch/filter/MoveParticleFilter.birch"
          libbirch_line_(90);
          #line 90 "birch/filter/MoveParticleFilter.birch"
          if (birch::log(birch::simulate_uniform(0.0, 1.0, handler_), handler_) <= _u0945) {
            #line 91 "birch/filter/MoveParticleFilter.birch"
            libbirch_line_(91);
            #line 91 "birch/filter/MoveParticleFilter.birch"
            x = x_prime_;
            #line 92 "birch/filter/MoveParticleFilter.birch"
            libbirch_line_(92);
            #line 92 "birch/filter/MoveParticleFilter.birch"
            this_()->naccepts.set(libbirch::make_slice(n - 1), this_()->naccepts.get(libbirch::make_slice(n - 1)) + birch::type::Integer(1));
          }
        }
        #line 95 "birch/filter/MoveParticleFilter.birch"
        libbirch_line_(95);
        #line 95 "birch/filter/MoveParticleFilter.birch"
        this_()->x.set(libbirch::make_slice(n - 1), x);
      }
    }
    #line 97 "birch/filter/MoveParticleFilter.birch"
    libbirch_line_(97);
    #line 97 "birch/filter/MoveParticleFilter.birch"
    birch::collect(handler_);
  }
}

#line 101 "birch/filter/MoveParticleFilter.birch"
void birch::type::MoveParticleFilter::reduce(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 101 "birch/filter/MoveParticleFilter.birch"
  libbirch_function_("reduce", "birch/filter/MoveParticleFilter.birch", 101);
  #line 102 "birch/filter/MoveParticleFilter.birch"
  libbirch_line_(102);
  #line 102 "birch/filter/MoveParticleFilter.birch"
  this_()->super_type_::reduce(handler_);
  #line 103 "birch/filter/MoveParticleFilter.birch"
  libbirch_line_(103);
  #line 103 "birch/filter/MoveParticleFilter.birch"
  this_()->raccept = birch::Real(birch::sum(this_()->naccepts, handler_), handler_) / (this_()->nparticles * this_()->nmoves);
}

#line 106 "birch/filter/MoveParticleFilter.birch"
void birch::type::MoveParticleFilter::read(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 106 "birch/filter/MoveParticleFilter.birch"
  libbirch_function_("read", "birch/filter/MoveParticleFilter.birch", 106);
  #line 107 "birch/filter/MoveParticleFilter.birch"
  libbirch_line_(107);
  #line 107 "birch/filter/MoveParticleFilter.birch"
  this_()->super_type_::read(buffer, handler_);
  #line 108 "birch/filter/MoveParticleFilter.birch"
  libbirch_line_(108);
  #line 108 "birch/filter/MoveParticleFilter.birch"
  libbirch::optional_assign(this_()->scale, buffer->get(birch::type::String("scale"), this_()->scale, handler_));
  #line 109 "birch/filter/MoveParticleFilter.birch"
  libbirch_line_(109);
  #line 109 "birch/filter/MoveParticleFilter.birch"
  libbirch::optional_assign(this_()->nmoves, buffer->get(birch::type::String("nmoves"), this_()->nmoves, handler_));
  #line 110 "birch/filter/MoveParticleFilter.birch"
  libbirch_line_(110);
  #line 110 "birch/filter/MoveParticleFilter.birch"
  libbirch::optional_assign(this_()->nlags, buffer->get(birch::type::String("nlags"), this_()->nlags, handler_));
}

#line 113 "birch/filter/MoveParticleFilter.birch"
void birch::type::MoveParticleFilter::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 113 "birch/filter/MoveParticleFilter.birch"
  libbirch_function_("write", "birch/filter/MoveParticleFilter.birch", 113);
  #line 114 "birch/filter/MoveParticleFilter.birch"
  libbirch_line_(114);
  #line 114 "birch/filter/MoveParticleFilter.birch"
  this_()->super_type_::write(buffer, handler_);
  #line 115 "birch/filter/MoveParticleFilter.birch"
  libbirch_line_(115);
  #line 115 "birch/filter/MoveParticleFilter.birch"
  buffer->set(birch::type::String("scale"), this_()->scale, handler_);
  #line 116 "birch/filter/MoveParticleFilter.birch"
  libbirch_line_(116);
  #line 116 "birch/filter/MoveParticleFilter.birch"
  buffer->set(birch::type::String("nmoves"), this_()->nmoves, handler_);
  #line 117 "birch/filter/MoveParticleFilter.birch"
  libbirch_line_(117);
  #line 117 "birch/filter/MoveParticleFilter.birch"
  buffer->set(birch::type::String("nlags"), this_()->nlags, handler_);
}

#line 1 "birch/filter/MoveParticleFilter.birch"
birch::type::MoveParticleFilter* birch::type::make_MoveParticleFilter_() {
  #line 1 "birch/filter/MoveParticleFilter.birch"
  return new birch::type::MoveParticleFilter();
  #line 1 "birch/filter/MoveParticleFilter.birch"
}

#line 1 "birch/filter/ParticleFilter.birch"
birch::type::ParticleFilter::ParticleFilter(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/filter/ParticleFilter.birch"
    super_type_(),
    #line 19 "birch/filter/ParticleFilter.birch"
    x(),
    #line 24 "birch/filter/ParticleFilter.birch"
    w(),
    #line 29 "birch/filter/ParticleFilter.birch"
    a(),
    #line 34 "birch/filter/ParticleFilter.birch"
    ess(0.0),
    #line 39 "birch/filter/ParticleFilter.birch"
    lsum(0.0),
    #line 44 "birch/filter/ParticleFilter.birch"
    lnormalize(0.0),
    #line 52 "birch/filter/ParticleFilter.birch"
    npropagations(birch::type::Integer(0)),
    #line 57 "birch/filter/ParticleFilter.birch"
    raccept(0.0),
    #line 63 "birch/filter/ParticleFilter.birch"
    nsteps(),
    #line 68 "birch/filter/ParticleFilter.birch"
    nforecasts(birch::type::Integer(0)),
    #line 73 "birch/filter/ParticleFilter.birch"
    nparticles(birch::type::Integer(1)),
    #line 80 "birch/filter/ParticleFilter.birch"
    trigger(0.7),
    #line 85 "birch/filter/ParticleFilter.birch"
    delayed(true) {
  //
}

#line 92 "birch/filter/ParticleFilter.birch"
birch::type::Integer birch::type::ParticleFilter::size(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 92 "birch/filter/ParticleFilter.birch"
  libbirch_function_("size", "birch/filter/ParticleFilter.birch", 92);
  #line 93 "birch/filter/ParticleFilter.birch"
  libbirch_line_(93);
  #line 93 "birch/filter/ParticleFilter.birch"
  libbirch_assert_(this_()->nsteps.query());
  #line 94 "birch/filter/ParticleFilter.birch"
  libbirch_line_(94);
  #line 94 "birch/filter/ParticleFilter.birch"
  return this_()->nsteps.get();
}

#line 100 "birch/filter/ParticleFilter.birch"
libbirch::Lazy<libbirch::Shared<birch::type::Particle>> birch::type::ParticleFilter::particle(const libbirch::Lazy<libbirch::Shared<birch::type::Model>>& archetype, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 100 "birch/filter/ParticleFilter.birch"
  libbirch_function_("particle", "birch/filter/ParticleFilter.birch", 100);
  #line 101 "birch/filter/ParticleFilter.birch"
  libbirch_line_(101);
  #line 101 "birch/filter/ParticleFilter.birch"
  return birch::Particle(archetype, handler_);
}

#line 111 "birch/filter/ParticleFilter.birch"
void birch::type::ParticleFilter::initialize(const libbirch::Lazy<libbirch::Shared<birch::type::Model>>& archetype, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 111 "birch/filter/ParticleFilter.birch"
  libbirch_function_("initialize", "birch/filter/ParticleFilter.birch", 111);
  #line 112 "birch/filter/ParticleFilter.birch"
  libbirch_line_(112);
  #line 112 "birch/filter/ParticleFilter.birch"
  this_()->x = birch::clone(this_()->particle(archetype, handler_), this_()->nparticles, handler_);
  #line 113 "birch/filter/ParticleFilter.birch"
  libbirch_line_(113);
  #line 113 "birch/filter/ParticleFilter.birch"
  this_()->w = birch::vector(0.0, this_()->nparticles, handler_);
  #line 114 "birch/filter/ParticleFilter.birch"
  libbirch_line_(114);
  #line 114 "birch/filter/ParticleFilter.birch"
  this_()->a = birch::iota(birch::type::Integer(1), this_()->nparticles, handler_);
  #line 115 "birch/filter/ParticleFilter.birch"
  libbirch_line_(115);
  #line 115 "birch/filter/ParticleFilter.birch"
  this_()->ess = this_()->nparticles;
  #line 116 "birch/filter/ParticleFilter.birch"
  libbirch_line_(116);
  #line 116 "birch/filter/ParticleFilter.birch"
  this_()->lsum = 0.0;
  #line 117 "birch/filter/ParticleFilter.birch"
  libbirch_line_(117);
  #line 117 "birch/filter/ParticleFilter.birch"
  this_()->lnormalize = 0.0;
  #line 118 "birch/filter/ParticleFilter.birch"
  libbirch_line_(118);
  #line 118 "birch/filter/ParticleFilter.birch"
  this_()->npropagations = this_()->nparticles;
  #line 120 "birch/filter/ParticleFilter.birch"
  libbirch_line_(120);
  #line 120 "birch/filter/ParticleFilter.birch"
  if (!this_()->nsteps.query()) {
    #line 121 "birch/filter/ParticleFilter.birch"
    libbirch_line_(121);
    #line 121 "birch/filter/ParticleFilter.birch"
    this_()->nsteps = archetype->size(handler_);
  }
}

#line 128 "birch/filter/ParticleFilter.birch"
void birch::type::ParticleFilter::filter(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 128 "birch/filter/ParticleFilter.birch"
  libbirch_function_("filter", "birch/filter/ParticleFilter.birch", 128);
  #line 129 "birch/filter/ParticleFilter.birch"
  libbirch_line_(129);
  #line 129 "birch/filter/ParticleFilter.birch"
  this_()->propagate(handler_);
  #line 130 "birch/filter/ParticleFilter.birch"
  libbirch_line_(130);
  #line 130 "birch/filter/ParticleFilter.birch"
  this_()->reduce(handler_);
}

#line 138 "birch/filter/ParticleFilter.birch"
void birch::type::ParticleFilter::filter(const birch::type::Integer& t, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 138 "birch/filter/ParticleFilter.birch"
  libbirch_function_("filter", "birch/filter/ParticleFilter.birch", 138);
  #line 139 "birch/filter/ParticleFilter.birch"
  libbirch_line_(139);
  #line 139 "birch/filter/ParticleFilter.birch"
  this_()->resample(t, handler_);
  #line 140 "birch/filter/ParticleFilter.birch"
  libbirch_line_(140);
  #line 140 "birch/filter/ParticleFilter.birch"
  this_()->propagate(t, handler_);
  #line 141 "birch/filter/ParticleFilter.birch"
  libbirch_line_(141);
  #line 141 "birch/filter/ParticleFilter.birch"
  this_()->reduce(handler_);
}

#line 147 "birch/filter/ParticleFilter.birch"
void birch::type::ParticleFilter::propagate(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 147 "birch/filter/ParticleFilter.birch"
  libbirch_function_("propagate", "birch/filter/ParticleFilter.birch", 147);
  #line 148 "birch/filter/ParticleFilter.birch"
  libbirch_line_(148);
  #line 148 "birch/filter/ParticleFilter.birch"
  #pragma omp parallel
  {
    #line 148 "birch/filter/ParticleFilter.birch"
    libbirch_function_("<parallel for>", "birch/filter/ParticleFilter.birch", 148);
    #pragma omp for schedule(static)
    for (auto n = birch::type::Integer(1); n <= this_()->nparticles; ++n) {
      #line 149 "birch/filter/ParticleFilter.birch"
      libbirch_line_(149);
      #line 149 "birch/filter/ParticleFilter.birch"
      auto handler = birch::PlayHandler(this_()->delayed, handler_);
      #line 150 "birch/filter/ParticleFilter.birch"
      libbirch_line_(150);
      #line 150 "birch/filter/ParticleFilter.birch"
      {
        auto handler_ = (handler);
        #line 151 "birch/filter/ParticleFilter.birch"
        libbirch_line_(151);
        #line 151 "birch/filter/ParticleFilter.birch"
        this_()->x.get(libbirch::make_slice(n - 1))->m->simulate(handler_);
        #line 152 "birch/filter/ParticleFilter.birch"
        libbirch_line_(152);
        #line 152 "birch/filter/ParticleFilter.birch"
        this_()->w.set(libbirch::make_slice(n - 1), this_()->w.get(libbirch::make_slice(n - 1)) + handler->w);
      }
    }
  }
}

#line 160 "birch/filter/ParticleFilter.birch"
void birch::type::ParticleFilter::propagate(const birch::type::Integer& t, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 160 "birch/filter/ParticleFilter.birch"
  libbirch_function_("propagate", "birch/filter/ParticleFilter.birch", 160);
  #line 161 "birch/filter/ParticleFilter.birch"
  libbirch_line_(161);
  #line 161 "birch/filter/ParticleFilter.birch"
  #pragma omp parallel
  {
    #line 161 "birch/filter/ParticleFilter.birch"
    libbirch_function_("<parallel for>", "birch/filter/ParticleFilter.birch", 161);
    #pragma omp for schedule(static)
    for (auto n = birch::type::Integer(1); n <= this_()->nparticles; ++n) {
      #line 162 "birch/filter/ParticleFilter.birch"
      libbirch_line_(162);
      #line 162 "birch/filter/ParticleFilter.birch"
      auto handler = birch::PlayHandler(this_()->delayed, handler_);
      #line 163 "birch/filter/ParticleFilter.birch"
      libbirch_line_(163);
      #line 163 "birch/filter/ParticleFilter.birch"
      {
        auto handler_ = (handler);
        #line 164 "birch/filter/ParticleFilter.birch"
        libbirch_line_(164);
        #line 164 "birch/filter/ParticleFilter.birch"
        this_()->x.get(libbirch::make_slice(n - 1))->m->simulate(t, handler_);
        #line 165 "birch/filter/ParticleFilter.birch"
        libbirch_line_(165);
        #line 165 "birch/filter/ParticleFilter.birch"
        this_()->w.set(libbirch::make_slice(n - 1), this_()->w.get(libbirch::make_slice(n - 1)) + handler->w);
      }
    }
  }
}

#line 173 "birch/filter/ParticleFilter.birch"
void birch::type::ParticleFilter::forecast(const birch::type::Integer& t, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 173 "birch/filter/ParticleFilter.birch"
  libbirch_function_("forecast", "birch/filter/ParticleFilter.birch", 173);
  #line 174 "birch/filter/ParticleFilter.birch"
  libbirch_line_(174);
  #line 174 "birch/filter/ParticleFilter.birch"
  #pragma omp parallel
  {
    #line 174 "birch/filter/ParticleFilter.birch"
    libbirch_function_("<parallel for>", "birch/filter/ParticleFilter.birch", 174);
    #pragma omp for schedule(static)
    for (auto n = birch::type::Integer(1); n <= this_()->nparticles; ++n) {
      #line 175 "birch/filter/ParticleFilter.birch"
      libbirch_line_(175);
      #line 175 "birch/filter/ParticleFilter.birch"
      auto handler = birch::PlayHandler(this_()->delayed, handler_);
      #line 176 "birch/filter/ParticleFilter.birch"
      libbirch_line_(176);
      #line 176 "birch/filter/ParticleFilter.birch"
      {
        auto handler_ = (handler);
        #line 177 "birch/filter/ParticleFilter.birch"
        libbirch_line_(177);
        #line 177 "birch/filter/ParticleFilter.birch"
        this_()->x.get(libbirch::make_slice(n - 1))->m->forecast(t, handler_);
        #line 178 "birch/filter/ParticleFilter.birch"
        libbirch_line_(178);
        #line 178 "birch/filter/ParticleFilter.birch"
        this_()->w.set(libbirch::make_slice(n - 1), this_()->w.get(libbirch::make_slice(n - 1)) + handler->w);
      }
    }
  }
}

#line 187 "birch/filter/ParticleFilter.birch"
void birch::type::ParticleFilter::reduce(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 187 "birch/filter/ParticleFilter.birch"
  libbirch_function_("reduce", "birch/filter/ParticleFilter.birch", 187);
  #line 188 "birch/filter/ParticleFilter.birch"
  libbirch_line_(188);
  #line 188 "birch/filter/ParticleFilter.birch"
  libbirch::tie(this_()->ess, this_()->lsum) = birch::resample_reduce(this_()->w, handler_);
  #line 189 "birch/filter/ParticleFilter.birch"
  libbirch_line_(189);
  #line 189 "birch/filter/ParticleFilter.birch"
  this_()->lnormalize = this_()->lnormalize + this_()->lsum - birch::log(birch::Real(this_()->nparticles, handler_), handler_);
}

#line 195 "birch/filter/ParticleFilter.birch"
void birch::type::ParticleFilter::resample(const birch::type::Integer& t, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 195 "birch/filter/ParticleFilter.birch"
  libbirch_function_("resample", "birch/filter/ParticleFilter.birch", 195);
  #line 196 "birch/filter/ParticleFilter.birch"
  libbirch_line_(196);
  #line 196 "birch/filter/ParticleFilter.birch"
  if (this_()->ess <= this_()->trigger * this_()->nparticles) {
    #line 197 "birch/filter/ParticleFilter.birch"
    libbirch_line_(197);
    #line 197 "birch/filter/ParticleFilter.birch"
    this_()->a = birch::resample_systematic(this_()->w, handler_);
    #line 198 "birch/filter/ParticleFilter.birch"
    libbirch_line_(198);
    #line 198 "birch/filter/ParticleFilter.birch"
    this_()->w = birch::vector(0.0, this_()->nparticles, handler_);
    #line 199 "birch/filter/ParticleFilter.birch"
    libbirch_line_(199);
    #line 199 "birch/filter/ParticleFilter.birch"
    #pragma omp parallel
    {
      #line 199 "birch/filter/ParticleFilter.birch"
      libbirch_function_("<parallel for>", "birch/filter/ParticleFilter.birch", 199);
      #pragma omp for schedule(guided)
      for (auto n = birch::type::Integer(1); n <= this_()->nparticles; ++n) {
        #line 200 "birch/filter/ParticleFilter.birch"
        libbirch_line_(200);
        #line 200 "birch/filter/ParticleFilter.birch"
        if (this_()->a.get(libbirch::make_slice(n - 1)) != n) {
          #line 201 "birch/filter/ParticleFilter.birch"
          libbirch_line_(201);
          #line 201 "birch/filter/ParticleFilter.birch"
          this_()->x.set(libbirch::make_slice(n - 1), birch::clone(this_()->x.get(libbirch::make_slice(this_()->a.get(libbirch::make_slice(n - 1)) - 1)), handler_));
        }
      }
    }
    #line 204 "birch/filter/ParticleFilter.birch"
    libbirch_line_(204);
    #line 204 "birch/filter/ParticleFilter.birch"
    birch::collect(handler_);
  } else {
    #line 207 "birch/filter/ParticleFilter.birch"
    libbirch_line_(207);
    #line 207 "birch/filter/ParticleFilter.birch"
    this_()->w = this_()->w - birch::vector(this_()->lsum - birch::log(birch::Real(this_()->nparticles, handler_), handler_), this_()->nparticles, handler_);
  }
}

#line 214 "birch/filter/ParticleFilter.birch"
void birch::type::ParticleFilter::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const birch::type::Integer& t, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 214 "birch/filter/ParticleFilter.birch"
  libbirch_function_("write", "birch/filter/ParticleFilter.birch", 214);
  #line 215 "birch/filter/ParticleFilter.birch"
  libbirch_line_(215);
  #line 215 "birch/filter/ParticleFilter.birch"
  buffer->set(birch::type::String("sample"), birch::clone(this_()->x, handler_), handler_);
  #line 216 "birch/filter/ParticleFilter.birch"
  libbirch_line_(216);
  #line 216 "birch/filter/ParticleFilter.birch"
  buffer->set(birch::type::String("lweight"), this_()->w, handler_);
  #line 217 "birch/filter/ParticleFilter.birch"
  libbirch_line_(217);
  #line 217 "birch/filter/ParticleFilter.birch"
  buffer->set(birch::type::String("lnormalize"), this_()->lnormalize, handler_);
  #line 218 "birch/filter/ParticleFilter.birch"
  libbirch_line_(218);
  #line 218 "birch/filter/ParticleFilter.birch"
  buffer->set(birch::type::String("ess"), this_()->ess, handler_);
  #line 219 "birch/filter/ParticleFilter.birch"
  libbirch_line_(219);
  #line 219 "birch/filter/ParticleFilter.birch"
  buffer->set(birch::type::String("npropagations"), this_()->npropagations, handler_);
  #line 220 "birch/filter/ParticleFilter.birch"
  libbirch_line_(220);
  #line 220 "birch/filter/ParticleFilter.birch"
  buffer->set(birch::type::String("raccept"), this_()->raccept, handler_);
}

#line 223 "birch/filter/ParticleFilter.birch"
void birch::type::ParticleFilter::read(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 223 "birch/filter/ParticleFilter.birch"
  libbirch_function_("read", "birch/filter/ParticleFilter.birch", 223);
  #line 224 "birch/filter/ParticleFilter.birch"
  libbirch_line_(224);
  #line 224 "birch/filter/ParticleFilter.birch"
  this_()->super_type_::read(buffer, handler_);
  #line 225 "birch/filter/ParticleFilter.birch"
  libbirch_line_(225);
  #line 225 "birch/filter/ParticleFilter.birch"
  libbirch::optional_assign(this_()->nsteps, buffer->get(birch::type::String("nsteps"), this_()->nsteps, handler_));
  #line 226 "birch/filter/ParticleFilter.birch"
  libbirch_line_(226);
  #line 226 "birch/filter/ParticleFilter.birch"
  libbirch::optional_assign(this_()->nforecasts, buffer->get(birch::type::String("nforecasts"), this_()->nforecasts, handler_));
  #line 227 "birch/filter/ParticleFilter.birch"
  libbirch_line_(227);
  #line 227 "birch/filter/ParticleFilter.birch"
  libbirch::optional_assign(this_()->nparticles, buffer->get(birch::type::String("nparticles"), this_()->nparticles, handler_));
  #line 228 "birch/filter/ParticleFilter.birch"
  libbirch_line_(228);
  #line 228 "birch/filter/ParticleFilter.birch"
  libbirch::optional_assign(this_()->trigger, buffer->get(birch::type::String("trigger"), this_()->trigger, handler_));
  #line 229 "birch/filter/ParticleFilter.birch"
  libbirch_line_(229);
  #line 229 "birch/filter/ParticleFilter.birch"
  libbirch::optional_assign(this_()->delayed, buffer->get(birch::type::String("delayed"), this_()->delayed, handler_));
}

#line 232 "birch/filter/ParticleFilter.birch"
void birch::type::ParticleFilter::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 232 "birch/filter/ParticleFilter.birch"
  libbirch_function_("write", "birch/filter/ParticleFilter.birch", 232);
  #line 233 "birch/filter/ParticleFilter.birch"
  libbirch_line_(233);
  #line 233 "birch/filter/ParticleFilter.birch"
  this_()->super_type_::write(buffer, handler_);
  #line 234 "birch/filter/ParticleFilter.birch"
  libbirch_line_(234);
  #line 234 "birch/filter/ParticleFilter.birch"
  buffer->set(birch::type::String("nsteps"), this_()->nsteps.get(), handler_);
  #line 235 "birch/filter/ParticleFilter.birch"
  libbirch_line_(235);
  #line 235 "birch/filter/ParticleFilter.birch"
  buffer->set(birch::type::String("nforecasts"), this_()->nforecasts, handler_);
  #line 236 "birch/filter/ParticleFilter.birch"
  libbirch_line_(236);
  #line 236 "birch/filter/ParticleFilter.birch"
  buffer->set(birch::type::String("nparticles"), this_()->nparticles, handler_);
  #line 237 "birch/filter/ParticleFilter.birch"
  libbirch_line_(237);
  #line 237 "birch/filter/ParticleFilter.birch"
  buffer->set(birch::type::String("trigger"), this_()->trigger, handler_);
  #line 238 "birch/filter/ParticleFilter.birch"
  libbirch_line_(238);
  #line 238 "birch/filter/ParticleFilter.birch"
  buffer->set(birch::type::String("delayed"), this_()->delayed, handler_);
}

#line 1 "birch/filter/ParticleFilter.birch"
birch::type::ParticleFilter* birch::type::make_ParticleFilter_() {
  #line 1 "birch/filter/ParticleFilter.birch"
  return new birch::type::ParticleFilter();
  #line 1 "birch/filter/ParticleFilter.birch"
}

