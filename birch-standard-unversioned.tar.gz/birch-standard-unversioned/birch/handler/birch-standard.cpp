#line 13 "birch/handler/Handler.birch"
birch::type::Handler::Handler(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 13 "birch/handler/Handler.birch"
    super_type_(),
    #line 17 "birch/handler/Handler.birch"
    input(),
    #line 22 "birch/handler/Handler.birch"
    output(),
    #line 27 "birch/handler/Handler.birch"
    w(0.0) {
  //
}

#line 37 "birch/handler/Handler.birch"
void birch::type::Handler::handle(const libbirch::Lazy<libbirch::Shared<birch::type::Event>>& event, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 37 "birch/handler/Handler.birch"
  libbirch_function_("handle", "birch/handler/Handler.birch", 37);
  #line 38 "birch/handler/Handler.birch"
  libbirch_line_(38);
  #line 38 "birch/handler/Handler.birch"
  if (this_()->input.query()) {
    #line 39 "birch/handler/Handler.birch"
    libbirch_line_(39);
    #line 39 "birch/handler/Handler.birch"
    this_()->doHandle(this_()->input.get()->current(handler_), event, handler_);
    #line 40 "birch/handler/Handler.birch"
    libbirch_line_(40);
    #line 40 "birch/handler/Handler.birch"
    this_()->input.get()->next(handler_);
  } else {
    #line 42 "birch/handler/Handler.birch"
    libbirch_line_(42);
    #line 42 "birch/handler/Handler.birch"
    this_()->doHandle(event, handler_);
  }
  #line 44 "birch/handler/Handler.birch"
  libbirch_line_(44);
  #line 44 "birch/handler/Handler.birch"
  if (this_()->output.query()) {
    #line 45 "birch/handler/Handler.birch"
    libbirch_line_(45);
    #line 45 "birch/handler/Handler.birch"
    this_()->output.get()->pushBack(event->record(handler_), handler_);
  }
}

#line 1 "birch/handler/MoveHandler.birch"
birch::type::MoveHandler::MoveHandler(const birch::type::Boolean& delayed, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/handler/MoveHandler.birch"
    super_type_(),
    #line 19 "birch/handler/MoveHandler.birch"
    delayed(delayed),
    #line 24 "birch/handler/MoveHandler.birch"
    z() {
  //
}

#line 26 "birch/handler/MoveHandler.birch"
void birch::type::MoveHandler::doHandle(const libbirch::Lazy<libbirch::Shared<birch::type::Event>>& event, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "birch/handler/MoveHandler.birch"
  libbirch_function_("doHandle", "birch/handler/MoveHandler.birch", 26);
  #line 28 "birch/handler/MoveHandler.birch"
  libbirch_line_(28);
  #line 28 "birch/handler/MoveHandler.birch"
  event->accept(shared_from_this_(), handler_);
}

#line 31 "birch/handler/MoveHandler.birch"
void birch::type::MoveHandler::doHandle(const libbirch::Lazy<libbirch::Shared<birch::type::Record>>& record, const libbirch::Lazy<libbirch::Shared<birch::type::Event>>& event, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 31 "birch/handler/MoveHandler.birch"
  libbirch_function_("doHandle", "birch/handler/MoveHandler.birch", 31);
  #line 33 "birch/handler/MoveHandler.birch"
  libbirch_line_(33);
  #line 33 "birch/handler/MoveHandler.birch"
  event->accept(record, shared_from_this_(), handler_);
}

#line 81 "birch/handler/MoveHandler.birch"
void birch::type::MoveHandler::doHandle(const libbirch::Lazy<libbirch::Shared<birch::type::FactorEvent>>& event, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 81 "birch/handler/MoveHandler.birch"
  libbirch_function_("doHandle", "birch/handler/MoveHandler.birch", 81);
  #line 82 "birch/handler/MoveHandler.birch"
  libbirch_line_(82);
  #line 82 "birch/handler/MoveHandler.birch"
  if (this_()->z.query()) {
    #line 83 "birch/handler/MoveHandler.birch"
    libbirch_line_(83);
    #line 83 "birch/handler/MoveHandler.birch"
    this_()->z = this_()->z.get() + event->w;
  } else {
    #line 85 "birch/handler/MoveHandler.birch"
    libbirch_line_(85);
    #line 85 "birch/handler/MoveHandler.birch"
    this_()->z = event->w;
  }
}

#line 137 "birch/handler/MoveHandler.birch"
void birch::type::MoveHandler::doHandle(const libbirch::Lazy<libbirch::Shared<birch::type::FactorRecord>>& record, const libbirch::Lazy<libbirch::Shared<birch::type::FactorEvent>>& event, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 137 "birch/handler/MoveHandler.birch"
  libbirch_function_("doHandle", "birch/handler/MoveHandler.birch", 137);
  #line 139 "birch/handler/MoveHandler.birch"
  libbirch_line_(139);
  #line 139 "birch/handler/MoveHandler.birch"
  this_()->doHandle(event, handler_);
}

#line 146 "birch/handler/MoveHandler.birch"
libbirch::Lazy<libbirch::Shared<birch::type::MoveHandler>> birch::MoveHandler(const birch::type::Boolean& delayed, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 146 "birch/handler/MoveHandler.birch"
  libbirch_function_("MoveHandler", "birch/handler/MoveHandler.birch", 146);
  #line 147 "birch/handler/MoveHandler.birch"
  libbirch_line_(147);
  #line 147 "birch/handler/MoveHandler.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::MoveHandler>>>(delayed, handler_);
}

#line 1 "birch/handler/PlayHandler.birch"
birch::type::PlayHandler::PlayHandler(const birch::type::Boolean& delayed, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/handler/PlayHandler.birch"
    super_type_(),
    #line 19 "birch/handler/PlayHandler.birch"
    delayed(delayed) {
  //
}

#line 21 "birch/handler/PlayHandler.birch"
void birch::type::PlayHandler::doHandle(const libbirch::Lazy<libbirch::Shared<birch::type::Event>>& event, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 21 "birch/handler/PlayHandler.birch"
  libbirch_function_("doHandle", "birch/handler/PlayHandler.birch", 21);
  #line 23 "birch/handler/PlayHandler.birch"
  libbirch_line_(23);
  #line 23 "birch/handler/PlayHandler.birch"
  event->accept(shared_from_this_(), handler_);
}

#line 26 "birch/handler/PlayHandler.birch"
void birch::type::PlayHandler::doHandle(const libbirch::Lazy<libbirch::Shared<birch::type::Record>>& record, const libbirch::Lazy<libbirch::Shared<birch::type::Event>>& event, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 26 "birch/handler/PlayHandler.birch"
  libbirch_function_("doHandle", "birch/handler/PlayHandler.birch", 26);
  #line 28 "birch/handler/PlayHandler.birch"
  libbirch_line_(28);
  #line 28 "birch/handler/PlayHandler.birch"
  event->accept(record, shared_from_this_(), handler_);
}

#line 56 "birch/handler/PlayHandler.birch"
void birch::type::PlayHandler::doHandle(const libbirch::Lazy<libbirch::Shared<birch::type::FactorEvent>>& event, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 56 "birch/handler/PlayHandler.birch"
  libbirch_function_("doHandle", "birch/handler/PlayHandler.birch", 56);
  #line 57 "birch/handler/PlayHandler.birch"
  libbirch_line_(57);
  #line 57 "birch/handler/PlayHandler.birch"
  this_()->w = this_()->w + event->w->value(handler_);
}

#line 98 "birch/handler/PlayHandler.birch"
void birch::type::PlayHandler::doHandle(const libbirch::Lazy<libbirch::Shared<birch::type::FactorRecord>>& record, const libbirch::Lazy<libbirch::Shared<birch::type::FactorEvent>>& event, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 98 "birch/handler/PlayHandler.birch"
  libbirch_function_("doHandle", "birch/handler/PlayHandler.birch", 98);
  #line 100 "birch/handler/PlayHandler.birch"
  libbirch_line_(100);
  #line 100 "birch/handler/PlayHandler.birch"
  this_()->w = this_()->w + event->w->value(handler_);
}

#line 107 "birch/handler/PlayHandler.birch"
libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>> birch::PlayHandler(const birch::type::Boolean& delayed, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 107 "birch/handler/PlayHandler.birch"
  libbirch_function_("PlayHandler", "birch/handler/PlayHandler.birch", 107);
  #line 108 "birch/handler/PlayHandler.birch"
  libbirch_line_(108);
  #line 108 "birch/handler/PlayHandler.birch"
  return birch::construct<libbirch::Lazy<libbirch::Shared<birch::type::PlayHandler>>>(delayed, handler_);
}

