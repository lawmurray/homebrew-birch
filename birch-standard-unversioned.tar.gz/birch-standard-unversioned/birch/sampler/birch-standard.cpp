#line 17 "birch/sampler/ConditionalParticleSampler.birch"
birch::type::ConditionalParticleSampler::ConditionalParticleSampler(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 17 "birch/sampler/ConditionalParticleSampler.birch"
    super_type_() {
  //
}

#line 18 "birch/sampler/ConditionalParticleSampler.birch"
void birch::type::ConditionalParticleSampler::sample(const libbirch::Lazy<libbirch::Shared<birch::type::ParticleFilter>>& filter, const libbirch::Lazy<libbirch::Shared<birch::type::Model>>& archetype, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "birch/sampler/ConditionalParticleSampler.birch"
  libbirch_function_("sample", "birch/sampler/ConditionalParticleSampler.birch", 18);
  #line 19 "birch/sampler/ConditionalParticleSampler.birch"
  libbirch_line_(19);
  #line 19 "birch/sampler/ConditionalParticleSampler.birch"
  auto conditionalFilter = libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::ConditionalParticleFilter>>>(filter);
  #line 20 "birch/sampler/ConditionalParticleSampler.birch"
  libbirch_line_(20);
  #line 20 "birch/sampler/ConditionalParticleSampler.birch"
  if (conditionalFilter.query()) {
    #line 21 "birch/sampler/ConditionalParticleSampler.birch"
    libbirch_line_(21);
    #line 21 "birch/sampler/ConditionalParticleSampler.birch"
    this_()->sample(conditionalFilter.get(), archetype, handler_);
  } else {
    #line 23 "birch/sampler/ConditionalParticleSampler.birch"
    libbirch_line_(23);
    #line 23 "birch/sampler/ConditionalParticleSampler.birch"
    birch::error(birch::type::String("A ConditionalParticleSampler requires a ConditionalParticleFilter."), handler_);
  }
}

#line 27 "birch/sampler/ConditionalParticleSampler.birch"
void birch::type::ConditionalParticleSampler::sample(const libbirch::Lazy<libbirch::Shared<birch::type::ParticleFilter>>& filter, const libbirch::Lazy<libbirch::Shared<birch::type::Model>>& archetype, const birch::type::Integer& t, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "birch/sampler/ConditionalParticleSampler.birch"
  libbirch_function_("sample", "birch/sampler/ConditionalParticleSampler.birch", 27);
  #line 29 "birch/sampler/ConditionalParticleSampler.birch"
  libbirch_line_(29);
  #line 29 "birch/sampler/ConditionalParticleSampler.birch"
  auto conditionalFilter = libbirch::cast<libbirch::Lazy<libbirch::Shared<birch::type::ConditionalParticleFilter>>>(filter);
  #line 30 "birch/sampler/ConditionalParticleSampler.birch"
  libbirch_line_(30);
  #line 30 "birch/sampler/ConditionalParticleSampler.birch"
  if (conditionalFilter.query()) {
    #line 31 "birch/sampler/ConditionalParticleSampler.birch"
    libbirch_line_(31);
    #line 31 "birch/sampler/ConditionalParticleSampler.birch"
    this_()->sample(conditionalFilter.get(), archetype, t, handler_);
  } else {
    #line 33 "birch/sampler/ConditionalParticleSampler.birch"
    libbirch_line_(33);
    #line 33 "birch/sampler/ConditionalParticleSampler.birch"
    birch::error(birch::type::String("A ConditionalParticleSampler requires a ConditionalParticleFilter."), handler_);
  }
}

#line 1 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
birch::type::MarginalizedParticleGibbsSampler::MarginalizedParticleGibbsSampler(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
    super_type_() {
  //
}

#line 18 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
void birch::type::MarginalizedParticleGibbsSampler::sample(const libbirch::Lazy<libbirch::Shared<birch::type::ConditionalParticleFilter>>& filter, const libbirch::Lazy<libbirch::Shared<birch::type::Model>>& archetype, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  libbirch_function_("sample", "birch/sampler/MarginalizedParticleGibbsSampler.birch", 18);
  #line 20 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  libbirch_line_(20);
  #line 20 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  filter->alreadyInitialized = false;
}

#line 23 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
void birch::type::MarginalizedParticleGibbsSampler::sample(const libbirch::Lazy<libbirch::Shared<birch::type::ConditionalParticleFilter>>& filter, const libbirch::Lazy<libbirch::Shared<birch::type::Model>>& archetype, const birch::type::Integer& n, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  libbirch_function_("sample", "birch/sampler/MarginalizedParticleGibbsSampler.birch", 23);
  #line 25 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  libbirch_line_(25);
  #line 25 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  this_()->clearDiagnostics(handler_);
  #line 26 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  libbirch_line_(26);
  #line 26 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  filter->initialize(archetype, handler_);
  #line 27 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  libbirch_line_(27);
  #line 27 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  filter->filter(handler_);
  #line 28 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  libbirch_line_(28);
  #line 28 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  this_()->pushDiagnostics(filter, handler_);
  #line 29 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  libbirch_line_(29);
  #line 29 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  for (auto t = birch::type::Integer(1); t <= filter->size(handler_); ++t) {
    #line 30 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
    libbirch_line_(30);
    #line 30 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
    filter->filter(t, handler_);
    #line 31 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
    libbirch_line_(31);
    #line 31 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
    this_()->pushDiagnostics(filter, handler_);
  }
  #line 35 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  libbirch_line_(35);
  #line 35 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  filter->b = birch::ancestor(filter->w, handler_);
  #line 36 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  libbirch_line_(36);
  #line 36 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  if (filter->b == birch::type::Integer(0)) {
    #line 37 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
    libbirch_line_(37);
    #line 37 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
    birch::error(birch::type::String("particle filter degenerated"), handler_);
  }
  #line 39 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  libbirch_line_(39);
  #line 39 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  this_()->x = filter->x.get(libbirch::make_slice(filter->b - 1))->m;
  #line 40 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  libbirch_line_(40);
  #line 40 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  this_()->w = 0.0;
  #line 42 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  libbirch_line_(42);
  #line 42 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  birch::collect(handler_);
}

#line 1 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
birch::type::MarginalizedParticleGibbsSampler* birch::type::make_MarginalizedParticleGibbsSampler_() {
  #line 1 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
  return new birch::type::MarginalizedParticleGibbsSampler();
  #line 1 "birch/sampler/MarginalizedParticleGibbsSampler.birch"
}

#line 1 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
birch::type::MarginalizedParticleImportanceSampler::MarginalizedParticleImportanceSampler(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
    super_type_() {
  //
}

#line 18 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
void birch::type::MarginalizedParticleImportanceSampler::sample(const libbirch::Lazy<libbirch::Shared<birch::type::ParticleFilter>>& filter, const libbirch::Lazy<libbirch::Shared<birch::type::Model>>& archetype, const birch::type::Integer& n, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
  libbirch_function_("sample", "birch/sampler/MarginalizedParticleImportanceSampler.birch", 18);
  #line 20 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
  libbirch_line_(20);
  #line 20 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
  this_()->clearDiagnostics(handler_);
  #line 21 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
  libbirch_line_(21);
  #line 21 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
  filter->initialize(archetype, handler_);
  #line 22 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
  libbirch_line_(22);
  #line 22 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
  filter->filter(handler_);
  #line 23 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
  libbirch_line_(23);
  #line 23 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
  this_()->pushDiagnostics(filter, handler_);
  #line 24 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
  libbirch_line_(24);
  #line 24 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
  for (auto t = birch::type::Integer(1); t <= filter->size(handler_); ++t) {
    #line 25 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
    libbirch_line_(25);
    #line 25 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
    filter->filter(t, handler_);
    #line 26 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
    libbirch_line_(26);
    #line 26 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
    this_()->pushDiagnostics(filter, handler_);
  }
  #line 30 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
  libbirch_line_(30);
  #line 30 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
  auto b = birch::ancestor(filter->w, handler_);
  #line 31 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
  libbirch_line_(31);
  #line 31 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
  if (b == birch::type::Integer(0)) {
    #line 32 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
    libbirch_line_(32);
    #line 32 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
    birch::warn(birch::type::String("particle filter degenerated, problem sample will be assigned zero weight"), handler_);
    #line 33 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
    libbirch_line_(33);
    #line 33 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
    this_()->w = -birch::inf();
  } else {
    #line 35 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
    libbirch_line_(35);
    #line 35 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
    this_()->x = filter->x.get(libbirch::make_slice(b - 1))->m;
    #line 36 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
    libbirch_line_(36);
    #line 36 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
    this_()->w = filter->lnormalize;
  }
  #line 38 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
  libbirch_line_(38);
  #line 38 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
  birch::collect(handler_);
}

#line 1 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
birch::type::MarginalizedParticleImportanceSampler* birch::type::make_MarginalizedParticleImportanceSampler_() {
  #line 1 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
  return new birch::type::MarginalizedParticleImportanceSampler();
  #line 1 "birch/sampler/MarginalizedParticleImportanceSampler.birch"
}

#line 1 "birch/sampler/ParticleGibbsSampler.birch"
birch::type::ParticleGibbsSampler::ParticleGibbsSampler(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "birch/sampler/ParticleGibbsSampler.birch"
    super_type_() {
  //
}

#line 18 "birch/sampler/ParticleGibbsSampler.birch"
void birch::type::ParticleGibbsSampler::sample(const libbirch::Lazy<libbirch::Shared<birch::type::ConditionalParticleFilter>>& filter, const libbirch::Lazy<libbirch::Shared<birch::type::Model>>& archetype, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 18 "birch/sampler/ParticleGibbsSampler.birch"
  libbirch_function_("sample", "birch/sampler/ParticleGibbsSampler.birch", 18);
  #line 20 "birch/sampler/ParticleGibbsSampler.birch"
  libbirch_line_(20);
  #line 20 "birch/sampler/ParticleGibbsSampler.birch"
  filter->alreadyInitialized = true;
}

#line 23 "birch/sampler/ParticleGibbsSampler.birch"
void birch::type::ParticleGibbsSampler::sample(const libbirch::Lazy<libbirch::Shared<birch::type::ConditionalParticleFilter>>& filter, const libbirch::Lazy<libbirch::Shared<birch::type::Model>>& archetype, const birch::type::Integer& n, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 23 "birch/sampler/ParticleGibbsSampler.birch"
  libbirch_function_("sample", "birch/sampler/ParticleGibbsSampler.birch", 23);
  #line 25 "birch/sampler/ParticleGibbsSampler.birch"
  libbirch_line_(25);
  #line 25 "birch/sampler/ParticleGibbsSampler.birch"
  this_()->clearDiagnostics(handler_);
  #line 27 "birch/sampler/ParticleGibbsSampler.birch"
  libbirch_line_(27);
  #line 27 "birch/sampler/ParticleGibbsSampler.birch"
  if (filter->r.query()) {
    #line 29 "birch/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(29);
    #line 29 "birch/sampler/ParticleGibbsSampler.birch"
    libbirch::Lazy<libbirch::Shared<birch::type::Tape<libbirch::Lazy<libbirch::Shared<birch::type::Record>>>>> r = filter->r.get();
    #line 30 "birch/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(30);
    #line 30 "birch/sampler/ParticleGibbsSampler.birch"
    libbirch::Lazy<libbirch::Shared<birch::type::Tape<libbirch::Lazy<libbirch::Shared<birch::type::Record>>>>> r_prime_;
    #line 32 "birch/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(32);
    #line 32 "birch/sampler/ParticleGibbsSampler.birch"
    auto x_prime_ = birch::clone(archetype, handler_);
    #line 33 "birch/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(33);
    #line 33 "birch/sampler/ParticleGibbsSampler.birch"
    auto handler = birch::PlayHandler(true, handler_);
    #line 34 "birch/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(34);
    #line 34 "birch/sampler/ParticleGibbsSampler.birch"
    handler->output = r_prime_;
    #line 35 "birch/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(35);
    #line 35 "birch/sampler/ParticleGibbsSampler.birch"
    {
      auto handler_ = (handler);
      #line 36 "birch/sampler/ParticleGibbsSampler.birch"
      libbirch_line_(36);
      #line 36 "birch/sampler/ParticleGibbsSampler.birch"
      x_prime_->simulate(handler_);
    }
    #line 38 "birch/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(38);
    #line 38 "birch/sampler/ParticleGibbsSampler.birch"
    auto w_prime_ = handler->w;
    #line 40 "birch/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(40);
    #line 40 "birch/sampler/ParticleGibbsSampler.birch"
    handler = birch::PlayHandler(filter->delayed, handler_);
    #line 41 "birch/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(41);
    #line 41 "birch/sampler/ParticleGibbsSampler.birch"
    handler->input = filter->r.get();
    #line 42 "birch/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(42);
    #line 42 "birch/sampler/ParticleGibbsSampler.birch"
    {
      auto handler_ = (handler);
      #line 43 "birch/sampler/ParticleGibbsSampler.birch"
      libbirch_line_(43);
      #line 43 "birch/sampler/ParticleGibbsSampler.birch"
      for (auto t = birch::type::Integer(1); t <= filter->size(handler_); ++t) {
        #line 44 "birch/sampler/ParticleGibbsSampler.birch"
        libbirch_line_(44);
        #line 44 "birch/sampler/ParticleGibbsSampler.birch"
        x_prime_->simulate(t, handler_);
      }
    }
    #line 47 "birch/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(47);
    #line 47 "birch/sampler/ParticleGibbsSampler.birch"
    w_prime_ = w_prime_ + handler->w;
    #line 49 "birch/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(49);
    #line 49 "birch/sampler/ParticleGibbsSampler.birch"
    x_prime_ = birch::clone(archetype, handler_);
    #line 50 "birch/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(50);
    #line 50 "birch/sampler/ParticleGibbsSampler.birch"
    handler = birch::PlayHandler(filter->delayed, handler_);
    #line 51 "birch/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(51);
    #line 51 "birch/sampler/ParticleGibbsSampler.birch"
    handler->input = r_prime_;
    #line 52 "birch/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(52);
    #line 52 "birch/sampler/ParticleGibbsSampler.birch"
    {
      auto handler_ = (handler);
      #line 53 "birch/sampler/ParticleGibbsSampler.birch"
      libbirch_line_(53);
      #line 53 "birch/sampler/ParticleGibbsSampler.birch"
      x_prime_->simulate(handler_);
    }
    #line 55 "birch/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(55);
    #line 55 "birch/sampler/ParticleGibbsSampler.birch"
    this_()->lnormalize->pushBack(handler->w, handler_);
    #line 56 "birch/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(56);
    #line 56 "birch/sampler/ParticleGibbsSampler.birch"
    this_()->ess->pushBack(1.0, handler_);
    #line 57 "birch/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(57);
    #line 57 "birch/sampler/ParticleGibbsSampler.birch"
    this_()->npropagations->pushBack(birch::type::Integer(1), handler_);
    #line 58 "birch/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(58);
    #line 58 "birch/sampler/ParticleGibbsSampler.birch"
    filter->r.get()->rewind(handler_);
  }
  #line 61 "birch/sampler/ParticleGibbsSampler.birch"
  libbirch_line_(61);
  #line 61 "birch/sampler/ParticleGibbsSampler.birch"
  filter->initialize(archetype, handler_);
  #line 62 "birch/sampler/ParticleGibbsSampler.birch"
  libbirch_line_(62);
  #line 62 "birch/sampler/ParticleGibbsSampler.birch"
  filter->filter(handler_);
  #line 63 "birch/sampler/ParticleGibbsSampler.birch"
  libbirch_line_(63);
  #line 63 "birch/sampler/ParticleGibbsSampler.birch"
  this_()->pushDiagnostics(filter, handler_);
  #line 64 "birch/sampler/ParticleGibbsSampler.birch"
  libbirch_line_(64);
  #line 64 "birch/sampler/ParticleGibbsSampler.birch"
  for (auto t = birch::type::Integer(1); t <= filter->size(handler_); ++t) {
    #line 65 "birch/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(65);
    #line 65 "birch/sampler/ParticleGibbsSampler.birch"
    filter->filter(t, handler_);
    #line 66 "birch/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(66);
    #line 66 "birch/sampler/ParticleGibbsSampler.birch"
    this_()->pushDiagnostics(filter, handler_);
  }
  #line 70 "birch/sampler/ParticleGibbsSampler.birch"
  libbirch_line_(70);
  #line 70 "birch/sampler/ParticleGibbsSampler.birch"
  filter->b = birch::ancestor(filter->w, handler_);
  #line 71 "birch/sampler/ParticleGibbsSampler.birch"
  libbirch_line_(71);
  #line 71 "birch/sampler/ParticleGibbsSampler.birch"
  if (filter->b == birch::type::Integer(0)) {
    #line 72 "birch/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(72);
    #line 72 "birch/sampler/ParticleGibbsSampler.birch"
    birch::error(birch::type::String("particle filter degenerated"), handler_);
  }
  #line 74 "birch/sampler/ParticleGibbsSampler.birch"
  libbirch_line_(74);
  #line 74 "birch/sampler/ParticleGibbsSampler.birch"
  this_()->x = filter->x.get(libbirch::make_slice(filter->b - 1))->m;
  #line 75 "birch/sampler/ParticleGibbsSampler.birch"
  libbirch_line_(75);
  #line 75 "birch/sampler/ParticleGibbsSampler.birch"
  this_()->w = 0.0;
  #line 77 "birch/sampler/ParticleGibbsSampler.birch"
  libbirch_line_(77);
  #line 77 "birch/sampler/ParticleGibbsSampler.birch"
  birch::collect(handler_);
}

#line 1 "birch/sampler/ParticleGibbsSampler.birch"
birch::type::ParticleGibbsSampler* birch::type::make_ParticleGibbsSampler_() {
  #line 1 "birch/sampler/ParticleGibbsSampler.birch"
  return new birch::type::ParticleGibbsSampler();
  #line 1 "birch/sampler/ParticleGibbsSampler.birch"
}

#line 17 "birch/sampler/ParticleSampler.birch"
birch::type::ParticleSampler::ParticleSampler(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 17 "birch/sampler/ParticleSampler.birch"
    super_type_(),
    #line 21 "birch/sampler/ParticleSampler.birch"
    x(),
    #line 26 "birch/sampler/ParticleSampler.birch"
    w(0.0),
    #line 31 "birch/sampler/ParticleSampler.birch"
    lnormalize(),
    #line 36 "birch/sampler/ParticleSampler.birch"
    ess(),
    #line 41 "birch/sampler/ParticleSampler.birch"
    npropagations(),
    #line 46 "birch/sampler/ParticleSampler.birch"
    raccepts(),
    #line 51 "birch/sampler/ParticleSampler.birch"
    nsamples(birch::type::Integer(1)) {
  //
}

#line 57 "birch/sampler/ParticleSampler.birch"
birch::type::Integer birch::type::ParticleSampler::size(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 57 "birch/sampler/ParticleSampler.birch"
  libbirch_function_("size", "birch/sampler/ParticleSampler.birch", 57);
  #line 58 "birch/sampler/ParticleSampler.birch"
  libbirch_line_(58);
  #line 58 "birch/sampler/ParticleSampler.birch"
  return this_()->nsamples;
}

#line 69 "birch/sampler/ParticleSampler.birch"
void birch::type::ParticleSampler::sample(const libbirch::Lazy<libbirch::Shared<birch::type::ParticleFilter>>& filter, const libbirch::Lazy<libbirch::Shared<birch::type::Model>>& archetype, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 69 "birch/sampler/ParticleSampler.birch"
  libbirch_function_("sample", "birch/sampler/ParticleSampler.birch", 69);
}

#line 88 "birch/sampler/ParticleSampler.birch"
void birch::type::ParticleSampler::clearDiagnostics(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 88 "birch/sampler/ParticleSampler.birch"
  libbirch_function_("clearDiagnostics", "birch/sampler/ParticleSampler.birch", 88);
  #line 89 "birch/sampler/ParticleSampler.birch"
  libbirch_line_(89);
  #line 89 "birch/sampler/ParticleSampler.birch"
  this_()->lnormalize->clear(handler_);
  #line 90 "birch/sampler/ParticleSampler.birch"
  libbirch_line_(90);
  #line 90 "birch/sampler/ParticleSampler.birch"
  this_()->ess->clear(handler_);
  #line 91 "birch/sampler/ParticleSampler.birch"
  libbirch_line_(91);
  #line 91 "birch/sampler/ParticleSampler.birch"
  this_()->npropagations->clear(handler_);
  #line 92 "birch/sampler/ParticleSampler.birch"
  libbirch_line_(92);
  #line 92 "birch/sampler/ParticleSampler.birch"
  this_()->raccepts->clear(handler_);
}

#line 98 "birch/sampler/ParticleSampler.birch"
void birch::type::ParticleSampler::pushDiagnostics(const libbirch::Lazy<libbirch::Shared<birch::type::ParticleFilter>>& filter, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 98 "birch/sampler/ParticleSampler.birch"
  libbirch_function_("pushDiagnostics", "birch/sampler/ParticleSampler.birch", 98);
  #line 99 "birch/sampler/ParticleSampler.birch"
  libbirch_line_(99);
  #line 99 "birch/sampler/ParticleSampler.birch"
  this_()->lnormalize->pushBack(filter->lnormalize, handler_);
  #line 100 "birch/sampler/ParticleSampler.birch"
  libbirch_line_(100);
  #line 100 "birch/sampler/ParticleSampler.birch"
  this_()->ess->pushBack(filter->ess, handler_);
  #line 101 "birch/sampler/ParticleSampler.birch"
  libbirch_line_(101);
  #line 101 "birch/sampler/ParticleSampler.birch"
  this_()->npropagations->pushBack(filter->npropagations, handler_);
  #line 102 "birch/sampler/ParticleSampler.birch"
  libbirch_line_(102);
  #line 102 "birch/sampler/ParticleSampler.birch"
  this_()->raccepts->pushBack(filter->raccept, handler_);
}

#line 108 "birch/sampler/ParticleSampler.birch"
void birch::type::ParticleSampler::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const birch::type::Integer& n, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 108 "birch/sampler/ParticleSampler.birch"
  libbirch_function_("write", "birch/sampler/ParticleSampler.birch", 108);
  #line 109 "birch/sampler/ParticleSampler.birch"
  libbirch_line_(109);
  #line 109 "birch/sampler/ParticleSampler.birch"
  buffer->set(birch::type::String("sample"), birch::clone(this_()->x.get(), handler_), handler_);
  #line 110 "birch/sampler/ParticleSampler.birch"
  libbirch_line_(110);
  #line 110 "birch/sampler/ParticleSampler.birch"
  buffer->set(birch::type::String("lweight"), this_()->w, handler_);
  #line 111 "birch/sampler/ParticleSampler.birch"
  libbirch_line_(111);
  #line 111 "birch/sampler/ParticleSampler.birch"
  buffer->set(birch::type::String("lnormalize"), this_()->lnormalize, handler_);
  #line 112 "birch/sampler/ParticleSampler.birch"
  libbirch_line_(112);
  #line 112 "birch/sampler/ParticleSampler.birch"
  buffer->set(birch::type::String("ess"), this_()->ess, handler_);
  #line 113 "birch/sampler/ParticleSampler.birch"
  libbirch_line_(113);
  #line 113 "birch/sampler/ParticleSampler.birch"
  buffer->set(birch::type::String("npropagations"), this_()->npropagations, handler_);
  #line 114 "birch/sampler/ParticleSampler.birch"
  libbirch_line_(114);
  #line 114 "birch/sampler/ParticleSampler.birch"
  buffer->set(birch::type::String("raccepts"), this_()->raccepts, handler_);
}

#line 117 "birch/sampler/ParticleSampler.birch"
void birch::type::ParticleSampler::read(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 117 "birch/sampler/ParticleSampler.birch"
  libbirch_function_("read", "birch/sampler/ParticleSampler.birch", 117);
  #line 118 "birch/sampler/ParticleSampler.birch"
  libbirch_line_(118);
  #line 118 "birch/sampler/ParticleSampler.birch"
  this_()->super_type_::read(buffer, handler_);
  #line 119 "birch/sampler/ParticleSampler.birch"
  libbirch_line_(119);
  #line 119 "birch/sampler/ParticleSampler.birch"
  libbirch::optional_assign(this_()->nsamples, buffer->get(birch::type::String("nsamples"), this_()->nsamples, handler_));
}

#line 122 "birch/sampler/ParticleSampler.birch"
void birch::type::ParticleSampler::write(const libbirch::Lazy<libbirch::Shared<birch::type::Buffer>>& buffer, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 122 "birch/sampler/ParticleSampler.birch"
  libbirch_function_("write", "birch/sampler/ParticleSampler.birch", 122);
  #line 123 "birch/sampler/ParticleSampler.birch"
  libbirch_line_(123);
  #line 123 "birch/sampler/ParticleSampler.birch"
  this_()->super_type_::write(buffer, handler_);
  #line 124 "birch/sampler/ParticleSampler.birch"
  libbirch_line_(124);
  #line 124 "birch/sampler/ParticleSampler.birch"
  buffer->set(birch::type::String("nsamples"), this_()->nsamples, handler_);
}

