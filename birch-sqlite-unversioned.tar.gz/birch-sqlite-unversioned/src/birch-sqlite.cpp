#line 3 "src/SQLite3.birch"
birch::type::SQLite3::SQLite3(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 3 "src/SQLite3.birch"
    super_type_() {
  //
}

#line 16 "src/SQLite3.birch"
void birch::type::SQLite3::open(const birch::type::String& filename, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 16 "src/SQLite3.birch"
  libbirch_function_("open", "src/SQLite3.birch", 16);
  #line 17 "src/SQLite3.birch"
assert(!this->db);
    auto res = sqlite3_open(filename.c_str(), &this->db);
    libbirch_error_msg_(res == SQLITE_OK, "sqlite3_open failed");
    }

#line 27 "src/SQLite3.birch"
void birch::type::SQLite3::close(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 27 "src/SQLite3.birch"
  libbirch_function_("close", "src/SQLite3.birch", 27);
  #line 28 "src/SQLite3.birch"
auto res = sqlite3_close(this->db);
    libbirch_error_msg_(res == SQLITE_OK, "sqlite3_close failed");
    this->db = nullptr;
    }

#line 38 "src/SQLite3.birch"
libbirch::Lazy<libbirch::Shared<birch::type::SQLite3Statement>> birch::type::SQLite3::prepare(const birch::type::String& sql, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 38 "src/SQLite3.birch"
  libbirch_function_("prepare", "src/SQLite3.birch", 38);
  #line 39 "src/SQLite3.birch"
  libbirch_line_(39);
  #line 39 "src/SQLite3.birch"
  libbirch::Lazy<libbirch::Shared<birch::type::SQLite3Statement>> stmt;
  #line 40 "src/SQLite3.birch"
auto res = sqlite3_prepare_v2(this->db, sql.c_str(), sql.length(), &stmt->stmt, nullptr);
    libbirch_error_msg_(res == SQLITE_OK, "sqlite3_prepare_v2 failed");
      #line 44 "src/SQLite3.birch"
  libbirch_line_(44);
  #line 44 "src/SQLite3.birch"
  return stmt;
}

#line 50 "src/SQLite3.birch"
void birch::type::SQLite3::exec(const birch::type::String& sql, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 50 "src/SQLite3.birch"
  libbirch_function_("exec", "src/SQLite3.birch", 50);
  #line 51 "src/SQLite3.birch"
auto res = sqlite3_exec(this->db, sql.c_str(), nullptr, nullptr, nullptr);
    libbirch_error_msg_(res == SQLITE_OK, "sqlite3_exec failed");
    }

#line 3 "src/SQLite3.birch"
birch::type::SQLite3* birch::type::make_SQLite3_() {
  #line 3 "src/SQLite3.birch"
  return new birch::type::SQLite3();
  #line 3 "src/SQLite3.birch"
}

#line 1 "src/SQLite3Statement.birch"
birch::type::SQLite3Statement::SQLite3Statement(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) :
    #line 1 "src/SQLite3Statement.birch"
    super_type_() {
  //
}

#line 15 "src/SQLite3Statement.birch"
void birch::type::SQLite3Statement::bind(const birch::type::Integer& i, const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 15 "src/SQLite3Statement.birch"
  libbirch_function_("bind", "src/SQLite3Statement.birch", 15);
  #line 16 "src/SQLite3Statement.birch"
auto res = sqlite3_bind_int64(this->stmt, i, x);
    libbirch_error_msg_(res == SQLITE_OK, "sqlite3_bind_int64 failed");
    }

#line 28 "src/SQLite3Statement.birch"
void birch::type::SQLite3Statement::bind(const birch::type::Integer& i, const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 28 "src/SQLite3Statement.birch"
  libbirch_function_("bind", "src/SQLite3Statement.birch", 28);
  #line 29 "src/SQLite3Statement.birch"
auto res = sqlite3_bind_double(this->stmt, i, x);
    libbirch_error_msg_(res == SQLITE_OK, "sqlite3_bind_double failed");
    }

#line 41 "src/SQLite3Statement.birch"
void birch::type::SQLite3Statement::bind(const birch::type::Integer& i, const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 41 "src/SQLite3Statement.birch"
  libbirch_function_("bind", "src/SQLite3Statement.birch", 41);
  #line 42 "src/SQLite3Statement.birch"
auto res = sqlite3_bind_text(this->stmt, i, x.c_str(), x.length(), SQLITE_TRANSIENT);
    libbirch_error_msg_(res == SQLITE_OK, "sqlite3_bind_text failed");
    }

#line 53 "src/SQLite3Statement.birch"
void birch::type::SQLite3Statement::bindNull(const birch::type::Integer& i, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 53 "src/SQLite3Statement.birch"
  libbirch_function_("bindNull", "src/SQLite3Statement.birch", 53);
  #line 54 "src/SQLite3Statement.birch"
auto res = sqlite3_bind_null(this->stmt, i);
    libbirch_error_msg_(res == SQLITE_OK, "sqlite3_bind_null failed");
    }

#line 74 "src/SQLite3Statement.birch"
birch::type::Boolean birch::type::SQLite3Statement::step(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 74 "src/SQLite3Statement.birch"
  libbirch_function_("step", "src/SQLite3Statement.birch", 74);
  #line 75 "src/SQLite3Statement.birch"
auto res = sqlite3_step(this->stmt);
    libbirch_error_msg_(res == SQLITE_ROW || res == SQLITE_DONE, "sqlite3_step failed");
    return (res == SQLITE_ROW);
    }

#line 85 "src/SQLite3Statement.birch"
birch::type::Integer birch::type::SQLite3Statement::columnCount(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 85 "src/SQLite3Statement.birch"
  libbirch_function_("columnCount", "src/SQLite3Statement.birch", 85);
  #line 86 "src/SQLite3Statement.birch"
return sqlite3_column_count(this->stmt);
    }

#line 98 "src/SQLite3Statement.birch"
libbirch::Optional<birch::type::Integer> birch::type::SQLite3Statement::columnInteger(const birch::type::Integer& i, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 98 "src/SQLite3Statement.birch"
  libbirch_function_("columnInteger", "src/SQLite3Statement.birch", 98);
  #line 99 "src/SQLite3Statement.birch"
if (sqlite3_column_type(this->stmt, i - 1) == SQLITE_INTEGER) {
      return (Integer)sqlite3_column_int64(this->stmt, i - 1);
    }
      #line 104 "src/SQLite3Statement.birch"
  libbirch_line_(104);
  #line 104 "src/SQLite3Statement.birch"
  return libbirch::nil;
}

#line 114 "src/SQLite3Statement.birch"
libbirch::Optional<birch::type::Real> birch::type::SQLite3Statement::columnReal(const birch::type::Integer& i, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 114 "src/SQLite3Statement.birch"
  libbirch_function_("columnReal", "src/SQLite3Statement.birch", 114);
  #line 115 "src/SQLite3Statement.birch"
if (sqlite3_column_type(this->stmt, i - 1) == SQLITE_FLOAT) {
      return sqlite3_column_double(this->stmt, i - 1);
    }
      #line 120 "src/SQLite3Statement.birch"
  libbirch_line_(120);
  #line 120 "src/SQLite3Statement.birch"
  return libbirch::cast<birch::type::Real>(this_()->columnInteger(i, handler_));
}

#line 130 "src/SQLite3Statement.birch"
libbirch::Optional<birch::type::String> birch::type::SQLite3Statement::columnString(const birch::type::Integer& i, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 130 "src/SQLite3Statement.birch"
  libbirch_function_("columnString", "src/SQLite3Statement.birch", 130);
  #line 131 "src/SQLite3Statement.birch"
if (sqlite3_column_type(this->stmt, i - 1) == SQLITE_TEXT) {
      return std::string(reinterpret_cast<const char*>(sqlite3_column_text(this->stmt, i - 1)));
    }
      #line 136 "src/SQLite3Statement.birch"
  libbirch_line_(136);
  #line 136 "src/SQLite3Statement.birch"
  return libbirch::nil;
}

#line 144 "src/SQLite3Statement.birch"
birch::type::Boolean birch::type::SQLite3Statement::columnNull(const birch::type::Integer& i, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 144 "src/SQLite3Statement.birch"
  libbirch_function_("columnNull", "src/SQLite3Statement.birch", 144);
  #line 145 "src/SQLite3Statement.birch"
return sqlite3_column_type(this->stmt, i - 1) == SQLITE_NULL;
    }

#line 153 "src/SQLite3Statement.birch"
void birch::type::SQLite3Statement::reset(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 153 "src/SQLite3Statement.birch"
  libbirch_function_("reset", "src/SQLite3Statement.birch", 153);
  #line 154 "src/SQLite3Statement.birch"
auto res = sqlite3_reset(this->stmt);
    libbirch_error_msg_(res == SQLITE_OK, "sqlite3_reset failed");
    }

#line 163 "src/SQLite3Statement.birch"
void birch::type::SQLite3Statement::finalize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_) {
  #line 163 "src/SQLite3Statement.birch"
  libbirch_function_("finalize", "src/SQLite3Statement.birch", 163);
  #line 164 "src/SQLite3Statement.birch"
auto res = sqlite3_finalize(this->stmt);
    libbirch_error_msg_(res == SQLITE_OK, "sqlite3_finalize failed");
    }

#line 1 "src/SQLite3Statement.birch"
birch::type::SQLite3Statement* birch::type::make_SQLite3Statement_() {
  #line 1 "src/SQLite3Statement.birch"
  return new birch::type::SQLite3Statement();
  #line 1 "src/SQLite3Statement.birch"
}

