#ifndef BI_BIRCH_SQLITE_HPP
#define BI_BIRCH_SQLITE_HPP

#include "libbirch.hpp"

#include "birch-standard.hpp"
#include <sqlite3.h>

namespace birch {
namespace type {
class SQLite3;
class SQLite3Statement;


#line 3 "src/SQLite3.birch"
class SQLite3 : public Object {
public:
  #line 3 "src/SQLite3.birch"
  using class_type_ = SQLite3;
  #line 3 "src/SQLite3.birch"
  using this_type_ = class_type_;
  #line 3 "src/SQLite3.birch"
  using super_type_ = Object;

  #line 3 "src/SQLite3.birch"
  using super_type_::operator=;
  
  #line 3 "src/SQLite3.birch"
  SQLite3(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);

sqlite3* db = nullptr;
    #line 16 "src/SQLite3.birch"
  virtual void open(const birch::type::String& filename, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 27 "src/SQLite3.birch"
  virtual void close(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 38 "src/SQLite3.birch"
  virtual libbirch::Lazy<libbirch::Shared<birch::type::SQLite3Statement>> prepare(const birch::type::String& sql, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 50 "src/SQLite3.birch"
  virtual void exec(const birch::type::String& sql, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  
  #line 3 "src/SQLite3.birch"
  LIBBIRCH_CLASS(SQLite3, Object)
  #line 3 "src/SQLite3.birch"
  LIBBIRCH_MEMBERS()
};

#line 3 "src/SQLite3.birch"
extern "C" birch::type::SQLite3* make_SQLite3_();

#line 1 "src/SQLite3Statement.birch"
class SQLite3Statement : public Object {
public:
  #line 1 "src/SQLite3Statement.birch"
  using class_type_ = SQLite3Statement;
  #line 1 "src/SQLite3Statement.birch"
  using this_type_ = class_type_;
  #line 1 "src/SQLite3Statement.birch"
  using super_type_ = Object;

  #line 1 "src/SQLite3Statement.birch"
  using super_type_::operator=;
  
  #line 1 "src/SQLite3Statement.birch"
  SQLite3Statement(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);

sqlite3_stmt* stmt = nullptr;
    #line 15 "src/SQLite3Statement.birch"
  virtual void bind(const birch::type::Integer& i, const birch::type::Integer& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 28 "src/SQLite3Statement.birch"
  virtual void bind(const birch::type::Integer& i, const birch::type::Real& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 41 "src/SQLite3Statement.birch"
  virtual void bind(const birch::type::Integer& i, const birch::type::String& x, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 53 "src/SQLite3Statement.birch"
  virtual void bindNull(const birch::type::Integer& i, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 74 "src/SQLite3Statement.birch"
  virtual birch::type::Boolean step(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 85 "src/SQLite3Statement.birch"
  virtual birch::type::Integer columnCount(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 98 "src/SQLite3Statement.birch"
  virtual libbirch::Optional<birch::type::Integer> columnInteger(const birch::type::Integer& i, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 114 "src/SQLite3Statement.birch"
  virtual libbirch::Optional<birch::type::Real> columnReal(const birch::type::Integer& i, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 130 "src/SQLite3Statement.birch"
  virtual libbirch::Optional<birch::type::String> columnString(const birch::type::Integer& i, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 144 "src/SQLite3Statement.birch"
  virtual birch::type::Boolean columnNull(const birch::type::Integer& i, const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 153 "src/SQLite3Statement.birch"
  virtual void reset(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  #line 163 "src/SQLite3Statement.birch"
  virtual void finalize(const libbirch::Lazy<libbirch::Shared<birch::type::Handler>>& handler_ = nullptr);
  
  #line 1 "src/SQLite3Statement.birch"
  LIBBIRCH_CLASS(SQLite3Statement, Object)
  #line 1 "src/SQLite3Statement.birch"
  LIBBIRCH_MEMBERS()
};

#line 1 "src/SQLite3Statement.birch"
extern "C" birch::type::SQLite3Statement* make_SQLite3Statement_();


}

}

#endif
