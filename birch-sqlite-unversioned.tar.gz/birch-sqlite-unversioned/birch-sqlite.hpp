#ifndef BI_BIRCH_SQLITE_HPP
#define BI_BIRCH_SQLITE_HPP

#include "libbirch.hpp"

#include "birch-standard.hpp"

#include <sqlite3.h>

namespace birch {
namespace type {
class SQLite3;
class SQLite3Statement;


#line 3 "src/SQLite3.birch"
class SQLite3 : public Object {
public:
  #line 3 "src/SQLite3.birch"
  LIBBIRCH_CLASS(SQLite3, Object)
  #line 3 "src/SQLite3.birch"
  #line 3 "src/SQLite3.birch"
  using base_type_::operator=;
  
  #line 3 "src/SQLite3.birch"
  SQLite3();


  sqlite3* db = nullptr;
    #line 16 "src/SQLite3.birch"
  virtual void open(const birch::type::String& filename);
  #line 27 "src/SQLite3.birch"
  virtual void close();
  #line 38 "src/SQLite3.birch"
  virtual libbirch::Shared<birch::type::SQLite3Statement> prepare(const birch::type::String& sql);
  #line 50 "src/SQLite3.birch"
  virtual void exec(const birch::type::String& sql);
};

#line 3 "src/SQLite3.birch"
extern "C" birch::type::SQLite3* make_SQLite3_();

#line 1 "src/SQLite3Statement.birch"
class SQLite3Statement : public Object {
public:
  #line 1 "src/SQLite3Statement.birch"
  LIBBIRCH_CLASS(SQLite3Statement, Object)
  #line 1 "src/SQLite3Statement.birch"
  #line 1 "src/SQLite3Statement.birch"
  using base_type_::operator=;
  
  #line 1 "src/SQLite3Statement.birch"
  SQLite3Statement();


  sqlite3_stmt* stmt = nullptr;
    #line 15 "src/SQLite3Statement.birch"
  virtual void bind(const birch::type::Integer& i, const birch::type::Integer& x);
  #line 28 "src/SQLite3Statement.birch"
  virtual void bind(const birch::type::Integer& i, const birch::type::Real& x);
  #line 41 "src/SQLite3Statement.birch"
  virtual void bind(const birch::type::Integer& i, const birch::type::String& x);
  #line 53 "src/SQLite3Statement.birch"
  virtual void bindNull(const birch::type::Integer& i);
  #line 74 "src/SQLite3Statement.birch"
  virtual birch::type::Boolean step();
  #line 85 "src/SQLite3Statement.birch"
  virtual birch::type::Integer columnCount();
  #line 98 "src/SQLite3Statement.birch"
  virtual std::optional<birch::type::Integer> columnInteger(const birch::type::Integer& i);
  #line 114 "src/SQLite3Statement.birch"
  virtual std::optional<birch::type::Real> columnReal(const birch::type::Integer& i);
  #line 130 "src/SQLite3Statement.birch"
  virtual std::optional<birch::type::String> columnString(const birch::type::Integer& i);
  #line 144 "src/SQLite3Statement.birch"
  virtual birch::type::Boolean columnNull(const birch::type::Integer& i);
  #line 153 "src/SQLite3Statement.birch"
  virtual void reset();
  #line 163 "src/SQLite3Statement.birch"
  virtual void finalize();
};

#line 1 "src/SQLite3Statement.birch"
extern "C" birch::type::SQLite3Statement* make_SQLite3Statement_();


}

}

#endif
