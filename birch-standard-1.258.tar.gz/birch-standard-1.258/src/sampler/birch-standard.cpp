#line 1 "src/sampler/ConditionalParticleSampler.birch"
birch::type::ConditionalParticleSampler::ConditionalParticleSampler() :
    #line 1 "src/sampler/ConditionalParticleSampler.birch"
    base_type_() {
  //
}

#line 14 "src/sampler/ConditionalParticleSampler.birch"
void birch::type::ConditionalParticleSampler::sample(const libbirch::Shared<birch::type::ParticleFilter>& filter, const libbirch::Shared<birch::type::Model>& model, const libbirch::Shared<birch::type::Buffer>& input) {
  #line 14 "src/sampler/ConditionalParticleSampler.birch"
  libbirch_function_("sample", "src/sampler/ConditionalParticleSampler.birch", 14);
  #line 16 "src/sampler/ConditionalParticleSampler.birch"
  libbirch_line_(16);
  #line 16 "src/sampler/ConditionalParticleSampler.birch"
  auto c = libbirch::cast<libbirch::Shared<birch::type::ConditionalParticleFilter>>(filter);
  #line 17 "src/sampler/ConditionalParticleSampler.birch"
  libbirch_line_(17);
  #line 17 "src/sampler/ConditionalParticleSampler.birch"
  if (!(c.has_value())) {
    #line 18 "src/sampler/ConditionalParticleSampler.birch"
    libbirch_line_(18);
    #line 18 "src/sampler/ConditionalParticleSampler.birch"
    birch::error(birch::type::String("A ConditionalParticleSampler requires a ConditionalParticleFilter."));
  }
  #line 20 "src/sampler/ConditionalParticleSampler.birch"
  libbirch_line_(20);
  #line 20 "src/sampler/ConditionalParticleSampler.birch"
  return this->sample(c.value(), model, input);
}

#line 23 "src/sampler/ConditionalParticleSampler.birch"
void birch::type::ConditionalParticleSampler::sample(const libbirch::Shared<birch::type::ParticleFilter>& filter, const birch::type::Integer& t, const libbirch::Shared<birch::type::Buffer>& input) {
  #line 23 "src/sampler/ConditionalParticleSampler.birch"
  libbirch_function_("sample", "src/sampler/ConditionalParticleSampler.birch", 23);
  #line 25 "src/sampler/ConditionalParticleSampler.birch"
  libbirch_line_(25);
  #line 25 "src/sampler/ConditionalParticleSampler.birch"
  auto c = libbirch::cast<libbirch::Shared<birch::type::ConditionalParticleFilter>>(filter);
  #line 26 "src/sampler/ConditionalParticleSampler.birch"
  libbirch_line_(26);
  #line 26 "src/sampler/ConditionalParticleSampler.birch"
  if (!(c.has_value())) {
    #line 27 "src/sampler/ConditionalParticleSampler.birch"
    libbirch_line_(27);
    #line 27 "src/sampler/ConditionalParticleSampler.birch"
    birch::error(birch::type::String("A ConditionalParticleSampler requires a ConditionalParticleFilter."));
  }
  #line 29 "src/sampler/ConditionalParticleSampler.birch"
  libbirch_line_(29);
  #line 29 "src/sampler/ConditionalParticleSampler.birch"
  return this->sample(c.value(), t, input);
}

#line 32 "src/sampler/ConditionalParticleSampler.birch"
std::tuple<libbirch::Shared<birch::type::Model>, birch::type::Real> birch::type::ConditionalParticleSampler::draw(const libbirch::Shared<birch::type::ParticleFilter>& filter) {
  #line 32 "src/sampler/ConditionalParticleSampler.birch"
  libbirch_function_("draw", "src/sampler/ConditionalParticleSampler.birch", 32);
  #line 33 "src/sampler/ConditionalParticleSampler.birch"
  libbirch_line_(33);
  #line 33 "src/sampler/ConditionalParticleSampler.birch"
  auto c = libbirch::cast<libbirch::Shared<birch::type::ConditionalParticleFilter>>(filter);
  #line 34 "src/sampler/ConditionalParticleSampler.birch"
  libbirch_line_(34);
  #line 34 "src/sampler/ConditionalParticleSampler.birch"
  if (!(c.has_value())) {
    #line 35 "src/sampler/ConditionalParticleSampler.birch"
    libbirch_line_(35);
    #line 35 "src/sampler/ConditionalParticleSampler.birch"
    birch::error(birch::type::String("A ConditionalParticleSampler requires a ConditionalParticleFilter."));
  }
  #line 37 "src/sampler/ConditionalParticleSampler.birch"
  libbirch_line_(37);
  #line 37 "src/sampler/ConditionalParticleSampler.birch"
  return this->draw(c.value());
}

#line 47 "src/sampler/ConditionalParticleSampler.birch"
void birch::type::ConditionalParticleSampler::sample(const libbirch::Shared<birch::type::ConditionalParticleFilter>& filter, const libbirch::Shared<birch::type::Model>& model, const libbirch::Shared<birch::type::Buffer>& input) {
  #line 47 "src/sampler/ConditionalParticleSampler.birch"
  libbirch_function_("sample", "src/sampler/ConditionalParticleSampler.birch", 47);
  #line 48 "src/sampler/ConditionalParticleSampler.birch"
  libbirch_line_(48);
  #line 48 "src/sampler/ConditionalParticleSampler.birch"
  filter->filter(model, input);
}

#line 58 "src/sampler/ConditionalParticleSampler.birch"
void birch::type::ConditionalParticleSampler::sample(const libbirch::Shared<birch::type::ConditionalParticleFilter>& filter, const birch::type::Integer& t, const libbirch::Shared<birch::type::Buffer>& input) {
  #line 58 "src/sampler/ConditionalParticleSampler.birch"
  libbirch_function_("sample", "src/sampler/ConditionalParticleSampler.birch", 58);
  #line 59 "src/sampler/ConditionalParticleSampler.birch"
  libbirch_line_(59);
  #line 59 "src/sampler/ConditionalParticleSampler.birch"
  filter->filter(t, input);
}

#line 65 "src/sampler/ConditionalParticleSampler.birch"
std::tuple<libbirch::Shared<birch::type::Model>, birch::type::Real> birch::type::ConditionalParticleSampler::draw(const libbirch::Shared<birch::type::ConditionalParticleFilter>& filter) {
  #line 65 "src/sampler/ConditionalParticleSampler.birch"
  libbirch_function_("draw", "src/sampler/ConditionalParticleSampler.birch", 65);
  #line 66 "src/sampler/ConditionalParticleSampler.birch"
  libbirch_line_(66);
  #line 66 "src/sampler/ConditionalParticleSampler.birch"
  return std::make_tuple(filter->x(filter->b)->m, 0.0);
}

#line 1 "src/sampler/ConditionalParticleSampler.birch"
birch::type::ConditionalParticleSampler* birch::type::make_ConditionalParticleSampler_() {
  #line 1 "src/sampler/ConditionalParticleSampler.birch"
  return new birch::type::ConditionalParticleSampler();
  #line 1 "src/sampler/ConditionalParticleSampler.birch"
}

#line 1 "src/sampler/ParticleGibbsSampler.birch"
birch::type::ParticleGibbsSampler::ParticleGibbsSampler() :
    #line 1 "src/sampler/ParticleGibbsSampler.birch"
    base_type_(),
    #line 17 "src/sampler/ParticleGibbsSampler.birch"
    ancestor(false) {
  //
}

#line 19 "src/sampler/ParticleGibbsSampler.birch"
void birch::type::ParticleGibbsSampler::sample(const libbirch::Shared<birch::type::ConditionalParticleFilter>& filter, const libbirch::Shared<birch::type::Model>& model, const libbirch::Shared<birch::type::Buffer>& input) {
  #line 19 "src/sampler/ParticleGibbsSampler.birch"
  libbirch_function_("sample", "src/sampler/ParticleGibbsSampler.birch", 19);
  #line 21 "src/sampler/ParticleGibbsSampler.birch"
  libbirch_line_(21);
  #line 21 "src/sampler/ParticleGibbsSampler.birch"
  if (filter->r.has_value()) {
    #line 23 "src/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(23);
    #line 23 "src/sampler/ParticleGibbsSampler.birch"
    libbirch::Shared<birch::type::Tape<libbirch::Shared<birch::type::Record>>> r = filter->r.value();
    #line 24 "src/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(24);
    #line 24 "src/sampler/ParticleGibbsSampler.birch"
    libbirch::Shared<birch::type::Tape<libbirch::Shared<birch::type::Record>>> r_prime_ = libbirch::make<libbirch::Shared<birch::type::Tape<libbirch::Shared<birch::type::Record>>>>();
    #line 26 "src/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(26);
    #line 26 "src/sampler/ParticleGibbsSampler.birch"
    auto x_prime_ = birch::copy(model);
    #line 27 "src/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(27);
    #line 27 "src/sampler/ParticleGibbsSampler.birch"
    auto handler = birch::PlayHandler(true);
    #line 28 "src/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(28);
    #line 28 "src/sampler/ParticleGibbsSampler.birch"
    handler->output = r_prime_;
    #line 29 "src/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(29);
    #line 29 "src/sampler/ParticleGibbsSampler.birch"
    {
      auto handler_ = birch::swap_handler((handler));
      #line 30 "src/sampler/ParticleGibbsSampler.birch"
      libbirch_line_(30);
      #line 30 "src/sampler/ParticleGibbsSampler.birch"
      x_prime_->read(input);
      #line 31 "src/sampler/ParticleGibbsSampler.birch"
      libbirch_line_(31);
      #line 31 "src/sampler/ParticleGibbsSampler.birch"
      x_prime_->simulate();
      birch::set_handler(handler_);
    }
    #line 33 "src/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(33);
    #line 33 "src/sampler/ParticleGibbsSampler.birch"
    auto w_prime_ = handler->w;
    #line 35 "src/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(35);
    #line 35 "src/sampler/ParticleGibbsSampler.birch"
    handler = birch::PlayHandler(filter->delayed);
    #line 36 "src/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(36);
    #line 36 "src/sampler/ParticleGibbsSampler.birch"
    handler->input = filter->r.value();
    #line 37 "src/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(37);
    #line 37 "src/sampler/ParticleGibbsSampler.birch"
    {
      auto handler_ = birch::swap_handler((handler));
      #line 38 "src/sampler/ParticleGibbsSampler.birch"
      libbirch_line_(38);
      #line 38 "src/sampler/ParticleGibbsSampler.birch"
      for (auto t = birch::type::Integer(1); t <= filter->r.value()->size(); ++t) {
        #line 40 "src/sampler/ParticleGibbsSampler.birch"
        libbirch_line_(40);
        #line 40 "src/sampler/ParticleGibbsSampler.birch"
        x_prime_->simulate(t);
      }
      birch::set_handler(handler_);
    }
    #line 43 "src/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(43);
    #line 43 "src/sampler/ParticleGibbsSampler.birch"
    w_prime_ = w_prime_ + handler->w;
    #line 45 "src/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(45);
    #line 45 "src/sampler/ParticleGibbsSampler.birch"
    x_prime_ = birch::copy(model);
    #line 46 "src/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(46);
    #line 46 "src/sampler/ParticleGibbsSampler.birch"
    handler = birch::PlayHandler(filter->delayed);
    #line 47 "src/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(47);
    #line 47 "src/sampler/ParticleGibbsSampler.birch"
    handler->input = r_prime_;
    #line 48 "src/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(48);
    #line 48 "src/sampler/ParticleGibbsSampler.birch"
    {
      auto handler_ = birch::swap_handler((handler));
      #line 50 "src/sampler/ParticleGibbsSampler.birch"
      libbirch_line_(50);
      #line 50 "src/sampler/ParticleGibbsSampler.birch"
      x_prime_->simulate();
      birch::set_handler(handler_);
    }
    #line 52 "src/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(52);
    #line 52 "src/sampler/ParticleGibbsSampler.birch"
    filter->r.value()->rewind();
  }
  #line 54 "src/sampler/ParticleGibbsSampler.birch"
  libbirch_line_(54);
  #line 54 "src/sampler/ParticleGibbsSampler.birch"
  this->base_type_::sample(filter, model, input);
}

#line 57 "src/sampler/ParticleGibbsSampler.birch"
void birch::type::ParticleGibbsSampler::sample(const libbirch::Shared<birch::type::ConditionalParticleFilter>& filter, const birch::type::Integer& t, const libbirch::Shared<birch::type::Buffer>& input) {
  #line 57 "src/sampler/ParticleGibbsSampler.birch"
  libbirch_function_("sample", "src/sampler/ParticleGibbsSampler.birch", 57);
  #line 59 "src/sampler/ParticleGibbsSampler.birch"
  libbirch_line_(59);
  #line 59 "src/sampler/ParticleGibbsSampler.birch"
  if (filter->r.has_value() && this->ancestor) {
    #line 60 "src/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(60);
    #line 60 "src/sampler/ParticleGibbsSampler.birch"
    auto w_prime_ = filter->w;
    #line 61 "src/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(61);
    #line 61 "src/sampler/ParticleGibbsSampler.birch"
    #pragma omp parallel
    {
      #line 61 "src/sampler/ParticleGibbsSampler.birch"
      libbirch_function_("<parallel for>", "src/sampler/ParticleGibbsSampler.birch", 61);
      #pragma omp for schedule(guided)
      for (auto n = birch::type::Integer(1); n <= filter->nparticles; ++n) {
        #line 62 "src/sampler/ParticleGibbsSampler.birch"
        libbirch_line_(62);
        #line 62 "src/sampler/ParticleGibbsSampler.birch"
        auto x_prime_ = birch::copy(filter->x(n));
        #line 63 "src/sampler/ParticleGibbsSampler.birch"
        libbirch_line_(63);
        #line 63 "src/sampler/ParticleGibbsSampler.birch"
        auto r_prime_ = birch::copy(filter->r.value());
        #line 64 "src/sampler/ParticleGibbsSampler.birch"
        libbirch_line_(64);
        #line 64 "src/sampler/ParticleGibbsSampler.birch"
        auto handler = birch::PlayHandler(filter->delayed);
        #line 65 "src/sampler/ParticleGibbsSampler.birch"
        libbirch_line_(65);
        #line 65 "src/sampler/ParticleGibbsSampler.birch"
        handler->input = r_prime_;
        #line 66 "src/sampler/ParticleGibbsSampler.birch"
        libbirch_line_(66);
        #line 66 "src/sampler/ParticleGibbsSampler.birch"
        {
          auto handler_ = birch::swap_handler((handler));
          #line 67 "src/sampler/ParticleGibbsSampler.birch"
          libbirch_line_(67);
          #line 67 "src/sampler/ParticleGibbsSampler.birch"
          x_prime_->m->read(t, input);
          #line 68 "src/sampler/ParticleGibbsSampler.birch"
          libbirch_line_(68);
          #line 68 "src/sampler/ParticleGibbsSampler.birch"
          x_prime_->m->simulate(t);
          #line 69 "src/sampler/ParticleGibbsSampler.birch"
          libbirch_line_(69);
          #line 69 "src/sampler/ParticleGibbsSampler.birch"
          w_prime_(n) = w_prime_(n) + handler->w;
          birch::set_handler(handler_);
        }
      }
    }
    #line 72 "src/sampler/ParticleGibbsSampler.birch"
    libbirch_line_(72);
    #line 72 "src/sampler/ParticleGibbsSampler.birch"
    filter->b = birch::ancestor(w_prime_);
  }
  #line 74 "src/sampler/ParticleGibbsSampler.birch"
  libbirch_line_(74);
  #line 74 "src/sampler/ParticleGibbsSampler.birch"
  this->base_type_::sample(filter, t, input);
}

#line 77 "src/sampler/ParticleGibbsSampler.birch"
void birch::type::ParticleGibbsSampler::read(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 77 "src/sampler/ParticleGibbsSampler.birch"
  libbirch_function_("read", "src/sampler/ParticleGibbsSampler.birch", 77);
  #line 78 "src/sampler/ParticleGibbsSampler.birch"
  libbirch_line_(78);
  #line 78 "src/sampler/ParticleGibbsSampler.birch"
  this->base_type_::read(buffer);
  #line 79 "src/sampler/ParticleGibbsSampler.birch"
  libbirch_line_(79);
  #line 79 "src/sampler/ParticleGibbsSampler.birch"
    libbirch::optional_assign(this->ancestor, buffer->get<birch::type::Boolean>(birch::type::String("ancestor")));
;
}

#line 1 "src/sampler/ParticleGibbsSampler.birch"
birch::type::ParticleGibbsSampler* birch::type::make_ParticleGibbsSampler_() {
  #line 1 "src/sampler/ParticleGibbsSampler.birch"
  return new birch::type::ParticleGibbsSampler();
  #line 1 "src/sampler/ParticleGibbsSampler.birch"
}

#line 1 "src/sampler/ParticleSampler.birch"
birch::type::ParticleSampler::ParticleSampler() :
    #line 1 "src/sampler/ParticleSampler.birch"
    base_type_() {
  //
}

#line 21 "src/sampler/ParticleSampler.birch"
void birch::type::ParticleSampler::sample(const libbirch::Shared<birch::type::ParticleFilter>& filter, const libbirch::Shared<birch::type::Model>& model, const libbirch::Shared<birch::type::Buffer>& input) {
  #line 21 "src/sampler/ParticleSampler.birch"
  libbirch_function_("sample", "src/sampler/ParticleSampler.birch", 21);
  #line 22 "src/sampler/ParticleSampler.birch"
  libbirch_line_(22);
  #line 22 "src/sampler/ParticleSampler.birch"
  filter->filter(model, input);
}

#line 32 "src/sampler/ParticleSampler.birch"
void birch::type::ParticleSampler::sample(const libbirch::Shared<birch::type::ParticleFilter>& filter, const birch::type::Integer& t, const libbirch::Shared<birch::type::Buffer>& input) {
  #line 32 "src/sampler/ParticleSampler.birch"
  libbirch_function_("sample", "src/sampler/ParticleSampler.birch", 32);
  #line 33 "src/sampler/ParticleSampler.birch"
  libbirch_line_(33);
  #line 33 "src/sampler/ParticleSampler.birch"
  filter->filter(t, input);
}

#line 39 "src/sampler/ParticleSampler.birch"
std::tuple<libbirch::Shared<birch::type::Model>, birch::type::Real> birch::type::ParticleSampler::draw(const libbirch::Shared<birch::type::ParticleFilter>& filter) {
  #line 39 "src/sampler/ParticleSampler.birch"
  libbirch_function_("draw", "src/sampler/ParticleSampler.birch", 39);
  #line 40 "src/sampler/ParticleSampler.birch"
  libbirch_line_(40);
  #line 40 "src/sampler/ParticleSampler.birch"
  return std::make_tuple(filter->x(filter->b)->m, filter->lnormalize);
}

#line 1 "src/sampler/ParticleSampler.birch"
birch::type::ParticleSampler* birch::type::make_ParticleSampler_() {
  #line 1 "src/sampler/ParticleSampler.birch"
  return new birch::type::ParticleSampler();
  #line 1 "src/sampler/ParticleSampler.birch"
}

