#line 8 "src/primitive/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::resample_systematic(const libbirch::DefaultArray<birch::type::Real,1>& w) {
  #line 8 "src/primitive/resample.birch"
  libbirch_function_("resample_systematic", "src/primitive/resample.birch", 8);
  #line 9 "src/primitive/resample.birch"
  libbirch_line_(9);
  #line 9 "src/primitive/resample.birch"
  return birch::cumulative_offspring_to_ancestors_permute(birch::systematic_cumulative_offspring(birch::cumulative_weights(w)));
}

#line 20 "src/primitive/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::resample_multinomial(const libbirch::DefaultArray<birch::type::Real,1>& w) {
  #line 20 "src/primitive/resample.birch"
  libbirch_function_("resample_multinomial", "src/primitive/resample.birch", 20);
  #line 21 "src/primitive/resample.birch"
  libbirch_line_(21);
  #line 21 "src/primitive/resample.birch"
  return birch::offspring_to_ancestors_permute(birch::simulate_multinomial(birch::length(w), birch::norm_exp(w)));
}

#line 34 "src/primitive/resample.birch"
std::tuple<libbirch::DefaultArray<birch::type::Integer,1>, birch::type::Integer> birch::conditional_resample_multinomial(const libbirch::DefaultArray<birch::type::Real,1>& w, const birch::type::Integer& b) {
  #line 34 "src/primitive/resample.birch"
  libbirch_function_("conditional_resample_multinomial", "src/primitive/resample.birch", 34);
  #line 36 "src/primitive/resample.birch"
  libbirch_line_(36);
  #line 36 "src/primitive/resample.birch"
  auto N = birch::length(w);
  #line 37 "src/primitive/resample.birch"
  libbirch_line_(37);
  #line 37 "src/primitive/resample.birch"
  auto o = birch::simulate_multinomial(N - birch::type::Integer(1), birch::norm_exp(w));
  #line 38 "src/primitive/resample.birch"
  libbirch_line_(38);
  #line 38 "src/primitive/resample.birch"
  o(b) = o(b) + birch::type::Integer(1);
  #line 39 "src/primitive/resample.birch"
  libbirch_line_(39);
  #line 39 "src/primitive/resample.birch"
  auto a = birch::offspring_to_ancestors_permute(o);
  #line 40 "src/primitive/resample.birch"
  libbirch_line_(40);
  #line 40 "src/primitive/resample.birch"
  libbirch_assert_(a(b) == b);
  #line 41 "src/primitive/resample.birch"
  libbirch_line_(41);
  #line 41 "src/primitive/resample.birch"
  return std::make_tuple(a, b);
}

#line 47 "src/primitive/resample.birch"
birch::type::Real birch::log_sum_exp(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 47 "src/primitive/resample.birch"
  libbirch_function_("log_sum_exp", "src/primitive/resample.birch", 47);
  #line 48 "src/primitive/resample.birch"
  libbirch_line_(48);
  #line 48 "src/primitive/resample.birch"
  libbirch_assert_(birch::length(x) > birch::type::Integer(0));
  #line 49 "src/primitive/resample.birch"
  libbirch_line_(49);
  #line 49 "src/primitive/resample.birch"
  auto mx = birch::max(x);
  #line 50 "src/primitive/resample.birch"
  libbirch_line_(50);
  #line 50 "src/primitive/resample.birch"
  auto r = 0.0;
  #line 51 "src/primitive/resample.birch"
  libbirch_line_(51);
  #line 51 "src/primitive/resample.birch"
  for (auto n = birch::type::Integer(1); n <= birch::length(x); ++n) {
    #line 52 "src/primitive/resample.birch"
    libbirch_line_(52);
    #line 52 "src/primitive/resample.birch"
    r = r + birch::nan_exp(x(n) - mx);
  }
  #line 54 "src/primitive/resample.birch"
  libbirch_line_(54);
  #line 54 "src/primitive/resample.birch"
  return mx + birch::log(r);
}

#line 60 "src/primitive/resample.birch"
birch::type::Real birch::log_sum(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 60 "src/primitive/resample.birch"
  libbirch_function_("log_sum", "src/primitive/resample.birch", 60);
  #line 61 "src/primitive/resample.birch"
  libbirch_line_(61);
  #line 61 "src/primitive/resample.birch"
  return birch::transform_reduce<birch::type::Real>(x, 0.0, std::function<birch::type::Real(birch::type::Real,birch::type::Real)>([=](const birch::type::Real& x, const birch::type::Real& y) {
    #line 62 "src/primitive/resample.birch"
    libbirch_line_(62);
    #line 62 "src/primitive/resample.birch"
    return x + y;
  }), std::function<birch::type::Real(birch::type::Real)>([=](const birch::type::Real& x) {
    #line 62 "src/primitive/resample.birch"
    libbirch_line_(62);
    #line 62 "src/primitive/resample.birch"
    return birch::log(x);
  }));
}

#line 68 "src/primitive/resample.birch"
birch::type::Real birch::nan_exp(const birch::type::Real& x) {
  #line 68 "src/primitive/resample.birch"
  libbirch_function_("nan_exp", "src/primitive/resample.birch", 68);
  #line 69 "src/primitive/resample.birch"
  libbirch_line_(69);
  #line 69 "src/primitive/resample.birch"
  if (birch::isnan(x)) {
    #line 70 "src/primitive/resample.birch"
    libbirch_line_(70);
    #line 70 "src/primitive/resample.birch"
    return 0.0;
  } else {
    #line 72 "src/primitive/resample.birch"
    libbirch_line_(72);
    #line 72 "src/primitive/resample.birch"
    return birch::exp(x);
  }
}

#line 81 "src/primitive/resample.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::norm_exp(const libbirch::DefaultArray<birch::type::Real,1>& x) {
  #line 81 "src/primitive/resample.birch"
  libbirch_function_("norm_exp", "src/primitive/resample.birch", 81);
  #line 82 "src/primitive/resample.birch"
  libbirch_line_(82);
  #line 82 "src/primitive/resample.birch"
  libbirch_assert_(birch::length(x) > birch::type::Integer(0));
  #line 83 "src/primitive/resample.birch"
  libbirch_line_(83);
  #line 83 "src/primitive/resample.birch"
  auto mx = birch::max(x);
  #line 84 "src/primitive/resample.birch"
  libbirch_line_(84);
  #line 84 "src/primitive/resample.birch"
  auto r = 0.0;
  #line 85 "src/primitive/resample.birch"
  libbirch_line_(85);
  #line 85 "src/primitive/resample.birch"
  for (auto n = birch::type::Integer(1); n <= birch::length(x); ++n) {
    #line 86 "src/primitive/resample.birch"
    libbirch_line_(86);
    #line 86 "src/primitive/resample.birch"
    r = r + birch::nan_exp(x(n) - mx);
  }
  #line 88 "src/primitive/resample.birch"
  libbirch_line_(88);
  #line 88 "src/primitive/resample.birch"
  auto W = mx + birch::log(r);
  #line 89 "src/primitive/resample.birch"
  libbirch_line_(89);
  #line 89 "src/primitive/resample.birch"
  return birch::transform<birch::type::Real>(x, std::function<birch::type::Real(birch::type::Real)>([=](const birch::type::Real& w) {
    #line 89 "src/primitive/resample.birch"
    libbirch_line_(89);
    #line 89 "src/primitive/resample.birch"
    return birch::nan_exp(w - W);
  }));
}

#line 95 "src/primitive/resample.birch"
birch::type::Integer birch::cumulative_ancestor(const libbirch::DefaultArray<birch::type::Real,1>& W) {
  #line 95 "src/primitive/resample.birch"
  libbirch_function_("cumulative_ancestor", "src/primitive/resample.birch", 95);
  #line 96 "src/primitive/resample.birch"
  libbirch_line_(96);
  #line 96 "src/primitive/resample.birch"
  auto N = birch::length(W);
  #line 97 "src/primitive/resample.birch"
  libbirch_line_(97);
  #line 97 "src/primitive/resample.birch"
  libbirch_assert_(W(N) > 0.0);
  #line 98 "src/primitive/resample.birch"
  libbirch_line_(98);
  #line 98 "src/primitive/resample.birch"
  auto u = birch::simulate_uniform(0.0, W(N));
  #line 99 "src/primitive/resample.birch"
  libbirch_line_(99);
  #line 99 "src/primitive/resample.birch"
  auto n = birch::type::Integer(1);
  #line 100 "src/primitive/resample.birch"
  libbirch_line_(100);
  #line 100 "src/primitive/resample.birch"
  while (W(n) < u) {
    #line 101 "src/primitive/resample.birch"
    libbirch_line_(101);
    #line 101 "src/primitive/resample.birch"
    n = n + birch::type::Integer(1);
  }
  #line 103 "src/primitive/resample.birch"
  libbirch_line_(103);
  #line 103 "src/primitive/resample.birch"
  return n;
}

#line 110 "src/primitive/resample.birch"
birch::type::Integer birch::ancestor(const libbirch::DefaultArray<birch::type::Real,1>& w) {
  #line 110 "src/primitive/resample.birch"
  libbirch_function_("ancestor", "src/primitive/resample.birch", 110);
  #line 111 "src/primitive/resample.birch"
  libbirch_line_(111);
  #line 111 "src/primitive/resample.birch"
  auto N = birch::length(w);
  #line 112 "src/primitive/resample.birch"
  libbirch_line_(112);
  #line 112 "src/primitive/resample.birch"
  auto W = birch::cumulative_weights(w);
  #line 113 "src/primitive/resample.birch"
  libbirch_line_(113);
  #line 113 "src/primitive/resample.birch"
  if (W(N) > 0.0) {
    #line 114 "src/primitive/resample.birch"
    libbirch_line_(114);
    #line 114 "src/primitive/resample.birch"
    return birch::cumulative_ancestor(W);
  } else {
    #line 116 "src/primitive/resample.birch"
    libbirch_line_(116);
    #line 116 "src/primitive/resample.birch"
    return birch::type::Integer(0);
  }
}

#line 123 "src/primitive/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::systematic_cumulative_offspring(const libbirch::DefaultArray<birch::type::Real,1>& W) {
  #line 123 "src/primitive/resample.birch"
  libbirch_function_("systematic_cumulative_offspring", "src/primitive/resample.birch", 123);
  #line 124 "src/primitive/resample.birch"
  libbirch_line_(124);
  #line 124 "src/primitive/resample.birch"
  auto N = birch::length(W);
  #line 125 "src/primitive/resample.birch"
  libbirch_line_(125);
  #line 125 "src/primitive/resample.birch"
  libbirch::DefaultArray<birch::type::Integer,1> O = libbirch::make_array<birch::type::Integer>(libbirch::make_shape(N));
  #line 127 "src/primitive/resample.birch"
  libbirch_line_(127);
  #line 127 "src/primitive/resample.birch"
  auto u = birch::simulate_uniform(0.0, 1.0);
  #line 128 "src/primitive/resample.birch"
  libbirch_line_(128);
  #line 128 "src/primitive/resample.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 129 "src/primitive/resample.birch"
    libbirch_line_(129);
    #line 129 "src/primitive/resample.birch"
    auto r = N * W(n) / W(N);
    #line 130 "src/primitive/resample.birch"
    libbirch_line_(130);
    #line 130 "src/primitive/resample.birch"
    O(n) = birch::min(N, birch::Integer(birch::floor(r + u)));
  }
  #line 132 "src/primitive/resample.birch"
  libbirch_line_(132);
  #line 132 "src/primitive/resample.birch"
  return O;
}

#line 138 "src/primitive/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::offspring_to_ancestors(const libbirch::DefaultArray<birch::type::Integer,1>& o) {
  #line 138 "src/primitive/resample.birch"
  libbirch_function_("offspring_to_ancestors", "src/primitive/resample.birch", 138);
  #line 139 "src/primitive/resample.birch"
  libbirch_line_(139);
  #line 139 "src/primitive/resample.birch"
  auto N = birch::length(o);
  #line 140 "src/primitive/resample.birch"
  libbirch_line_(140);
  #line 140 "src/primitive/resample.birch"
  auto i = birch::type::Integer(1);
  #line 141 "src/primitive/resample.birch"
  libbirch_line_(141);
  #line 141 "src/primitive/resample.birch"
  libbirch::DefaultArray<birch::type::Integer,1> a = libbirch::make_array<birch::type::Integer>(libbirch::make_shape(N));
  #line 142 "src/primitive/resample.birch"
  libbirch_line_(142);
  #line 142 "src/primitive/resample.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 143 "src/primitive/resample.birch"
    libbirch_line_(143);
    #line 143 "src/primitive/resample.birch"
    for (auto j = birch::type::Integer(1); j <= o(n); ++j) {
      #line 144 "src/primitive/resample.birch"
      libbirch_line_(144);
      #line 144 "src/primitive/resample.birch"
      a(i) = n;
      #line 145 "src/primitive/resample.birch"
      libbirch_line_(145);
      #line 145 "src/primitive/resample.birch"
      i = i + birch::type::Integer(1);
    }
  }
  #line 148 "src/primitive/resample.birch"
  libbirch_line_(148);
  #line 148 "src/primitive/resample.birch"
  libbirch_assert_(i == N + birch::type::Integer(1));
  #line 149 "src/primitive/resample.birch"
  libbirch_line_(149);
  #line 149 "src/primitive/resample.birch"
  return a;
}

#line 155 "src/primitive/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::offspring_to_ancestors_permute(const libbirch::DefaultArray<birch::type::Integer,1>& o) {
  #line 155 "src/primitive/resample.birch"
  libbirch_function_("offspring_to_ancestors_permute", "src/primitive/resample.birch", 155);
  #line 156 "src/primitive/resample.birch"
  libbirch_line_(156);
  #line 156 "src/primitive/resample.birch"
  auto N = birch::length(o);
  #line 157 "src/primitive/resample.birch"
  libbirch_line_(157);
  #line 157 "src/primitive/resample.birch"
  auto i = birch::type::Integer(1);
  #line 158 "src/primitive/resample.birch"
  libbirch_line_(158);
  #line 158 "src/primitive/resample.birch"
  libbirch::DefaultArray<birch::type::Integer,1> a = libbirch::make_array<birch::type::Integer>(libbirch::make_shape(N));
  #line 159 "src/primitive/resample.birch"
  libbirch_line_(159);
  #line 159 "src/primitive/resample.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 160 "src/primitive/resample.birch"
    libbirch_line_(160);
    #line 160 "src/primitive/resample.birch"
    for (auto j = birch::type::Integer(1); j <= o(n); ++j) {
      #line 161 "src/primitive/resample.birch"
      libbirch_line_(161);
      #line 161 "src/primitive/resample.birch"
      a(i) = n;
      #line 162 "src/primitive/resample.birch"
      libbirch_line_(162);
      #line 162 "src/primitive/resample.birch"
      i = i + birch::type::Integer(1);
    }
  }
  #line 165 "src/primitive/resample.birch"
  libbirch_line_(165);
  #line 165 "src/primitive/resample.birch"
  libbirch_assert_(i == N + birch::type::Integer(1));
  #line 168 "src/primitive/resample.birch"
  libbirch_line_(168);
  #line 168 "src/primitive/resample.birch"
  auto n = birch::type::Integer(1);
  #line 169 "src/primitive/resample.birch"
  libbirch_line_(169);
  #line 169 "src/primitive/resample.birch"
  while (n <= N) {
    #line 170 "src/primitive/resample.birch"
    libbirch_line_(170);
    #line 170 "src/primitive/resample.birch"
    auto c = a(n);
    #line 171 "src/primitive/resample.birch"
    libbirch_line_(171);
    #line 171 "src/primitive/resample.birch"
    if (c != n && a(c) != c) {
      #line 172 "src/primitive/resample.birch"
      libbirch_line_(172);
      #line 172 "src/primitive/resample.birch"
      a(n) = a(c);
      #line 173 "src/primitive/resample.birch"
      libbirch_line_(173);
      #line 173 "src/primitive/resample.birch"
      a(c) = c;
    } else {
      #line 175 "src/primitive/resample.birch"
      libbirch_line_(175);
      #line 175 "src/primitive/resample.birch"
      n = n + birch::type::Integer(1);
    }
  }
  #line 179 "src/primitive/resample.birch"
  libbirch_line_(179);
  #line 179 "src/primitive/resample.birch"
  return a;
}

#line 185 "src/primitive/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::cumulative_offspring_to_ancestors(const libbirch::DefaultArray<birch::type::Integer,1>& O) {
  #line 185 "src/primitive/resample.birch"
  libbirch_function_("cumulative_offspring_to_ancestors", "src/primitive/resample.birch", 185);
  #line 186 "src/primitive/resample.birch"
  libbirch_line_(186);
  #line 186 "src/primitive/resample.birch"
  auto N = birch::length(O);
  #line 187 "src/primitive/resample.birch"
  libbirch_line_(187);
  #line 187 "src/primitive/resample.birch"
  libbirch::DefaultArray<birch::type::Integer,1> a = libbirch::make_array<birch::type::Integer>(libbirch::make_shape(N));
  #line 188 "src/primitive/resample.birch"
  libbirch_line_(188);
  #line 188 "src/primitive/resample.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 189 "src/primitive/resample.birch"
    libbirch_line_(189);
    #line 189 "src/primitive/resample.birch"
    birch::type::Integer start = libbirch::make<birch::type::Integer>();
    #line 190 "src/primitive/resample.birch"
    libbirch_line_(190);
    #line 190 "src/primitive/resample.birch"
    if (n == birch::type::Integer(1)) {
      #line 191 "src/primitive/resample.birch"
      libbirch_line_(191);
      #line 191 "src/primitive/resample.birch"
      start = birch::type::Integer(0);
    } else {
      #line 193 "src/primitive/resample.birch"
      libbirch_line_(193);
      #line 193 "src/primitive/resample.birch"
      start = O(n - birch::type::Integer(1));
    }
    #line 195 "src/primitive/resample.birch"
    libbirch_line_(195);
    #line 195 "src/primitive/resample.birch"
    auto o = O(n) - start;
    #line 196 "src/primitive/resample.birch"
    libbirch_line_(196);
    #line 196 "src/primitive/resample.birch"
    for (auto j = birch::type::Integer(1); j <= o; ++j) {
      #line 197 "src/primitive/resample.birch"
      libbirch_line_(197);
      #line 197 "src/primitive/resample.birch"
      a(start + j) = n;
    }
  }
  #line 200 "src/primitive/resample.birch"
  libbirch_line_(200);
  #line 200 "src/primitive/resample.birch"
  return a;
}

#line 207 "src/primitive/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::cumulative_offspring_to_ancestors_permute(const libbirch::DefaultArray<birch::type::Integer,1>& O) {
  #line 207 "src/primitive/resample.birch"
  libbirch_function_("cumulative_offspring_to_ancestors_permute", "src/primitive/resample.birch", 207);
  #line 209 "src/primitive/resample.birch"
  libbirch_line_(209);
  #line 209 "src/primitive/resample.birch"
  libbirch::DefaultArray<birch::type::Integer,1> a = libbirch::make_array<birch::type::Integer>(libbirch::make_shape(O(birch::length(O))));
  #line 210 "src/primitive/resample.birch"
  libbirch_line_(210);
  #line 210 "src/primitive/resample.birch"
  auto N = birch::length(a);
  #line 211 "src/primitive/resample.birch"
  libbirch_line_(211);
  #line 211 "src/primitive/resample.birch"
  for (auto n = birch::type::Integer(1); n <= N; ++n) {
    #line 212 "src/primitive/resample.birch"
    libbirch_line_(212);
    #line 212 "src/primitive/resample.birch"
    auto start = birch::type::Integer(0);
    #line 213 "src/primitive/resample.birch"
    libbirch_line_(213);
    #line 213 "src/primitive/resample.birch"
    if (n > birch::type::Integer(1)) {
      #line 214 "src/primitive/resample.birch"
      libbirch_line_(214);
      #line 214 "src/primitive/resample.birch"
      start = O(n - birch::type::Integer(1));
    }
    #line 216 "src/primitive/resample.birch"
    libbirch_line_(216);
    #line 216 "src/primitive/resample.birch"
    auto o = O(n) - start;
    #line 217 "src/primitive/resample.birch"
    libbirch_line_(217);
    #line 217 "src/primitive/resample.birch"
    for (auto j = birch::type::Integer(1); j <= o; ++j) {
      #line 218 "src/primitive/resample.birch"
      libbirch_line_(218);
      #line 218 "src/primitive/resample.birch"
      a(start + j) = n;
    }
  }
  #line 223 "src/primitive/resample.birch"
  libbirch_line_(223);
  #line 223 "src/primitive/resample.birch"
  auto n = birch::type::Integer(1);
  #line 224 "src/primitive/resample.birch"
  libbirch_line_(224);
  #line 224 "src/primitive/resample.birch"
  while (n <= N) {
    #line 225 "src/primitive/resample.birch"
    libbirch_line_(225);
    #line 225 "src/primitive/resample.birch"
    auto c = a(n);
    #line 226 "src/primitive/resample.birch"
    libbirch_line_(226);
    #line 226 "src/primitive/resample.birch"
    if (c != n && a(c) != c) {
      #line 227 "src/primitive/resample.birch"
      libbirch_line_(227);
      #line 227 "src/primitive/resample.birch"
      a(n) = a(c);
      #line 228 "src/primitive/resample.birch"
      libbirch_line_(228);
      #line 228 "src/primitive/resample.birch"
      a(c) = c;
    } else {
      #line 230 "src/primitive/resample.birch"
      libbirch_line_(230);
      #line 230 "src/primitive/resample.birch"
      n = n + birch::type::Integer(1);
    }
  }
  #line 234 "src/primitive/resample.birch"
  libbirch_line_(234);
  #line 234 "src/primitive/resample.birch"
  return a;
}

#line 240 "src/primitive/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::cumulative_offspring_to_offspring(const libbirch::DefaultArray<birch::type::Integer,1>& O) {
  #line 240 "src/primitive/resample.birch"
  libbirch_function_("cumulative_offspring_to_offspring", "src/primitive/resample.birch", 240);
  #line 241 "src/primitive/resample.birch"
  libbirch_line_(241);
  #line 241 "src/primitive/resample.birch"
  return birch::adjacent_difference<birch::type::Integer>(O, std::function<birch::type::Integer(birch::type::Integer,birch::type::Integer)>([=](const birch::type::Integer& x, const birch::type::Integer& y) {
    #line 242 "src/primitive/resample.birch"
    libbirch_line_(242);
    #line 242 "src/primitive/resample.birch"
    return x - y;
  }));
}

#line 249 "src/primitive/resample.birch"
libbirch::DefaultArray<birch::type::Integer,1> birch::permute_ancestors(const libbirch::DefaultArray<birch::type::Integer,1>& a) {
  #line 249 "src/primitive/resample.birch"
  libbirch_function_("permute_ancestors", "src/primitive/resample.birch", 249);
  #line 250 "src/primitive/resample.birch"
  libbirch_line_(250);
  #line 250 "src/primitive/resample.birch"
  auto N = birch::length(a);
  #line 251 "src/primitive/resample.birch"
  libbirch_line_(251);
  #line 251 "src/primitive/resample.birch"
  auto b = a;
  #line 252 "src/primitive/resample.birch"
  libbirch_line_(252);
  #line 252 "src/primitive/resample.birch"
  auto n = birch::type::Integer(1);
  #line 253 "src/primitive/resample.birch"
  libbirch_line_(253);
  #line 253 "src/primitive/resample.birch"
  while (n <= N) {
    #line 254 "src/primitive/resample.birch"
    libbirch_line_(254);
    #line 254 "src/primitive/resample.birch"
    auto c = b(n);
    #line 255 "src/primitive/resample.birch"
    libbirch_line_(255);
    #line 255 "src/primitive/resample.birch"
    if (c != n && b(c) != c) {
      #line 256 "src/primitive/resample.birch"
      libbirch_line_(256);
      #line 256 "src/primitive/resample.birch"
      b(n) = b(c);
      #line 257 "src/primitive/resample.birch"
      libbirch_line_(257);
      #line 257 "src/primitive/resample.birch"
      b(c) = c;
    } else {
      #line 259 "src/primitive/resample.birch"
      libbirch_line_(259);
      #line 259 "src/primitive/resample.birch"
      n = n + birch::type::Integer(1);
    }
  }
  #line 262 "src/primitive/resample.birch"
  libbirch_line_(262);
  #line 262 "src/primitive/resample.birch"
  return b;
}

#line 268 "src/primitive/resample.birch"
libbirch::DefaultArray<birch::type::Real,1> birch::cumulative_weights(const libbirch::DefaultArray<birch::type::Real,1>& w) {
  #line 268 "src/primitive/resample.birch"
  libbirch_function_("cumulative_weights", "src/primitive/resample.birch", 268);
  #line 269 "src/primitive/resample.birch"
  libbirch_line_(269);
  #line 269 "src/primitive/resample.birch"
  auto N = birch::length(w);
  #line 270 "src/primitive/resample.birch"
  libbirch_line_(270);
  #line 270 "src/primitive/resample.birch"
  libbirch::DefaultArray<birch::type::Real,1> W = libbirch::make_array<birch::type::Real>(libbirch::make_shape(N));
  #line 272 "src/primitive/resample.birch"
  libbirch_line_(272);
  #line 272 "src/primitive/resample.birch"
  if (N > birch::type::Integer(0)) {
    #line 273 "src/primitive/resample.birch"
    libbirch_line_(273);
    #line 273 "src/primitive/resample.birch"
    auto mx = birch::max(w);
    #line 274 "src/primitive/resample.birch"
    libbirch_line_(274);
    #line 274 "src/primitive/resample.birch"
    W(birch::type::Integer(1)) = birch::nan_exp(w(birch::type::Integer(1)) - mx);
    #line 275 "src/primitive/resample.birch"
    libbirch_line_(275);
    #line 275 "src/primitive/resample.birch"
    for (auto n = birch::type::Integer(2); n <= N; ++n) {
      #line 276 "src/primitive/resample.birch"
      libbirch_line_(276);
      #line 276 "src/primitive/resample.birch"
      W(n) = W(n - birch::type::Integer(1)) + birch::nan_exp(w(n) - mx);
    }
  }
  #line 279 "src/primitive/resample.birch"
  libbirch_line_(279);
  #line 279 "src/primitive/resample.birch"
  return W;
}

#line 289 "src/primitive/resample.birch"
std::tuple<birch::type::Real, birch::type::Real> birch::resample_reduce(const libbirch::DefaultArray<birch::type::Real,1>& w) {
  #line 289 "src/primitive/resample.birch"
  libbirch_function_("resample_reduce", "src/primitive/resample.birch", 289);
  #line 290 "src/primitive/resample.birch"
  libbirch_line_(290);
  #line 290 "src/primitive/resample.birch"
  if (birch::length(w) == birch::type::Integer(0)) {
    #line 291 "src/primitive/resample.birch"
    libbirch_line_(291);
    #line 291 "src/primitive/resample.birch"
    return std::make_tuple(0.0, 0.0);
  } else {
    #line 293 "src/primitive/resample.birch"
    libbirch_line_(293);
    #line 293 "src/primitive/resample.birch"
    auto N = birch::length(w);
    #line 294 "src/primitive/resample.birch"
    libbirch_line_(294);
    #line 294 "src/primitive/resample.birch"
    auto W = 0.0;
    #line 295 "src/primitive/resample.birch"
    libbirch_line_(295);
    #line 295 "src/primitive/resample.birch"
    auto W2 = 0.0;
    #line 296 "src/primitive/resample.birch"
    libbirch_line_(296);
    #line 296 "src/primitive/resample.birch"
    auto mx = birch::max(w);
    #line 297 "src/primitive/resample.birch"
    libbirch_line_(297);
    #line 297 "src/primitive/resample.birch"
    for (auto n = birch::type::Integer(1); n <= N; ++n) {
      #line 298 "src/primitive/resample.birch"
      libbirch_line_(298);
      #line 298 "src/primitive/resample.birch"
      auto v = birch::nan_exp(w(n) - mx);
      #line 299 "src/primitive/resample.birch"
      libbirch_line_(299);
      #line 299 "src/primitive/resample.birch"
      W = W + v;
      #line 300 "src/primitive/resample.birch"
      libbirch_line_(300);
      #line 300 "src/primitive/resample.birch"
      W2 = W2 + v * v;
    }
    #line 302 "src/primitive/resample.birch"
    libbirch_line_(302);
    #line 302 "src/primitive/resample.birch"
    return std::make_tuple(W * W / W2, birch::log(W) + mx);
  }
}

