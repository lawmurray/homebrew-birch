#line 7 "src/iterator/BufferIterator.birch"
birch::type::BufferIterator::BufferIterator(const libbirch::Shared<birch::type::Buffer>& buffer) :
    #line 7 "src/iterator/BufferIterator.birch"
    base_type_(),
    #line 11 "src/iterator/BufferIterator.birch"
    buffer(std::move(buffer)),
    #line 16 "src/iterator/BufferIterator.birch"
    i(birch::type::Integer(0)) {
  //
}

#line 21 "src/iterator/BufferIterator.birch"
birch::type::Boolean birch::type::BufferIterator::hasNext() {
  #line 21 "src/iterator/BufferIterator.birch"
  libbirch_function_("hasNext", "src/iterator/BufferIterator.birch", 21);
  #line 22 "src/iterator/BufferIterator.birch"
  libbirch_line_(22);
  #line 22 "src/iterator/BufferIterator.birch"
  return this->i < this->buffer->size();
}

#line 28 "src/iterator/BufferIterator.birch"
libbirch::Shared<birch::type::Buffer> birch::type::BufferIterator::next() {
  #line 28 "src/iterator/BufferIterator.birch"
  libbirch_function_("next", "src/iterator/BufferIterator.birch", 28);
  #line 29 "src/iterator/BufferIterator.birch"
  libbirch_line_(29);
  #line 29 "src/iterator/BufferIterator.birch"
  this->i = this->i + birch::type::Integer(1);
  #line 30 "src/iterator/BufferIterator.birch"
  libbirch_line_(30);
  #line 30 "src/iterator/BufferIterator.birch"
  return this->buffer->values.value()(this->i);
}

#line 37 "src/iterator/BufferIterator.birch"
libbirch::Shared<birch::type::BufferIterator> birch::BufferIterator(const libbirch::Shared<birch::type::Buffer>& buffer) {
  #line 37 "src/iterator/BufferIterator.birch"
  libbirch_function_("BufferIterator", "src/iterator/BufferIterator.birch", 37);
  #line 38 "src/iterator/BufferIterator.birch"
  libbirch_line_(38);
  #line 38 "src/iterator/BufferIterator.birch"
  libbirch_assert_(!(buffer->keys.has_value()) && buffer->values.has_value());
  #line 39 "src/iterator/BufferIterator.birch"
  libbirch_line_(39);
  #line 39 "src/iterator/BufferIterator.birch"
  return birch::construct<libbirch::Shared<birch::type::BufferIterator>>(buffer);
}

