#line 37 "src/filter.birch"
int birch::filter(int argc_, char** argv_) {
  #line 37 "src/filter.birch"
  libbirch_function_("filter", "src/filter.birch", 37);
  #line 37 "src/filter.birch"
  std::optional<birch::type::String> config;
  #line 37 "src/filter.birch"
  std::optional<birch::type::Integer> seed;
  #line 37 "src/filter.birch"
  std::optional<birch::type::String> model;
  #line 37 "src/filter.birch"
  std::optional<birch::type::String> filter;
  #line 37 "src/filter.birch"
  std::optional<birch::type::Integer> nsteps;
  #line 37 "src/filter.birch"
  std::optional<birch::type::Integer> nforecasts;
  #line 37 "src/filter.birch"
  std::optional<birch::type::String> input;
  #line 37 "src/filter.birch"
  std::optional<birch::type::String> output;
  #line 37 "src/filter.birch"
  birch::type::Boolean quiet = false;
  
  enum {
    configFLAG_,
    seedFLAG_,
    modelFLAG_,
    filterFLAG_,
    nstepsFLAG_,
    nforecastsFLAG_,
    inputFLAG_,
    outputFLAG_,
    quietFLAG_,
  };
  #line 37 "src/filter.birch"
  int c_, option_index_;
  #line 37 "src/filter.birch"
  option long_options_[] = {
    #line 37 "src/filter.birch"
    {"config", required_argument, 0, configFLAG_ },
    #line 37 "src/filter.birch"
    {"seed", required_argument, 0, seedFLAG_ },
    #line 37 "src/filter.birch"
    {"model", required_argument, 0, modelFLAG_ },
    #line 37 "src/filter.birch"
    {"filter", required_argument, 0, filterFLAG_ },
    #line 37 "src/filter.birch"
    {"nsteps", required_argument, 0, nstepsFLAG_ },
    #line 37 "src/filter.birch"
    {"nforecasts", required_argument, 0, nforecastsFLAG_ },
    #line 37 "src/filter.birch"
    {"input", required_argument, 0, inputFLAG_ },
    #line 37 "src/filter.birch"
    {"output", required_argument, 0, outputFLAG_ },
    #line 37 "src/filter.birch"
    {"quiet", required_argument, 0, quietFLAG_ },
    #line 37 "src/filter.birch"
    {0, 0, 0, 0}
  #line 37 "src/filter.birch"
  };
  #line 37 "src/filter.birch"
  const char* short_options_ = ":";
  #line 37 "src/filter.birch"
  ::opterr = 0;
  #line 37 "src/filter.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 37 "src/filter.birch"
  while (c_ != -1) {
    #line 37 "src/filter.birch"
    switch (c_) {
      #line 38 "src/filter.birch"
      case configFLAG_:
        #line 38 "src/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 38 "src/filter.birch"
        config = birch::String(birch::type::String(::optarg));
        break;
      #line 39 "src/filter.birch"
      case seedFLAG_:
        #line 39 "src/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 39 "src/filter.birch"
        seed = birch::Integer(birch::type::String(::optarg));
        break;
      #line 40 "src/filter.birch"
      case modelFLAG_:
        #line 40 "src/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 40 "src/filter.birch"
        model = birch::String(birch::type::String(::optarg));
        break;
      #line 41 "src/filter.birch"
      case filterFLAG_:
        #line 41 "src/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 41 "src/filter.birch"
        filter = birch::String(birch::type::String(::optarg));
        break;
      #line 42 "src/filter.birch"
      case nstepsFLAG_:
        #line 42 "src/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 42 "src/filter.birch"
        nsteps = birch::Integer(birch::type::String(::optarg));
        break;
      #line 43 "src/filter.birch"
      case nforecastsFLAG_:
        #line 43 "src/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 43 "src/filter.birch"
        nforecasts = birch::Integer(birch::type::String(::optarg));
        break;
      #line 44 "src/filter.birch"
      case inputFLAG_:
        #line 44 "src/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 44 "src/filter.birch"
        input = birch::String(birch::type::String(::optarg));
        break;
      #line 45 "src/filter.birch"
      case outputFLAG_:
        #line 45 "src/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 45 "src/filter.birch"
        output = birch::String(birch::type::String(::optarg));
        break;
      #line 46 "src/filter.birch"
      case quietFLAG_:
        #line 46 "src/filter.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 46 "src/filter.birch"
        quiet = birch::Boolean(birch::type::String(::optarg));
        break;
      #line 37 "src/filter.birch"
      case '?':
        #line 37 "src/filter.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 37 "src/filter.birch"
      case ':':
        #line 37 "src/filter.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 37 "src/filter.birch"
      default:
        #line 37 "src/filter.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 37 "src/filter.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  Eigen::initParallel();

  {
    #line 48 "src/filter.birch"
    libbirch_line_(48);
    #line 48 "src/filter.birch"
    libbirch::Shared<birch::type::Buffer> configBuffer = libbirch::make<libbirch::Shared<birch::type::Buffer>>();
    #line 49 "src/filter.birch"
    libbirch_line_(49);
    #line 49 "src/filter.birch"
    if (config.has_value()) {
      #line 50 "src/filter.birch"
      libbirch_line_(50);
      #line 50 "src/filter.birch"
      configBuffer = birch::slurp(config.value());
    }
    #line 54 "src/filter.birch"
    libbirch_line_(54);
    #line 54 "src/filter.birch"
    if (!(seed.has_value())) {
      #line 55 "src/filter.birch"
      libbirch_line_(55);
      #line 55 "src/filter.birch"
            libbirch::optional_assign(seed, configBuffer->get<birch::type::Integer>(birch::type::String("seed")));
;
    }
    #line 57 "src/filter.birch"
    libbirch_line_(57);
    #line 57 "src/filter.birch"
    if (seed.has_value()) {
      #line 58 "src/filter.birch"
      libbirch_line_(58);
      #line 58 "src/filter.birch"
      birch::seed(seed.value());
    } else {
      #line 60 "src/filter.birch"
      libbirch_line_(60);
      #line 60 "src/filter.birch"
      birch::seed();
    }
    #line 64 "src/filter.birch"
    libbirch_line_(64);
    #line 64 "src/filter.birch"
    libbirch::Shared<birch::type::Buffer> modelBuffer = libbirch::make<libbirch::Shared<birch::type::Buffer>>();
    #line 65 "src/filter.birch"
    libbirch_line_(65);
    #line 65 "src/filter.birch"
        libbirch::optional_assign(modelBuffer, configBuffer->get(birch::type::String("model")));
;
    #line 66 "src/filter.birch"
    libbirch_line_(66);
    #line 66 "src/filter.birch"
    if (model.has_value()) {
      #line 67 "src/filter.birch"
      libbirch_line_(67);
      #line 67 "src/filter.birch"
      modelBuffer->set(birch::type::String("class"), model.value());
    }
    #line 69 "src/filter.birch"
    libbirch_line_(69);
    #line 69 "src/filter.birch"
    auto theModel = birch::make<libbirch::Shared<birch::type::Model>>(modelBuffer);
    #line 70 "src/filter.birch"
    libbirch_line_(70);
    #line 70 "src/filter.birch"
    if (!(theModel.has_value())) {
      #line 71 "src/filter.birch"
      libbirch_line_(71);
      #line 71 "src/filter.birch"
      birch::error(birch::type::String("could not create model; the model class should be given as ") + birch::type::String("model.class in the config file, or `--model` on the command ") + birch::type::String("line, and should derive from Model."));
    }
    #line 77 "src/filter.birch"
    libbirch_line_(77);
    #line 77 "src/filter.birch"
    libbirch::Shared<birch::type::Buffer> filterBuffer = libbirch::make<libbirch::Shared<birch::type::Buffer>>();
    #line 78 "src/filter.birch"
    libbirch_line_(78);
    #line 78 "src/filter.birch"
        libbirch::optional_assign(filterBuffer, configBuffer->get(birch::type::String("filter")));
;
    #line 79 "src/filter.birch"
    libbirch_line_(79);
    #line 79 "src/filter.birch"
    if (filter.has_value()) {
      #line 80 "src/filter.birch"
      libbirch_line_(80);
      #line 80 "src/filter.birch"
      filterBuffer->set(birch::type::String("class"), filter.value());
    } else {
      #line 81 "src/filter.birch"
      libbirch_line_(81);
      #line 81 "src/filter.birch"
      if (!(filterBuffer->get(birch::type::String("class")).has_value())) {
        #line 82 "src/filter.birch"
        libbirch_line_(82);
        #line 82 "src/filter.birch"
        filterBuffer->set(birch::type::String("class"), birch::type::String("ParticleFilter"));
      }
    }
    #line 84 "src/filter.birch"
    libbirch_line_(84);
    #line 84 "src/filter.birch"
    auto theFilter = birch::make<libbirch::Shared<birch::type::ParticleFilter>>(filterBuffer);
    #line 85 "src/filter.birch"
    libbirch_line_(85);
    #line 85 "src/filter.birch"
    if (!(theFilter.has_value())) {
      #line 86 "src/filter.birch"
      libbirch_line_(86);
      #line 86 "src/filter.birch"
      birch::error(birch::type::String("could not create filter; the filter class should be given as ") + birch::type::String("filter.class in the config file, or --filter on the command ") + birch::type::String("line, and should derive from ParticleFilter."));
    }
    #line 92 "src/filter.birch"
    libbirch_line_(92);
    #line 92 "src/filter.birch"
    if (!(nsteps.has_value())) {
      #line 93 "src/filter.birch"
      libbirch_line_(93);
      #line 93 "src/filter.birch"
            libbirch::optional_assign(nsteps, configBuffer->get<birch::type::Integer>(birch::type::String("nsteps")));
;
      #line 94 "src/filter.birch"
      libbirch_line_(94);
      #line 94 "src/filter.birch"
      if (!(nsteps.has_value())) {
        #line 95 "src/filter.birch"
        libbirch_line_(95);
        #line 95 "src/filter.birch"
                libbirch::optional_assign(nsteps, filterBuffer->get<birch::type::Integer>(birch::type::String("nsteps")));
;
        #line 96 "src/filter.birch"
        libbirch_line_(96);
        #line 96 "src/filter.birch"
        if (nsteps.has_value()) {
        }
      }
    }
    #line 105 "src/filter.birch"
    libbirch_line_(105);
    #line 105 "src/filter.birch"
    if (!(nforecasts.has_value())) {
      #line 106 "src/filter.birch"
      libbirch_line_(106);
      #line 106 "src/filter.birch"
            libbirch::optional_assign(nforecasts, configBuffer->get<birch::type::Integer>(birch::type::String("nforecasts")));
;
      #line 107 "src/filter.birch"
      libbirch_line_(107);
      #line 107 "src/filter.birch"
      if (!(nforecasts.has_value())) {
        #line 108 "src/filter.birch"
        libbirch_line_(108);
        #line 108 "src/filter.birch"
                libbirch::optional_assign(nforecasts, filterBuffer->get<birch::type::Integer>(birch::type::String("nforecasts")));
;
        #line 109 "src/filter.birch"
        libbirch_line_(109);
        #line 109 "src/filter.birch"
        if (nforecasts.has_value()) {
        }
      }
    }
    #line 118 "src/filter.birch"
    libbirch_line_(118);
    #line 118 "src/filter.birch"
    auto inputPath = configBuffer->get<birch::type::String>(birch::type::String("input"));
    #line 119 "src/filter.birch"
    libbirch_line_(119);
    #line 119 "src/filter.birch"
        libbirch::optional_assign(inputPath, input);
;
    #line 120 "src/filter.birch"
    libbirch_line_(120);
    #line 120 "src/filter.birch"
    std::optional<libbirch::Shared<birch::type::Reader>> inputReader = libbirch::make<std::optional<libbirch::Shared<birch::type::Reader>>>();
    #line 121 "src/filter.birch"
    libbirch_line_(121);
    #line 121 "src/filter.birch"
    if (inputPath.has_value() && inputPath.value() != birch::type::String("")) {
      #line 122 "src/filter.birch"
      libbirch_line_(122);
      #line 122 "src/filter.birch"
      inputReader = birch::Reader(inputPath.value());
    }
    #line 126 "src/filter.birch"
    libbirch_line_(126);
    #line 126 "src/filter.birch"
    auto outputPath = configBuffer->get<birch::type::String>(birch::type::String("output"));
    #line 127 "src/filter.birch"
    libbirch_line_(127);
    #line 127 "src/filter.birch"
        libbirch::optional_assign(outputPath, output);
;
    #line 128 "src/filter.birch"
    libbirch_line_(128);
    #line 128 "src/filter.birch"
    std::optional<libbirch::Shared<birch::type::Writer>> outputWriter = libbirch::make<std::optional<libbirch::Shared<birch::type::Writer>>>();
    #line 129 "src/filter.birch"
    libbirch_line_(129);
    #line 129 "src/filter.birch"
    if (outputPath.has_value() && outputPath.value() != birch::type::String("")) {
      #line 130 "src/filter.birch"
      libbirch_line_(130);
      #line 130 "src/filter.birch"
      outputWriter = birch::Writer(outputPath.value());
    }
    #line 134 "src/filter.birch"
    libbirch_line_(134);
    #line 134 "src/filter.birch"
    libbirch::Shared<birch::type::ProgressBar> bar = libbirch::make<libbirch::Shared<birch::type::ProgressBar>>();
    #line 135 "src/filter.birch"
    libbirch_line_(135);
    #line 135 "src/filter.birch"
    if (!(quiet)) {
      #line 136 "src/filter.birch"
      libbirch_line_(136);
      #line 136 "src/filter.birch"
      bar->update(0.0);
    }
    #line 140 "src/filter.birch"
    libbirch_line_(140);
    #line 140 "src/filter.birch"
    auto t = birch::type::Integer(0);
    #line 141 "src/filter.birch"
    libbirch_line_(141);
    #line 141 "src/filter.birch"
    while ((nsteps.has_value() && t <= nsteps.value()) || (!(nsteps.has_value()) && inputReader.value()->hasNext())) {
      #line 143 "src/filter.birch"
      libbirch_line_(143);
      #line 143 "src/filter.birch"
      libbirch::Shared<birch::type::Buffer> inputBuffer = libbirch::make<libbirch::Shared<birch::type::Buffer>>();
      #line 144 "src/filter.birch"
      libbirch_line_(144);
      #line 144 "src/filter.birch"
      libbirch::Shared<birch::type::Buffer> filterBuffer = inputBuffer;
      #line 145 "src/filter.birch"
      libbirch_line_(145);
      #line 145 "src/filter.birch"
      if (inputReader.has_value() && inputReader.value()->hasNext()) {
        #line 146 "src/filter.birch"
        libbirch_line_(146);
        #line 146 "src/filter.birch"
        inputBuffer = inputReader.value()->next();
        #line 147 "src/filter.birch"
        libbirch_line_(147);
        #line 147 "src/filter.birch"
        filterBuffer = inputBuffer;
        #line 148 "src/filter.birch"
        libbirch_line_(148);
        #line 148 "src/filter.birch"
                libbirch::optional_assign(filterBuffer, inputBuffer->get(birch::type::String("filter")));
;
      }
      #line 152 "src/filter.birch"
      libbirch_line_(152);
      #line 152 "src/filter.birch"
      if (t == birch::type::Integer(0)) {
        #line 153 "src/filter.birch"
        libbirch_line_(153);
        #line 153 "src/filter.birch"
        theFilter.value()->filter(theModel.value(), filterBuffer);
      } else {
        #line 155 "src/filter.birch"
        libbirch_line_(155);
        #line 155 "src/filter.birch"
        theFilter.value()->filter(t, filterBuffer);
      }
      #line 159 "src/filter.birch"
      libbirch_line_(159);
      #line 159 "src/filter.birch"
      auto forecastSize = inputBuffer->size(birch::type::String("forecast"));
      #line 160 "src/filter.birch"
      libbirch_line_(160);
      #line 160 "src/filter.birch"
      auto forecastIterator = inputBuffer->walk(birch::type::String("forecast"));
      #line 161 "src/filter.birch"
      libbirch_line_(161);
      #line 161 "src/filter.birch"
      auto forecastBuffer = birch::Buffer();
      #line 162 "src/filter.birch"
      libbirch_line_(162);
      #line 162 "src/filter.birch"
      if (nforecasts.has_value()) {
        #line 163 "src/filter.birch"
        libbirch_line_(163);
        #line 163 "src/filter.birch"
        forecastSize = nforecasts.value();
      }
      #line 165 "src/filter.birch"
      libbirch_line_(165);
      #line 165 "src/filter.birch"
      if (forecastSize > birch::type::Integer(0)) {
        #line 166 "src/filter.birch"
        libbirch_line_(166);
        #line 166 "src/filter.birch"
        auto theFilter_prime_ = birch::copy(theFilter.value());
        #line 167 "src/filter.birch"
        libbirch_line_(167);
        #line 167 "src/filter.birch"
        theFilter_prime_->trigger = 1.0;
        #line 168 "src/filter.birch"
        libbirch_line_(168);
        #line 168 "src/filter.birch"
        theFilter_prime_->resample();
        #line 169 "src/filter.birch"
        libbirch_line_(169);
        #line 169 "src/filter.birch"
        for (auto t_prime_ = (t + birch::type::Integer(1)); t_prime_ <= (t + forecastSize); ++t_prime_) {
          #line 170 "src/filter.birch"
          libbirch_line_(170);
          #line 170 "src/filter.birch"
          if (forecastIterator->hasNext()) {
            #line 171 "src/filter.birch"
            libbirch_line_(171);
            #line 171 "src/filter.birch"
            theFilter_prime_->filter(t_prime_, forecastIterator->next());
          } else {
            #line 173 "src/filter.birch"
            libbirch_line_(173);
            #line 173 "src/filter.birch"
            theFilter_prime_->filter(t_prime_, birch::Buffer());
          }
          #line 175 "src/filter.birch"
          libbirch_line_(175);
          #line 175 "src/filter.birch"
          if (outputWriter.has_value()) {
            #line 176 "src/filter.birch"
            libbirch_line_(176);
            #line 176 "src/filter.birch"
            forecastBuffer->push(t, theFilter_prime_->x);
          }
        }
      }
      #line 182 "src/filter.birch"
      libbirch_line_(182);
      #line 182 "src/filter.birch"
      if (outputWriter.has_value()) {
        #line 183 "src/filter.birch"
        libbirch_line_(183);
        #line 183 "src/filter.birch"
        auto outputBuffer = birch::Buffer();
        #line 184 "src/filter.birch"
        libbirch_line_(184);
        #line 184 "src/filter.birch"
        if (t > birch::type::Integer(0)) {
          #line 185 "src/filter.birch"
          libbirch_line_(185);
          #line 185 "src/filter.birch"
          outputBuffer->set(birch::type::String("filter"), t, theFilter.value()->x);
        }
        #line 187 "src/filter.birch"
        libbirch_line_(187);
        #line 187 "src/filter.birch"
        outputBuffer->set(birch::type::String("lweight"), theFilter.value()->w);
        #line 188 "src/filter.birch"
        libbirch_line_(188);
        #line 188 "src/filter.birch"
        outputBuffer->set(birch::type::String("ess"), theFilter.value()->ess);
        #line 189 "src/filter.birch"
        libbirch_line_(189);
        #line 189 "src/filter.birch"
        outputBuffer->set(birch::type::String("lnormalize"), theFilter.value()->lnormalize);
        #line 190 "src/filter.birch"
        libbirch_line_(190);
        #line 190 "src/filter.birch"
        outputBuffer->set(birch::type::String("npropagations"), theFilter.value()->npropagations);
        #line 191 "src/filter.birch"
        libbirch_line_(191);
        #line 191 "src/filter.birch"
        outputBuffer->set(birch::type::String("raccepts"), theFilter.value()->raccepts);
        #line 192 "src/filter.birch"
        libbirch_line_(192);
        #line 192 "src/filter.birch"
        outputBuffer->set(birch::type::String("forecast"), forecastBuffer);
        #line 193 "src/filter.birch"
        libbirch_line_(193);
        #line 193 "src/filter.birch"
        outputWriter.value()->push(outputBuffer);
      }
      #line 195 "src/filter.birch"
      libbirch_line_(195);
      #line 195 "src/filter.birch"
      if (!(quiet)) {
        #line 196 "src/filter.birch"
        libbirch_line_(196);
        #line 196 "src/filter.birch"
        bar->update((t + 1.0) / (nsteps.value() + 1.0));
      }
      #line 198 "src/filter.birch"
      libbirch_line_(198);
      #line 198 "src/filter.birch"
      t = t + birch::type::Integer(1);
    }
    #line 202 "src/filter.birch"
    libbirch_line_(202);
    #line 202 "src/filter.birch"
    if (inputReader.has_value()) {
      #line 203 "src/filter.birch"
      libbirch_line_(203);
      #line 203 "src/filter.birch"
      inputReader.value()->close();
    }
    #line 205 "src/filter.birch"
    libbirch_line_(205);
    #line 205 "src/filter.birch"
    if (outputWriter.has_value()) {
      #line 206 "src/filter.birch"
      libbirch_line_(206);
      #line 206 "src/filter.birch"
      outputWriter.value()->close();
    }
  }
  #line 37 "src/filter.birch"
  libbirch_line_(37);
  #line 37 "src/filter.birch"
  libbirch::collect();
  #line 37 "src/filter.birch"
  libbirch_line_(37);
  #line 37 "src/filter.birch"
  return 0;
}

#line 42 "src/sample.birch"
int birch::sample(int argc_, char** argv_) {
  #line 42 "src/sample.birch"
  libbirch_function_("sample", "src/sample.birch", 42);
  #line 42 "src/sample.birch"
  std::optional<birch::type::String> config;
  #line 42 "src/sample.birch"
  std::optional<birch::type::Integer> seed;
  #line 42 "src/sample.birch"
  std::optional<birch::type::String> model;
  #line 42 "src/sample.birch"
  std::optional<birch::type::String> sampler;
  #line 42 "src/sample.birch"
  std::optional<birch::type::String> filter;
  #line 42 "src/sample.birch"
  std::optional<birch::type::Integer> nsamples;
  #line 42 "src/sample.birch"
  std::optional<birch::type::Integer> nsteps;
  #line 42 "src/sample.birch"
  std::optional<birch::type::String> input;
  #line 42 "src/sample.birch"
  std::optional<birch::type::String> output;
  #line 42 "src/sample.birch"
  birch::type::Boolean quiet = false;
  
  enum {
    configFLAG_,
    seedFLAG_,
    modelFLAG_,
    samplerFLAG_,
    filterFLAG_,
    nsamplesFLAG_,
    nstepsFLAG_,
    inputFLAG_,
    outputFLAG_,
    quietFLAG_,
  };
  #line 42 "src/sample.birch"
  int c_, option_index_;
  #line 42 "src/sample.birch"
  option long_options_[] = {
    #line 42 "src/sample.birch"
    {"config", required_argument, 0, configFLAG_ },
    #line 42 "src/sample.birch"
    {"seed", required_argument, 0, seedFLAG_ },
    #line 42 "src/sample.birch"
    {"model", required_argument, 0, modelFLAG_ },
    #line 42 "src/sample.birch"
    {"sampler", required_argument, 0, samplerFLAG_ },
    #line 42 "src/sample.birch"
    {"filter", required_argument, 0, filterFLAG_ },
    #line 42 "src/sample.birch"
    {"nsamples", required_argument, 0, nsamplesFLAG_ },
    #line 42 "src/sample.birch"
    {"nsteps", required_argument, 0, nstepsFLAG_ },
    #line 42 "src/sample.birch"
    {"input", required_argument, 0, inputFLAG_ },
    #line 42 "src/sample.birch"
    {"output", required_argument, 0, outputFLAG_ },
    #line 42 "src/sample.birch"
    {"quiet", required_argument, 0, quietFLAG_ },
    #line 42 "src/sample.birch"
    {0, 0, 0, 0}
  #line 42 "src/sample.birch"
  };
  #line 42 "src/sample.birch"
  const char* short_options_ = ":";
  #line 42 "src/sample.birch"
  ::opterr = 0;
  #line 42 "src/sample.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 42 "src/sample.birch"
  while (c_ != -1) {
    #line 42 "src/sample.birch"
    switch (c_) {
      #line 43 "src/sample.birch"
      case configFLAG_:
        #line 43 "src/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 43 "src/sample.birch"
        config = birch::String(birch::type::String(::optarg));
        break;
      #line 44 "src/sample.birch"
      case seedFLAG_:
        #line 44 "src/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 44 "src/sample.birch"
        seed = birch::Integer(birch::type::String(::optarg));
        break;
      #line 45 "src/sample.birch"
      case modelFLAG_:
        #line 45 "src/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 45 "src/sample.birch"
        model = birch::String(birch::type::String(::optarg));
        break;
      #line 46 "src/sample.birch"
      case samplerFLAG_:
        #line 46 "src/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 46 "src/sample.birch"
        sampler = birch::String(birch::type::String(::optarg));
        break;
      #line 47 "src/sample.birch"
      case filterFLAG_:
        #line 47 "src/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 47 "src/sample.birch"
        filter = birch::String(birch::type::String(::optarg));
        break;
      #line 48 "src/sample.birch"
      case nsamplesFLAG_:
        #line 48 "src/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 48 "src/sample.birch"
        nsamples = birch::Integer(birch::type::String(::optarg));
        break;
      #line 49 "src/sample.birch"
      case nstepsFLAG_:
        #line 49 "src/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 49 "src/sample.birch"
        nsteps = birch::Integer(birch::type::String(::optarg));
        break;
      #line 50 "src/sample.birch"
      case inputFLAG_:
        #line 50 "src/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 50 "src/sample.birch"
        input = birch::String(birch::type::String(::optarg));
        break;
      #line 51 "src/sample.birch"
      case outputFLAG_:
        #line 51 "src/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 51 "src/sample.birch"
        output = birch::String(birch::type::String(::optarg));
        break;
      #line 52 "src/sample.birch"
      case quietFLAG_:
        #line 52 "src/sample.birch"
        libbirch_error_msg_(::optarg, "option --" << long_options_[::optopt].name << " requires a value.");
        #line 52 "src/sample.birch"
        quiet = birch::Boolean(birch::type::String(::optarg));
        break;
      #line 42 "src/sample.birch"
      case '?':
        #line 42 "src/sample.birch"
        libbirch_error_msg_(false, "option " << argv_[::optind - 1] << " unrecognized.");
      #line 42 "src/sample.birch"
      case ':':
        #line 42 "src/sample.birch"
        libbirch_error_msg_(false, "option --" << long_options_[::optopt].name << " requires a value.");
      #line 42 "src/sample.birch"
      default:
        #line 42 "src/sample.birch"
        libbirch_error_msg_(false, std::string("unknown error parsing command-line options."));
    }
    #line 42 "src/sample.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  Eigen::initParallel();

  {
    #line 54 "src/sample.birch"
    libbirch_line_(54);
    #line 54 "src/sample.birch"
    libbirch::Shared<birch::type::Buffer> configBuffer = libbirch::make<libbirch::Shared<birch::type::Buffer>>();
    #line 55 "src/sample.birch"
    libbirch_line_(55);
    #line 55 "src/sample.birch"
    if (config.has_value()) {
      #line 56 "src/sample.birch"
      libbirch_line_(56);
      #line 56 "src/sample.birch"
      configBuffer = birch::slurp(config.value());
    }
    #line 60 "src/sample.birch"
    libbirch_line_(60);
    #line 60 "src/sample.birch"
    if (!(seed.has_value())) {
      #line 61 "src/sample.birch"
      libbirch_line_(61);
      #line 61 "src/sample.birch"
            libbirch::optional_assign(seed, configBuffer->get<birch::type::Integer>(birch::type::String("seed")));
;
    }
    #line 63 "src/sample.birch"
    libbirch_line_(63);
    #line 63 "src/sample.birch"
    if (seed.has_value()) {
      #line 64 "src/sample.birch"
      libbirch_line_(64);
      #line 64 "src/sample.birch"
      birch::seed(seed.value());
    } else {
      #line 66 "src/sample.birch"
      libbirch_line_(66);
      #line 66 "src/sample.birch"
      birch::seed();
    }
    #line 70 "src/sample.birch"
    libbirch_line_(70);
    #line 70 "src/sample.birch"
    libbirch::Shared<birch::type::Buffer> modelBuffer = libbirch::make<libbirch::Shared<birch::type::Buffer>>();
    #line 71 "src/sample.birch"
    libbirch_line_(71);
    #line 71 "src/sample.birch"
        libbirch::optional_assign(modelBuffer, configBuffer->get(birch::type::String("model")));
;
    #line 72 "src/sample.birch"
    libbirch_line_(72);
    #line 72 "src/sample.birch"
    if (model.has_value()) {
      #line 73 "src/sample.birch"
      libbirch_line_(73);
      #line 73 "src/sample.birch"
      modelBuffer->set(birch::type::String("class"), model.value());
    }
    #line 75 "src/sample.birch"
    libbirch_line_(75);
    #line 75 "src/sample.birch"
    auto theModel = birch::make<libbirch::Shared<birch::type::Model>>(modelBuffer);
    #line 76 "src/sample.birch"
    libbirch_line_(76);
    #line 76 "src/sample.birch"
    if (!(theModel.has_value())) {
      #line 77 "src/sample.birch"
      libbirch_line_(77);
      #line 77 "src/sample.birch"
      birch::error(birch::type::String("could not create model; the model class should be given as ") + birch::type::String("model.class in the config file, or `--model` on the command ") + birch::type::String("line, and should derive from Model."));
    }
    #line 83 "src/sample.birch"
    libbirch_line_(83);
    #line 83 "src/sample.birch"
    libbirch::Shared<birch::type::Buffer> samplerBuffer = libbirch::make<libbirch::Shared<birch::type::Buffer>>();
    #line 84 "src/sample.birch"
    libbirch_line_(84);
    #line 84 "src/sample.birch"
        libbirch::optional_assign(samplerBuffer, configBuffer->get(birch::type::String("sampler")));
;
    #line 85 "src/sample.birch"
    libbirch_line_(85);
    #line 85 "src/sample.birch"
    if (sampler.has_value()) {
      #line 86 "src/sample.birch"
      libbirch_line_(86);
      #line 86 "src/sample.birch"
      samplerBuffer->set(birch::type::String("class"), sampler.value());
    } else {
      #line 87 "src/sample.birch"
      libbirch_line_(87);
      #line 87 "src/sample.birch"
      if (!(samplerBuffer->get(birch::type::String("class")).has_value())) {
        #line 88 "src/sample.birch"
        libbirch_line_(88);
        #line 88 "src/sample.birch"
        samplerBuffer->set(birch::type::String("class"), birch::type::String("ParticleSampler"));
      }
    }
    #line 90 "src/sample.birch"
    libbirch_line_(90);
    #line 90 "src/sample.birch"
    auto theSampler = birch::make<libbirch::Shared<birch::type::ParticleSampler>>(samplerBuffer);
    #line 91 "src/sample.birch"
    libbirch_line_(91);
    #line 91 "src/sample.birch"
    if (!(theSampler.has_value())) {
      #line 92 "src/sample.birch"
      libbirch_line_(92);
      #line 92 "src/sample.birch"
      birch::error(birch::type::String("could not create sampler; the sampler class should be given as ") + birch::type::String("sampler.class in the config file, or --sampler on the command ") + birch::type::String("line, and should derive from ParticleSampler."));
    }
    #line 98 "src/sample.birch"
    libbirch_line_(98);
    #line 98 "src/sample.birch"
    libbirch::Shared<birch::type::Buffer> filterBuffer = libbirch::make<libbirch::Shared<birch::type::Buffer>>();
    #line 99 "src/sample.birch"
    libbirch_line_(99);
    #line 99 "src/sample.birch"
        libbirch::optional_assign(filterBuffer, configBuffer->get(birch::type::String("filter")));
;
    #line 100 "src/sample.birch"
    libbirch_line_(100);
    #line 100 "src/sample.birch"
    if (filter.has_value()) {
      #line 101 "src/sample.birch"
      libbirch_line_(101);
      #line 101 "src/sample.birch"
      filterBuffer->set(birch::type::String("class"), filter.value());
    } else {
      #line 102 "src/sample.birch"
      libbirch_line_(102);
      #line 102 "src/sample.birch"
      if (!(filterBuffer->get(birch::type::String("class")).has_value())) {
        #line 103 "src/sample.birch"
        libbirch_line_(103);
        #line 103 "src/sample.birch"
        if (libbirch::cast<libbirch::Shared<birch::type::ConditionalParticleSampler>>(theSampler).has_value()) {
          #line 104 "src/sample.birch"
          libbirch_line_(104);
          #line 104 "src/sample.birch"
          filterBuffer->set(birch::type::String("class"), birch::type::String("ConditionalParticleFilter"));
        } else {
          #line 106 "src/sample.birch"
          libbirch_line_(106);
          #line 106 "src/sample.birch"
          filterBuffer->set(birch::type::String("class"), birch::type::String("ParticleFilter"));
        }
      }
    }
    #line 109 "src/sample.birch"
    libbirch_line_(109);
    #line 109 "src/sample.birch"
    auto theFilter = birch::make<libbirch::Shared<birch::type::ParticleFilter>>(filterBuffer);
    #line 110 "src/sample.birch"
    libbirch_line_(110);
    #line 110 "src/sample.birch"
    if (!(theFilter.has_value())) {
      #line 111 "src/sample.birch"
      libbirch_line_(111);
      #line 111 "src/sample.birch"
      birch::error(birch::type::String("could not create filter; the filter class should be given as ") + birch::type::String("filter.class in the config file, or --filter on the command ") + birch::type::String("line, and should derive from ParticleFilter."));
    }
    #line 117 "src/sample.birch"
    libbirch_line_(117);
    #line 117 "src/sample.birch"
    if (!(nsamples.has_value())) {
      #line 118 "src/sample.birch"
      libbirch_line_(118);
      #line 118 "src/sample.birch"
            libbirch::optional_assign(nsamples, configBuffer->get<birch::type::Integer>(birch::type::String("nsamples")));
;
      #line 119 "src/sample.birch"
      libbirch_line_(119);
      #line 119 "src/sample.birch"
      if (!(nsamples.has_value())) {
        #line 120 "src/sample.birch"
        libbirch_line_(120);
        #line 120 "src/sample.birch"
                libbirch::optional_assign(nsamples, samplerBuffer->get<birch::type::Integer>(birch::type::String("nsamples")));
;
        #line 121 "src/sample.birch"
        libbirch_line_(121);
        #line 121 "src/sample.birch"
        if (nsamples.has_value()) {
        } else {
          #line 126 "src/sample.birch"
          libbirch_line_(126);
          #line 126 "src/sample.birch"
          nsamples = birch::type::Integer(1);
        }
      }
    }
    #line 132 "src/sample.birch"
    libbirch_line_(132);
    #line 132 "src/sample.birch"
    if (!(nsteps.has_value())) {
      #line 133 "src/sample.birch"
      libbirch_line_(133);
      #line 133 "src/sample.birch"
            libbirch::optional_assign(nsteps, configBuffer->get<birch::type::Integer>(birch::type::String("nsteps")));
;
      #line 134 "src/sample.birch"
      libbirch_line_(134);
      #line 134 "src/sample.birch"
      if (!(nsteps.has_value())) {
        #line 135 "src/sample.birch"
        libbirch_line_(135);
        #line 135 "src/sample.birch"
                libbirch::optional_assign(nsteps, filterBuffer->get<birch::type::Integer>(birch::type::String("nsteps")));
;
        #line 136 "src/sample.birch"
        libbirch_line_(136);
        #line 136 "src/sample.birch"
        if (nsteps.has_value()) {
        }
      }
    }
    #line 145 "src/sample.birch"
    libbirch_line_(145);
    #line 145 "src/sample.birch"
    auto inputPath = configBuffer->get<birch::type::String>(birch::type::String("input"));
    #line 146 "src/sample.birch"
    libbirch_line_(146);
    #line 146 "src/sample.birch"
        libbirch::optional_assign(inputPath, input);
;
    #line 147 "src/sample.birch"
    libbirch_line_(147);
    #line 147 "src/sample.birch"
    libbirch::Shared<birch::type::Buffer> inputBuffer = libbirch::make<libbirch::Shared<birch::type::Buffer>>();
    #line 148 "src/sample.birch"
    libbirch_line_(148);
    #line 148 "src/sample.birch"
    inputBuffer->setEmptyArray();
    #line 149 "src/sample.birch"
    libbirch_line_(149);
    #line 149 "src/sample.birch"
    if (inputPath.has_value() && inputPath.value() != birch::type::String("")) {
      #line 150 "src/sample.birch"
      libbirch_line_(150);
      #line 150 "src/sample.birch"
      auto inputReader = birch::Reader(inputPath.value());
      #line 151 "src/sample.birch"
      libbirch_line_(151);
      #line 151 "src/sample.birch"
      if (!(nsteps.has_value())) {
        #line 152 "src/sample.birch"
        libbirch_line_(152);
        #line 152 "src/sample.birch"
        inputBuffer = inputReader->slurp();
        #line 153 "src/sample.birch"
        libbirch_line_(153);
        #line 153 "src/sample.birch"
        nsteps = inputBuffer->size() - birch::type::Integer(1);
      } else {
        #line 155 "src/sample.birch"
        libbirch_line_(155);
        #line 155 "src/sample.birch"
        auto t = birch::type::Integer(0);
        #line 156 "src/sample.birch"
        libbirch_line_(156);
        #line 156 "src/sample.birch"
        while (t <= nsteps.value() && inputReader->hasNext()) {
          #line 157 "src/sample.birch"
          libbirch_line_(157);
          #line 157 "src/sample.birch"
          inputBuffer->push(inputReader->next());
          #line 158 "src/sample.birch"
          libbirch_line_(158);
          #line 158 "src/sample.birch"
          t = t + birch::type::Integer(1);
        }
      }
      #line 161 "src/sample.birch"
      libbirch_line_(161);
      #line 161 "src/sample.birch"
      inputReader->close();
    }
    #line 163 "src/sample.birch"
    libbirch_line_(163);
    #line 163 "src/sample.birch"
    if (!(nsteps.has_value())) {
      #line 164 "src/sample.birch"
      libbirch_line_(164);
      #line 164 "src/sample.birch"
      nsteps = birch::type::Integer(0);
    }
    #line 168 "src/sample.birch"
    libbirch_line_(168);
    #line 168 "src/sample.birch"
    auto outputPath = configBuffer->get<birch::type::String>(birch::type::String("output"));
    #line 169 "src/sample.birch"
    libbirch_line_(169);
    #line 169 "src/sample.birch"
        libbirch::optional_assign(outputPath, output);
;
    #line 170 "src/sample.birch"
    libbirch_line_(170);
    #line 170 "src/sample.birch"
    std::optional<libbirch::Shared<birch::type::Writer>> outputWriter = libbirch::make<std::optional<libbirch::Shared<birch::type::Writer>>>();
    #line 171 "src/sample.birch"
    libbirch_line_(171);
    #line 171 "src/sample.birch"
    if (outputPath.has_value() && outputPath.value() != birch::type::String("")) {
      #line 172 "src/sample.birch"
      libbirch_line_(172);
      #line 172 "src/sample.birch"
      outputWriter = birch::Writer(outputPath.value());
    }
    #line 176 "src/sample.birch"
    libbirch_line_(176);
    #line 176 "src/sample.birch"
    libbirch::Shared<birch::type::ProgressBar> bar = libbirch::make<libbirch::Shared<birch::type::ProgressBar>>();
    #line 177 "src/sample.birch"
    libbirch_line_(177);
    #line 177 "src/sample.birch"
    if (!(quiet)) {
      #line 178 "src/sample.birch"
      libbirch_line_(178);
      #line 178 "src/sample.birch"
      bar->update(0.0);
    }
    #line 182 "src/sample.birch"
    libbirch_line_(182);
    #line 182 "src/sample.birch"
    libbirch::Shared<birch::type::Buffer> buffer = libbirch::make<libbirch::Shared<birch::type::Buffer>>();
    #line 183 "src/sample.birch"
    libbirch_line_(183);
    #line 183 "src/sample.birch"
    for (auto n = birch::type::Integer(1); n <= nsamples.value(); ++n) {
      #line 185 "src/sample.birch"
      libbirch_line_(185);
      #line 185 "src/sample.birch"
      auto inputIter = inputBuffer->walk();
      #line 186 "src/sample.birch"
      libbirch_line_(186);
      #line 186 "src/sample.birch"
      if (inputIter->hasNext()) {
        #line 187 "src/sample.birch"
        libbirch_line_(187);
        #line 187 "src/sample.birch"
        buffer = inputIter->next();
      } else {
        #line 189 "src/sample.birch"
        libbirch_line_(189);
        #line 189 "src/sample.birch"
        buffer = birch::Buffer();
      }
      #line 191 "src/sample.birch"
      libbirch_line_(191);
      #line 191 "src/sample.birch"
      theSampler.value()->sample(theFilter.value(), theModel.value(), buffer);
      #line 194 "src/sample.birch"
      libbirch_line_(194);
      #line 194 "src/sample.birch"
      libbirch::Shared<birch::type::Buffer> outputBuffer = libbirch::make<libbirch::Shared<birch::type::Buffer>>();
      #line 195 "src/sample.birch"
      libbirch_line_(195);
      #line 195 "src/sample.birch"
      if (outputWriter.has_value()) {
        #line 196 "src/sample.birch"
        libbirch_line_(196);
        #line 196 "src/sample.birch"
        outputBuffer->set(birch::type::String("ess"), theFilter.value()->ess);
        #line 197 "src/sample.birch"
        libbirch_line_(197);
        #line 197 "src/sample.birch"
        outputBuffer->set(birch::type::String("lnormalize"), theFilter.value()->lnormalize);
        #line 198 "src/sample.birch"
        libbirch_line_(198);
        #line 198 "src/sample.birch"
        outputBuffer->set(birch::type::String("npropagations"), theFilter.value()->npropagations);
        #line 199 "src/sample.birch"
        libbirch_line_(199);
        #line 199 "src/sample.birch"
        outputBuffer->set(birch::type::String("raccepts"), theFilter.value()->raccepts);
      }
      #line 203 "src/sample.birch"
      libbirch_line_(203);
      #line 203 "src/sample.birch"
      if (!(quiet)) {
        #line 204 "src/sample.birch"
        libbirch_line_(204);
        #line 204 "src/sample.birch"
        bar->update((n - 1.0) / nsamples.value() + 1.0 / (nsamples.value() * (nsteps.value() + 1.0)));
      }
      #line 208 "src/sample.birch"
      libbirch_line_(208);
      #line 208 "src/sample.birch"
      for (auto t = birch::type::Integer(1); t <= nsteps.value(); ++t) {
        #line 209 "src/sample.birch"
        libbirch_line_(209);
        #line 209 "src/sample.birch"
        if (inputIter->hasNext()) {
          #line 210 "src/sample.birch"
          libbirch_line_(210);
          #line 210 "src/sample.birch"
          buffer = inputIter->next();
        } else {
          #line 212 "src/sample.birch"
          libbirch_line_(212);
          #line 212 "src/sample.birch"
          buffer = birch::Buffer();
        }
        #line 214 "src/sample.birch"
        libbirch_line_(214);
        #line 214 "src/sample.birch"
        theSampler.value()->sample(theFilter.value(), t, buffer);
        #line 217 "src/sample.birch"
        libbirch_line_(217);
        #line 217 "src/sample.birch"
        if (outputWriter.has_value()) {
          #line 218 "src/sample.birch"
          libbirch_line_(218);
          #line 218 "src/sample.birch"
          outputBuffer->push(birch::type::String("ess"), theFilter.value()->ess);
          #line 219 "src/sample.birch"
          libbirch_line_(219);
          #line 219 "src/sample.birch"
          outputBuffer->push(birch::type::String("lnormalize"), theFilter.value()->lnormalize);
          #line 220 "src/sample.birch"
          libbirch_line_(220);
          #line 220 "src/sample.birch"
          outputBuffer->push(birch::type::String("npropagations"), theFilter.value()->npropagations);
          #line 221 "src/sample.birch"
          libbirch_line_(221);
          #line 221 "src/sample.birch"
          outputBuffer->push(birch::type::String("raccepts"), theFilter.value()->raccepts);
        }
        #line 225 "src/sample.birch"
        libbirch_line_(225);
        #line 225 "src/sample.birch"
        if (!(quiet)) {
          #line 226 "src/sample.birch"
          libbirch_line_(226);
          #line 226 "src/sample.birch"
          bar->update((n - 1.0) / nsamples.value() + (t + 1.0) / (nsamples.value() * (nsteps.value() + 1.0)));
        }
      }
      #line 231 "src/sample.birch"
      libbirch_line_(231);
      #line 231 "src/sample.birch"
      if (outputWriter.has_value()) {
        #line 232 "src/sample.birch"
        libbirch_line_(232);
        #line 232 "src/sample.birch"
        std::optional<libbirch::Shared<birch::type::Model>> x = libbirch::make<std::optional<libbirch::Shared<birch::type::Model>>>();
        #line 233 "src/sample.birch"
        libbirch_line_(233);
        #line 233 "src/sample.birch"
        birch::type::Real w = libbirch::make<birch::type::Real>();
        #line 234 "src/sample.birch"
        libbirch_line_(234);
        #line 234 "src/sample.birch"
        std::tie(x, w) = theSampler.value()->draw(theFilter.value());
        #line 235 "src/sample.birch"
        libbirch_line_(235);
        #line 235 "src/sample.birch"
        outputBuffer->set(birch::type::String("lweight"), w);
        #line 236 "src/sample.birch"
        libbirch_line_(236);
        #line 236 "src/sample.birch"
        outputBuffer->push(birch::type::String("sample"), x.value());
        #line 237 "src/sample.birch"
        libbirch_line_(237);
        #line 237 "src/sample.birch"
        for (auto t = birch::type::Integer(1); t <= nsteps.value(); ++t) {
          #line 238 "src/sample.birch"
          libbirch_line_(238);
          #line 238 "src/sample.birch"
          outputBuffer->push(birch::type::String("sample"), t, x.value());
        }
        #line 240 "src/sample.birch"
        libbirch_line_(240);
        #line 240 "src/sample.birch"
        outputWriter.value()->push(outputBuffer);
        #line 241 "src/sample.birch"
        libbirch_line_(241);
        #line 241 "src/sample.birch"
        outputWriter.value()->flush();
      }
      #line 245 "src/sample.birch"
      libbirch_line_(245);
      #line 245 "src/sample.birch"
      if (!(quiet)) {
        #line 246 "src/sample.birch"
        libbirch_line_(246);
        #line 246 "src/sample.birch"
        bar->update(birch::Real(n) / nsamples.value());
      }
    }
    #line 251 "src/sample.birch"
    libbirch_line_(251);
    #line 251 "src/sample.birch"
    if (outputWriter.has_value()) {
      #line 252 "src/sample.birch"
      libbirch_line_(252);
      #line 252 "src/sample.birch"
      outputWriter.value()->close();
    }
  }
  #line 42 "src/sample.birch"
  libbirch_line_(42);
  #line 42 "src/sample.birch"
  libbirch::collect();
  #line 42 "src/sample.birch"
  libbirch_line_(42);
  #line 42 "src/sample.birch"
  return 0;
}

