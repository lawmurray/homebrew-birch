#line 13 "src/handler/Handler.birch"
birch::type::Handler::Handler() :
    #line 13 "src/handler/Handler.birch"
    base_type_(),
    #line 17 "src/handler/Handler.birch"
    input(libbirch::make<std::optional<libbirch::Shared<birch::type::Tape<libbirch::Shared<birch::type::Record>>>>>()),
    #line 22 "src/handler/Handler.birch"
    output(libbirch::make<std::optional<libbirch::Shared<birch::type::Tape<libbirch::Shared<birch::type::Record>>>>>()),
    #line 27 "src/handler/Handler.birch"
    w(0.0) {
  //
}

#line 37 "src/handler/Handler.birch"
void birch::type::Handler::handle(const libbirch::Shared<birch::type::Event>& event) {
  #line 37 "src/handler/Handler.birch"
  libbirch_function_("handle", "src/handler/Handler.birch", 37);
  #line 38 "src/handler/Handler.birch"
  libbirch_line_(38);
  #line 38 "src/handler/Handler.birch"
  if (this->input.has_value()) {
    #line 39 "src/handler/Handler.birch"
    libbirch_line_(39);
    #line 39 "src/handler/Handler.birch"
    this->doHandle(this->input.value()->front(), event);
    #line 40 "src/handler/Handler.birch"
    libbirch_line_(40);
    #line 40 "src/handler/Handler.birch"
    this->input.value()->popFront();
  } else {
    #line 42 "src/handler/Handler.birch"
    libbirch_line_(42);
    #line 42 "src/handler/Handler.birch"
    this->doHandle(event);
  }
  #line 44 "src/handler/Handler.birch"
  libbirch_line_(44);
  #line 44 "src/handler/Handler.birch"
  if (this->output.has_value()) {
    #line 45 "src/handler/Handler.birch"
    libbirch_line_(45);
    #line 45 "src/handler/Handler.birch"
    this->output.value()->pushBack(event->record());
  }
}

#line 1 "src/handler/MoveHandler.birch"
birch::type::MoveHandler::MoveHandler(const birch::type::Boolean& delayed) :
    #line 1 "src/handler/MoveHandler.birch"
    base_type_(),
    #line 19 "src/handler/MoveHandler.birch"
    delayed(std::move(delayed)),
    #line 24 "src/handler/MoveHandler.birch"
    z(libbirch::make<std::optional<libbirch::Shared<birch::type::Expression<birch::type::Real>>>>()) {
  //
}

#line 26 "src/handler/MoveHandler.birch"
void birch::type::MoveHandler::doHandle(const libbirch::Shared<birch::type::Event>& event) {
  #line 26 "src/handler/MoveHandler.birch"
  libbirch_function_("doHandle", "src/handler/MoveHandler.birch", 26);
  #line 28 "src/handler/MoveHandler.birch"
  libbirch_line_(28);
  #line 28 "src/handler/MoveHandler.birch"
  event->accept(this->shared_from_this_());
}

#line 31 "src/handler/MoveHandler.birch"
void birch::type::MoveHandler::doHandle(const libbirch::Shared<birch::type::Record>& record, const libbirch::Shared<birch::type::Event>& event) {
  #line 31 "src/handler/MoveHandler.birch"
  libbirch_function_("doHandle", "src/handler/MoveHandler.birch", 31);
  #line 33 "src/handler/MoveHandler.birch"
  libbirch_line_(33);
  #line 33 "src/handler/MoveHandler.birch"
  event->accept(record, this->shared_from_this_());
}

#line 72 "src/handler/MoveHandler.birch"
void birch::type::MoveHandler::doHandle(const libbirch::Shared<birch::type::FactorEvent>& event) {
  #line 72 "src/handler/MoveHandler.birch"
  libbirch_function_("doHandle", "src/handler/MoveHandler.birch", 72);
  #line 73 "src/handler/MoveHandler.birch"
  libbirch_line_(73);
  #line 73 "src/handler/MoveHandler.birch"
  if (this->z.has_value()) {
    #line 74 "src/handler/MoveHandler.birch"
    libbirch_line_(74);
    #line 74 "src/handler/MoveHandler.birch"
    this->z = this->z.value() + event->w;
  } else {
    #line 76 "src/handler/MoveHandler.birch"
    libbirch_line_(76);
    #line 76 "src/handler/MoveHandler.birch"
    this->z = event->w;
  }
}

#line 122 "src/handler/MoveHandler.birch"
void birch::type::MoveHandler::doHandle(const libbirch::Shared<birch::type::FactorRecord>& record, const libbirch::Shared<birch::type::FactorEvent>& event) {
  #line 122 "src/handler/MoveHandler.birch"
  libbirch_function_("doHandle", "src/handler/MoveHandler.birch", 122);
  #line 124 "src/handler/MoveHandler.birch"
  libbirch_line_(124);
  #line 124 "src/handler/MoveHandler.birch"
  this->doHandle(event);
}

#line 131 "src/handler/MoveHandler.birch"
libbirch::Shared<birch::type::MoveHandler> birch::MoveHandler(const birch::type::Boolean& delayed) {
  #line 131 "src/handler/MoveHandler.birch"
  libbirch_function_("MoveHandler", "src/handler/MoveHandler.birch", 131);
  #line 132 "src/handler/MoveHandler.birch"
  libbirch_line_(132);
  #line 132 "src/handler/MoveHandler.birch"
  return birch::construct<libbirch::Shared<birch::type::MoveHandler>>(delayed);
}

#line 1 "src/handler/PlayHandler.birch"
birch::type::PlayHandler::PlayHandler(const birch::type::Boolean& delayed) :
    #line 1 "src/handler/PlayHandler.birch"
    base_type_(),
    #line 19 "src/handler/PlayHandler.birch"
    delayed(std::move(delayed)) {
  //
}

#line 21 "src/handler/PlayHandler.birch"
void birch::type::PlayHandler::doHandle(const libbirch::Shared<birch::type::Event>& event) {
  #line 21 "src/handler/PlayHandler.birch"
  libbirch_function_("doHandle", "src/handler/PlayHandler.birch", 21);
  #line 23 "src/handler/PlayHandler.birch"
  libbirch_line_(23);
  #line 23 "src/handler/PlayHandler.birch"
  event->accept(this->shared_from_this_());
}

#line 26 "src/handler/PlayHandler.birch"
void birch::type::PlayHandler::doHandle(const libbirch::Shared<birch::type::Record>& record, const libbirch::Shared<birch::type::Event>& event) {
  #line 26 "src/handler/PlayHandler.birch"
  libbirch_function_("doHandle", "src/handler/PlayHandler.birch", 26);
  #line 28 "src/handler/PlayHandler.birch"
  libbirch_line_(28);
  #line 28 "src/handler/PlayHandler.birch"
  event->accept(record, this->shared_from_this_());
}

#line 49 "src/handler/PlayHandler.birch"
void birch::type::PlayHandler::doHandle(const libbirch::Shared<birch::type::FactorEvent>& event) {
  #line 49 "src/handler/PlayHandler.birch"
  libbirch_function_("doHandle", "src/handler/PlayHandler.birch", 49);
  #line 50 "src/handler/PlayHandler.birch"
  libbirch_line_(50);
  #line 50 "src/handler/PlayHandler.birch"
  this->w = this->w + event->w->value();
}

#line 86 "src/handler/PlayHandler.birch"
void birch::type::PlayHandler::doHandle(const libbirch::Shared<birch::type::FactorRecord>& record, const libbirch::Shared<birch::type::FactorEvent>& event) {
  #line 86 "src/handler/PlayHandler.birch"
  libbirch_function_("doHandle", "src/handler/PlayHandler.birch", 86);
  #line 88 "src/handler/PlayHandler.birch"
  libbirch_line_(88);
  #line 88 "src/handler/PlayHandler.birch"
  this->w = this->w + event->w->value();
}

#line 95 "src/handler/PlayHandler.birch"
libbirch::Shared<birch::type::PlayHandler> birch::PlayHandler(const birch::type::Boolean& delayed) {
  #line 95 "src/handler/PlayHandler.birch"
  libbirch_function_("PlayHandler", "src/handler/PlayHandler.birch", 95);
  #line 96 "src/handler/PlayHandler.birch"
  libbirch_line_(96);
  #line 96 "src/handler/PlayHandler.birch"
  return birch::construct<libbirch::Shared<birch::type::PlayHandler>>(delayed);
}

